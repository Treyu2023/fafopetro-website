@echo off
title FAFO — Add video folder for Explorer metadata
cd /d "%~dp0"

echo.
echo  Add a folder so FAFO can write Tags/Ratings into real files.
echo  Subfolders are included automatically (rolled up).
echo  The metadata server must already be running (START_META_SERVER.bat).
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Run INSTALL_DEPS.bat first.
  pause
  exit /b 1
)

if "%~1"=="" (
  echo  A Windows folder window will open.
  echo  Pick the parent folder — you do not need the exact path.
  echo.
  python "%~dp0add_folder.py" --pick
) else (
  python "%~dp0add_folder.py" "%~1"
)
echo.
pause
