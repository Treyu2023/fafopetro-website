// FAFO Ultimate Tab — service worker (context menu + action)

// Open Options when the toolbar icon is clicked
chrome.action.onClicked.addListener(() => {
    try {
        chrome.runtime.openOptionsPage();
    } catch (e) {
        console.warn('openOptionsPage failed', e);
    }
});

// 1. Init Context Menu
chrome.runtime.onInstalled.addListener(() => {
    try {
        chrome.contextMenus.removeAll(() => {
            chrome.contextMenus.create({
                id: "fafo-save-media",
                title: "⚡ Add to FAFO Library",
                contexts: ["image", "video", "audio"]
            });
        });
    } catch (e) {
        chrome.contextMenus.create({
            id: "fafo-save-media",
            title: "⚡ Add to FAFO Library",
            contexts: ["image", "video", "audio"]
        });
    }
});

// 2. Handle Clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "fafo-save-media") {
        const url = info.srcUrl;
        if (!url) return;

        // Notify user via badge
        chrome.action.setBadgeText({text: "⬇️"});
        chrome.action.setBadgeBackgroundColor({ color: "#00e5ff" });
        
        try {
            const type = info.mediaType === 'video' ? 'videos' : 'photos';
            await downloadAndStore(url, type);
            
            chrome.action.setBadgeText({text: "✔"});
            chrome.action.setBadgeBackgroundColor({ color: "#00ff00" });
            
            setTimeout(() => chrome.action.setBadgeText({text: ""}), 3000);
        } catch (e) {
            console.error("Save failed", e);
            chrome.action.setBadgeText({text: "ERR"});
            chrome.action.setBadgeBackgroundColor({ color: "#ff0000" });
            setTimeout(() => chrome.action.setBadgeText({text: ""}), 5000);
        }
    }
});

// 3. Download & Store Logic
async function downloadAndStore(url, storeName) {
    try {
        // Fetch blob
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP error! status: ${resp.status}`);
        const blob = await resp.blob();
        
        // Generate filename from URL or Timestamp
        const typePart = blob.type.split('/')[1] || 'dat';
        // Clean URL to make a safe filename
        const cleanUrl = url.split('/').pop().split('?')[0].substring(0, 30).replace(/[^a-zA-Z0-9._-]/g, '_');
        const filename = `webclip_${Date.now()}_${cleanUrl}.${typePart}`;
        
        // Create File object (Shim for IndexedDB storage)
        const file = new File([blob], filename, { type: blob.type });

        // Open DB & Save
        return new Promise((resolve, reject) => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            
            req.onupgradeneeded = e => {
                const d = e.target.result;
                if (!d.objectStoreNames.contains('videos')) d.createObjectStore('videos', {autoIncrement: true});
                if (!d.objectStoreNames.contains('photos')) d.createObjectStore('photos', {autoIncrement: true});
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', {keyPath: 'id'});
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', {keyPath: 'id'});
            };

            req.onsuccess = () => {
                const db = req.result;
                const tx = db.transaction(storeName, 'readwrite');
                const store = tx.objectStore(storeName);
                store.put(file, crypto.randomUUID());
                
                tx.oncomplete = () => resolve();
                tx.onerror = e => reject(e);
            };
            
            req.onerror = e => reject(e);
        });
    } catch (err) {
        throw err;
    }
}