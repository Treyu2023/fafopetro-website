# Chrome Web Store readiness — FAFO Ultimate Tab

**Assessment date:** 2026-08-13  
**Dev tip (this tree):** `manifest.json` **6.4.76**  
**Git repo root:** `fafo-chrome-extensions` (not the parent `html` folder)  
**Verdict:** **Yes — still uploadable**, with packaging discipline and a few review-hardening steps.  
Not blocked by architecture. Not “drop the zip of the whole LOAD THIS folder and pray.”

---

## Short answer

| Question | Answer |
|----------|--------|
| Can this still go to the **Chrome Web Store**? | **Yes.** MV3 new-tab media center is a valid single purpose. |
| Is the **current working tree** store-zip ready as-is? | **No.** Ship an **extension-only package**, not explorer-meta / backups / user JSON. |
| Do we need a **split branch**? | **Recommended.** Keep `main` as full local power-user; maintain `store/chrome-web-store` for review-safe packaging + tighter manifest. |
| Hard policy kill-switch? | **None found.** Risks are review friction, permission justification, and package hygiene. |

---

## What already looks store-compatible

- **Manifest V3** (`manifest_version: 3`)
- **Single purpose** is coherent: cinematic **new tab** for **local** videos/photos + tags/playlists/FX
- **Narrow host access:** only `http://127.0.0.1:8765/*` and `http://localhost:8765/*` (optional companion)
- **No remote-hosted code** (no CDN script injection / no remote eval of extension logic)
- **Permissions are explainable:**
  - `storage` / `unlimitedStorage` — tags, library index, vaults, prefs, backups in Chrome storage
  - `contextMenus` — “Add to FAFO Library” on page images/videos
- New-tab override (`chrome_url_overrides.newtab`) is **allowed** when the product *is* a new-tab experience
- Listing / packaging docs already exist: `STORE_LISTING.md`, `DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md`
- Package size without media is small (core JS/HTML/CSS ≪ store limits)

---

## Review friction / soft blockers (fix before upload)

1. **Package contents**  
   Do **not** zip:
   - `explorer-meta\` (ship companion on FAFOPetro.com)
   - `Videos\` / `Photos\` / large media
   - `explorer-meta\FAFO-Backups\`, `configs\` user dumps, `fafo-tags-backup-*.json`
   - `__pycache__`, machine-local `*.local.json`, docs you don’t want public  
   Use `tools/package-store-zip.ps1` on the store branch.

2. **`web_accessible_resources` + `matches: ["<all_urls>"]`**  
   Broad WAR is leftover “bundled Videos on any page” thinking. Store branch should **narrow or remove** unused WAR. Reviewers scrutinize `<all_urls>` patterns.

3. **Host permissions at install time**  
   Localhost is fine if justified, but **optional host permissions** are cleaner: extension works offline without companion; prompt only when Explorer sync is used. Store branch prefers `optional_host_permissions`.

4. **Privacy policy URL**  
   Dashboard field + public page on **https://www.FAFOPetro.com** (or dedicated privacy page). Must match reality: no cloud media upload, optional local companion, Chrome storage for tags/settings.

5. **Icons**  
   Store requires **128×128** PNG (present). Prefer also **16** and **48** in `manifest.icons` for polish.

6. **Listing honesty**  
   Update `STORE_LISTING.md` when features land (private vaults, tag DB, wall mode). Don’t claim cloud sync or “unbreakable encryption” beyond what the code does (local PIN-gated vaults + opaque tag DB).

7. **Context-menu fetch**  
   `background.js` `fetch(srcUrl)` only works when the origin allows it (CORS / accessible URL). Not a store ban, but don’t market “save any video from any site” as 100% reliable.

8. **Single purpose / feature sprawl**  
   Keep store description centered on **new-tab local media center**. Vaults, wall, pairing, FX are still that product. Avoid sounding like a general browser toolkit.

9. **Version story**  
   Public store was around **2.9** → catch-up **6.4.x**. Dirty jumps are fine if “What’s new” explains them (already drafted in listing docs).

10. **Uncommitted / local-only surface**  
    Dev tree can run ahead of the last published package. Always upload from a **tagged store package**, not a random dirty folder.

---

## Dev line vs store line

| Branch / tip | Role |
|--------------|------|
| `main` (dev) | Full power-user: wall scalability, multi vaults, opaque tag DB, chrome art, explorer-meta sources in tree |
| Tag `milestone/ultimate-tab-6.4.59-pre-store-split` | Frozen **pre-split** point for this assessment |
| `store/chrome-web-store` | Review-oriented: packaging script, tighter WAR/permissions, store zip excludes, listing checklist |

Both share product DNA. Store branch is not a rewrite — it’s **ship hygiene + permission minimums**.

---

## Dashboard checklist (each upload)

- [ ] Bump `manifest.json` `version` (must increase every package)
- [ ] Run `tools/package-store-zip.ps1` → inspect zip file list
- [ ] Confirm no Videos / no FAFO-Backups / no user JSON dumps
- [ ] Privacy policy URL live and accurate
- [ ] Single-purpose + permission justifications filled
- [ ] Screenshots: cinema, tags, wall (optional), Options library
- [ ] Homepage: https://www.FAFOPetro.com
- [ ] Companion download separate (not inside extension zip)
- [ ] Submit → wait review (localhost-only is usually faster than `<all_urls>`)

---

## Related docs

- `STORE_LISTING.md` — paste-ready listing copy  
- `DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md` — publisher workflow  
- `MILESTONE_STORE_SPLIT_v6.4.59.md` — freeze pointer + branch intent  
- `TAGS_AND_RATINGS.md` — end-user companion setup  

---

## Bottom line

**Capable of Google Chrome Web Store upload: yes.**  
Treat store as a **disciplined package + slightly tighter manifest**, not as abandoning the project. Keep the wild local features on `main`; ship from `store/chrome-web-store` when you want review to stay boring.
