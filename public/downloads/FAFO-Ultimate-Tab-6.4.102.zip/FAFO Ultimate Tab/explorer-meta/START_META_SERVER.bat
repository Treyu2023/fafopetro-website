@echo off
setlocal EnableExtensions
title FAFO Explorer Metadata Server
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Run INSTALL_DEPS.bat first.
  pause
  exit /b 1
)

REM Ensure deps exist (quiet)
python -c "import fastapi, uvicorn, mutagen" 2>nul
if errorlevel 1 (
  echo Missing packages — running INSTALL_DEPS.bat ...
  call "%~dp0INSTALL_DEPS.bat"
)

python -c "from win32com.propsys import propsys" 2>nul
if errorlevel 1 (
  echo Installing pywin32...
  python -m pip install -q pywin32
)

echo.
echo  FAFO Explorer Metadata Server
echo  -----------------------------

REM 1) Already healthy? Do not start a second copy.
python -c "import urllib.request,sys; urllib.request.urlopen('http://127.0.0.1:8765/api/health', timeout=2); sys.exit(0)" 2>nul
if not errorlevel 1 (
  echo.
  echo  [OK] Already running at http://127.0.0.1:8765
  echo       Tags / ratings companion is up — leave the other window open.
  echo       Close this window.
  echo.
  echo  To force a restart, run:  RESTART_META_SERVER.bat
  echo.
  pause
  exit /b 0
)

REM 2) Port busy or dead process? Free 8765 then start.
echo  Port check / free 8765 if needed...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$con = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue;" ^
  "if (-not $con) { exit 0 }" ^
  "$pids = @($con | Select-Object -ExpandProperty OwningProcess -Unique);" ^
  "foreach ($pid in $pids) {" ^
  "  if ($pid -and $pid -gt 0) {" ^
  "    try {" ^
  "      $p = Get-Process -Id $pid -ErrorAction Stop;" ^
  "      Write-Host ('  Stopping PID {0} ({1}) holding port 8765...' -f $pid, $p.ProcessName);" ^
  "      Stop-Process -Id $pid -Force -ErrorAction Stop;" ^
  "    } catch { Write-Host ('  Could not stop PID {0}: {1}' -f $pid, $_.Exception.Message) }" ^
  "  }" ^
  "}" ^
  "Start-Sleep -Seconds 1"

REM Double-check nothing still listening
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "if (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue) { exit 1 } else { exit 0 }"
if errorlevel 1 (
  echo.
  echo  [ERROR] Port 8765 is still busy after kill attempt.
  echo  Run RESTART_META_SERVER.bat as Administrator, or manually:
  echo    Get-NetTCPConnection -LocalPort 8765 -State Listen
  echo    Stop-Process -Id ^<PID^> -Force
  echo.
  pause
  exit /b 1
)

echo.
echo  Starting on http://127.0.0.1:8765
echo  Leave this window open while you use FAFO tags / ratings.
echo.

python "%~dp0server.py"
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" (
  echo.
  echo  Server exited with error code %ERR%.
  echo  If WinError 10048: run RESTART_META_SERVER.bat
  pause
)
exit /b %ERR%
