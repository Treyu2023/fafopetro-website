/**
 * FAFO Local Media — cinematic capability intro (v7.1).
 * Full-viewport multi-phase sequence: neon lettering, feature demos,
 * border FX — one continuous “trailer” while the app boots.
 */
class FafoIntroSplash {
    /**
     * Capability beats shown in order (title + short demo label).
     * Each beat gets a neon style class on the wordmark / feature line.
     */
    static FEATURE_BEATS = [
        { id: 'cinema', title: 'Cinema Engine', sub: 'Full-screen scale · ambilight · HUD', style: 'neon-cyan' },
        { id: 'tags', title: 'Tags & Ratings', sub: 'Hotkeys · bulk Explorer sync · library', style: 'neon-amber' },
        { id: 'explorer', title: 'Explorer Companion', sub: 'Real file Tags / Rating on disk', style: 'neon-lime' },
        { id: 'neon', title: 'Audio-Reactive Neon', sub: 'Borders that pulse with the track', style: 'neon-magenta' },
        { id: 'particles', title: 'Atmosphere FX', sub: 'Particles · bokeh · vignette', style: 'neon-violet' },
        { id: 'one', title: 'One Package', sub: 'New tab · tags · neon · done', style: 'neon-white' },
    ];

    constructor(rootEl, opts = {}) {
        this.root = rootEl;
        this.canvas = rootEl?.querySelector('canvas') || null;
        this.statusEl = rootEl?.querySelector('.intro-status') || null;
        this.barFill = rootEl?.querySelector('.intro-bar-fill') || null;
        this.versionEl = rootEl?.querySelector('.intro-version') || null;
        this.featureTitleEl = rootEl?.querySelector('.intro-feature-title') || null;
        this.featureSubEl = rootEl?.querySelector('.intro-feature-sub') || null;
        this.capsEl = rootEl?.querySelector('.intro-caps') || null;
        this.wordmarkEl = rootEl?.querySelector('.intro-wordmark') || null;
        this.frameEl = rootEl?.querySelector('.intro-neon-frame') || null;
        this.letters = rootEl ? [...rootEl.querySelectorAll('.intro-letter')] : [];
        this.accent = opts.accent || '#00e5ff';
        this.version = opts.version || '7.1.0';
        /** Total sequence length (ms). Boot can finish earlier; we still play the demo. */
        this.minDurationMs = opts.minDurationMs ?? 7200;
        this.progress = 0;
        this.targetProgress = 0;
        this.bootComplete = false;
        this.rafId = null;
        this.t0 = performance.now();
        this.orbs = [];
        this.sparks = [];
        this.beams = [];
        this.done = false;
        this.reduced = false;
        this.phase = 0;
        this.beatIndex = -1;
        this._resize = () => this.resize();
        this._onKey = (e) => {
            if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.skip();
            }
        };
    }

    static mount(doc = document, opts = {}) {
        let el = doc.getElementById('fafo-intro');
        if (!el) {
            el = doc.createElement('div');
            el.id = 'fafo-intro';
            el.className = 'fafo-intro';
            el.setAttribute('role', 'dialog');
            el.setAttribute('aria-label', 'FAFO Local Media intro');
            el.innerHTML = `
                <canvas class="intro-canvas" aria-hidden="true"></canvas>
                <div class="intro-grid" aria-hidden="true"></div>
                <div class="intro-scanlines" aria-hidden="true"></div>
                <div class="intro-neon-frame" aria-hidden="true">
                    <span class="intro-neon-corner tl"></span>
                    <span class="intro-neon-corner tr"></span>
                    <span class="intro-neon-corner bl"></span>
                    <span class="intro-neon-corner br"></span>
                    <span class="intro-neon-edge top"></span>
                    <span class="intro-neon-edge right"></span>
                    <span class="intro-neon-edge bottom"></span>
                    <span class="intro-neon-edge left"></span>
                </div>
                <div class="intro-vignette"></div>
                <div class="intro-stage">
                    <div class="intro-content">
                        <div class="intro-mark" aria-hidden="true">
                            <span class="intro-ring"></span>
                            <span class="intro-ring delay"></span>
                            <span class="intro-ring delay2"></span>
                            <span class="intro-core">
                                <svg viewBox="0 0 64 64" class="intro-logo-svg" aria-hidden="true">
                                    <defs>
                                        <linearGradient id="fafoG" x1="0%" y1="0%" x2="100%" y2="100%">
                                            <stop offset="0%" stop-color="#ffffff"/>
                                            <stop offset="45%" stop-color="var(--intro-accent, #00e5ff)"/>
                                            <stop offset="100%" stop-color="#7c5cff"/>
                                        </linearGradient>
                                    </defs>
                                    <path fill="url(#fafoG)" d="M14 12h28c6 0 10 4 10 10v6c0 4-2 7-6 9l-12 7v8h-10V12zm10 10v12l8-5c2-1 3-2 3-4v-3c0-1-1-2-2-2H24z"/>
                                    <circle cx="48" cy="48" r="5" fill="url(#fafoG)" opacity="0.9"/>
                                </svg>
                            </span>
                        </div>
                        <div class="intro-wordmark" data-style="neon-cyan">
                            <div class="intro-fafo-letters" aria-label="FAFO">
                                <span class="intro-letter" data-i="0">F</span>
                                <span class="intro-letter" data-i="1">A</span>
                                <span class="intro-letter" data-i="2">F</span>
                                <span class="intro-letter" data-i="3">O</span>
                            </div>
                            <div class="intro-local">Local Media</div>
                        </div>
                        <div class="intro-feature" aria-live="polite">
                            <div class="intro-feature-title">Powering up…</div>
                            <div class="intro-feature-sub">Cinematic boot sequence</div>
                        </div>
                        <div class="intro-caps" aria-hidden="true"></div>
                        <div class="intro-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                            <div class="intro-bar-fill"></div>
                        </div>
                        <div class="intro-status">Starting…</div>
                        <div class="intro-version"></div>
                        <button type="button" class="intro-skip" title="Skip intro (Esc)">Skip · Esc</button>
                    </div>
                </div>
            `;
            doc.body.appendChild(el);
        }
        doc.body.classList.add('fafo-intro-active');
        const splash = new FafoIntroSplash(el, opts);
        splash.start();
        return splash;
    }

    setAccent(hex) {
        this.accent = hex || this.accent;
        if (this.root) this.root.style.setProperty('--intro-accent', this.accent);
    }

    setVersion(v) {
        this.version = v || this.version;
        if (this.versionEl) this.versionEl.textContent = this.version ? `v${this.version}` : '';
    }

    resize() {
        if (!this.canvas) return;
        const dpr = Math.min(window.devicePixelRatio || 1, 2);
        // Full browser window (handles scaled OS displays)
        const w = Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1);
        const h = Math.max(1, window.innerHeight || document.documentElement.clientHeight || 1);
        this.canvas.width = Math.floor(w * dpr);
        this.canvas.height = Math.floor(h * dpr);
        this.canvas.style.width = w + 'px';
        this.canvas.style.height = h + 'px';
        const ctx = this.canvas.getContext('2d');
        if (ctx) ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        this.w = w;
        this.h = h;
        // Scale stage content with the shorter viewport edge
        if (this.root) {
            const s = Math.min(1.15, Math.max(0.72, Math.min(w / 1280, h / 720)));
            this.root.style.setProperty('--intro-scale', String(s));
        }
    }

    start() {
        if (!this.root) return;
        this.root.classList.remove('intro-done', 'intro-hidden');
        this.setAccent(this.accent);
        this.setVersion(this.version);
        this.reduced = !!window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
        if (this.reduced) this.minDurationMs = Math.min(this.minDurationMs, 1800);

        this.resize();
        window.addEventListener('resize', this._resize);
        document.addEventListener('keydown', this._onKey, true);
        this.root.querySelector('.intro-skip')?.addEventListener('click', () => this.skip());

        this._buildCaps();
        this.root.classList.add('intro-phase-0');

        const n = this.reduced ? 12 : 48;
        const scale = Math.min(this.w, this.h) / 900;
        this.orbs = Array.from({ length: n }, (_, i) => ({
            a: (i / n) * Math.PI * 2,
            r: (90 + (i % 10) * 32 + Math.random() * 40) * scale,
            s: 0.1 + (i % 7) * 0.035,
            size: (1.2 + (i % 5) * 0.45) * scale,
            phase: Math.random() * Math.PI * 2,
        }));
        this.sparks = Array.from({ length: this.reduced ? 10 : 36 }, () => ({
            x: Math.random(),
            y: Math.random(),
            v: 0.12 + Math.random() * 0.45,
            a: Math.random() * Math.PI * 2,
            life: Math.random(),
        }));
        this.beams = Array.from({ length: 5 }, (_, i) => ({
            y: 0.15 + i * 0.16,
            speed: 0.08 + i * 0.02,
            phase: i * 0.7,
        }));

        const loop = (now) => {
            if (this.done) return;
            // Smooth bar; time-based floor so sequence always advances
            const elapsed = now - this.t0;
            const timePct = Math.min(1, elapsed / this.minDurationMs);
            const blended = Math.max(this.targetProgress * 0.55 + timePct * 0.45, timePct * 0.85);
            this.progress += (blended - this.progress) * (this.reduced ? 0.18 : 0.07);
            this._tickTimeline(elapsed / 1000);
            this.draw(now);
            if (this.barFill) this.barFill.style.width = `${Math.min(100, this.progress * 100)}%`;
            const bar = this.root.querySelector('.intro-bar');
            if (bar) bar.setAttribute('aria-valuenow', String(Math.round(this.progress * 100)));
            this.rafId = requestAnimationFrame(loop);
        };
        this.rafId = requestAnimationFrame(loop);
    }

    _buildCaps() {
        if (!this.capsEl) return;
        this.capsEl.innerHTML = FafoIntroSplash.FEATURE_BEATS.map((b, i) =>
            `<span class="intro-cap" data-cap="${b.id}" data-i="${i}">${this._escape(b.title.split(' ')[0])}</span>`
        ).join('');
    }

    _escape(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    /**
     * Sequential “one long video” timeline — phases flow without hard cuts.
     * t is seconds since start.
     */
    _tickTimeline(t) {
        const d = this.reduced ? 0.35 : 1;
        // Phase 0 — black power-up
        if (t < 0.55 * d) {
            this._setPhase(0);
            this._setFeature('Powering systems', 'Neon · particles · cinema');
            return;
        }
        // Phase 1 — letter ignite
        if (t < 1.9 * d) {
            this._setPhase(1);
            this._setFeature('FAFO', 'Local Media package');
            const lit = Math.min(4, Math.floor((t - 0.55 * d) / (0.28 * d)) + 1);
            this.letters.forEach((el, i) => {
                el.classList.toggle('lit', i < lit);
                el.classList.toggle('glow-pulse', i === lit - 1);
            });
            return;
        }
        // Phase 2 — subtitle + full neon wordmark
        if (t < 2.7 * d) {
            this._setPhase(2);
            this.letters.forEach((el) => {
                el.classList.add('lit');
                el.classList.remove('glow-pulse');
            });
            this.wordmarkEl?.classList.add('intro-wm-alive');
            this._setFeature('Local Media', 'One extension · full cinema stack');
            this._setNeonStyle('neon-cyan');
            return;
        }
        // Phase 3 — feature beats (capability showcase)
        const beatStart = 2.7 * d;
        const beatLen = 0.72 * d;
        const beats = FafoIntroSplash.FEATURE_BEATS;
        const bi = Math.min(beats.length - 1, Math.floor((t - beatStart) / beatLen));
        if (t < beatStart + beats.length * beatLen) {
            this._setPhase(3);
            if (bi !== this.beatIndex) {
                this.beatIndex = bi;
                const beat = beats[bi];
                this._setFeature(beat.title, beat.sub);
                this._setNeonStyle(beat.style);
                this._lightCap(bi);
                this.root?.classList.toggle('intro-flicker', bi % 2 === 1);
            }
            return;
        }
        // Phase 4 — finale merge
        this._setPhase(4);
        this.root?.classList.remove('intro-flicker');
        this._setNeonStyle('neon-cyan');
        this._setFeature('Ready', this.bootComplete ? 'Entering cinema' : 'Finishing boot…');
        this.letters.forEach((el) => el.classList.add('lit', 'finale'));
        if (this.capsEl) {
            this.capsEl.querySelectorAll('.intro-cap').forEach((c) => c.classList.add('on'));
        }
    }

    _setPhase(p) {
        if (this.phase === p) return;
        this.phase = p;
        if (!this.root) return;
        for (let i = 0; i <= 4; i++) this.root.classList.toggle(`intro-phase-${i}`, i === p);
        this.frameEl?.classList.toggle('active', p >= 2);
        this.frameEl?.classList.toggle('finale', p >= 4);
    }

    _setFeature(title, sub) {
        if (this.featureTitleEl && this.featureTitleEl.textContent !== title) {
            this.featureTitleEl.textContent = title;
            this.featureTitleEl.classList.remove('intro-pop');
            // reflow for CSS re-trigger
            void this.featureTitleEl.offsetWidth;
            this.featureTitleEl.classList.add('intro-pop');
        }
        if (this.featureSubEl && sub != null) this.featureSubEl.textContent = sub;
    }

    _setNeonStyle(style) {
        if (!this.wordmarkEl) return;
        const styles = ['neon-cyan', 'neon-amber', 'neon-lime', 'neon-magenta', 'neon-violet', 'neon-white'];
        styles.forEach((s) => this.wordmarkEl.classList.toggle(s, s === style));
        this.wordmarkEl.dataset.style = style;
        this.root?.style.setProperty('--intro-feature-glow', this._styleColor(style));
        if (this.frameEl) {
            styles.forEach((s) => this.frameEl.classList.toggle(s, s === style));
        }
    }

    _styleColor(style) {
        switch (style) {
            case 'neon-amber': return '#ffc107';
            case 'neon-lime': return '#00ff88';
            case 'neon-magenta': return '#ff2bd6';
            case 'neon-violet': return '#a78bfa';
            case 'neon-white': return '#ffffff';
            default: return this.accent || '#00e5ff';
        }
    }

    _lightCap(index) {
        if (!this.capsEl) return;
        this.capsEl.querySelectorAll('.intro-cap').forEach((el, i) => {
            el.classList.toggle('on', i <= index);
            el.classList.toggle('current', i === index);
        });
    }

    setStatus(text, pct) {
        if (this.statusEl && text != null) this.statusEl.textContent = text;
        if (pct != null) this.targetProgress = Math.max(this.targetProgress, Math.min(1, pct));
    }

    draw(now) {
        const ctx = this.canvas?.getContext('2d');
        if (!ctx || !this.w) return;
        const t = (now - this.t0) * 0.001;
        const w = this.w;
        const h = this.h;
        const cx = w * 0.5;
        const cy = h * 0.42;
        const rgb = this.hexToRgb(this.accent);
        const scale = Math.min(w, h) / 900;

        ctx.clearRect(0, 0, w, h);

        // Full-frame ambient wash (scales with window)
        const washR = Math.max(w, h) * (0.55 + Math.sin(t * 0.4) * 0.04);
        const bg = ctx.createRadialGradient(cx, cy, 20 * scale, cx, cy, washR);
        const intensity = this.phase === 0 ? 0.06 + t * 0.12 : 0.16;
        bg.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${intensity})`);
        bg.addColorStop(0.35, `rgba(124,92,255,${0.04 + this.phase * 0.01})`);
        bg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, w, h);

        // Power-on expanding ring
        if (this.phase === 0) {
            const r = Math.min(w, h) * (0.05 + t * 0.55);
            ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},${Math.max(0, 0.7 - t)})`;
            ctx.lineWidth = 3 * scale;
            ctx.beginPath();
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Horizon
        const hy = h * 0.78;
        const hg = ctx.createLinearGradient(0, hy, w, hy);
        hg.addColorStop(0, 'rgba(0,0,0,0)');
        hg.addColorStop(0.5, `rgba(${rgb.r},${rgb.g},${rgb.b},0.22)`);
        hg.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.strokeStyle = hg;
        ctx.lineWidth = 1.5 * scale;
        ctx.beginPath();
        ctx.moveTo(w * 0.06, hy);
        ctx.lineTo(w * 0.94, hy);
        ctx.stroke();

        ctx.globalCompositeOperation = 'screen';

        // Orbits — larger on big screens
        for (const o of this.orbs) {
            const ang = o.a + t * o.s;
            const x = cx + Math.cos(ang) * o.r * (1 + Math.sin(t * 0.7 + o.phase) * 0.05);
            const y = cy + Math.sin(ang) * o.r * 0.55 * (1 + Math.cos(t * 0.5 + o.phase) * 0.06);
            const pulse = 0.3 + Math.sin(t * 2.2 + o.phase) * 0.28;
            const rad = o.size * 8;
            const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
            g.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},${0.55 * pulse})`);
            g.addColorStop(0.45, `rgba(124,92,255,${0.14 * pulse})`);
            g.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(x, y, rad, 0, Math.PI * 2);
            ctx.fill();
        }

        // Sparks
        for (const s of this.sparks) {
            s.life += s.v * 0.016;
            const px = (s.x + Math.cos(s.a + t * s.v) * 0.04) * w;
            const py = ((s.y + t * s.v * 0.045) % 1) * h;
            const a = 0.12 + (Math.sin(s.life * 6) * 0.5 + 0.5) * 0.5;
            ctx.fillStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},${a})`;
            ctx.beginPath();
            ctx.arc(px, py, 1.4 * scale, 0, Math.PI * 2);
            ctx.fill();
        }

        // Horizontal neon beams during feature showcase
        if (this.phase >= 3) {
            for (const b of this.beams) {
                const y = ((b.y + t * b.speed) % 1) * h;
                const g = ctx.createLinearGradient(0, y, w, y);
                g.addColorStop(0, 'rgba(0,0,0,0)');
                g.addColorStop(0.5, `rgba(${rgb.r},${rgb.g},${rgb.b},0.12)`);
                g.addColorStop(1, 'rgba(0,0,0,0)');
                ctx.strokeStyle = g;
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(0, y);
                ctx.lineTo(w, y);
                ctx.stroke();
            }
        }

        // Traveling border light (demo of neon frame capability)
        if (this.phase >= 2) {
            const pad = Math.min(w, h) * 0.035;
            const peri = 2 * ((w - pad * 2) + (h - pad * 2));
            const pos = ((t * 0.22) % 1) * peri;
            const pt = this._pointOnRect(pad, pad, w - pad * 2, h - pad * 2, pos);
            const g = ctx.createRadialGradient(pt.x, pt.y, 0, pt.x, pt.y, 48 * scale);
            g.addColorStop(0, `rgba(${rgb.r},${rgb.g},${rgb.b},0.85)`);
            g.addColorStop(0.4, `rgba(255,255,255,0.25)`);
            g.addColorStop(1, 'rgba(0,0,0,0)');
            ctx.fillStyle = g;
            ctx.beginPath();
            ctx.arc(pt.x, pt.y, 48 * scale, 0, Math.PI * 2);
            ctx.fill();
        }

        // Dual scan arcs around brand center
        const sweep = (t * 1.35) % (Math.PI * 2);
        const baseR = 100 * scale * (this.phase >= 4 ? 1.15 : 1);
        ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.42)`;
        ctx.lineWidth = 2 * scale;
        ctx.beginPath();
        ctx.arc(cx, cy, baseR + Math.sin(t) * 6 * scale, sweep, sweep + 1.15);
        ctx.stroke();
        ctx.strokeStyle = `rgba(124,92,255,0.3)`;
        ctx.lineWidth = 1.5 * scale;
        ctx.beginPath();
        ctx.arc(cx, cy, baseR * 1.28, -sweep * 0.9, -sweep * 0.9 + 2.1);
        ctx.stroke();

        // Progress ring
        const p = Math.max(0.02, this.progress);
        ctx.strokeStyle = `rgba(${rgb.r},${rgb.g},${rgb.b},0.7)`;
        ctx.lineWidth = 3 * scale;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.arc(cx, cy, baseR * 0.85, -Math.PI / 2, -Math.PI / 2 + p * Math.PI * 2);
        ctx.stroke();

        // Chromatic glitch flashes on odd beats
        if (this.phase === 3 && Math.floor(t * 3) % 7 === 0) {
            ctx.fillStyle = `rgba(255,0,80,0.04)`;
            ctx.fillRect(0, 0, w, h);
            ctx.fillStyle = `rgba(0,255,255,0.03)`;
            ctx.fillRect(2 * scale, 0, w, h);
        }

        ctx.globalCompositeOperation = 'source-over';
    }

    /** Perimeter position on a rectangle (for traveling neon). */
    _pointOnRect(x, y, rw, rh, dist) {
        const peri = 2 * (rw + rh);
        let d = ((dist % peri) + peri) % peri;
        if (d < rw) return { x: x + d, y };
        d -= rw;
        if (d < rh) return { x: x + rw, y: y + d };
        d -= rh;
        if (d < rw) return { x: x + rw - d, y: y + rh };
        d -= rw;
        return { x, y: y + rh - d };
    }

    hexToRgb(hex) {
        const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#00e5ff');
        return m
            ? { r: parseInt(m[1], 16), g: parseInt(m[2], 16), b: parseInt(m[3], 16) }
            : { r: 0, g: 229, b: 255 };
    }

    skip() {
        this.minDurationMs = 0;
        this.bootComplete = true;
        this.targetProgress = 1;
        this.progress = 1;
    }

    /**
     * Hold until boot is done AND the cinematic sequence has played.
     * @param {number} [extraHoldMs] additional ms after sequence (fade cushion)
     */
    async finish(extraHoldMs = 400) {
        this.bootComplete = true;
        this.targetProgress = 1;
        await new Promise((resolve) => {
            const wait = () => {
                if (this.done) {
                    resolve();
                    return;
                }
                const elapsed = performance.now() - this.t0;
                const longEnough = elapsed >= this.minDurationMs;
                const barReady = this.progress > 0.96;
                if (longEnough && barReady) resolve();
                else requestAnimationFrame(wait);
            };
            wait();
        });
        if (extraHoldMs > 0) await new Promise((r) => setTimeout(r, extraHoldMs));
        this.done = true;
        if (this.rafId) cancelAnimationFrame(this.rafId);
        window.removeEventListener('resize', this._resize);
        document.removeEventListener('keydown', this._onKey, true);
        document.body.classList.remove('fafo-intro-active');
        document.body.classList.add('fafo-ready');
        if (this.root) {
            this.root.classList.add('intro-done');
            await new Promise((r) => setTimeout(r, 700));
            this.root.classList.add('intro-hidden');
            try { this.root.remove(); } catch { /* ignore */ }
        }
    }

    destroy() {
        this.done = true;
        if (this.rafId) cancelAnimationFrame(this.rafId);
        window.removeEventListener('resize', this._resize);
        document.removeEventListener('keydown', this._onKey, true);
        document.body.classList.remove('fafo-intro-active');
        this.root?.remove();
    }
}

if (typeof window !== 'undefined') window.FafoIntroSplash = FafoIntroSplash;
