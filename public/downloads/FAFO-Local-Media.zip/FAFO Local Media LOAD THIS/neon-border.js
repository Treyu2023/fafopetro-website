/**
 * Audio-reactive neon border engine v3 — professional multi-pattern trim.
 * Supports light shapes, intensity, dual colors, corner styles, and advanced patterns.
 */
class NeonBorderEngine {
    constructor(frameEl, getConfig) {
        this.frame = frameEl;
        this.getConfig = getConfig;
        this.segments = [];
        this.rafId = null;
        this.audioCtx = null;
        this.analyser = null;
        this.audioData = null;
        this.connectedVideo = null;
        this.stackProgress = 0;
        this.smoothAudio = 0;
        this.smoothMids = 0;
        this.smoothHighs = 0;
        this.beatEnergy = 0;
        this.lastBeatTime = 0;
        this.beatFlash = 0;
        this.lightningTimer = 0;
        this.lightningSeg = 0;
        this.phase = 0;
    }

    getColor(cfg) {
        return cfg.neonUseAccent !== false ? (cfg.accentColor || '#00e5ff') : (cfg.neonColor || '#00e5ff');
    }

    getColor2(cfg) {
        return cfg.neonColor2 || this.getColor(cfg);
    }

    hexToRgb(hex) {
        const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return m ? { r: +m[1], g: +m[2], b: +m[3] } : { r: 0, g: 229, b: 255 };
    }

    lerpColor(c1, c2, t) {
        const a = this.hexToRgb(c1);
        const b = this.hexToRgb(c2);
        const u = Math.max(0, Math.min(1, t));
        const r = Math.round(a.r + (b.r - a.r) * u);
        const g = Math.round(a.g + (b.g - a.g) * u);
        const bl = Math.round(a.b + (b.b - a.b) * u);
        return `#${[r, g, bl].map((x) => x.toString(16).padStart(2, '0')).join('')}`;
    }

    rebuild() {
        const cfg = this.getConfig();
        if (!this.frame) return;
        this.frame.innerHTML = '';
        this.segments = [];
        if (!cfg.neonBorder) {
            this.frame.classList.add('hidden');
            return;
        }
        this.frame.classList.remove('hidden');
        const shape = cfg.neonShape || 'rounded';
        const corner = cfg.neonCornerStyle || 'nodes';
        this.frame.dataset.shape = shape;
        this.frame.dataset.corners = corner;
        this.frame.style.setProperty('--neon-intensity', String(cfg.neonIntensity ?? 1));
        this.frame.style.setProperty('--neon-glow-layers', String(cfg.neonGlowLayers ?? 2));

        const count = Math.max(8, Math.min(96, cfg.neonSegments || 32));
        const color = this.getColor(cfg);
        const w = cfg.neonWidth || 4;
        for (let i = 0; i < count; i++) {
            const seg = document.createElement('div');
            seg.className = 'neon-segment neon-shape-' + shape;
            seg.dataset.index = i;
            seg.style.setProperty('--neon-color', color);
            seg.style.setProperty('--neon-width', `${w}px`);
            this.frame.appendChild(seg);
            this.segments.push(seg);
        }
        this.layoutSegments(count);
        this.addCornerDecor(color, w, corner, shape);
    }

    addCornerDecor(color, w, style, shape) {
        if (!this.frame || style === 'none') return;
        const positions = ['tl', 'tr', 'br', 'bl'];
        positions.forEach((pos) => {
            if (style === 'brackets') {
                const h = document.createElement('div');
                h.className = `neon-bracket neon-bracket-h neon-corner-${pos}`;
                h.style.setProperty('--neon-color', color);
                h.style.setProperty('--neon-width', `${w}px`);
                const v = document.createElement('div');
                v.className = `neon-bracket neon-bracket-v neon-corner-${pos}`;
                v.style.setProperty('--neon-color', color);
                v.style.setProperty('--neon-width', `${w}px`);
                this.frame.appendChild(h);
                this.frame.appendChild(v);
            } else if (style === 'arcs') {
                const arc = document.createElement('div');
                arc.className = `neon-arc neon-corner-${pos}`;
                arc.style.setProperty('--neon-color', color);
                arc.style.setProperty('--neon-width', `${Math.max(2, w)}px`);
                this.frame.appendChild(arc);
            } else {
                // nodes (default) — diamond if shape diamond
                const node = document.createElement('div');
                node.className = `neon-corner neon-corner-${pos} neon-corner-${shape}`;
                node.style.setProperty('--neon-color', color);
                node.style.setProperty('--neon-width', `${w * 2}px`);
                this.frame.appendChild(node);
            }
        });
    }

    layoutSegments(count) {
        const perSide = Math.max(2, Math.ceil(count / 4));
        if (this.frame) this.frame.style.setProperty('--seg-span', String(perSide));
        this.segments.forEach((seg, i) => {
            const side = Math.min(3, Math.floor(i / perSide));
            const pos = (i % perSide) / Math.max(1, perSide - 1);
            // inset slightly from true corners for cleaner caps
            const inset = 0.02 + pos * 0.96;
            seg.style.opacity = '0.06';
            seg.classList.remove('top', 'bottom', 'left', 'right');
            seg.style.left = '';
            seg.style.right = '';
            seg.style.top = '';
            seg.style.bottom = '';
            if (side === 0) {
                seg.classList.add('top');
                seg.style.left = `${inset * 100}%`;
            } else if (side === 1) {
                seg.classList.add('right');
                seg.style.top = `${inset * 100}%`;
            } else if (side === 2) {
                seg.classList.add('bottom');
                seg.style.left = `${(1 - inset) * 100}%`;
            } else {
                seg.classList.add('left');
                seg.style.top = `${(1 - inset) * 100}%`;
            }
        });
    }

    async connectAudio(videoEl) {
        if (!videoEl || videoEl === this.connectedVideo) return;
        const cfg = this.getConfig();
        if (!cfg.neonBorder || cfg.neonAudio === false) return;
        this.disconnectAudio();
        this.connectedVideo = videoEl;
        try {
            this.audioCtx = new AudioContext();
            if (this.audioCtx.state === 'suspended') await this.audioCtx.resume();
            const source = this.audioCtx.createMediaElementSource(videoEl);
            this.analyser = this.audioCtx.createAnalyser();
            this.analyser.fftSize = 1024;
            this.analyser.smoothingTimeConstant = 0.62;
            source.connect(this.analyser);
            this.analyser.connect(this.audioCtx.destination);
            this.audioData = new Uint8Array(this.analyser.frequencyBinCount);
        } catch (e) {
            console.warn('Neon audio connect failed', e);
            this.disconnectAudio();
        }
    }

    disconnectAudio() {
        if (this.audioCtx) {
            try { this.audioCtx.close(); } catch (_) {}
        }
        this.audioCtx = null;
        this.analyser = null;
        this.audioData = null;
        this.connectedVideo = null;
        this.smoothAudio = 0;
        this.smoothMids = 0;
        this.smoothHighs = 0;
        this.beatEnergy = 0;
    }

    getAudioLevel() {
        if (!this.analyser || !this.audioData) {
            return { bass: 0, mids: 0, highs: 0, raw: 0, bins: null };
        }
        this.analyser.getByteFrequencyData(this.audioData);
        const cfg = this.getConfig();
        const sens = cfg.neonSensitivity || 1.2;
        const len = this.audioData.length;
        const bassEnd = Math.floor(len * 0.1);
        const midEnd = Math.floor(len * 0.4);
        let bass = 0, mids = 0, highs = 0;
        for (let i = 0; i < bassEnd; i++) bass += this.audioData[i];
        for (let i = bassEnd; i < midEnd; i++) mids += this.audioData[i];
        for (let i = midEnd; i < len; i++) highs += this.audioData[i];
        bass = Math.min(1, (bass / Math.max(1, bassEnd) / 255) * sens);
        mids = Math.min(1, (mids / Math.max(1, midEnd - bassEnd) / 255) * sens);
        highs = Math.min(1, (highs / Math.max(1, len - midEnd) / 255) * sens);
        return { bass, mids, highs, raw: bass, bins: this.audioData };
    }

    updateBeat(bass, time) {
        this.beatEnergy = this.beatEnergy * 0.92 + bass * 0.08;
        const threshold = 0.26 + (this.getConfig().neonStrobe || 0.8) * 0.12;
        if (bass > threshold && bass > this.beatEnergy * 1.12 && time - this.lastBeatTime > 0.11) {
            this.lastBeatTime = time;
            this.beatFlash = 1;
            this.lightningTimer = 0.18;
            this.lightningSeg = Math.floor(Math.random() * Math.max(1, this.segments.length));
        }
        this.beatFlash *= 0.88;
        this.lightningTimer = Math.max(0, this.lightningTimer - 0.016);
    }

    start() {
        this.stop();
        this.rebuild();
        const loop = (time) => {
            this.tick(time * 0.001);
            this.rafId = requestAnimationFrame(loop);
        };
        this.rafId = requestAnimationFrame(loop);
    }

    stop() {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = null;
    }

    destroy() {
        this.stop();
        this.disconnectAudio();
        if (this.frame) this.frame.innerHTML = '';
        this.segments = [];
    }

    setSegmentBrightness(seg, level, color, extraGlow = 0) {
        const cfg = this.getConfig();
        const intensity = Math.max(0.15, Math.min(2.5, cfg.neonIntensity ?? 1));
        const layers = Math.max(1, Math.min(4, cfg.neonGlowLayers ?? 2));
        const hot = Math.min(1, (level + extraGlow * 0.5) * Math.min(1.4, intensity));
        const glow = (5 + hot * 28 + extraGlow * 22) * intensity;
        const rgb = this.hexToRgb(color);
        seg.style.opacity = String(0.04 + hot * 0.96);
        const shape = cfg.neonShape || 'rounded';
        if (shape === 'sharp') {
            seg.style.background = color;
        } else if (shape === 'capsule') {
            seg.style.background = `radial-gradient(ellipse at center, rgba(255,255,255,${hot * 0.55}) 0%, ${color} 45%, rgba(${rgb.r},${rgb.g},${rgb.b},0.2) 100%)`;
        } else {
            seg.style.background = `linear-gradient(135deg, rgba(${rgb.r},${rgb.g},${rgb.b},1), rgba(255,255,255,${hot * 0.35}))`;
        }
        const shadows = [];
        for (let L = 1; L <= layers; L++) {
            const mul = L / layers;
            shadows.push(`0 0 ${glow * mul}px rgba(${rgb.r},${rgb.g},${rgb.b},${0.75 / L})`);
        }
        shadows.push(`inset 0 0 ${glow * 0.35}px rgba(255,255,255,${hot * 0.28})`);
        seg.style.boxShadow = shadows.join(', ');
    }

    setCornerPulse(level, color) {
        if (!this.frame) return;
        const intensity = Math.max(0.15, Math.min(2.5, this.getConfig().neonIntensity ?? 1));
        const glow = (8 + level * 32) * intensity;
        this.frame.querySelectorAll('.neon-corner, .neon-bracket, .neon-arc').forEach((node) => {
            node.style.opacity = String(0.08 + level * 0.92);
            node.style.boxShadow = `0 0 ${glow}px ${color}, 0 0 ${glow * 1.8}px ${color}`;
            node.style.setProperty('--neon-color', color);
        });
    }

    tick(time) {
        const cfg = this.getConfig();
        if (!cfg.neonBorder || !this.segments.length) return;

        const color1 = this.getColor(cfg);
        const color2 = this.getColor2(cfg);
        const count = this.segments.length;
        const speed = (cfg.neonSpeed || 1) * 2;
        const audioData = cfg.neonAudio !== false
            ? this.getAudioLevel()
            : { bass: 0, mids: 0, highs: 0, raw: 0, bins: null };
        const audio = audioData.bass;
        this.smoothAudio += (audio - this.smoothAudio) * 0.18;
        this.smoothMids += (audioData.mids - this.smoothMids) * 0.15;
        this.smoothHighs += (audioData.highs - this.smoothHighs) * 0.12;
        this.updateBeat(audio, time);
        const strobeAmt = cfg.neonStrobe || 0.8;
        const pattern = cfg.neonPattern || 'chase';
        const beatBoost = this.beatFlash * strobeAmt;
        this.phase = time * speed;

        const mixT = 0.5 + Math.sin(time * 0.6) * 0.5;
        const liveColor = this.lerpColor(color1, color2, mixT * (cfg.neonDualMix ?? 0.45));

        this.segments.forEach((s) => s.style.setProperty('--neon-color', liveColor));
        this.frame?.querySelectorAll('.neon-corner, .neon-bracket, .neon-arc').forEach((n) => {
            n.style.setProperty('--neon-color', liveColor);
        });

        const paint = (seg, level, t = 0, boost = 0) => {
            const c = this.lerpColor(color1, color2, t);
            this.setSegmentBrightness(seg, level, c, boost);
        };

        switch (pattern) {
            case 'strobe': {
                const beat = audio > (0.22 - strobeAmt * 0.12) || this.beatFlash > 0.4;
                const flash = beat ? 0.55 + audio * 0.45 + beatBoost * 0.3 : 0.04;
                this.segments.forEach((seg) => paint(seg, flash, mixT, beatBoost));
                this.setCornerPulse(flash, liveColor);
                break;
            }
            case 'pulse': {
                const pulse = 0.28 + this.smoothAudio * 0.55 + Math.sin(time * speed * 2.2) * 0.14 + beatBoost * 0.2;
                this.segments.forEach((seg) => paint(seg, Math.min(1, pulse), mixT));
                this.setCornerPulse(pulse * 0.85, liveColor);
                break;
            }
            case 'wave': {
                this.segments.forEach((seg, i) => {
                    const wave = (Math.sin(time * speed * 2.2 + (i / count) * Math.PI * 2) + 1) / 2;
                    paint(seg, wave * (0.32 + this.smoothAudio * 0.68), i / count, beatBoost * wave);
                });
                this.setCornerPulse(this.smoothAudio, liveColor);
                break;
            }
            case 'breath': {
                const b = 0.2 + (Math.sin(time * speed * 1.1) * 0.5 + 0.5) * (0.35 + this.smoothAudio * 0.55);
                this.segments.forEach((seg, i) => {
                    const edge = Math.sin((i / count) * Math.PI * 2 + time) * 0.08;
                    paint(seg, Math.min(1, b + edge), (Math.sin(time + i * 0.1) + 1) / 2);
                });
                this.setCornerPulse(b, liveColor);
                break;
            }
            case 'stack': {
                this.stackProgress += 0.014 * speed * (1 + this.smoothAudio * 0.5);
                if (this.stackProgress > count + 2) this.stackProgress = 0;
                const lit = Math.floor(this.stackProgress);
                this.segments.forEach((seg, i) => {
                    let level = i < lit ? 0.75 : 0.05;
                    if (i === lit) level = 0.35 + audio * 0.65;
                    paint(seg, level, i / count, i === lit ? beatBoost : 0);
                });
                break;
            }
            case 'flicker': {
                this.segments.forEach((seg, i) => {
                    const seed = Math.sin(time * 14 + i * 7.3) * 0.5 + 0.5;
                    const flick = seed < (0.12 - audio * 0.08) ? 0.9 + audio * 0.1 : 0.05 + audio * 0.12;
                    paint(seg, Math.min(1, flick), seed);
                });
                break;
            }
            case 'spectrum': {
                const bins = audioData.bins;
                this.segments.forEach((seg, i) => {
                    let level = 0.06;
                    if (bins) {
                        const bin = Math.floor((i / count) * bins.length * 0.55);
                        level = 0.08 + (bins[bin] / 255) * 0.88 * (cfg.neonSensitivity || 1.2);
                    }
                    level = Math.min(1, level + beatBoost * 0.25);
                    paint(seg, level, i / count);
                });
                this.setCornerPulse(this.smoothAudio + beatBoost * 0.3, liveColor);
                break;
            }
            case 'dual': {
                const head1 = Math.floor((time * speed * 3.5) % count);
                const head2 = (head1 + Math.floor(count / 2)) % count;
                const tail = 5;
                this.segments.forEach((seg, i) => {
                    let d1 = Math.abs(i - head1);
                    let d2 = Math.abs(i - head2);
                    if (d1 > count / 2) d1 = count - d1;
                    if (d2 > count / 2) d2 = count - d2;
                    const l1 = d1 === 0 ? 1 : d1 <= tail ? 0.78 - d1 * 0.14 : 0;
                    const l2 = d2 === 0 ? 1 : d2 <= tail ? 0.78 - d2 * 0.14 : 0;
                    const level = Math.max(l1, l2, 0.04) + this.smoothAudio * strobeAmt * 0.3;
                    paint(seg, Math.min(1, level), l1 >= l2 ? 0 : 1, (l1 > 0.8 || l2 > 0.8) ? beatBoost : 0);
                });
                break;
            }
            case 'comet': {
                const head = Math.floor((time * speed * 5) % count);
                const tail = 8;
                this.segments.forEach((seg, i) => {
                    let dist = (head - i + count) % count;
                    let level = dist === 0 ? 1 : dist <= tail ? Math.pow(1 - dist / tail, 1.4) * 0.95 : 0.03;
                    level = Math.min(1, level + this.smoothHighs * 0.2);
                    paint(seg, level, dist / tail, dist === 0 ? beatBoost : 0);
                });
                break;
            }
            case 'braid': {
                this.segments.forEach((seg, i) => {
                    const a = Math.sin(time * speed * 2.8 + i * 0.45);
                    const b = Math.cos(time * speed * 2.1 - i * 0.38);
                    const level = 0.08 + Math.max(0, a) * 0.55 + Math.max(0, b) * 0.4 + this.smoothMids * 0.25;
                    paint(seg, Math.min(1, level), (a + 1) / 2, beatBoost * Math.max(0, a));
                });
                break;
            }
            case 'radar': {
                const head = Math.floor((time * speed * 2.2) % count);
                this.segments.forEach((seg, i) => {
                    let dist = Math.abs(i - head);
                    if (dist > count / 2) dist = count - dist;
                    const beam = dist === 0 ? 1 : dist < 2 ? 0.55 : 0.04;
                    const fade = 0.06 + this.smoothAudio * 0.15 * (1 - dist / (count / 2));
                    paint(seg, Math.max(beam, fade), dist / (count / 4), dist === 0 ? beatBoost : 0);
                });
                this.setCornerPulse(0.3 + this.smoothAudio * 0.5, liveColor);
                break;
            }
            case 'lightning': {
                this.segments.forEach((seg, i) => {
                    let level = 0.05 + this.smoothAudio * 0.12;
                    if (this.lightningTimer > 0) {
                        const d = Math.abs(i - this.lightningSeg);
                        if (d < 3) level = 1 - d * 0.25;
                        else if (Math.random() < 0.02) level = 0.7;
                    }
                    paint(seg, level, Math.random() * 0.3, this.lightningTimer > 0 ? beatBoost : 0);
                });
                break;
            }
            case 'solid': {
                const base = 0.35 + this.smoothAudio * 0.5 + beatBoost * 0.25;
                this.segments.forEach((seg, i) => paint(seg, base, (Math.sin(time + i * 0.05) + 1) / 2));
                this.setCornerPulse(base, liveColor);
                break;
            }
            case 'matrix': {
                this.segments.forEach((seg, i) => {
                    const col = i % 8;
                    const row = Math.floor(i / 8);
                    const drop = (time * speed * 3 + col * 1.7) % 1.4;
                    const v = (i / count);
                    const hit = Math.abs(v - drop) < 0.06 ? 1 : 0.06 + this.smoothHighs * 0.2;
                    paint(seg, hit, col / 8, hit > 0.5 ? beatBoost : 0);
                });
                break;
            }
            case 'orbit': {
                const head = Math.floor((time * speed * 3.2) % count);
                this.segments.forEach((seg, i) => {
                    let dist = Math.abs(i - head);
                    if (dist > count / 2) dist = count - dist;
                    const level = dist === 0 ? 1 : dist <= 3 ? 0.7 - dist * 0.18 : 0.08 + Math.sin(time * 2 + i) * 0.04;
                    const ring = 0.15 + this.smoothMids * 0.35 * Math.cos((i / count) * Math.PI * 2 + time);
                    paint(seg, Math.min(1, Math.max(level, ring)), i / count, dist === 0 ? beatBoost : 0);
                });
                break;
            }
            case 'chase':
            default: {
                const head = Math.floor((time * speed * 4) % count);
                const tail = 5;
                this.segments.forEach((seg, i) => {
                    let dist = Math.abs(i - head);
                    if (dist > count / 2) dist = count - dist;
                    let level = dist === 0 ? 1 : dist <= tail ? 0.75 - dist * 0.14 : 0.04;
                    level = Math.min(1, level + this.smoothAudio * strobeAmt * 0.42 + (dist === 0 ? beatBoost * 0.3 : 0));
                    paint(seg, level, dist / tail, dist === 0 ? beatBoost : 0);
                });
                break;
            }
        }
    }
}
