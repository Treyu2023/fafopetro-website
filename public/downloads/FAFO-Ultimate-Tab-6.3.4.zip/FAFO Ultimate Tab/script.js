document.addEventListener('DOMContentLoaded', async () => {
    // --- DOM ELEMENTS ---
    const scene = document.getElementById('scene-root');
    const overlay = document.getElementById('overlay');
    const bokehCanvas = document.getElementById('bokeh-canvas');
    const ui = {
        clock: document.getElementById('clock'),
        date: document.getElementById('date'),
        box: document.getElementById('ui-container')
    };
    const hud = {
        box: document.getElementById('player-hud'),
        title: document.getElementById('hud-title'),
        index: document.getElementById('hud-index'),
        play: document.getElementById('hud-play'),
        prev: document.getElementById('hud-prev'),
        next: document.getElementById('hud-next'),
        shuffle: document.getElementById('hud-shuffle'),
        speedDown: document.getElementById('hud-speed-down'),
        speed: document.getElementById('hud-speed'),
        speedUp: document.getElementById('hud-speed-up'),
        mute: document.getElementById('hud-mute'),
        volume: document.getElementById('hud-volume'),
        pip: document.getElementById('hud-pip'),
        fs: document.getElementById('hud-fs'),
        progressWrap: document.getElementById('hud-progress-wrap'),
        progressTrack: document.getElementById('hud-progress-track'),
        progress: document.getElementById('hud-progress'),
        progressThumb: document.getElementById('hud-progress-thumb'),
        timeCurrent: document.getElementById('hud-time-current'),
        timeTotal: document.getElementById('hud-time-total')
    };
    const emptyState = document.getElementById('empty-state');
    const neonFrame = document.getElementById('neon-frame');
    const shortcutHelp = document.getElementById('shortcut-help');

    // --- 1. CONFIGURATION DEFAULTS ---
    let cfg = {
        // Library Settings
        useLocal: true, 
        usePhotos: true, 
        urls: [],
        activePlaylistId: 'all', 
        
        // Layout Settings
        layout: 'cinema', 
        scaling: 'scale-capped',
        gridCols: 4, 
        gridRows: 1, 
        carouselCount: 8, 
        carouselRadius: 650, 
        carouselTilt: 0,
        carouselSpeed: 40,
        reflectOpacity: 30, 
        reflectOffset: 0,
        
        // Playback Settings
        loops: 1, 
        shuffle: true, 
        volume: 0.7,
        playbackSpeed: 1,
        photoDuration: 3, 
        kenburns: true,
        
        // Visual Settings
        accentColor: '#00e5ff', 
        brightness: 100, 
        contrast: 100, 
        saturate: 100, 
        sepia: 0, 
        grayscale: 0,
        
        // Ambilight & Borders
        borderSize: 0, 
        borderColor: '#44858d', 
        borderGlow: 15,
        ambiScale: 1.0, 
        ambiOpacity: 0.25, 
        ambiBlur: 5,
        ambiMode: 'blur',

        // Audio-reactive neon border
        neonBorder: false,
        neonPattern: 'chase',
        neonSegments: 24,
        neonSpeed: 1,
        neonAudio: true,
        neonStrobe: 0.8,
        neonSensitivity: 1.2,
        neonWidth: 4,
        neonUseAccent: true,
        neonColor: '#00e5ff',
        
        // Detailed Particle Configs (Updated with all controls)
        fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
        fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
        fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
        fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
        fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
        fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,
        
        // UI Settings
        showDate: true, 
        format12h: true, 
        showSeconds: false,
        clockSize: 25, 
        font: "'Arial Black', sans-serif", 
        pos: 'pos-bottom-left',
        
        // Per-File Overrides
        overrides: {},

        // Performance
        performanceMode: false,
        maxDisplayHeight: 1080,
        disableAmbience: false,
        disableParticles: false,
        disableCssFilters: false,
        disableNeonAudio: false,
    };

    // --- STATE VARIABLES ---
    let playlist = [];
    let currentIdx = 0;
    let loopCount = 0;
    let db = null;
    let mainVideo = null;
    let ambienceVideo = null;
    let photoTimeout = null;
    let collageInterval = null; 
    let isPaused = false;
    let permissionWarned = false;
    let healthCheckInterval = null;
    let consecutiveErrors = 0;
    let currentBlobUrl = null;
    let clockInterval = null;
    let neonEngine = null;
    let particleEngine = null;
    let progressInterval = null;
    let libraryEmpty = false;
    let isSeeking = false;
    let hudIdleTimer = null;
    let gridResizeTimer = null;
    let volumeSaveTimer = null;
    /** Stack of prior playlist indices so Prev returns to the last played clip. */
    let playHistory = [];
    const PLAY_HISTORY_MAX = 200;
    const HUD_IDLE_MS = 5000;
    const SPEED_STEPS = [0.25, 0.33, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
    /** Keys that require rebuilding the playlist when mediaConfig changes. */
    const PLAYLIST_AFFECTING_KEYS = [
        'activePlaylistId', 'shuffle', 'useLocal', 'usePhotos', 'urls',
    ];
    /** Keys that only need live apply — never rebuild / re-layout. */
    const SOFT_CONFIG_KEYS = [
        'volume', 'playbackSpeed', 'brightness', 'contrast', 'saturate',
        'sepia', 'grayscale', 'showDate', 'format12h', 'showSeconds',
        'clockSize', 'font', 'pos',
    ];

    // --- 2. INITIALIZATION SEQUENCE ---
    await loadConfig();
    applyGlobalStyles();
    applyHUD();
    await initDB();
    await buildPlaylist();
    initNeonEngine();
    refreshParticles();
    initLayout();
    startClock();
    initInputListeners();
    initHudControls();
    initHudAutoHide();
    initGridResizeListener();
    startHealthCheck();
    listenForConfigChanges();

    // --- 3. CORE FUNCTIONS ---

    async function loadConfig() {
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        cfg = {...cfg, ...mediaConfig};
    }

    function listenForConfigChanges() {
        chrome.storage.onChanged.addListener(async (changes, area) => {
            if (area !== 'local' || !changes.mediaConfig) return;
            const oldVal = changes.mediaConfig.oldValue || {};
            const newVal = changes.mediaConfig.newValue || {};
            if (!newVal || typeof newVal !== 'object') return;

            // Diff only keys that actually changed (volume slider writes many times)
            const changedKeys = Object.keys(newVal).filter((k) => {
                try {
                    return JSON.stringify(oldVal[k]) !== JSON.stringify(newVal[k]);
                } catch {
                    return oldVal[k] !== newVal[k];
                }
            });
            if (!changedKeys.length) return;

            const prevLayout = cfg.layout;
            const prevPlaylistId = cfg.activePlaylistId;
            cfg = { ...cfg, ...newVal };

            // Soft-only updates (volume/speed/etc.) — never rebuild playlist or restart video
            const needsPlaylist = changedKeys.some((k) => PLAYLIST_AFFECTING_KEYS.includes(k));
            const needsLayout = changedKeys.includes('layout')
                || (newVal.activePlaylistId !== undefined && newVal.activePlaylistId !== prevPlaylistId);
            const softOnly = !needsPlaylist && !needsLayout
                && changedKeys.every((k) => SOFT_CONFIG_KEYS.includes(k));

            if (softOnly) {
                if (changedKeys.includes('volume') && mainVideo) {
                    const vol = Math.max(0, Math.min(1, cfg.volume ?? 0.7));
                    mainVideo.volume = vol;
                    if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
                    if (hud.volume) hud.volume.value = Math.round(vol * 100);
                    updateHudMuteIcon();
                }
                if (changedKeys.includes('playbackSpeed') && mainVideo) {
                    mainVideo.playbackRate = cfg.playbackSpeed || 1;
                    if (ambienceVideo) ambienceVideo.playbackRate = cfg.playbackSpeed || 1;
                    if (hud.speed) hud.speed.textContent = formatSpeedLabel(cfg.playbackSpeed || 1);
                }
                if (changedKeys.some((k) => ['showDate', 'format12h', 'showSeconds', 'clockSize', 'font', 'pos'].includes(k))) {
                    applyHUD();
                }
                if (changedKeys.some((k) => ['brightness', 'contrast', 'saturate', 'sepia', 'grayscale'].includes(k))) {
                    applyGlobalStyles();
                }
                return;
            }

            applyGlobalStyles();
            applyHUD();
            initNeonEngine();
            refreshParticles();

            if (needsPlaylist) {
                // Keep current clip if it still exists after rebuild
                const prevItem = playlist[currentIdx];
                const prevKey = prevItem
                    ? (prevItem.name || prevItem.handle?.name || prevItem.url || '')
                    : '';
                await buildPlaylist();
                if (prevKey && playlist.length) {
                    const found = playlist.findIndex((it) =>
                        (it.name || it.handle?.name || it.url || '') === prevKey
                    );
                    if (found >= 0) currentIdx = found;
                    else currentIdx = Math.min(currentIdx, playlist.length - 1);
                }
                // Playlist order changed — history indices are stale
                playHistory = [];
            }

            if (needsLayout || cfg.layout !== prevLayout) {
                initLayout();
            } else {
                updateHUD();
            }
        });
    }

    function initNeonEngine() {
        if (!neonEngine) neonEngine = new NeonBorderEngine(neonFrame, () => cfg);
        neonEngine.rebuild();
        neonEngine.start();
    }

    function refreshParticles() {
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        document.body.classList.toggle('fx-active', anyFx);
        if (!particleEngine) particleEngine = new ParticleFXEngine(bokehCanvas, () => cfg);
        if (anyFx) {
            particleEngine.rebuild();
            if (!particleEngine.rafId) particleEngine.start();
            syncParticlePerformance();
        } else {
            particleEngine.destroy();
        }
    }

    function syncParticlePerformance() {
        if (!particleEngine) return;
        const videoBusy = cfg.layout === 'cinema' && mainVideo && !mainVideo.paused && !isPaused;
        const forceOff = cfg.disableParticles || cfg.performanceMode;
        if (forceOff && videoBusy) {
            particleEngine.setPerformanceMode(true);
            // Fully pause particle loop while media plays in perf mode
            if (particleEngine.rafId) particleEngine.destroy();
            document.body.classList.remove('fx-active');
            return;
        }
        particleEngine.setPerformanceMode(videoBusy || !!cfg.performanceMode);
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        if (anyFx && !particleEngine.rafId && !(forceOff && videoBusy)) {
            document.body.classList.add('fx-active');
            particleEngine.rebuild();
            particleEngine.start();
        }
    }

    function computeOptimalGrid(cellCount) {
        if (cellCount <= 1) return { cols: 1, rows: 1 };
        const aspect = innerWidth / innerHeight;
        let best = { cols: 1, rows: cellCount, score: -Infinity };
        for (let cols = 1; cols <= cellCount; cols++) {
            const rows = Math.ceil(cellCount / cols);
            const waste = cols * rows - cellCount;
            const cellAspect = (cols / rows) * aspect;
            const target = 16 / 9;
            const score = -Math.abs(Math.log(cellAspect / target)) - waste * 0.45;
            if (score > best.score) best = { cols, rows, score };
        }
        return { cols: best.cols, rows: best.rows };
    }

    function applyGridDimensions() {
        const cellCount = Math.max(1, (cfg.gridCols || 4) * (cfg.gridRows || 1));
        const grid = computeOptimalGrid(cellCount);
        document.documentElement.style.setProperty('--grid-cols', grid.cols);
        document.documentElement.style.setProperty('--grid-rows', grid.rows);
        return { ...grid, cellCount };
    }

    function initGridResizeListener() {
        window.addEventListener('resize', () => {
            if (cfg.layout !== 'grid') return;
            clearTimeout(gridResizeTimer);
            gridResizeTimer = setTimeout(applyGridDimensions, 120);
        });
    }

    function revokeCurrentBlob() {
        if (currentBlobUrl) {
            URL.revokeObjectURL(currentBlobUrl);
            currentBlobUrl = null;
        }
    }

    // NEW: Helper for Theme Engine
    function hexToRgb(hex) {
        const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    function isPerfMode() {
        return !!(cfg.performanceMode || cfg.disableCssFilters);
    }

    function applyGlobalStyles() {
        const root = document.documentElement;
        const body = document.body;
        
        // Apply Accent Color Logic
        const rgb = hexToRgb(cfg.accentColor || '#00e5ff');
        if (rgb) {
            root.style.setProperty('--accent', cfg.accentColor);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }

        // Color grading on #scene-root is expensive (re-filters the whole video layer).
        // In perf mode or when disabled, force identity filters so GPU can composite cleanly.
        const noFilters = cfg.disableCssFilters || cfg.performanceMode;
        if (noFilters) {
            root.style.setProperty('--brightness', '100%');
            root.style.setProperty('--contrast', '100%');
            root.style.setProperty('--saturate', '100%');
            root.style.setProperty('--sepia', '0%');
            root.style.setProperty('--grayscale', '0%');
            scene?.classList.add('no-scene-filter');
        } else {
            root.style.setProperty('--brightness', `${cfg.brightness}%`);
            root.style.setProperty('--contrast', `${cfg.contrast}%`);
            root.style.setProperty('--saturate', `${cfg.saturate}%`);
            root.style.setProperty('--sepia', `${cfg.sepia}%`);
            root.style.setProperty('--grayscale', `${cfg.grayscale}%`);
            scene?.classList.remove('no-scene-filter');
        }

        // Cap display size for perf (CSS inset:0 + margin:auto centers the smaller box)
        const maxH = parseInt(cfg.maxDisplayHeight, 10) || 0;
        if (maxH > 0) {
            root.style.setProperty('--video-max-h', `min(100%, ${maxH}px)`);
            root.style.setProperty('--video-max-w', `min(100%, ${Math.round(maxH * 16 / 9)}px)`);
        } else {
            root.style.setProperty('--video-max-h', '100%');
            root.style.setProperty('--video-max-w', '100%');
        }
        body.classList.toggle('perf-mode', !!cfg.performanceMode);
        
        // Borders & Layout
        root.style.setProperty('--border-size', `${cfg.borderSize}px`);
        root.style.setProperty('--border-color', cfg.borderColor);
        root.style.setProperty('--border-glow', `${cfg.borderGlow}px`);
        if (cfg.layout === 'grid') applyGridDimensions();
        else {
            root.style.setProperty('--grid-cols', cfg.gridCols);
            root.style.setProperty('--grid-rows', cfg.gridRows);
        }
        
        // Reflections (Convert 0-100 to 0.0-1.0)
        root.style.setProperty('--reflect-op', `${cfg.reflectOpacity / 100}`);
        root.style.setProperty('--reflect-off', `${cfg.reflectOffset}px`);
    }

    function applyVideoGpuHints(videoEl) {
        if (!videoEl) return;
        // Do NOT set inline transform here — CSS owns layout/centering.
        // Overwriting transform previously broke cinema scale (only top-left visible).
        try { videoEl.disablePictureInPicture = false; } catch (_) {}
        videoEl.setAttribute('playsinline', '');
        videoEl.style.backfaceVisibility = 'hidden';
        // Optional display cap via CSS variables (keeps object-fit + full-frame layout)
        // Inline max size only when not using cover (cover needs full viewport box)
    }

    function applyCinemaObjectFit(videoEl, objectFit) {
        if (!videoEl) return;
        // scale-capped = never upscale past native resolution (or maxDisplayHeight).
        // Previously this was identical to contain and still filled the whole screen.
        const capped = (cfg.scaling === 'scale-capped') || objectFit === 'capped';
        if (capped) {
            const placeCapped = () => {
                const vw = videoEl.videoWidth || videoEl.naturalWidth || 0;
                const vh = videoEl.videoHeight || videoEl.naturalHeight || 0;
                const maxCfg = parseInt(cfg.maxDisplayHeight, 10) || 0;
                const maxH = Math.min(
                    window.innerHeight || 1080,
                    maxCfg > 0 ? maxCfg : (vh || window.innerHeight),
                    vh || window.innerHeight
                );
                const maxW = Math.min(
                    window.innerWidth || 1920,
                    vw || window.innerWidth,
                    maxCfg > 0 ? Math.round(maxCfg * 16 / 9) : (vw || window.innerWidth)
                );
                // Fit inside max box without upscaling past native
                let drawW = vw || maxW;
                let drawH = vh || maxH;
                if (drawW > maxW || drawH > maxH) {
                    const s = Math.min(maxW / Math.max(drawW, 1), maxH / Math.max(drawH, 1));
                    drawW = Math.round(drawW * s);
                    drawH = Math.round(drawH * s);
                }
                videoEl.style.objectFit = 'contain';
                videoEl.style.width = drawW + 'px';
                videoEl.style.height = drawH + 'px';
                videoEl.style.maxWidth = '100%';
                videoEl.style.maxHeight = '100%';
                videoEl.style.left = '50%';
                videoEl.style.top = '50%';
                videoEl.style.right = 'auto';
                videoEl.style.bottom = 'auto';
                videoEl.style.inset = 'auto';
                videoEl.style.margin = '0';
                videoEl.style.transform = 'translate(-50%, -50%) translateZ(0)';
            };
            placeCapped();
            if (!videoEl._fafoCappedBound) {
                videoEl._fafoCappedBound = true;
                videoEl.addEventListener('loadedmetadata', placeCapped);
                window.addEventListener('resize', placeCapped);
            }
            videoEl._fafoPlaceCapped = placeCapped;
            return;
        }
        videoEl.style.objectFit = objectFit || 'contain';
        // "Raw / center" mode: show intrinsic size centered, not cropped top-left
        if (objectFit === 'none') {
            videoEl.style.width = 'auto';
            videoEl.style.height = 'auto';
            videoEl.style.maxWidth = '100%';
            videoEl.style.maxHeight = '100%';
            videoEl.style.left = '50%';
            videoEl.style.top = '50%';
            videoEl.style.right = 'auto';
            videoEl.style.bottom = 'auto';
            videoEl.style.transform = 'translate(-50%, -50%) translateZ(0)';
        } else {
            videoEl.style.width = '100%';
            videoEl.style.height = '100%';
            videoEl.style.left = '';
            videoEl.style.top = '';
            videoEl.style.right = '';
            videoEl.style.bottom = '';
            videoEl.style.inset = '';
            videoEl.style.margin = '';
            videoEl.style.transform = 'translateZ(0)';
            videoEl.style.maxWidth = '';
            videoEl.style.maxHeight = '';
        }
    }

    function applyHUD() {
        ui.clock.style.fontSize = `${cfg.clockSize}px`;
        ui.box.style.fontFamily = cfg.font;
        ui.box.className = cfg.pos;
        ui.date.style.display = cfg.showDate ? 'block' : 'none';
    }

    function initInputListeners() {
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            if (e.code === 'Space') { e.preventDefault(); togglePause(); }
            if (e.code === 'ArrowRight') skipTrack(1);
            if (e.code === 'ArrowLeft') skipTrack(-1);
            if (e.code === 'KeyM') toggleMute();
            if (e.code === 'KeyS') toggleShuffle();
            if (e.code === 'KeyP') togglePiP();
            if (e.code === 'KeyF') toggleFullscreen();
            if (e.code === 'KeyL') { e.preventDefault(); openPlaylistPicker(); }
            if (e.code === 'Comma') changeSpeed(-1);
            if (e.code === 'Period') changeSpeed(1);
            if (e.key === '?') shortcutHelp?.classList.toggle('hidden');
            revealHud();
        });
        document.addEventListener('click', (e) => {
            if (e.target.closest('a') || e.target.closest('button') || e.target.closest('.modal') || e.target.closest('.player-hud') || e.target.closest('#meta-dock') || e.target.closest('#playlist-pick')) return;
            togglePause();
        });
        document.addEventListener('mousemove', revealHud, { passive: true });
        
        // Creative 3D Tilt for Carousel
        document.addEventListener('mousemove', (e) => {
            if (cfg.layout === 'carousel') {
                const x = (e.clientX / window.innerWidth - 0.5) * 2; // -1 to 1
                const y = (e.clientY / window.innerHeight - 0.5) * 2;
                
                const pivot = document.querySelector('.carousel-pivot');
                if(pivot) {
                    pivot.style.transformOrigin = 'center center';
                    scene.style.transform = `rotateX(${cfg.carouselTilt + (y * 10)}deg) rotateY(${x * 10}deg)`;
                }
            }
        });
    }

    function pushPlayHistory(idx) {
        if (idx == null || idx < 0 || !playlist.length) return;
        // Avoid duplicate consecutive entries
        if (playHistory.length && playHistory[playHistory.length - 1] === idx) return;
        playHistory.push(idx);
        if (playHistory.length > PLAY_HISTORY_MAX) playHistory.shift();
    }

    /**
     * Advance (or go back) in the playlist.
     * dir < 0 uses play history so Prev returns the last played clip (not just index-1).
     * When skip-tagged mode is on, forward skips already-tagged / heavily-tagged clips.
     */
    function skipTrack(dir) {
        if (!playlist.length) return;
        clearTimeout(photoTimeout);
        loopCount = 0;
        isPaused = false;
        ui.clock.style.opacity = 1;
        if (hud.play) hud.play.textContent = '⏸';
        try { window.FAFOMeta?.clearUntaggedPrompt?.(); } catch (_) {}

        if (dir < 0) {
            // Prefer real history of what was played
            while (playHistory.length) {
                const prev = playHistory.pop();
                if (prev !== currentIdx && prev >= 0 && prev < playlist.length) {
                    currentIdx = prev;
                    playNext({ fromHistory: true });
                    return;
                }
            }
            // Fallback: previous index in current order
            currentIdx = (currentIdx - 1 + playlist.length) % playlist.length;
            playNext({ fromHistory: true });
            return;
        }

        // Forward: remember where we were, then find next eligible index
        pushPlayHistory(currentIdx);
        const next = findNextEligibleIndex(currentIdx, 1);
        currentIdx = next;
        playNext();
    }

    /**
     * Find next playlist index respecting FAFOMeta skip-tagged mode when active.
     * Falls back to simple wrap if every item is filtered.
     */
    function findNextEligibleIndex(fromIdx, dir) {
        const n = playlist.length;
        if (!n) return 0;
        const step = dir < 0 ? -1 : 1;
        const skipMode = !!window.FAFOMeta?.isSkipTaggedMode?.();
        if (!skipMode) {
            return (fromIdx + step + n) % n;
        }
        // Prefer untagged; if none left in a full scan, prefer < 5 tags
        let foundLight = -1;
        for (let i = 1; i <= n; i++) {
            const idx = (fromIdx + step * i + n * 10) % n;
            const item = playlist[idx];
            const count = window.FAFOMeta?.tagCountForItem?.(item) ?? 0;
            if (count === 0) return idx;
            if (foundLight < 0 && count < 5) foundLight = idx;
        }
        // All tagged: skip ones with 5+ tags when possible
        if (foundLight >= 0) return foundLight;
        return (fromIdx + step + n) % n;
    }

    // Bridge for fafo-meta.js (tags / ratings / meta prev-next)
    window.FAFOPlayer = {
        skipTrack,
        getCurrentItem: () => playlist[currentIdx] || null,
        getCurrentIndex: () => currentIdx,
        getPlaylistLength: () => playlist.length,
        getPlaylist: () => playlist.slice(),
        togglePause: () => { if (typeof togglePause === 'function') togglePause(); },
        openPlaylistPicker: () => openPlaylistPicker(),
        findNextEligibleIndex,
    };

    // --- PLAYLIST QUICK-ADD (during playback) ---
    async function listDbPlaylists() {
        if (!db) return [];
        try {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            return await new Promise(res => {
                const req = store.getAll();
                req.onsuccess = () => res(req.result || []);
                req.onerror = () => res([]);
            });
        } catch { return []; }
    }

    async function openPlaylistPicker() {
        const panel = document.getElementById('playlist-pick');
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        if (!panel || !select) return;
        const item = playlist[currentIdx];
        if (!item || !item.handle) {
            // Bundled URL items can't join handle playlists easily
            console.warn('Current item has no file handle for playlist storage');
        }
        const lists = (await listDbPlaylists()).filter(p => p.type !== 'smart');
        select.innerHTML = '<option value="">— select playlist —</option>' +
            lists.map(p => `<option value="${p.id}">${p.name} (${(p.items || []).length})</option>`).join('');
        if (newName) newName.value = '';
        panel.classList.remove('hidden');
        revealHud();
    }

    function closePlaylistPicker() {
        document.getElementById('playlist-pick')?.classList.add('hidden');
    }

    async function addCurrentToPlaylist() {
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        const item = playlist[currentIdx];
        if (!item?.handle) {
            alert('This clip has no local file handle (bundled/URL). Link a folder in Options to use playlists.');
            return;
        }
        if (!db) await initDB();

        let playlistId = select?.value || '';
        let pl = null;

        if (newName?.value?.trim()) {
            const name = newName.value.trim();
            pl = {
                id: 'pl_' + Date.now().toString(36),
                name,
                items: [],
                created: Date.now(),
            };
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
            playlistId = pl.id;
        } else if (playlistId) {
            const tx = db.transaction('playlists', 'readonly');
            pl = await new Promise(res => {
                const r = tx.objectStore('playlists').get(playlistId);
                r.onsuccess = () => res(r.result);
                r.onerror = () => res(null);
            });
        }
        if (!pl) {
            alert('Pick an existing playlist or type a new name.');
            return;
        }

        const storeName = item.type === 'photo' ? 'photos' : 'videos';
        let handleKey = null;
        try {
            const tx = db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const vals = await new Promise((res, rej) => {
                const r = store.getAll();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const keys = await new Promise((res, rej) => {
                const tx2 = db.transaction(storeName, 'readonly');
                const r = tx2.objectStore(storeName).getAllKeys();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const targetName = item.handle?.name || item.name;
            for (let i = 0; i < vals.length; i++) {
                const entry = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(vals[i]) : null;
                const h = entry?.handle || vals[i];
                const n = entry?.name || vals[i]?.name || h?.name;
                if (h === item.handle || (targetName && n === targetName)) {
                    handleKey = keys[i];
                    break;
                }
            }
        } catch (e) {
            console.warn(e);
        }

        if (handleKey == null) {
            try {
                const tx = db.transaction(storeName, 'readwrite');
                handleKey = await new Promise((res, rej) => {
                    const payload = {
                        handle: item.handle,
                        name: item.handle?.name || item.name,
                        addedAt: Date.now(),
                    };
                    const r = tx.objectStore(storeName).add(payload);
                    r.onsuccess = () => res(r.result);
                    r.onerror = () => rej(r.error);
                });
            } catch (e) {
                alert('Could not resolve file in library: ' + e.message);
                return;
            }
        }

        pl.items = pl.items || [];
        const exists = pl.items.some(i => i.store === storeName && String(i.key) === String(handleKey));
        if (!exists) {
            pl.items.push({ store: storeName, key: handleKey });
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
        }
        closePlaylistPicker();
        if (hud.title) {
            const prev = hud.title.textContent;
            hud.title.textContent = `✓ Added to ${pl.name}`;
            setTimeout(() => { if (hud.title) hud.title.textContent = prev; }, 1600);
        }
    }

    document.getElementById('playlist-pick-cancel')?.addEventListener('click', closePlaylistPicker);
    document.getElementById('playlist-pick-ok')?.addEventListener('click', () => addCurrentToPlaylist());
    document.getElementById('playlist-pick')?.addEventListener('click', (e) => {
        if (e.target.id === 'playlist-pick') closePlaylistPicker();
    });

    function toggleMute() {
        if (!mainVideo) return;
        mainVideo.muted = !mainVideo.muted;
        if (!mainVideo.muted && mainVideo.volume === 0 && hud.volume) {
            mainVideo.volume = hud.volume.value / 100;
        }
        updateHudMuteIcon();
    }

    function toggleShuffle() {
        cfg.shuffle = !cfg.shuffle;
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, shuffle: cfg.shuffle}});
        });
        if (cfg.shuffle && playlist.length > 1) {
            const current = playlist[currentIdx];
            playlist = playlist.filter((_, i) => i !== currentIdx).sort(() => Math.random() - 0.5);
            playlist.unshift(current);
            currentIdx = 0;
            playHistory = []; // indices invalidated by reorder
            updateHUD();
        }
    }

    function formatSpeedLabel(speed) {
        if (speed === 1) return '1×';
        if (speed === 0.33) return '0.33×';
        if (speed === 0.25) return '0.25×';
        return `${speed}×`;
    }

    function changeSpeed(dir) {
        const idx = SPEED_STEPS.indexOf(cfg.playbackSpeed);
        const base = idx < 0 ? SPEED_STEPS.indexOf(1) : idx;
        const next = SPEED_STEPS[Math.max(0, Math.min(SPEED_STEPS.length - 1, base + dir))];
        setPlaybackSpeed(next);
        revealHud();
    }

    function setPlaybackSpeed(speed) {
        cfg.playbackSpeed = speed;
        if (mainVideo) mainVideo.playbackRate = speed;
        if (ambienceVideo) ambienceVideo.playbackRate = speed;
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(speed);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, playbackSpeed: speed}});
        });
    }

    async function togglePiP() {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        try {
            if (document.pictureInPictureElement) {
                await document.exitPictureInPicture();
            } else if (document.pictureInPictureEnabled) {
                await mainVideo.requestPictureInPicture();
            }
        } catch (e) { console.warn('PiP unavailable', e); }
    }

    function formatTime(sec) {
        if (!isFinite(sec) || sec < 0) return '0:00';
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    }

    function updateProgressUI() {
        if (!mainVideo || !mainVideo.duration) return;
        const ratio = mainVideo.currentTime / mainVideo.duration;
        const pct = `${ratio * 100}%`;
        if (hud.progress) hud.progress.style.width = pct;
        if (hud.progressThumb) hud.progressThumb.style.left = pct;
        if (hud.timeCurrent) hud.timeCurrent.textContent = formatTime(mainVideo.currentTime);
        if (hud.timeTotal) hud.timeTotal.textContent = formatTime(mainVideo.duration);
    }

    function seekFromEvent(e) {
        if (!mainVideo || !mainVideo.duration || !hud.progressTrack) return;
        const rect = hud.progressTrack.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        mainVideo.currentTime = ratio * mainVideo.duration;
        if (ambienceVideo && ambienceVideo.duration) ambienceVideo.currentTime = mainVideo.currentTime;
        updateProgressUI();
    }

    function initProgressSeek() {
        if (!hud.progressTrack) return;
        const onDown = (e) => {
            if (!mainVideo?.duration) return;
            isSeeking = true;
            hud.progressTrack.classList.add('seeking');
            seekFromEvent(e);
            e.preventDefault();
        };
        const onMove = (e) => { if (isSeeking) seekFromEvent(e); };
        const onUp = () => {
            isSeeking = false;
            hud.progressTrack?.classList.remove('seeking');
        };
        hud.progressTrack.addEventListener('mousedown', onDown);
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    function setVolume(level) {
        const vol = Math.max(0, Math.min(1, level));
        cfg.volume = vol;
        if (mainVideo) {
            mainVideo.volume = vol;
            if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
        }
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        updateHudMuteIcon();
        // Debounce storage writes so sliding the volume doesn't thrash storage
        // (and so even a mis-fired rebuild can't spam-reshuffle mid-drag)
        clearTimeout(volumeSaveTimer);
        volumeSaveTimer = setTimeout(() => {
            chrome.storage.local.get('mediaConfig', ({ mediaConfig = {} }) => {
                // Only write if volume actually differs (avoids echo loops)
                if (mediaConfig.volume === vol) return;
                chrome.storage.local.set({ mediaConfig: { ...mediaConfig, volume: vol } });
            });
        }, 180);
    }

    function revealHud() {
        if (!hud.box || cfg.layout !== 'cinema') return;
        hud.box.classList.add('hud-visible');
        hud.box.classList.remove('hud-idle');
        clearTimeout(hudIdleTimer);
        hudIdleTimer = setTimeout(() => {
            if (!hud.box.matches(':hover')) hud.box.classList.add('hud-idle');
            hud.box.classList.remove('hud-visible');
        }, HUD_IDLE_MS);
    }

    function initHudAutoHide() {
        if (cfg.layout === 'cinema') revealHud();
        else if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
    }

    function updateEmptyState() {
        if (!emptyState) return;
        emptyState.classList.toggle('hidden', !libraryEmpty || cfg.layout !== 'cinema');
    }

    function toggleFullscreen() {
        document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    }

    function togglePause() {
        if (cfg.layout === 'collage') {
            isPaused = !isPaused;
            ui.clock.style.opacity = isPaused ? 0.5 : 1;
            if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
            return;
        }

        if (!mainVideo) return;

        // At end of untagged clip: stay paused until tagged, then Space advances
        if (mainVideo.ended && (isPaused || mainVideo.paused)) {
            if (window.FAFOMeta?.isUntagged?.()) {
                window.FAFOMeta.notifyEndNeedsTag?.();
                revealHud();
                return;
            }
            // Tagged — go to next clip
            loopCount = 0;
            if (playlist.length) {
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            isPaused = false;
            ui.clock.style.opacity = 1;
            if (hud.play) hud.play.textContent = '⏸';
            playNext();
            revealHud();
            return;
        }

        isPaused = !isPaused;
        ui.clock.style.opacity = isPaused ? 0.5 : 1;
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';

        if (isPaused) {
            mainVideo.pause();
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.pause();
        } else {
            mainVideo.play().catch(() => {});
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.play().catch(() => {});
        }
        syncParticlePerformance();
        revealHud();
    }

    function getTrackName(item) {
        if (!item) return '—';
        if (item.name) return item.name;
        if (item.handle?.name) return item.handle.name;
        if (item.url) return item.url.split('/').pop().split('?')[0] || 'Stream';
        return 'Unknown';
    }

    function updateHUD() {
        if (!hud.box) return;
        const item = playlist[currentIdx];
        if (hud.title) hud.title.textContent = getTrackName(item);
        if (hud.index) hud.index.textContent = playlist.length ? `${currentIdx + 1} / ${playlist.length}` : '0 / 0';
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(cfg.playbackSpeed || 1);
        updateHudMuteIcon();
        const isVideo = item?.type === 'video' && cfg.layout === 'cinema';
        if (hud.progressWrap) hud.progressWrap.classList.toggle('hidden', !isVideo);
        if (!isVideo && hud.timeCurrent) hud.timeCurrent.textContent = '0:00';
        if (!isVideo && hud.timeTotal) hud.timeTotal.textContent = '0:00';
        updateEmptyState();
    }

    function updateHudMuteIcon() {
        if (!hud.mute) return;
        const muted = !mainVideo || mainVideo.muted || mainVideo.volume === 0;
        hud.mute.textContent = muted ? '🔇' : '🔊';
    }

    function startProgressBar() {
        if (progressInterval) clearInterval(progressInterval);
        if (!mainVideo) return;
        mainVideo.removeEventListener('timeupdate', updateProgressUI);
        mainVideo.addEventListener('timeupdate', updateProgressUI);
        updateProgressUI();
    }

    function bindHudReveal(el, fn) {
        if (!el) return;
        el.addEventListener('click', () => { revealHud(); fn(); });
    }

    function initHudControls() {
        bindHudReveal(hud.prev, () => skipTrack(-1));
        bindHudReveal(hud.next, () => skipTrack(1));
        bindHudReveal(hud.play, () => togglePause());
        bindHudReveal(hud.shuffle, () => toggleShuffle());
        bindHudReveal(hud.speedDown, () => changeSpeed(-1));
        bindHudReveal(hud.speedUp, () => changeSpeed(1));
        if (hud.speed) hud.speed.onclick = () => { revealHud(); setPlaybackSpeed(1); };
        bindHudReveal(hud.mute, () => toggleMute());
        bindHudReveal(hud.pip, () => togglePiP());
        bindHudReveal(hud.fs, () => toggleFullscreen());
        bindHudReveal(document.getElementById('hud-playlist'), () => openPlaylistPicker());
        if (hud.volume) {
            hud.volume.value = Math.round((cfg.volume ?? 0.7) * 100);
            hud.volume.addEventListener('input', () => {
                revealHud();
                setVolume(hud.volume.value / 100);
            });
        }
        initProgressSeek();
        const helpClose = document.getElementById('help-close');
        if (helpClose) helpClose.onclick = () => shortcutHelp?.classList.add('hidden');
        if (hud.box) {
            hud.box.addEventListener('mouseenter', revealHud);
            hud.box.addEventListener('mousemove', revealHud);
        }
        if (hud.progressTrack) {
            hud.progressTrack.addEventListener('mousedown', revealHud);
        }
        updateHUD();
    }

    // --- 4. LIBRARY MANAGEMENT ---

    function toPlaylistItem(entry, typeHint) {
        if (!entry) return null;
        const unwrapped = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(entry) : null;
        if (unwrapped?.handle) {
            return {
                type: typeHint || (unwrapped.storeName === 'photos' ? 'photo' : 'video'),
                handle: unwrapped.handle,
                name: unwrapped.name,
            };
        }
        if (entry.handle) {
            return { type: typeHint || 'video', handle: entry.handle, name: entry.name };
        }
        if (typeof entry.getFile === 'function' || entry.kind === 'file') {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        if (entry instanceof File) {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        return null;
    }

    async function buildPlaylist() {
        playlist = [];
        libraryEmpty = false;
        
        // 1. PLAYLIST MODE: manual or smart
        if (cfg.activePlaylistId && cfg.activePlaylistId !== 'all' && db) {
            try {
                const tx = db.transaction('playlists', 'readonly');
                const store = tx.objectStore('playlists');
                const pl = await new Promise(res => {
                    const req = store.get(cfg.activePlaylistId);
                    req.onsuccess = () => res(req.result);
                    req.onerror = () => res(null);
                });

                if (pl && window.FAFOLibrary?.resolvePlaylist) {
                    const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
                    const resolved = await FAFOLibrary.resolvePlaylist(db, pl, fafoMediaMeta);
                    for (const item of resolved) {
                        playlist.push({
                            type: item.type,
                            handle: item.handle,
                            name: item.name,
                        });
                    }
                } else if (pl?.items?.length) {
                    for (const itemRef of pl.items) {
                        const raw = await getHandleByKey(itemRef.store || itemRef.storeName, itemRef.key);
                        const item = toPlaylistItem(raw, (itemRef.store || itemRef.storeName) === 'photos' ? 'photo' : 'video');
                        if (item) playlist.push(item);
                    }
                }
            } catch (e) { console.warn('Failed to load playlist', e); }
        } 
        
        // 2. FALLBACK TO ALL IF EMPTY OR 'ALL' MODE
        if (playlist.length === 0) {
            if (cfg.useLocal) {
                const videos = await getHandles('videos');
                for (const h of videos) {
                    const item = toPlaylistItem(h, 'video');
                    if (item) playlist.push(item);
                }
            }
            if (cfg.usePhotos) {
                const photos = await getHandles('photos');
                for (const h of photos) {
                    const item = toPlaylistItem(h, 'photo');
                    if (item) playlist.push(item);
                }
            }
            const bundled = await loadBundledLibrary();
            if (bundled.length > 0) playlist.push(...bundled);
        }
        
        // 3. FINAL FALLBACK
        if (playlist.length === 0) {
            if (cfg.urls && cfg.urls.length > 0) {
                playlist = cfg.urls.map(u => ({type: 'video', url: u}));
            } else {
                libraryEmpty = true;
                playlist = [{type: 'video', url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm', isDemo: true}];
            }
        }
        
        if (cfg.shuffle) playlist = playlist.sort(() => Math.random() - 0.5);
        updateEmptyState();
        maybeShowRestoreBanner();
    }

    // Helper to get specific item for playlist
    async function getHandleByKey(storeName, key) {
        return new Promise(res => {
            try {
                const tx = db.transaction(storeName, 'readonly');
                const req = tx.objectStore(storeName).get(key);
                req.onsuccess = () => res(req.result);
                req.onerror = () => res(null);
            } catch(e) { res(null); }
        });
    }

    async function loadBundledLibrary() {
        try {
            const resp = await fetch('library.json');
            if (!resp.ok) return [];
            const files = await resp.json();
            return files.map(f => {
                const path = f.replace(/^videos\//i, 'Videos/').replace(/^photos\//i, 'Photos/');
                return {
                    type: path.match(/\.(jpg|jpeg|png|webp|gif)$/i) ? 'photo' : 'video',
                    url: path,
                    isBundled: true
                };
            });
        } catch (e) {
            return [];
        }
    }

    let restoreBannerEl = null;

    function removeRestoreBanner() {
        if (restoreBannerEl) {
            if (restoreBannerEl._wrap) restoreBannerEl._wrap.remove();
            else restoreBannerEl.remove();
            restoreBannerEl = null;
        }
        permissionWarned = false;
    }

    async function restoreLibraryAccessFromBanner() {
        if (!db || !window.FAFOLibrary) {
            window.location.href = 'options.html';
            return;
        }
        try {
            if (restoreBannerEl) {
                restoreBannerEl.textContent = '🔓 Restoring access… allow if Chrome asks';
                restoreBannerEl.disabled = true;
            }
            const r = await FAFOLibrary.restoreAccess(db);
            // Optional light resync when folders exist
            const folders = await FAFOLibrary.listFolders(db);
            if (folders.length) {
                await FAFOLibrary.resyncAllFolders(db);
            }
            removeRestoreBanner();
            await buildPlaylist();
            if (typeof initLayout === 'function') initLayout();
            else if (typeof playNext === 'function') playNext();
            console.info('Library access restored', r);
        } catch (e) {
            console.warn(e);
            if (restoreBannerEl) {
                restoreBannerEl.disabled = false;
                restoreBannerEl.textContent = '⚠️ Restore failed — click for Options';
                restoreBannerEl.onclick = () => { window.location.href = 'options.html'; };
            }
        }
    }

    function showRestoreBanner(msg) {
        if (restoreBannerEl) return;
        permissionWarned = true;
        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:96vw;';
        const warn = document.createElement('button');
        warn.textContent = msg || '⚠️ Library access lost — click to Restore (no re-link)';
        warn.style.cssText = 'background:#d32f2f;color:white;padding:12px 18px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.5);';
        warn.onclick = () => restoreLibraryAccessFromBanner();
        const opt = document.createElement('button');
        opt.textContent = 'Options';
        opt.style.cssText = 'background:#222;color:#fff;padding:12px 14px;border:1px solid #555;border-radius:8px;cursor:pointer;';
        opt.onclick = () => { window.location.href = 'options.html'; };
        wrap.appendChild(warn);
        wrap.appendChild(opt);
        document.body.appendChild(wrap);
        restoreBannerEl = warn;
        // Keep wrap as parent for remove
        restoreBannerEl._wrap = wrap;
        const origRemove = restoreBannerEl.remove.bind(restoreBannerEl);
        restoreBannerEl.remove = () => { wrap.remove(); };
    }

    async function maybeShowRestoreBanner() {
        if (!db || !window.FAFOLibrary || permissionWarned) return;
        try {
            const st = await FAFOLibrary.libraryAccessStatus(db);
            if (st.needsRestore && (st.folders > 0 || st.sampleBad > 0)) {
                showRestoreBanner('⚠️ Library access needs restore — click here (saved folders, no re-pick)');
            }
        } catch (_) {}
    }

    async function getSrc(item) {
        if (item.url) return item.url;
        if (item.handle) {
            if (item.handle instanceof File) {
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(item.handle);
                return currentBlobUrl;
            }
            try {
                if (window.FAFOLibrary) {
                    const ok = await FAFOLibrary.ensurePermission(item.handle, 'read');
                    if (!ok) throw new Error('permission denied');
                }
                const file = await item.handle.getFile();
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(file);
                removeRestoreBanner();
                return currentBlobUrl;
            } catch (e) {
                showRestoreBanner('⚠️ Permissions lost — click to Restore Access (keeps your folders)');
                return null;
            }
        }
        return null;
    }

    async function getHandles(store) {
        if (!db) return [];
        try {
            const tx = db.transaction(store, 'readonly');
            const req = tx.objectStore(store).getAll();
            return new Promise(res => req.onsuccess = () => res(req.result || []));
        } catch(e) { return []; }
    }
    
    function getObjectFitFromConfig() {
        switch(cfg.scaling) {
            case 'scale-cover': return 'cover';
            case 'scale-contain': return 'contain';
            case 'scale-capped': return 'contain'; 
            case 'scale-center': return 'none';
            default: return 'contain';
        }
    }

    // --- 5. LAYOUT ENGINES ---

    function initLayout() {
        scene.innerHTML = '';
        if (collageInterval) clearInterval(collageInterval);
        if (photoTimeout) clearTimeout(photoTimeout);
        if (progressInterval) clearInterval(progressInterval);
        if (neonEngine) neonEngine.disconnectAudio();
        revokeCurrentBlob();

        if (cfg.layout !== 'cinema') {
            overlay.style.opacity = '0';
            if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
        } else {
            initHudAutoHide();
        }

        scene.className = `layout-${cfg.layout}`;
        scene.removeAttribute('style'); 
        
        if (cfg.layout === 'grid') initGrid();
        else if (cfg.layout === 'carousel') initCarousel();
        else if (cfg.layout === 'collage') initCollage(); 
        else initCinema();
    }

    function initCinema() {
        // Dual-video ambilight (2× decode + huge CSS blur) is the #1 lag source on 4K.
        const useAmbiVideo = cfg.ambiMode === 'blur'
            && !cfg.disableAmbience
            && !cfg.performanceMode;

        if (useAmbiVideo) {
            ambienceVideo = document.createElement('video');
            ambienceVideo.className = 'ambience';
            ambienceVideo.muted = true;
            ambienceVideo.loop = true;
            ambienceVideo.playsInline = true;
            // Prefer cheaper blur in normal mode; still expensive — keep scale modest
            const blurPx = Math.min(cfg.ambiBlur || 5, 12);
            ambienceVideo.style.filter = `blur(${blurPx}px) brightness(${cfg.ambiOpacity}) saturate(1.1)`;
            ambienceVideo.style.transform = `translate(-50%, -50%) scale(${cfg.ambiScale}) translateZ(0)`;
            ambienceVideo.style.willChange = 'transform';
            scene.appendChild(ambienceVideo);
        } else {
            scene.style.backgroundColor = cfg.accentColor || '#000';
            ambienceVideo = null;
        }

        mainVideo = document.createElement('video');
        mainVideo.id = 'bg-video';
        mainVideo.playsInline = true;
        mainVideo.autoplay = true;
        // Prefer hardware decode paths; avoid software filter on the video element itself
        try { mainVideo.disableRemotePlayback = true; } catch (_) {}
        applyVideoGpuHints(mainVideo);
        scene.appendChild(mainVideo);

        playNext();
        updateHUD();
        
        mainVideo.addEventListener('play', syncParticlePerformance);
        mainVideo.addEventListener('pause', syncParticlePerformance);

        mainVideo.onended = () => {
            // Hold at end if this clip still has no tags — so you can rate/tag before skip
            try {
                if (window.FAFOMeta?.isUntagged?.()) {
                    isPaused = true;
                    ui.clock.style.opacity = 0.5;
                    if (hud.play) hud.play.textContent = '▶';
                    if (ambienceVideo) try { ambienceVideo.pause(); } catch (_) {}
                    window.FAFOMeta.notifyEndNeedsTag?.();
                    revealHud();
                    syncParticlePerformance();
                    return;
                }
            } catch (e) { console.warn('untagged end check', e); }

            if (++loopCount >= cfg.loops) {
                loopCount = 0;
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            playNext();
        };

        const sync = () => {
            if(ambienceVideo && Math.abs(mainVideo.currentTime - ambienceVideo.currentTime) > 0.5) 
                ambienceVideo.currentTime = mainVideo.currentTime;
        };
        
        if(ambienceVideo) {
            mainVideo.addEventListener('play', () => ambienceVideo.play().catch(()=>{}));
            mainVideo.addEventListener('pause', () => ambienceVideo.pause());
            mainVideo.addEventListener('timeupdate', sync);
        }
    }

    async function playNext() {
        if (consecutiveErrors > 5) return; 

        if (photoTimeout) clearTimeout(photoTimeout);
        overlay.style.opacity = '1';
        
        await new Promise(r => setTimeout(r, 250));

        const item = playlist[currentIdx];
        if (!item) return; 

        const src = await getSrc(item);
        
        if (!src) {
             consecutiveErrors++;
             pushPlayHistory(currentIdx);
             currentIdx = findNextEligibleIndex(currentIdx, 1);
             setTimeout(playNext, 100);
             return;
        }

        consecutiveErrors = 0;
        const fileName = item.handle?.name || (item.url ? item.url.split('/').pop() : 'unknown');
        const overrides = cfg.overrides?.[fileName] || {};
        updateHUD();
        try {
            if (window.FAFOMeta?.bindToItem) {
                window.FAFOMeta.bindToItem(item, currentIdx);
            }
        } catch (e) { console.warn('FAFOMeta bind', e); }
        
        const vol = overrides.volume !== undefined ? overrides.volume : cfg.volume;
        mainVideo.volume = vol;
        mainVideo.playbackRate = cfg.playbackSpeed || 1;
        if (hud.volume) hud.volume.value = Math.round(vol * 100);

        let scaleMode = overrides.scaling || cfg.scaling;
        let objectFit = 'contain';
        if (scaleMode === 'scale-cover' || scaleMode === 'cover') objectFit = 'cover';
        else if (scaleMode === 'scale-center') objectFit = 'none';
        
        applyCinemaObjectFit(mainVideo, objectFit);
        mainVideo.classList.remove('ken-burns');
        
        if(ambienceVideo) ambienceVideo.src = src;

        if (item.type === 'photo') {
            mainVideo.style.background = `url("${src}") center/${objectFit === 'cover' ? 'cover' : 'contain'} no-repeat`;
            mainVideo.src = "";
            
            if(ambienceVideo) ambienceVideo.poster = src;
            if(cfg.kenburns) mainVideo.classList.add('ken-burns');
            
            overlay.style.opacity = '0';
            photoTimeout = setTimeout(() => {
                if (!isPaused) {
                    pushPlayHistory(currentIdx);
                    currentIdx = findNextEligibleIndex(currentIdx, 1);
                    playNext();
                }
            }, cfg.photoDuration * 1000);
        } else {
            mainVideo.src = src;
            mainVideo.style.background = '';
            
            try {
                await mainVideo.play();
                if(ambienceVideo) await ambienceVideo.play();
                overlay.style.opacity = '0';
                applyVideoGpuHints(mainVideo);
                if (neonEngine) {
                    if (cfg.disableNeonAudio || cfg.performanceMode) {
                        try { neonEngine.disconnectAudio(); } catch (_) {}
                    } else {
                        neonEngine.connectAudio(mainVideo);
                    }
                }
                startProgressBar();
                updateHudMuteIcon();
                syncParticlePerformance();
            } catch(e) {
                console.warn("Autoplay blocked, muted retry.");
                mainVideo.muted = true;
                try { 
                    await mainVideo.play(); 
                    overlay.style.opacity = '0';
                } catch(err) {
                    consecutiveErrors++;
                    playNext();
                }
            }
        }
    }

    function initGrid() {
        const { cellCount } = applyGridDimensions();

        for (let i = 0; i < cellCount; i++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;

            v.onerror = () => loadRandomVideo(v);
            cell.appendChild(v);
            scene.appendChild(cell);
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
    }

    function initCarousel() {
        const pivot = document.createElement('div');
        pivot.className = 'carousel-pivot';
        scene.appendChild(pivot);
        
        scene.style.transform = `rotateX(${cfg.carouselTilt}deg)`;

        const count = cfg.carouselCount;
        const radius = cfg.carouselRadius;
        const fit = getObjectFitFromConfig();

        for (let i = 0; i < count; i++) {
            const card = document.createElement('div');
            card.className = 'carousel-card';
            
            // FIX: Inner wrapper for breathing animation
            const inner = document.createElement('div');
            inner.className = 'carousel-inner';
            inner.style.animationDelay = `${i * 0.2}s`;

            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;
            v.style.width = '100%';
            v.style.height = '100%';
            v.style.objectFit = fit;
            
            v.onerror = () => loadRandomVideo(v);
            
            inner.appendChild(v);
            card.appendChild(inner);
            pivot.appendChild(card);
            
            const angle = (i / count) * 360;
            // 3D Transform is now safe on the outer card
            card.style.transform = `rotateY(${angle}deg) translateZ(${radius}px)`;
            
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
        // Pivot spin is handled in CSS via class
        pivot.style.animationDuration = `${cfg.carouselSpeed}s`;
    }

    function initCollage() {
        const photoPlaylist = playlist.filter(item => item.type === 'photo');
        
        if (!photoPlaylist.length) {
            const msg = document.createElement('div');
            msg.textContent = "Add photos to library for Collage Mode";
            msg.style.color = "#555";
            scene.appendChild(msg);
            return;
        }

        isPaused = false;

        const spawnPhoto = async () => {
            if (isPaused) return;

            const item = photoPlaylist[Math.floor(Math.random() * photoPlaylist.length)];
            const src = await getSrc(item);
            if (!src) return;

            const img = document.createElement('img');
            img.src = src;
            img.className = 'collage-card';
            
            const top = Math.random() * 80;
            const left = Math.random() * 80;
            const rot = (Math.random() - 0.5) * 40;
            
            img.style.top = `${top}%`;
            img.style.left = `${left}%`;
            img.style.transform = `rotate(${rot}deg) scale(0.8)`;
            
            img.style.zIndex = Date.now() % 10000; 

            scene.appendChild(img);

            requestAnimationFrame(() => {
                img.classList.add('visible');
                img.style.transform = `rotate(${rot}deg) scale(1)`;
            });

            setTimeout(() => {
                img.style.opacity = 0;
                setTimeout(() => img.remove(), 2000);
            }, 60000);
        };

        spawnPhoto();
        spawnPhoto();
        spawnPhoto();
        
        collageInterval = setInterval(spawnPhoto, 3000); 
    }

    async function loadRandomVideo(v) {
        if (!playlist.length) return;
        const item = playlist[Math.floor(Math.random() * playlist.length)];
        const src = await getSrc(item);
        if (!src) return;

        if (item.type === 'photo') {
             v.src = "";
             v.poster = src;
        } else {
            v.src = src;
            v.muted = true;
            v.playsInline = true;
            try {
                await v.play();
            } catch(e) {
                // console.warn("Grid autoplay blocked, retrying muted...", e);
                v.muted = true;
                try {
                    await v.play();
                } catch(err) {
                    // console.error("Grid video failed completely", err);
                }
            }
        }
    }

    // --- 6. UTILITIES ---

    function startClock() {
        if (clockInterval) clearInterval(clockInterval);
        const tick = () => {
            const n = new Date();
            let h = n.getHours();
            if (cfg.format12h) h = h % 12 || 12;
            const m = n.getMinutes().toString().padStart(2, '0');
            const s = n.getSeconds().toString().padStart(2, '0');
            ui.clock.textContent = cfg.showSeconds ? `${h}:${m}:${s}` : `${h}:${m}`;
            if (cfg.showDate) ui.date.textContent = n.toLocaleDateString(undefined, {weekday:'long', month:'long', day:'numeric'});
        };
        tick();
        clockInterval = setInterval(tick, 1000);
    }

    async function initDB() {
        try {
            if (window.FAFOLibrary?.openDB) {
                db = await FAFOLibrary.openDB();
                return;
            }
        } catch (e) {
            console.warn('FAFOLibrary.openDB failed', e);
        }
        db = await new Promise(res => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            req.onblocked = () => console.warn('Database Upgrade Pending — close other FAFO tabs');
            req.onupgradeneeded = e => {
                const d = e.target.result;
                ['videos', 'photos'].forEach(s => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', { keyPath: 'id' });
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }

    function startHealthCheck() {
        if (healthCheckInterval) clearInterval(healthCheckInterval);
        healthCheckInterval = setInterval(() => {
            if (isPaused) return;
            const videos = document.querySelectorAll('#scene-root video');
            videos.forEach(v => {
                if (v.src && !v.paused && v.readyState < 3 && !v.ended) {
                    v.play().catch(() => {
                         if(!v.muted) { v.muted = true; v.play().catch(()=>{}); }
                    });
                }
            });
        }, 5000);
    }
});