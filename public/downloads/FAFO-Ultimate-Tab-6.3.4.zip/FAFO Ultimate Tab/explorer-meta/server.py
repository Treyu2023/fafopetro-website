"""
FAFO Explorer Metadata Server
-----------------------------
Lightweight local companion for FAFO Ultimate Tab.

Listens on http://127.0.0.1:8765 and writes real Windows file metadata
(System.Keywords tags + System.Rating stars) so File Explorer and other
apps can see ratings/tags set while videos play.

Compatible API subset used by FAFO:
  GET  /api/health
  POST /api/fs/write-metadata
  GET  /api/fs/read-metadata
  POST /api/library/add-folder
  GET  /api/library
  POST /api/library/rescan

Also works side-by-side with the full AI HTML TOOLBOX server if that is
already running on the same port (start only ONE of them).
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any

# Ensure local imports work when launched from any CWD
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from file_metadata import write_file_metadata, read_file_metadata, normalize_tags

HOST = "127.0.0.1"
PORT = 8765
CONFIG_PATH = ROOT / "config.json"
INDEX_PATH = ROOT / "library_index.json"

VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi", ".wmv", ".ts"}
SKIP_DIRS = {"$recycle.bin", "system volume information", ".git", "node_modules", "__pycache__"}

app = FastAPI(title="FAFO Explorer Metadata Server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_lock = threading.Lock()
_index: dict[str, list[dict[str, Any]]] = {}  # name_lower -> [{path, size, mtime, name}]
_config: dict[str, Any] = {"watched_dirs": [], "version": 1}


def load_config() -> dict[str, Any]:
    global _config
    if CONFIG_PATH.exists():
        try:
            _config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            _config = {"watched_dirs": [], "version": 1}
    else:
        _config = {"watched_dirs": [], "version": 1}
    _config.setdefault("watched_dirs", [])
    return _config


def save_config() -> None:
    CONFIG_PATH.write_text(json.dumps(_config, indent=2), encoding="utf-8")


def load_index() -> None:
    global _index
    if INDEX_PATH.exists():
        try:
            data = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
            _index = data.get("by_name") or {}
            return
        except Exception:
            pass
    _index = {}


def save_index() -> None:
    INDEX_PATH.write_text(
        json.dumps({"by_name": _index, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )


def scan_dir(root: Path) -> int:
    """Index video files under root. Returns count added/updated."""
    count = 0
    root = root.resolve()
    if not root.is_dir():
        return 0

    for dirpath, dirnames, filenames in os.walk(root):
        # prune junk
        dirnames[:] = [
            d for d in dirnames
            if d.lower() not in SKIP_DIRS and not d.startswith(".")
        ]
        for name in filenames:
            ext = Path(name).suffix.lower()
            if ext not in VIDEO_EXTS:
                continue
            full = Path(dirpath) / name
            try:
                st = full.stat()
            except OSError:
                continue
            entry = {
                "path": str(full),
                "name": name,
                "size": st.st_size,
                "mtime": st.st_mtime,
            }
            key = name.lower()
            with _lock:
                bucket = _index.setdefault(key, [])
                # replace same path
                bucket = [e for e in bucket if e.get("path") != entry["path"]]
                bucket.append(entry)
                _index[key] = bucket
            count += 1
    return count


def rebuild_index() -> int:
    global _index
    with _lock:
        _index = {}
    total = 0
    for d in list(_config.get("watched_dirs") or []):
        total += scan_dir(Path(d))
    # Always index sibling Videos folder if present (bundled library)
    bundled = ROOT.parent / "Videos"
    if bundled.is_dir() and str(bundled.resolve()) not in [
        str(Path(x).resolve()) for x in (_config.get("watched_dirs") or []) if Path(x).exists()
    ]:
        total += scan_dir(bundled)
    save_index()
    return total


def find_by_identity(
    name: str | None,
    size: int | None,
    mtime: float | None,
    path: str | None = None,
) -> Path | None:
    if path:
        p = Path(path)
        if p.is_file():
            return p

    if not name:
        return None

    key = name.lower()
    with _lock:
        candidates = list(_index.get(key) or [])

    if not candidates:
        # fallback: search watched dirs + bundled Videos live
        for d in list(_config.get("watched_dirs") or []) + [str(ROOT.parent / "Videos")]:
            root = Path(d)
            if not root.is_dir():
                continue
            for hit in root.rglob(name):
                if hit.is_file():
                    candidates.append({
                        "path": str(hit),
                        "name": hit.name,
                        "size": hit.stat().st_size,
                        "mtime": hit.stat().st_mtime,
                    })

    if not candidates:
        return None

    if size is not None:
        sized = [c for c in candidates if int(c.get("size") or 0) == int(size)]
        if sized:
            candidates = sized

    if mtime is not None and len(candidates) > 1:
        mt = float(mtime)
        if mt > 1e12:
            mt = mt / 1000.0
        candidates = sorted(candidates, key=lambda c: abs(float(c.get("mtime") or 0) - mt))

    p = Path(candidates[0]["path"])
    return p if p.is_file() else None


class FileMetaWrite(BaseModel):
    path: str | None = None
    name: str | None = None
    size: int | None = None
    mtime: float | None = None
    tags: list[str] | None = None
    rating: int | None = None
    update_catalog: bool = True


class AddFolder(BaseModel):
    path: str = Field(..., description="Absolute folder path to index for metadata writes")


@app.on_event("startup")
def on_startup() -> None:
    load_config()
    load_index()
    # Auto-index bundled Videos + configured dirs
    try:
        n = rebuild_index()
        print(f"[FAFO Meta] Indexed {n} video files from watched folders.")
    except Exception as e:
        print(f"[FAFO Meta] Index warning: {e}")


@app.get("/api/health")
def health():
    return {
        "ok": True,
        "service": "fafo-explorer-meta",
        "version": "1.0.0",
        "watched_dirs": _config.get("watched_dirs") or [],
        "indexed_names": len(_index),
    }


@app.get("/api/library")
def library_info():
    with _lock:
        file_count = sum(len(v) for v in _index.values())
    return {
        "watched_dirs": _config.get("watched_dirs") or [],
        "file_count": file_count,
        "unique_names": len(_index),
    }


@app.post("/api/library/add-folder")
def add_folder(body: AddFolder):
    p = Path(body.path).expanduser()
    if not p.is_dir():
        raise HTTPException(404, f"Folder not found: {body.path}")
    resolved = str(p.resolve())
    dirs = list(_config.get("watched_dirs") or [])
    if resolved not in dirs:
        dirs.append(resolved)
        _config["watched_dirs"] = dirs
        save_config()
    n = scan_dir(p)
    save_index()
    return {"ok": True, "path": resolved, "files_indexed": n, "watched_dirs": _config["watched_dirs"]}


@app.post("/api/library/rescan")
def rescan():
    n = rebuild_index()
    return {"ok": True, "files_indexed": n, "watched_dirs": _config.get("watched_dirs") or []}


@app.post("/api/fs/write-metadata")
def api_write_metadata(body: FileMetaWrite):
    if body.tags is None and body.rating is None:
        raise HTTPException(400, "Provide tags and/or rating")

    target = find_by_identity(body.name, body.size, body.mtime, body.path)
    if not target:
        raise HTTPException(
            404,
            "File not found in the metadata library. "
            "Run START_META_SERVER.bat, then add the video folder "
            "(POST /api/library/add-folder or edit config.json watched_dirs) "
            "or pass an absolute path.",
        )

    tags = normalize_tags(body.tags) if body.tags is not None else None
    rating = body.rating
    if rating is not None:
        try:
            rating = max(0, min(5, int(rating)))
        except (TypeError, ValueError):
            rating = 0

    result = write_file_metadata(target, tags=tags, rating=rating)
    result["resolved_path"] = str(target)
    # Refresh this entry in index
    try:
        st = target.stat()
        key = target.name.lower()
        entry = {"path": str(target), "name": target.name, "size": st.st_size, "mtime": st.st_mtime}
        with _lock:
            bucket = [e for e in (_index.get(key) or []) if e.get("path") != entry["path"]]
            bucket.append(entry)
            _index[key] = bucket
        save_index()
    except Exception:
        pass
    return result


@app.get("/api/fs/read-metadata")
def api_read_metadata(path: str = Query(...)):
    p = Path(path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    return read_file_metadata(p)


def main() -> None:
    print("=" * 56)
    print("  FAFO Explorer Metadata Server")
    print(f"  http://{HOST}:{PORT}")
    print("  Keep this window open while using FAFO tags/ratings.")
    print("  Press Ctrl+C to stop.")
    print("=" * 56)
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")


if __name__ == "__main__":
    main()
