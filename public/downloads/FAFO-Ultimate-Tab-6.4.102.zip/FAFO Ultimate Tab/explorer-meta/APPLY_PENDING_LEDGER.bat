@echo off
setlocal EnableExtensions
title FAFO — apply pending ledger
cd /d "%~dp0"

REM Starts the companion server if needed, waits briefly, then writes pending
REM tags/ratings from fafo-meta-ledger.json onto Windows Explorer files.

set QUIET=0
if /I "%~1"=="/quiet" set QUIET=1
if /I "%~1"=="--quiet" set QUIET=1

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Run INSTALL_DEPS.bat first.
  if "%QUIET%"=="0" pause
  exit /b 1
)

echo.
echo  FAFO salvage ledger
echo  Starting companion if needed, then applying pending Explorer writes...
echo.

python "%~dp0stack.py" apply --delay 1
set ERR=%ERRORLEVEL%

if "%QUIET%"=="0" (
  echo.
  if not "%ERR%"=="0" echo  Finished with error code %ERR%.
  pause
)
exit /b %ERR%
