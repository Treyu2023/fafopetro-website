@echo off
title Compile FAFO Knowledge
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo Node.js not found on PATH. Install Node or run:
  echo   node tools\compile-fafo-knowledge.js
  pause
  exit /b 1
)
node tools\compile-fafo-knowledge.js
if errorlevel 1 (
  echo Compile failed.
  pause
  exit /b 1
)
echo.
echo Done. Guide: docs\knowledge\FAFO-GUIDE.md
echo Bundle: fafo-knowledge.bundle.js
pause
