# Milestone: pre–Chrome Web Store split (v6.4.59)

**Date:** 2026-08-13  
**Extension tip:** FAFO Ultimate Tab **6.4.59**  
**Repo:** `fafo-chrome-extensions` → `FAFO Local Media LOAD THIS\`  
**Remote:** `origin` → `https://github.com/Treyu2023/fafo-chrome-extensions.git`

## Why this milestone exists

1. Freeze the **full local/power-user** product (vaults, tag DB, wall config/scalability, chrome art, dual space) before a store-oriented line diverges on packaging/permissions.
2. Record an honest **store readiness** answer: still uploadable; not zip-the-whole-folder ready.
3. Anchor a **split branch** for Chrome Web Store packages without freezing innovation on `main`.

## Git markers (expected)

| Marker | Meaning |
|--------|---------|
| Tag `milestone/ultimate-tab-6.4.59-pre-store-split` | This freeze |
| Branch `store/chrome-web-store` | Store packaging + review hardening |
| Branch `main` | Continue full local development |

## Included product surface at freeze (high level)

- Opaque encrypted **tag DB** + grow-only vocabulary  
- **Multi private vaults** + master PIN non-retroactive rules  
- Light **play-panel tagging** + quick tags  
- **Wall** mode: 2/6/8, gap, full frames, live reflow, pin (Options + HUD)  
- Chrome art, backup/restore, pairing, library, companion hooks on localhost:8765  

## Explicitly not part of store zip

- User media libraries  
- Explorer companion runtime data / backups  
- Machine-local configs  

See `STORE_READINESS.md` and `tools/package-store-zip.ps1`.

## Older freeze

Prior desktop snapshot pointer: `MILESTONE_FREEZE.md` (v5.2.1 era, external path).
