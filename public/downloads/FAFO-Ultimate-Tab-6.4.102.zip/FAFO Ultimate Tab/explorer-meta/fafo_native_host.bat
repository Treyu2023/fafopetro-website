@echo off
setlocal EnableExtensions
set "PY="
if exist "%~dp0python.path" (
  set /p PY=<"%~dp0python.path"
)
if not defined PY set "PY=python"
"%PY%" -u "%~dp0fafo_native_host.py"
