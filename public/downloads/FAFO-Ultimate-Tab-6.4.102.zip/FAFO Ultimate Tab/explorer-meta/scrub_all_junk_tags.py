#!/usr/bin/env python3
"""
FAFO Fix-All: strip long / junk tags from every indexed media file + tag vocab.

Usage:
  python scrub_all_junk_tags.py              # rewrite all dirty files
  python scrub_all_junk_tags.py --dry-run    # scan only
  python scrub_all_junk_tags.py --via-api    # use running server POST /api/tags/scrub

Criteria (see file_metadata.is_junk_tag):
  - length > 100 chars
  - Signature: / ComfyUI / AI prompt dumps
  - paths, JSON blobs, base64 noise, multi-separator soup
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from file_metadata import (  # noqa: E402
    is_junk_tag,
    normalize_tags,
    read_file_metadata,
    write_file_metadata,
    TAG_MAX_CHARS,
)

INDEX_PATH = ROOT / "library_index.json"
TAGS_CACHE_PATH = ROOT / "tags_cache.json"
API = "http://127.0.0.1:8765/api/tags/scrub"


def load_index_paths() -> list[Path]:
    if not INDEX_PATH.exists():
        print(f"No library index at {INDEX_PATH}")
        return []
    data = json.loads(INDEX_PATH.read_text(encoding="utf-8-sig"))
    by_name = data.get("by_name") or {}
    paths: list[Path] = []
    seen: set[str] = set()
    for bucket in by_name.values():
        for e in bucket or []:
            p = e.get("path")
            if not p:
                continue
            key = str(Path(p))
            if key in seen:
                continue
            seen.add(key)
            paths.append(Path(p))
    return paths


def scrub_vocab() -> dict:
    removed = 0
    remaining: list[str] = []
    if TAGS_CACHE_PATH.exists():
        try:
            raw = json.loads(TAGS_CACHE_PATH.read_text(encoding="utf-8-sig"))
            tags = raw.get("tags") or []
        except Exception:
            tags = []
    else:
        tags = []
    keep: dict[str, str] = {}
    for t in tags:
        s = str(t).strip()
        if not s or is_junk_tag(s) or len(s) > TAG_MAX_CHARS:
            removed += 1
            continue
        for part in normalize_tags([s]):
            keep[part.lower()] = part
    remaining = sorted(keep.values(), key=str.lower)
    TAGS_CACHE_PATH.write_text(
        json.dumps({"tags": remaining, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )
    return {"removed": removed, "remaining": len(remaining)}


def scrub_files(paths: list[Path], *, dry_run: bool, max_files: int) -> dict:
    scanned = 0
    dirty = 0
    rewritten = 0
    failed = 0
    tags_dropped = 0
    samples: list[str] = []
    longest = 0

    for path in paths[:max_files]:
        if not path.is_file():
            continue
        scanned += 1
        try:
            meta = read_file_metadata(path)
            raw = list(meta.get("tags") or [])
            if not raw:
                continue
            clean = normalize_tags(raw)
            clean_low = {t.lower() for t in clean}
            dropped = []
            for t in raw:
                s = str(t or "").strip()
                if not s:
                    continue
                if s.lower() in clean_low:
                    continue
                dropped.append(s)
                longest = max(longest, len(s))
                if len(samples) < 15:
                    prev = s if len(s) <= 80 else s[:77] + "…"
                    samples.append(f"{prev} ({len(s)} chars) · {path.name}")

            raw_norm = [str(t).strip() for t in raw if str(t).strip()]
            same = {x.lower() for x in raw_norm} == clean_low and len(raw_norm) == len(clean)
            if same and not dropped:
                continue

            dirty += 1
            tags_dropped += max(0, len(raw) - len(clean))
            if dry_run:
                continue

            rating = meta.get("rating") or 0
            # Always write (even empty) to CLEAR junk keywords / ©cmt dumps from the file
            r = write_file_metadata(
                path,
                tags=clean,
                rating=int(rating) if rating else 0,
                retries=2,
                retry_delay_s=0.2,
            )
            if r.get("ok") or (r.get("methods") or []):
                rewritten += 1
            else:
                failed += 1
                print(f"  FAIL {path.name}: {r.get('errors')}")
        except Exception as e:
            failed += 1
            print(f"  ERR {path}: {e}")

        if scanned % 100 == 0:
            print(f"  … scanned {scanned} dirty={dirty} rewritten={rewritten}")

    return {
        "scanned": scanned,
        "dirty": dirty,
        "rewritten": rewritten,
        "failed": failed,
        "tags_dropped": tags_dropped,
        "longest": longest,
        "samples": samples,
        "dry_run": dry_run,
    }


def via_api(dry_run: bool) -> dict:
    import urllib.request

    body = json.dumps({"rewrite_files": not dry_run, "dry_run": dry_run, "max_files": 50000}).encode()
    req = urllib.request.Request(
        API,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=3600) as resp:
        return json.loads(resp.read().decode("utf-8"))


def main() -> int:
    ap = argparse.ArgumentParser(description="FAFO fix-all junk tag scrubber")
    ap.add_argument("--dry-run", action="store_true", help="Scan only, do not write")
    ap.add_argument("--via-api", action="store_true", help="Use running meta server API")
    ap.add_argument("--max-files", type=int, default=50000)
    args = ap.parse_args()

    print(f"FAFO junk-tag fix-all · max_chars={TAG_MAX_CHARS} · dry_run={args.dry_run}")
    t0 = time.time()

    if args.via_api:
        try:
            result = via_api(args.dry_run)
            print(json.dumps(result, indent=2)[:4000])
            print(f"Done in {time.time() - t0:.1f}s via API")
            return 0
        except Exception as e:
            print(f"API failed ({e}) — falling back to local scrub")

    vocab = scrub_vocab()
    print(f"Tag vocab: removed {vocab['removed']}, remaining {vocab['remaining']}")

    paths = load_index_paths()
    print(f"Indexed paths: {len(paths)}")
    result = scrub_files(paths, dry_run=args.dry_run, max_files=args.max_files)
    print("---")
    print(f"Scanned:      {result['scanned']}")
    print(f"Files dirty:  {result['dirty']}")
    print(f"Rewritten:    {result['rewritten']}")
    print(f"Failed:       {result['failed']}")
    print(f"Tags dropped: {result['tags_dropped']}")
    print(f"Longest junk: {result['longest']} chars")
    if result["samples"]:
        print("Samples:")
        for s in result["samples"]:
            print(f"  • {s}")
    print(f"Done in {time.time() - t0:.1f}s")
    print()
    print("Also open FAFO new-tab → ★ Tags → Clear junk… to clean Chrome storage.")
    return 0 if result["failed"] == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
