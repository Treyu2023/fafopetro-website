# FAFO Local Media — **LOAD THIS**

**Path:** `D:\Chrome python_HTML AI apps\FAFO Local Media LOAD THIS`  
**Chrome name:** FAFO Local Media · **version 7.2.0**

## What this is

Merged product:

| Source | Brought in |
|--------|------------|
| `C:\Users\rkey2\FAFO_Ultimate_Tab` **6.4.6** | Full tags UI, pairs/compare, smart playlists, library, explorer dock, E-set, skip/apply+next, options About, etc. |
| Local Media visuals | Pro neon border v3, full particle engine (stars/dust/meteors/…) |
| This package extras | Cinematic multi-phase intro, junk-tag guards |

## Chrome setup

1. `chrome://extensions` → remove other FAFO new-tab loads  
2. **Load unpacked** → this folder only  
3. Confirm version **7.2.0**  
4. Explorer tags: companion on `127.0.0.1:8765` (`explorer-meta\`)

## Do not edit / load

- `ZZ_DO_NOT_LOAD - old FAFO Local Media (deprecated)` — old 3.x cinema-only  
- Empty leftover `FAFO Ultimate Tab` under D:  
- Prefer this D: path over `C:\Users\rkey2\FAFO_Ultimate_Tab` so future edits land in one place  

## Backup

Pre-merge thin fork backup:  
`D:\Chrome python_HTML AI apps\ZZ_BACKUP_before_merge_from_6.4.6_*`
