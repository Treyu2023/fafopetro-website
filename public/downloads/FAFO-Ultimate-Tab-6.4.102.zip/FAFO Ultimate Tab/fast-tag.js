/**
 * FAFO Graffiti Speed Tagging — paged thumbnail grid.
 * Pick any number of tags from the public list (and private list when unlocked),
 * then click tiles to apply with no confirmation.
 * Create new tags in place. Right-click a chip to assign it to Public or Private.
 * Private mode lists private tags first, then public — lists are not bulk-copied.
 * Tag chips sort by this-session apply count, then overall count (public/private maps never mix).
 * Hover preview plays in the right rail (full frame, contain). Rail + Preview sliders and a drag split enlarge it.
 * Auto-play top row. Auto-scroll by row.
 * Drag / Ctrl / Shift multi-select: confirm before applying armed tags to a group.
 */
(function () {
    'use strict';

    const PREFS_KEY = 'fafoFastTagPrefs';
    const TECH_KEY = 'fafoFastTagTech';
    const TOOLBOX_API = 'http://127.0.0.1:8765/api';
    const RANK_COLORS = ['rank-1', 'rank-2', 'rank-3'];
    const PLACEHOLDER =
        'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NCIgaGVpZ2h0PSI2NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzE2MTYxNiIvPjwvc3ZnPg==';

    const FACETS = [
        {
            id: 'length',
            label: 'Length',
            options: [
                { id: 'under30', label: 'Under 30s' },
                { id: '30to60', label: '30s – 1 min' },
                { id: '1to3m', label: '1 – 3 min' },
                { id: '3to10m', label: '3 – 10 min' },
                { id: '10to30m', label: '10 – 30 min' },
                { id: 'over30m', label: '30+ min' },
                { id: 'unknown', label: 'Unknown' },
                { id: 'na', label: 'n/a (photos)' },
            ],
        },
        {
            id: 'fps',
            label: 'FPS',
            options: [
                { id: '24', label: '24' },
                { id: '25', label: '25' },
                { id: '30', label: '30' },
                { id: '48', label: '48' },
                { id: '50', label: '50' },
                { id: '60', label: '60' },
                { id: 'high', label: '90+' },
                { id: 'unknown', label: 'Unknown' },
                { id: 'na', label: 'n/a (photos)' },
            ],
        },
        {
            id: 'res',
            label: 'Resolution',
            options: [
                { id: '480p', label: '480p' },
                { id: '720p', label: '720p' },
                { id: '1080p', label: '1080p' },
                { id: '1440p', label: '1440p' },
                { id: '4k', label: '4K' },
                { id: '8k', label: '8K' },
                { id: 'other', label: 'Other' },
                { id: 'unknown', label: 'Unknown' },
            ],
        },
        {
            id: 'size',
            label: 'Size',
            options: [
                { id: 'lt50', label: 'Under 50 MB' },
                { id: '50to200', label: '50 – 200 MB' },
                { id: '200to500', label: '200 – 500 MB' },
                { id: '500to1g', label: '500 MB – 1 GB' },
                { id: 'over1g', label: '1 GB+' },
                { id: 'unknown', label: 'Unknown' },
            ],
        },
        {
            id: 'aspect',
            label: 'Aspect',
            options: [
                { id: '16x9', label: '16:9' },
                { id: '9x16', label: '9:16' },
                { id: '4x3', label: '4:3' },
                { id: '1x1', label: '1:1' },
                { id: 'other', label: 'Other' },
                { id: 'unknown', label: 'Unknown' },
            ],
        },
    ];

    const $ = (id) => document.getElementById(id);

    const state = {
        db: null,
        spaceKeys: null,
        publicKeys: null,
        privateKeys: null,
        privateActive: false,
        vaultId: 'default',
        vaultName: '',
        items: [],
        filtered: [],
        mediaMeta: {},
        publicTagLib: [],
        privateTagLib: [],
        applyCounts: {},
        publicApplyCounts: {},
        privateApplyCounts: {},
        sessionCounts: { public: {}, private: {} },
        lastUsed: {},
        armed: [],
        session: [], // { id, key, name, type, applied[], thumbUrl }
        libDirty: { public: false, private: false },
        prefs: {
            thumb: 168,
            hover: 400,
            sideW: 400,
            fit: 'contain',
            scroll: 4,
            pageSize: 50,
            thumbSeek: 1,
            autoScroll: true,
            autoPlay: true,
            rightClickRemove: true,
            untaggedOnly: false,
            type: 'all',
            filter: '',
            tagFilter: '',
            createDest: 'private',
            facets: { length: [], fps: [], res: [], size: [], aspect: [] },
        },
        tech: {},
        techDirty: false,
        techTimer: null,
        probeQueue: [],
        probing: false,
        persistTimer: null,
        explorerTimer: null,
        explorerQueue: [],
        scrollTimer: null,
        hoverItem: null,
        hoverHideTimer: null,
        urlCache: new Map(),
        fileCache: new Map(),
        visible: new Set(),
        playingRow: new Set(),
        dirtyMeta: false,
        sessionCount: 0,
        undoStack: [],
        selected: new Set(),
        lastAnchor: null,
        marquee: null,
        suppressClick: false,
        applyingBulk: false,
        page: 0,
        thumbBusy: 0,
        thumbQueue: [],
    };

    const THUMB_CONCURRENCY = 3;

    function toast(msg) {
        const el = $('ft-toast');
        if (!el) return;
        el.textContent = msg;
        el.classList.add('is-on');
        clearTimeout(toast._t);
        toast._t = setTimeout(() => el.classList.remove('is-on'), 1800);
    }

    function setStatus(msg) {
        const el = $('ft-status');
        if (el) el.textContent = msg;
    }

    function paintDiskPip(state, title) {
        const pip = $('fafo-disk-pip');
        if (!pip) return;
        pip.className = 'fafo-disk-pip ' + (state || 'unknown');
        pip.title = title || 'Disk tag server';
        pip.setAttribute('aria-label', pip.title);
        const word = pip.querySelector('.fafo-disk-pip-word');
        if (word) {
            word.textContent = ({
                online: 'On',
                offline: 'Off',
                busy: '…',
                unknown: 'Disk',
            })[state] || 'Disk';
        }
    }

    async function diskOnline() {
        try {
            const r = await fetch(TOOLBOX_API + '/health', { signal: AbortSignal.timeout(1500) });
            if (!r.ok) return false;
            const j = await r.json().catch(() => ({}));
            const svc = String((j && j.service) || '');
            if (svc && !/fafo/i.test(svc)) return false;
            return true;
        } catch {
            return false;
        }
    }

    async function refreshDiskPip() {
        const on = await diskOnline();
        paintDiskPip(
            on ? 'online' : 'offline',
            on
                ? 'Disk tag server ON. Click to recheck.'
                : 'Disk tag server OFF. Click to launch.'
        );
        return on;
    }

    async function launchDiskServer() {
        paintDiskPip('busy', 'Launching Disk tag server…');
        setStatus('Starting Disk tag server…');
        try {
            await chrome.runtime.sendMessage({ type: 'fafo-boot-stack', reason: 'graffiti-pip', force: true });
        } catch (_) {}
        const t0 = Date.now();
        while (Date.now() - t0 < 14000) {
            await new Promise((r) => setTimeout(r, 400));
            if (await diskOnline()) {
                paintDiskPip('online', 'Disk tag server ON.');
                setStatus('Disk tag server on');
                return true;
            }
        }
        paintDiskPip('offline', 'Disk tag server did not start. Click to retry.');
        setStatus('Disk server off — click Disk to retry');
        return false;
    }

    function normalizeTag(t) {
        if (window.FAFOId?.normalizeTag) return FAFOId.normalizeTag(t);
        return String(t || '').trim().replace(/\s+/g, ' ');
    }

    function userTags(list) {
        if (window.FAFOId?.userTagsOnly) return FAFOId.userTagsOnly(list);
        return (Array.isArray(list) ? list : []).map(normalizeTag).filter(Boolean);
    }

    function hasTag(lib, tag) {
        const low = String(tag || '').toLowerCase();
        return (lib || []).some((x) => String(x).toLowerCase() === low);
    }

    function defaultCreateDest() {
        if (!state.privateActive) return 'public';
        return state.prefs.createDest === 'public' ? 'public' : 'private';
    }

    function originOf(tag) {
        const t = normalizeTag(tag);
        const inPriv = state.privateActive && hasTag(state.privateTagLib, t);
        const inPub = hasTag(state.publicTagLib, t);
        if (inPriv && inPub) return 'both';
        if (inPriv) return 'private';
        if (inPub) return 'public';
        return null;
    }

    function addToList(tag, which) {
        const t = normalizeTag(tag);
        if (!t) return false;
        if (which === 'private' && !state.privateActive) return false;
        const lib = which === 'private' ? state.privateTagLib : state.publicTagLib;
        if (hasTag(lib, t)) return false;
        lib.unshift(t);
        state.libDirty[which] = true;
        return true;
    }

    function removeFromList(tag, which) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return false;
        const lib = which === 'private' ? state.privateTagLib : state.publicTagLib;
        const next = lib.filter((x) => x.toLowerCase() !== low);
        if (next.length === lib.length) return false;
        if (which === 'private') state.privateTagLib = next;
        else state.publicTagLib = next;
        state.libDirty[which] = true;
        return true;
    }

    function overallCount(tag, origin) {
        const map = origin === 'private' ? state.privateApplyCounts : state.publicApplyCounts;
        return Number(map[String(tag).toLowerCase()] || 0);
    }

    function sessionCount(tag, origin) {
        const map = state.sessionCounts[origin === 'private' ? 'private' : 'public'] || {};
        return Number(map[String(tag).toLowerCase()] || 0);
    }

    function sortLib(list, origin) {
        return list.slice().sort((a, b) => {
            const sa = sessionCount(a, origin);
            const sb = sessionCount(b, origin);
            if (sb !== sa) return sb - sa;
            const oa = overallCount(a, origin);
            const ob = overallCount(b, origin);
            if (ob !== oa) return ob - oa;
            return String(a).localeCompare(String(b), undefined, { sensitivity: 'base' });
        });
    }

    function mergeIntoLib(target, extra) {
        const map = new Map(target.map((t) => [String(t).toLowerCase(), t]));
        extra.forEach((t) => {
            const n = normalizeTag(t);
            if (!n) return;
            const low = n.toLowerCase();
            if (!map.has(low)) map.set(low, n);
        });
        return [...map.values()];
    }

    function readMenuScope(raw) {
        const out = {};
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return out;
        Object.keys(raw).forEach((key) => {
            const low = String(key || '').trim().toLowerCase();
            const v = raw[key];
            if (!low) return;
            if (v === 'hidden' || v === 'both') out[low] = v;
        });
        return out;
    }

    function scopeMap(origin) {
        return origin === 'private' ? (state.menuScopePrivate || {}) : (state.menuScopePublic || {});
    }

    /** Hidden-menu-only tags stay out of the normal Graffiti lists. Both still shows. */
    function scopeOf(name, origin) {
        const v = scopeMap(origin)[String(name || '').trim().toLowerCase()];
        return v === 'hidden' || v === 'both' ? v : 'public';
    }

    /** Picker rows: private first (private mode), then public. No bulk copy. */
    function pickerRows(query) {
        const q = query == null
            ? String(state.prefs.tagFilter || '').trim().toLowerCase()
            : String(query || '').trim().toLowerCase();
        const visible = (t, origin) => {
            if (q && !String(t).toLowerCase().includes(q)) return false;
            return scopeOf(t, origin) !== 'hidden';
        };
        const rows = [];
        if (state.privateActive) {
            const priv = sortLib(state.privateTagLib, 'private').filter((t) => visible(t, 'private'));
            const privLow = new Set(state.privateTagLib.map((t) => t.toLowerCase()));
            const pub = sortLib(state.publicTagLib, 'public').filter((t) => visible(t, 'public') && !privLow.has(t.toLowerCase()));
            if (priv.length) rows.push({ type: 'label', origin: 'private', text: `Private · ${priv.length}` });
            priv.forEach((t) => rows.push({ type: 'tag', origin: 'private', name: t }));
            if (pub.length) rows.push({ type: 'label', origin: 'public', text: `Public · ${pub.length}` });
            pub.forEach((t) => rows.push({ type: 'tag', origin: 'public', name: t }));
        } else {
            sortLib(state.publicTagLib, 'public').filter((t) => visible(t, 'public')).forEach((t) => {
                rows.push({ type: 'tag', origin: 'public', name: t });
            });
        }
        return rows;
    }

    function knownTagCount() {
        if (!state.privateActive) return state.publicTagLib.length;
        const set = new Set(state.privateTagLib.map((t) => t.toLowerCase()));
        state.publicTagLib.forEach((t) => set.add(t.toLowerCase()));
        return set.size;
    }

    function paintSpaceUi() {
        const el = $('ft-space');
        if (el) {
            if (state.privateActive) {
                el.textContent = state.vaultName ? `Private · ${state.vaultName}` : 'Private';
                el.classList.add('is-private');
                el.classList.remove('is-public');
            } else {
                el.textContent = 'Public';
                el.classList.add('is-public');
                el.classList.remove('is-private');
            }
        }
        const dest = $('ft-dest');
        if (dest) dest.hidden = !state.privateActive;
        const privBtn = $('ft-dest-private');
        const pubBtn = $('ft-dest-public');
        const d = defaultCreateDest();
        privBtn?.classList.toggle('is-on', d === 'private');
        pubBtn?.classList.toggle('is-on', d === 'public');
        const hint = $('ft-create-hint');
        if (hint) {
            hint.textContent = state.privateActive
                ? 'Private tags list first. Pick from either list — nothing is bulk-copied. Right-click a chip to assign it to Public or Private.'
                : 'Complete public list. Create a tag, or right-click a chip to assign it to Public or Private (Private only while unlocked).';
        }
    }

    function itemId(it) {
        return `${it.storeName}:${it.key}`;
    }

    function isVideo(it) {
        return it.type === 'video' || (window.FAFOLibrary?.VIDEO_RE || /\.(mp4|webm|mkv|mov|m4v|avi)$/i).test(it.name || '');
    }

    function techId(it) {
        return itemId(it);
    }

    function fpsFromName(name) {
        const s = String(name || '').toLowerCase();
        let m = s.match(/(\d{2,3})\s*fps\b/);
        if (m) return Number(m[1]);
        m = s.match(/(?:^|[^\d])(\d{3,4})p(\d{2,3})(?:\b|[^\d])/);
        if (m) return Number(m[2]);
        m = s.match(/(?:^|[^\d])(24|25|30|48|50|60|90|120)p(?:\b|[^\d])/);
        if (m) return Number(m[1]);
        return null;
    }

    function resFromName(name) {
        const s = String(name || '').toLowerCase();
        if (/(?:^|[^\d])(8k|4320p)(?:\b|[^\d])/.test(s)) return { width: 7680, height: 4320 };
        if (/(?:^|[^\d])(4k|2160p|uhd)(?:\b|[^\d])/.test(s)) return { width: 3840, height: 2160 };
        if (/(?:1440p|2560x1440|2k)(?:\b|[^\d])/.test(s)) return { width: 2560, height: 1440 };
        if (/(?:1080p|1920x1080|full\s?hd)(?:\b|[^\d])/.test(s)) return { width: 1920, height: 1080 };
        if (/(?:720p|1280x720)(?:\b|[^\d])/.test(s)) return { width: 1280, height: 720 };
        if (/(?:480p|854x480|640x480)(?:\b|[^\d])/.test(s)) return { width: 854, height: 480 };
        const dim = s.match(/(\d{3,4})\s*[x×]\s*(\d{3,4})/);
        if (dim) return { width: Number(dim[1]), height: Number(dim[2]) };
        return null;
    }

    function seedTech(it) {
        const id = techId(it);
        const prev = state.tech[id] || {};
        const named = resFromName(it.name);
        const fps = prev.fps || fpsFromName(it.name);
        state.tech[id] = {
            duration: prev.duration,
            width: prev.width || named?.width || 0,
            height: prev.height || named?.height || 0,
            fps: fps || 0,
            size: it.size || prev.size || 0,
            photo: !isVideo(it),
            fromName: !prev.width && !!named,
            probed: !!prev.probed,
        };
    }

    function rememberTech(it, info) {
        if (!it || !info) return;
        const id = techId(it);
        const prev = state.tech[id] || {};
        const next = {
            duration: Number.isFinite(info.duration) ? info.duration : prev.duration,
            width: info.width || prev.width || 0,
            height: info.height || prev.height || 0,
            fps: info.fps || prev.fps || fpsFromName(it.name) || 0,
            size: it.size || info.size || prev.size || 0,
            photo: !isVideo(it),
            probed: true,
            fromName: false,
        };
        state.tech[id] = next;
        state.techDirty = true;
        clearTimeout(state.techTimer);
        state.techTimer = setTimeout(flushTech, 400);
        renderFacetCounts();
    }

    async function loadTech() {
        try {
            const bag = await chrome.storage.local.get(TECH_KEY);
            const t = bag[TECH_KEY];
            if (t && typeof t === 'object') state.tech = t;
        } catch (_) {}
    }

    function flushTech() {
        if (!state.techDirty) return;
        state.techDirty = false;
        chrome.storage.local.set({ [TECH_KEY]: state.tech }).catch(() => {});
    }

    function lengthBucket(it) {
        if (!isVideo(it)) return 'na';
        const d = Number(state.tech[techId(it)]?.duration);
        if (!Number.isFinite(d) || d <= 0) return 'unknown';
        if (d < 30) return 'under30';
        if (d < 60) return '30to60';
        if (d < 180) return '1to3m';
        if (d < 600) return '3to10m';
        if (d < 1800) return '10to30m';
        return 'over30m';
    }

    function fpsBucket(it) {
        if (!isVideo(it)) return 'na';
        const n = Number(state.tech[techId(it)]?.fps);
        if (!Number.isFinite(n) || n <= 0) return 'unknown';
        const r = Math.round(n);
        if (r <= 24) return '24';
        if (r <= 26) return '25';
        if (r <= 32) return '30';
        if (r <= 49) return '48';
        if (r <= 51) return '50';
        if (r <= 70) return '60';
        return 'high';
    }

    function resBucket(it) {
        const t = state.tech[techId(it)] || {};
        const long = Math.max(Number(t.width) || 0, Number(t.height) || 0);
        if (long >= 7000) return '8k';
        if (long >= 3000) return '4k';
        if (long >= 2200) return '1440p';
        if (long >= 1600) return '1080p';
        if (long >= 1100) return '720p';
        if (long >= 600) return '480p';
        if (long > 0) return 'other';
        return 'unknown';
    }

    function sizeBucket(it) {
        const n = Number(it.size || state.tech[techId(it)]?.size || 0);
        if (!n) return 'unknown';
        const mb = n / (1024 * 1024);
        if (mb < 50) return 'lt50';
        if (mb < 200) return '50to200';
        if (mb < 500) return '200to500';
        if (mb < 1024) return '500to1g';
        return 'over1g';
    }

    function aspectBucket(it) {
        const t = state.tech[techId(it)] || {};
        const w = Number(t.width) || 0;
        const h = Number(t.height) || 0;
        if (w < 2 || h < 2) return 'unknown';
        const r = w / h;
        if (r > 1.6 && r < 1.9) return '16x9';
        if (r > 0.52 && r < 0.65) return '9x16';
        if (r > 1.25 && r < 1.45) return '4x3';
        if (r > 0.9 && r < 1.1) return '1x1';
        return 'other';
    }

    function bucketOf(it, facetId) {
        if (facetId === 'length') return lengthBucket(it);
        if (facetId === 'fps') return fpsBucket(it);
        if (facetId === 'res') return resBucket(it);
        if (facetId === 'size') return sizeBucket(it);
        if (facetId === 'aspect') return aspectBucket(it);
        return 'unknown';
    }

    function selectedFacet(id) {
        const arr = state.prefs.facets?.[id];
        return Array.isArray(arr) ? arr : [];
    }

    function matchesFacets(it, skipId) {
        return FACETS.every((f) => {
            if (skipId && f.id === skipId) return true;
            const sel = selectedFacet(f.id);
            if (!sel.length) return true;
            return sel.includes(bucketOf(it, f.id));
        });
    }

    function basePass(it) {
        const q = String(state.prefs.filter || '').trim().toLowerCase();
        const type = state.prefs.type || 'all';
        if (type !== 'all' && it.type !== type) return false;
        if (q && !String(it.name || '').toLowerCase().includes(q)) return false;
        if (state.prefs.untaggedOnly && tagsOnItem(it).length) return false;
        return true;
    }

    function facetCounts(facetId) {
        const counts = {};
        state.items.forEach((it) => {
            if (!basePass(it)) return;
            if (!matchesFacets(it, facetId)) return;
            const b = bucketOf(it, facetId);
            counts[b] = (counts[b] || 0) + 1;
        });
        return counts;
    }

    function renderFacetMenus() {
        const host = $('ft-facets');
        if (!host) return;
        host.innerHTML = '';
        FACETS.forEach((f) => {
            const wrap = document.createElement('div');
            wrap.className = 'ft-dd';
            wrap.dataset.facet = f.id;
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'ft-dd-btn';
            btn.innerHTML = `${f.label} <b data-role="badge"></b>`;
            const menu = document.createElement('div');
            menu.className = 'ft-dd-menu';
            menu.hidden = true;
            f.options.forEach((opt) => {
                const lab = document.createElement('label');
                lab.dataset.opt = opt.id;
                const ck = document.createElement('input');
                ck.type = 'checkbox';
                ck.value = opt.id;
                ck.checked = selectedFacet(f.id).includes(opt.id);
                ck.addEventListener('change', () => {
                    const cur = new Set(selectedFacet(f.id));
                    if (ck.checked) cur.add(opt.id);
                    else cur.delete(opt.id);
                    state.prefs.facets[f.id] = [...cur];
                    savePrefs();
                    applyFilter(true);
                });
                const name = document.createElement('span');
                name.textContent = opt.label;
                const n = document.createElement('span');
                n.className = 'ft-dd-n';
                n.textContent = '0';
                lab.appendChild(ck);
                lab.appendChild(name);
                lab.appendChild(n);
                menu.appendChild(lab);
            });
            const clear = document.createElement('button');
            clear.type = 'button';
            clear.className = 'ft-dd-clear';
            clear.textContent = 'Clear';
            clear.addEventListener('click', (e) => {
                e.stopPropagation();
                state.prefs.facets[f.id] = [];
                savePrefs();
                menu.querySelectorAll('input').forEach((i) => { i.checked = false; });
                applyFilter(true);
            });
            menu.appendChild(clear);
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const open = !menu.hidden;
                closeFacetMenus();
                menu.hidden = open;
                wrap.classList.toggle('is-open', !open);
            });
            wrap.appendChild(btn);
            wrap.appendChild(menu);
            host.appendChild(wrap);
        });
        const scan = document.createElement('button');
        scan.type = 'button';
        scan.className = 'ft-btn';
        scan.id = 'ft-scan-tech';
        scan.textContent = 'Scan length / res';
        scan.addEventListener('click', () => queueTechScan(true));
        host.appendChild(scan);
        renderFacetCounts();
    }

    function closeFacetMenus() {
        document.querySelectorAll('.ft-dd-menu').forEach((m) => { m.hidden = true; });
        document.querySelectorAll('.ft-dd').forEach((d) => d.classList.remove('is-open'));
    }

    function renderFacetCounts() {
        FACETS.forEach((f) => {
            const wrap = document.querySelector(`.ft-dd[data-facet="${f.id}"]`);
            if (!wrap) return;
            const counts = facetCounts(f.id);
            const sel = selectedFacet(f.id);
            wrap.querySelectorAll('label[data-opt]').forEach((lab) => {
                const id = lab.dataset.opt;
                const n = lab.querySelector('.ft-dd-n');
                if (n) n.textContent = String(counts[id] || 0);
            });
            const badge = wrap.querySelector('[data-role="badge"]');
            if (badge) {
                badge.textContent = sel.length ? String(sel.length) : '';
                wrap.classList.toggle('has-sel', sel.length > 0);
            }
        });
        const scan = $('ft-scan-tech');
        if (scan && !state.probing) {
            const need = state.items.filter((it) => isVideo(it) && !state.tech[techId(it)]?.probed).length;
            scan.textContent = need ? `Scan length / res · ${need}` : 'Scan length / res';
        }
    }

    function queueTechScan(all) {
        const list = (all ? state.items : state.filtered).filter((it) => {
            const t = state.tech[techId(it)];
            return !t?.probed;
        });
        list.forEach((it) => {
            if (!state.probeQueue.some((x) => techId(x) === techId(it))) state.probeQueue.push(it);
        });
        runProbeQueue(!!all);
    }

    async function runProbeQueue(announce) {
        if (state.probing) {
            state._probeAnnounce = state._probeAnnounce || !!announce;
            return;
        }
        state.probing = true;
        const wantAnnounce = !!announce || !!state._probeAnnounce;
        state._probeAnnounce = false;
        const scan = $('ft-scan-tech');
        while (state.probeQueue.length) {
            const it = state.probeQueue.shift();
            if (scan) scan.textContent = `Scanning… ${state.probeQueue.length} left`;
            try {
                await probeItem(it);
            } catch (_) {}
        }
        state.probing = false;
        flushTech();
        applyFilter(false);
        renderFacetCounts();
        if (wantAnnounce) toast('Length / resolution scan done');
    }

    async function probeItem(it) {
        const file = await getFileFor(it);
        if (!file) return;
        if (!isVideo(it)) {
            await new Promise((resolve) => {
                const img = new Image();
                const url = URL.createObjectURL(file);
                img.onload = () => {
                    rememberTech(it, { width: img.naturalWidth, height: img.naturalHeight, duration: 0, size: file.size });
                    URL.revokeObjectURL(url);
                    resolve();
                };
                img.onerror = () => {
                    URL.revokeObjectURL(url);
                    rememberTech(it, { size: file.size });
                    resolve();
                };
                img.src = url;
                setTimeout(resolve, 2500);
            });
            return;
        }
        await new Promise((resolve) => {
            const video = document.createElement('video');
            video.muted = true;
            video.preload = 'metadata';
            video.playsInline = true;
            let url;
            try { url = URL.createObjectURL(file); } catch { resolve(); return; }
            let done = false;
            const finish = () => {
                if (done) return;
                done = true;
                rememberTech(it, {
                    duration: Number(video.duration) || 0,
                    width: video.videoWidth || 0,
                    height: video.videoHeight || 0,
                    fps: fpsFromName(it.name) || 0,
                    size: file.size,
                });
                try { URL.revokeObjectURL(url); } catch (_) {}
                try { video.removeAttribute('src'); video.load(); } catch (_) {}
                resolve();
            };
            video.addEventListener('loadedmetadata', finish, { once: true });
            video.addEventListener('error', finish, { once: true });
            setTimeout(finish, 4000);
            video.src = url;
        });
    }

    async function loadPrefs() {
        try {
            const bag = await chrome.storage.local.get(PREFS_KEY);
            const p = bag[PREFS_KEY];
            if (p && typeof p === 'object') {
                const facets = { ...state.prefs.facets, ...(p.facets || {}) };
                Object.assign(state.prefs, p);
                state.prefs.facets = {
                    length: Array.isArray(facets.length) ? facets.length : [],
                    fps: Array.isArray(facets.fps) ? facets.fps : [],
                    res: Array.isArray(facets.res) ? facets.res : [],
                    size: Array.isArray(facets.size) ? facets.size : [],
                    aspect: Array.isArray(facets.aspect) ? facets.aspect : [],
                };
                if (![30, 50, 100, 200, 300, 500].includes(Number(state.prefs.pageSize))) {
                    state.prefs.pageSize = 50;
                }
                const seekN = Number(state.prefs.thumbSeek);
                state.prefs.thumbSeek = Number.isFinite(seekN) ? Math.max(0, Math.min(15, seekN)) : 1;
                state.prefs.thumb = clampNum(state.prefs.thumb, 96, 720, 168);
                state.prefs.hover = clampNum(state.prefs.hover, 240, 900, 400);
                state.prefs.sideW = clampNum(state.prefs.sideW || state.prefs.hover, 240, 900, state.prefs.hover);
                state.prefs.fit = state.prefs.fit === 'cover' ? 'cover' : 'contain';
            }
        } catch (_) {}
        applyPrefsToUi();
    }

    function clampNum(n, lo, hi, fallback) {
        n = Number(n);
        if (!Number.isFinite(n)) return fallback;
        return Math.max(lo, Math.min(hi, n));
    }

    function savePrefs() {
        chrome.storage.local.set({ [PREFS_KEY]: { ...state.prefs } }).catch(() => {});
    }

    function applyPrefsToUi() {
        const p = state.prefs;
        const thumb = $('ft-thumb');
        const hover = $('ft-hover-size');
        const scroll = $('ft-scroll');
        if (thumb) thumb.value = String(p.thumb);
        if (hover) hover.value = String(p.hover);
        if (scroll) scroll.value = String(p.scroll);
        $('ft-thumb-val').textContent = `${p.thumb}px`;
        $('ft-hover-val').textContent = `${p.hover}px`;
        $('ft-scroll-val').textContent = `${Number(p.scroll).toFixed(1)}s`;
        const seek = $('ft-thumb-seek');
        if (seek) seek.value = String(thumbSeekSec());
        const seekVal = $('ft-thumb-seek-val');
        if (seekVal) seekVal.textContent = `${thumbSeekSec().toFixed(1)}s`;
        const pageSel = $('ft-page-size');
        if (pageSel) pageSel.value = String(pageSize());
        document.documentElement.style.setProperty('--ft-thumb', `${p.thumb}px`);
        applyLayoutVars();
        $('ft-auto-scroll')?.classList.toggle('is-on', !!p.autoScroll);
        $('ft-auto-play')?.classList.toggle('is-on', !!p.autoPlay);
        $('ft-right-click')?.classList.toggle('is-on', !!p.rightClickRemove);
        $('ft-untagged')?.classList.toggle('is-on', !!p.untaggedOnly);
        const type = $('ft-type');
        if (type) type.value = p.type || 'all';
        const filter = $('ft-filter');
        if (filter && p.filter) filter.value = p.filter;
        const tf = $('ft-tag-filter');
        if (tf && p.tagFilter) tf.value = p.tagFilter;
        syncFitBtn();
    }

    function applyLayoutVars() {
        const p = state.prefs;
        const max = Math.min(900, Math.round(window.innerWidth * 0.75) || 900);
        p.hover = clampNum(p.hover, 240, max, 400);
        p.sideW = clampNum(p.hover, 240, max, p.hover);
        document.documentElement.style.setProperty('--ft-thumb', `${p.thumb}px`);
        document.documentElement.style.setProperty('--ft-hover', `${p.hover}px`);
        document.documentElement.style.setProperty('--ft-side-w', `${p.sideW}px`);
        document.documentElement.style.setProperty('--ft-fit', p.fit === 'cover' ? 'cover' : 'contain');
        document.documentElement.setAttribute('data-ft-fit', p.fit === 'cover' ? 'cover' : 'contain');
        const hover = $('ft-hover-size');
        if (hover) hover.value = String(p.hover);
        if ($('ft-hover-val')) $('ft-hover-val').textContent = `${p.hover}px`;
    }

    function syncFitBtn() {
        const btn = $('ft-fit');
        if (!btn) return;
        const contain = state.prefs.fit !== 'cover';
        btn.textContent = contain ? 'Fit: contain' : 'Fit: cover';
        btn.classList.toggle('is-on', contain);
        btn.title = contain
            ? 'Showing the whole frame. Click for cover (fill + crop).'
            : 'Filling the box (cropped). Click for contain (whole frame).';
    }

    async function resolveSpace() {
        let privateActive = false;
        let vaultId = 'default';
        let vaultName = '';
        try {
            const { fafoPrivateSession } = await chrome.storage.local.get('fafoPrivateSession');
            privateActive = !!(fafoPrivateSession && fafoPrivateSession.active && fafoPrivateSession.unlocked);
            vaultId = fafoPrivateSession?.vaultId || 'default';
            vaultName = String(fafoPrivateSession?.vaultName || '');
        } catch (_) {}
        state.privateActive = privateActive;
        state.vaultId = vaultId;
        state.vaultName = vaultName;
        const PV = window.FAFOPrivateVaults;
        state.publicKeys = PV?.publicStorageKeys?.() || {
            mediaMeta: 'fafoMediaMeta',
            tagLibrary: 'fafoTagLibrary',
            applyCounts: 'fafoTagApplyCounts',
            tagLastUsed: 'fafoTagLastUsed',
            tagDb: 'fafoTagDb',
            tagMenuScope: 'fafoTagMenuScope',
        };
        state.privateKeys = PV?.privateStorageKeys?.(vaultId) || {
            mediaMeta: 'fafoMediaMetaPrivate',
            tagLibrary: 'fafoTagLibraryPrivate',
            applyCounts: 'fafoTagApplyCountsPrivate',
            tagLastUsed: 'fafoTagLastUsedPrivate',
            tagDb: 'fafoTagDbPrivate',
            tagMenuScope: 'fafoTagMenuScopePrivate',
        };
        if (PV?.spaceStorageKeys) {
            state.spaceKeys = PV.spaceStorageKeys(privateActive, vaultId);
        } else {
            state.spaceKeys = privateActive ? state.privateKeys : state.publicKeys;
        }
        paintSpaceUi();
    }

    async function hydrateLibFromBag(bag, keys) {
        let lib = Array.isArray(bag[keys.tagLibrary]) ? bag[keys.tagLibrary].slice() : [];
        if (window.FAFOTagDb?.load && keys.tagDb) {
            try {
                const db = await FAFOTagDb.load(keys.tagDb);
                if (db?.tags?.length) lib = mergeIntoLib(lib, db.tags);
            } catch (_) {}
        }
        return userTags(lib.map(normalizeTag));
    }

    async function loadMetaAndTags() {
        const k = state.spaceKeys;
        const pub = state.publicKeys;
        const priv = state.privateKeys;
        const want = [k.mediaMeta, k.applyCounts, k.tagLastUsed, pub.tagLibrary, pub.applyCounts];
        if (pub.tagMenuScope) want.push(pub.tagMenuScope);
        if (state.privateActive && priv.tagMenuScope) want.push(priv.tagMenuScope);
        if (pub.tagDb) want.push(pub.tagDb);
        if (state.privateActive) {
            want.push(priv.tagLibrary, priv.applyCounts);
            if (priv.tagDb) want.push(priv.tagDb);
        }
        const bag = await chrome.storage.local.get(want);
        state.mediaMeta = bag[k.mediaMeta] && typeof bag[k.mediaMeta] === 'object' ? bag[k.mediaMeta] : {};
        state.publicApplyCounts = bag[pub.applyCounts] && typeof bag[pub.applyCounts] === 'object' ? { ...bag[pub.applyCounts] } : {};
        state.privateApplyCounts = state.privateActive && bag[priv.applyCounts] && typeof bag[priv.applyCounts] === 'object'
            ? { ...bag[priv.applyCounts] }
            : {};
        state.applyCounts = state.privateActive ? state.privateApplyCounts : state.publicApplyCounts;
        state.lastUsed = bag[k.tagLastUsed] && typeof bag[k.tagLastUsed] === 'object' ? { ...bag[k.tagLastUsed] } : {};
        state.sessionCounts = { public: {}, private: {} };

        if (window.FAFOTagDb?.load) {
            try {
                const db = await FAFOTagDb.load(k.tagDb);
                if (db.applyCounts) {
                    if (state.privateActive) {
                        state.privateApplyCounts = { ...db.applyCounts, ...state.privateApplyCounts };
                    } else {
                        state.publicApplyCounts = { ...db.applyCounts, ...state.publicApplyCounts };
                    }
                    state.applyCounts = state.privateActive ? state.privateApplyCounts : state.publicApplyCounts;
                }
                if (db.lastUsed) state.lastUsed = { ...db.lastUsed, ...state.lastUsed };
            } catch (_) {}
        }

        state.menuScopePublic = readMenuScope(bag[pub.tagMenuScope]);
        state.menuScopePrivate = state.privateActive ? readMenuScope(bag[priv.tagMenuScope]) : {};
        state.publicTagLib = await hydrateLibFromBag(bag, pub);
        state.privateTagLib = state.privateActive ? await hydrateLibFromBag(bag, priv) : [];

        // Harvest tags already on THIS space's files into THIS space's list only.
        const fromFiles = [];
        Object.values(state.mediaMeta).forEach((m) => {
            userTags(m?.tags).forEach((t) => fromFiles.push(t));
        });
        if (state.privateActive) {
            state.privateTagLib = mergeIntoLib(state.privateTagLib, fromFiles);
        } else {
            state.publicTagLib = mergeIntoLib(state.publicTagLib, fromFiles);
        }
        state.libDirty.public = false;
        state.libDirty.private = false;
        renderChips();
    }

    function metaForItem(it) {
        const key = it.mediaKey;
        if (key && state.mediaMeta[key]) return { key, meta: state.mediaMeta[key] };
        if (window.FAFOId?.findStoredMeta) {
            const hit = FAFOId.findStoredMeta(state.mediaMeta, {
                key,
                name: it.name,
                size: it.size,
            });
            if (hit) return hit;
        }
        const low = String(it.name || '').toLowerCase();
        const hits = Object.entries(state.mediaMeta).filter(([, m]) => m && String(m.name || '').toLowerCase() === low);
        if (hits.length === 1) return { key: hits[0][0], meta: hits[0][1] };
        return { key: key || null, meta: null };
    }

    function tagsOnItem(it) {
        return userTags(metaForItem(it).meta?.tags);
    }

    function hasArmedTags(it) {
        const have = new Set(tagsOnItem(it).map((t) => t.toLowerCase()));
        return state.armed.some((t) => have.has(t.toLowerCase()));
    }

    async function loadLibrary() {
        state.db = await FAFOLibrary.openDB();
        const space = state.privateActive ? 'private' : 'public';
        const opts = { vaultId: state.vaultId };
        const [videos, photos] = await Promise.all([
            FAFOLibrary.getMediaForSpace(state.db, 'videos', space, opts),
            FAFOLibrary.getMediaForSpace(state.db, 'photos', space, opts),
        ]);
        const items = [];
        videos.forEach((v) => {
            items.push({
                storeName: 'videos',
                key: v.key,
                handle: v.handle,
                name: v.name || 'video',
                size: v.size,
                lastModified: v.lastModified,
                type: 'video',
                mediaKey: null,
            });
        });
        photos.forEach((p) => {
            items.push({
                storeName: 'photos',
                key: p.key,
                handle: p.handle,
                name: p.name || 'photo',
                size: p.size,
                lastModified: p.lastModified,
                type: 'photo',
                mediaKey: null,
            });
        });
        items.sort((a, b) => String(a.name).localeCompare(String(b.name), undefined, { sensitivity: 'base' }));
        items.forEach(seedTech);
        state.items = items;
        await checkAccessBanner();
        applyFilter();
    }

    async function checkAccessBanner() {
        const banner = $('ft-banner');
        if (!state.db || !FAFOLibrary.libraryAccessStatus) {
            banner?.classList.remove('is-on');
            return;
        }
        try {
            const st = await FAFOLibrary.libraryAccessStatus(state.db);
            const need = !!(st && st.needsRestore);
            banner?.classList.toggle('is-on', need);
        } catch (_) {
            banner?.classList.remove('is-on');
        }
    }

    async function restoreAccess() {
        if (!state.db) return;
        setStatus('Requesting folder access…');
        try {
            const r = await FAFOLibrary.restoreAccess(state.db);
            toast(`Access restored · ${r.grantedFolders || 0} folders`);
            state.fileCache.clear();
            revokeAllUrls();
            await checkAccessBanner();
            applyFilter(true);
        } catch (e) {
            toast('Restore failed — click again');
            console.warn('Graffiti restore', e);
        }
    }

    function applyFilter(rebuild) {
        state.filtered = state.items.filter((it) => basePass(it) && matchesFacets(it));
        const maxPage = Math.max(0, Math.ceil(state.filtered.length / pageSize()) - 1);
        if (state.page > maxPage) state.page = maxPage;
        if (rebuild === true) {
            state.page = 0;
            renderGrid(true);
        } else renderGrid();
        pruneSelection();
        updateStatus();
        renderFacetCounts();
        scheduleRowPlay();
    }

    function updateStatus() {
        const n = state.filtered.length;
        const armed = state.armed.length;
        const tagged = state.session.length;
        const picked = state.selected.size;
        setStatus(picked
            ? `${n} tiles · ${picked} selected · ${armed} tag${armed === 1 ? '' : 's'} armed`
            : `${n} tiles · ${armed} tag${armed === 1 ? '' : 's'} armed · ${tagged} this pass`);
        const ac = $('ft-armed-count');
        if (ac) ac.textContent = String(armed);
        const sc = $('ft-side-count');
        if (sc) sc.textContent = String(tagged);
        $('ft-undo').disabled = state.undoStack.length === 0;
        paintSelBar();
    }

    function selectedItems() {
        return state.filtered.filter((it) => state.selected.has(itemId(it)));
    }

    function pruneSelection() {
        if (!state.selected.size) return;
        const live = new Set(state.filtered.map(itemId));
        [...state.selected].forEach((id) => {
            if (!live.has(id)) state.selected.delete(id);
        });
        if (state.lastAnchor && !state.selected.has(state.lastAnchor)) state.lastAnchor = null;
        paintPicked();
    }

    function paintPicked() {
        document.querySelectorAll('.ft-tile').forEach((el) => {
            el.classList.toggle('is-picked', state.selected.has(el.dataset.id));
        });
    }

    function setSelection(ids, anchor) {
        state.selected = new Set(ids);
        if (anchor) state.lastAnchor = anchor;
        paintPicked();
        updateStatus();
    }

    function toggleSelected(id) {
        if (state.selected.has(id)) state.selected.delete(id);
        else state.selected.add(id);
        state.lastAnchor = id;
        paintPicked();
        updateStatus();
    }

    function rangeSelect(id, additive) {
        const ids = state.filtered.map(itemId);
        const end = ids.indexOf(id);
        if (end < 0) return;
        const start = ids.indexOf(state.lastAnchor);
        const from = start >= 0 ? start : end;
        const a = Math.min(from, end);
        const b = Math.max(from, end);
        const next = additive ? new Set(state.selected) : new Set();
        for (let i = a; i <= b; i++) next.add(ids[i]);
        state.selected = next;
        paintPicked();
        updateStatus();
    }

    function clearSelection() {
        state.selected.clear();
        state.lastAnchor = null;
        paintPicked();
        hideConfirm();
        updateStatus();
    }

    function paintSelBar() {
        const bar = $('ft-selbar');
        if (!bar) return;
        const n = state.selected.size;
        bar.hidden = n === 0;
        if (!n) return;
        const armed = state.armed.length;
        $('ft-sel-count').textContent = `${n} selected`;
        const apply = $('ft-sel-apply');
        if (apply) {
            apply.disabled = armed === 0 || state.applyingBulk;
            apply.textContent = armed
                ? `Apply ${armed} tag${armed === 1 ? '' : 's'} to ${n}`
                : 'Arm tags, then apply';
        }
        const skip = $('ft-sel-skip');
        if (skip) skip.disabled = armed === 0;
        const rem = $('ft-sel-remove');
        if (rem) rem.disabled = armed === 0 || state.applyingBulk;
        document.body.style.setProperty('--ft-selbar-pad', n ? '56px' : '0px');
    }

    function hideConfirm() {
        const el = $('ft-confirm');
        if (el) el.hidden = true;
    }

    function showConfirmApply() {
        if (!state.selected.size || !state.armed.length) return false;
        const el = $('ft-confirm');
        if (!el) return false;
        const n = state.selected.size;
        const tags = state.armed.slice();
        $('ft-confirm-title').textContent = `Apply ${tags.length} tag${tags.length === 1 ? '' : 's'} to ${n} file${n === 1 ? '' : 's'}?`;
        const box = $('ft-confirm-tags');
        box.innerHTML = '';
        tags.forEach((t) => {
            const s = document.createElement('span');
            s.className = 'ft-chip is-on';
            s.textContent = t;
            box.appendChild(s);
        });
        el.hidden = false;
        return true;
    }

    function declineApply() {
        hideConfirm();
        if (!state.armed.length) return;
        state.armed = [];
        renderChips();
        updateStatus();
        toast('Tags cleared · files still selected');
    }

    function maybePromptApply() {
        if (state.selected.size < 2 || !state.armed.length) return;
        showConfirmApply();
    }

    async function applyToSelection(opts = {}) {
        const items = selectedItems();
        const tags = (opts.tags || state.armed).map(normalizeTag).filter(Boolean);
        if (!items.length || !tags.length) {
            toast(tags.length ? 'Nothing selected' : 'Arm tags first');
            return;
        }
        hideConfirm();
        state.applyingBulk = true;
        paintSelBar();
        const mark = state.undoStack.length;
        let ok = 0;
        for (const it of items) {
            await applyToItem(it, tileEl(it), { remove: !!opts.remove, tags });
            ok += 1;
        }
        const slice = state.undoStack.splice(mark);
        if (slice.length) {
            state.undoStack.push({ bulk: true, items: slice });
            if (state.undoStack.length > 80) state.undoStack.shift();
        }
        state.applyingBulk = false;
        paintPicked();
        updateStatus();
        toast(opts.remove
            ? `Removed tags from ${ok} file${ok === 1 ? '' : 's'}`
            : `Applied to ${ok} file${ok === 1 ? '' : 's'} · group still selected`);
    }

    function renderChips() {
        const wrap = $('ft-chips');
        if (!wrap) return;
        const armedLow = new Set(state.armed.map((t) => t.toLowerCase()));
        const rows = pickerRows();
        wrap.innerHTML = '';
        if (!rows.length) {
            const empty = document.createElement('div');
            empty.className = 'ft-chip-empty';
            empty.textContent = knownTagCount()
                ? 'No tags match that filter.'
                : 'No tags yet — type one above and hit Create & arm.';
            wrap.appendChild(empty);
            return;
        }
        let tags = 0;
        rows.forEach((row) => {
            if (row.type === 'label') {
                const lab = document.createElement('div');
                lab.className = 'ft-chip-label is-' + row.origin;
                lab.textContent = row.text;
                wrap.appendChild(lab);
                return;
            }
            if (tags >= 500) return;
            tags += 1;
            const chip = document.createElement('button');
            chip.type = 'button';
            chip.className = 'ft-chip is-' + row.origin + (armedLow.has(row.name.toLowerCase()) ? ' is-on' : '');
            const sess = sessionCount(row.name, row.origin);
            const all = overallCount(row.name, row.origin);
            chip.textContent = row.name;
            if (sess || all) {
                const n = document.createElement('span');
                n.className = 'ft-chip-count';
                n.textContent = sess ? `· ${sess}` : `· ${all}`;
                chip.appendChild(n);
            }
            chip.title = row.origin === 'private'
                ? `${row.name} · private · session ${sess} · overall ${all}`
                : `${row.name} · public · session ${sess} · overall ${all}`;
            chip.addEventListener('click', () => armTag(row.name, !armedLow.has(row.name.toLowerCase())));
            chip.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                e.stopPropagation();
                showChipMenu(e, row.name, row.origin);
            });
            wrap.appendChild(chip);
        });
    }

    function armTag(tag, on) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        state.armed = state.armed.filter((x) => x.toLowerCase() !== low);
        if (on) state.armed.push(t);
        renderChips();
        updateStatus();
    }

    function createAndArm(raw, dest) {
        const t = normalizeTag(raw);
        if (!t) {
            toast('Type a tag name first');
            return;
        }
        if (window.FAFOId?.isOversizedOrSuspectTag?.(t)) {
            toast('That tag looks like junk metadata — skipped');
            return;
        }
        const which = dest || defaultCreateDest();
        addToList(t, which);
        armTag(t, true);
        schedulePersist();
        toast(`Armed “${t}” on the ${which} list`);
    }

    function hideCtx() {
        const el = $('ft-ctx');
        if (!el) return;
        el.hidden = true;
        el.innerHTML = '';
    }

    function placeCtx(el, x, y) {
        el.hidden = false;
        const pad = 8;
        const w = el.offsetWidth || 260;
        const h = el.offsetHeight || 200;
        const left = Math.min(Math.max(pad, x), window.innerWidth - w - pad);
        const top = Math.min(Math.max(pad, y), window.innerHeight - h - pad);
        el.style.left = `${left}px`;
        el.style.top = `${top}px`;
    }

    function ctxHead(text) {
        const h = document.createElement('div');
        h.className = 'ft-ctx-head';
        h.textContent = text;
        return h;
    }

    function ctxItem(label, onClick, extraClass) {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'ft-ctx-item' + (extraClass ? ' ' + extraClass : '');
        b.textContent = label;
        b.addEventListener('click', (e) => {
            e.preventDefault();
            hideCtx();
            onClick();
        });
        return b;
    }

    function showChipMenu(e, tag, origin) {
        const el = $('ft-ctx');
        if (!el) return;
        el.innerHTML = '';
        el.appendChild(ctxHead(tag));
        const onPriv = origin === 'private' || origin === 'both' || hasTag(state.privateTagLib, tag);
        const onPub = origin === 'public' || origin === 'both' || hasTag(state.publicTagLib, tag);
        if (state.privateActive) {
            if (onPriv) {
                el.appendChild(ctxItem('On Private list — remove', () => {
                    removeFromList(tag, 'private');
                    renderChips();
                    schedulePersist();
                    toast(`Removed “${tag}” from Private`);
                }, 'is-private'));
            } else {
                el.appendChild(ctxItem('Assign to Private list', () => {
                    addToList(tag, 'private');
                    renderChips();
                    schedulePersist();
                    toast(`“${tag}” → Private list`);
                }, 'is-private'));
            }
        }
        if (onPub) {
            el.appendChild(ctxItem('On Public list — remove', () => {
                removeFromList(tag, 'public');
                renderChips();
                schedulePersist();
                toast(`Removed “${tag}” from Public`);
            }));
        } else {
            el.appendChild(ctxItem('Assign to Public list', () => {
                addToList(tag, 'public');
                renderChips();
                schedulePersist();
                toast(`“${tag}” → Public list`);
            }));
        }
        const sep = document.createElement('div');
        sep.className = 'ft-ctx-sep';
        el.appendChild(sep);
        const armed = state.armed.some((t) => t.toLowerCase() === tag.toLowerCase());
        el.appendChild(ctxItem(armed ? 'Disarm this tag' : 'Arm this tag', () => armTag(tag, !armed)));
        placeCtx(el, e.clientX, e.clientY);
    }

    function showTileMenu(e, it, tile) {
        const el = $('ft-ctx');
        if (!el) return;
        el.innerHTML = '';
        el.appendChild(ctxHead(it.name || 'file'));
        if (state.armed.length) {
            el.appendChild(ctxItem(`Apply ${state.armed.length} armed tag${state.armed.length === 1 ? '' : 's'}`, () => {
                applyToItem(it, tile, { remove: false });
            }, 'is-on'));
            el.appendChild(ctxItem('Remove armed tags', () => {
                applyToItem(it, tile, { remove: true });
            }, 'is-danger'));
        }
        const sep = document.createElement('div');
        sep.className = 'ft-ctx-sep';
        el.appendChild(sep);
        el.appendChild(ctxHead('Assign any tag'));
        const search = document.createElement('input');
        search.className = 'ft-ctx-search';
        search.type = 'search';
        search.placeholder = 'Filter tags…';
        search.autocomplete = 'off';
        el.appendChild(search);

        const listWrap = document.createElement('div');
        el.appendChild(listWrap);

        const paintList = () => {
            listWrap.innerHTML = '';
            const q = search.value.trim().toLowerCase();
            const pruned = pickerRows(q);
            if (!pruned.some((r) => r.type === 'tag')) {
                const empty = document.createElement('div');
                empty.className = 'ft-ctx-empty';
                empty.textContent = knownTagCount() ? 'No tags match.' : 'No tags yet — create one above.';
                listWrap.appendChild(empty);
                return;
            }
            pruned.slice(0, 80).forEach((r) => {
                if (r.type === 'label') {
                    const h = document.createElement('div');
                    h.className = 'ft-ctx-head';
                    h.textContent = r.text;
                    listWrap.appendChild(h);
                    return;
                }
                const onFile = tagsOnItem(it).some((t) => t.toLowerCase() === r.name.toLowerCase());
                const cls = [r.origin === 'private' ? 'is-private' : '', onFile ? 'is-on' : ''].filter(Boolean).join(' ');
                listWrap.appendChild(ctxItem(
                    (onFile ? '✓ ' : '') + r.name,
                    () => applySingleTag(it, tile, r.name, onFile),
                    cls
                ));
            });
        };
        search.addEventListener('input', paintList);
        paintList();
        placeCtx(el, e.clientX, e.clientY);
        setTimeout(() => search.focus(), 0);
    }

    function applySingleTag(it, tile, tag, already) {
        applyToItem(it, tile, { remove: !!already, tags: [tag] });
    }

    function renderGrid() {
        const grid = $('ft-grid');
        if (!grid) return;
        state.thumbQueue = [];
        hideHover();
        grid.innerHTML = '';
        stopAllInlineVideo();
        if (!state.filtered.length) {
            const empty = document.createElement('div');
            empty.className = 'ft-empty';
            empty.innerHTML = state.items.length
                ? 'No files match this filter.'
                : 'Library is empty. Open Options → Visual Library, link a folder, then Restore Access.';
            grid.appendChild(empty);
            return;
        }
        const frag = document.createDocumentFragment();
        pagedItems().forEach((it) => {
            frag.appendChild(buildTile(it));
        });
        grid.appendChild(frag);
        observeTiles();
        paintTaggedState();
        paintPicked();
        updatePager();
    }

    function pageSize() {
        const n = Number(state.prefs.pageSize) || 50;
        return [30, 50, 100, 200, 300, 500].includes(n) ? n : 50;
    }

    function pagedItems() {
        const n = pageSize();
        const start = Math.max(0, state.page) * n;
        return state.filtered.slice(start, start + n);
    }

    function updatePager() {
        const info = $('ft-page-info');
        const total = state.filtered.length;
        const n = pageSize();
        const start = total ? state.page * n + 1 : 0;
        const end = Math.min(total, (state.page + 1) * n);
        if (info) info.textContent = total ? `${start}–${end} of ${total}` : '0';
        const prev = $('ft-page-prev');
        const next = $('ft-page-next');
        if (prev) prev.disabled = state.page <= 0;
        if (next) next.disabled = end >= total;
    }

    function goPage(delta) {
        const maxPage = Math.max(0, Math.ceil(state.filtered.length / pageSize()) - 1);
        state.page = Math.max(0, Math.min(maxPage, state.page + delta));
        renderGrid(true);
        const scroller = $('ft-scroller');
        if (scroller) scroller.scrollTop = 0;
    }

    function buildTile(it) {
        const tile = document.createElement('button');
        tile.type = 'button';
        tile.className = 'ft-tile';
        tile.dataset.id = itemId(it);
        tile.title = it.name || '';

        const ph = document.createElement('div');
        ph.className = 'ft-ph';
        ph.textContent = isVideo(it) ? '▶' : '▣';
        tile.appendChild(ph);

        const img = document.createElement('img');
        img.alt = '';
        img.decoding = 'async';
        img.src = PLACEHOLDER;
        img.hidden = true;
        tile.appendChild(img);

        const type = document.createElement('div');
        type.className = 'ft-type';
        type.textContent = isVideo(it) ? '🎬' : '🖼';
        tile.appendChild(type);

        const meta = document.createElement('div');
        meta.className = 'ft-meta';
        tile.appendChild(meta);

        const name = document.createElement('div');
        name.className = 'ft-name';
        name.textContent = it.name || 'file';
        tile.appendChild(name);

        tile.draggable = false;
        tile.addEventListener('click', (e) => {
            e.preventDefault();
            onTileClick(it, tile, e);
        });
        tile.addEventListener('dblclick', (e) => {
            e.preventDefault();
            onTileRemove(it, tile);
        });
        tile.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            if (state.prefs.rightClickRemove && !e.shiftKey) onTileRemove(it, tile);
            else showTileMenu(e, it, tile);
        });
        tile.addEventListener('pointerenter', () => onHoverIn(it, tile));
        tile.addEventListener('pointerleave', () => onHoverOut(it, tile));
        return tile;
    }

    function tileEl(it) {
        return document.querySelector(`.ft-tile[data-id="${CSS.escape(itemId(it))}"]`);
    }

    function paintTaggedState() {
        const sessionIds = new Set(state.session.map((s) => s.id));
        pagedItems().forEach((it) => {
            const el = tileEl(it);
            if (!el) return;
            el.classList.toggle('is-tagged', sessionIds.has(itemId(it)));
            paintTileMeta(it, el);
        });
    }

    function paintTileMeta(it, el) {
        const box = el.querySelector('.ft-meta');
        if (!box) return;
        box.innerHTML = '';
        const { meta } = metaForItem(it);
        const tags = userTags(meta?.tags);
        const rating = Number(meta?.rating || 0);
        if (rating) {
            const pill = document.createElement('span');
            pill.className = 'ft-pill';
            pill.textContent = '★'.repeat(Math.min(5, rating));
            box.appendChild(pill);
        }
        tags.slice(0, 2).forEach((t) => {
            const pill = document.createElement('span');
            pill.className = 'ft-pill';
            pill.textContent = t;
            box.appendChild(pill);
        });
        if (tags.length > 2) {
            const pill = document.createElement('span');
            pill.className = 'ft-pill';
            pill.textContent = `+${tags.length - 2}`;
            box.appendChild(pill);
        }
    }

    function observeTiles() {
        if (observeTiles.io) observeTiles.io.disconnect();
        observeTiles.io = new IntersectionObserver((entries) => {
            entries.forEach((en) => {
                const id = en.target.dataset.id;
                if (!id) return;
                if (en.isIntersecting) {
                    state.visible.add(id);
                    const it = state.filtered.find((x) => itemId(x) === id);
                    if (it) {
                        enqueueThumb(it, en.target);
                        if (!state.tech[techId(it)]?.probed) {
                            if (!state.probeQueue.some((x) => techId(x) === techId(it))) state.probeQueue.push(it);
                            runProbeQueue(false);
                        }
                    }
                } else {
                    state.visible.delete(id);
                    stopInlineVideo(en.target);
                }
            });
            scheduleRowPlay();
        }, { root: $('ft-scroller'), rootMargin: '240px 0px', threshold: 0.01 });
        document.querySelectorAll('.ft-tile').forEach((el) => observeTiles.io.observe(el));
    }

    async function getFileFor(it) {
        const id = itemId(it);
        if (state.fileCache.has(id)) return state.fileCache.get(id);
        const handle = it.handle;
        if (!handle) return null;
        try {
            if (handle instanceof File) {
                state.fileCache.set(id, handle);
                return handle;
            }
            const ok = await FAFOLibrary.ensurePermission(handle, 'read');
            if (!ok) return null;
            const file = await handle.getFile();
            state.fileCache.set(id, file);
            if (file) {
                it.size = file.size;
                it.lastModified = file.lastModified;
                it.name = file.name || it.name;
                if (window.FAFOId?.keyFromFile) it.mediaKey = FAFOId.keyFromFile(file, it.name);
            }
            return file;
        } catch (e) {
            const el = tileEl(it);
            el?.classList.add('is-perm');
            return null;
        }
    }

    async function objectUrlFor(it) {
        const id = itemId(it);
        const hit = state.urlCache.get(id);
        if (hit) return hit;
        const file = await getFileFor(it);
        if (!file) return null;
        try {
            const url = URL.createObjectURL(file);
            state.urlCache.set(id, url);
            return url;
        } catch {
            return null;
        }
    }

    function thumbSeekSec() {
        const n = Number(state.prefs.thumbSeek);
        return Number.isFinite(n) ? Math.max(0, Math.min(15, n)) : 1;
    }

    function thumbCacheKey(it, seek) {
        return `${itemId(it)}::${Number(seek).toFixed(2)}::${it.lastModified || 0}::${it.size || 0}`;
    }

    function openThumbDb() {
        if (openThumbDb._p) return openThumbDb._p;
        openThumbDb._p = new Promise((resolve, reject) => {
            try {
                const req = indexedDB.open('fafoGraffitiThumbs', 1);
                req.onupgradeneeded = () => {
                    if (!req.result.objectStoreNames.contains('frames')) req.result.createObjectStore('frames');
                };
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            } catch (e) { reject(e); }
        }).catch(() => null);
        return openThumbDb._p;
    }

    async function getCachedThumb(key) {
        try {
            const db = await openThumbDb();
            if (!db) return null;
            return await new Promise((resolve) => {
                const tx = db.transaction('frames', 'readonly');
                const req = tx.objectStore('frames').get(key);
                req.onsuccess = () => resolve(req.result || null);
                req.onerror = () => resolve(null);
            });
        } catch {
            return null;
        }
    }

    async function setCachedThumb(key, dataUrl) {
        if (!key || !dataUrl) return;
        try {
            const db = await openThumbDb();
            if (!db) return;
            await new Promise((resolve) => {
                const tx = db.transaction('frames', 'readwrite');
                tx.objectStore('frames').put(dataUrl, key);
                tx.oncomplete = () => resolve();
                tx.onerror = () => resolve();
            });
        } catch (_) {}
    }

    function enqueueThumb(it, el) {
        if (!el || !it) return;
        const st = el.dataset.thumb;
        if (st === '1' || st === 'pending' || st === 'queued') return;
        el.dataset.thumb = 'queued';
        state.thumbQueue.push({ it, el });
        pumpThumbs();
    }

    function pumpThumbs() {
        while (state.thumbBusy < THUMB_CONCURRENCY && state.thumbQueue.length) {
            const job = state.thumbQueue.shift();
            if (!job?.el?.isConnected) continue;
            if (job.el.dataset.thumb === '1') continue;
            job.el.dataset.thumb = 'pending';
            state.thumbBusy += 1;
            Promise.resolve()
                .then(() => ensureThumb(job.it, job.el))
                .catch(() => {
                    if (job.el.dataset.thumb === 'pending') job.el.dataset.thumb = '0';
                })
                .finally(() => {
                    state.thumbBusy = Math.max(0, state.thumbBusy - 1);
                    pumpThumbs();
                });
        }
    }

    function showTileThumb(el, src) {
        if (!el || !src) return;
        const img = el.querySelector('img');
        const ph = el.querySelector('.ft-ph');
        if (img) {
            img.src = src;
            img.hidden = false;
        }
        if (ph) ph.remove();
    }

    async function ensureThumb(it, el) {
        if (!el || el.dataset.thumb === '1') return;
        el.dataset.thumb = 'pending';
        const seek = thumbSeekSec();
        let cacheKey = thumbCacheKey(it, seek);
        let cached = await getCachedThumb(cacheKey);
        if (cached) {
            showTileThumb(el, cached);
            el.dataset.thumb = '1';
            return;
        }
        const file = await getFileFor(it);
        if (!file) {
            el.dataset.thumb = '0';
            el.classList.add('is-perm');
            return;
        }
        cacheKey = thumbCacheKey(it, seek);
        cached = await getCachedThumb(cacheKey);
        if (cached) {
            showTileThumb(el, cached);
            el.dataset.thumb = '1';
            return;
        }
        if (!isVideo(it)) {
            const url = await objectUrlFor(it);
            if (url) showTileThumb(el, url);
            rememberTech(it, { size: file.size });
            el.dataset.thumb = '1';
            return;
        }
        const dataUrl = await captureFrame(file, seek, (meta) => rememberTech(it, meta));
        if (dataUrl) {
            showTileThumb(el, dataUrl);
            setCachedThumb(cacheKey, dataUrl);
        } else {
            const url = await objectUrlFor(it);
            if (url) showTileThumb(el, url);
        }
        el.dataset.thumb = '1';
    }

    function captureFrame(file, seekSec, onMeta) {
        return new Promise((resolve) => {
            let settled = false;
            const video = document.createElement('video');
            video.muted = true;
            video.playsInline = true;
            video.preload = 'auto';
            let url;
            try { url = URL.createObjectURL(file); } catch { resolve(null); return; }
            const finish = (val) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                try { URL.revokeObjectURL(url); } catch (_) {}
                try { video.removeAttribute('src'); video.load(); } catch (_) {}
                resolve(val);
            };
            const timer = setTimeout(() => finish(null), 5000);
            const snap = () => {
                try {
                    const w = video.videoWidth;
                    const h = video.videoHeight;
                    if (w < 2 || h < 2) return finish(null);
                    const c = document.createElement('canvas');
                    const max = 720;
                    const scale = Math.min(1, max / Math.max(w, h));
                    c.width = Math.max(2, Math.round(w * scale));
                    c.height = Math.max(2, Math.round(h * scale));
                    c.getContext('2d').drawImage(video, 0, 0, c.width, c.height);
                    finish(c.toDataURL('image/jpeg', 0.72));
                } catch {
                    finish(null);
                }
            };
            video.addEventListener('loadeddata', () => {
                if (typeof onMeta === 'function') {
                    onMeta({
                        duration: Number(video.duration) || 0,
                        width: video.videoWidth || 0,
                        height: video.videoHeight || 0,
                        fps: fpsFromName(file.name) || 0,
                        size: file.size,
                    });
                }
                const dur = Number(video.duration);
                const want = Number(seekSec);
                const cap = Number.isFinite(dur) && dur > 0 ? Math.max(0, dur - 0.12) : 15;
                const t = Math.max(0, Math.min(Number.isFinite(want) ? want : 1, cap));
                if (t <= 0.04 || Math.abs((video.currentTime || 0) - t) < 0.05) {
                    snap();
                    return;
                }
                video.addEventListener('seeked', snap, { once: true });
                try { video.currentTime = t; } catch { snap(); }
            }, { once: true });
            video.addEventListener('error', () => finish(null), { once: true });
            video.src = url;
        });
    }

    function revokeAllUrls() {
        state.urlCache.forEach((url) => {
            try { URL.revokeObjectURL(url); } catch (_) {}
        });
        state.urlCache.clear();
        state.fileCache.clear();
    }

    function onTileClick(it, tile, e) {
        if (state.suppressClick) {
            state.suppressClick = false;
            return;
        }
        const id = itemId(it);
        const ctrl = !!(e && (e.ctrlKey || e.metaKey));
        const shift = !!(e && e.shiftKey);
        if (ctrl && shift) {
            rangeSelect(id, true);
            return;
        }
        if (ctrl) {
            toggleSelected(id);
            return;
        }
        if (shift) {
            rangeSelect(id, false);
            maybePromptApply();
            return;
        }
        if (state.selected.size > 1) {
            if (state.selected.has(id)) return;
            clearSelection();
        }
        if (!state.armed.length) {
            setSelection([id], id);
            return;
        }
        if (state.selected.size && !state.selected.has(id)) clearSelection();
        applyToItem(it, tile, { remove: false });
    }

    function onTileRemove(it, tile) {
        if (!state.armed.length) {
            const sess = state.session.find((s) => s.id === itemId(it));
            if (sess?.applied?.length) {
                applyToItem(it, tile, { remove: true, tags: sess.applied });
                return;
            }
            toast('Select the tags to remove, then double-click');
            return;
        }
        applyToItem(it, tile, { remove: true });
    }

    async function applyToItem(it, tile, opts) {
        const file = await getFileFor(it);
        const name = file?.name || it.name;
        const size = file?.size != null ? file.size : it.size;
        const mtime = file?.lastModified != null ? file.lastModified : it.lastModified;
        const key = (window.FAFOId?.keyFromParts
            ? FAFOId.keyFromParts(name, size, mtime)
            : `file:${name}|${size}|${mtime}`);
        it.mediaKey = key;

        const prev = state.mediaMeta[key] || metaForItem(it).meta || {};
        const prevTags = userTags(prev.tags);
        const prevLow = new Set(prevTags.map((t) => t.toLowerCase()));
        const want = (opts.tags || state.armed).map(normalizeTag).filter(Boolean);
        if (!want.length) return;

        let nextTags;
        let applied = [];
        let removed = [];
        let newlyApplied = [];
        if (opts.remove) {
            const kill = new Set(want.map((t) => t.toLowerCase()));
            nextTags = prevTags.filter((t) => !kill.has(t.toLowerCase()));
            removed = prevTags.filter((t) => kill.has(t.toLowerCase()));
            if (!removed.length) return;
        } else {
            nextTags = prevTags.slice();
            want.forEach((t) => {
                if (!prevLow.has(t.toLowerCase())) {
                    nextTags.push(t);
                    applied.push(t);
                }
            });
            newlyApplied = applied.slice();
            if (!applied.length) {
                // already had them — still send to side list / darken
                applied = want.slice();
            }
        }

        if (!opts.silentUndo) {
            state.undoStack.push({
                key,
                id: itemId(it),
                beforeTags: prevTags.slice(),
                beforeRating: prev.rating || 0,
                beforePair: prev.pairId || '',
                beforeEntry: prev && Object.keys(prev).length ? { ...prev } : null,
                sessionHad: state.session.some((s) => s.id === itemId(it)),
            });
            if (state.undoStack.length > 80) state.undoStack.shift();
        }

        const now = Date.now();
        state.mediaMeta[key] = {
            ...prev,
            rating: prev.rating || 0,
            tags: nextTags,
            name,
            size: size != null ? size : prev.size,
            pairId: prev.pairId,
            pairRole: prev.pairRole,
            updated: now,
        };

        if (newlyApplied.length) {
            newlyApplied.forEach((t) => {
                const low = t.toLowerCase();
                const bucket = (state.privateActive && hasTag(state.privateTagLib, t)) ? 'private' : 'public';
                state.sessionCounts[bucket][low] = (state.sessionCounts[bucket][low] || 0) + 1;
                if (bucket === 'private') {
                    state.privateApplyCounts[low] = (state.privateApplyCounts[low] || 0) + 1;
                } else {
                    state.publicApplyCounts[low] = (state.publicApplyCounts[low] || 0) + 1;
                }
                state.applyCounts = state.privateActive ? state.privateApplyCounts : state.publicApplyCounts;
                state.lastUsed[low] = now;
                if (!originOf(t)) addToList(t, defaultCreateDest());
            });
            renderChips();
        } else if (!opts.remove && applied.length) {
            applied.forEach((t) => { state.lastUsed[t.toLowerCase()] = now; });
        }
        if (removed.length) {
            removed.forEach((t) => {
                const low = t.toLowerCase();
                const bucket = hasTag(state.privateTagLib, t) && state.privateActive ? 'private' : 'public';
                const map = bucket === 'private' ? state.privateApplyCounts : state.publicApplyCounts;
                if ((map[low] || 0) > 0) {
                    map[low] -= 1;
                    if (map[low] <= 0) delete map[low];
                }
                if ((state.sessionCounts[bucket][low] || 0) > 0) {
                    state.sessionCounts[bucket][low] -= 1;
                    if (state.sessionCounts[bucket][low] <= 0) delete state.sessionCounts[bucket][low];
                }
            });
            state.applyCounts = state.privateActive ? state.privateApplyCounts : state.publicApplyCounts;
            renderChips();
        }

        const id = itemId(it);
        if (opts.remove) {
            const stillArmed = hasArmedTags(it);
            state.session = state.session.filter((s) => s.id !== id);
            tile?.classList.toggle('is-tagged', false);
            if (stillArmed) {
                // keep dark only if this pass still "owns" it — user asked darken on select
            }
        } else {
            const url = tile?.querySelector('img')?.src || PLACEHOLDER;
            state.session = state.session.filter((s) => s.id !== id);
            state.session.unshift({
                id,
                key,
                name,
                type: it.type,
                applied: applied.slice(),
                thumbUrl: url,
                item: it,
            });
            tile?.classList.add('is-tagged', 'is-flash');
            setTimeout(() => tile?.classList.remove('is-flash'), 180);
        }

        paintTileMeta(it, tile || tileEl(it));
        renderSide();
        updateStatus();
        schedulePersist();
        queueExplorerWrite(key, name, size, mtime, nextTags, prev.rating || 0);
    }

    function renderSide() {
        const list = $('ft-side-list');
        if (!list) return;
        list.innerHTML = '';
        if (!state.session.length) {
            const empty = document.createElement('div');
            empty.className = 'ft-side-empty';
            empty.textContent = 'Click any thumbnail to apply the armed tags. Tagged files land here. Last three get color borders.';
            list.appendChild(empty);
            return;
        }
        state.session.forEach((s, i) => {
            const row = document.createElement('div');
            row.className = 'ft-side-item' + (i < 3 ? ' ' + RANK_COLORS[i] : '');
            row.title = 'Click to jump · double-click or right-click to remove tags';
            const img = document.createElement('img');
            img.alt = '';
            img.src = s.thumbUrl || PLACEHOLDER;
            row.appendChild(img);
            const body = document.createElement('div');
            const nm = document.createElement('div');
            nm.className = 'ft-side-name';
            nm.textContent = s.name;
            const tg = document.createElement('div');
            tg.className = 'ft-side-tags';
            tg.textContent = (s.applied || []).join(' · ');
            body.appendChild(nm);
            body.appendChild(tg);
            row.appendChild(body);
            row.addEventListener('click', () => {
                const el = document.querySelector(`.ft-tile[data-id="${CSS.escape(s.id)}"]`);
                el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
            });
            row.addEventListener('dblclick', (e) => {
                e.preventDefault();
                if (s.item) onTileRemove(s.item, tileEl(s.item));
            });
            row.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                if (!s.item) return;
                if (state.prefs.rightClickRemove && !e.shiftKey) onTileRemove(s.item, tileEl(s.item));
                else showTileMenu(e, s.item, tileEl(s.item));
            });
            list.appendChild(row);
        });
    }

    function schedulePersist() {
        state.dirtyMeta = true;
        clearTimeout(state.persistTimer);
        state.persistTimer = setTimeout(flushPersist, 160);
    }

    async function flushPersist() {
        if (!state.dirtyMeta) return;
        state.dirtyMeta = false;
        const k = state.spaceKeys;
        const pub = state.publicKeys;
        const priv = state.privateKeys;
        const pubDirty = state.libDirty.public;
        const privDirty = state.libDirty.private;
        const payload = {
            [k.mediaMeta]: state.mediaMeta,
            [k.applyCounts]: state.privateActive ? state.privateApplyCounts : state.publicApplyCounts,
            [pub.applyCounts]: state.publicApplyCounts,
            [k.tagLastUsed]: state.lastUsed,
        };
        if (state.privateActive) payload[priv.applyCounts] = state.privateApplyCounts;
        // Current space library always (harvest/apply). Other space only when explicitly assigned.
        if (state.privateActive) {
            payload[priv.tagLibrary] = state.privateTagLib;
            if (pubDirty) payload[pub.tagLibrary] = state.publicTagLib;
        } else {
            payload[pub.tagLibrary] = state.publicTagLib;
        }
        try {
            await chrome.storage.local.set(payload);
            state.libDirty.public = false;
            state.libDirty.private = false;
            try {
                window.FAFOMetaLedger?.harvest?.(
                    state.privateActive ? 'private' : 'public',
                    state.mediaMeta
                );
            } catch (_) {}
        } catch (e) {
            console.warn('Graffiti persist', e);
            state.dirtyMeta = true;
            state.libDirty.public = pubDirty;
            state.libDirty.private = privDirty;
        }
        try {
            if (window.FAFOTagDb?.mergeTags) {
                if (state.privateActive) {
                    await FAFOTagDb.mergeTags(priv.tagDb, state.privateTagLib);
                    if (pubDirty) await FAFOTagDb.mergeTags(pub.tagDb, state.publicTagLib);
                } else {
                    await FAFOTagDb.mergeTags(pub.tagDb, state.publicTagLib);
                }
            }
        } catch (_) {}
        try {
            if (state.privateActive) {
                await window.FAFOBackup?.afterPrivateLiveSave?.(payload, 'fast-tag');
                if (pubDirty) {
                    await window.FAFOBackup?.afterLiveSave?.(
                        { fafoTagLibrary: state.publicTagLib },
                        'fast-tag-public-list'
                    );
                }
            } else {
                await window.FAFOBackup?.afterLiveSave?.(
                    { fafoMediaMeta: state.mediaMeta, fafoTagLibrary: state.publicTagLib, fafoTagApplyCounts: state.applyCounts },
                    'fast-tag'
                );
            }
        } catch (_) {}
    }

    function queueExplorerWrite(key, name, size, mtime, tags, rating) {
        try {
            const space = state.privateActive ? 'private' : 'public';
            window.FAFOMetaLedger?.recordConfigured?.(space, key, { name, size, mtime, tags, rating });
        } catch (_) {}
        state.explorerQueue.push({ key, name, size, mtime, tags, rating });
        clearTimeout(state.explorerTimer);
        state.explorerTimer = setTimeout(flushExplorer, 220);
    }

    async function flushExplorer() {
        const batch = state.explorerQueue.splice(0, 12);
        if (!batch.length) return;
        const space = state.privateActive ? 'private' : 'public';
        for (const row of batch) {
            try {
                const r = await fetch(`${TOOLBOX_API}/fs/write-metadata`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: row.name,
                        size: row.size ?? null,
                        mtime: row.mtime ?? null,
                        tags: row.tags,
                        rating: row.rating || 0,
                        update_catalog: true,
                        client_key: row.key || undefined,
                    }),
                    signal: AbortSignal.timeout(3500),
                });
                const data = await r.json().catch(() => ({}));
                if (row.key && window.FAFOMetaLedger) {
                    if (r.ok && data.ok !== false) {
                        FAFOMetaLedger.markApplied(space, row.key, {
                            path: data.resolved_path,
                            methods: data.methods,
                            deferred: !!(data.deferred_shell || data.file_locked),
                        });
                    } else {
                        FAFOMetaLedger.markFailed(space, row.key, data.detail || data.error || r.statusText);
                    }
                }
            } catch (e) {
                if (row.key && window.FAFOMetaLedger) {
                    FAFOMetaLedger.markFailed(space, row.key, e.message || 'network');
                }
            }
        }
        if (state.explorerQueue.length) state.explorerTimer = setTimeout(flushExplorer, 80);
    }

    async function undoLast() {
        const u = state.undoStack.pop();
        if (!u) return;
        const restoreOne = (row) => {
            if (!row) return;
            if (row.beforeEntry && row.key) state.mediaMeta[row.key] = { ...row.beforeEntry };
            else if (row.key) delete state.mediaMeta[row.key];
            if (!row.sessionHad && row.id) {
                state.session = state.session.filter((s) => s.id !== row.id);
                const el = document.querySelector(`.ft-tile[data-id="${CSS.escape(row.id)}"]`);
                el?.classList.remove('is-tagged');
                const it = state.items.find((x) => itemId(x) === row.id);
                if (it && el) paintTileMeta(it, el);
            } else if (row.id) {
                const it = state.items.find((x) => itemId(x) === row.id);
                const el = it ? tileEl(it) : null;
                if (it && el) paintTileMeta(it, el);
            }
        };
        if (u.bulk && Array.isArray(u.items)) {
            u.items.forEach(restoreOne);
            renderSide();
            updateStatus();
            schedulePersist();
            toast(`Undid ${u.items.length} file${u.items.length === 1 ? '' : 's'}`);
            return;
        }
        restoreOne(u);
        renderSide();
        updateStatus();
        schedulePersist();
        toast('Undid last tag action');
    }

    /* ── hover preview plays in the right rail (full frame) ─ */

    function onHoverIn(it, tile) {
        if (state.marquee?.on) return;
        state.hoverItem = it;
        tile.classList.add('ft-hover-src');
        clearTimeout(state.hoverHideTimer);
        showHover(it, tile);
    }

    function onHoverOut(it, tile) {
        tile.classList.remove('ft-hover-src');
        if (state.hoverItem && itemId(state.hoverItem) === itemId(it)) state.hoverItem = null;
        if (!state.playingRow.has(itemId(it))) stopInlineVideo(tile);
        // Keep the last clip looping in the rail so you can watch while tagging.
    }

    function previewDock() {
        return $('ft-preview');
    }

    async function showHover(it, tile) {
        const dock = previewDock();
        if (!dock) return;
        applyLayoutVars();
        dock.innerHTML = '';
        const still = tile?.querySelector('img');
        if (still && still.src && !still.hidden) {
            const img = document.createElement('img');
            img.alt = it.name || '';
            img.src = still.src;
            dock.appendChild(img);
        } else {
            const empty = document.createElement('div');
            empty.className = 'ft-preview-empty';
            empty.textContent = it.name || 'Loading…';
            dock.appendChild(empty);
        }
        const url = await objectUrlFor(it);
        if (!url || state.hoverItem !== it) return;
        if (isVideo(it)) {
            const v = document.createElement('video');
            v.muted = true;
            v.loop = true;
            v.playsInline = true;
            v.autoplay = true;
            v.controls = false;
            v.src = url;
            v.addEventListener('contextmenu', (e) => e.preventDefault());
            dock.innerHTML = '';
            dock.appendChild(v);
            v.play().catch(() => {});
        } else {
            dock.innerHTML = '';
            const img = document.createElement('img');
            img.alt = it.name || '';
            img.src = url;
            dock.appendChild(img);
        }
    }

    function hideHover() {
        const dock = previewDock();
        if (!dock) return;
        const v = dock.querySelector('video');
        if (v) {
            try { v.pause(); v.removeAttribute('src'); v.load(); } catch (_) {}
        }
        dock.innerHTML = '<div class="ft-preview-empty">Hover a tile — the full video plays here. Drag the rail or crank Preview to enlarge.</div>';
    }

    async function playInline(it, tile) {
        if (!isVideo(it) || !tile) return;
        if (tile.querySelector('video.ft-inline')) return;
        const url = await objectUrlFor(it);
        if (!url) return;
        const v = document.createElement('video');
        v.className = 'ft-inline';
        v.muted = true;
        v.loop = true;
        v.playsInline = true;
        v.src = url;
        v.addEventListener('contextmenu', (e) => e.preventDefault());
        tile.appendChild(v);
        v.play().catch(() => {});
        const img = tile.querySelector('img');
        if (img) img.style.opacity = '0';
    }

    function stopInlineVideo(tile) {
        if (!tile) return;
        tile.querySelectorAll('video.ft-inline').forEach((v) => {
            try { v.pause(); v.removeAttribute('src'); v.load(); } catch (_) {}
            v.remove();
        });
        const img = tile.querySelector('img');
        if (img) img.style.opacity = '';
    }

    function stopAllInlineVideo() {
        document.querySelectorAll('.ft-tile video.ft-inline').forEach((v) => {
            try { v.pause(); v.removeAttribute('src'); v.load(); } catch (_) {}
            v.remove();
        });
        state.playingRow.clear();
    }

    function scheduleRowPlay() {
        clearTimeout(scheduleRowPlay._t);
        scheduleRowPlay._t = setTimeout(playTopRow, 60);
    }

    function playTopRow() {
        const scroller = $('ft-scroller');
        if (!scroller || !state.prefs.autoPlay) {
            stopAllInlineVideo();
            return;
        }
        const tiles = [...document.querySelectorAll('.ft-tile')];
        if (!tiles.length) return;
        const top = scroller.getBoundingClientRect().top + 8;
        const firstVisible = tiles.find((t) => {
            const r = t.getBoundingClientRect();
            return r.bottom > top + 4 && r.top < scroller.getBoundingClientRect().bottom;
        });
        if (!firstVisible) return;
        const rowTop = firstVisible.getBoundingClientRect().top;
        const rowH = firstVisible.getBoundingClientRect().height;
        const row = tiles.filter((t) => {
            const r = t.getBoundingClientRect();
            return Math.abs(r.top - rowTop) < rowH * 0.45;
        });
        const ids = new Set(row.map((el) => el.dataset.id));
        tiles.forEach((el) => {
            const id = el.dataset.id;
            const it = state.filtered.find((x) => itemId(x) === id);
            if (!it) return;
            if (ids.has(id) && isVideo(it)) {
                if (!state.playingRow.has(id)) {
                    state.playingRow.add(id);
                    playInline(it, el);
                }
            } else if (state.hoverItem && itemId(state.hoverItem) === id) {
                /* keep hover playback */
            } else if (state.playingRow.has(id)) {
                state.playingRow.delete(id);
                stopInlineVideo(el);
            }
        });
    }

    function rowHeight() {
        const tile = document.querySelector('.ft-tile');
        if (!tile) return Number(state.prefs.thumb) * 9 / 16 + 10;
        const gap = 10;
        return tile.getBoundingClientRect().height + gap;
    }

    function startAutoScroll() {
        stopAutoScroll();
        if (!state.prefs.autoScroll) return;
        const tick = () => {
            const scroller = $('ft-scroller');
            if (!scroller) return;
            const h = rowHeight();
            const max = scroller.scrollHeight - scroller.clientHeight;
            if (max <= 8) return;
            if (scroller.scrollTop >= max - 4) {
                scroller.scrollTo({ top: 0, behavior: 'smooth' });
            } else {
                scroller.scrollBy({ top: h, behavior: 'smooth' });
            }
            setTimeout(playTopRow, 420);
        };
        const ms = Math.max(800, Number(state.prefs.scroll) * 1000);
        state.scrollTimer = setInterval(tick, ms);
    }

    function stopAutoScroll() {
        if (state.scrollTimer) {
            clearInterval(state.scrollTimer);
            state.scrollTimer = null;
        }
    }

    function bindMarquee() {
        const scroller = $('ft-scroller');
        const box = $('ft-marquee');
        if (!scroller) return;

        const draw = () => {
            const m = state.marquee;
            if (!box) return;
            if (!m?.on) {
                box.hidden = true;
                return;
            }
            const x = Math.min(m.x0, m.x1);
            const y = Math.min(m.y0, m.y1);
            box.hidden = false;
            box.style.left = `${x}px`;
            box.style.top = `${y}px`;
            box.style.width = `${Math.abs(m.x1 - m.x0)}px`;
            box.style.height = `${Math.abs(m.y1 - m.y0)}px`;
        };

        const hit = () => {
            const m = state.marquee;
            if (!m?.on) return;
            const x1 = Math.min(m.x0, m.x1);
            const x2 = Math.max(m.x0, m.x1);
            const y1 = Math.min(m.y0, m.y1);
            const y2 = Math.max(m.y0, m.y1);
            const next = m.additive ? new Set(m.base) : new Set();
            scroller.querySelectorAll('.ft-tile').forEach((el) => {
                const r = el.getBoundingClientRect();
                if (r.right < x1 || r.left > x2 || r.bottom < y1 || r.top > y2) return;
                if (el.dataset.id) next.add(el.dataset.id);
            });
            state.selected = next;
            paintPicked();
            paintSelBar();
        };

        const edgeScroll = (e) => {
            const r = scroller.getBoundingClientRect();
            let dy = 0;
            if (e.clientY > r.bottom - 36) dy = 24;
            else if (e.clientY < r.top + 36) dy = -24;
            if (dy) {
                scroller.scrollTop += dy;
                hit();
            }
        };

        scroller.addEventListener('pointerdown', (e) => {
            if (e.button !== 0) return;
            if (e.target.closest('#ft-selbar, #ft-confirm, #ft-ctx, a, input, select, textarea, .ft-btn')) return;
            hideHover();
            state.marquee = {
                on: false,
                pointerId: e.pointerId,
                x0: e.clientX,
                y0: e.clientY,
                x1: e.clientX,
                y1: e.clientY,
                additive: !!(e.ctrlKey || e.metaKey),
                base: new Set(state.selected),
            };
            state.suppressClick = false;
        });

        window.addEventListener('pointermove', (e) => {
            const m = state.marquee;
            if (!m) return;
            const dist = Math.hypot(e.clientX - m.x0, e.clientY - m.y0);
            if (!m.on) {
                if (dist < 8) return;
                m.on = true;
                state.suppressClick = true;
                hideHover();
                hideCtx();
            }
            m.x1 = e.clientX;
            m.y1 = e.clientY;
            draw();
            hit();
            edgeScroll(e);
        });

        const endMarquee = () => {
            const m = state.marquee;
            if (!m) return;
            const wasDrag = m.on;
            state.marquee = null;
            if (box) box.hidden = true;
            if (wasDrag) {
                const ids = [...state.selected];
                if (ids.length) state.lastAnchor = ids[ids.length - 1];
                paintPicked();
                updateStatus();
                maybePromptApply();
                setTimeout(() => { state.suppressClick = false; }, 60);
            }
        };
        window.addEventListener('pointerup', endMarquee);
        window.addEventListener('pointercancel', endMarquee);
    }

    function bindRailSplit() {
        const handle = $('ft-split');
        if (!handle || handle._ftBound) return;
        handle._ftBound = true;
        handle.addEventListener('pointerdown', (ev) => {
            if (ev.button !== 0) return;
            ev.preventDefault();
            const startX = ev.clientX;
            const startW = Number(state.prefs.sideW) || 400;
            handle.classList.add('is-on');
            const max = Math.min(900, Math.round(window.innerWidth * 0.75));
            const onMove = (e) => {
                const next = clampNum(startW + (startX - e.clientX), 240, max, startW);
                state.prefs.sideW = next;
                state.prefs.hover = next;
                applyLayoutVars();
            };
            const onUp = () => {
                handle.classList.remove('is-on');
                window.removeEventListener('pointermove', onMove);
                window.removeEventListener('pointerup', onUp);
                window.removeEventListener('pointercancel', onUp);
                savePrefs();
            };
            window.addEventListener('pointermove', onMove);
            window.addEventListener('pointerup', onUp);
            window.addEventListener('pointercancel', onUp);
            try { handle.setPointerCapture?.(ev.pointerId); } catch (_) {}
        });
    }

    function bindUi() {
        const thumb = $('ft-thumb');
        const hover = $('ft-hover-size');
        const scroll = $('ft-scroll');
        thumb?.addEventListener('input', () => {
            state.prefs.thumb = Number(thumb.value);
            $('ft-thumb-val').textContent = `${state.prefs.thumb}px`;
            document.documentElement.style.setProperty('--ft-thumb', `${state.prefs.thumb}px`);
            scheduleRowPlay();
        });
        thumb?.addEventListener('change', () => { savePrefs(); startAutoScroll(); });
        hover?.addEventListener('input', () => {
            state.prefs.hover = clampNum(hover.value, 240, 900, 400);
            state.prefs.sideW = state.prefs.hover;
            applyLayoutVars();
        });
        hover?.addEventListener('change', savePrefs);
        $('ft-fit')?.addEventListener('click', () => {
            state.prefs.fit = state.prefs.fit === 'cover' ? 'contain' : 'cover';
            applyLayoutVars();
            syncFitBtn();
            savePrefs();
        });
        bindRailSplit();
        const seek = $('ft-thumb-seek');
        seek?.addEventListener('input', () => {
            state.prefs.thumbSeek = Number(seek.value);
            $('ft-thumb-seek-val').textContent = `${thumbSeekSec().toFixed(1)}s`;
        });
        seek?.addEventListener('change', () => {
            state.prefs.thumbSeek = Number(seek.value);
            savePrefs();
            state.thumbQueue = [];
            document.querySelectorAll('.ft-tile').forEach((el) => {
                el.dataset.thumb = '0';
            });
            document.querySelectorAll('.ft-tile').forEach((el) => {
                const it = state.filtered.find((x) => itemId(x) === el.dataset.id);
                if (it && state.visible.has(itemId(it))) enqueueThumb(it, el);
            });
        });
        $('ft-page-size')?.addEventListener('change', (e) => {
            state.prefs.pageSize = Number(e.target.value) || 50;
            state.page = 0;
            savePrefs();
            renderGrid(true);
        });
        $('ft-page-prev')?.addEventListener('click', () => goPage(-1));
        $('ft-page-next')?.addEventListener('click', () => goPage(1));
        scroll?.addEventListener('input', () => {
            state.prefs.scroll = Number(scroll.value);
            $('ft-scroll-val').textContent = `${Number(state.prefs.scroll).toFixed(1)}s`;
        });
        scroll?.addEventListener('change', () => { savePrefs(); startAutoScroll(); });

        const toggle = (id, key, extra) => {
            $(id)?.addEventListener('click', () => {
                state.prefs[key] = !state.prefs[key];
                $(id).classList.toggle('is-on', !!state.prefs[key]);
                savePrefs();
                extra?.();
            });
        };
        toggle('ft-auto-scroll', 'autoScroll', startAutoScroll);
        toggle('ft-auto-play', 'autoPlay', () => {
            if (!state.prefs.autoPlay) stopAllInlineVideo();
            else playTopRow();
        });
        toggle('ft-right-click', 'rightClickRemove');
        $('ft-untagged')?.addEventListener('click', () => {
            state.prefs.untaggedOnly = !state.prefs.untaggedOnly;
            $('ft-untagged').classList.toggle('is-on', state.prefs.untaggedOnly);
            savePrefs();
            applyFilter(true);
        });
        $('ft-type')?.addEventListener('change', (e) => {
            state.prefs.type = e.target.value;
            savePrefs();
            applyFilter(true);
        });
        $('ft-filter')?.addEventListener('input', (e) => {
            state.prefs.filter = e.target.value;
            savePrefs();
            applyFilter(true);
        });
        $('ft-tag-filter')?.addEventListener('input', (e) => {
            state.prefs.tagFilter = e.target.value;
            renderChips();
        });
        $('ft-tag-filter')?.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter') return;
            createAndArm(e.target.value);
            e.target.value = '';
            state.prefs.tagFilter = '';
            renderChips();
        });
        $('ft-new-tag')?.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter') return;
            createAndArm(e.target.value);
            e.target.value = '';
        });
        $('ft-create')?.addEventListener('click', () => {
            const input = $('ft-new-tag');
            createAndArm(input?.value);
            if (input) input.value = '';
        });
        const setDest = (which) => {
            state.prefs.createDest = which;
            savePrefs();
            paintSpaceUi();
        };
        $('ft-dest-private')?.addEventListener('click', () => setDest('private'));
        $('ft-dest-public')?.addEventListener('click', () => setDest('public'));
        $('ft-clear-tags')?.addEventListener('click', () => {
            state.armed = [];
            renderChips();
            updateStatus();
        });
        $('ft-clear-session')?.addEventListener('click', () => {
            state.session = [];
            document.querySelectorAll('.ft-tile.is-tagged').forEach((el) => el.classList.remove('is-tagged'));
            renderSide();
            updateStatus();
        });
        $('ft-restore')?.addEventListener('click', restoreAccess);
        $('ft-banner-restore')?.addEventListener('click', restoreAccess);
        $('ft-undo')?.addEventListener('click', undoLast);
        $('ft-sel-apply')?.addEventListener('click', () => showConfirmApply() || applyToSelection());
        $('ft-sel-skip')?.addEventListener('click', declineApply);
        $('ft-sel-remove')?.addEventListener('click', () => applyToSelection({ remove: true }));
        $('ft-sel-clear')?.addEventListener('click', clearSelection);
        $('ft-confirm-yes')?.addEventListener('click', () => applyToSelection());
        $('ft-confirm-no')?.addEventListener('click', declineApply);
        $('ft-confirm')?.addEventListener('click', (e) => {
            if (e.target.id === 'ft-confirm') declineApply();
        });

        bindMarquee();

        $('ft-scroller')?.addEventListener('scroll', () => scheduleRowPlay(), { passive: true });

        document.addEventListener('keydown', (e) => {
            const typing = e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT');
            if (e.key === 'Escape') {
                const ctx = $('ft-ctx');
                if (ctx && !ctx.hidden) {
                    hideCtx();
                    return;
                }
                if (document.querySelector('.ft-dd.is-open')) {
                    closeFacetMenus();
                    return;
                }
                if ($('ft-confirm') && !$('ft-confirm').hidden) {
                    declineApply();
                    return;
                }
                if (state.selected.size) {
                    clearSelection();
                    return;
                }
                window.location.href = 'options.html';
                return;
            }
            if (typing) return;
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') {
                e.preventDefault();
                const ids = pagedItems().map(itemId);
                setSelection(ids, ids[0] || null);
                maybePromptApply();
                return;
            }
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
                e.preventDefault();
                undoLast();
            }
            if (e.code === 'Space') {
                e.preventDefault();
                state.prefs.autoScroll = !state.prefs.autoScroll;
                $('ft-auto-scroll')?.classList.toggle('is-on', state.prefs.autoScroll);
                savePrefs();
                startAutoScroll();
            }
        });

        document.addEventListener('pointerdown', (e) => {
            const ctx = $('ft-ctx');
            if (ctx && !ctx.hidden && !ctx.contains(e.target)) hideCtx();
            if (!e.target.closest('.ft-dd')) closeFacetMenus();
        });
        window.addEventListener('blur', hideCtx);
        window.addEventListener('resize', () => {
            hideCtx();
            applyLayoutVars();
        });

        window.addEventListener('beforeunload', () => {
            if (state.dirtyMeta) flushPersist();
            flushTech();
        });

        $('fafo-disk-pip')?.addEventListener('click', () => {
            launchDiskServer().catch(() => {});
        });
        refreshDiskPip().catch(() => {});
        setInterval(() => { refreshDiskPip().catch(() => {}); }, 12000);
    }

    async function boot() {
        bindUi();
        await loadPrefs();
        await loadTech();
        renderFacetMenus();
        await resolveSpace();
        try {
            if (window.FAFOVisual?.loadFromStorage) {
                const v = await FAFOVisual.loadFromStorage();
                FAFOVisual.apply?.(v);
            }
        } catch (_) {}
        await loadMetaAndTags();
        try {
            await loadLibrary();
        } catch (e) {
            console.warn('Graffiti library', e);
            $('ft-grid').innerHTML = '<div class="ft-empty">Could not open the library database.</div>';
            setStatus('Library unavailable');
            return;
        }
        startAutoScroll();
        setTimeout(playTopRow, 1200);
        setStatus(`${state.filtered.length} tiles ready`);
    }

    boot().catch((e) => {
        console.error('Graffiti boot', e);
        setStatus('Graffiti Speed Tagging failed to start');
    });
})();
