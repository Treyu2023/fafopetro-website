# FAFO Explorer Meta (S2) — copy to a space-free folder, register
# fafo-companion://, start a supervisor, keep the tag server alive.
# Same pattern as Imagine Vault. Chrome should never need a manual start.
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$work = Join-Path $env:LOCALAPPDATA 'FAFO\ExplorerMeta'
New-Item -ItemType Directory -Force -Path $work | Out-Null

$prefsRoot = $null
$prefsFile = Join-Path $env:LOCALAPPDATA 'FAFO\launch-prefs.json'
if (Test-Path -LiteralPath $prefsFile) {
    try {
        $prefsJson = Get-Content -LiteralPath $prefsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($prefsJson.fafoMetaRoot) { $prefsRoot = [string]$prefsJson.fafoMetaRoot }
    } catch {}
}
# Prefer the live checkout over this script's folder. The copy under
# %LOCALAPPDATA%\FAFO\ExplorerMeta is often stale, and $here is that copy
# when Chrome launches fafo-companion://.
$srcRoots = @(
    $prefsRoot,
    (Join-Path $env:USERPROFILE 'fafo-chrome-extensions\FAFO Local Media LOAD THIS\explorer-meta'),
    (Join-Path $env:USERPROFILE 'FAFO_Ultimate_Tab\explorer-meta'),
    $here
) | Where-Object { $_ -and (Test-Path -LiteralPath (Join-Path $_ 'server.py')) }

$src = $srcRoots | Select-Object -First 1
if (-not $src) { $src = $here }

$copyNames = @(
    'server.py', 'file_metadata.py', '_shell_props.ps1', 'pick_folder.ps1', 'stack.py',
    'fafo_native_host.py', 'fafo_native_host.bat', 'requirements.txt',
    'Launch-ExplorerMeta.ps1', 'Launch-ExplorerMeta.vbs', 'Launch-ExplorerMeta.bat'
)
foreach ($name in $copyNames) {
    $from = Join-Path $src $name
    if (Test-Path -LiteralPath $from) {
        Copy-Item -LiteralPath $from -Destination (Join-Path $work $name) -Force
    }
}

$srcCfg = Join-Path $src 'config.json'
$dstCfg = Join-Path $work 'config.json'
if ((Test-Path -LiteralPath $srcCfg) -and -not (Test-Path -LiteralPath $dstCfg)) {
    Copy-Item -LiteralPath $srcCfg -Destination $dstCfg -Force
}

function Find-Python {
    $prod = 'C:\_Git\repos\html\HTML Toolbox AI tools\production\.venv\Scripts'
    $list = @(
        (Join-Path $prod 'python.exe'),
        (Join-Path $prod 'pythonw.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\FAFO-Power-Toolbox\.venv\Scripts\python.exe'),
        (Join-Path $env:USERPROFILE 'Desktop\FAFO-Power-Toolbox\.venv\Scripts\pythonw.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python314\python.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python314\pythonw.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python313\pythonw.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312\pythonw.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\pythonw.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Python\Python311\python.exe')
    )
    foreach ($c in $list) { if (Test-Path -LiteralPath $c) { return $c } }
    foreach ($name in @('pythonw', 'python', 'py')) {
        $cmd = Get-Command $name -ErrorAction SilentlyContinue
        if ($cmd) { return $cmd.Source }
    }
    return $null
}

$py = Find-Python
if (-not $py) { throw 'Python not found. Run explorer-meta\INSTALL_DEPS.bat once.' }
# Native messaging needs a console Python. pythonw drops the stdin/stdout pipe Chrome uses.
$hostPy = $py
if ($hostPy -match 'pythonw\.exe$') {
    $console = $hostPy -replace 'pythonw\.exe$', 'python.exe'
    if (Test-Path -LiteralPath $console) { $hostPy = $console }
}
$pyw = $hostPy
if ($hostPy -match 'python\.exe$') {
    $alt = $hostPy -replace 'python\.exe$', 'pythonw.exe'
    if (Test-Path -LiteralPath $alt) { $pyw = $alt }
}
Set-Content -LiteralPath (Join-Path $work 'python.path') -Value $hostPy -Encoding ASCII

# Protocol handler — wscript on a space-free path (Chrome cannot launch paths with spaces).
$vbs = Join-Path $work 'Launch-ExplorerMeta.vbs'
$prot = 'HKCU:\Software\Classes\fafo-companion'
New-Item -Path $prot -Force | Out-Null
Set-ItemProperty $prot -Name '(default)' -Value 'URL:FAFO Companion'
New-ItemProperty -Path $prot -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
$cmdKey = Join-Path $prot 'shell\open\command'
New-Item -Path $cmdKey -Force | Out-Null
Set-ItemProperty $cmdKey -Name '(default)' -Value ("wscript.exe //B `"$vbs`" `"%1`"")

# Login startup — hidden, no console.
$startup = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
New-Item -ItemType Directory -Force -Path $startup | Out-Null
@(
    '@echo off',
    'timeout /t 6 /nobreak >nul',
    "start `"`" /min wscript.exe //B `"$vbs`""
) | Set-Content -LiteralPath (Join-Path $startup 'FAFO Companion.cmd') -Encoding ASCII

function Get-ExtensionId {
    foreach ($a in $args) {
        $s = [string]$a
        if ($s -match '([a-p]{32})') { return $Matches[1] }
        if ($s -match 'chrome-extension://([a-p]{32})') { return $Matches[1] }
    }
    $saved = Join-Path $work 'extension-id.txt'
    if (Test-Path -LiteralPath $saved) {
        $raw = (Get-Content -LiteralPath $saved -Raw -ErrorAction SilentlyContinue)
        if ($raw -match '([a-p]{32})') { return $Matches[1] }
    }
    return $null
}

$extId = Get-ExtensionId @args
if ($extId) {
    Set-Content -LiteralPath (Join-Path $work 'extension-id.txt') -Value $extId -Encoding ASCII
    $hostBat = Join-Path $work 'fafo_native_host.bat'
    $hostJson = Join-Path $work 'com.fafo.companion.installed.json'
    $origin = "chrome-extension://$extId/"
    $obj = [ordered]@{
        name            = 'com.fafo.companion'
        description     = 'FAFO Explorer companion auto-launch'
        path            = $hostBat
        type            = 'stdio'
        allowed_origins = @($origin)
    }
    $obj | ConvertTo-Json | Set-Content -Encoding UTF8 $hostJson
    New-Item -Path 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.fafo.companion' -Force | Out-Null
    Set-ItemProperty 'HKCU:\Software\Google\Chrome\NativeMessagingHosts\com.fafo.companion' -Name '(default)' -Value $hostJson
    New-Item -Path 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.fafo.companion' -Force | Out-Null
    Set-ItemProperty 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\com.fafo.companion' -Name '(default)' -Value $hostJson
}

function Test-MetaUp {
    try {
        $r = Invoke-WebRequest -Uri 'http://127.0.0.1:8765/api/health' -UseBasicParsing -TimeoutSec 1
        if ($r.StatusCode -ne 200) { return $false }
        $body = $r.Content
        if ($body -match 'fafo-explorer-meta' -or $body -match '"ok"\s*:\s*true') { return $true }
        return $true
    } catch { return $false }
}

function Test-WatchAlive {
    $pidFile = Join-Path $work 'meta-watch.pid'
    if (-not (Test-Path -LiteralPath $pidFile)) { return $false }
    $raw = (Get-Content -LiteralPath $pidFile -ErrorAction SilentlyContinue | Select-Object -First 1)
    $wpid = 0
    [void][int]::TryParse($raw, [ref]$wpid)
    if ($wpid -le 0) { return $false }
    return [bool](Get-Process -Id $wpid -ErrorAction SilentlyContinue)
}

# First-run packages — quiet, only if import fails.
$probe = @('-c', 'import fastapi,uvicorn,mutagen')
$probeOk = $false
try {
    & $py @probe 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { $probeOk = $true }
} catch { $probeOk = $false }
if (-not $probeOk) {
    $req = Join-Path $work 'requirements.txt'
    if (Test-Path -LiteralPath $req) {
        Start-Process -FilePath $py -ArgumentList @('-m', 'pip', 'install', '-q', '-r', 'requirements.txt') -WorkingDirectory $work -WindowStyle Hidden -Wait | Out-Null
    }
}

# The tab asked. Tell the watcher and the toolbox watchdog to keep S2 up.
$fafoDir = Join-Path $env:LOCALAPPDATA 'FAFO'
New-Item -ItemType Directory -Force -Path $fafoDir | Out-Null
$stamp = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() / 1000.0
('{"at":' + $stamp + ',"app":"fafo-companion-launch","which":"s2"}') | Set-Content -LiteralPath (Join-Path $fafoDir 'demand-s2.json') -Encoding ASCII
if (Test-Path -LiteralPath $prefsFile) {
    try {
        $wake = Get-Content -LiteralPath $prefsFile -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $wake.serversSleeping) {
            $wake | Add-Member -NotePropertyName serversSleeping -NotePropertyValue ([pscustomobject]@{ toolboxServer = $false; fafoMetaServer = $false }) -Force
        } else {
            $wake.serversSleeping.fafoMetaServer = $false
        }
        if (-not $wake.manualHold) {
            $wake | Add-Member -NotePropertyName manualHold -NotePropertyValue ([pscustomobject]@{ toolboxServer = $false; fafoMetaServer = $true }) -Force
        } else {
            $wake.manualHold.fafoMetaServer = $true
        }
        if ($wake.sessions) { $wake.sessions.fafoMediaActive = $true }
        $wake.updatedAt = (Get-Date).ToString('o')
        ($wake | ConvertTo-Json -Depth 8) | Set-Content -LiteralPath $prefsFile -Encoding UTF8
    } catch {}
}

# A live watch PID with nothing on 8765 is a stuck watcher. Start again when the port is down.
if (-not (Test-MetaUp)) {
    $stop = Join-Path $work 'stop.flag'
    if (Test-Path -LiteralPath $stop) { Remove-Item -LiteralPath $stop -Force -ErrorAction SilentlyContinue }
    Start-Process -FilePath $pyw -ArgumentList @('-u', 'server.py', '--watch') -WorkingDirectory $work -WindowStyle Hidden | Out-Null
}

if (Test-MetaUp) { exit 0 }
$deadline = (Get-Date).AddSeconds(16)
do {
    Start-Sleep -Milliseconds 300
    if (Test-MetaUp) { exit 0 }
} while ((Get-Date) -lt $deadline)
exit 0
