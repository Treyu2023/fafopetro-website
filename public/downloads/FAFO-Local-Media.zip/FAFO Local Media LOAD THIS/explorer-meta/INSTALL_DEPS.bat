@echo off
title FAFO — Install Metadata Server Dependencies
cd /d "%~dp0"

echo.
echo  ================================================
echo   FAFO Explorer Metadata — Install Dependencies
echo  ================================================
echo.
echo  This installs Python packages needed to write
echo  Windows Explorer Tags and Ratings into video files:
echo    - fastapi, uvicorn  (local server)
echo    - pywin32           (Windows file properties)
echo    - mutagen           (MP4 embedded tags)
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo  [ERROR] Python was not found on PATH.
  echo  Install Python 3.10+ from https://www.python.org/downloads/
  echo  IMPORTANT: check "Add python.exe to PATH" during setup.
  echo.
  pause
  exit /b 1
)

python --version
echo.
echo  Installing packages...
python -m pip install --upgrade pip
python -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo  [ERROR] pip install failed.
  pause
  exit /b 1
)

echo.
echo  Verifying pywin32...
python -c "from win32com.propsys import propsys; print('  pywin32 OK')"
if errorlevel 1 (
  echo  [WARN] pywin32 import failed. Trying force reinstall...
  python -m pip install --force-reinstall --no-cache-dir pywin32
  python -c "from win32com.propsys import propsys; print('  pywin32 OK after reinstall')"
)

echo.
echo  Verifying server modules...
python -c "import file_metadata; print('  file_metadata OK')"

echo.
echo  Done. Next: run START_META_SERVER.bat
echo.
pause
exit /b 0
