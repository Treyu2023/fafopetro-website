@echo off
setlocal EnableExtensions
title FAFO companion stack
cd /d "%~dp0"

REM Auto-launch path used by fafo-companion://, Startup, and native messaging.
REM Delegates to Launch-ExplorerMeta (space-free LOCALAPPDATA copy + supervisor).

if exist "%~dp0Launch-ExplorerMeta.vbs" (
  start "" wscript.exe //B "%~dp0Launch-ExplorerMeta.vbs" %*
  exit /b 0
)
if exist "%~dp0Launch-ExplorerMeta.ps1" (
  powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Launch-ExplorerMeta.ps1" %*
  exit /b %ERRORLEVEL%
)

echo Launch-ExplorerMeta.ps1 missing.
if /I not "%~1"=="/quiet" pause
exit /b 1
