/**
 * FAFO opaque Tag Database
 *
 * Vocabulary is stored as AES-GCM encrypted blobs in chrome.storage — not plain JSON
 * arrays anyone can open in LevelDB and read. Per public / private-vault key.
 *
 * Rules:
 * - Tag DB is the source of truth for known tags (unused tags are NEVER auto-wiped).
 * - App always merges media tags INTO the DB (grow-only) and pulls the full vocab on load.
 * - Explicit user delete still removes a tag from the DB.
 */
(function (global) {
    'use strict';

    const KEY_DEVICE = 'fafoTdK'; // device key material (hex) — not the tag text
    const MAGIC = 'FAFOTD1';

    let deviceKeyPromise = null;

    function storageKeyForSpace(spaceKeys) {
        if (spaceKeys && spaceKeys.tagDb) return spaceKeys.tagDb;
        return 'fafoTagDb';
    }

    function publicTagDbKey() {
        return 'fafoTagDb';
    }

    function privateTagDbKey(vaultId) {
        const id = String(vaultId || 'default').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40) || 'default';
        if (id === 'default') return 'fafoTagDbPrivate';
        return `fafoTagDbPrivate_${id}`;
    }

    function bytesToHex(buf) {
        return Array.from(new Uint8Array(buf))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
    }

    function hexToBytes(hex) {
        const h = String(hex || '');
        const out = new Uint8Array(Math.floor(h.length / 2));
        for (let i = 0; i < out.length; i++) {
            out[i] = parseInt(h.substr(i * 2, 2), 16);
        }
        return out;
    }

    function b64FromBytes(bytes) {
        let s = '';
        const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
        for (let i = 0; i < arr.length; i++) s += String.fromCharCode(arr[i]);
        return btoa(s);
    }

    function bytesFromB64(b64) {
        const s = atob(String(b64 || ''));
        const out = new Uint8Array(s.length);
        for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
        return out;
    }

    async function getDeviceKey() {
        if (deviceKeyPromise) return deviceKeyPromise;
        deviceKeyPromise = (async () => {
            const bag = await chrome.storage.local.get([KEY_DEVICE]);
            let hex = bag[KEY_DEVICE];
            if (!hex || String(hex).length < 64) {
                const raw = new Uint8Array(32);
                crypto.getRandomValues(raw);
                hex = bytesToHex(raw);
                await chrome.storage.local.set({ [KEY_DEVICE]: hex });
            }
            return crypto.subtle.importKey(
                'raw',
                hexToBytes(hex),
                { name: 'AES-GCM' },
                false,
                ['encrypt', 'decrypt']
            );
        })();
        return deviceKeyPromise;
    }

    /**
     * @param {object} payload plain { tags, lastUsed?, applyCounts?, version }
     * @returns {Promise<object>} opaque storage record
     */
    async function seal(payload) {
        const key = await getDeviceKey();
        const iv = new Uint8Array(12);
        crypto.getRandomValues(iv);
        const plain = new TextEncoder().encode(JSON.stringify(payload || {}));
        const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plain);
        return {
            v: 1,
            m: MAGIC,
            iv: b64FromBytes(iv),
            ct: b64FromBytes(new Uint8Array(ct)),
            // decoy fields so casual storage viewers see noise, not tag lists
            n: Math.floor(Math.random() * 1e9),
            t: Date.now(),
        };
    }

    /**
     * @param {object} sealed
     * @returns {Promise<object|null>}
     */
    async function open(sealed) {
        if (!sealed || typeof sealed !== 'object') return null;
        if (sealed.m !== MAGIC || !sealed.iv || !sealed.ct) return null;
        try {
            const key = await getDeviceKey();
            const iv = bytesFromB64(sealed.iv);
            const ct = bytesFromB64(sealed.ct);
            const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ct);
            const json = new TextDecoder().decode(plain);
            const data = JSON.parse(json);
            return data && typeof data === 'object' ? data : null;
        } catch (e) {
            console.warn('FAFO TagDB open failed', e);
            return null;
        }
    }

    function normalizeTagList(list) {
        const out = [];
        const seen = new Set();
        (Array.isArray(list) ? list : []).forEach((raw) => {
            const t = String(raw || '').trim().replace(/\s+/g, ' ');
            if (!t) return;
            const low = t.toLowerCase();
            if (seen.has(low)) return;
            seen.add(low);
            out.push(t);
        });
        return out;
    }

    /**
     * Load vocabulary from opaque DB for a storage key.
     * @returns {Promise<{ tags: string[], lastUsed: object, applyCounts: object, ok: boolean }>}
     */
    async function load(dbKey) {
        const key = dbKey || publicTagDbKey();
        const bag = await chrome.storage.local.get([key]);
        const sealed = bag[key];
        const data = await open(sealed);
        if (!data) {
            return { tags: [], lastUsed: {}, applyCounts: {}, ok: false };
        }
        return {
            tags: normalizeTagList(data.tags),
            lastUsed: data.lastUsed && typeof data.lastUsed === 'object' ? { ...data.lastUsed } : {},
            applyCounts:
                data.applyCounts && typeof data.applyCounts === 'object' ? { ...data.applyCounts } : {},
            ok: true,
            updated: data.updated || null,
        };
    }

    /**
     * Save vocabulary into opaque DB. Never drops tags unless caller passes a reduced list.
     */
    async function save(dbKey, { tags, lastUsed, applyCounts }) {
        const key = dbKey || publicTagDbKey();
        const payload = {
            version: 1,
            tags: normalizeTagList(tags),
            lastUsed: lastUsed && typeof lastUsed === 'object' ? lastUsed : {},
            applyCounts: applyCounts && typeof applyCounts === 'object' ? applyCounts : {},
            updated: Date.now(),
        };
        const sealed = await seal(payload);
        await chrome.storage.local.set({ [key]: sealed });
        return { ok: true, count: payload.tags.length };
    }

    /**
     * Merge extra tags into existing DB (grow-only). Used when discovering tags on media.
     */
    async function mergeTags(dbKey, moreTags) {
        const cur = await load(dbKey);
        const set = new Map();
        cur.tags.forEach((t) => set.set(t.toLowerCase(), t));
        normalizeTagList(moreTags).forEach((t) => {
            const low = t.toLowerCase();
            if (!set.has(low)) set.set(low, t);
        });
        const tags = [...set.values()].sort((a, b) =>
            a.localeCompare(b, undefined, { sensitivity: 'base' })
        );
        await save(dbKey, {
            tags,
            lastUsed: cur.lastUsed,
            applyCounts: cur.applyCounts,
        });
        return tags;
    }

    /**
     * Migrate plain fafoTagLibrary (+ counts) into opaque DB if DB empty.
     */
    async function migrateFromPlain(dbKey, plainTags, plainLastUsed, plainCounts) {
        const existing = await load(dbKey);
        if (existing.ok && existing.tags.length) {
            // Still absorb any plain leftovers (grow-only)
            const merged = await mergeTags(dbKey, plainTags || []);
            return { tags: merged, migrated: false, absorbed: true };
        }
        const tags = normalizeTagList(plainTags);
        if (!tags.length && !(plainCounts && Object.keys(plainCounts).length)) {
            return { tags: [], migrated: false };
        }
        await save(dbKey, {
            tags,
            lastUsed: plainLastUsed || {},
            applyCounts: plainCounts || {},
        });
        return { tags, migrated: true };
    }

    /**
     * True if a stored value looks like our sealed blob (not a plain array).
     */
    function isSealedRecord(val) {
        return !!(val && typeof val === 'object' && val.m === MAGIC && val.ct && val.iv);
    }

    global.FAFOTagDb = {
        KEY_DEVICE,
        MAGIC,
        storageKeyForSpace,
        publicTagDbKey,
        privateTagDbKey,
        load,
        save,
        mergeTags,
        migrateFromPlain,
        seal,
        open,
        isSealedRecord,
        normalizeTagList,
    };
})(typeof window !== 'undefined' ? window : globalThis);
