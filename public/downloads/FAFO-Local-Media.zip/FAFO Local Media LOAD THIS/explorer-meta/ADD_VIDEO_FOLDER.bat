@echo off
title FAFO — Add video folder for Explorer metadata
cd /d "%~dp0"

echo.
echo  Add a folder so FAFO can write Tags/Ratings into real files.
echo  The metadata server must already be running (START_META_SERVER.bat).
echo.
set /p FOLDER=Paste full folder path: 
if "%FOLDER%"=="" (
  echo Cancelled.
  pause
  exit /b 1
)

python "%~dp0add_folder.py" "%FOLDER%"
echo.
pause
