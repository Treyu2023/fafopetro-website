/**
 * FAFOViewport — lock floating UI to the actual window.
 *
 * Works the same in windowed or fullscreen: measures the *painted* box
 * via getBoundingClientRect() (includes CSS transforms / scale), then
 * nudges left/top and optionally shrinks width/height until fully inside.
 *
 * Prefer this over hand-rolled max(0, ww-w) math that forgets scale.
 */
(function (global) {
    'use strict';

    const DEFAULT_MARGIN = 4;

    /**
     * Visible browser content box in CSS pixels.
     * Under Ctrl+/- browser zoom (e.g. 50–80% on a TV), clientWidth/Height track the
     * layout viewport correctly. Prefer those over 100vw (vw often disagrees with zoom).
     */
    function viewportBox() {
        const doc = document.documentElement;
        const layoutW = Math.max(1, Math.floor(
            doc.clientWidth || global.innerWidth || 800
        ));
        const layoutH = Math.max(1, Math.floor(
            doc.clientHeight || global.innerHeight || 600
        ));
        const vv = global.visualViewport;
        // Pinch-zoom / mobile: visualViewport can differ; desktop Ctrl-zoom usually matches layout
        if (vv && vv.width > 0 && vv.height > 0) {
            const dw = Math.abs(vv.width - layoutW);
            const dh = Math.abs(vv.height - layoutH);
            // Only prefer visualViewport when it clearly differs (pinch), not noise
            if (dw > 2 || dh > 2 || (vv.offsetLeft || 0) !== 0 || (vv.offsetTop || 0) !== 0) {
                const ox = vv.offsetLeft || 0;
                const oy = vv.offsetTop || 0;
                return {
                    left: ox, top: oy,
                    width: Math.floor(vv.width),
                    height: Math.floor(vv.height),
                    right: ox + Math.floor(vv.width),
                    bottom: oy + Math.floor(vv.height),
                    pageZoomHint: estimatePageZoom(),
                };
            }
        }
        return {
            left: 0, top: 0,
            width: layoutW, height: layoutH,
            right: layoutW, bottom: layoutH,
            pageZoomHint: estimatePageZoom(),
        };
    }

    /** Rough page-zoom estimate (1 = 100%). Useful for diagnostics; layout uses clientWidth. */
    function estimatePageZoom() {
        try {
            // devicePixelRatio includes browser zoom on Chromium; baseline is noisy on HiDPI
            // outer/inner is imperfect but directionally useful on desktop
            if (global.outerWidth && global.innerWidth) {
                const z = global.outerWidth / global.innerWidth;
                if (z > 0.2 && z < 5) return Math.round(z * 100) / 100;
            }
        } catch (_) {}
        return 1;
    }

    function readStylePx(el, prop) {
        const v = parseFloat(el.style[prop] || el.style.getPropertyValue(prop));
        return Number.isFinite(v) ? v : null;
    }

    /**
     * Lock one element fully inside the window.
     * @param {HTMLElement} el
     * @param {object} [opts]
     * @param {number} [opts.margin=4]
     * @param {boolean} [opts.canResize=true] shrink width/height if larger than window
     * @param {number} [opts.minW=80]
     * @param {number} [opts.minH=48]
     * @returns {{ x:number, y:number, w:number, h:number }|null}
     */
    function lock(el, opts = {}) {
        if (!el || !el.getBoundingClientRect) return null;
        if (el.classList?.contains('collapsed') || el.getAttribute('aria-hidden') === 'true') {
            // still allow if visible — collapsed often still in DOM
        }
        const cs = global.getComputedStyle(el);
        if (cs.display === 'none' || cs.visibility === 'hidden') return null;

        const margin = opts.margin != null ? opts.margin : DEFAULT_MARGIN;
        const canResize = opts.canResize !== false;
        const minW = opts.minW != null ? opts.minW : 80;
        const minH = opts.minH != null ? opts.minH : 48;
        const vp = viewportBox();
        const maxVisW = Math.max(minW, vp.width - margin * 2);
        const maxVisH = Math.max(minH, vp.height - margin * 2);

        // Ensure we position with left/top (not right/bottom)
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');

        let left = readStylePx(el, 'left');
        let top = readStylePx(el, 'top');
        let r = el.getBoundingClientRect();

        // Bootstrap left/top from painted rect if missing
        if (left == null || top == null) {
            left = Math.round(r.left);
            top = Math.round(r.top);
            el.style.setProperty('left', `${left}px`, 'important');
            el.style.setProperty('top', `${top}px`, 'important');
            r = el.getBoundingClientRect();
        }

        // 1) If painted size exceeds window, shrink layout size.
        //    scale ≈ painted / offset (handles transform: scale)
        if (canResize) {
            const ow = Math.max(1, el.offsetWidth || r.width);
            const oh = Math.max(1, el.offsetHeight || r.height);
            const scaleX = r.width / ow;
            const scaleY = r.height / oh;
            const scale = Math.max(0.01, Math.min(scaleX || 1, scaleY || 1) || 1);

            if (r.width > maxVisW + 0.5 || r.height > maxVisH + 0.5) {
                const maxLayoutW = Math.max(minW, Math.floor(maxVisW / scale));
                const maxLayoutH = Math.max(minH, Math.floor(maxVisH / scale));
                if (ow > maxLayoutW) {
                    el.style.width = maxLayoutW + 'px';
                    el.style.maxWidth = maxLayoutW + 'px';
                }
                if (oh > maxLayoutH) {
                    el.style.height = maxLayoutH + 'px';
                    el.style.maxHeight = maxLayoutH + 'px';
                }
                r = el.getBoundingClientRect();
            }
        }

        // 2) Nudge so the *painted* box is fully inside the viewport
        let dx = 0;
        let dy = 0;
        if (r.left < vp.left + margin) dx = (vp.left + margin) - r.left;
        else if (r.right > vp.right - margin) dx = (vp.right - margin) - r.right;
        if (r.top < vp.top + margin) dy = (vp.top + margin) - r.top;
        else if (r.bottom > vp.bottom - margin) dy = (vp.bottom - margin) - r.bottom;

        if (dx !== 0 || dy !== 0) {
            left = Math.round(left + dx);
            top = Math.round(top + dy);
            el.style.setProperty('left', `${left}px`, 'important');
            el.style.setProperty('top', `${top}px`, 'important');
            r = el.getBoundingClientRect();
        }

        // 3) Final pass if still overflowing on the opposite edge after nudge
        dx = 0;
        dy = 0;
        if (r.left < vp.left + margin) dx = (vp.left + margin) - r.left;
        if (r.right > vp.right - margin) dx = (vp.right - margin) - r.right;
        if (r.top < vp.top + margin) dy = (vp.top + margin) - r.top;
        if (r.bottom > vp.bottom - margin) dy = (vp.bottom - margin) - r.bottom;
        if (dx !== 0 || dy !== 0) {
            left = Math.round(left + dx);
            top = Math.round(top + dy);
            el.style.setProperty('left', `${left}px`, 'important');
            el.style.setProperty('top', `${top}px`, 'important');
            r = el.getBoundingClientRect();
        }

        return {
            x: Math.round(readStylePx(el, 'left') ?? left),
            y: Math.round(readStylePx(el, 'top') ?? top),
            w: Math.round(el.offsetWidth || r.width),
            h: Math.round(el.offsetHeight || r.height),
            rect: r,
        };
    }

    /** Lock several elements; runs twice across rAF so layout/scale settle. */
    function lockMany(list, opts) {
        const run = () => {
            (list || []).forEach((item) => {
                if (!item) return;
                if (item.nodeType === 1) lock(item, opts);
                else if (item.el) lock(item.el, { ...opts, ...item });
            });
        };
        run();
        requestAnimationFrame(run);
    }

    let scheduled = false;
    const listeners = new Set();

    function onLock(fn) {
        if (typeof fn === 'function') listeners.add(fn);
        return () => listeners.delete(fn);
    }

    function requestLockAll() {
        if (scheduled) return;
        scheduled = true;
        requestAnimationFrame(() => {
            scheduled = false;
            listeners.forEach((fn) => {
                try { fn(); } catch (e) { console.warn('FAFOViewport lock handler', e); }
            });
        });
    }

    let watching = false;
    function watch() {
        if (watching) return;
        watching = true;
        global.addEventListener('resize', requestLockAll, { passive: true });
        if (global.visualViewport) {
            global.visualViewport.addEventListener('resize', requestLockAll, { passive: true });
            global.visualViewport.addEventListener('scroll', requestLockAll, { passive: true });
        }
        // Fullscreen enter/exit
        document.addEventListener('fullscreenchange', requestLockAll);
        document.addEventListener('webkitfullscreenchange', requestLockAll);
    }

    /** Propose left/top for a box of layout size w×h with uniform scale so it fits. */
    function clampPoint(x, y, w, h, scale, margin) {
        margin = margin != null ? margin : DEFAULT_MARGIN;
        scale = scale > 0 ? scale : 1;
        const vp = viewportBox();
        const boxW = Math.max(1, (w || 100) * scale);
        const boxH = Math.max(1, (h || 100) * scale);
        const maxX = Math.max(margin, vp.width - boxW - margin);
        const maxY = Math.max(margin, vp.height - boxH - margin);
        return {
            x: Math.round(Math.max(margin, Math.min(maxX, Number(x) || 0))),
            y: Math.round(Math.max(margin, Math.min(maxY, Number(y) || 0))),
            maxW: Math.max(1, Math.floor((vp.width - margin * 2) / scale)),
            maxH: Math.max(1, Math.floor((vp.height - margin * 2) / scale)),
            vp,
        };
    }

    /** 'fullscreen' | 'windowed' — used for dual layout memory slots. */
    function layoutMode() {
        try {
            if (document.fullscreenElement || document.webkitFullscreenElement) return 'fullscreen';
        } catch (_) {}
        return 'windowed';
    }

    /**
     * Normalize pixel placement to fractions of the current viewport (0–1).
     * Survives resize / fullscreen much better than raw left/top alone.
     */
    function toNorm(x, y, w, h) {
        const vp = viewportBox();
        const pw = Math.max(1, vp.width);
        const ph = Math.max(1, vp.height);
        return {
            nx: (Number(x) || 0) / pw,
            ny: (Number(y) || 0) / ph,
            nw: w != null ? (Number(w) || 0) / pw : null,
            nh: h != null ? (Number(h) || 0) / ph : null,
            vpW: pw,
            vpH: ph,
            mode: layoutMode(),
        };
    }

    /**
     * Expand a normalized slot back to pixels for the *current* viewport.
     * Falls back to absolute x/y if norms are missing.
     */
    function fromNorm(slot, opts = {}) {
        const vp = viewportBox();
        const margin = opts.margin != null ? opts.margin : DEFAULT_MARGIN;
        if (!slot || typeof slot !== 'object') {
            return { x: margin, y: margin, w: null, h: null, vp };
        }
        let x;
        let y;
        let w = null;
        let h = null;
        if (typeof slot.nx === 'number' && typeof slot.ny === 'number') {
            x = Math.round(slot.nx * vp.width);
            y = Math.round(slot.ny * vp.height);
        } else if (typeof slot.x === 'number' && typeof slot.y === 'number'
            && slot.vpW > 0 && slot.vpH > 0
            && (Math.abs(slot.vpW - vp.width) > 8 || Math.abs(slot.vpH - vp.height) > 8)) {
            // Remap absolute coords proportionally when viewport changed
            x = Math.round((slot.x / slot.vpW) * vp.width);
            y = Math.round((slot.y / slot.vpH) * vp.height);
        } else {
            x = Math.round(Number(slot.x) || 0);
            y = Math.round(Number(slot.y) || 0);
        }
        if (typeof slot.nw === 'number' && slot.nw > 0) w = Math.round(slot.nw * vp.width);
        else if (typeof slot.w === 'number' && slot.vpW > 0 && Math.abs(slot.vpW - vp.width) > 8) {
            w = Math.round((slot.w / slot.vpW) * vp.width);
        } else if (typeof slot.w === 'number') w = Math.round(slot.w);
        if (typeof slot.nh === 'number' && slot.nh > 0) h = Math.round(slot.nh * vp.height);
        else if (typeof slot.h === 'number' && slot.vpH > 0 && Math.abs(slot.vpH - vp.height) > 8) {
            h = Math.round((slot.h / slot.vpH) * vp.height);
        } else if (typeof slot.h === 'number') h = Math.round(slot.h);

        // Soft clamp into viewport (leave final painted lock to lock())
        const maxX = Math.max(margin, vp.width - margin - 40);
        const maxY = Math.max(margin, vp.height - margin - 40);
        x = Math.max(margin, Math.min(maxX, x));
        y = Math.max(margin, Math.min(maxY, y));
        return { x, y, w, h, vp };
    }

    /**
     * Remap a free-float point when the viewport size changes (stick mode).
     * Keeps relative placement instead of slamming to corners.
     */
    function remapOnResize(x, y, prevVpW, prevVpH) {
        const vp = viewportBox();
        if (!(prevVpW > 0) || !(prevVpH > 0)) {
            return { x: Math.round(Number(x) || 0), y: Math.round(Number(y) || 0), vp };
        }
        // Ignore tiny noise (scrollbar / zoom jitter)
        if (Math.abs(prevVpW - vp.width) < 6 && Math.abs(prevVpH - vp.height) < 6) {
            return { x: Math.round(Number(x) || 0), y: Math.round(Number(y) || 0), vp };
        }
        return {
            x: Math.round(((Number(x) || 0) / prevVpW) * vp.width),
            y: Math.round(((Number(y) || 0) / prevVpH) * vp.height),
            vp,
        };
    }

    global.FAFOViewport = {
        margin: DEFAULT_MARGIN,
        viewportBox,
        estimatePageZoom,
        layoutMode,
        toNorm,
        fromNorm,
        remapOnResize,
        lock,
        lockMany,
        clampPoint,
        onLock,
        requestLockAll,
        watch,
    };
})(typeof window !== 'undefined' ? window : globalThis);
