@echo off
setlocal
cd /d "%~dp0"
title FAFO — Clear ALL junk / long tags from files
echo.
echo  ================================================
echo   FAFO FIX-ALL — strip long / Signature / Comfy tags
echo   from every indexed video (writes Explorer keywords)
echo  ================================================
echo.
echo  This rewrites Windows tags on disk. Export a FAFO
echo  tags backup first if you care about rolling back.
echo.
echo  Criteria: over 100 chars, Signature dumps, ComfyUI,
echo  AI prompts, paths, JSON, base64 noise.
echo.
pause

REM Prefer project venv python if present, else PATH
set PY=
if exist "..\..\..\HTML Toolbox AI tools\production\.venv\Scripts\python.exe" (
  set "PY=..\..\..\HTML Toolbox AI tools\production\.venv\Scripts\python.exe"
)
if exist "C:\_Git\repos\html\HTML Toolbox AI tools\production\.venv\Scripts\python.exe" (
  set "PY=C:\_Git\repos\html\HTML Toolbox AI tools\production\.venv\Scripts\python.exe"
)
if "%PY%"=="" set PY=python

echo Using: %PY%
echo.
echo [1/2] Dry-run scan...
"%PY%" scrub_all_junk_tags.py --dry-run
echo.
echo [2/2] REWRITE all dirty files...
"%PY%" scrub_all_junk_tags.py
echo.
echo Done. In Chrome FAFO new-tab: open Tags panel and click "Clear junk..."
echo to clean extension storage too (or reload new-tab — auto-scrub runs on load).
echo.
pause
