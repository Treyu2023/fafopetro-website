@echo off
title FAFO Explorer Metadata Server
cd /d "%~dp0"

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found. Run INSTALL_DEPS.bat first.
  pause
  exit /b 1
)

REM Ensure deps exist (quiet)
python -c "import fastapi, uvicorn, mutagen" 2>nul
if errorlevel 1 (
  echo Missing packages — running INSTALL_DEPS.bat ...
  call "%~dp0INSTALL_DEPS.bat"
)

python -c "from win32com.propsys import propsys" 2>nul
if errorlevel 1 (
  echo Installing pywin32...
  python -m pip install -q pywin32
)

echo.
echo  Starting FAFO Explorer Metadata Server on http://127.0.0.1:8765
echo  Leave this window open while you use FAFO tags / ratings.
echo.

python "%~dp0server.py"
if errorlevel 1 (
  echo.
  echo  Server exited with an error.
  pause
)
