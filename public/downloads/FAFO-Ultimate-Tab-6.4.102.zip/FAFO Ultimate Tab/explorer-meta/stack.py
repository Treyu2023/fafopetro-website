#!/usr/bin/env python3
"""
FAFO companion stack — deps, metadata server, salvage ledger apply.

Used by APPLY_PENDING_LEDGER.bat, LAUNCH_FAFO_STACK.bat, and the Chrome
native-messaging / fafo-companion:// auto-launch path.

Boot is fast: start the HTTP server, return when /api/health is up.
Ledger apply runs in a background thread so Chrome does not time out.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

ROOT = os.path.dirname(os.path.abspath(__file__))
HEALTH = "http://127.0.0.1:8765/api/health"
APPLY = "http://127.0.0.1:8765/api/fafo/ledger/apply"


def note_s2_demand(app: str = "fafo-stack-boot") -> None:
    """Watchdog reads this file and keeps S2 up while FAFO is in use.

    Opening Ultimate Tab is an explicit start. Clear S2 sleep so the
    watchdog does not leave the tag server down after the user asked for it.
    """
    try:
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~\\AppData\\Local")
        folder = os.path.join(base, "FAFO")
        os.makedirs(folder, exist_ok=True)
        with open(os.path.join(folder, "demand-s2.json"), "w", encoding="utf-8") as f:
            json.dump({"at": time.time(), "app": app, "which": "s2"}, f)
        prefs_path = os.path.join(folder, "launch-prefs.json")
        if os.path.isfile(prefs_path):
            with open(prefs_path, encoding="utf-8") as f:
                prefs = json.load(f)
            if isinstance(prefs, dict):
                sleep = prefs.get("serversSleeping")
                if not isinstance(sleep, dict):
                    sleep = {}
                sleep["fafoMetaServer"] = False
                prefs["serversSleeping"] = sleep
                hold = prefs.get("manualHold")
                if not isinstance(hold, dict):
                    hold = {}
                hold["fafoMetaServer"] = True
                prefs["manualHold"] = hold
                sessions = prefs.get("sessions")
                if isinstance(sessions, dict):
                    sessions["fafoMediaActive"] = True
                prefs["updatedAt"] = time.strftime("%Y-%m-%dT%H:%M:%S")
                with open(prefs_path, "w", encoding="utf-8") as f:
                    json.dump(prefs, f, indent=2)
                    f.write("\n")
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        pass


def log(msg: str) -> None:
    print(f"[FAFO stack] {msg}", flush=True)


def health() -> bool:
    try:
        with urllib.request.urlopen(HEALTH, timeout=2) as r:
            if not (200 <= r.status < 300):
                return False
            raw = r.read().decode("utf-8", "replace") or "{}"
        try:
            body = json.loads(raw)
        except json.JSONDecodeError:
            return True
        svc = str((body or {}).get("service") or "")
        if svc and "fafo" not in svc.lower():
            return False
        return True
    except Exception:
        return False


def ensure_deps() -> None:
    try:
        import fastapi  # noqa: F401
        import mutagen  # noqa: F401
        import uvicorn  # noqa: F401
    except ImportError:
        req = os.path.join(ROOT, "requirements.txt")
        log("Installing Python packages (one-time)…")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "-r", req])
    try:
        from win32com.propsys import propsys  # noqa: F401
    except Exception:
        log("Installing pywin32…")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "pywin32"])


def _popen_hidden(args: list[str]) -> None:
    kwargs: dict = {
        "cwd": ROOT,
        "stdout": subprocess.DEVNULL,
        "stderr": subprocess.DEVNULL,
        "stdin": subprocess.DEVNULL,
        "close_fds": True,
    }
    if os.name == "nt":
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(
            subprocess, "DETACHED_PROCESS", 0
        ) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
        kwargs["creationflags"] = flags
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        kwargs["startupinfo"] = si
    else:
        kwargs["start_new_session"] = True
    subprocess.Popen(args, **kwargs)


def start_server() -> None:
    if health():
        log("Server already running on 127.0.0.1:8765")
        return
    log("Starting Explorer metadata server…")
    script = os.path.join(ROOT, "server.py")
    _popen_hidden([sys.executable, "-u", script, "--watch"])


def wait_health(timeout: float = 16.0) -> bool:
    t0 = time.time()
    while time.time() - t0 < timeout:
        if health():
            log("Server healthy")
            return True
        time.sleep(0.35)
    log("Server did not become healthy in time")
    return False


def apply_ledger() -> list[tuple[str, dict]]:
    out: list[tuple[str, dict]] = []
    for space in ("public", "private"):
        req = urllib.request.Request(
            APPLY,
            data=json.dumps({"space": space}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                body = json.loads(r.read().decode("utf-8") or "{}")
            log(
                f"{space}: applied={body.get('applied')} "
                f"failed={body.get('failed')} deferred={body.get('deferred')}"
            )
            out.append((space, body if isinstance(body, dict) else {"ok": True}))
        except Exception as e:
            log(f"{space} apply failed: {e}")
            out.append((space, {"ok": False, "error": str(e)}))
    return out


def apply_ledger_bg() -> None:
    threading.Thread(target=apply_ledger, daemon=True, name="fafo-ledger").start()


def boot(delay: float = 0.4) -> list[tuple[str, dict]]:
    """Bring S2 up quickly. Ledger apply is background so Chrome can return."""
    note_s2_demand("fafo-stack-boot")
    try:
        ensure_deps()
    except Exception as e:
        log(f"deps warning: {e}")
    if not health():
        start_server()
        wait_health()
    if delay > 0:
        time.sleep(min(delay, 1.5))
    if health():
        apply_ledger_bg()
        return [("background", {"ok": True, "deferred": True})]
    log("Skip ledger apply — server not up")
    return []


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    cmd = (argv[0] if argv else "boot").lower()
    delay = 0.4
    if "--delay" in argv:
        i = argv.index("--delay")
        try:
            delay = float(argv[i + 1])
        except (IndexError, ValueError):
            delay = 0.4
    if cmd in ("boot", "apply"):
        if cmd == "apply":
            note_s2_demand("fafo-stack-apply")
            if not health():
                try:
                    ensure_deps()
                except Exception:
                    pass
                start_server()
                wait_health()
            apply_ledger()
        else:
            boot(delay=delay)
        return 0
    if cmd == "health":
        ok = health()
        print("up" if ok else "down")
        return 0 if ok else 1
    if cmd == "server":
        try:
            ensure_deps()
        except Exception:
            pass
        start_server()
        return 0 if wait_health() else 1
    print("usage: stack.py boot|apply|health|server [--delay N]")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
