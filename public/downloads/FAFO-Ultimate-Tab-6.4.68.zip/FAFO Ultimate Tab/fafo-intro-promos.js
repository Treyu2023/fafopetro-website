/**
 * FAFO Intro Promos — up to 4 boot video intros (folder-linked).
 *
 * - Shuffle residual queue per slot (persist in chrome.storage) so the same
 *   clip is not repeated until the deck is exhausted.
 * - Each promo plays ONE full loop (until video ends), individually skippable.
 * - Slot 4 is sponsored by BOFA Deez Teas (branding overlay + tagline).
 */
(function (global) {
  'use strict';

  const VIDEO_RE = /\.(mp4|webm|mkv|mov|m4v|avi)$/i;
  const STORAGE_KEY = 'fafoIntroPromos';
  const QUEUE_KEY = 'fafoIntroPromoQueues';

  const BOFA = {
    name: 'BOFA Deez Teas',
    tagline: 'Suck one down today at a retailer near you!',
    short: 'Sponsored · BOFA Deez Teas',
  };

  const DEFAULT_SLOTS = [
    { id: 1, key: 'intro-promo-1', label: 'Intro 1', enabled: true, sponsored: false },
    { id: 2, key: 'intro-promo-2', label: 'Intro 2', enabled: true, sponsored: false },
    { id: 3, key: 'intro-promo-3', label: 'Intro 3', enabled: true, sponsored: false },
    {
      id: 4,
      key: 'intro-promo-4',
      label: 'BOFA Deez Teas',
      enabled: true,
      sponsored: true,
      sponsor: { ...BOFA },
    },
  ];

  const DEFAULTS = {
    enabled: true,
    shuffle: true,
    playToEnd: true,
    showSplashAfter: false,
    slots: DEFAULT_SLOTS.map((s) => ({ ...s, sponsor: s.sponsor ? { ...s.sponsor } : undefined })),
  };

  function deepDefaults() {
    return JSON.parse(JSON.stringify(DEFAULTS));
  }

  async function readConfig() {
    try {
      const res = await chrome.storage.local.get(STORAGE_KEY);
      const raw = res[STORAGE_KEY];
      if (!raw || typeof raw !== 'object') return deepDefaults();
      const base = deepDefaults();
      const slots = DEFAULT_SLOTS.map((def, i) => {
        const got = Array.isArray(raw.slots) ? raw.slots.find((s) => s.id === def.id) || raw.slots[i] : null;
        return {
          ...def,
          enabled: got && typeof got.enabled === 'boolean' ? got.enabled : def.enabled,
          label: (got && got.label) || def.label,
          sponsor: def.sponsored ? { ...BOFA, ...(got?.sponsor || {}) } : undefined,
        };
      });
      return {
        enabled: raw.enabled !== false,
        shuffle: raw.shuffle !== false,
        playToEnd: raw.playToEnd !== false,
        showSplashAfter: !!raw.showSplashAfter,
        slots,
      };
    } catch {
      return deepDefaults();
    }
  }

  async function writeConfig(partial) {
    const cur = await readConfig();
    const next = {
      ...cur,
      ...partial,
      slots: partial.slots
        ? DEFAULT_SLOTS.map((def) => {
            const g = partial.slots.find((s) => s.id === def.id) || {};
            return {
              ...def,
              enabled: typeof g.enabled === 'boolean' ? g.enabled : def.enabled,
              label: g.label || def.label,
              sponsor: def.sponsored ? { ...BOFA, ...(g.sponsor || {}) } : undefined,
            };
          })
        : cur.slots,
    };
    await chrome.storage.local.set({ [STORAGE_KEY]: next });
    return next;
  }

  async function readQueues() {
    try {
      const res = await chrome.storage.local.get(QUEUE_KEY);
      return res[QUEUE_KEY] && typeof res[QUEUE_KEY] === 'object' ? res[QUEUE_KEY] : {};
    } catch {
      return {};
    }
  }

  async function writeQueues(q) {
    await chrome.storage.local.set({ [QUEUE_KEY]: q || {} });
  }

  function shuffleInPlace(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const t = arr[i];
      arr[i] = arr[j];
      arr[j] = t;
    }
    return arr;
  }

  async function getFolderByKey(key) {
    if (!global.FAFOLibrary?.openDB || !global.FAFOLibrary?.listFolders) return null;
    try {
      const db = await FAFOLibrary.openDB();
      const folders = await FAFOLibrary.listFolders(db);
      return folders.find((f) => f.id === key || f.kind === key || f.promoKey === key) || null;
    } catch {
      return null;
    }
  }

  async function listVideos(folder) {
    if (!folder?.handle) return [];
    const ok = await FAFOLibrary.ensurePermission(folder.handle, 'read');
    if (!ok) return [];
    const out = [];
    try {
      for await (const entry of folder.handle.values()) {
        if (entry.kind === 'file' && VIDEO_RE.test(entry.name)) out.push(entry);
      }
    } catch (e) {
      console.warn('FAFO intro promos list', e);
    }
    out.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
    return out;
  }

  /**
   * Residual shuffle deck: pick next file name, rebuild when empty.
   * Persists so reopening the tab does not restart the same first clips.
   */
  async function pickNextVideo(slotKey, handles, shuffle) {
    if (!handles.length) return null;
    const names = handles.map((h) => h.name);
    const nameSet = new Set(names);
    const queues = await readQueues();
    let deck = Array.isArray(queues[slotKey]) ? queues[slotKey].filter((n) => nameSet.has(n)) : [];

    if (!deck.length) {
      deck = names.slice();
      if (shuffle) shuffleInPlace(deck);
    }

    const nextName = deck.shift();
    queues[slotKey] = deck;
    await writeQueues(queues);

    return handles.find((h) => h.name === nextName) || handles[0];
  }

  async function linkSlotFolder(slotId) {
    if (!global.showDirectoryPicker) throw new Error('Folder picker not supported in this browser');
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) throw new Error('Unknown intro slot');

    const handle = await showDirectoryPicker({
      id: 'fafo-' + slot.key,
      mode: 'read',
    });
    const db = await FAFOLibrary.openDB();
    // Replace previous folder with same key
    try {
      if (db.objectStoreNames.contains('folders')) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').put({
          id: slot.key,
          kind: slot.key,
          promoKey: slot.key,
          storeName: 'videos',
          name: handle.name || slot.label,
          handle,
          addedAt: Date.now(),
          lastSyncedAt: Date.now(),
          fileCount: 0,
          introPromo: true,
          slotId,
        });
        await new Promise((res, rej) => {
          tx.oncomplete = () => res();
          tx.onerror = () => rej(tx.error);
        });
      }
    } catch (e) {
      console.warn('intro promo folder save', e);
      throw e;
    }

    // Reset residual queue for this slot so new library builds a fresh deck
    const q = await readQueues();
    delete q[slot.key];
    await writeQueues(q);

    const vids = await listVideos({ handle });
    return { folderName: handle.name, count: vids.length, slot };
  }

  async function clearSlotFolder(slotId) {
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) return;
    try {
      const db = await FAFOLibrary.openDB();
      if (db.objectStoreNames.contains('folders')) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').delete(slot.key);
        await new Promise((res) => {
          tx.oncomplete = () => res();
          tx.onerror = () => res();
        });
      }
    } catch (_) {}
    const q = await readQueues();
    delete q[slot.key];
    await writeQueues(q);
  }

  async function slotStatus(slotId) {
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) return null;
    const folder = await getFolderByKey(slot.key);
    let count = 0;
    if (folder) {
      try {
        count = (await listVideos(folder)).length;
      } catch (_) {}
    }
    const q = await readQueues();
    const remaining = Array.isArray(q[slot.key]) ? q[slot.key].length : null;
    return {
      slot,
      folderName: folder?.name || null,
      linked: !!folder?.handle,
      count,
      queueRemaining: remaining,
    };
  }

  function ensureOverlay() {
    let el = document.getElementById('fafo-intro-promo');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'fafo-intro-promo';
    el.className = 'fafo-intro-promo hidden';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-label', 'Intro promo');
    el.innerHTML = `
      <div class="fip-bg-pattern" aria-hidden="true"></div>
      <div class="fip-frame" aria-hidden="true">
        <span class="fip-corner tl"></span><span class="fip-corner tr"></span>
        <span class="fip-corner bl"></span><span class="fip-corner br"></span>
      </div>
      <video class="fip-video" playsinline></video>
      <div class="fip-chrome">
        <div class="fip-top">
          <div class="fip-slot-label"></div>
          <div class="fip-sponsor hidden"></div>
        </div>
        <div class="fip-bottom">
          <div class="fip-progress"><div class="fip-progress-fill"></div></div>
          <div class="fip-actions">
            <button type="button" class="fip-skip" title="Skip this intro (Esc)">Skip intro · Esc</button>
            <button type="button" class="fip-skip-all" title="Skip all remaining intros">Skip all</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(el);
    return el;
  }

  function playFile(videoEl, file) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      let settled = false;
      const done = (err) => {
        if (settled) return;
        settled = true;
        try { URL.revokeObjectURL(url); } catch (_) {}
        videoEl.removeAttribute('src');
        try { videoEl.load(); } catch (_) {}
        if (err) reject(err);
        else resolve();
      };
      videoEl.onended = () => done();
      videoEl.onerror = () => done(new Error('video error'));
      videoEl.src = url;
      videoEl.currentTime = 0;
      videoEl.muted = false;
      videoEl.play().catch(() => {
        // Autoplay policy: mute and retry
        videoEl.muted = true;
        videoEl.play().catch(() => done(new Error('play blocked')));
      });
    });
  }

  /**
   * Play all enabled intro promos in slot order (1→4).
   * Within each slot, next residual-shuffled video plays once to the end.
   */
  async function playBootSequence(opts = {}) {
    const cfg = await readConfig();
    if (!cfg.enabled) return { played: 0, skipped: true };

    const root = ensureOverlay();
    const videoEl = root.querySelector('.fip-video');
    const slotLabel = root.querySelector('.fip-slot-label');
    const sponsorEl = root.querySelector('.fip-sponsor');
    const fill = root.querySelector('.fip-progress-fill');
    const btnSkip = root.querySelector('.fip-skip');
    const btnSkipAll = root.querySelector('.fip-skip-all');

    let skipOne = false;
    let skipAll = false;
    let progressTimer = null;

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        skipOne = true;
        try { videoEl.pause(); } catch (_) {}
        try { videoEl.currentTime = videoEl.duration || 0; } catch (_) {}
      }
    };

    btnSkip.onclick = () => {
      skipOne = true;
      try { videoEl.pause(); } catch (_) {}
      try { videoEl.currentTime = videoEl.duration || 0; } catch (_) {}
    };
    btnSkipAll.onclick = () => {
      skipAll = true;
      skipOne = true;
      try { videoEl.pause(); } catch (_) {}
      try { videoEl.currentTime = videoEl.duration || 0; } catch (_) {}
    };

    document.addEventListener('keydown', onKey, true);
    root.classList.remove('hidden');
    document.body.classList.add('fafo-intro-promo-active');

    let played = 0;
    try {
      for (const slot of cfg.slots) {
        if (skipAll) break;
        if (!slot.enabled) continue;

        const folder = await getFolderByKey(slot.key);
        if (!folder?.handle) {
          opts.onStatus?.(`${slot.label}: no folder linked`);
          continue;
        }

        const handles = await listVideos(folder);
        if (!handles.length) {
          opts.onStatus?.(`${slot.label}: empty folder`);
          continue;
        }

        const pick = await pickNextVideo(slot.key, handles, cfg.shuffle);
        if (!pick) continue;

        skipOne = false;
        if (slotLabel) {
          slotLabel.textContent = slot.sponsored
            ? `Intro ${slot.id} · Sponsored`
            : `Intro ${slot.id} · ${slot.label}`;
        }
        if (sponsorEl) {
          if (slot.sponsored) {
            const sp = slot.sponsor || BOFA;
            sponsorEl.classList.remove('hidden');
            sponsorEl.innerHTML =
              `<strong>${escapeHtml(sp.name || BOFA.name)}</strong>` +
              `<span>${escapeHtml(sp.tagline || BOFA.tagline)}</span>`;
            root.classList.add('fip-sponsored');
          } else {
            sponsorEl.classList.add('hidden');
            sponsorEl.innerHTML = '';
            root.classList.remove('fip-sponsored');
          }
        }

        opts.onStatus?.(
          slot.sponsored
            ? `Sponsored by ${BOFA.name}…`
            : `Playing ${slot.label}: ${pick.name}`
        );

        let file;
        try {
          file = await pick.getFile();
        } catch (e) {
          console.warn('intro promo getFile', e);
          continue;
        }

        clearInterval(progressTimer);
        progressTimer = setInterval(() => {
          if (!videoEl.duration || !fill) return;
          const p = Math.min(100, (videoEl.currentTime / videoEl.duration) * 100);
          fill.style.width = p + '%';
        }, 120);

        try {
          await playFile(videoEl, file);
          played += 1;
        } catch (e) {
          console.warn('intro promo play', e);
        }
        clearInterval(progressTimer);
        if (fill) fill.style.width = '100%';

        if (skipOne && !skipAll) {
          // continue to next slot
          continue;
        }
      }
    } finally {
      clearInterval(progressTimer);
      document.removeEventListener('keydown', onKey, true);
      root.classList.add('hidden');
      document.body.classList.remove('fafo-intro-promo-active');
      root.classList.remove('fip-sponsored');
      try {
        videoEl.pause();
        videoEl.removeAttribute('src');
        videoEl.load();
      } catch (_) {}
    }

    return { played, skipped: skipAll };
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  global.FAFOIntroPromos = {
    BOFA,
    DEFAULT_SLOTS,
    readConfig,
    writeConfig,
    linkSlotFolder,
    clearSlotFolder,
    slotStatus,
    listVideos,
    getFolderByKey,
    playBootSequence,
    readQueues,
  };
})(typeof window !== 'undefined' ? window : globalThis);
