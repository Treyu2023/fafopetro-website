@echo off
setlocal EnableExtensions
title FAFO — stop meta server
cd /d "%~dp0"

echo.
echo  Stopping anything listening on 127.0.0.1:8765 ...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$con = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue;" ^
  "if (-not $con) { Write-Host '  Nothing listening on 8765.'; exit 0 }" ^
  "$pids = @($con | Select-Object -ExpandProperty OwningProcess -Unique);" ^
  "foreach ($pid in $pids) {" ^
  "  if ($pid -and $pid -gt 0) {" ^
  "    try {" ^
  "      $p = Get-Process -Id $pid -ErrorAction Stop;" ^
  "      Write-Host ('  Killing PID {0} ({1})' -f $pid, $p.ProcessName);" ^
  "      Stop-Process -Id $pid -Force -ErrorAction Stop;" ^
  "    } catch { Write-Host ('  Failed PID {0}: {1}' -f $pid, $_.Exception.Message) }" ^
  "  }" ^
  "}" ^
  "Start-Sleep -Milliseconds 500;" ^
  "if (Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue) {" ^
  "  Write-Host '  [WARN] Port still in use.'; exit 1" ^
  "} else { Write-Host '  [OK] Port 8765 is free.' }"

echo.
pause
