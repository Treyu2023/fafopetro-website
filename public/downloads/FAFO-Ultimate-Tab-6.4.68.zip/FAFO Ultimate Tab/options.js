document.addEventListener('DOMContentLoaded', async () => {
    const $ = id => document.getElementById(id);
    let db = null;
    let currentConfig = {};
    let editingFile = null;

    // --- STATE ---
    let currentPage = 1;
    let itemsPerPage = 50;
    let allLibraryItems = []; 
    let activePlaylistView = 'all';
    /** Named custom themes (pack base + colors + animations). */
    let customThemes = [];
    let selectedCustomThemeId = '';
    /** Discreet private workspace (synced from new-tab private mode) */
    let privateOptionsMode = false;
    /** Active private vault id while Options is in private shell */
    let privateOptionsVaultId = 'default';
    let escapeTapAt = 0;

    // --- TOAST NOTIFICATION SYSTEM ---
    function showToast(msg, type = 'success') {
        const status = $('save-status');
        if (!status) return;
        status.textContent = msg;
        status.style.borderColor = type === 'error' ? '#ff4444' : (privateOptionsMode ? '#c084fc' : '#00e5ff');
        status.style.color = type === 'error' ? '#ff4444' : (privateOptionsMode ? '#e9d5ff' : '#00e5ff');
        status.style.display = 'block';
        setTimeout(() => status.style.display = 'none', 3000);
    }

    async function readPrivateSession() {
        try {
            const { fafoPrivateSession } = await chrome.storage.local.get('fafoPrivateSession');
            if (fafoPrivateSession?.vaultId) {
                privateOptionsVaultId = String(fafoPrivateSession.vaultId);
            }
            return !!(fafoPrivateSession && fafoPrivateSession.active && fafoPrivateSession.unlocked);
        } catch {
            return false;
        }
    }

    async function clearPrivateSession() {
        try {
            await chrome.storage.local.set({
                fafoPrivateSession: { active: false, unlocked: false, at: Date.now() },
            });
        } catch (_) {}
    }

    function ensurePrivateBanner() {
        let bar = document.getElementById('fafo-private-options-banner');
        if (bar) return bar;
        bar = document.createElement('div');
        bar.id = 'fafo-private-options-banner';
        bar.innerHTML = `
            <span style="font-weight:700;letter-spacing:0.06em;">Private workspace</span>
            <span style="opacity:0.75;font-size:0.85rem;">Only private folders &amp; tags · public library hidden</span>
            <span style="opacity:0.55;font-size:0.8rem;margin-left:auto;">Esc twice → normal mode</span>
            <button type="button" id="fafo-private-options-exit" class="btn btn-ghost" style="width:auto;padding:6px 12px;">Exit</button>
        `;
        bar.style.cssText = [
            'display:none',
            'align-items:center',
            'gap:12px',
            'flex-wrap:wrap',
            'padding:10px 16px',
            'background:linear-gradient(90deg,rgba(60,10,80,0.95),rgba(20,0,30,0.98))',
            'border-bottom:1px solid rgba(180,100,255,0.35)',
            'color:#f3e8ff',
            'position:sticky',
            'top:0',
            'z-index:50',
        ].join(';');
        const main = document.querySelector('main');
        if (main && main.parentNode) {
            main.parentNode.insertBefore(bar, main);
        } else {
            document.body.prepend(bar);
        }
        bar.querySelector('#fafo-private-options-exit')?.addEventListener('click', () => exitPrivateOptionsMode());
        return bar;
    }

    /**
     * Discreet private Options: hide public library/backup/pairing tabs;
     * only private folders appear; neutral branding.
     */
    async function applyPrivateOptionsShell(active) {
        privateOptionsMode = !!active;
        document.body.classList.toggle('fafo-private-options', privateOptionsMode);
        const bar = ensurePrivateBanner();
        bar.style.display = privateOptionsMode ? 'flex' : 'none';

        const brand = document.querySelector('.brand');
        if (brand) {
            if (!brand.dataset.publicLabel) brand.dataset.publicLabel = brand.textContent || 'FAFO';
            brand.textContent = privateOptionsMode ? 'Private' : brand.dataset.publicLabel;
        }

        // Tabs allowed in private (no public library / backup / pairing leakage)
        const allowed = new Set(['view-library', 'view-tags', 'view-tag-themes', 'view-theme', 'view-scale']);
        document.querySelectorAll('.tab').forEach((tab) => {
            const t = tab.dataset.target;
            const show = !privateOptionsMode || allowed.has(t);
            tab.style.display = show ? '' : 'none';
            if (privateOptionsMode && t === 'view-library') {
                tab.textContent = '📁 Private library';
            } else if (!privateOptionsMode && t === 'view-library') {
                tab.textContent = '📂 Visual Library';
            }
        });
        document.querySelectorAll('.nav-group').forEach((g) => {
            if (!privateOptionsMode) {
                g.style.display = '';
                return;
            }
            // Hide nav groups that have zero visible tabs following them until next group
            let el = g.nextElementSibling;
            let any = false;
            while (el && !el.classList.contains('nav-group') && !el.classList.contains('actions')) {
                if (el.classList.contains('tab') && el.style.display !== 'none') any = true;
                el = el.nextElementSibling;
            }
            g.style.display = any ? '' : 'none';
            if (g.textContent.trim() === 'Library' && any) g.textContent = 'Private';
            else if (g.textContent.trim() === 'Private' && !privateOptionsMode) g.textContent = 'Library';
        });

        // Force library view if current tab hidden
        if (privateOptionsMode) {
            const activeTab = document.querySelector('.tab.active');
            if (activeTab && activeTab.style.display === 'none') {
                const lib = document.querySelector('.tab[data-target="view-library"]');
                if (lib) lib.click();
            }
            // Soften page chrome
            document.documentElement.style.setProperty('--accent', '#c084fc');
            document.documentElement.style.setProperty('--accent-glow', 'rgba(192,132,252,0.45)');
        } else {
            // Let theme engine restore; mild reset
            document.documentElement.style.removeProperty('--accent');
            document.documentElement.style.removeProperty('--accent-glow');
        }

        allLibraryItems = [];
        if (db) {
            try {
                await loadLibraryGrid();
                await refreshLinkedFoldersUI();
            } catch (_) {}
        }
    }

    async function exitPrivateOptionsMode() {
        await clearPrivateSession();
        await applyPrivateOptionsShell(false);
        showToast('Normal mode');
        // Soft reload so all public UIs rehydrate cleanly
        setTimeout(() => location.reload(), 400);
    }

    async function refreshPrivateOptionsMode() {
        const on = await readPrivateSession();
        if (on !== privateOptionsMode) {
            await applyPrivateOptionsShell(on);
        }
    }

    /** Full JSON backup (options + playlists + file catalog + tags) on every meaningful save. */
    let fullBackupTimer = null;
    function scheduleFullBackup(reason) {
        clearTimeout(fullBackupTimer);
        fullBackupTimer = setTimeout(() => {
            if (!window.FAFOBackup?.afterLiveSave) return;
            FAFOBackup.afterLiveSave(
                { mediaConfig: currentConfig || {} },
                reason || 'options-save'
            ).catch((e) => console.warn('FAFO full backup', e));
        }, 250);
    }

    // --- Chrome Art (random bg + optional locked panel crop) ---
    function paintChromeArtTileGallery(cfg) {
        const host = $('chrome-art-tile-gallery');
        const TP = window.FAFOTilePatterns;
        const TC = window.FAFOTagColors;
        if (!host) return;
        const list = (TP && Array.isArray(TP.CATALOG) && TP.CATALOG.length)
            ? TP.CATALOG
            : (TC && Array.isArray(TC.TILE_PATTERNS) ? TC.TILE_PATTERNS : []);
        const selected = cfg?.tilePattern || 'circuit';
        const scale = Number(cfg?.tileScale) || 28;
        const lab = $('chrome-art-tile-label');
        const meta = list.find((p) => p.id === selected);
        if (lab) lab.textContent = 'Pattern: ' + (meta?.label || selected);
        host.innerHTML = list.map((p) =>
            `<button type="button" class="tcs-pat${p.id === selected ? ' on' : ''}" data-chrome-pat="${p.id}" title="${p.label}">
                <div class="tcs-pat-swatch" data-chrome-swatch="${p.id}"></div>
                <span class="tcs-pat-name">${p.label}</span>
            </button>`
        ).join('');
        list.forEach((p) => {
            const sw = host.querySelector(`[data-chrome-swatch="${p.id}"]`);
            if (!sw) return;
            const slot = {
                tilePattern: p.id,
                tileScale: scale,
                fillA: '#00e5ff',
                fillB: '#7c5cff',
                fillC: '#00ffa8',
                fillAlpha: 0.95,
                fillAlphaB: 0.8,
                fillAlphaC: 0.7,
                fillColorCount: 3,
                fillMode: 'pattern',
            };
            if (TC?.paintFromSlot) TC.paintFromSlot(sw, slot);
            else if (TP?.build && TP.applyToEl) TP.applyToEl(sw, TP.build(slot));
        });
        host.querySelectorAll('[data-chrome-pat]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const id = btn.getAttribute('data-chrome-pat') || 'circuit';
                await FAFOChromeArt.writeConfig({ tilePattern: id, tileFallback: true });
                if ($('chrome-art-tile')) $('chrome-art-tile').checked = true;
                await saveChromeArtSettings({ toast: false });
                showToast('Wallpaper tile: ' + (list.find((x) => x.id === id)?.label || id));
            });
        });
    }

    async function refreshChromeArtUi() {
        if (!window.FAFOChromeArt) return;
        const cfg = await FAFOChromeArt.readConfig();
        const set = (id, val) => { const el = $(id); if (el) el.value = val; };
        const setCheck = (id, on) => { const el = $(id); if (el) el.checked = !!on; };
        setCheck('chrome-art-enabled', cfg.enabled !== false);
        setCheck('chrome-art-bg-random', cfg.bgRandom !== false);
        setCheck('chrome-art-panel-lock', cfg.panelMode === 'locked' && !!cfg.panelLock?.dataUrl);
        setCheck('chrome-art-banner-follow', cfg.bannerFollowPanels !== false);
        setCheck('chrome-art-random-slices', cfg.randomSlices !== false);
        set('chrome-art-dim', Math.round((cfg.dim ?? 0.42) * 100));
        set('chrome-art-bg-op', Math.round((cfg.bgOpacity ?? 0.55) * 100));
        set('chrome-art-banner-op', Math.round((cfg.bannerOpacity ?? 0.5) * 100));
        set('chrome-art-side-op', Math.round((cfg.sideOpacity ?? 0.34) * 100));
        set('chrome-art-glow', Math.round((cfg.glowUnderArt ?? 0.35) * 100));
        set('chrome-art-bg-name', cfg.bgName || '');
        const tileOn = $('chrome-art-tile');
        if (tileOn) tileOn.checked = cfg.tileFallback !== false;
        const tileScale = $('chrome-art-tile-scale');
        const tileScaleVal = $('chrome-art-tile-scale-val');
        if (tileScale) tileScale.value = String(cfg.tileScale || 28);
        if (tileScaleVal) tileScaleVal.textContent = (cfg.tileScale || 28) + 'px';
        paintChromeArtTileGallery(cfg);
        const dimV = $('chrome-art-dim-val');
        const bgV = $('chrome-art-bg-op-val');
        const banV = $('chrome-art-banner-op-val');
        const sideV = $('chrome-art-side-op-val');
        const glowV = $('chrome-art-glow-val');
        if (dimV) dimV.textContent = Math.round((cfg.dim ?? 0.42) * 100) + '%';
        if (bgV) bgV.textContent = Math.round((cfg.bgOpacity ?? 0.55) * 100) + '%';
        if (banV) banV.textContent = Math.round((cfg.bannerOpacity ?? 0.5) * 100) + '%';
        if (sideV) sideV.textContent = Math.round((cfg.sideOpacity ?? 0.34) * 100) + '%';
        if (glowV) glowV.textContent = Math.round((cfg.glowUnderArt ?? 0.35) * 100) + '%';

        // Locked crop preview
        const wrap = $('chrome-art-lock-preview-wrap');
        const prev = $('chrome-art-lock-preview');
        const meta = $('chrome-art-lock-meta');
        if (cfg.panelMode === 'locked' && cfg.panelLock?.dataUrl) {
            if (wrap) wrap.style.display = 'block';
            if (prev) prev.src = cfg.panelLock.dataUrl;
            if (meta) {
                meta.textContent = [
                    cfg.panelLock.name || 'panel crop',
                    cfg.panelLock.width && cfg.panelLock.height
                        ? `${cfg.panelLock.width}×${cfg.panelLock.height}`
                        : '',
                    'panels locked · background still random',
                ].filter(Boolean).join(' · ');
            }
        } else {
            if (wrap) wrap.style.display = 'none';
            if (prev) prev.removeAttribute('src');
            if (meta) meta.textContent = '';
        }

        const status = $('chrome-art-status');
        const names = $('chrome-art-names');
        try {
            const folder = await FAFOChromeArt.getArtFolder();
            if (!folder) {
                if (status) status.textContent = 'No art folder linked yet.';
                if (names) names.textContent = '';
                return;
            }
            const imgs = await FAFOChromeArt.listArtImages(folder);
            const modeBits = [
                cfg.bgRandom !== false ? 'bg: random each tab' : `bg: fixed ${cfg.bgName || '—'}`,
                cfg.panelMode === 'locked' && cfg.panelLock?.dataUrl
                    ? 'panels: locked crop'
                    : 'panels: random',
            ];
            if (status) {
                status.textContent = `Linked: ${folder.name || 'Chrome Art'} · ${imgs.length} image(s) · ${modeBits.join(' · ')}`;
            }
            if (names) {
                names.textContent = imgs.length
                    ? 'Files: ' + imgs.slice(0, 24).map((h) => h.name).join(' · ') + (imgs.length > 24 ? ' …' : '')
                    : 'Folder is empty — add jpg/png/webp images.';
            }
        } catch (e) {
            if (status) status.textContent = 'Could not read art folder (Restore Access if needed).';
        }
    }

    function wireChromeArtUi() {
        if (!window.FAFOChromeArt) return;
        const pctLabel = (rangeId, labelId) => {
            const r = $(rangeId);
            const l = $(labelId);
            if (!r || !l) return;
            const sync = () => { l.textContent = r.value + '%'; };
            r.addEventListener('input', sync);
            sync();
        };
        pctLabel('chrome-art-dim', 'chrome-art-dim-val');
        pctLabel('chrome-art-bg-op', 'chrome-art-bg-op-val');
        pctLabel('chrome-art-banner-op', 'chrome-art-banner-op-val');
        pctLabel('chrome-art-side-op', 'chrome-art-side-op-val');
        pctLabel('chrome-art-glow', 'chrome-art-glow-val');
        const tileScale = $('chrome-art-tile-scale');
        const tileScaleVal = $('chrome-art-tile-scale-val');
        if (tileScale && tileScaleVal) {
            const syncTile = () => { tileScaleVal.textContent = tileScale.value + 'px'; };
            tileScale.addEventListener('input', syncTile);
            tileScale.addEventListener('change', () => saveChromeArtSettings({ toast: false }));
            syncTile();
        }
        $('chrome-art-tile')?.addEventListener('change', () => saveChromeArtSettings({ toast: true }));

        $('chrome-art-link')?.addEventListener('click', async () => {
            try {
                const r = await FAFOChromeArt.linkFolder();
                showToast(`Chrome art linked · ${r.images || 0} image(s) · bg random`);
                await refreshChromeArtUi();
            } catch (e) {
                if (e?.name === 'AbortError') return;
                showToast(e.message || 'Link failed', 'error');
            }
        });
        $('chrome-art-clear')?.addEventListener('click', async () => {
            if (!confirm('Clear chrome art folder link?')) return;
            await FAFOChromeArt.clearFolder();
            showToast('Chrome art cleared');
            await refreshChromeArtUi();
        });
        $('chrome-art-refresh')?.addEventListener('click', async () => {
            await saveChromeArtSettings({ toast: true, reRoll: true });
        });
        $('chrome-art-save')?.addEventListener('click', async () => {
            await saveChromeArtSettings({ toast: true });
        });
        $('chrome-art-pick-crop')?.addEventListener('click', async () => {
            try {
                const cfg = await FAFOChromeArt.pickAndLockPanelCrop();
                if (!cfg) return;
                showToast('Panel crop saved · background still randomizes');
                await refreshChromeArtUi();
                scheduleFullBackup('chrome-art');
            } catch (e) {
                if (e?.name === 'AbortError') return;
                showToast(e.message || 'Crop failed', 'error');
            }
        });
        $('chrome-art-clear-lock')?.addEventListener('click', async () => {
            await FAFOChromeArt.clearPanelLock();
            if ($('chrome-art-panel-lock')) $('chrome-art-panel-lock').checked = false;
            await saveChromeArtSettings({ toast: true });
            showToast('Panel lock cleared · panels random again');
        });
        $('chrome-art-panel-lock')?.addEventListener('change', async () => {
            const on = !!$('chrome-art-panel-lock')?.checked;
            if (on) {
                const cur = await FAFOChromeArt.readConfig();
                if (!cur.panelLock?.dataUrl) {
                    // Need a crop first
                    $('chrome-art-panel-lock').checked = false;
                    showToast('Pick & crop an image first', 'error');
                    try {
                        const cfg = await FAFOChromeArt.pickAndLockPanelCrop();
                        if (cfg) {
                            showToast('Panel crop locked');
                            await refreshChromeArtUi();
                        }
                    } catch (e) {
                        if (e?.name !== 'AbortError') showToast(e.message || 'Crop failed', 'error');
                    }
                    return;
                }
                await FAFOChromeArt.writeConfig({ panelMode: 'locked' });
            } else {
                await FAFOChromeArt.writeConfig({ panelMode: 'random' });
            }
            await saveChromeArtSettings({ toast: true });
        });
        refreshChromeArtUi().catch(() => {});
    }

    async function saveChromeArtSettings(opts = {}) {
        if (!window.FAFOChromeArt) return;
        const n = (id, d) => {
            const v = parseInt($(id)?.value, 10);
            return Number.isFinite(v) ? v / 100 : d;
        };
        const cur = await FAFOChromeArt.readConfig();
        const lockOn = !!$('chrome-art-panel-lock')?.checked;
        const cfg = await FAFOChromeArt.writeConfig({
            enabled: !!$('chrome-art-enabled')?.checked,
            bgRandom: !!$('chrome-art-bg-random')?.checked,
            panelMode: lockOn && cur.panelLock?.dataUrl ? 'locked' : (lockOn ? cur.panelMode : 'random'),
            bannerFollowPanels: !!$('chrome-art-banner-follow')?.checked,
            randomSlices: !!$('chrome-art-random-slices')?.checked,
            dim: n('chrome-art-dim', 0.42),
            bgOpacity: n('chrome-art-bg-op', 0.55),
            bannerOpacity: n('chrome-art-banner-op', 0.5),
            sideOpacity: n('chrome-art-side-op', 0.34),
            panelOpacity: n('chrome-art-side-op', 0.3),
            glowUnderArt: n('chrome-art-glow', 0.35),
            bgName: $('chrome-art-bg-name')?.value?.trim() || '',
            tileFallback: $('chrome-art-tile') ? !!$('chrome-art-tile').checked : true,
            tileScale: (() => {
                const v = parseInt($('chrome-art-tile-scale')?.value, 10);
                return Number.isFinite(v) ? Math.max(8, Math.min(64, v)) : 28;
            })(),
            // keep existing panelLock when locking
            panelLock: cur.panelLock || null,
        });
        try {
            await FAFOChromeArt.apply({ config: cfg });
        } catch (_) {}
        if (opts.toast) {
            const msg = cfg.panelMode === 'locked'
                ? 'Chrome art saved · bg re-rolls · panels stay on your crop'
                : 'Chrome art saved · bg + panels re-roll from folder';
            showToast(msg);
        }
        await refreshChromeArtUi();
        scheduleFullBackup('chrome-art');
    }

    // --- Intro promos (4 boot video folders · shuffle queue · BOFA slot 4) ---
    async function refreshIntroPromosUi() {
        if (!window.FAFOIntroPromos) return;
        const cfg = await FAFOIntroPromos.readConfig();
        const en = $('intro-promo-enabled');
        const sh = $('intro-promo-shuffle');
        if (en) en.checked = cfg.enabled !== false;
        if (sh) sh.checked = cfg.shuffle !== false;
        const host = $('intro-promo-slots');
        if (!host) return;
        host.innerHTML = '';
        for (const slot of cfg.slots) {
            const st = await FAFOIntroPromos.slotStatus(slot.id);
            const panel = document.createElement('div');
            panel.className = 'panel';
            const isBofa = !!slot.sponsored;
            panel.innerHTML = `
                <div class="panel-title" style="${isBofa ? 'color:#ffc107;' : ''}">
                    Intro ${slot.id}${isBofa ? ' · Sponsored · BOFA Deez Teas' : ''}
                </div>
                ${isBofa ? `<p style="color:#c9a227;font-size:0.85rem;margin:-6px 0 12px;line-height:1.45;">
                    <strong>BOFA Deez Teas!</strong> Suck one down today at a retailer near you!
                </p>` : ''}
                <label class="toggle-label" style="margin-bottom:10px;display:flex;align-items:center;gap:8px;">
                    <input type="checkbox" data-intro-en="${slot.id}" ${slot.enabled ? 'checked' : ''}>
                    <span>Enable this intro</span>
                </label>
                <div class="row" style="gap:8px;flex-wrap:wrap;align-items:center;">
                    <button class="btn btn-primary" data-intro-link="${slot.id}" style="width:auto;">+ Link video folder</button>
                    <button class="btn btn-ghost" data-intro-clear="${slot.id}" style="width:auto;">Clear folder</button>
                </div>
                <p style="color:var(--accent);font-size:0.82rem;margin-top:10px;line-height:1.4;">
                    ${st?.linked
                        ? `Linked: <strong>${st.folderName || 'folder'}</strong> · ${st.count} video(s)` +
                          (st.queueRemaining != null ? ` · queue left: ${st.queueRemaining}` : '')
                        : 'No folder linked yet.'}
                </p>
            `;
            host.appendChild(panel);
        }
        host.querySelectorAll('[data-intro-link]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const id = parseInt(btn.getAttribute('data-intro-link'), 10);
                try {
                    const r = await FAFOIntroPromos.linkSlotFolder(id);
                    showToast(`Intro ${id} linked · ${r.count} video(s)`);
                    await refreshIntroPromosUi();
                } catch (e) {
                    if (e?.name === 'AbortError') return;
                    showToast(e.message || 'Link failed', 'error');
                }
            });
        });
        host.querySelectorAll('[data-intro-clear]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const id = parseInt(btn.getAttribute('data-intro-clear'), 10);
                if (!confirm(`Clear Intro ${id} folder link?`)) return;
                await FAFOIntroPromos.clearSlotFolder(id);
                showToast(`Intro ${id} cleared`);
                await refreshIntroPromosUi();
            });
        });
        host.querySelectorAll('[data-intro-en]').forEach((cb) => {
            cb.addEventListener('change', async () => {
                const id = parseInt(cb.getAttribute('data-intro-en'), 10);
                const cfg2 = await FAFOIntroPromos.readConfig();
                cfg2.slots = cfg2.slots.map((s) =>
                    s.id === id ? { ...s, enabled: !!cb.checked } : s
                );
                await FAFOIntroPromos.writeConfig(cfg2);
                showToast(`Intro ${id} ${cb.checked ? 'enabled' : 'disabled'}`);
            });
        });
        const status = $('intro-promo-status');
        if (status) {
            status.textContent = cfg.enabled
                ? 'Promos on · open a new tab to play (Skip · Esc per intro)'
                : 'Promos disabled';
        }
    }

    function wireIntroPromosUi() {
        if (!window.FAFOIntroPromos) return;
        $('intro-promo-save')?.addEventListener('click', async () => {
            await FAFOIntroPromos.writeConfig({
                enabled: !!$('intro-promo-enabled')?.checked,
                shuffle: !!$('intro-promo-shuffle')?.checked,
                playToEnd: true,
            });
            showToast('Intro promo settings saved');
            await refreshIntroPromosUi();
            scheduleFullBackup('intro-promos');
        });
        $('intro-promo-reset-queues')?.addEventListener('click', async () => {
            if (!confirm('Reset residual shuffle queues for all intro slots?')) return;
            await chrome.storage.local.set({ fafoIntroPromoQueues: {} });
            showToast('Shuffle queues reset — next open rebuilds decks');
            await refreshIntroPromosUi();
        });
        refreshIntroPromosUi().catch(() => {});
    }
    wireIntroPromosUi();

    // --- Tag themes (full look control) ---
    function wireTagThemesUi() {
        if (!window.FAFOTagThemes) return;
        const sel = $('tag-theme-select');
        const cards = $('tag-theme-cards');
        const animSel = $('tag-theme-anim');
        const lastSel = $('tag-theme-last-anim');
        const borderSel = $('tag-theme-border');

        const fillSelects = () => {
            const packs = FAFOTagThemes.list();
            if (sel) {
                sel.innerHTML = packs.map((p) =>
                    `<option value="${p.id}">${p.name}${p.user ? ' ★' : ''}</option>`
                ).join('');
            }
            if (animSel && FAFOTagThemes.ANIM_OPTIONS) {
                animSel.innerHTML = FAFOTagThemes.ANIM_OPTIONS.map((a) =>
                    `<option value="${a.id}">${a.label}</option>`
                ).join('');
            }
            if (lastSel && FAFOTagThemes.LAST_ANIM_OPTIONS) {
                lastSel.innerHTML = FAFOTagThemes.LAST_ANIM_OPTIONS.map((a) =>
                    `<option value="${a.id}">${a.label}</option>`
                ).join('');
            }
            if (borderSel && FAFOTagThemes.BORDER_STYLES) {
                borderSel.innerHTML = FAFOTagThemes.BORDER_STYLES.map((a) =>
                    `<option value="${a.id}">${a.label}</option>`
                ).join('');
            }
            if (cards) {
                cards.innerHTML = packs.map((p) => `
                    <button type="button" class="tag-theme-card" data-theme-id="${p.id}"
                        style="text-align:left;padding:12px;border-radius:12px;border:1px solid #333;background:#0a0a0e;color:#eee;cursor:pointer;">
                        <div style="font-weight:700;margin-bottom:4px;">${p.name}${p.user ? ' ★' : ''}</div>
                        <div style="font-size:0.75rem;color:#888;line-height:1.3;">${p.description || p.anim || ''}</div>
                        <div style="font-size:0.7rem;color:#555;margin-top:6px;">${p.anim || ''} · ${p.borderStyle || ''}</div>
                    </button>
                `).join('');
                cards.querySelectorAll('[data-theme-id]').forEach((btn) => {
                    btn.addEventListener('click', () => {
                        FAFOTagThemes.clearOverrides?.();
                        FAFOTagThemes.apply(btn.dataset.themeId);
                        if (sel) sel.value = btn.dataset.themeId;
                        syncControlsFromCurrent();
                        paintPreview();
                        highlightCard(btn.dataset.themeId);
                        showToast('Theme: ' + (FAFOTagThemes.current()?.name || ''));
                    });
                });
            }
        };

        const highlightCard = (id) => {
            cards?.querySelectorAll('[data-theme-id]').forEach((b) => {
                const on = b.dataset.themeId === id;
                b.style.borderColor = on ? 'var(--accent)' : '#333';
                b.style.boxShadow = on ? '0 0 12px rgba(0,229,255,0.25)' : 'none';
            });
        };

        const hexFromCssColor = (css) => {
            if (!css) return '#00e5ff';
            if (css.startsWith('#')) return css.length === 4
                ? `#${css[1]}${css[1]}${css[2]}${css[2]}${css[3]}${css[3]}`
                : css.slice(0, 7);
            const m = css.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
            if (m) {
                const h = (n) => Number(n).toString(16).padStart(2, '0');
                return `#${h(m[1])}${h(m[2])}${h(m[3])}`;
            }
            return '#00e5ff';
        };

        const syncControlsFromCurrent = () => {
            const cur = FAFOTagThemes.current?.() || {};
            const v = cur.vars || {};
            if (sel && cur.id) sel.value = cur.id;
            if (animSel) animSel.value = cur.anim || 'neon';
            if (lastSel) lastSel.value = cur.lastAnim || 'breathe-gold';
            if (borderSel) borderSel.value = cur.borderStyle || 'glow';

            const radius = parseInt(String(v['--tag-radius'] || '12').replace('px', ''), 10);
            const setRange = (id, val, labelId, fmt) => {
                const el = $(id);
                if (el) el.value = val;
                const lab = $(labelId);
                if (lab) lab.textContent = fmt != null ? fmt : val;
            };
            setRange('tt-radius', Number.isFinite(radius) ? Math.min(24, radius) : 12, 'tt-radius-val');
            setRange('tt-borderw', parseFloat(String(v['--tag-border-w'] || '1').replace('px', '')) || 1, 'tt-borderw-val');
            setRange('tt-padx', parseInt(String(v['--tag-pad-x'] || '10').replace('px', ''), 10) || 10, 'tt-padx-val');
            setRange('tt-pady', parseInt(String(v['--tag-pad-y'] || '4').replace('px', ''), 10) || 4, 'tt-pady-val');
            setRange('tt-hover', parseFloat(v['--tag-hover-scale'] || '1.04') || 1.04, 'tt-hover-val');
            setRange('tt-weight', parseInt(v['--tag-weight'] || '700', 10) || 700, 'tt-weight-val');

            const font = $('tt-font');
            if (font) font.value = v['--tag-font'] || font.options[0].value;

            const setColor = (id, cssVal) => {
                const el = $(id);
                if (el) el.value = hexFromCssColor(cssVal);
            };
            setColor('tt-c-bg', v['--tag-bg']);
            setColor('tt-c-border', v['--tag-border']);
            setColor('tt-c-fg', v['--tag-fg']);
            setColor('tt-c-sel-border', v['--tag-selected-border']);
            setColor('tt-c-sel-fg', v['--tag-selected-fg']);
            setColor('tt-c-last', v['--tag-last-border']);
            setColor('tt-c-panel', v['--tag-panel-border']);
            highlightCard(cur.id);
        };

        const paintPreview = () => {
            const host = $('tag-theme-preview');
            if (!host) return;
            host.innerHTML = ['field', 'site', 'parts', 'sprint', 'last']
                .map((t, i) => {
                    const on = i < 2 ? ' on-video' : '';
                    const last = i === 4 ? ' last-video' : '';
                    return `<span class="meta-lib-tag${on}${last}" style="display:inline-block;margin:2px;">${t}</span>`;
                })
                .join('');
            const st = $('tag-theme-status');
            const cur = FAFOTagThemes.current?.();
            if (st && cur) {
                st.textContent = `Active: ${cur.name} · anim ${cur.anim} · border ${cur.borderStyle}`;
            }
        };

        const applyTweaksFromControls = () => {
            const r = $('tt-radius')?.value ?? 12;
            const bw = $('tt-borderw')?.value ?? 1;
            const px = $('tt-padx')?.value ?? 10;
            const py = $('tt-pady')?.value ?? 4;
            const hov = $('tt-hover')?.value ?? 1.04;
            const w = $('tt-weight')?.value ?? 700;
            if ($('tt-radius-val')) $('tt-radius-val').textContent = r;
            if ($('tt-borderw-val')) $('tt-borderw-val').textContent = bw;
            if ($('tt-padx-val')) $('tt-padx-val').textContent = px;
            if ($('tt-pady-val')) $('tt-pady-val').textContent = py;
            if ($('tt-hover-val')) $('tt-hover-val').textContent = hov;
            if ($('tt-weight-val')) $('tt-weight-val').textContent = w;

            const cBg = $('tt-c-bg')?.value || '#00141c';
            const cBorder = $('tt-c-border')?.value || '#00e5ff';
            const cFg = $('tt-c-fg')?.value || '#b8f7ff';
            const cSelB = $('tt-c-sel-border')?.value || '#00ffa8';
            const cSelF = $('tt-c-sel-fg')?.value || '#e8fff6';
            const cLast = $('tt-c-last')?.value || '#ffc107';
            const cPanel = $('tt-c-panel')?.value || '#00e5ff';

            const tracking = parseFloat($('tt-tracking')?.value || '0.02');
            if ($('tt-tracking-val')) $('tt-tracking-val').textContent = String(tracking);

            FAFOTagThemes.setOverride({
                anim: animSel?.value || null,
                lastAnim: lastSel?.value || null,
                borderStyle: borderSel?.value || null,
                vars: {
                    '--tag-radius': `${r}px`,
                    '--tag-border-w': `${bw}px`,
                    '--tag-pad-x': `${px}px`,
                    '--tag-pad-y': `${py}px`,
                    '--tag-hover-scale': String(hov),
                    '--tag-weight': String(w),
                    '--tag-font': $('tt-font')?.value || "'Segoe UI', system-ui, sans-serif",
                    '--tag-letter-spacing': `${tracking}em`,
                    '--tag-bg': cBg + 'c0',
                    '--tag-border': cBorder + '99',
                    '--tag-fg': cFg,
                    '--tag-selected-border': cSelB,
                    '--tag-selected-fg': cSelF,
                    '--tag-selected-bg': `linear-gradient(135deg, ${cSelB}55, ${cBorder}33)`,
                    '--tag-selected-glow': `0 0 14px ${cSelB}88`,
                    '--tag-last-border': cLast,
                    '--tag-last-glow': `0 0 10px ${cLast}66`,
                    '--tag-panel-border': cPanel + '55',
                    '--tag-panel-glow': `0 0 18px ${cPanel}33`,
                },
            });
            paintPreview();
        };

        fillSelects();
        const cur = FAFOTagThemes.current?.();
        if (sel && cur) sel.value = cur.id;
        syncControlsFromCurrent();
        paintPreview();

        $('tag-theme-apply')?.addEventListener('click', () => {
            applyTweaksFromControls();
            showToast('Tag look applied · open a new tab if it was already open');
        });
        $('tag-theme-cycle')?.addEventListener('click', () => {
            FAFOTagThemes.cycle();
            fillSelects();
            syncControlsFromCurrent();
            paintPreview();
            showToast('Theme: ' + (FAFOTagThemes.current()?.name || ''));
        });
        $('tag-theme-reset-overrides')?.addEventListener('click', () => {
            FAFOTagThemes.clearOverrides?.();
            syncControlsFromCurrent();
            paintPreview();
            showToast('Tweaks cleared · pack defaults restored');
        });
        sel?.addEventListener('change', () => {
            FAFOTagThemes.clearOverrides?.();
            FAFOTagThemes.apply(sel.value);
            syncControlsFromCurrent();
            paintPreview();
            highlightCard(sel.value);
        });

        [animSel, lastSel, borderSel, $('tt-font')].forEach((el) => {
            el?.addEventListener('change', applyTweaksFromControls);
        });
        ['tt-radius', 'tt-borderw', 'tt-padx', 'tt-pady', 'tt-hover', 'tt-weight', 'tt-tracking',
            'tt-c-bg', 'tt-c-border', 'tt-c-fg', 'tt-c-sel-border', 'tt-c-sel-fg', 'tt-c-last', 'tt-c-panel'
        ].forEach((id) => {
            $(id)?.addEventListener('input', applyTweaksFromControls);
        });

        $('tag-theme-save')?.addEventListener('click', async () => {
            applyTweaksFromControls();
            const name = ($('tag-theme-save-name')?.value || '').trim() || 'My theme';
            const pack = await FAFOTagThemes.saveUserPack?.(name);
            fillSelects();
            if (sel && pack) sel.value = pack.id;
            syncControlsFromCurrent();
            paintPreview();
            showToast('Saved custom theme: ' + name);
        });
        $('tag-theme-delete')?.addEventListener('click', async () => {
            const id = sel?.value;
            if (!id || !String(id).startsWith('user-')) {
                showToast('Select a custom (★) theme to delete');
                return;
            }
            if (!confirm('Delete this custom theme?')) return;
            await FAFOTagThemes.deleteUserPack?.(id);
            fillSelects();
            syncControlsFromCurrent();
            paintPreview();
            showToast('Custom theme deleted');
        });
    }
    wireTagThemesUi();

    // --- Named color slots (fill/border/gradient) — overrides theme on tags ---
    function wireTagColorSlotsUi() {
        const TC = window.FAFOTagColors;
        if (!TC || typeof TC.getSlots !== 'function') {
            const st = $('tcs-status');
            if (st) st.textContent = 'Color slots module not loaded — reload Options.';
            return;
        }
        let selected = 0;
        let loading = false;
        let saveTimer = null;
        const $id = (id) => $(id);

        // Fill direction + tile pattern selects (gallery is primary UI; select is hidden sync)
        const dirSel = $id('tcs-grad-dir');
        if (dirSel && TC.GRADIENT_DIRS) {
            dirSel.innerHTML = TC.GRADIENT_DIRS.map((d) =>
                `<option value="${d.id}">${d.label}</option>`
            ).join('');
        }
        const tileSel = $id('tcs-tile-pattern');
        const patterns = Array.isArray(TC.TILE_PATTERNS) ? TC.TILE_PATTERNS : [];
        if (tileSel) {
            tileSel.innerHTML = patterns.map((p) =>
                `<option value="${p.id}">${p.label}</option>`
            ).join('');
            if (!patterns.length) {
                console.warn('FAFOTagColors.TILE_PATTERNS empty — pattern gallery will be limited');
            }
        }

        const setStatus = (msg) => {
            const st = $id('tcs-status');
            if (st) st.textContent = msg || '';
        };

        const refreshThemeBanner = () => {
            const tid = TC.getThemeId?.() || window.FAFOTagThemes?.current?.()?.id || '—';
            const name = window.FAFOTagThemes?.current?.()?.name || tid;
            const el = $id('tcs-theme-name');
            if (el) el.textContent = name;
            return tid;
        };

        const readPatch = () => {
            const n = (id, d) => {
                const v = parseInt($id(id)?.value, 10);
                return Number.isFinite(v) ? v / 100 : d;
            };
            const stop = parseInt($id('tcs-grad-stop')?.value, 10);
            const stopC = parseInt($id('tcs-grad-stop-c')?.value, 10);
            const blend = parseInt($id('tcs-blend')?.value, 10);
            const tileScale = parseInt($id('tcs-tile-scale')?.value, 10);
            const fillCount = parseInt($id('tcs-fill-count')?.value, 10);
            const mode = $id('tcs-fill-mode')?.value || 'solid';
            return {
                name: ($id('tcs-name')?.value || '').trim() || `Slot ${selected + 1}`,
                scope: $id('tcs-scope')?.value === 'per-theme' ? 'per-theme' : 'global',
                fillMode: ['solid', 'gradient', 'pattern'].includes(mode) ? mode : 'solid',
                fillColorCount: Number.isFinite(fillCount) ? fillCount : 2,
                fillA: $id('tcs-fill-a')?.value || '#00e5ff',
                fillB: $id('tcs-fill-b')?.value || '#00ffa8',
                fillC: $id('tcs-fill-c')?.value || '#a78bfa',
                fillAlpha: n('tcs-fill-alpha', 0.95),
                fillAlphaB: n('tcs-fill-alpha-b', 0.85),
                fillAlphaC: n('tcs-fill-alpha-c', 0.7),
                borderMode: $id('tcs-border-mode')?.value || 'solid',
                borderColorCount: Number.isFinite(fillCount) ? fillCount : 2,
                borderA: $id('tcs-border-a')?.value || '#00e5ff',
                borderB: $id('tcs-border-b')?.value || '#ffffff',
                borderC: $id('tcs-border-c')?.value || '#00ffa8',
                borderAlpha: n('tcs-border-alpha', 1),
                borderAlphaB: n('tcs-border-alpha-b', 0.85),
                borderAlphaC: n('tcs-border-alpha-c', 0.7),
                gradientPattern: $id('tcs-grad-pattern')?.value || 'linear',
                gradientDir: $id('tcs-grad-dir')?.value || 'to bottom right',
                blendSoftness: Number.isFinite(blend) ? blend : 55,
                gradientStop: Number.isFinite(stop) ? stop : 50,
                gradientStopC: Number.isFinite(stopC) ? stopC : 80,
                tilePattern: $id('tcs-tile-pattern')?.value || 'stripes-h',
                tileScale: Number.isFinite(tileScale) ? Math.max(4, Math.min(96, tileScale)) : 16,
            };
        };

        const paintPatternGallery = () => {
            const host = $id('tcs-pattern-gallery');
            if (!host || !TC) return;
            const list = Array.isArray(TC.TILE_PATTERNS) ? TC.TILE_PATTERNS : [];
            const patch = readPatch();
            // Force pattern mode for gallery previews using current colors/scale
            const base = { ...patch, fillMode: 'pattern' };
            const selectedId = patch.tilePattern || 'stripes-h';
            host.innerHTML = list.map((p) =>
                `<button type="button" class="tcs-pat${p.id === selectedId ? ' on' : ''}" data-pat="${p.id}" title="${p.label}">
                    <div class="tcs-pat-swatch" data-pat-swatch="${p.id}"></div>
                    <span class="tcs-pat-name">${p.label}</span>
                </button>`
            ).join('');
            list.forEach((p) => {
                const sw = host.querySelector(`[data-pat-swatch="${p.id}"]`);
                if (sw && TC.paintFromSlot) {
                    TC.paintFromSlot(sw, { ...base, tilePattern: p.id });
                }
            });
            host.querySelectorAll('[data-pat]').forEach((btn) => {
                btn.addEventListener('click', () => {
                    const id = btn.getAttribute('data-pat');
                    if ($id('tcs-tile-pattern')) $id('tcs-tile-pattern').value = id;
                    if ($id('tcs-fill-mode') && $id('tcs-fill-mode').value !== 'pattern') {
                        $id('tcs-fill-mode').value = 'pattern';
                    }
                    const lab = $id('tcs-pattern-selected-label');
                    const meta = list.find((x) => x.id === id);
                    if (lab) lab.textContent = 'Pattern: ' + (meta?.label || id);
                    syncModeRows();
                    schedule();
                    paintPatternGallery();
                    paintPreviewChip();
                });
            });
            const lab = $id('tcs-pattern-selected-label');
            const meta = list.find((x) => x.id === selectedId);
            if (lab) lab.textContent = 'Pattern: ' + (meta?.label || selectedId);
        };

        const syncModeRows = () => {
            const mode = $id('tcs-fill-mode')?.value || 'solid';
            const gRow = $id('tcs-gradient-row');
            const pRow = $id('tcs-pattern-row');
            if (gRow) gRow.style.display = mode === 'gradient' ? '' : 'none';
            if (pRow) pRow.style.display = mode === 'pattern' ? '' : 'none';
            if (mode === 'pattern') paintPatternGallery();
        };

        const loadSlot = (i) => {
            refreshThemeBanner();
            const slots = TC.getSlots() || [];
            if (!slots.length) return;
            selected = Math.max(0, Math.min(i, slots.length - 1));
            const s = slots[selected];
            loading = true;
            if ($id('tcs-name')) $id('tcs-name').value = s.name || '';
            if ($id('tcs-scope')) $id('tcs-scope').value = s.scope === 'per-theme' ? 'per-theme' : 'global';
            if ($id('tcs-fill-mode')) $id('tcs-fill-mode').value = s.fillMode || 'solid';
            if ($id('tcs-fill-count')) $id('tcs-fill-count').value = String(s.fillColorCount || 2);
            if ($id('tcs-fill-a')) $id('tcs-fill-a').value = s.fillA || '#00e5ff';
            if ($id('tcs-fill-b')) $id('tcs-fill-b').value = s.fillB || '#00ffa8';
            if ($id('tcs-fill-c')) $id('tcs-fill-c').value = s.fillC || '#a78bfa';
            if ($id('tcs-fill-alpha')) $id('tcs-fill-alpha').value = Math.round((s.fillAlpha ?? 0.95) * 100);
            if ($id('tcs-fill-alpha-b')) $id('tcs-fill-alpha-b').value = Math.round((s.fillAlphaB ?? 0.85) * 100);
            if ($id('tcs-fill-alpha-c')) $id('tcs-fill-alpha-c').value = Math.round((s.fillAlphaC ?? 0.7) * 100);
            if ($id('tcs-border-mode')) $id('tcs-border-mode').value = s.borderMode || 'solid';
            if ($id('tcs-border-a')) $id('tcs-border-a').value = s.borderA || s.fillA || '#00e5ff';
            if ($id('tcs-border-b')) $id('tcs-border-b').value = s.borderB || '#ffffff';
            if ($id('tcs-border-c')) $id('tcs-border-c').value = s.borderC || '#00ffa8';
            if ($id('tcs-border-alpha')) $id('tcs-border-alpha').value = Math.round((s.borderAlpha ?? 1) * 100);
            if ($id('tcs-border-alpha-b')) $id('tcs-border-alpha-b').value = Math.round((s.borderAlphaB ?? 0.85) * 100);
            if ($id('tcs-border-alpha-c')) $id('tcs-border-alpha-c').value = Math.round((s.borderAlphaC ?? 0.7) * 100);
            if ($id('tcs-grad-pattern')) $id('tcs-grad-pattern').value = s.gradientPattern || 'linear';
            if ($id('tcs-grad-dir')) $id('tcs-grad-dir').value = s.gradientDir || 'to bottom right';
            if ($id('tcs-blend')) $id('tcs-blend').value = s.blendSoftness ?? 55;
            if ($id('tcs-grad-stop')) $id('tcs-grad-stop').value = s.gradientStop ?? 50;
            if ($id('tcs-grad-stop-c')) $id('tcs-grad-stop-c').value = s.gradientStopC ?? 80;
            if ($id('tcs-tile-pattern')) $id('tcs-tile-pattern').value = s.tilePattern || 'stripes-h';
            if ($id('tcs-tile-scale')) $id('tcs-tile-scale').value = s.tileScale ?? 16;
            updateValLabels();
            syncModeRows();
            paintTiles();
            paintPreviewChip();
            if ((s.fillMode || 'solid') === 'pattern') paintPatternGallery();
            requestAnimationFrame(() => { loading = false; });
        };

        const updateValLabels = () => {
            const set = (id, pctId, suffix = '%') => {
                const v = $id(id)?.value;
                const lab = $id(pctId);
                if (lab && v != null) lab.textContent = `${v}${suffix}`;
            };
            set('tcs-fill-alpha', 'tcs-fill-alpha-val');
            set('tcs-fill-alpha-b', 'tcs-fill-alpha-b-val');
            set('tcs-fill-alpha-c', 'tcs-fill-alpha-c-val');
            set('tcs-border-alpha', 'tcs-border-alpha-val');
            set('tcs-border-alpha-b', 'tcs-border-alpha-b-val');
            set('tcs-border-alpha-c', 'tcs-border-alpha-c-val');
            set('tcs-blend', 'tcs-blend-val');
            set('tcs-grad-stop', 'tcs-grad-stop-val');
            set('tcs-grad-stop-c', 'tcs-grad-stop-c-val');
            set('tcs-tile-scale', 'tcs-tile-scale-val', 'px');
        };

        const paintPreviewChip = () => {
            const el = $id('tcs-preview');
            if (!el) return;
            const patch = readPatch();
            el.textContent = patch.name || 'Preview';
            TC.paintFromSlot?.(el, patch);
        };

        const paintTiles = () => {
            const host = $id('tcs-tiles');
            if (!host) return;
            const slots = TC.getSlots() || [];
            host.innerHTML = slots.map((s, i) => {
                const on = i === selected ? ' on' : '';
                const scopeCls = s.scope === 'per-theme'
                    ? (s.hasThemeOverride ? 'per ov' : 'per')
                    : '';
                const scopeLab = s.scope === 'per-theme'
                    ? (s.hasThemeOverride ? 'theme★' : 'theme')
                    : 'global';
                const modeTag = s.fillMode === 'pattern' ? ' · tile' : (s.fillMode === 'gradient' ? ' · grad' : '');
                return `<button type="button" class="tcs-tile${on}" data-i="${i}">
                    <span class="tcs-tile-swatch" data-slot-swatch="${i}"></span>
                    <span class="tcs-tile-name">${s.name || ('Slot ' + (i + 1))}</span>
                    <span class="tcs-tile-num">#${i + 1}${modeTag} · <span class="tcs-tile-scope ${scopeCls}">${scopeLab}</span></span>
                </button>`;
            }).join('');
            slots.forEach((s, i) => {
                const sw = host.querySelector(`[data-slot-swatch="${i}"]`);
                if (sw) TC.paintFromSlot?.(sw, s);
            });
            host.querySelectorAll('[data-i]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    if (!loading && selected >= 0) {
                        await TC.updateSlot(selected, readPatch());
                    }
                    loadSlot(parseInt(btn.dataset.i, 10));
                });
            });
        };

        const persist = async (toast) => {
            if (loading) return;
            const patch = readPatch();
            await TC.updateSlot(selected, patch);
            paintTiles();
            paintPreviewChip();
            if (patch.fillMode === 'pattern') paintPatternGallery();
            const scopeNote = patch.scope === 'per-theme'
                ? `per-theme (${refreshThemeBanner()})`
                : 'global (all themes)';
            if (toast) {
                const modeNote = patch.fillMode === 'pattern'
                    ? `pattern · ${patch.tilePattern} · ${patch.tileScale}px`
                    : patch.fillMode === 'gradient'
                        ? `gradient · soft ${patch.blendSoftness}%`
                        : 'solid';
                setStatus(`Saved “${patch.name}” · ${modeNote} · ${scopeNote}`);
            }
            showToast?.('Color slot saved: ' + patch.name);
        };

        const schedule = () => {
            if (loading) return;
            updateValLabels();
            // Live thumbs: pattern gallery + slot tiles + big preview every tick
            paintPreviewChip();
            if (($id('tcs-fill-mode')?.value || '') === 'pattern') {
                paintPatternGallery();
            }
            // Live-update selected slot tile swatch without waiting for save
            try {
                const host = $id('tcs-tiles');
                const sw = host?.querySelector?.(`[data-slot-swatch="${selected}"]`);
                if (sw) TC.paintFromSlot?.(sw, readPatch());
            } catch (_) {}
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => persist(true), 320);
        };

        // Wire controls
        [
            'tcs-name', 'tcs-scope', 'tcs-fill-mode', 'tcs-border-mode', 'tcs-fill-count',
            'tcs-fill-a', 'tcs-fill-b', 'tcs-fill-c',
            'tcs-fill-alpha', 'tcs-fill-alpha-b', 'tcs-fill-alpha-c',
            'tcs-border-a', 'tcs-border-b', 'tcs-border-c',
            'tcs-border-alpha', 'tcs-border-alpha-b', 'tcs-border-alpha-c',
            'tcs-grad-pattern', 'tcs-grad-dir', 'tcs-blend', 'tcs-grad-stop', 'tcs-grad-stop-c',
            'tcs-tile-pattern', 'tcs-tile-scale',
        ].forEach((id) => {
            const el = $id(id);
            if (!el) return;
            el.addEventListener('input', () => { syncModeRows(); schedule(); });
            el.addEventListener('change', () => { syncModeRows(); schedule(); });
        });
        // Tile scale: force immediate gallery refresh (realtime thumb preview)
        $id('tcs-tile-scale')?.addEventListener('input', () => {
            if (loading) return;
            updateValLabels();
            if (($id('tcs-fill-mode')?.value || '') !== 'pattern') {
                if ($id('tcs-fill-mode')) $id('tcs-fill-mode').value = 'pattern';
                syncModeRows();
            }
            paintPatternGallery();
            paintPreviewChip();
            try {
                const host = $id('tcs-tiles');
                const sw = host?.querySelector?.(`[data-slot-swatch="${selected}"]`);
                if (sw) TC.paintFromSlot?.(sw, { ...readPatch(), fillMode: 'pattern' });
            } catch (_) {}
        });

        $id('tcs-save')?.addEventListener('click', () => persist(true));
        $id('tcs-add')?.addEventListener('click', async () => {
            await persist(false);
            await TC.addSlot({ name: `Slot ${(TC.getSlots()?.length || 0) + 1}` });
            const slots = TC.getSlots() || [];
            loadSlot(slots.length - 1);
            setStatus('Added slot ' + slots.length);
        });
        $id('tcs-reset')?.addEventListener('click', async () => {
            if (!confirm('Reset all named color slots to defaults? (theme-specific overrides stay until you clear them by setting a slot Global)')) return;
            await TC.resetSlots();
            loadSlot(0);
            setStatus('Slots reset to defaults');
        });

        // When user switches tag theme pack, reload effective slot looks
        document.addEventListener('fafo:tag-theme', () => {
            refreshThemeBanner();
            loadSlot(selected);
            setStatus('Theme changed · showing slots for this pack (per-theme overrides apply)');
        });

        // Wait for FAFOTagColors.load()
        const boot = async () => {
            try { await TC.load?.(); } catch (_) {}
            const nPat = (TC.TILE_PATTERNS || []).length;
            loadSlot(0);
            setStatus(
                `${(TC.getSlots() || []).length} slots · ${nPat} tile patterns · scale 4–96px · ` +
                `set Fill mode → Tile pattern to browse gallery · auto-save · included in Save As full config`
            );
        };
        boot();
    }
    wireTagColorSlotsUi();
    wireChosenTagStyleUi();

    /** Global “chosen / on-clip” tag look — live to all new-tab fields */
    function wireChosenTagStyleUi() {
        const TC = window.FAFOTagColors;
        if (!TC) return;
        const $id = (id) => $(id);
        const status = (msg) => {
            const el = $id('tcs-chosen-status');
            if (el) el.textContent = msg || '';
        };
        const lab = (id, val, suffix = '%') => {
            const el = $id(id);
            if (el) el.textContent = `${val}${suffix}`;
        };

        const read = () => {
            const n = (id, d) => {
                const v = parseInt($id(id)?.value, 10);
                return Number.isFinite(v) ? v / 100 : d;
            };
            return {
                enabled: !!$id('tcs-chosen-enabled')?.checked,
                fillMode: $id('tcs-chosen-mode')?.value || 'sphere',
                fillA: $id('tcs-chosen-a')?.value || '#7ef7ff',
                fillB: $id('tcs-chosen-b')?.value || '#00e5ff',
                fillC: $id('tcs-chosen-c')?.value || '#0066aa',
                fillAlpha: n('tcs-chosen-alpha', 0.98),
                fillAlphaB: n('tcs-chosen-alpha-b', 0.95),
                fillAlphaC: n('tcs-chosen-alpha-c', 0.92),
                textMode: $id('tcs-chosen-text-mode')?.value === 'auto' ? 'auto' : 'custom',
                textColor: $id('tcs-chosen-text')?.value || '#041018',
                borderMode: $id('tcs-chosen-border-mode')?.value || 'solid',
                borderA: $id('tcs-chosen-border')?.value || '#00ffa8',
                borderAlpha: 1,
                glow: n('tcs-chosen-glow', 0.55),
                blendSoftness: parseInt($id('tcs-chosen-soft')?.value, 10) || 70,
                lightX: parseInt($id('tcs-chosen-lx')?.value, 10) || 32,
                lightY: parseInt($id('tcs-chosen-ly')?.value, 10) || 28,
            };
        };

        const writeForm = (c) => {
            if (!c) return;
            if ($id('tcs-chosen-enabled')) $id('tcs-chosen-enabled').checked = c.enabled !== false;
            if ($id('tcs-chosen-mode')) $id('tcs-chosen-mode').value = c.fillMode || 'sphere';
            if ($id('tcs-chosen-a')) $id('tcs-chosen-a').value = c.fillA || '#7ef7ff';
            if ($id('tcs-chosen-b')) $id('tcs-chosen-b').value = c.fillB || '#00e5ff';
            if ($id('tcs-chosen-c')) $id('tcs-chosen-c').value = c.fillC || '#0066aa';
            if ($id('tcs-chosen-alpha')) $id('tcs-chosen-alpha').value = Math.round((c.fillAlpha ?? 0.98) * 100);
            if ($id('tcs-chosen-alpha-b')) $id('tcs-chosen-alpha-b').value = Math.round((c.fillAlphaB ?? 0.95) * 100);
            if ($id('tcs-chosen-alpha-c')) $id('tcs-chosen-alpha-c').value = Math.round((c.fillAlphaC ?? 0.92) * 100);
            if ($id('tcs-chosen-text-mode')) $id('tcs-chosen-text-mode').value = c.textMode === 'auto' ? 'auto' : 'custom';
            if ($id('tcs-chosen-text')) $id('tcs-chosen-text').value = c.textColor || '#041018';
            if ($id('tcs-chosen-border')) $id('tcs-chosen-border').value = c.borderA || '#00ffa8';
            if ($id('tcs-chosen-border-mode')) $id('tcs-chosen-border-mode').value = c.borderMode || 'solid';
            if ($id('tcs-chosen-glow')) $id('tcs-chosen-glow').value = Math.round((c.glow ?? 0.55) * 100);
            if ($id('tcs-chosen-soft')) $id('tcs-chosen-soft').value = c.blendSoftness ?? 70;
            if ($id('tcs-chosen-lx')) $id('tcs-chosen-lx').value = c.lightX ?? 32;
            if ($id('tcs-chosen-ly')) $id('tcs-chosen-ly').value = c.lightY ?? 28;
            updateLabs();
        };

        const updateLabs = () => {
            lab('tcs-chosen-alpha-val', $id('tcs-chosen-alpha')?.value ?? 98);
            lab('tcs-chosen-alpha-b-val', $id('tcs-chosen-alpha-b')?.value ?? 95);
            lab('tcs-chosen-alpha-c-val', $id('tcs-chosen-alpha-c')?.value ?? 92);
            lab('tcs-chosen-glow-val', $id('tcs-chosen-glow')?.value ?? 55);
            lab('tcs-chosen-soft-val', $id('tcs-chosen-soft')?.value ?? 70);
            lab('tcs-chosen-lx-val', $id('tcs-chosen-lx')?.value ?? 32);
            lab('tcs-chosen-ly-val', $id('tcs-chosen-ly')?.value ?? 28);
            const textOn = ($id('tcs-chosen-text-mode')?.value || 'custom') === 'custom';
            if ($id('tcs-chosen-text')) $id('tcs-chosen-text').disabled = !textOn;
        };

        const paintPreviews = () => {
            try {
                TC.paintChosenPreview?.($id('tcs-chosen-preview'));
                TC.paintChosenPreview?.($id('tcs-chosen-preview-2'));
                TC.paintChosenPreview?.($id('tcs-chosen-preview-3'));
            } catch (_) {}
        };

        let timer = null;
        const applyLive = () => {
            updateLabs();
            const patch = read();
            // Immediate preview in Options
            try {
                TC.setChosen?.(patch, { persist: false, paint: false });
            } catch (_) {}
            paintPreviews();
            clearTimeout(timer);
            timer = setTimeout(async () => {
                try {
                    await TC.setChosen?.(patch, { persist: true, paint: true });
                    status(`Live · ${patch.fillMode}${patch.enabled ? '' : ' (off)'}`);
                } catch (e) {
                    status('Save failed');
                }
            }, 120);
        };

        const ids = [
            'tcs-chosen-enabled', 'tcs-chosen-mode', 'tcs-chosen-text-mode', 'tcs-chosen-text',
            'tcs-chosen-a', 'tcs-chosen-b', 'tcs-chosen-c', 'tcs-chosen-border', 'tcs-chosen-border-mode',
            'tcs-chosen-alpha', 'tcs-chosen-alpha-b', 'tcs-chosen-alpha-c',
            'tcs-chosen-glow', 'tcs-chosen-soft', 'tcs-chosen-lx', 'tcs-chosen-ly',
        ];
        ids.forEach((id) => {
            const el = $id(id);
            if (!el) return;
            el.addEventListener('input', applyLive);
            el.addEventListener('change', applyLive);
        });
        $id('tcs-chosen-reset')?.addEventListener('click', async () => {
            const d = TC.defaultChosen?.() || {};
            writeForm(d);
            await TC.setChosen?.(d, { persist: true, paint: true });
            paintPreviews();
            status('Reset to default sphere look');
        });

        (async () => {
            try { await TC.load?.(); } catch (_) {}
            writeForm(TC.getChosen?.() || TC.defaultChosen?.());
            paintPreviews();
            status('Live');
        })();
    }

    // --- Full system config Save As + clear tag colors (Options only) ---
    function wireConfigManagementUi() {
        const status = (msg) => {
            const el = $('cfg-mgmt-status');
            if (el) el.textContent = msg || '';
        };
        const DEFAULT_PATH =
            window.FAFOBackup?.DEFAULT_CONFIGS_PATH
            || 'C:\\_Git\\repos\\html\\fafo-chrome-extensions\\FAFO Local Media LOAD THIS\\configs';

        async function refreshPathField() {
            let path = DEFAULT_PATH;
            try {
                if (window.FAFOBackup?.getConfigsFolderPath) {
                    path = await FAFOBackup.getConfigsFolderPath();
                }
            } catch (_) {}
            if ($('cfg-folder-path')) $('cfg-folder-path').value = path;
            if ($('cfg-folder-hint')) {
                $('cfg-folder-hint').textContent =
                    `Default / remembered folder: ${path} · Save As always lets you pick the real file location. ` +
                    `Copy files into that folder so you always know where they live.`;
            }
        }

        async function refreshConfigList() {
            const host = $('cfg-list');
            if (!host) return;
            let list = [];
            try {
                list = (await window.FAFOBackup?.listNamedConfigs?.()) || [];
            } catch (_) {}
            if (!list.length) {
                host.innerHTML = '<p style="color:#555;font-size:0.8rem;margin:0;">No named configs yet — use Save As above.</p>';
                return;
            }
            host.innerHTML = list.map((e) => {
                const when = e.savedAtIso
                    ? new Date(e.savedAtIso).toLocaleString()
                    : (e.savedAt ? new Date(e.savedAt).toLocaleString() : '—');
                const path = e.savedPath || ((e.pathHint || '') + '\\' + (e.filename || ''));
                return `<div style="padding:10px 12px;border:1px solid #2a2a32;border-radius:10px;background:#08080c;">
                    <div style="font-weight:700;color:#eee;">${escapeHtmlOpt(e.name || 'Unnamed')}</div>
                    <div style="font-size:0.72rem;color:#888;margin-top:4px;line-height:1.4;">
                        ${when} · ${escapeHtmlOpt(e.filename || '')}<br>
                        <span style="font-family:ui-monospace,Consolas,monospace;color:#666;">${escapeHtmlOpt(path)}</span>
                    </div>
                </div>`;
            }).join('');
        }

        function escapeHtmlOpt(s) {
            return String(s || '')
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;');
        }

        $('cfg-folder-reset')?.addEventListener('click', async () => {
            if ($('cfg-folder-path')) $('cfg-folder-path').value = DEFAULT_PATH;
            try { await window.FAFOBackup?.setConfigsFolderPath?.(DEFAULT_PATH); } catch (_) {}
            await refreshPathField();
            status('Path reset to repo configs folder');
        });
        $('cfg-folder-save')?.addEventListener('click', async () => {
            const p = ($('cfg-folder-path')?.value || '').trim() || DEFAULT_PATH;
            try {
                await window.FAFOBackup?.setConfigsFolderPath?.(p);
                status('Remembered folder: ' + p);
                showToast('Configs folder path saved');
            } catch (e) {
                status('Could not save path: ' + (e.message || e));
            }
            await refreshPathField();
        });

        $('cfg-save-as')?.addEventListener('click', async () => {
            const name = ($('cfg-save-name')?.value || '').trim();
            if (!name) {
                status('Enter a config name first (Save As always requires a name)');
                showToast('Name required for Save As', 'error');
                return;
            }
            const pathHint = ($('cfg-folder-path')?.value || '').trim() || DEFAULT_PATH;
            status('Saving full system config…');
            try {
                const result = await window.FAFOBackup.saveFullConfigAs(name, { suggestedPath: pathHint });
                status(
                    `Saved “${name}” as ${result.filename} · ${result.method} · ` +
                    `put/keep file under: ${result.pathHint}`
                );
                showToast('Full config saved: ' + name);
                if ($('cfg-save-name')) $('cfg-save-name').value = '';
                await refreshConfigList();
            } catch (e) {
                const msg = e?.message || String(e);
                if (/cancel/i.test(msg)) {
                    status('Save cancelled');
                } else {
                    status('Save failed: ' + msg);
                    showToast('Save failed: ' + msg, 'error');
                }
            }
        });

        $('cfg-load')?.addEventListener('click', () => $('cfg-load-file')?.click());
        $('cfg-load-file')?.addEventListener('change', async (ev) => {
            const file = ev.target?.files?.[0];
            ev.target.value = '';
            if (!file) return;
            if (!confirm(
                `Load full system config from “${file.name}”?\n\n` +
                `This replaces options, themes, color slots, tag colors, layout, scales, and related settings in this browser.\n` +
                `A safety snapshot is taken first.`
            )) return;
            status('Loading config…');
            try {
                const r = await (window.FAFOBackup.importFullConfigFromFile
                    ? FAFOBackup.importFullConfigFromFile(file)
                    : FAFOBackup.importFromFile(file, { fullSystem: true }));
                status(
                    `Loaded config · media ${r.mediaEntries ?? '—'} · tags ${r.tags ?? '—'} · ` +
                    `Reload Options / open a new tab to see everything.`
                );
                showToast('Config loaded — refresh new tab');
                // Reload color slots UI if present
                try {
                    await window.FAFOTagColors?.load?.();
                    // re-select first slot if editor exists
                    const bootBtn = $('tcs-tiles')?.querySelector('[data-i="0"]');
                    bootBtn?.click();
                } catch (_) {}
                try { await window.FAFOTagThemes?.load?.(); } catch (_) {}
            } catch (e) {
                status('Load failed: ' + (e.message || e));
                showToast('Load failed: ' + (e.message || e), 'error');
            }
        });

        $('cfg-clear-tag-colors')?.addEventListener('click', async () => {
            if (!window.FAFOTagColors?.clearAllTagAssignments) {
                showToast('Color module missing', 'error');
                return;
            }
            const ok = confirm(
                'Clear ALL assigned tag colors?\n\n' +
                '• Every tag loses its custom color / slot link and falls back to the theme pack\n' +
                '• Named color slots (Subject, Weapons, gradients, patterns) are KEPT\n' +
                '• This cannot be undone unless you Load a saved full config\n\n' +
                'Continue?'
            );
            if (!ok) return;
            const ok2 = confirm('Final confirmation: clear all tag→color assignments now?');
            if (!ok2) return;
            try {
                const r = await FAFOTagColors.clearAllTagAssignments();
                status(`Cleared ${r.cleared} tag color assignment(s). Slots palette unchanged.`);
                showToast(`Cleared ${r.cleared} tag color(s)`);
            } catch (e) {
                status('Clear failed: ' + (e.message || e));
                showToast('Clear failed', 'error');
            }
        });

        refreshPathField();
        refreshConfigList();
    }
    wireConfigManagementUi();

    // --- Session / intro frequency ---
    async function wireSessionUi() {
        if (!window.FAFOSession) return;
        const prefs = await FAFOSession.readIntroPrefs();
        const mode = $('session-intro-mode');
        const quiet = $('session-quiet-splash');
        if (mode) mode.value = prefs.mode || 'daily';
        if (quiet) quiet.checked = prefs.quietSplash !== false;
        $('session-save')?.addEventListener('click', async () => {
            await FAFOSession.writeIntroPrefs({
                mode: mode?.value || 'daily',
                quietSplash: !!quiet?.checked,
            });
            const st = $('session-status');
            if (st) st.textContent = 'Saved · next new tab uses these intro rules';
            showToast('Session / intro prefs saved');
        });
    }
    wireSessionUi().catch(() => {});

    // --- Advanced Visual FX (colors / gradients / animations) ---
    function readVisualForm() {
        const g = (id, d) => $(id)?.value || d;
        const c = (id) => !!$(id)?.checked;
        const n = (id, d) => {
            const v = parseInt($(id)?.value, 10);
            return Number.isFinite(v) ? v : d;
        };
        return {
            colors: {
                accent: g('vis-accent', '#00e5ff'),
                accent2: g('vis-accent2', '#2dd4bf'),
                accent3: g('vis-accent3', '#a78bfa'),
                useAccentGradient: c('vis-use-accent-grad'),
                bg: g('vis-bg', '#050505'),
                bg2: g('vis-bg2', '#0a0a12'),
                bg3: g('vis-bg3', '#050510'),
                useBgGradient: c('vis-use-bg-grad'),
                text: g('vis-text', '#eeeeee'),
                textDim: g('vis-text-dim', '#888888'),
                panelBorder: g('vis-panel-border', '#00e5ff'),
                tagSelected: g('vis-tag-selected', '#00ffa8'),
                tagLastVideo: g('vis-tag-last', '#ffc107'),
                tagSession: g('vis-tag-session', '#2dd4bf'),
                tagLibrary: g('vis-tag-library', '#a78bfa'),
                tagUnused: g('vis-tag-unused', '#666666'),
                sprint: g('vis-sprint', '#ffc107'),
                neon: g('vis-neon', '#00e5ff'),
                mouseGlow: g('vis-mouse-glow', '#00e5ff'),
            },
            gradients: {
                accentAngle: n('vis-accent-angle', 135),
                bgAngle: n('vis-bg-angle', 160),
                panelAngle: 180,
            },
            anim: {
                background: g('vis-bg-anim', 'none'),
                backgroundSpeed: n('vis-bg-speed', 100) / 100,
                backgroundIntensity: n('vis-bg-intensity', 45) / 100,
                mouse: g('vis-mouse-anim', 'none'),
                mouseSize: n('vis-mouse-size', 140),
                mouseOpacity: n('vis-mouse-op', 35) / 100,
                tagSelected: g('vis-tag-sel-anim', 'neon'),
                tagLastVideo: g('vis-tag-last-anim', 'breathe-gold'),
                panelPulse: c('vis-panel-pulse'),
                hudBreath: c('vis-hud-breath'),
                reduceMotion: c('vis-reduce-motion'),
            },
            cursor: {
                profile: g('vis-cursor-profile', 'theme'),
                themeId: g('vis-cursor-theme', 'cyan'),
                hover: g('vis-cursor-hover', 'theme'),
                leftClick: g('vis-cursor-left', 'theme'),
                rightClick: g('vis-cursor-right', 'theme'),
                intensity: n('vis-cursor-i', 75) / 100,
                size: n('vis-cursor-s', 100) / 100,
            },
            borders: {
                style: g('vis-border-style', 'glow'),
                width: n('vis-border-w', 1),
                radius: n('vis-border-r', 14),
                glow: n('vis-border-glow', 10),
                color: g('vis-border-c1', '#00e5ff'),
                color2: g('vis-border-c2', '#a78bfa'),
                color3: g('vis-border-c3', '#2dd4bf'),
                animSpeed: n('vis-border-speed', 100) / 100,
                frameStyle: g('vis-frame-style', 'match'),
            },
            lights: {
                vignette: c('vis-light-vignette'),
                vignetteStrength: n('vis-vignette', 40) / 100,
                bloom: c('vis-light-bloom'),
                bloomStrength: n('vis-bloom', 30) / 100,
                scanlines: c('vis-light-scanlines'),
                scanlinesOpacity: n('vis-scan', 7) / 100,
                crt: c('vis-light-crt'),
                ambient: g('vis-light-ambient', 'none'),
                ambientStrength: n('vis-ambient', 35) / 100,
                colorWash: c('vis-light-wash'),
                colorWashOpacity: n('vis-scan', 7) / 100,
                flicker: c('vis-light-flicker'),
                godRays: c('vis-light-rays'),
                godRaysStrength: n('vis-scan', 7) / 100 * 3,
            },
        };
    }

    function fillVisualForm(v) {
        if (!v) return;
        const c = v.colors || {};
        const g = v.gradients || {};
        const a = v.anim || {};
        const b = v.borders || {};
        const L = v.lights || {};
        const set = (id, val) => { const el = $(id); if (el && val != null) el.value = val; };
        const setC = (id, on) => { const el = $(id); if (el) el.checked = !!on; };
        set('vis-accent', c.accent);
        set('vis-accent2', c.accent2);
        set('vis-accent3', c.accent3);
        setC('vis-use-accent-grad', c.useAccentGradient);
        set('vis-bg', c.bg);
        set('vis-bg2', c.bg2);
        set('vis-bg3', c.bg3);
        setC('vis-use-bg-grad', c.useBgGradient);
        set('vis-tag-selected', c.tagSelected);
        set('vis-tag-last', c.tagLastVideo);
        set('vis-tag-session', c.tagSession);
        set('vis-tag-library', c.tagLibrary);
        set('vis-tag-unused', c.tagUnused);
        set('vis-text', c.text);
        set('vis-text-dim', c.textDim);
        set('vis-panel-border', c.panelBorder);
        set('vis-sprint', c.sprint);
        set('vis-neon', c.neon);
        set('vis-mouse-glow', c.mouseGlow);
        set('vis-accent-angle', g.accentAngle ?? 135);
        set('vis-bg-angle', g.bgAngle ?? 160);
        set('vis-bg-anim', a.background || 'none');
        set('vis-mouse-anim', a.mouse || 'none');
        set('vis-tag-sel-anim', a.tagSelected || 'neon');
        set('vis-tag-last-anim', a.tagLastVideo || 'breathe-gold');
        set('vis-bg-speed', Math.round((a.backgroundSpeed ?? 1) * 100));
        set('vis-bg-intensity', Math.round((a.backgroundIntensity ?? 0.45) * 100));
        set('vis-mouse-size', a.mouseSize ?? 140);
        set('vis-mouse-op', Math.round((a.mouseOpacity ?? 0.35) * 100));
        setC('vis-panel-pulse', a.panelPulse);
        setC('vis-hud-breath', a.hudBreath);
        setC('vis-reduce-motion', a.reduceMotion);
        const cur = v.cursor || {};
        set('vis-cursor-profile', cur.profile || 'theme');
        set('vis-cursor-theme', cur.themeId || 'cyan');
        set('vis-cursor-hover', cur.hover || 'theme');
        set('vis-cursor-left', cur.leftClick || 'theme');
        set('vis-cursor-right', cur.rightClick || 'theme');
        set('vis-cursor-i', Math.round((cur.intensity ?? 0.75) * 100));
        set('vis-cursor-s', Math.round((cur.size ?? 1) * 100));
        set('vis-border-style', b.style || 'glow');
        set('vis-frame-style', b.frameStyle || 'match');
        set('vis-border-c1', b.color || '#00e5ff');
        set('vis-border-c2', b.color2 || '#a78bfa');
        set('vis-border-c3', b.color3 || '#2dd4bf');
        set('vis-border-w', b.width ?? 1);
        set('vis-border-r', b.radius ?? 14);
        set('vis-border-glow', b.glow ?? 10);
        set('vis-border-speed', Math.round((b.animSpeed ?? 1) * 100));
        setC('vis-light-vignette', L.vignette);
        setC('vis-light-bloom', L.bloom);
        setC('vis-light-scanlines', L.scanlines);
        setC('vis-light-crt', L.crt);
        setC('vis-light-wash', L.colorWash);
        setC('vis-light-flicker', L.flicker);
        setC('vis-light-rays', L.godRays);
        set('vis-light-ambient', L.ambient || 'none');
        set('vis-vignette', Math.round((L.vignetteStrength ?? 0.4) * 100));
        set('vis-bloom', Math.round((L.bloomStrength ?? 0.3) * 100));
        set('vis-ambient', Math.round((L.ambientStrength ?? 0.35) * 100));
        set('vis-scan', Math.round((L.scanlinesOpacity ?? 0.07) * 100));
        updateVisualLabels();
        updateGradPreview();
    }

    function updateVisualLabels() {
        const set = (id, t) => { const el = $(id); if (el) el.textContent = t; };
        set('vis-accent-angle-val', ($('vis-accent-angle')?.value || 135) + '°');
        set('vis-bg-angle-val', ($('vis-bg-angle')?.value || 160) + '°');
        const sp = parseInt($('vis-bg-speed')?.value || 100, 10) / 100;
        set('vis-bg-speed-val', (Math.round(sp * 100) / 100) + '×');
        set('vis-bg-intensity-val', ($('vis-bg-intensity')?.value || 45) + '%');
        set('vis-mouse-size-val', $('vis-mouse-size')?.value || 140);
        set('vis-mouse-op-val', ($('vis-mouse-op')?.value || 35) + '%');
        set('vis-cursor-i-val', ($('vis-cursor-i')?.value || 75) + '%');
        const cs = parseInt($('vis-cursor-s')?.value || 100, 10) / 100;
        set('vis-cursor-s-val', (Math.round(cs * 100) / 100) + '×');
        set('vis-border-w-val', ($('vis-border-w')?.value || 1) + 'px');
        set('vis-border-r-val', $('vis-border-r')?.value || 14);
        set('vis-border-glow-val', $('vis-border-glow')?.value || 10);
        const bs = parseInt($('vis-border-speed')?.value || 100, 10) / 100;
        set('vis-border-speed-val', (Math.round(bs * 100) / 100) + '×');
        set('vis-vignette-val', ($('vis-vignette')?.value || 40) + '%');
        set('vis-bloom-val', ($('vis-bloom')?.value || 30) + '%');
        set('vis-ambient-val', ($('vis-ambient')?.value || 35) + '%');
        set('vis-scan-val', ($('vis-scan')?.value || 7) + '%');
    }

    function updateGradPreview() {
        const prev = $('vis-grad-preview');
        if (!prev || !window.FAFOVisual) return;
        const f = readVisualForm();
        if (f.colors.useAccentGradient) {
            prev.style.background = FAFOVisual.gradient(
                f.colors.accent, f.colors.accent2, f.colors.accent3,
                f.gradients.accentAngle, true
            );
        } else if (f.colors.useBgGradient) {
            prev.style.background = FAFOVisual.gradient(
                f.colors.bg, f.colors.bg2, f.colors.bg3,
                f.gradients.bgAngle, true
            );
        } else {
            prev.style.background = f.colors.accent;
        }
    }

    async function applyVisualFromForm(opts = {}) {
        if (!window.FAFOVisual) return null;
        const visual = FAFOVisual.normalize(readVisualForm());
        FAFOVisual.apply(visual);
        // Keep primary accent pickers in sync for theme engine
        if ($('accent-color') && visual.colors.accent) {
            $('accent-color').value = visual.colors.accent;
            applyTheme(visual.colors.accent);
        }
        if (opts.save) {
            await FAFOVisual.saveToStorage(visual);
            currentConfig.visual = visual;
            currentConfig.accentColor = visual.colors.accent;
            if ($('vis-status')) {
                $('vis-status').textContent = 'Visual FX saved · open a new tab to see full player effect';
            }
            if (opts.toast) showToast('Visual FX saved');
            scheduleFullBackup('visual-fx');
        } else if ($('vis-status')) {
            $('vis-status').textContent = 'Preview applied on this Options page (not saved yet)';
        }
        updateGradPreview();
        return visual;
    }

    function wireVisualFxUi() {
        if (!window.FAFOVisual) return;
        const liveIds = [
            'vis-accent', 'vis-accent2', 'vis-accent3', 'vis-use-accent-grad',
            'vis-bg', 'vis-bg2', 'vis-bg3', 'vis-use-bg-grad',
            'vis-tag-selected', 'vis-tag-last', 'vis-tag-session', 'vis-tag-library', 'vis-tag-unused',
            'vis-text', 'vis-text-dim', 'vis-panel-border', 'vis-sprint', 'vis-mouse-glow', 'vis-neon',
            'vis-accent-angle', 'vis-bg-angle',
            'vis-bg-anim', 'vis-mouse-anim', 'vis-tag-sel-anim', 'vis-tag-last-anim',
            'vis-bg-speed', 'vis-bg-intensity', 'vis-mouse-size', 'vis-mouse-op',
            'vis-panel-pulse', 'vis-hud-breath', 'vis-reduce-motion',
            'vis-cursor-profile', 'vis-cursor-theme', 'vis-cursor-hover', 'vis-cursor-left', 'vis-cursor-right',
            'vis-cursor-i', 'vis-cursor-s',
            'vis-border-style', 'vis-frame-style', 'vis-border-c1', 'vis-border-c2', 'vis-border-c3',
            'vis-border-w', 'vis-border-r', 'vis-border-glow', 'vis-border-speed',
            'vis-light-vignette', 'vis-light-bloom', 'vis-light-scanlines', 'vis-light-crt',
            'vis-light-wash', 'vis-light-flicker', 'vis-light-rays', 'vis-light-ambient',
            'vis-vignette', 'vis-bloom', 'vis-ambient', 'vis-scan',
        ];
        // Populate unique cursor FX dropdowns once
        const fillCursorSelects = () => {
            const list = window.FAFOVisual?.CURSOR_FX_LIST || [{ id: 'theme', label: 'Follow theme' }, { id: 'none', label: 'None' }];
            ['vis-cursor-hover', 'vis-cursor-left', 'vis-cursor-right'].forEach((id) => {
                const sel = $(id);
                if (!sel || sel.options.length > 1) return;
                sel.innerHTML = list.map((fx) =>
                    `<option value="${fx.id}">${fx.label}</option>`
                ).join('');
            });
        };
        fillCursorSelects();
        liveIds.forEach((id) => {
            $(id)?.addEventListener('input', () => {
                updateVisualLabels();
                updateGradPreview();
            });
            $(id)?.addEventListener('change', () => {
                updateVisualLabels();
                updateGradPreview();
            });
        });
        $('vis-preview')?.addEventListener('click', () => applyVisualFromForm({ save: false, toast: false }));
        $('vis-save')?.addEventListener('click', () => applyVisualFromForm({ save: true, toast: true }));
        $('vis-reset')?.addEventListener('click', async () => {
            if (!confirm('Reset all advanced visual colors & animations to defaults?')) return;
            fillVisualForm(FAFOVisual.DEFAULTS);
            await applyVisualFromForm({ save: true, toast: true });
        });
        FAFOVisual.loadFromStorage().then((v) => {
            fillCursorSelects();
            fillVisualForm(v);
            try { FAFOVisual.apply(v); } catch (_) {}
        }).catch(() => {});
    }

    // --- THUMBNAIL QUEUE SYSTEM ---
    const thumbQueue = {
        active: 0, queue: [], limit: 3,
        add: function(file, imgElement) { this.queue.push({file, imgElement}); this.process(); },
        process: async function() {
            if (this.active >= this.limit || this.queue.length === 0) return;
            this.active++;
            const task = this.queue.shift();
            try {
                const url = await generateThumbnail(task.file);
                if (url) task.imgElement.src = url;
            } catch(e) { console.log("Thumb gen failed", e); } finally { this.active--; this.process(); }
        }
    };

    // --- TABS SYSTEM ---
    document.querySelectorAll('.tab').forEach(t => {
        t.onclick = () => {
            document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
            document.querySelectorAll('.view-section').forEach(x => x.classList.remove('active'));
            t.classList.add('active');
            const target = $(t.dataset.target);
            if(target) target.classList.add('active');
            if (t.dataset.target === 'view-library') loadLibraryGrid();
            if (t.dataset.target === 'view-playlists') loadPlaylistsUI();
            if (t.dataset.target === 'view-chrome-art') refreshChromeArtUi();
            if (t.dataset.target === 'view-pairing' && window.FAFOPairs) {
                FAFOPairs.onActivate({ db });
            }
            if (t.dataset.target === 'view-backup' && !privateOptionsMode) refreshTagsBackupUI();
            if (t.dataset.target === 'view-tags') refreshTagsOptionsUI();
        };
    });

    // --- SLIDERS UI ---
    function initSliders() {
        document.querySelectorAll('input[type=range]').forEach(el => {
            const span = document.getElementById(el.id + '-val');
            if(span) {
                span.textContent = el.value;
                el.addEventListener('input', () => span.textContent = el.value);
            }
        });
    }

    // --- THEME ENGINE ---
    function applyTheme(hex) {
        if (!hex) return;
        const root = document.documentElement;
        const hexToRgb = (h) => {
            const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
            h = h.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h);
            return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null;
        };
        const rgb = hexToRgb(hex);
        if (rgb) {
            root.style.setProperty('--accent', hex);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }
    }

    // --- DB INIT (v4: folders store for persistent directory handles) ---
    async function openDB() {
        try {
            if (window.FAFOLibrary?.openDB) {
                db = await FAFOLibrary.openDB();
                return db;
            }
        } catch (e) {
            console.error('FAFOLibrary openDB', e);
            if (/blocked|version/i.test(String(e))) {
                alert('Database upgrade blocked — close other FAFO / New Tab windows and reload Options.');
            }
        }
        return new Promise((res) => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            req.onblocked = () => alert('Database Upgrade Blocked! Close other New Tab pages and reload.');
            req.onupgradeneeded = (e) => {
                const d = e.target.result;
                ['videos', 'photos'].forEach((s) => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', { keyPath: 'id' });
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = () => { db = req.result; res(db); };
            req.onerror = (e) => { console.error('DB Error', e); res(null); };
        });
    }

    // --- LOAD SETTINGS ---
    async function loadSettings() {
        await openDB();
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        
        const defaults = {
            useLocal: true, usePhotos: true, urls: [], 
            layout: 'cinema', scaling: 'scale-contain',
            gridCols: 4, gridRows: 1, 
            carouselRadius: 650, carouselTilt: 0, carouselSpeed: 40,
            reflectOpacity: 30, reflectOffset: 0,

            neonBorder: false, neonPattern: 'chase', neonSegments: 24,
            neonSpeed: 1, neonAudio: true, neonStrobe: 0.8,
            neonSensitivity: 1.2, neonWidth: 4, neonUseAccent: true, neonColor: '#00e5ff',
            
            // FX DEFAULTS
            fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
            fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
            fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
            fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
            fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
            fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,

            brightness: 100, contrast: 100, saturate: 100, sepia: 0, grayscale: 0,
            ambiScale: 1.0, ambiOpacity: 0.25, ambiBlur: 5, ambiMode: 'blur',
            borderSize: 0, borderColor: '#44858d', borderGlow: 15,
            screenFrameEnabled: false, screenFrameSize: 3, screenFrameColor: '#00e5ff',
            screenFrameGlow: 12, screenFrameOpacity: 0.9, screenFrameStyle: 'solid', screenFrameRadius: 0,
            volume: 0.7, photoDuration: 3, shuffle: true,
            playbackSpeed: 1, loops: 1, kenburns: true,
            clockSize: 25, font: "'Arial Black', sans-serif", pos: 'pos-bottom-left',
            showDate: true, format12h: true, showSeconds: false,
            accentColor: '#00e5ff', activePlaylistId: 'all', overrides: {},
            uiThemePreset: 'cyan',
            uiPanelOpacity: 0.92,
            uiHudOpacity: 0.82,
            uiPanelBorderOpacity: 0.14,
            uiRadius: 14,
            uiPanelBorderColor: '#00e5ff',
            performanceMode: false,
            maxDisplayHeight: 0,
            disableAmbience: false,
            disableParticles: false,
            disableCssFilters: false,
            disableNeonAudio: false,
        };

        currentConfig = {...defaults, ...mediaConfig};
        applyTheme(currentConfig.accentColor);

        const set = (id, val, type) => {
            const el = $(id);
            if(!el) return;
            if (type === 'check') el.checked = val;
            else if (type === 'val') el.value = val;
            else if (type === 'array') el.value = (val || []).join('\n'); 
            else el.value = val;
            
            if(el.type === 'range') {
                const span = document.getElementById(el.id + '-val');
                if(span) span.textContent = val;
            }
        };

        // Basic fields
        Object.keys(currentConfig).forEach(k => {
            if(k === 'overrides') return;
            const el = $(k);
            if(el) set(k, currentConfig[k], el.type === 'checkbox' ? 'check' : (k === 'urls' ? 'array' : 'val'));
        });
        
        // Manual Mappings
        set('grid-cols', currentConfig.gridCols); set('grid-rows', currentConfig.gridRows);
        set('carousel-radius', currentConfig.carouselRadius); set('carousel-tilt', currentConfig.carouselTilt);
        set('carousel-speed', currentConfig.carouselSpeed); set('reflect-opacity', currentConfig.reflectOpacity);
        set('reflect-offset', currentConfig.reflectOffset);

        // Dynamic FX Loading
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            set(`fx-${type}`, currentConfig[camelCase(`fx-${type}`)], 'check');
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                set(id, currentConfig[camelCase(id)]);
            });
        });

        set('ambi-mode', currentConfig.ambiMode);
        set('ambi-scale', currentConfig.ambiScale);
        set('ambi-opacity', currentConfig.ambiOpacity);
        set('ambi-blur', currentConfig.ambiBlur);
        set('border-color', currentConfig.borderColor);
        set('performanceMode', currentConfig.performanceMode, 'check');
        set('maxDisplayHeight', currentConfig.maxDisplayHeight ?? 0);
        set('disableAmbience', currentConfig.disableAmbience, 'check');
        set('disableParticles', currentConfig.disableParticles, 'check');
        set('disableCssFilters', currentConfig.disableCssFilters, 'check');
        set('disableNeonAudio', currentConfig.disableNeonAudio, 'check');
        set('border-glow', currentConfig.borderGlow);
        set('photo-duration', currentConfig.photoDuration);
        set('clock-pos', currentConfig.pos);
        set('clock-size', currentConfig.clockSize);
        set('font-family', currentConfig.font);
        set('show-date', currentConfig.showDate, 'check');
        set('format-12h', currentConfig.format12h, 'check');
        set('show-seconds', currentConfig.showSeconds, 'check');
        set('use-local', currentConfig.useLocal, 'check');
        set('use-photos', currentConfig.usePhotos, 'check');
        set('urls', currentConfig.urls, 'array');
        set('accent-color', currentConfig.accentColor);
        set('uiThemePreset', currentConfig.uiThemePreset || 'cyan');
        set('uiPanelOpacity', currentConfig.uiPanelOpacity ?? 0.92);
        set('uiHudOpacity', currentConfig.uiHudOpacity ?? 0.82);
        set('uiPanelBorderOpacity', currentConfig.uiPanelBorderOpacity ?? 0.14);
        set('uiRadius', currentConfig.uiRadius ?? 14);
        set('uiPanelBorderColor', currentConfig.uiPanelBorderColor || currentConfig.accentColor || '#00e5ff');
        set('border-size', currentConfig.borderSize ?? 0);
        set('border-glow', currentConfig.borderGlow ?? 15);
        set('screen-frame-enabled', !!currentConfig.screenFrameEnabled, 'check');
        set('screen-frame-size', currentConfig.screenFrameSize ?? 3);
        set('screen-frame-glow', currentConfig.screenFrameGlow ?? 12);
        set('screen-frame-opacity', currentConfig.screenFrameOpacity ?? 0.9);
        set('screen-frame-color', currentConfig.screenFrameColor || '#00e5ff');
        set('screen-frame-style', currentConfig.screenFrameStyle || 'solid');
        set('screen-frame-radius', currentConfig.screenFrameRadius ?? 0);
        // Live val labels for new ranges
        ['uiPanelOpacity', 'uiHudOpacity', 'uiPanelBorderOpacity', 'uiRadius',
            'screen-frame-size', 'screen-frame-glow', 'screen-frame-opacity', 'screen-frame-radius'].forEach((id) => {
            const el = $(id);
            const span = $(id + '-val');
            if (el && span) {
                span.textContent = el.value;
                el.addEventListener('input', () => { span.textContent = el.value; });
            }
        });
        // Solidified dark theme packs (UI chrome + accent)
        const THEME_PACKS = [
            { id: 'cyan',    name: 'Cyan neon',     blurb: 'Default cyber FAFO — matches media tools', accent: '#00e5ff', border: '#00e5ff', bg1: '#0c0c12', bg2: '#050508', glow: 'rgba(0,229,255,0.4)', tag: 'Default' },
            { id: 'amber',   name: 'Amber field',   blurb: 'Warm industrial — FAFOPetro service vibe', accent: '#ffb300', border: '#ffc107', bg1: '#18140a', bg2: '#0a0804', glow: 'rgba(255,179,0,0.4)', tag: 'Petro' },
            { id: 'violet',  name: 'Violet haze',   blurb: 'Premium AI corner / Architect feel', accent: '#b388ff', border: '#b388ff', bg1: '#120e18', bg2: '#08060c', glow: 'rgba(179,136,255,0.4)', tag: 'AI' },
            { id: 'green',   name: 'Matrix green',  blurb: 'Terminal / Progen tech energy', accent: '#69f0ae', border: '#69f0ae', bg1: '#0a1410', bg2: '#040a06', glow: 'rgba(105,240,174,0.35)', tag: 'Progen' },
            { id: 'steel',   name: 'Steel minimal', blurb: 'Quiet professional dashboard', accent: '#90a4ae', border: '#90a4ae', bg1: '#101214', bg2: '#060708', glow: 'rgba(144,164,174,0.3)', tag: 'Business' },
            { id: 'ice',     name: 'Ice blue',      blurb: 'Cool glass, soft contrast on video', accent: '#80deea', border: '#e0f7fa', bg1: '#0a1014', bg2: '#04080c', glow: 'rgba(128,222,234,0.35)', tag: 'Cool' },
            { id: 'rose',    name: 'Rose pulse',    blurb: 'Hot accent for highlight reels', accent: '#ff80ab', border: '#ff80ab', bg1: '#161014', bg2: '#0a0608', glow: 'rgba(255,128,171,0.35)', tag: 'Show' },
            { id: 'crimson', name: 'Crimson',       blurb: 'High-drama cinema frames', accent: '#ff5252', border: '#ff5252', bg1: '#140a0a', bg2: '#080404', glow: 'rgba(255,82,82,0.35)', tag: 'Cinema' },
        ];
        const presetMap = Object.fromEntries(THEME_PACKS.map((p) => [p.id, { accent: p.accent, border: p.border }]));
        customThemes = Array.isArray(currentConfig.customThemes) ? currentConfig.customThemes.slice() : [];
        selectedCustomThemeId = currentConfig.activeCustomThemeId || '';

        async function loadCustomThemesStore() {
            try {
                const { fafoCustomThemes = [], fafoActiveCustomThemeId = '' } = await chrome.storage.local.get([
                    'fafoCustomThemes', 'fafoActiveCustomThemeId',
                ]);
                if (Array.isArray(fafoCustomThemes)) customThemes = fafoCustomThemes;
                if (fafoActiveCustomThemeId) selectedCustomThemeId = fafoActiveCustomThemeId;
                if (Array.isArray(currentConfig.customThemes) && currentConfig.customThemes.length) {
                    customThemes = currentConfig.customThemes;
                }
            } catch (_) {}
        }

        async function persistCustomThemes() {
            currentConfig.customThemes = customThemes;
            currentConfig.activeCustomThemeId = selectedCustomThemeId || '';
            try {
                await chrome.storage.local.set({
                    fafoCustomThemes: customThemes,
                    fafoActiveCustomThemeId: selectedCustomThemeId || '',
                    mediaConfig: currentConfig,
                });
            } catch (_) {}
            renderCustomThemeCards();
        }

        function snapshotCurrentAsTheme(name) {
            const baseId = $('uiThemePreset')?.value || currentConfig.uiThemePreset || 'cyan';
            const pack = THEME_PACKS.find((p) => p.id === baseId) || THEME_PACKS[0];
            const visual = window.FAFOVisual
                ? FAFOVisual.normalize(typeof readVisualForm === 'function' ? readVisualForm() : (currentConfig.visual || {}))
                : (currentConfig.visual || null);
            return {
                id: 'ct_' + Date.now().toString(36),
                name: (name || '').trim() || `Custom ${customThemes.length + 1}`,
                basePack: pack.id,
                savedAt: Date.now(),
                accentColor: $('accent-color')?.value || currentConfig.accentColor || pack.accent,
                uiPanelBorderColor: $('uiPanelBorderColor')?.value || pack.border,
                uiPanelOpacity: parseFloat($('uiPanelOpacity')?.value ?? currentConfig.uiPanelOpacity ?? 0.92),
                uiHudOpacity: parseFloat($('uiHudOpacity')?.value ?? currentConfig.uiHudOpacity ?? 0.82),
                uiPanelBorderOpacity: parseFloat($('uiPanelBorderOpacity')?.value ?? currentConfig.uiPanelBorderOpacity ?? 0.14),
                uiRadius: parseInt($('uiRadius')?.value ?? currentConfig.uiRadius ?? 14, 10),
                visual,
                // pack swatch colors for card preview
                bg1: pack.bg1,
                bg2: pack.bg2,
                glow: pack.glow,
            };
        }

        function selectThemePack(id, opts = {}) {
            // Built-in pack only (custom themes use selectCustomTheme)
            const pack = THEME_PACKS.find((p) => p.id === id) || THEME_PACKS[0];
            if ($('uiThemePreset')) $('uiThemePreset').value = pack.id;
            if ($('accent-color') && !opts.keepAccent) $('accent-color').value = pack.accent;
            if ($('uiPanelBorderColor') && !opts.keepAccent) $('uiPanelBorderColor').value = pack.border;
            applyTheme(opts.keepAccent && $('accent-color') ? $('accent-color').value : pack.accent);
            document.querySelectorAll('#theme-card-grid .theme-card').forEach((c) => {
                c.classList.toggle('active', c.dataset.theme === pack.id);
            });
            if (!opts.keepCustom) {
                selectedCustomThemeId = '';
                document.querySelectorAll('#custom-theme-grid .theme-card').forEach((c) => c.classList.remove('active'));
            }
            // Apply unique cursor signature for this pack (independently overridable in custom themes)
            if (!opts.skipCursor && window.FAFOVisual) {
                if ($('vis-cursor-theme')) $('vis-cursor-theme').value = pack.id;
                if ($('vis-cursor-profile')) $('vis-cursor-profile').value = 'theme';
                if ($('vis-cursor-hover')) $('vis-cursor-hover').value = 'theme';
                if ($('vis-cursor-left')) $('vis-cursor-left').value = 'theme';
                if ($('vis-cursor-right')) $('vis-cursor-right').value = 'theme';
                try {
                    const cur = typeof readVisualForm === 'function' ? readVisualForm() : {};
                    const withCursor = FAFOVisual.applyThemeCursor(cur, pack.id);
                    fillVisualForm(withCursor);
                    FAFOVisual.apply(withCursor);
                } catch (_) {}
            }
            if ($('theme-active-label')) {
                const sig = window.FAFOVisual?.THEME_CURSOR?.[pack.id];
                const hint = sig
                    ? ` · cursor: ${sig.hover} / L:${sig.leftClick} / R:${sig.rightClick}`
                    : '';
                $('theme-active-label').textContent = `Active: ${pack.name}${hint}`;
            }
        }

        async function selectCustomTheme(id) {
            const th = customThemes.find((t) => t.id === id);
            if (!th) return;
            selectedCustomThemeId = id;
            // Start from base pack chrome, then overlay custom
            if (th.basePack) selectThemePack(th.basePack, { keepAccent: true, keepCustom: true });
            if ($('accent-color') && th.accentColor) $('accent-color').value = th.accentColor;
            if ($('uiPanelBorderColor') && th.uiPanelBorderColor) $('uiPanelBorderColor').value = th.uiPanelBorderColor;
            if ($('uiPanelOpacity') && th.uiPanelOpacity != null) {
                $('uiPanelOpacity').value = th.uiPanelOpacity;
                if ($('uiPanelOpacity-val')) $('uiPanelOpacity-val').textContent = th.uiPanelOpacity;
            }
            if ($('uiHudOpacity') && th.uiHudOpacity != null) {
                $('uiHudOpacity').value = th.uiHudOpacity;
                if ($('uiHudOpacity-val')) $('uiHudOpacity-val').textContent = th.uiHudOpacity;
            }
            if ($('uiPanelBorderOpacity') && th.uiPanelBorderOpacity != null) {
                $('uiPanelBorderOpacity').value = th.uiPanelBorderOpacity;
                if ($('uiPanelBorderOpacity-val')) $('uiPanelBorderOpacity-val').textContent = th.uiPanelBorderOpacity;
            }
            if ($('uiRadius') && th.uiRadius != null) {
                $('uiRadius').value = th.uiRadius;
                if ($('uiRadius-val')) $('uiRadius-val').textContent = th.uiRadius;
            }
            applyTheme(th.accentColor || $('accent-color')?.value || '#00e5ff');
            if (th.visual && window.FAFOVisual) {
                try {
                    fillVisualForm(th.visual);
                    await FAFOVisual.saveToStorage(th.visual);
                    FAFOVisual.apply(th.visual);
                } catch (_) {}
            }
            document.querySelectorAll('#custom-theme-grid .theme-card').forEach((c) => {
                c.classList.toggle('active', c.dataset.theme === id);
            });
            if ($('theme-active-label')) $('theme-active-label').textContent = `Active: ${th.name} (custom)`;
            if ($('custom-theme-status')) $('custom-theme-status').textContent = `Applied custom theme “${th.name}”`;
            await persistCustomThemes();
        }

        function renderThemeCards() {
            const grid = $('theme-card-grid');
            if (!grid) return;
            const active = $('uiThemePreset')?.value || currentConfig.uiThemePreset || 'cyan';
            grid.innerHTML = THEME_PACKS.map((p) => `
                <button type="button" class="theme-card ${p.id === active && !selectedCustomThemeId ? 'active' : ''}" data-theme="${p.id}" role="option" aria-selected="${p.id === active}">
                    <div class="theme-card-swatch" style="--swatch-accent:${p.accent};--swatch-bg1:${p.bg1};--swatch-bg2:${p.bg2};--swatch-glow:${p.glow}"></div>
                    <div class="theme-card-body">
                        <strong>${p.name}</strong>
                        <span>${p.blurb}</span>
                        <span class="theme-card-chip" style="--swatch-accent:${p.accent}">${p.tag}</span>
                    </div>
                </button>
            `).join('');
            grid.querySelectorAll('.theme-card').forEach((card) => {
                card.addEventListener('click', () => {
                    selectedCustomThemeId = '';
                    selectThemePack(card.dataset.theme);
                    persistCustomThemes();
                });
            });
            if (!selectedCustomThemeId) {
                selectThemePack(active, { keepAccent: !!currentConfig.accentColor && currentConfig.uiThemePreset === active });
            }
            renderCustomThemeCards();
        }

        function renderCustomThemeCards() {
            const grid = $('custom-theme-grid');
            if (!grid) return;
            if (!customThemes.length) {
                grid.innerHTML = '<span style="color:#666;font-size:0.85rem;padding:8px 0;">No custom themes yet — tweak colors/animations below, then Save current as custom theme.</span>';
                return;
            }
            grid.innerHTML = customThemes.map((t) => {
                const acc = t.accentColor || t.visual?.colors?.accent || '#00e5ff';
                const bg1 = t.bg1 || t.visual?.colors?.bg || '#0c0c12';
                const bg2 = t.bg2 || t.visual?.colors?.bg2 || '#050508';
                const glow = t.glow || `color-mix(in srgb, ${acc} 40%, transparent)`;
                return `
                <button type="button" class="theme-card ${t.id === selectedCustomThemeId ? 'active' : ''}" data-theme="${t.id}" role="option">
                    <div class="theme-card-swatch" style="--swatch-accent:${acc};--swatch-bg1:${bg1};--swatch-bg2:${bg2};--swatch-glow:${glow}"></div>
                    <div class="theme-card-body">
                        <strong>${escapeHtmlTheme(t.name)}</strong>
                        <span>Based on ${escapeHtmlTheme(t.basePack || 'custom')} · colors + anims</span>
                        <span class="theme-card-chip" style="--swatch-accent:${acc}">Custom</span>
                    </div>
                </button>`;
            }).join('');
            grid.querySelectorAll('.theme-card').forEach((card) => {
                card.addEventListener('click', () => selectCustomTheme(card.dataset.theme));
            });
        }

        function escapeHtmlTheme(s) {
            return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        $('custom-theme-save')?.addEventListener('click', async () => {
            const name = $('custom-theme-name')?.value?.trim() || '';
            const th = snapshotCurrentAsTheme(name);
            customThemes = [th, ...customThemes.filter((t) => t.name !== th.name)].slice(0, 20);
            selectedCustomThemeId = th.id;
            if ($('custom-theme-name')) $('custom-theme-name').value = '';
            await persistCustomThemes();
            if (window.FAFOBackup?.saveThemeToDisk) {
                FAFOBackup.saveThemeToDisk(th).catch(() => {});
            }
            if ($('custom-theme-status')) {
                $('custom-theme-status').textContent = `Saved custom theme “${th.name}” (also written to FAFO-Backups/themes when vault is available)`;
            }
            showToast(`Custom theme: ${th.name}`);
            renderCustomThemeCards();
        });
        $('custom-theme-update')?.addEventListener('click', async () => {
            if (!selectedCustomThemeId) {
                showToast('Select a custom theme first', 'error');
                return;
            }
            const prev = customThemes.find((t) => t.id === selectedCustomThemeId);
            if (!prev) return;
            const th = snapshotCurrentAsTheme(prev.name);
            th.id = prev.id;
            customThemes = customThemes.map((t) => (t.id === prev.id ? th : t));
            await persistCustomThemes();
            if (window.FAFOBackup?.saveThemeToDisk) FAFOBackup.saveThemeToDisk(th).catch(() => {});
            showToast(`Updated “${th.name}”`);
            if ($('custom-theme-status')) $('custom-theme-status').textContent = `Updated “${th.name}”`;
        });
        $('custom-theme-delete')?.addEventListener('click', async () => {
            if (!selectedCustomThemeId) {
                showToast('Select a custom theme to delete', 'error');
                return;
            }
            const prev = customThemes.find((t) => t.id === selectedCustomThemeId);
            if (!prev || !confirm(`Delete custom theme “${prev.name}”?`)) return;
            customThemes = customThemes.filter((t) => t.id !== selectedCustomThemeId);
            selectedCustomThemeId = '';
            await persistCustomThemes();
            showToast('Custom theme deleted');
        });

        await loadCustomThemesStore();
        renderThemeCards();
        if (selectedCustomThemeId && customThemes.some((t) => t.id === selectedCustomThemeId)) {
            // Don't re-apply full visual on every options open if keep — just mark active cards
            renderCustomThemeCards();
            const th = customThemes.find((t) => t.id === selectedCustomThemeId);
            if (th && $('theme-active-label')) $('theme-active-label').textContent = `Active: ${th.name} (custom)`;
        }

        set('neon-border', currentConfig.neonBorder, 'check');
        set('neon-pattern', currentConfig.neonPattern);
        set('neon-segments', currentConfig.neonSegments);
        set('neon-speed', currentConfig.neonSpeed);
        set('neon-audio', currentConfig.neonAudio, 'check');
        set('neon-strobe', currentConfig.neonStrobe);
        set('neon-sensitivity', currentConfig.neonSensitivity);
        set('neon-width', currentConfig.neonWidth);
        set('neon-use-accent', currentConfig.neonUseAccent, 'check');
        set('neon-color', currentConfig.neonColor);
        set('border-size', currentConfig.borderSize);
        set('playback-speed', currentConfig.playbackSpeed ?? 1);
        set('loops', currentConfig.loops ?? 1);
        set('kenburns', !!currentConfig.kenburns, 'check');
        set('shuffle', !!currentConfig.shuffle, 'check');
        set('volume', currentConfig.volume ?? 0.7);

        // Tagging defaults (separate storage keys + mediaConfig)
        try {
            const tagPrefs = await chrome.storage.local.get([
                'fafoSkipTaggedMode', 'fafoApplyAndNext', 'fafoTagCountMode',
            ]);
            set('opt-skip-tagged', !!tagPrefs.fafoSkipTaggedMode, 'check');
            set('opt-apply-next', !!tagPrefs.fafoApplyAndNext, 'check');
            set('opt-tag-count-mode', tagPrefs.fafoTagCountMode === 'total' ? 'total' : 'session');
        } catch (_) {}
        
        if (db && !privateOptionsMode) await loadPlaylistsUI();
        
        if($('active-playlist-selector') && !privateOptionsMode) {
             $('active-playlist-selector').value = currentConfig.activePlaylistId || 'all';
             activePlaylistView = currentConfig.activePlaylistId || 'all';
        }

        if (db) loadLibraryGrid();
        initSliders();
        await initIndependentScaleControls();
        try { initWallConfigOptions(); } catch (e) { console.warn('wall config options', e); }
    }

    function spaceMetaKeys() {
        if (!privateOptionsMode) {
            return { meta: 'fafoMediaMeta', tags: 'fafoTagLibrary', counts: 'fafoTagApplyCounts' };
        }
        const sk = window.FAFOPrivateVaults?.privateStorageKeys?.(privateOptionsVaultId || 'default');
        if (sk) {
            return { meta: sk.mediaMeta, tags: sk.tagLibrary, counts: sk.applyCounts };
        }
        return { meta: 'fafoMediaMetaPrivate', tags: 'fafoTagLibraryPrivate', counts: 'fafoTagApplyCountsPrivate' };
    }

    // --- The Wall configuration & scalability (Layout tab + player HUD) ---
    const WALL_COUNTS = [2, 6, 8];
    const DEFAULT_WALL_PREFS = {
        count: 8,
        gapScale: 1,
        fullFrame: true,
        liveReflow: true,
        stayOnScreen: true,
        muteHoverScale: true,
    };
    let wallPrefsSaveTimer = null;

    function normalizeWallPrefs(raw) {
        const src = raw && typeof raw === 'object' ? raw : {};
        const count = WALL_COUNTS.includes(parseInt(src.count, 10))
            ? parseInt(src.count, 10)
            : DEFAULT_WALL_PREFS.count;
        const gapScale = Math.max(0.4, Math.min(1.8, Number(src.gapScale) || DEFAULT_WALL_PREFS.gapScale));
        return {
            count,
            gapScale: Math.round(gapScale * 100) / 100,
            fullFrame: src.fullFrame !== false,
            liveReflow: src.liveReflow !== false,
            stayOnScreen: src.stayOnScreen !== false,
            muteHoverScale: src.muteHoverScale !== false,
        };
    }

    function wallMatrixForCount(count) {
        // Landscape default (player flips on portrait)
        const map = { 2: [2, 1], 6: [3, 2], 8: [4, 2] };
        return map[count] || [4, 2];
    }

    function paintWallCountPicker(count) {
        const n = WALL_COUNTS.includes(count) ? count : 8;
        const hidden = $('opt-wall-count');
        if (hidden) hidden.value = String(n);
        document.querySelectorAll('#opt-wall-count-picker [data-wall-count]').forEach((btn) => {
            const c = parseInt(btn.getAttribute('data-wall-count'), 10);
            btn.classList.toggle('active', c === n);
        });
    }

    function readWallPrefsFromUi() {
        const count = parseInt($('opt-wall-count')?.value, 10);
        const gapPct = parseInt($('opt-wall-gap')?.value, 10);
        return normalizeWallPrefs({
            count: WALL_COUNTS.includes(count) ? count : 8,
            gapScale: (Number.isFinite(gapPct) ? gapPct : 100) / 100,
            fullFrame: !!$('opt-wall-full-frame')?.checked,
            liveReflow: !!$('opt-wall-live-reflow')?.checked,
            stayOnScreen: !!$('opt-wall-stay-on-screen')?.checked,
            muteHoverScale: !!$('opt-wall-mute-hover-scale')?.checked,
        });
    }

    function applyWallPrefsToUi(prefs) {
        const p = normalizeWallPrefs(prefs);
        paintWallCountPicker(p.count);
        const gapEl = $('opt-wall-gap');
        const gapVal = $('opt-wall-gap-val');
        if (gapEl) gapEl.value = String(Math.round(p.gapScale * 100));
        if (gapVal) gapVal.textContent = Math.round(p.gapScale * 100) + '%';
        if ($('opt-wall-full-frame')) $('opt-wall-full-frame').checked = p.fullFrame;
        if ($('opt-wall-live-reflow')) $('opt-wall-live-reflow').checked = p.liveReflow;
        if ($('opt-wall-stay-on-screen')) $('opt-wall-stay-on-screen').checked = p.stayOnScreen;
        if ($('opt-wall-mute-hover-scale')) $('opt-wall-mute-hover-scale').checked = p.muteHoverScale;
        const [cols, rows] = wallMatrixForCount(p.count);
        const st = $('opt-wall-status');
        if (st) {
            st.textContent =
                `Ready · ${p.count} tiles (${cols}×${rows} landscape) · gap ${Math.round(p.gapScale * 100)}% · ` +
                `${p.fullFrame ? 'full frames' : 'may crop'} · ` +
                `${p.liveReflow ? 'live reflow' : 'static'} · ` +
                `${p.stayOnScreen ? 'viewport pin' : 'free layout'}`;
        }
        return p;
    }

    async function loadWallPrefsOptions() {
        try {
            const data = await chrome.storage.local.get(['fafoWallPrefs', 'fafoWallCount']);
            let prefs = data.fafoWallPrefs;
            if (!prefs || typeof prefs !== 'object') {
                const n = parseInt(data.fafoWallCount, 10);
                prefs = { ...DEFAULT_WALL_PREFS, count: WALL_COUNTS.includes(n) ? n : 8 };
            }
            applyWallPrefsToUi(prefs);
        } catch (e) {
            console.warn('wall prefs load', e);
            applyWallPrefsToUi(DEFAULT_WALL_PREFS);
        }
    }

    async function persistWallPrefs(opts = {}) {
        const p = applyWallPrefsToUi(readWallPrefsFromUi());
        try {
            await chrome.storage.local.set({
                fafoWallPrefs: p,
                fafoWallCount: p.count, // legacy key for older player builds
            });
            // When Options layout is The Wall, keep grid geometry aligned with count
            if (opts.syncGrid !== false && currentConfig?.layout === 'grid') {
                const [cols, rows] = wallMatrixForCount(p.count);
                currentConfig.gridCols = cols;
                currentConfig.gridRows = rows;
                if ($('grid-cols')) {
                    $('grid-cols').value = String(cols);
                    const sv = $('grid-cols-val');
                    if (sv) sv.textContent = String(cols);
                }
                if ($('grid-rows')) {
                    $('grid-rows').value = String(rows);
                    const sv = $('grid-rows-val');
                    if (sv) sv.textContent = String(rows);
                }
            }
            if (opts.toast) showToast(`Wall · ${p.count} tiles saved`);
        } catch (e) {
            console.warn('wall prefs save', e);
        }
        return p;
    }

    function scheduleWallPrefsSave() {
        clearTimeout(wallPrefsSaveTimer);
        wallPrefsSaveTimer = setTimeout(() => {
            persistWallPrefs({ toast: false }).catch(() => {});
        }, 200);
    }

    function initWallConfigOptions() {
        loadWallPrefsOptions().catch(() => {});
        document.querySelectorAll('#opt-wall-count-picker [data-wall-count]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const n = parseInt(btn.getAttribute('data-wall-count'), 10);
                if (!WALL_COUNTS.includes(n)) return;
                paintWallCountPicker(n);
                applyWallPrefsToUi(readWallPrefsFromUi());
                scheduleWallPrefsSave();
            });
        });
        $('opt-wall-gap')?.addEventListener('input', () => {
            applyWallPrefsToUi(readWallPrefsFromUi());
            scheduleWallPrefsSave();
        });
        $('opt-wall-gap-reset')?.addEventListener('click', () => {
            if ($('opt-wall-gap')) $('opt-wall-gap').value = '100';
            applyWallPrefsToUi(readWallPrefsFromUi());
            scheduleWallPrefsSave();
        });
        ['opt-wall-full-frame', 'opt-wall-live-reflow', 'opt-wall-stay-on-screen', 'opt-wall-mute-hover-scale']
            .forEach((id) => {
                $(id)?.addEventListener('change', () => {
                    applyWallPrefsToUi(readWallPrefsFromUi());
                    scheduleWallPrefsSave();
                });
            });
        // Live when player changes wall count
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== 'local') return;
            if (changes.fafoWallPrefs) {
                applyWallPrefsToUi(changes.fafoWallPrefs.newValue);
            } else if (changes.fafoWallCount) {
                const n = parseInt(changes.fafoWallCount.newValue, 10);
                if (WALL_COUNTS.includes(n)) {
                    paintWallCountPicker(n);
                    applyWallPrefsToUi(readWallPrefsFromUi());
                }
            }
        });
    }

    // --- Independent GUI / Video scale (live + preview) ---
    // 100% defaults — browser page zoom (TV 50–80%) already scales the page
    const DEFAULT_GUI_SCALE = 1;
    const DEFAULT_VIDEO_SCALE = 1;
    let scaleSaveTimer = null;

    function pctToScale(pct) {
        const n = parseInt(pct, 10);
        if (!Number.isFinite(n)) return DEFAULT_GUI_SCALE;
        return Math.round(n) / 100;
    }
    function scaleToPct(s) {
        const n = Number(s);
        if (!Number.isFinite(n) || n <= 0) return Math.round(DEFAULT_GUI_SCALE * 100);
        return Math.round(n * 100);
    }

    function updateScalePreview() {
        const guiPct = parseInt($('optGuiScale')?.value ?? 100, 10) || 100;
        const vidPct = parseInt($('optVideoScale')?.value ?? 100, 10) || 100;
        const gui = guiPct / 100;
        const vid = vidPct / 100;

        const stage = $('scale-preview-stage');
        if (stage) {
            stage.style.setProperty('--pv-gui', String(gui));
            stage.style.setProperty('--pv-video', String(vid));
        }
        const vPctEl = $('scale-preview-video-pct');
        if (vPctEl) vPctEl.textContent = vidPct + '%';
        const vBox = $('scale-preview-video');
        if (vBox) {
            // Extra emphasis when not 100% so the live change is obvious
            vBox.style.outline = Math.abs(vidPct - 100) > 1
                ? '2px solid rgba(0,255,168,0.55)'
                : 'none';
        }

        const guiVal = $('optGuiScale-val');
        const vidVal = $('optVideoScale-val');
        if (guiVal) guiVal.textContent = guiPct + '%';
        if (vidVal) vidVal.textContent = vidPct + '%';

        // Reference: user screen when available, else 1920×1080
        const sw = window.screen?.width || 1920;
        const sh = window.screen?.height || 1080;
        // Docked video fills viewport then content scales — estimate content box
        const videoW = Math.round(sw * vid);
        const videoH = Math.round(sh * vid);
        // Typical HUD / tags footprints at 100% (approx)
        const hudBaseW = 360;
        const hudBaseH = 150;
        const tagsBaseW = 320;
        const tagsBaseH = 420;
        const hudW = Math.round(hudBaseW * gui);
        const hudH = Math.round(hudBaseH * gui);
        const tagsW = Math.round(tagsBaseW * gui);
        const tagsH = Math.round(tagsBaseH * gui);

        const letterboxH = Math.max(0, Math.round((sh - videoH) / 2));
        const letterboxW = Math.max(0, Math.round((sw - videoW) / 2));
        let letterNote;
        if (vid < 0.99) {
            letterNote = `~${letterboxW}px sides · ~${letterboxH}px top/bottom (centered)`;
        } else if (vid > 1.01) {
            letterNote = `Zoomed in — edges crop ~${Math.round((vid - 1) * 50)}% per side`;
        } else {
            letterNote = 'Full stage (no letterbox from scale)';
        }

        const setTxt = (id, t) => { const el = $(id); if (el) el.textContent = t; };
        setTxt('stat-gui-pct', guiPct + '%');
        setTxt('stat-video-pct', vidPct + '%');
        setTxt('stat-screen', `${sw}×${sh}`);
        setTxt('stat-video-box', `${videoW}×${videoH}px`);
        setTxt('stat-hud-box', `~${hudW}×${hudH}px`);
        setTxt('stat-tags-box', `~${tagsW}×${tagsH}px`);
        setTxt('stat-letterbox', letterNote);

        const note = $('stat-scale-note');
        if (note) {
            note.textContent =
                `At ${vidPct}% video on ${sh}p, content is ~${videoH}px tall (centered). ` +
                `GUI at ${guiPct}% keeps docks smaller and on-screen. ` +
                `Wheel on new-tab video adjusts video only; Ctrl+wheel off video adjusts GUI.`;
        }
    }

    async function persistIndependentScales(opts = {}) {
        const gui = pctToScale($('optGuiScale')?.value ?? 80);
        const vid = pctToScale($('optVideoScale')?.value ?? 80);
        const clampedGui = Math.max(0.65, Math.min(1.6, gui));
        const clampedVid = Math.max(0.25, Math.min(4, vid));

        let stage = {};
        try {
            const res = await chrome.storage.local.get('fafoVideoStage');
            if (res.fafoVideoStage && typeof res.fafoVideoStage === 'object') {
                stage = { ...res.fafoVideoStage };
            }
        } catch (_) {}

        stage.zoom = clampedVid;
        if (stage.locked === undefined) stage.locked = true;

        await chrome.storage.local.set({
            fafoChromeScale: clampedGui,
            fafoMetaUiScale: clampedGui,
            fafoVideoStage: stage,
            fafoScaleDefaultsV2: true,
        });

        if (opts.toast) showToast(`Scales · GUI ${Math.round(clampedGui * 100)}% · Video ${Math.round(clampedVid * 100)}%`);
    }

    function scheduleScalePersist() {
        clearTimeout(scaleSaveTimer);
        scaleSaveTimer = setTimeout(() => {
            persistIndependentScales({ toast: false }).catch(() => {});
        }, 180);
    }

    async function initIndependentScaleControls() {
        const guiEl = $('optGuiScale');
        const vidEl = $('optVideoScale');
        if (!guiEl || !vidEl) return;

        try {
            const res = await chrome.storage.local.get([
                'fafoChromeScale', 'fafoMetaUiScale', 'fafoVideoStage',
            ]);
            let gui = DEFAULT_GUI_SCALE;
            let vid = DEFAULT_VIDEO_SCALE;
            if (typeof res.fafoChromeScale === 'number' && res.fafoChromeScale > 0) {
                gui = res.fafoChromeScale;
            } else if (typeof res.fafoMetaUiScale === 'number' && res.fafoMetaUiScale > 0) {
                gui = res.fafoMetaUiScale;
            }
            if (res.fafoVideoStage && typeof res.fafoVideoStage.zoom === 'number' && res.fafoVideoStage.zoom > 0) {
                vid = res.fafoVideoStage.zoom;
            }
            guiEl.value = String(scaleToPct(gui));
            vidEl.value = String(scaleToPct(vid));
        } catch (_) {
            guiEl.value = '80';
            vidEl.value = '80';
        }

        const onInput = () => {
            updateScalePreview();
            scheduleScalePersist();
        };
        guiEl.addEventListener('input', onInput);
        vidEl.addEventListener('input', onInput);

        $('optGuiScale-reset')?.addEventListener('click', () => {
            guiEl.value = '100';
            onInput();
            persistIndependentScales({ toast: true });
        });
        $('optGuiScale-80')?.addEventListener('click', () => {
            guiEl.value = '80';
            onInput();
            persistIndependentScales({ toast: true });
        });
        $('optVideoScale-reset')?.addEventListener('click', () => {
            vidEl.value = '100';
            onInput();
            persistIndependentScales({ toast: true });
        });
        $('optVideoScale-80')?.addEventListener('click', () => {
            vidEl.value = '80';
            onInput();
            persistIndependentScales({ toast: true });
        });

        // Live when another tab (new-tab) changes scales
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== 'local') return;
            if (changes.fafoChromeScale || changes.fafoMetaUiScale || changes.fafoVideoStage) {
                const g = changes.fafoChromeScale?.newValue ?? changes.fafoMetaUiScale?.newValue;
                const st = changes.fafoVideoStage?.newValue;
                if (typeof g === 'number' && g > 0 && document.activeElement !== guiEl) {
                    guiEl.value = String(scaleToPct(g));
                }
                if (st && typeof st.zoom === 'number' && st.zoom > 0 && document.activeElement !== vidEl) {
                    vidEl.value = String(scaleToPct(st.zoom));
                }
                updateScalePreview();
            }
        });

        updateScalePreview();
        window.addEventListener('resize', () => updateScalePreview(), { passive: true });
        initNextUpOptionsControls().catch(() => {});
    }

    /** Up next strip prefs (count / scale / position / show-hide) → fafoNextUp */
    async function initNextUpOptionsControls() {
        const countEl = $('opt-nextup-count');
        const scaleEl = $('opt-nextup-scale');
        const posEl = $('opt-nextup-pos');
        const status = $('opt-nextup-status');
        if (!countEl || !scaleEl || !posEl) return;

        const applyVals = (L) => {
            const count = Math.max(3, Math.min(16, Math.round(Number(L.count) || 8)));
            const scale = Math.max(0.6, Math.min(1.8, Number(L.scale) || 1));
            const pos = ['bottom', 'top', 'left', 'right', 'free'].includes(L.pos) ? L.pos : 'bottom';
            if (document.activeElement !== countEl) countEl.value = String(count);
            if (document.activeElement !== scaleEl) scaleEl.value = String(Math.round(scale * 100));
            if (document.activeElement !== posEl) posEl.value = pos;
            const cv = $('opt-nextup-count-val');
            const sv = $('opt-nextup-scale-val');
            if (cv) cv.textContent = String(count);
            if (sv) sv.textContent = Math.round(scale * 100) + '%';
            if (status) {
                status.textContent = L.hidden
                    ? 'Hidden on new-tab · use Show strip or Ctrl+K'
                    : `Live · ${count} cards · ${pos} · ${Math.round(scale * 100)}%`;
            }
        };

        let cur = { pos: 'bottom', x: 24, y: 24, scale: 1, count: 8, hidden: false };
        try {
            const res = await chrome.storage.local.get(['fafoNextUp']);
            if (res.fafoNextUp && typeof res.fafoNextUp === 'object') {
                cur = { ...cur, ...res.fafoNextUp };
            }
        } catch (_) {}
        applyVals(cur);

        let saveTimer = null;
        const persist = (patch, toast) => {
            cur = { ...cur, ...patch };
            applyVals(cur);
            clearTimeout(saveTimer);
            saveTimer = setTimeout(async () => {
                try {
                    await chrome.storage.local.set({
                        fafoNextUp: {
                            pos: cur.pos,
                            x: cur.x,
                            y: cur.y,
                            scale: cur.scale,
                            count: cur.count,
                            hidden: !!cur.hidden,
                        },
                    });
                    if (toast) showToast(toast);
                    if (status && !toast) {
                        status.textContent = cur.hidden
                            ? 'Saved · hidden on new-tab'
                            : `Saved · ${cur.count} cards · ${cur.pos}`;
                    }
                } catch (e) {
                    if (status) status.textContent = 'Save failed';
                }
            }, 160);
        };

        countEl.addEventListener('input', () => {
            const n = Math.max(3, Math.min(16, parseInt(countEl.value, 10) || 8));
            const cv = $('opt-nextup-count-val');
            if (cv) cv.textContent = String(n);
            persist({ count: n });
        });
        scaleEl.addEventListener('input', () => {
            const pct = Math.max(60, Math.min(180, parseInt(scaleEl.value, 10) || 100));
            const sv = $('opt-nextup-scale-val');
            if (sv) sv.textContent = pct + '%';
            persist({ scale: pct / 100 });
        });
        posEl.addEventListener('change', () => {
            persist({ pos: posEl.value || 'bottom' });
        });
        $('opt-nextup-show')?.addEventListener('click', () => {
            persist({ hidden: false }, 'Up next · shown');
        });
        $('opt-nextup-hide')?.addEventListener('click', () => {
            persist({ hidden: true }, 'Up next · hidden');
        });

        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== 'local' || !changes.fafoNextUp?.newValue) return;
            const L = changes.fafoNextUp.newValue;
            if (L && typeof L === 'object') {
                cur = { ...cur, ...L };
                applyVals(cur);
            }
        });
    }

    function camelCase(str) { return str.replace(/-([a-z])/g, (g) => g[1].toUpperCase()); }

    function getThumbSeekSec() {
        if (window.FAFOPairs?.getThumbSeekSec) return FAFOPairs.getThumbSeekSec();
        const v = Number(currentConfig?.thumbSeekSec);
        return Number.isFinite(v) && v >= 0 ? v : 1;
    }

    /**
     * Capture a JPEG data-URL thumb. Always resolves (never hangs).
     * Images → object URL. Videos → seek frame with timeout fallback.
     */
    async function generateThumbnail(file, seekSec) {
        if (!file) return null;
        const name = file.name || '';
        if (String(file.type || '').startsWith('image') || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(name)) {
            try { return URL.createObjectURL(file); } catch { return null; }
        }
        const isVideo =
            String(file.type || '').startsWith('video') ||
            /\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(name);
        if (!isVideo) return null;

        const seek = seekSec != null ? Number(seekSec) : getThumbSeekSec();
        return new Promise((resolve) => {
            let settled = false;
            const video = document.createElement('video');
            video.preload = 'auto';
            video.muted = true;
            video.playsInline = true;
            video.crossOrigin = 'anonymous';
            let url;
            try { url = URL.createObjectURL(file); }
            catch { resolve(null); return; }
            video.src = url;

            const finish = (dataUrl) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                try { URL.revokeObjectURL(url); } catch (_) {}
                try { video.removeAttribute('src'); video.load(); video.remove(); } catch (_) {}
                resolve(dataUrl || null);
            };

            const capture = () => {
                try {
                    const w = video.videoWidth || 0;
                    const h = video.videoHeight || 0;
                    if (w < 2 || h < 2) {
                        finish(null);
                        return;
                    }
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1, Math.floor(w / 4));
                    canvas.height = Math.max(1, Math.floor(h / 4));
                    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                    finish(canvas.toDataURL('image/jpeg', 0.72));
                } catch {
                    finish(null);
                }
            };

            const timer = setTimeout(() => {
                // Last resort: grab whatever frame is loaded
                if (video.readyState >= 2) capture();
                else finish(null);
            }, 4500);

            video.addEventListener('seeked', () => capture(), { once: true });
            video.addEventListener('error', () => finish(null), { once: true });

            const doSeek = () => {
                try {
                    const dur = Number(video.duration);
                    const cap = Number.isFinite(dur) && dur > 0 ? Math.max(0, dur - 0.08) : 0;
                    const t = Math.min(Math.max(0, seek || 0), cap || 0);
                    // Setting currentTime to the same value may not fire seeked — force micro-nudge
                    if (Math.abs((video.currentTime || 0) - t) < 0.001) {
                        if (t <= 0.05) {
                            // Already at start with a frame
                            if (video.readyState >= 2) capture();
                            else video.currentTime = Math.min(0.1, cap || 0.1);
                        } else {
                            video.currentTime = Math.max(0, t - 0.05);
                        }
                    } else {
                        video.currentTime = t;
                    }
                } catch {
                    if (video.readyState >= 2) capture();
                    else finish(null);
                }
            };

            video.addEventListener('loadeddata', doSeek, { once: true });
            video.addEventListener('loadedmetadata', () => {
                if (video.readyState >= 2) doSeek();
            }, { once: true });
        });
    }

    async function getPlaylists() {
        if (!db) return [];
        return new Promise(res => {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            const req = store.getAll();
            req.onsuccess = () => res(req.result || []);
            req.onerror = () => res([]);
        });
    }

    async function smartPlaylistCount(p) {
        if (!db || p.type !== 'smart' || !window.FAFOLibrary) return null;
        try {
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            const items = await FAFOLibrary.resolveSmartPlaylist(db, p, fafoMediaMeta);
            return items.length;
        } catch {
            return null;
        }
    }

    /** Playlist currently being edited (id) — null when creating new */
    let editingPlaylistId = null;

    function setPlaylistEditMode(p) {
        editingPlaylistId = p?.id || null;
        const hint = $('playlist-edit-hint');
        const updateBtn = $('update-smart-pl-btn');
        const cancelBtn = $('cancel-pl-edit-btn');
        const createSmart = $('create-smart-pl-btn');
        if (!p) {
            if (hint) { hint.style.display = 'none'; hint.textContent = ''; }
            if (updateBtn) updateBtn.style.display = 'none';
            if (cancelBtn) cancelBtn.style.display = 'none';
            if (createSmart) createSmart.style.display = '';
            return;
        }
        if (hint) {
            hint.style.display = 'block';
            hint.textContent = p.type === 'smart'
                ? `Editing smart playlist “${p.name}” — change rules below, then Save smart edits (or rename only).`
                : `Editing manual playlist “${p.name}” — rename below, then Save. Items still added from Visual Library.`;
        }
        if (cancelBtn) cancelBtn.style.display = '';
        if (p.type === 'smart') {
            if ($('smart-pl-name')) $('smart-pl-name').value = p.name || '';
            if ($('smart-pl-min-rating')) $('smart-pl-min-rating').value = String(p.rules?.minRating || 0);
            if ($('smart-pl-media')) $('smart-pl-media').value = p.rules?.media || 'video';
            if ($('smart-pl-tags')) $('smart-pl-tags').value = (p.rules?.tags || []).join(', ');
            if ($('smart-pl-tags-mode')) $('smart-pl-tags-mode').value = p.rules?.tagsMode || 'any';
            if ($('smart-pl-untagged')) $('smart-pl-untagged').checked = !!p.rules?.untaggedOnly;
            if (updateBtn) {
                updateBtn.style.display = '';
                updateBtn.textContent = 'Save smart edits';
            }
            if (createSmart) createSmart.style.display = 'none';
            if ($('new-playlist-name')) $('new-playlist-name').value = '';
        } else {
            if ($('new-playlist-name')) $('new-playlist-name').value = p.name || '';
            if (updateBtn) {
                updateBtn.style.display = '';
                updateBtn.textContent = 'Save rename';
            }
            if (createSmart) createSmart.style.display = '';
        }
    }

    async function putPlaylist(pl) {
        if (!db || !pl?.id) return;
        return new Promise((resolve, reject) => {
            const tx = db.transaction('playlists', 'readwrite');
            tx.objectStore('playlists').put(pl);
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    }

    async function loadPlaylistsUI() {
        const playlists = await getPlaylists();
        const container = $('playlist-list');
        const select = $('active-playlist-selector');
        const modalSelect = $('modal-playlist-select');
        
        if(container) container.innerHTML = '';
        
        if(select) {
            const currentSelectVal = select.value || 'all';
            select.innerHTML = '<option value="all">📚 All Library</option>';
            for (const p of playlists) {
                const opt = document.createElement('option');
                opt.value = p.id;
                const n = p.type === 'smart' ? await smartPlaylistCount(p) : (p.items || []).length;
                const icon = p.type === 'smart' ? '✨' : '🎼';
                opt.textContent = `${icon} ${p.name} (${n != null ? n : '…'})`;
                select.appendChild(opt);
            }
            select.value = currentSelectVal;
        }

        if(modalSelect) {
            modalSelect.innerHTML = '<option value="">Select Playlist...</option>';
            playlists.filter(p => p.type !== 'smart').forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = p.name;
                modalSelect.appendChild(opt);
            });
        }

        if(container) {
            if(playlists.length === 0) container.innerHTML = '<span style="color:#666">No collections created yet.</span>';
            for (const p of playlists) {
                const chip = document.createElement('div');
                chip.className = 'playlist-chip';
                if (editingPlaylistId === p.id) chip.classList.add('editing');
                const n = p.type === 'smart' ? await smartPlaylistCount(p) : (p.items || []).length;
                const badge = p.type === 'smart' ? '✨ smart' : 'manual';
                let rulesHint = '';
                if (p.type === 'smart' && p.rules) {
                    const bits = [];
                    if (p.rules.minRating) bits.push('★' + p.rules.minRating + '+');
                    if (p.rules.untaggedOnly) bits.push('untagged');
                    if (p.rules.tags?.length) bits.push(p.rules.tags.join(','));
                    rulesHint = bits.length ? ` · ${bits.join(' · ')}` : '';
                }
                const label = document.createElement('span');
                label.innerHTML = `<span>${escapeHtmlPl(p.name)}</span> <span style="color:#666">(${n != null ? n : '…'}) ${badge}${escapeHtmlPl(rulesHint)}</span>`;
                chip.appendChild(label);

                const edit = document.createElement('button');
                edit.type = 'button';
                edit.textContent = '✎';
                edit.title = 'Edit playlist';
                edit.style.color = '#2dd4bf';
                edit.onclick = (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setPlaylistEditMode(p);
                    loadPlaylistsUI();
                    if (p.type === 'smart') {
                        $('smart-pl-name')?.focus();
                    } else {
                        $('new-playlist-name')?.focus();
                    }
                };
                chip.appendChild(edit);

                const del = document.createElement('button');
                del.type = 'button';
                del.textContent = '×';
                del.title = 'Delete playlist';
                del.onclick = async () => {
                    if(confirm(`Delete playlist "${p.name}"?`)) {
                        if (editingPlaylistId === p.id) setPlaylistEditMode(null);
                        const tx = db.transaction('playlists', 'readwrite');
                        tx.objectStore('playlists').delete(p.id);
                        tx.oncomplete = () => {
                            loadPlaylistsUI();
                            scheduleFullBackup('playlist-delete');
                        };
                    }
                };
                chip.appendChild(del);
                container.appendChild(chip);
            }
        }
    }

    function escapeHtmlPl(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    const createBtn = $('create-playlist-btn');
    if (createBtn) {
        createBtn.onclick = async () => {
            if (!db) { showToast("Database Not Ready", "error"); return; }
            const nameInput = $('new-playlist-name');
            const name = nameInput ? nameInput.value.trim() : "";
            if(!name) return;

            // If editing a manual playlist, rename it
            if (editingPlaylistId) {
                const all = await getPlaylists();
                const existing = all.find((x) => x.id === editingPlaylistId);
                if (existing && existing.type !== 'smart') {
                    existing.name = name;
                    existing.updated = Date.now();
                    await putPlaylist(existing);
                    if (nameInput) nameInput.value = '';
                    setPlaylistEditMode(null);
                    showToast(`Renamed playlist: ${name}`);
                    loadPlaylistsUI();
                    scheduleFullBackup('playlist-rename');
                    return;
                }
            }

            const tx = db.transaction('playlists', 'readwrite');
            const id = crypto.randomUUID();
            tx.objectStore('playlists').add({ id, name, type: 'manual', items: [], created: Date.now() });
            tx.oncomplete = () => {
                if(nameInput) nameInput.value = '';
                showToast(`Created playlist: ${name}`);
                loadPlaylistsUI();
                scheduleFullBackup('playlist-create');
            };
        };
    }

    async function createSmartPlaylist(preset) {
        if (!db) { showToast('Database Not Ready', 'error'); return; }
        let name = $('smart-pl-name')?.value?.trim() || '';
        let minRating = parseInt($('smart-pl-min-rating')?.value || '0', 10) || 0;
        let media = $('smart-pl-media')?.value || 'video';
        let tagsMode = $('smart-pl-tags-mode')?.value || 'any';
        let untaggedOnly = !!$('smart-pl-untagged')?.checked;
        let tags = window.FAFOLibrary
            ? FAFOLibrary.normalizeTags($('smart-pl-tags')?.value || '')
            : ($('smart-pl-tags')?.value || '').split(/[,;]+/).map(t => t.trim()).filter(Boolean);

        if (preset === '4star') {
            name = name || '4-star favorites';
            minRating = 4;
            untaggedOnly = false;
        } else if (preset === 'untagged') {
            name = name || 'Untagged';
            minRating = 0;
            tags = [];
            untaggedOnly = true;
        }

        if (!name) {
            showToast('Enter a smart playlist name', 'error');
            return;
        }
        if (!untaggedOnly && minRating <= 0 && !tags.length) {
            showToast('Set min rating, tags, or Untagged only', 'error');
            return;
        }

        const id = 'smart_' + crypto.randomUUID();
        const pl = {
            id,
            name,
            type: 'smart',
            items: [],
            rules: {
                minRating,
                tags,
                tagsMode,
                untaggedOnly,
                media,
            },
            created: Date.now(),
        };
        const tx = db.transaction('playlists', 'readwrite');
        tx.objectStore('playlists').put(pl);
        tx.oncomplete = () => {
            if ($('smart-pl-name')) $('smart-pl-name').value = '';
            showToast(`Smart playlist: ${name}`);
            loadPlaylistsUI();
            scheduleFullBackup('playlist-create');
        };
    }

    async function savePlaylistEdits() {
        if (!db || !editingPlaylistId) {
            showToast('Nothing to save — click ✎ Edit on a playlist first', 'error');
            return;
        }
        const all = await getPlaylists();
        const existing = all.find((x) => x.id === editingPlaylistId);
        if (!existing) {
            showToast('Playlist not found', 'error');
            setPlaylistEditMode(null);
            return;
        }

        if (existing.type === 'smart') {
            const name = $('smart-pl-name')?.value?.trim() || existing.name;
            const minRating = parseInt($('smart-pl-min-rating')?.value || '0', 10) || 0;
            const media = $('smart-pl-media')?.value || 'video';
            const tagsMode = $('smart-pl-tags-mode')?.value || 'any';
            const untaggedOnly = !!$('smart-pl-untagged')?.checked;
            const tags = window.FAFOLibrary
                ? FAFOLibrary.normalizeTags($('smart-pl-tags')?.value || '')
                : ($('smart-pl-tags')?.value || '').split(/[,;]+/).map(t => t.trim()).filter(Boolean);
            if (!name) {
                showToast('Name required', 'error');
                return;
            }
            if (!untaggedOnly && minRating <= 0 && !tags.length) {
                showToast('Set min rating, tags, or Untagged only', 'error');
                return;
            }
            existing.name = name;
            existing.rules = { minRating, tags, tagsMode, untaggedOnly, media };
            existing.updated = Date.now();
            await putPlaylist(existing);
            if ($('smart-pl-name')) $('smart-pl-name').value = '';
            setPlaylistEditMode(null);
            showToast(`Updated smart playlist: ${name}`);
            loadPlaylistsUI();
            scheduleFullBackup('playlist-edit');
            return;
        }

        // Manual rename via Save button
        const name = $('new-playlist-name')?.value?.trim() || existing.name;
        if (!name) {
            showToast('Name required', 'error');
            return;
        }
        existing.name = name;
        existing.updated = Date.now();
        await putPlaylist(existing);
        if ($('new-playlist-name')) $('new-playlist-name').value = '';
        setPlaylistEditMode(null);
        showToast(`Renamed playlist: ${name}`);
        loadPlaylistsUI();
        scheduleFullBackup('playlist-rename');
    }

    $('create-smart-pl-btn')?.addEventListener('click', () => createSmartPlaylist());
    $('update-smart-pl-btn')?.addEventListener('click', () => savePlaylistEdits());
    $('cancel-pl-edit-btn')?.addEventListener('click', () => {
        setPlaylistEditMode(null);
        if ($('smart-pl-name')) $('smart-pl-name').value = '';
        if ($('new-playlist-name')) $('new-playlist-name').value = '';
        loadPlaylistsUI();
    });
    $('preset-smart-4star')?.addEventListener('click', () => createSmartPlaylist('4star'));
    $('preset-smart-untagged')?.addEventListener('click', () => createSmartPlaylist('untagged'));

    const activeSelector = $('active-playlist-selector');
    if(activeSelector) {
        activeSelector.onchange = (e) => {
            activePlaylistView = e.target.value;
            currentConfig.activePlaylistId = activePlaylistView;
            chrome.storage.local.set({mediaConfig: currentConfig});
            currentPage = 1;
            allLibraryItems = []; 
            loadLibraryGrid();
        };
    }

    async function loadLibraryGrid() {
        if (!db) return;
        const grid = $('library-grid');
        if (!grid) return;
        grid.innerHTML = ''; 
        
        if (allLibraryItems.length === 0) {
             const getAllData = (name) => {
                return new Promise((resolve) => {
                    const tx = db.transaction(name, 'readonly');
                    const store = tx.objectStore(name);
                    const items = [];
                    const req = store.openCursor();
                    req.onsuccess = e => {
                        const cursor = e.target.result;
                        if(cursor) {
                            items.push({val: cursor.value, key: cursor.key});
                            cursor.continue();
                        } else {
                            resolve(items);
                        }
                    };
                    req.onerror = () => resolve([]);
                });
            };

            const space = privateOptionsMode ? 'private' : 'public';
            let vaultId;
            if (space === 'private') {
                try {
                    const { fafoPrivateSession } = await chrome.storage.local.get('fafoPrivateSession');
                    vaultId = fafoPrivateSession?.vaultId || 'default';
                } catch {
                    vaultId = 'default';
                }
            }
            let rawItems = [];
            if (window.FAFOLibrary?.getMediaForSpace) {
                const [videos, photos] = await Promise.all([
                    FAFOLibrary.getMediaForSpace(db, 'videos', space, { vaultId }),
                    FAFOLibrary.getMediaForSpace(db, 'photos', space, { vaultId }),
                ]);
                rawItems = [
                    ...videos.map((v) => ({
                        val: {
                            handle: v.handle,
                            name: v.name,
                            parentFolderId: v.parentFolderId,
                            space: v.space,
                            size: v.size,
                            lastModified: v.lastModified,
                        },
                        key: v.key,
                        type: 'video',
                        storeName: 'videos',
                    })),
                    ...photos.map((p) => ({
                        val: {
                            handle: p.handle,
                            name: p.name,
                            parentFolderId: p.parentFolderId,
                            space: p.space,
                            size: p.size,
                            lastModified: p.lastModified,
                        },
                        key: p.key,
                        type: 'photo',
                        storeName: 'photos',
                    })),
                ];
            } else {
                const [videos, photos] = await Promise.all([getAllData('videos'), getAllData('photos')]);
                rawItems = [
                    ...videos.map(v => ({...v, type: 'video', storeName: 'videos'})),
                    ...photos.map(p => ({...p, type: 'photo', storeName: 'photos'}))
                ];
            }

            // Playlists are public-space only — skip in private options
            if (!privateOptionsMode && activePlaylistView !== 'all') {
                const playlists = await getPlaylists();
                const pl = playlists.find(p => p.id === activePlaylistView);
                if (pl) {
                    if (pl.type === 'smart' && window.FAFOLibrary) {
                        const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
                        const resolved = await FAFOLibrary.resolveSmartPlaylist(db, pl, fafoMediaMeta);
                        const allowedKeys = new Set(resolved.map(i => `${i.storeName}_${i.key}`));
                        rawItems = rawItems.filter(item => allowedKeys.has(`${item.storeName}_${item.key}`));
                    } else {
                        const allowedKeys = new Set((pl.items || []).map(i => `${i.store || i.storeName}_${i.key}`));
                        rawItems = rawItems.filter(item => allowedKeys.has(`${item.storeName}_${item.key}`));
                    }
                }
            }
            allLibraryItems = rawItems;
        }

        const totalItems = allLibraryItems.length;
        if (totalItems === 0) {
            grid.innerHTML = '<div style="color:#555; padding:20px; grid-column: 1/-1; text-align:center;">No items found in this source.</div>';
            updatePaginationControls(0);
            return;
        }

        const startIdx = (currentPage - 1) * itemsPerPage;
        const endIdx = startIdx + itemsPerPage;
        const pageItems = allLibraryItems.slice(startIdx, endIdx);

        updatePaginationControls(totalItems);

        for (let i = 0; i < pageItems.length; i++) {
            const item = pageItems[i];
            const globalIndex = startIdx + i + 1; 
            await createGridItem(item.val, item.key, item.storeName, item.type, globalIndex);
        }
    }

    function updatePaginationControls(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        if (currentPage > totalPages && totalPages > 0) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        if($('lib-total-count')) $('lib-total-count').textContent = `${totalItems} Items`;
        if($('lib-page-display')) $('lib-page-display').textContent = `${currentPage}/${totalPages || 1}`;
        
        const prev = $('lib-prev');
        const next = $('lib-next');
        
        if(prev) {
            prev.disabled = currentPage <= 1;
            prev.style.opacity = currentPage <= 1 ? 0.5 : 1;
            prev.onclick = () => { if (currentPage > 1) { currentPage--; loadLibraryGrid(); }};
        }
        if(next) {
            next.disabled = currentPage >= totalPages;
            next.style.opacity = currentPage >= totalPages ? 0.5 : 1;
            next.onclick = () => { 
                const totalPages = Math.ceil(allLibraryItems.length / itemsPerPage);
                if (currentPage < totalPages) { currentPage++; loadLibraryGrid(); }
            };
        }
    }

    const perPageSelect = $('lib-per-page');
    if(perPageSelect) {
        perPageSelect.addEventListener('change', (e) => {
            itemsPerPage = parseInt(e.target.value);
            currentPage = 1;
            loadLibraryGrid();
        });
    }

    async function createGridItem(item, key, storeName, type, index) {
        const grid = $('library-grid');
        const card = document.createElement('div');
        card.className = 'media-card';
        
        let src = '', name = 'Unknown';
        let fileObj = null;
        const entry = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(item) : null;
        const fileHandle = entry?.handle || item;
        try {
            if (fileHandle instanceof File) {
                fileObj = fileHandle;
                src = URL.createObjectURL(fileHandle);
                name = fileHandle.name;
            } else if (fileHandle && typeof fileHandle.getFile === 'function') {
                name = entry?.name || fileHandle.name || 'Unknown';
                const granted = window.FAFOLibrary
                    ? await FAFOLibrary.ensurePermission(fileHandle, 'read')
                    : true;
                if (!granted) throw new Error('permission');
                fileObj = await fileHandle.getFile();
                src = URL.createObjectURL(fileObj);
                name = fileObj.name;
            } else if (item instanceof File) {
                fileObj = item;
                src = URL.createObjectURL(item);
                name = item.name;
            } else if (item?.kind === 'file') {
                fileObj = await item.getFile();
                src = URL.createObjectURL(fileObj);
                name = item.name;
            }
        } catch (e) {
            card.style.opacity = 0.5;
            name = entry?.name || item?.name || '⚠️ Permission Lost';
        }

        if (currentConfig.overrides && currentConfig.overrides[name]) card.classList.add('has-override');

        const el = document.createElement('img');
        el.style.objectFit = 'cover';
        if (type === 'photo') el.src = src;
        else {
            el.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NCIgaGVpZ2h0PSI2NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzIyMiIvPjwvc3ZnPg==';
            if (fileObj) thumbQueue.add(fileObj, el);
            const vidIcon = document.createElement('div');
            vidIcon.textContent = '🎬';
            vidIcon.style.cssText = 'position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); font-size:2rem; text-shadow: 0 2px 5px rgba(0,0,0,0.8);';
            card.appendChild(vidIcon);
        }

        const badge = document.createElement('div');
        badge.className = 'item-index-badge';
        badge.textContent = `#${index}`;
        card.appendChild(badge);

        // Tag/rating badge (public or private meta store)
        try {
            const metaKey = fileObj
                ? (window.FAFOId?.keyFromFile
                    ? FAFOId.keyFromFile(fileObj, name)
                    : `file:${name}|${fileObj.size}|${fileObj.lastModified}`)
                : null;
            const mk = spaceMetaKeys();
            const bag = await chrome.storage.local.get([mk.meta]);
            const fafoMediaMeta = bag[mk.meta] || {};
            let entry = metaKey ? fafoMediaMeta[metaKey] : null;
            if (!entry && window.FAFOId?.findStoredMeta) {
                entry = FAFOId.findStoredMeta(fafoMediaMeta, {
                    name,
                    size: fileObj?.size,
                    mtime: fileObj?.lastModified,
                })?.meta || null;
            }
            if (!entry && name) {
                const hits = Object.values(fafoMediaMeta).filter(m => m && m.name === name);
                entry = hits.length === 1 ? hits[0] : null;
            }
            if (entry && ((entry.tags && entry.tags.length) || entry.rating)) {
                const tagBadge = document.createElement('div');
                tagBadge.style.cssText = 'position:absolute;top:5px;left:5px;background:rgba(0,0,0,0.75);color:#ffc107;font-size:0.65rem;padding:2px 6px;border-radius:4px;max-width:70%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;z-index:5;';
                const stars = entry.rating ? '*'.repeat(entry.rating) : '';
                const t0 = (entry.tags || [])[0] || '';
                tagBadge.textContent = `${stars}${stars && t0 ? ' ' : ''}${t0}${(entry.tags||[]).length > 1 ? '…' : ''}`;
                card.appendChild(tagBadge);
            }
        } catch (_) {}

        const title = document.createElement('div');
        title.textContent = name;
        title.style.cssText = 'position:absolute; bottom:0; left:0; width:100%; padding:5px; background:linear-gradient(transparent, rgba(0,0,0,0.9)); color:white; font-size:0.7rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;';

        const delBtn = document.createElement('button');
        delBtn.innerHTML = '×';
        delBtn.style.cssText = 'position:absolute; top:5px; right:5px; background:rgba(255,0,0,0.7); color:white; border:none; border-radius:50%; width:24px; height:24px; cursor:pointer; display:none; align-items:center; justify-content:center; font-weight:bold; z-index:10;';
        delBtn.onclick = (e) => {
            e.stopPropagation();
            if(confirm(`Delete ${name}?`)) {
                const tx = db.transaction(storeName, 'readwrite');
                tx.objectStore(storeName).delete(key);
                tx.oncomplete = () => { card.remove(); showToast('Deleted item'); allLibraryItems = []; loadLibraryGrid(); };
            }
        };
        
        card.onmouseover = () => delBtn.style.display = 'flex';
        card.onmouseout = () => delBtn.style.display = 'none';

        card.appendChild(el); card.appendChild(title); card.appendChild(delBtn);
        card.onclick = () => openModal(name, src, type, key, storeName, fileObj);
        grid.appendChild(card);
    }

    const modal = $('file-modal');
    let modalRank = 0;
    let modalTags = [];

    function metaKeyFromFile(fileObj, fileName) {
        if (window.FAFOId?.keyFromFile) {
            return FAFOId.keyFromFile(fileObj, fileName);
        }
        if (fileObj) return `file:${fileName}|${fileObj.size}|${fileObj.lastModified}`;
        return `handle:${fileName}`;
    }

    function renderModalRank() {
        const box = $('modal-rank');
        if (!box) return;
        box.querySelectorAll('[data-r]').forEach(st => {
            const r = parseInt(st.dataset.r, 10);
            st.style.color = r <= modalRank ? '#ffc107' : '#444';
        });
    }

    function renderModalTagChips() {
        const box = $('modal-tag-chips');
        if (!box) return;
        box.innerHTML = modalTags.map((t, i) =>
            `<span style="font-size:11px;padding:3px 8px;border-radius:999px;background:rgba(0,229,255,0.15);color:#7ef7ff;cursor:pointer;" data-i="${i}">${t} ×</span>`
        ).join('');
        box.querySelectorAll('[data-i]').forEach(chip => {
            chip.onclick = () => {
                modalTags.splice(parseInt(chip.dataset.i, 10), 1);
                renderModalTagChips();
                if ($('modal-tags')) $('modal-tags').value = modalTags.join(', ');
            };
        });
    }

    async function refreshModalTagSuggestions() {
        const dl = $('modal-tag-suggestions');
        if (!dl) return;
        const mk = spaceMetaKeys();
        const bag = await chrome.storage.local.get([mk.tags, mk.meta]);
        const fafoTagLibrary = bag[mk.tags] || [];
        const fafoMediaMeta = bag[mk.meta] || {};
        const set = new Set(Array.isArray(fafoTagLibrary) ? fafoTagLibrary : []);
        // Opaque Tag DB is canonical vocabulary (plain fafoTagLibrary may be empty)
        try {
            const TD = window.FAFOTagDb;
            if (TD?.load) {
                const sk = window.FAFOPrivateVaults?.privateStorageKeys?.(privateOptionsVaultId)
                    || window.FAFOPrivateVaults?.publicStorageKeys?.();
                const dbKey = privateOptionsMode
                    ? (sk?.tagDb || TD.privateTagDbKey?.(privateOptionsVaultId) || 'fafoTagDbPrivate')
                    : (TD.publicTagDbKey?.() || 'fafoTagDb');
                const db = await TD.load(dbKey);
                (db.tags || []).forEach((t) => set.add(t));
            }
        } catch (_) {}
        Object.values(fafoMediaMeta || {}).forEach(m => (m.tags || []).forEach(t => set.add(t)));
        // Do not pull companion server global tags into private workspace
        if (!privateOptionsMode) {
            try {
                const r = await fetch('http://127.0.0.1:8765/api/tags', { signal: AbortSignal.timeout(1500) });
                if (r.ok) {
                    const tags = await r.json();
                    if (Array.isArray(tags)) tags.forEach(t => set.add(t));
                }
            } catch (_) {}
        }
        dl.innerHTML = [...set].slice(0, 200).map(t => `<option value="${String(t).replace(/"/g, '&quot;')}">`).join('');
    }

    function openModal(fileName, src, type, key, storeName, fileObj) {
        editingFile = { fileName, key, storeName, fileObj };
        if($('modal-title')) $('modal-title').textContent = fileName;
        const previewBox = $('modal-preview-box');
        if(previewBox) {
            previewBox.innerHTML = '';
            const el = type === 'video' ? document.createElement('video') : document.createElement('img');
            el.src = src; el.controls = true; 
            previewBox.appendChild(el);
        }

        const overrides = currentConfig.overrides?.[fileName] || {};
        if($('modal-volume')) $('modal-volume').value = overrides.volume !== undefined ? overrides.volume : -1;
        if($('modal-scaling')) $('modal-scaling').value = overrides.scaling || 'default';
        if($('modal-playlist-select')) $('modal-playlist-select').value = "";

        // Load shared FAFO tags/rating for this asset
        (async () => {
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            const mk = metaKeyFromFile(fileObj, fileName);
            let entry = fafoMediaMeta[mk];
            if (!entry && window.FAFOId?.findStoredMeta) {
                entry = FAFOId.findStoredMeta(fafoMediaMeta, {
                    name: fileName,
                    size: fileObj?.size,
                    mtime: fileObj?.lastModified,
                })?.meta || null;
            }
            if (!entry) {
                const hits = Object.values(fafoMediaMeta).filter(m => m && m.name === fileName);
                entry = hits.length === 1 ? hits[0] : null;
            }
            modalRank = entry?.rating || 0;
            modalTags = Array.isArray(entry?.tags) ? [...entry.tags] : [];
            if ($('modal-tags')) $('modal-tags').value = modalTags.join(', ');
            renderModalRank();
            renderModalTagChips();
            await refreshModalTagSuggestions();
        })();
        
        if(modal) modal.style.display = 'flex';
    }

    // Modal rank stars
    if ($('modal-rank')) {
        $('modal-rank').querySelectorAll('[data-r]').forEach(st => {
            st.onclick = () => {
                const r = parseInt(st.dataset.r, 10);
                modalRank = modalRank === r ? 0 : r;
                renderModalRank();
            };
        });
    }
    if ($('modal-tags')) {
        $('modal-tags').addEventListener('change', () => {
            modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
            renderModalTagChips();
        });
        $('modal-tags').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
                renderModalTagChips();
            }
        });
    }

    function closeModal() {
        if(modal) modal.style.display = 'none';
        if($('modal-preview-box')) $('modal-preview-box').innerHTML = ''; 
    }

    if($('modal-save')) {
        $('modal-save').onclick = async () => {
            if (!currentConfig.overrides) currentConfig.overrides = {};
            const vol = parseFloat($('modal-volume').value);
            const scale = $('modal-scaling').value;
            
            if (vol === -1 && scale === 'default') delete currentConfig.overrides[editingFile.fileName];
            else currentConfig.overrides[editingFile.fileName] = {
                volume: vol === -1 ? undefined : vol,
                scaling: scale === 'default' ? undefined : scale
            };

            const playlistId = $('modal-playlist-select') ? $('modal-playlist-select').value : null;
            if(playlistId && db) {
                const tx = db.transaction('playlists', 'readwrite');
                const store = tx.objectStore('playlists');
                const p = await new Promise(res => { 
                    store.get(playlistId).onsuccess = e => res(e.target.result); 
                });
                
                if(p) {
                    const exists = p.items.some(i => i.key === editingFile.key && i.store === editingFile.storeName);
                    if(!exists) {
                        p.items.push({ store: editingFile.storeName, key: editingFile.key });
                        store.put(p);
                        showToast(`Added to ${p.name}`);
                    }
                }
            }

            // Save tags/rating into shared fafoMediaMeta (same keys as new-tab player)
            if ($('modal-tags')) {
                modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
            }
            const {
                fafoMediaMeta = {},
                fafoTagLibrary = [],
                fafoTagApplyCounts = {},
            } = await chrome.storage.local.get(['fafoMediaMeta', 'fafoTagLibrary', 'fafoTagApplyCounts']);
            const mk = metaKeyFromFile(editingFile.fileObj, editingFile.fileName);
            const prevTags = Array.isArray(fafoMediaMeta[mk]?.tags) ? fafoMediaMeta[mk].tags : [];
            const prevLow = new Set(prevTags.map((t) => String(t).toLowerCase()));
            const nextLow = new Set(modalTags.map((t) => String(t).toLowerCase()));
            // Keep apply counts in sync with add/remove from Options modal
            const applyCounts = (fafoTagApplyCounts && typeof fafoTagApplyCounts === 'object')
                ? { ...fafoTagApplyCounts }
                : {};
            modalTags.forEach((t) => {
                const low = String(t).toLowerCase();
                if (!prevLow.has(low)) applyCounts[low] = (applyCounts[low] || 0) + 1;
            });
            prevTags.forEach((t) => {
                const low = String(t).toLowerCase();
                if (!nextLow.has(low) && (applyCounts[low] || 0) > 0) {
                    applyCounts[low] -= 1;
                    if (applyCounts[low] <= 0) delete applyCounts[low];
                }
            });
            fafoMediaMeta[mk] = {
                rating: modalRank || 0,
                tags: modalTags,
                name: editingFile.fileName,
                updated: Date.now(),
            };
            // Grow vocabulary without reordering MRU timestamps (options page doesn't touch lastUsed)
            const lib = Array.isArray(fafoTagLibrary) ? fafoTagLibrary.slice() : [];
            modalTags.forEach(t => {
                if (!lib.some(x => String(x).toLowerCase() === t.toLowerCase())) lib.push(t);
            });
            await chrome.storage.local.set({
                fafoMediaMeta,
                fafoTagLibrary: lib,
                fafoTagApplyCounts: applyCounts,
            });

            // Best-effort write to disk via toolbox/explorer-meta server
            try {
                const f = editingFile.fileObj;
                await fetch('http://127.0.0.1:8765/api/fs/write-metadata', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: editingFile.fileName,
                        size: f ? f.size : null,
                        mtime: f ? f.lastModified : null,
                        tags: modalTags,
                        rating: modalRank || 0,
                        update_catalog: true,
                    }),
                    signal: AbortSignal.timeout(4000),
                });
            } catch (_) {}

            await saveAll();
            closeModal();
            allLibraryItems = []; 
            loadLibraryGrid();
            showToast('Saved tags & overrides');
        };
    }

    if($('modal-delete')) {
        $('modal-delete').onclick = async () => {
            if(!confirm("Remove this file from library?")) return;
            const tx = db.transaction(editingFile.storeName, 'readwrite');
            tx.objectStore(editingFile.storeName).delete(editingFile.key);
            tx.oncomplete = () => { closeModal(); allLibraryItems = []; loadLibraryGrid(); };
        };
    }
    if($('modal-cancel')) $('modal-cancel').onclick = closeModal;

    async function saveAll() {
        const get = (id, type) => {
            const el = $(id);
            if (!el) return undefined;
            if(type === 'check') return el.checked;
            if(type === 'float') return parseFloat(el.value);
            if(type === 'array') return el.value.split('\n').map(l => l.trim()).filter(Boolean);
            return type === 'int' ? parseInt(el.value) : el.value;
        };

        const newConfig = {
            ...currentConfig,
            useLocal: get('use-local', 'check'),
            usePhotos: get('use-photos', 'check'),
            urls: get('urls', 'array'),
            thumbSeekSec: window.FAFOPairs?.getThumbSeekSec?.() ?? currentConfig.thumbSeekSec ?? 1,
            
            layout: get('layout'),
            scaling: get('scaling'),
            gridCols: get('grid-cols', 'int'),
            gridRows: get('grid-rows', 'int'),
            carouselRadius: get('carousel-radius', 'int'),
            carouselTilt: get('carousel-tilt', 'int'),
            carouselSpeed: get('carousel-speed', 'int'),
            reflectOpacity: get('reflect-opacity', 'int'),
            reflectOffset: get('reflect-offset', 'int'),
            
            // bokehEnable REMOVED - Controlled by individual switches now
            
            brightness: get('brightness', 'int'),
            contrast: get('contrast', 'int'),
            saturate: get('saturate', 'int'),
            sepia: get('sepia', 'int'),
            grayscale: get('grayscale', 'int'),
            
            ambiScale: get('ambi-scale', 'float'),
            ambiOpacity: get('ambi-opacity', 'float'),
            ambiBlur: get('ambi-blur', 'int'),
            ambiMode: get('ambi-mode'),
            borderColor: get('border-color'),
            borderGlow: get('border-glow', 'int'),
            borderSize: get('border-size', 'int'),

            screenFrameEnabled: get('screen-frame-enabled', 'check'),
            screenFrameSize: get('screen-frame-size', 'int'),
            screenFrameGlow: get('screen-frame-glow', 'int'),
            screenFrameOpacity: get('screen-frame-opacity', 'float'),
            screenFrameColor: get('screen-frame-color'),
            screenFrameStyle: get('screen-frame-style') || 'solid',
            screenFrameRadius: get('screen-frame-radius', 'int'),

            neonBorder: get('neon-border', 'check'),
            neonPattern: get('neon-pattern'),
            neonSegments: get('neon-segments', 'int'),
            neonSpeed: get('neon-speed', 'float'),
            neonAudio: get('neon-audio', 'check'),
            neonStrobe: get('neon-strobe', 'float'),
            neonSensitivity: get('neon-sensitivity', 'float'),
            neonWidth: get('neon-width', 'int'),
            neonUseAccent: get('neon-use-accent', 'check'),
            neonColor: get('neon-color'),
            
            volume: get('volume', 'float'),
            photoDuration: get('photo-duration', 'int'),
            shuffle: get('shuffle', 'check'),
            kenburns: get('kenburns', 'check'),
            playbackSpeed: parseFloat(get('playback-speed') ?? 1) || 1,
            loops: Math.max(1, parseInt(get('loops') ?? 1, 10) || 1),
            
            pos: get('clock-pos'),
            clockSize: get('clock-size', 'int'),
            font: get('font-family'),
            showDate: get('show-date', 'check'),
            format12h: get('format-12h', 'check'),
            showSeconds: get('show-seconds', 'check'),
            
            accentColor: get('accent-color'),
            activePlaylistId: activePlaylistView,

            uiThemePreset: get('uiThemePreset') || 'cyan',
            uiPanelOpacity: parseFloat(get('uiPanelOpacity') ?? 0.92) || 0.92,
            uiHudOpacity: parseFloat(get('uiHudOpacity') ?? 0.82) || 0.82,
            uiPanelBorderOpacity: parseFloat(get('uiPanelBorderOpacity') ?? 0.14) || 0.14,
            uiRadius: parseInt(get('uiRadius') ?? 14, 10) || 14,
            uiPanelBorderColor: get('uiPanelBorderColor') || get('accent-color') || '#00e5ff',

            performanceMode: !!get('performanceMode', 'check'),
            maxDisplayHeight: parseInt(get('maxDisplayHeight') ?? 0, 10) || 0,
            disableAmbience: !!get('disableAmbience', 'check'),
            disableParticles: !!get('disableParticles', 'check'),
            disableCssFilters: !!get('disableCssFilters', 'check'),
            disableNeonAudio: !!get('disableNeonAudio', 'check'),

            // Advanced visual customizer (also mirrored to fafoVisual)
            visual: window.FAFOVisual
                ? FAFOVisual.normalize(readVisualForm())
                : (currentConfig.visual || undefined),
            customThemes: Array.isArray(customThemes) ? customThemes : (currentConfig.customThemes || []),
            activeCustomThemeId: typeof selectedCustomThemeId !== 'undefined'
                ? selectedCustomThemeId
                : (currentConfig.activeCustomThemeId || ''),
        };
        
        // Dynamic FX Saving
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            const checkId = `fx-${type}`;
            if($(checkId)) newConfig[camelCase(checkId)] = $(checkId).checked;
            
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                if($(id)) newConfig[camelCase(id)] = parseInt($(id).value);
            });
        });

        await chrome.storage.local.set({ mediaConfig: newConfig });
        // Tagging defaults used by new-tab player
        await chrome.storage.local.set({
            fafoSkipTaggedMode: !!get('opt-skip-tagged', 'check'),
            fafoApplyAndNext: !!get('opt-apply-next', 'check'),
            fafoTagCountMode: get('opt-tag-count-mode') === 'total' ? 'total' : 'session',
        });
        // Independent GUI / video scales (also auto-save on slider move)
        try { await persistIndependentScales({ toast: false }); } catch (_) {}
        // Wall count / scalability prefs
        try { await persistWallPrefs({ toast: false, syncGrid: newConfig.layout === 'grid' }); } catch (_) {}
        currentConfig = newConfig;
        applyTheme(newConfig.accentColor);
        // Persist advanced visual FX + apply live
        try {
            if (window.FAFOVisual && newConfig.visual) {
                await FAFOVisual.saveToStorage(newConfig.visual);
                FAFOVisual.apply(newConfig.visual);
            }
        } catch (_) {}
        // Mirror options + playlists + library file index into rolling JSON backup
        scheduleFullBackup('options-save');
        showToast('System Configuration Saved');
    }

    async function refreshTagsOptionsUI() {
        const health = $('opt-tags-health');
        try {
            const data = await chrome.storage.local.get([
                'fafoMediaMeta', 'fafoTagLibrary', 'fafoTagApplyCounts',
                'fafoTagHotkeys', 'fafoSkipTaggedMode', 'fafoApplyAndNext',
            ]);
            const meta = data.fafoMediaMeta || {};
            const nMedia = Object.keys(meta).length;
            const nTagged = Object.values(meta).filter((m) => m?.tags?.length).length;
            const nTags = Array.isArray(data.fafoTagLibrary) ? data.fafoTagLibrary.length : 0;
            const nApply = data.fafoTagApplyCounts && typeof data.fafoTagApplyCounts === 'object'
                ? Object.keys(data.fafoTagApplyCounts).length
                : 0;
            if (health) {
                health.innerHTML =
                    `<strong>Indexed files:</strong> ${nMedia} · <strong>with tags:</strong> ${nTagged}<br>` +
                    `<strong>Known tags:</strong> ${nTags} · <strong>Uses counters:</strong> ${nApply}<br>` +
                    `<strong>Skip tagged default:</strong> ${data.fafoSkipTaggedMode ? 'ON' : 'off'} · ` +
                    `<strong>Apply+Next default:</strong> ${data.fafoApplyAndNext ? 'ON' : 'off'}`;
            }
        } catch (e) {
            if (health) health.textContent = 'Could not read tag storage: ' + (e.message || e);
        }
    }

    // Wire Tags options actions (once)
    $('opt-rebuild-from-disk')?.addEventListener('click', async () => {
        if (!confirm(
            'Rebuild FAFO tags from disk (Windows Explorer metadata)?\n\n' +
            'Requires S2 Explorer meta server running.\n' +
            'Reads Tags + Rating from each indexed file and merges into the FAFO library.\n' +
            'This is the recovery path when snapshots or Chrome storage lost tags.'
        )) return;
        const health = $('opt-tags-health');
        if (health) health.textContent = 'Reading tags from disk files… (can take a few minutes)';
        try {
            if (!window.FAFOMeta?.rebuildMediaMetaFromDisk) {
                // Fallback: open new tab player so FAFOMeta is available, or call API + storage directly
                throw new Error('Open a new tab (player) once so FAFOMeta loads, then retry — or use Tags panel → Rebuild');
            }
            const r = await FAFOMeta.rebuildMediaMetaFromDisk({});
            showToast(
                `Disk recovery · ${r.withTags || 0} tagged files · ${ (r.updated || 0) + (r.created || 0) } media entries`
            );
            await refreshTagsOptionsUI();
        } catch (e) {
            // Direct storage path if Meta not loaded: call export API and merge into fafoMediaMeta
            try {
                const online = await fetch('http://127.0.0.1:8765/api/health', { signal: AbortSignal.timeout(2000) }).then((r) => r.ok).catch(() => false);
                if (!online) throw e;
                if (health) health.textContent = 'S2 online — exporting disk tags…';
                await fetch('http://127.0.0.1:8765/api/library/rescan', { method: 'POST' }).catch(() => {});
                const exp = await fetch('http://127.0.0.1:8765/api/library/export-tags', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ rescan: false, only_tagged: true, max_files: 20000 }),
                });
                if (!exp.ok) throw new Error('export-tags HTTP ' + exp.status);
                const data = await exp.json();
                const items = Array.isArray(data.items) ? data.items : [];
                const { fafoMediaMeta = {}, fafoTagLibrary = [] } = await chrome.storage.local.get([
                    'fafoMediaMeta', 'fafoTagLibrary',
                ]);
                const meta = { ...(fafoMediaMeta || {}) };
                const lib = Array.isArray(fafoTagLibrary) ? fafoTagLibrary.slice() : [];
                const libLow = new Set(lib.map((t) => String(t).toLowerCase()));
                let n = 0;
                for (const it of items) {
                    const name = String(it.name || '').trim();
                    if (!name) continue;
                    const size = it.size != null ? Number(it.size) : 0;
                    const tags = (it.tags || []).map((t) => String(t).trim()).filter(Boolean);
                    const rating = Math.max(0, Math.min(5, parseInt(it.rating, 10) || 0));
                    if (!tags.length && !rating) continue;
                    const key = `file:${name}|${size}|0`;
                    const prev = meta[key] || Object
                    // Prefer existing better key match by name
                    let useKey = key;
                    for (const [k, v] of Object.entries(meta)) {
                        if (v?.name && String(v.name).toLowerCase() === name.toLowerCase()
                            && (size == null || v.size == null || Number(v.size) === size)) {
                            useKey = k;
                            break;
                        }
                    }
                    const prevTags = Array.isArray(meta[useKey]?.tags) ? meta[useKey].tags : [];
                    const map = new Map();
                    tags.forEach((t) => map.set(t.toLowerCase(), t));
                    prevTags.forEach((t) => {
                        const s = String(t).trim();
                        if (s && !map.has(s.toLowerCase())) map.set(s.toLowerCase(), s);
                    });
                    const merged = [...map.values()];
                    meta[useKey] = {
                        ...(meta[useKey] || prev),
                        name,
                        size: size || meta[useKey]?.size || null,
                        tags: merged,
                        rating: rating || meta[useKey]?.rating || 0,
                        path: it.path,
                        updated: Date.now(),
                        recoveredFromDisk: true,
                    };
                    merged.forEach((t) => {
                        if (!libLow.has(t.toLowerCase())) {
                            lib.push(t);
                            libLow.add(t.toLowerCase());
                        }
                    });
                    n += 1;
                }
                const counts = {};
                Object.values(meta).forEach((m) => {
                    (m.tags || []).forEach((raw) => {
                        const t = String(raw || '').trim();
                        if (!t) return;
                        const low = t.toLowerCase();
                        counts[low] = (counts[low] || 0) + 1;
                    });
                });
                await chrome.storage.local.set({
                    fafoMediaMeta: meta,
                    fafoTagLibrary: lib,
                    fafoTagApplyCounts: counts,
                });
                showToast(`Disk recovery · ${n} files · ${Object.keys(counts).length} tags — reload new tab`);
                await refreshTagsOptionsUI();
            } catch (e2) {
                showToast('Disk rebuild failed: ' + (e2.message || e2), 'error');
                if (health) health.textContent = 'Disk rebuild failed — is S2 running? ' + (e2.message || e2);
            }
        }
    });

    $('opt-rebuild-counts')?.addEventListener('click', async () => {
        if (!confirm('Rebuild Uses counts from library tags?\n\nEach tag’s Uses # becomes how many files currently have it.\n\nTip: use “Rebuild from disk tags” if the library itself is empty.')) return;
        try {
            if (window.FAFOMeta?.rebuildApplyCountsFromLibrary) {
                await FAFOMeta.rebuildApplyCountsFromLibrary();
                showToast('Uses counts rebuilt from FAFO library');
                await refreshTagsOptionsUI();
                return;
            }
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            const counts = {};
            const lib = new Set();
            Object.values(fafoMediaMeta).forEach((m) => {
                (m.tags || []).forEach((raw) => {
                    const t = String(raw || '').trim();
                    if (!t) return;
                    const low = t.toLowerCase();
                    counts[low] = (counts[low] || 0) + 1;
                    lib.add(t);
                });
            });
            const { fafoTagLibrary = [] } = await chrome.storage.local.get('fafoTagLibrary');
            const merged = Array.isArray(fafoTagLibrary) ? fafoTagLibrary.slice() : [];
            lib.forEach((t) => {
                if (!merged.some((x) => String(x).toLowerCase() === t.toLowerCase())) merged.push(t);
            });
            await chrome.storage.local.set({
                fafoTagApplyCounts: counts,
                fafoTagLibrary: merged,
            });
            showToast(`Rebuilt Uses for ${Object.keys(counts).length} tags`);
            await refreshTagsOptionsUI();
        } catch (e) {
            showToast('Rebuild failed: ' + (e.message || e), 'error');
        }
    });

    $('opt-export-tags-quick')?.addEventListener('click', async () => {
        if (!window.FAFOBackup?.exportToDownload) {
            showToast('Backup module missing', 'error');
            return;
        }
        try {
            // Full package: tags + options + playlists + library file index
            await FAFOBackup.exportToDownload({ includeConfig: true });
            showToast('Full JSON backup exported (tags · options · playlists · files)');
            await refreshTagsBackupUI();
        } catch (e) {
            showToast('Export failed: ' + (e.message || e), 'error');
        }
    });
    
    if($('save-all-btn')) $('save-all-btn').onclick = saveAll;

    function fmtBackupTime(ts) {
        if (!ts) return '—';
        try { return new Date(ts).toLocaleString(); } catch { return String(ts); }
    }

    /** File names from Visual Library (no getFile — fast) for tagged/untagged coverage. */
    function libraryNamesForBackup() {
        const items = Array.isArray(allLibraryItems) ? allLibraryItems : [];
        return items.map((it) => {
            try {
                const raw = it?.val != null ? it.val : it;
                if (typeof raw === 'string') return raw;
                if (raw instanceof File) return raw.name || '';
                return raw?.name || raw?.fileName || it?.name || it?.fileName || '';
            } catch {
                return '';
            }
        }).map((n) => String(n || '').trim()).filter(Boolean);
    }

    async function refreshBackupFolderStatus() {
        const el = $('backup-folder-status');
        if (!el) return;
        const lines = [];
        try {
            if (window.FAFOBackup?.vaultStatusFromServer) {
                const vs = await FAFOBackup.vaultStatusFromServer();
                if (vs?.ok) {
                    lines.push(`Companion vault: ${vs.vault}`);
                    lines.push(`latest/full.json: ${vs.latest_exists ? 'yes' : 'not yet'}`);
                    if (vs.buckets) {
                        const bits = Object.entries(vs.buckets)
                            .filter(([k]) => k !== 'legacy')
                            .map(([k, v]) => `${k} ${v.count}/${v.keep}`)
                            .join(' · ');
                        if (bits) lines.push(`Rolling: ${bits}`);
                    }
                    if (vs.themes != null) lines.push(`Custom themes on disk: ${vs.themes}`);
                } else {
                    lines.push('Companion vault offline — start explorer-meta\\START_META_SERVER.bat for disk vault.');
                }
            }
        } catch {
            lines.push('Companion vault offline.');
        }
        try {
            const user = window.FAFOBackup?.getUserBackupFolderInfo
                ? await FAFOBackup.getUserBackupFolderInfo()
                : null;
            if (user) {
                lines.push(`Your folder: ${user.name} (permission: ${user.permission || 'ok'})`);
            } else {
                lines.push('No custom backup folder linked — click Choose backup folder (e.g. Downloads).');
            }
        } catch (_) {}
        el.innerHTML = lines.map((l) => `<div>${l}</div>`).join('');
    }

    async function refreshTagsBackupUI() {
        const status = $('tags-backup-status');
        const list = $('tags-backup-history');
        refreshBackupFolderStatus().catch(() => {});
        if (!window.FAFOBackup) {
            if (status) status.textContent = 'Backup module missing (fafo-backup.js).';
            return;
        }
        try {
            // Ensure library grid is counted when available
            let libraryTotal = Array.isArray(allLibraryItems) ? allLibraryItems.length : 0;
            let libraryNames = libraryNamesForBackup();
            if (!libraryTotal && typeof loadLibraryGrid === 'function') {
                try {
                    await loadLibraryGrid?.();
                    libraryTotal = Array.isArray(allLibraryItems) ? allLibraryItems.length : 0;
                    libraryNames = libraryNamesForBackup();
                } catch (_) {}
            }

            const s = await FAFOBackup.statusSummary({
                libraryTotal: libraryTotal > 0 ? libraryTotal : undefined,
                libraryNames: libraryNames.length ? libraryNames : undefined,
            });
            const c = s.coverage || {};

            if (status) {
                const libBlock = c.libraryTotal != null
                    ? `<div class="backup-stat-card">
                        <div class="backup-stat-label">Visual library</div>
                        <div class="backup-stat-value">${c.libraryTotal}</div>
                        <div class="backup-stat-detail">
                            <span class="ok">${c.libraryTagged ?? 0} tagged</span>
                            · <span class="warn">${c.libraryUntagged ?? 0} untagged</span>
                            ${c.pctTaggedInLibrary != null ? ` · ${c.pctTaggedInLibrary}% tagged` : ''}
                        </div>
                       </div>`
                    : `<div class="backup-stat-card">
                        <div class="backup-stat-label">Visual library</div>
                        <div class="backup-stat-value">—</div>
                        <div class="backup-stat-detail">Open Visual Library once so FAFO can count files</div>
                       </div>`;

                status.innerHTML = `
                    <div class="backup-stats-grid">
                        <div class="backup-stat-card">
                            <div class="backup-stat-label">Tags recorded</div>
                            <div class="backup-stat-value">${c.totalTagsRecorded ?? s.liveTags ?? 0}</div>
                            <div class="backup-stat-detail">
                                ${c.uniqueTagsOnFiles ?? 0} used on files
                                · ${c.totalTagApplications ?? 0} total applies
                            </div>
                        </div>
                        <div class="backup-stat-card">
                            <div class="backup-stat-label">Files with tags</div>
                            <div class="backup-stat-value ok">${c.filesWithTags ?? 0}</div>
                            <div class="backup-stat-detail">
                                of ${c.mediaMetaEntries ?? s.liveMedia ?? 0} meta records
                                ${c.pctTaggedInMeta != null ? ` (${c.pctTaggedInMeta}%)` : ''}
                            </div>
                        </div>
                        <div class="backup-stat-card">
                            <div class="backup-stat-label">Untagged files</div>
                            <div class="backup-stat-value warn">${
                                c.libraryUntagged != null
                                    ? c.libraryUntagged
                                    : (c.filesWithoutTagsInMeta ?? 0)
                            }</div>
                            <div class="backup-stat-detail">
                                ${c.libraryTotal != null
                                    ? `in library of ${c.libraryTotal}`
                                    : `${c.filesWithoutTagsInMeta ?? 0} untagged meta · library size unknown`}
                            </div>
                        </div>
                        ${libBlock}
                        <div class="backup-stat-card">
                            <div class="backup-stat-label">Ratings · pairs</div>
                            <div class="backup-stat-value">${c.filesWithRating ?? 0} · ${s.livePairs ?? 0}</div>
                            <div class="backup-stat-detail">
                                ${c.filesRatingOnly ?? 0} rated with no tags
                            </div>
                        </div>
                        <div class="backup-stat-card">
                            <div class="backup-stat-label">Snapshots</div>
                            <div class="backup-stat-value">${s.historyCount ?? 0}</div>
                            <div class="backup-stat-detail">
                                Latest: ${s.snapshotAt ? fmtBackupTime(s.snapshotAt) : 'none yet'}
                                ${s.snapshotMedia != null ? ` · ${s.snapshotMedia} media` : ''}
                            </div>
                        </div>
                    </div>
                    <div class="backup-stats-note">
                        <strong>Live storage:</strong> ${s.liveMedia} meta entries · ${s.liveTags} tag vocabulary · ${s.livePairs} pairs.
                        “Untagged in library” uses Visual Library size when available; files never opened still count as untagged.
                    </div>
                `;
            }
            if (!list) return;
            if (!s.history.length) {
                list.innerHTML = '<span style="color:#666;font-size:0.85rem;">No history yet — tag a file or click Snapshot now.</span>';
                return;
            }
            list.innerHTML = s.history.map((h) => `
                <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 12px;border:1px solid #333;border-radius:10px;background:rgba(0,0,0,0.35);">
                    <div style="flex:1;min-width:180px;font-size:0.8rem;color:#ccc;">
                        <strong style="color:#fff;">${fmtBackupTime(h.savedAt)}</strong>
                        <span style="color:#666;"> · ${escapeHtmlBackup(h.reason || 'auto')}</span><br>
                        <span style="color:#888;">
                            ${h.tagCount || 0} tags ·
                            ${h.filesWithTags != null ? h.filesWithTags + ' tagged' : (h.mediaEntries || 0) + ' media'} ·
                            ${h.filesWithoutTags != null ? h.filesWithoutTags + ' untagged meta' : ''} ·
                            ${h.pairCount || 0} pairs
                        </span>
                    </div>
                    <button class="btn btn-primary small" data-restore-id="${escapeHtmlBackup(h.id)}">Restore</button>
                </div>
            `).join('');
            list.querySelectorAll('[data-restore-id]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    if (!confirm('Restore this backup? Current tags will be snapshotted first, then replaced.')) return;
                    try {
                        btn.disabled = true;
                        const r = await FAFOBackup.restoreHistoryId(btn.dataset.restoreId);
                        showToast(`Restored: ${r.mediaEntries} media, ${r.tags} tags, ${r.pairs} pairs`);
                        await refreshTagsBackupUI();
                    } catch (e) {
                        showToast(e.message || 'Restore failed', 'error');
                    } finally {
                        btn.disabled = false;
                    }
                });
            });
        } catch (e) {
            if (status) status.textContent = 'Could not load backup status: ' + (e.message || e);
        }
    }

    function escapeHtmlBackup(s) {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/"/g, '&quot;');
    }

    $('backup-folder-link')?.addEventListener('click', async () => {
        if (!window.FAFOBackup?.linkUserBackupFolder) {
            showToast('Backup module missing', 'error');
            return;
        }
        try {
            const r = await FAFOBackup.linkUserBackupFolder();
            showToast(`Backup folder ready: ${r.name || 'FAFO-Backups'}`);
            await refreshBackupFolderStatus();
        } catch (e) {
            if (e?.name === 'AbortError') return;
            showToast(e.message || 'Could not link folder', 'error');
        }
    });
    $('backup-folder-refresh')?.addEventListener('click', () => refreshBackupFolderStatus());

    if ($('export-tags-btn')) {
        $('export-tags-btn').onclick = async () => {
            if (!window.FAFOBackup) return showToast('Backup module missing', 'error');
            try {
                await FAFOBackup.exportToDownload({ includeConfig: false });
                showToast('Tags backup downloaded');
                await refreshTagsBackupUI();
            } catch (e) {
                showToast(e.message || 'Export failed', 'error');
            }
        };
    }
    if ($('import-tags-btn')) $('import-tags-btn').onclick = () => $('import-tags-file')?.click();
    if ($('import-tags-file')) {
        $('import-tags-file').onchange = async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (!file || !window.FAFOBackup) return;
            if (!confirm('Import tags backup? Live data will be snapshotted, then replaced from the file.')) return;
            try {
                const r = await FAFOBackup.importFromFile(file, { includeConfig: false });
                if (r.configOnly) {
                    showToast('That file was config-only — use Import config JSON', 'error');
                    return;
                }
                showToast(`Imported: ${r.mediaEntries} media, ${r.tags} tags, ${r.pairs} pairs — reloading…`);
                setTimeout(() => location.reload(), 900);
            } catch (err) {
                showToast(err.message || 'Import failed', 'error');
            }
        };
    }
    if ($('backup-now-btn')) {
        $('backup-now-btn').onclick = async () => {
            if (!window.FAFOBackup) return;
            try {
                await FAFOBackup.afterLiveSave(null, 'manual');
                showToast('Snapshot saved to history');
                await refreshTagsBackupUI();
            } catch (e) {
                showToast(e.message || 'Snapshot failed', 'error');
            }
        };
    }
    if ($('restore-latest-btn')) {
        $('restore-latest-btn').onclick = async () => {
            if (!window.FAFOBackup) return;
            if (!confirm('Restore the latest auto-snapshot? Current live data is snapshotted first.')) return;
            try {
                const r = await FAFOBackup.restoreLatestSnapshot();
                showToast(`Restored latest: ${r.mediaEntries} media — reloading…`);
                setTimeout(() => location.reload(), 900);
            } catch (e) {
                showToast(e.message || 'Restore failed', 'error');
            }
        };
    }

    if($('export-btn')) $('export-btn').onclick = () => {
        const blob = new Blob([JSON.stringify(currentConfig, null, 2)], {type: 'application/json'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'fafo-media-config.json'; a.click();
    };
    if($('import-btn')) $('import-btn').onclick = () => $('import-file').click();
    if($('import-file')) $('import-file').onchange = e => {
        const r = new FileReader();
        r.onload = async (evt) => {
            try {
                const obj = JSON.parse(evt.target.result);
                // Smart import: tags backup vs config
                if (window.FAFOBackup && (obj.kind === FAFOBackup.KIND || obj.fafoMediaMeta || obj.data?.fafoMediaMeta)) {
                    const res = await FAFOBackup.importFromObject(obj, { includeConfig: !!obj.data?.mediaConfig });
                    showToast(res.configOnly ? 'Config loaded' : `Tags imported (${res.mediaEntries} media) — reloading…`);
                    setTimeout(() => location.reload(), 900);
                    return;
                }
                await chrome.storage.local.set({mediaConfig: obj});
                showToast('Config Loaded! Reloading...'); setTimeout(() => location.reload(), 1000);
            } catch(err) { showToast('Invalid Config File', 'error'); }
        };
        r.readAsText(e.target.files[0]);
    };
    
    async function addFolder(storeName, btnId) {
        if (!db) { showToast('Database Not Ready', 'error'); return; }
        const btn = $(btnId);
        const originalText = btn.textContent;
        try {
            const dirHandle = await showDirectoryPicker({ mode: 'read' });
            btn.textContent = 'Scanning…';
            btn.disabled = true;
            btn.style.opacity = 0.5;

            if (window.FAFOLibrary?.linkFolder) {
                const space = privateOptionsMode ? 'private' : 'public';
                let vaultId;
                if (space === 'private') {
                    try {
                        const { fafoPrivateSession } = await chrome.storage.local.get('fafoPrivateSession');
                        vaultId = fafoPrivateSession?.vaultId || 'default';
                    } catch {
                        vaultId = 'default';
                    }
                }
                const { folder, added } = await FAFOLibrary.linkFolder(db, storeName, dirHandle, { space, vaultId });
                showToast(
                    privateOptionsMode
                        ? `Private folder “${folder.name}” — ${added} files (vault ${vaultId}, hidden from public)`
                        : `Linked “${folder.name}” — ${added} files (saved for resync)`
                );
            } else {
                // Fallback without shared module
                const regex = storeName === 'photos'
                    ? /\.(jpg|jpeg|png|webp|gif|bmp)$/i
                    : /\.(mp4|webm|mkv|mov|avi|m4v)$/i;
                const handles = [];
                async function scan(dir) {
                    for await (const entry of dir.values()) {
                        if (entry.kind === 'file' && regex.test(entry.name)) handles.push(entry);
                        else if (entry.kind === 'directory') await scan(entry);
                    }
                }
                await scan(dirHandle);
                if (!handles.length) {
                    showToast('No files found', 'error');
                    return;
                }
                const tx = db.transaction(storeName, 'readwrite');
                const store = tx.objectStore(storeName);
                handles.forEach((h) => store.put({ handle: h, name: h.name, addedAt: Date.now() }, crypto.randomUUID()));
                await new Promise((res) => { tx.oncomplete = res; });
                showToast(`Added ${handles.length} files`);
            }
            allLibraryItems = [];
            await loadLibraryGrid();
            await refreshLinkedFoldersUI();
        } catch (e) {
            if (e?.name !== 'AbortError') {
                console.warn(e);
                showToast(e.message || 'Link cancelled / failed', 'error');
            }
        } finally {
            btn.textContent = originalText;
            btn.disabled = false;
            btn.style.opacity = 1;
        }
    }

    async function refreshLinkedFoldersUI() {
        const list = $('linked-folders-list');
        const statusEl = $('library-access-status');
        if (!db || !list) return;

        if (!window.FAFOLibrary) {
            list.innerHTML = '<span style="color:#666;font-size:0.85rem">Update incomplete — fafo-library.js missing.</span>';
            return;
        }

        const space = privateOptionsMode ? 'private' : 'public';
        let vaultId;
        if (space === 'private') {
            try {
                const { fafoPrivateSession } = await chrome.storage.local.get('fafoPrivateSession');
                vaultId = fafoPrivateSession?.vaultId || 'default';
            } catch {
                vaultId = 'default';
            }
        }
        const folders = await FAFOLibrary.listFolders(db, { space, vaultId });
        const st = await FAFOLibrary.libraryAccessStatus(db);
        if (statusEl) {
            if (!folders.length && st.sampleOk === 0 && st.sampleBad === 0) {
                statusEl.textContent = privateOptionsMode
                    ? `No private folders yet for vault “${vaultId}” — use Link folder (saved as private only).`
                    : 'No folders linked yet — use + Link Video/Photo Folder below.';
                statusEl.style.color = '#888';
            } else if (st.needsRestore) {
                statusEl.textContent = `Access needs restore: ${st.folderPrompt + st.folderDenied} folder(s) pending · sample files ok ${st.sampleOk} / bad ${st.sampleBad}. Click 🔓 Restore Access.`;
                statusEl.style.color = '#ffc107';
            } else {
                statusEl.textContent = privateOptionsMode
                    ? `Private only — ${folders.length} folder(s). Public library is not shown.`
                    : `Access OK — ${folders.length} saved folder(s), ${st.folderGranted} granted. Resync picks up new files without re-picking.`;
                statusEl.style.color = 'var(--accent)';
            }
        }

        if (!folders.length) {
            list.innerHTML = privateOptionsMode
                ? '<span style="color:#555;font-size:0.85rem">No private folders yet. Link a folder while in this workspace.</span>'
                : '<span style="color:#555;font-size:0.85rem">No persistent folders yet. Newly linked folders appear here.</span>';
            return;
        }

        list.innerHTML = '';
        for (const f of folders) {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:8px 10px;background:rgba(255,255,255,0.03);border:1px solid #333;border-radius:8px;';
            const when = f.lastSyncedAt ? new Date(f.lastSyncedAt).toLocaleString() : '—';
            const perm = await FAFOLibrary.queryPermissionOnly(f.handle);
            const spaceLabel = (f.space === 'private' || privateOptionsMode) ? 'private' : (f.space || 'public');
            row.innerHTML = `
                <span style="flex:1;min-width:140px;color:#eee;font-size:0.85rem;">📁 ${f.name}
                    <span style="color:#666"> · ${f.kind} · ${spaceLabel} · ${f.fileCount ?? '?'} files · ${perm}</span><br>
                    <span style="color:#555;font-size:0.75rem">Last sync: ${when}</span>
                </span>`;
            const resyncBtn = document.createElement('button');
            resyncBtn.className = 'btn btn-ghost small';
            resyncBtn.textContent = '↻ Resync';
            resyncBtn.title = 'Re-scan this saved folder';
            resyncBtn.onclick = async () => {
                try {
                    resyncBtn.disabled = true;
                    resyncBtn.textContent = '…';
                    await FAFOLibrary.ensurePermission(f.handle, 'read');
                    const r = await FAFOLibrary.resyncFolder(db, f.id);
                    showToast(`Resynced “${f.name}” — ${r.count} files`);
                    allLibraryItems = [];
                    await loadLibraryGrid();
                    await refreshLinkedFoldersUI();
                } catch (e) {
                    showToast(e.message || 'Resync failed', 'error');
                } finally {
                    resyncBtn.disabled = false;
                    resyncBtn.textContent = '↻ Resync';
                }
            };
            const unlinkBtn = document.createElement('button');
            unlinkBtn.className = 'btn btn-danger small';
            unlinkBtn.textContent = 'Unlink';
            unlinkBtn.onclick = async () => {
                if (!confirm(`Unlink folder “${f.name}” and remove its indexed files?`)) return;
                try {
                    const storeName = f.storeName || (f.kind === 'photo' ? 'photos' : 'videos');
                    await FAFOLibrary.clearMediaForFolder(db, storeName, f.id);
                    await FAFOLibrary.deleteFolderRecord(db, f.id);
                    showToast(`Unlinked ${f.name}`);
                    allLibraryItems = [];
                    await loadLibraryGrid();
                    await refreshLinkedFoldersUI();
                } catch (e) {
                    showToast(e.message || 'Unlink failed', 'error');
                }
            };
            row.appendChild(resyncBtn);
            row.appendChild(unlinkBtn);
            list.appendChild(row);
        }
    }

    if ($('add-vid-btn')) $('add-vid-btn').onclick = () => addFolder('videos', 'add-vid-btn');
    if ($('add-img-btn')) $('add-img-btn').onclick = () => addFolder('photos', 'add-img-btn');
    if ($('refresh-lib')) $('refresh-lib').onclick = () => {
        showToast('Refreshing Library…');
        allLibraryItems = [];
        loadLibraryGrid();
        refreshLinkedFoldersUI();
    };
    if ($('restore-access-btn')) {
        $('restore-access-btn').onclick = async () => {
            if (!db || !window.FAFOLibrary) return;
            try {
                showToast('Requesting folder permissions…');
                const r = await FAFOLibrary.restoreAccess(db);
                showToast(
                    `Restored: ${r.grantedFolders}/${r.folderCount} folders` +
                        (r.grantedFiles ? `, ${r.grantedFiles} legacy files` : '') +
                        (r.deniedFolders ? ` · ${r.deniedFolders} denied` : '')
                );
                allLibraryItems = [];
                await loadLibraryGrid();
                await refreshLinkedFoldersUI();
            } catch (e) {
                showToast(e.message || 'Restore failed', 'error');
            }
        };
    }
    if ($('resync-all-btn')) {
        $('resync-all-btn').onclick = async () => {
            if (!db || !window.FAFOLibrary) return;
            try {
                showToast('Resyncing all saved folders…');
                await FAFOLibrary.restoreAccess(db);
                const results = await FAFOLibrary.resyncAllFolders(db, { skipPermission: false });
                const ok = results.filter((x) => x.ok);
                const bad = results.filter((x) => !x.ok);
                const total = ok.reduce((s, x) => s + (x.count || 0), 0);
                showToast(
                    bad.length
                        ? `Resynced ${ok.length} folder(s) (${total} files); ${bad.length} failed — Restore Access first`
                        : `Resynced ${ok.length} folder(s) — ${total} files`
                );
                allLibraryItems = [];
                await loadLibraryGrid();
                await refreshLinkedFoldersUI();
            } catch (e) {
                showToast(e.message || 'Resync failed', 'error');
            }
        };
    }
    if ($('wipe-db')) {
        $('wipe-db').onclick = async () => {
            if (!db) return;
            if (!confirm('⚠️ WIPE LIBRARY? Removes files, folders, and playlists.')) return;
            const stores = ['videos', 'photos', 'playlists'];
            if (db.objectStoreNames.contains('folders')) stores.push('folders');
            const tx = db.transaction(stores, 'readwrite');
            stores.forEach((s) => tx.objectStore(s).clear());
            tx.oncomplete = async () => {
                // Explicit wipe — clear playlist/file mirrors in backup storage too
                try {
                    await chrome.storage.local.set({
                        fafoPlaylistsBackup: [],
                        fafoLibraryCatalog: {
                            videos: [], photos: [], folders: [],
                            videoCount: 0, photoCount: 0, exportedAt: Date.now(), wiped: true,
                        },
                    });
                    if (window.FAFOBackup?.afterLiveSave) {
                        await FAFOBackup.afterLiveSave({
                            playlists: [],
                            libraryCatalog: {
                                videos: [], photos: [], folders: [],
                                videoCount: 0, photoCount: 0, exportedAt: Date.now(), wiped: true,
                            },
                            skipIdbEnrich: true,
                        }, 'wipe');
                    }
                } catch (_) {}
                showToast('Library wiped', 'error');
                allLibraryItems = [];
                loadLibraryGrid();
                loadPlaylistsUI();
                refreshLinkedFoldersUI();
            };
        };
    }

    // ─── Private multi-vault + Master PIN (Options) ───────────────────────
    function fmtWhen(ts) {
        if (!ts) return '—';
        try { return new Date(ts).toLocaleString(); } catch { return String(ts); }
    }

    async function refreshPrivateVaultsUi() {
        const PV = window.FAFOPrivateVaults;
        const statusEl = $('pv-master-status');
        const listEl = $('pv-vault-list');
        if (!PV) {
            if (statusEl) statusEl.textContent = 'Vault module missing — reload extension.';
            return;
        }
        const reg = await PV.loadRegistry();
        const master = PV.masterSummary(reg);
        const setupRow = $('pv-master-setup-row');
        const changeRow = $('pv-master-change-row');
        const saveBtn = $('pv-master-save');
        const changeBtn = $('pv-master-change');

        if (statusEl) {
            if (master.hasMaster) {
                statusEl.innerHTML =
                    `Master is <strong style="color:#e9d5ff">SET</strong> · established ${fmtWhen(master.establishedAt)}`
                    + (master.updatedAt && master.updatedAt !== master.establishedAt
                        ? ` · last rotated ${fmtWhen(master.updatedAt)}`
                        : '')
                    + `<br><span style="color:#888">Only vaults created on/after establish time accept Master override.</span>`;
            } else {
                statusEl.textContent =
                    'No Master PIN yet. Existing vaults will never be Master-overrideable once you set Master after them.';
            }
        }
        if (setupRow) setupRow.style.display = master.hasMaster ? 'none' : '';
        if (changeRow) changeRow.style.display = master.hasMaster ? '' : 'none';
        if (saveBtn) {
            saveBtn.style.display = master.hasMaster ? 'none' : '';
            saveBtn.textContent = 'Set Master PIN';
        }
        if (changeBtn) changeBtn.style.display = master.hasMaster ? '' : 'none';

        if (listEl) {
            const summaries = PV.vaultSummaries(reg);
            if (!summaries.length) {
                listEl.innerHTML =
                    '<div style="color:#666;font-size:0.85rem;">No private modes yet — create one below, or set PIN from the new-tab ◈ button.</div>';
            } else {
                listEl.innerHTML = summaries.map((v) => {
                    const badge = v.masterEligible
                        ? '<span style="color:#86efac;font-size:0.75rem;">Master can override</span>'
                        : '<span style="color:#fca5a5;font-size:0.75rem;">Master cannot override (predates Master or no Master)</span>';
                    return `<div class="pv-vault-card" data-vault-id="${v.id}" style="padding:12px;border:1px solid #333;border-radius:10px;background:rgba(192,132,252,0.06);">
                        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;justify-content:space-between;">
                            <div>
                                <strong style="color:#e9d5ff;">◈ ${escapeOpt(v.name)}</strong>
                                <span style="color:#666;font-size:0.75rem;margin-left:8px;">id: ${escapeOpt(v.id)}</span>
                                <div style="color:#888;font-size:0.78rem;margin-top:4px;">Created ${fmtWhen(v.createdAt)} · ${v.hasPin ? 'PIN set' : 'no PIN yet'}</div>
                                <div style="margin-top:4px;">${badge}</div>
                            </div>
                        </div>
                        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;align-items:flex-end;">
                            <div>
                                <label style="font-size:0.7rem;color:#888;">Rename</label>
                                <input type="text" class="pv-rename" data-vault-id="${v.id}" value="${escapeOpt(v.name)}" maxlength="48" style="min-width:120px;" />
                            </div>
                            <button type="button" class="btn btn-ghost pv-rename-btn" data-vault-id="${v.id}" style="width:auto;padding:6px 10px;">Save name</button>
                            <div>
                                <label style="font-size:0.7rem;color:#888;">Current vault PIN</label>
                                <input type="password" class="pv-cur" data-vault-id="${v.id}" autocomplete="current-password" style="min-width:100px;" />
                            </div>
                            <div>
                                <label style="font-size:0.7rem;color:#888;">New PIN</label>
                                <input type="password" class="pv-new" data-vault-id="${v.id}" autocomplete="new-password" style="min-width:100px;" />
                            </div>
                            <div>
                                <label style="font-size:0.7rem;color:#888;">Or Master PIN (if eligible)</label>
                                <input type="password" class="pv-mstr" data-vault-id="${v.id}" autocomplete="current-password" style="min-width:100px;" />
                            </div>
                            <button type="button" class="btn btn-primary pv-change-pin" data-vault-id="${v.id}" style="width:auto;padding:6px 10px;">Change PIN</button>
                        </div>
                        <div class="pv-vault-msg" data-vault-id="${v.id}" style="color:#c084fc;font-size:0.78rem;margin-top:6px;min-height:1em;"></div>
                    </div>`;
                }).join('');

                listEl.querySelectorAll('.pv-rename-btn').forEach((btn) => {
                    btn.addEventListener('click', async () => {
                        const id = btn.dataset.vaultId;
                        const input = listEl.querySelector(`.pv-rename[data-vault-id="${id}"]`);
                        const msg = listEl.querySelector(`.pv-vault-msg[data-vault-id="${id}"]`);
                        const res = await PV.renameVault(id, input?.value || '');
                        if (msg) msg.textContent = res.ok ? `Renamed to “${res.name}”` : (res.error || 'Failed');
                        if (res.ok) showToast(`Vault renamed: ${res.name}`);
                        await refreshPrivateVaultsUi();
                    });
                });
                listEl.querySelectorAll('.pv-change-pin').forEach((btn) => {
                    btn.addEventListener('click', async () => {
                        const id = btn.dataset.vaultId;
                        const cur = listEl.querySelector(`.pv-cur[data-vault-id="${id}"]`)?.value || '';
                        const neu = listEl.querySelector(`.pv-new[data-vault-id="${id}"]`)?.value || '';
                        const mstr = listEl.querySelector(`.pv-mstr[data-vault-id="${id}"]`)?.value || '';
                        const msg = listEl.querySelector(`.pv-vault-msg[data-vault-id="${id}"]`);
                        if (!neu || neu.length < 4) {
                            if (msg) msg.textContent = 'New PIN must be at least 4 characters';
                            return;
                        }
                        const res = await PV.changeVaultPin(id, {
                            newPin: neu,
                            vaultPin: cur || undefined,
                            masterPin: mstr || undefined,
                        });
                        if (msg) {
                            msg.textContent = res.ok
                                ? `PIN changed (via ${res.via})`
                                : (res.error || 'Failed');
                            msg.style.color = res.ok ? '#86efac' : '#fca5a5';
                        }
                        if (res.ok) {
                            showToast('Vault PIN updated');
                            listEl.querySelectorAll(`input[data-vault-id="${id}"]`).forEach((el) => {
                                if (el.classList.contains('pv-rename')) return;
                                el.value = '';
                            });
                        } else {
                            showToast(res.error || 'PIN change failed', 'error');
                        }
                    });
                });
            }
        }
    }

    function escapeOpt(s) {
        return String(s || '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function wirePrivateVaultsUi() {
        const PV = window.FAFOPrivateVaults;
        if (!PV) return;

        $('pv-master-save')?.addEventListener('click', async () => {
            const p1 = $('pv-master-pin')?.value || '';
            const p2 = $('pv-master-pin2')?.value || '';
            const msg = $('pv-master-msg');
            if (p1 !== p2) {
                if (msg) msg.textContent = 'Master PINs do not match';
                showToast('Master PINs do not match', 'error');
                return;
            }
            const res = await PV.setMasterPin(p1);
            if (msg) {
                msg.textContent = res.ok
                    ? (res.note || 'Master PIN set')
                    : (res.error || 'Failed');
                msg.style.color = res.ok ? '#86efac' : '#fca5a5';
            }
            if (res.ok) {
                showToast('Master PIN established');
                if ($('pv-master-pin')) $('pv-master-pin').value = '';
                if ($('pv-master-pin2')) $('pv-master-pin2').value = '';
                await refreshPrivateVaultsUi();
            } else {
                showToast(res.error || 'Failed', 'error');
            }
        });

        $('pv-master-change')?.addEventListener('click', async () => {
            const cur = $('pv-master-current')?.value || '';
            const n1 = $('pv-master-new')?.value || '';
            const n2 = $('pv-master-new2')?.value || '';
            const msg = $('pv-master-msg');
            if (n1 !== n2) {
                if (msg) msg.textContent = 'New Master PINs do not match';
                return;
            }
            const res = await PV.changeMasterPin({ currentPin: cur, newPin: n1 });
            if (msg) {
                msg.textContent = res.ok
                    ? 'Master PIN rotated (override scope unchanged)'
                    : (res.error || 'Failed');
                msg.style.color = res.ok ? '#86efac' : '#fca5a5';
            }
            if (res.ok) {
                showToast('Master PIN changed');
                ['pv-master-current', 'pv-master-new', 'pv-master-new2'].forEach((id) => {
                    if ($(id)) $(id).value = '';
                });
                await refreshPrivateVaultsUi();
            } else {
                showToast(res.error || 'Failed', 'error');
            }
        });

        $('pv-create-vault')?.addEventListener('click', async () => {
            const name = $('pv-new-name')?.value || '';
            const p1 = $('pv-new-pin')?.value || '';
            const p2 = $('pv-new-pin2')?.value || '';
            const msg = $('pv-create-msg');
            if (p1 !== p2) {
                if (msg) msg.textContent = 'PINs do not match';
                showToast('PINs do not match', 'error');
                return;
            }
            const res = await PV.createVault({ name, pin: p1 });
            if (msg) {
                msg.textContent = res.ok
                    ? `Created “${res.vault.name}” — unlock from new tab ◈`
                    : (res.error || 'Failed');
                msg.style.color = res.ok ? '#86efac' : '#fca5a5';
            }
            if (res.ok) {
                showToast(`Private mode “${res.vault.name}” created`);
                if ($('pv-new-name')) $('pv-new-name').value = '';
                if ($('pv-new-pin')) $('pv-new-pin').value = '';
                if ($('pv-new-pin2')) $('pv-new-pin2').value = '';
                await refreshPrivateVaultsUi();
            } else {
                showToast(res.error || 'Failed', 'error');
            }
        });

        // Refresh list when opening the tab
        document.querySelectorAll('.tab').forEach((tab) => {
            tab.addEventListener('click', () => {
                if (tab.dataset.target === 'view-private-vaults') {
                    refreshPrivateVaultsUi().catch(() => {});
                }
            });
        });
    }

    loadSettings().then(async () => {
        // Discreet private Options when new-tab private mode is active
        await refreshPrivateOptionsMode();
        await refreshLinkedFoldersUI();
        try {
            wirePrivateVaultsUi();
            await refreshPrivateVaultsUi();
        } catch (e) {
            console.warn('private vaults ui', e);
        }
        if (!privateOptionsMode && window.FAFOBackup?.tryRecoverEmptyLive) {
            await FAFOBackup.tryRecoverEmptyLive();
        }
        if (!privateOptionsMode && window.FAFOPairs) {
            await FAFOPairs.init({
                db,
                showToast,
                generateThumbnail: (file, seek) => generateThumbnail(file, seek),
            });
        }
        if (!privateOptionsMode && window.FAFOBackup) refreshTagsBackupUI();
        if (!privateOptionsMode) {
            wireChromeArtUi();
            wireVisualFxUi();
        }
        try {
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local') return;
                if (changes.fafoPrivateSession) {
                    refreshPrivateOptionsMode().catch(() => {});
                }
            });
        } catch (_) {}
        // Esc Esc → exit private options (and private session)
        document.addEventListener('keydown', (e) => {
            if (e.key !== 'Escape' && e.key !== 'Esc') return;
            if (!privateOptionsMode) {
                escapeTapAt = 0;
                return;
            }
            const now = Date.now();
            if (now - escapeTapAt < 700) {
                escapeTapAt = 0;
                e.preventDefault();
                exitPrivateOptionsMode();
            } else {
                escapeTapAt = now;
                showToast('Press Escape again to exit private workspace');
            }
        }, true);
    });
});