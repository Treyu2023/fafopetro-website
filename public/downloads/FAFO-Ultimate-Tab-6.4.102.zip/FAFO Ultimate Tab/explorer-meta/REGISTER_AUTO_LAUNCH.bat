@echo off
setlocal EnableExtensions
title FAFO — register auto-launch
cd /d "%~dp0"

set QUIET=0
if /I "%~1"=="/quiet" set QUIET=1

echo.
echo  Register FAFO companion auto-launch
echo  ----------------------------------
echo  Copies the tagger to a space-free folder
echo  (%%LOCALAPPDATA%%\FAFO\ExplorerMeta), then:
echo    • Protocol  fafo-companion://boot
echo    • Windows Startup (hidden)
echo    • Chrome native messaging when the extension ID is known
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Launch-ExplorerMeta.ps1" %*
set ERR=%ERRORLEVEL%
if not "%ERR%"=="0" (
  echo  [WARN] Launcher returned %ERR%. Python may be missing — run INSTALL_DEPS.bat.
) else (
  echo  [OK] Protocol, Startup, and supervisor registered.
  echo  Open a FAFO new tab — Disk writes start without a separate server window.
)

echo.
if not "%QUIET%"=="1" pause
exit /b %ERR%
