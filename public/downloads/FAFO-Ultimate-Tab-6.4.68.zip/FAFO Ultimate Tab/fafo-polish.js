/**
 * FAFO polish — status chips + small UX glue (stand-out pass E).
 */
(function (global) {
  'use strict';

  function ensureChips() {
    let el = document.getElementById('fafo-status-chips');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'fafo-status-chips';
    el.innerHTML = `
      <button type="button" class="fafo-chip btn" data-act="cmd" data-fafo-tip="cmd.palette" title="Command palette">⌘K</button>
      <button type="button" class="fafo-chip btn" data-act="undo" data-fafo-tip="tag.undo" title="Back · undo last tag/rating (up to 50)">Back</button>
      <button type="button" class="fafo-chip btn" data-act="resume" data-fafo-tip="session.resume" title="Resume last session">Resume</button>
      <button type="button" class="fafo-chip btn" data-act="doctor" data-fafo-tip="lib.doctor" title="Library doctor">Doctor</button>
      <button type="button" class="fafo-chip btn" data-act="theme" data-fafo-tip="tag.themes" title="Cycle tag theme">Theme</button>
      <button type="button" class="fafo-chip btn" data-act="guide" title="F1 · help for this screen (contextual guide)">Help</button>
      <button type="button" class="fafo-chip btn" data-act="guide-all" title="Full knowledge guide (all topics)">Guide</button>
      <span class="fafo-chip" id="fafo-chip-theme">Theme</span>
      <span class="fafo-chip" id="fafo-chip-s2" data-fafo-tip="srv.s1-s2">S2 …</span>
    `;
    document.body.appendChild(el);
    el.querySelectorAll('[data-act]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const a = btn.getAttribute('data-act');
        if (a === 'cmd') global.FAFOCommandPalette?.open?.();
        if (a === 'undo') global.FAFOUndo?.undo?.();
        if (a === 'resume') global.FAFOSession?.resumeNow?.();
        if (a === 'doctor') global.FAFOLibraryDoctor?.open?.();
        if (a === 'guide') global.FAFOHelp?.summon?.() || global.FAFOKnowledge?.openGuide?.();
        if (a === 'guide-all') global.FAFOHelp?.summon?.({ all: true }) || global.FAFOKnowledge?.openGuide?.();
        if (a === 'theme') {
          const p = global.FAFOTagThemes?.cycle?.();
          const t = document.getElementById('fafo-chip-theme');
          if (t && p) t.textContent = p.name;
        }
      });
    });
    try { global.FAFOKnowledge?.applyTooltips?.(el); } catch (_) {}
    return el;
  }

  async function refreshS2() {
    const chip = document.getElementById('fafo-chip-s2');
    if (!chip) return;
    try {
      const r = await fetch('http://127.0.0.1:8765/api/health', { signal: AbortSignal.timeout(1500) });
      if (r.ok) {
        chip.textContent = 'S2 on';
        chip.className = 'fafo-chip ok';
      } else {
        chip.textContent = 'S2 bad';
        chip.className = 'fafo-chip bad';
      }
    } catch {
      chip.textContent = 'S2 off';
      chip.className = 'fafo-chip warn';
    }
  }

  function refreshThemeChip() {
    const t = document.getElementById('fafo-chip-theme');
    const p = global.FAFOTagThemes?.current?.();
    if (t && p) t.textContent = p.name;
  }

  function patchHelp() {
    const panel = document.querySelector('#shortcut-help .shortcut-panel');
    if (!panel || panel.dataset.polishHelp) return;
    panel.dataset.polishHelp = '1';
    const extra = document.createElement('div');
    extra.innerHTML = `
      <p style="margin-top:10px;border-top:1px solid rgba(255,255,255,0.08);padding-top:8px;"><kbd>Ctrl</kbd>+<kbd>K</kbd> or <kbd>/</kbd> Command palette</p>
      <p><kbd>Ctrl</kbd>+<kbd>Z</kbd> or <strong>↩ Back</strong> — undo last 50 tag/rating changes</p>
      <p><strong>Select</strong> / <kbd>Ctrl</kbd>+click tags — multi-edit · <strong>All</strong> = visible</p>
      <p><kbd>Ctrl</kbd>+<kbd>K</kbd> → <strong>Show Up next strip</strong> if you hid the previews</p>
      <p>Top chips: Resume · Doctor · Theme · S2</p>
      <p>Bottom: <strong>Up next</strong> strip — click to jump</p>
    `;
    panel.insertBefore(extra, panel.querySelector('#help-close'));
  }

  function init() {
    ensureChips();
    refreshThemeChip();
    refreshS2();
    setInterval(refreshS2, 20000);
    setTimeout(patchHelp, 800);
    document.addEventListener('fafo:tag-theme', refreshThemeChip);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.FAFOPolish = { refreshS2, refreshThemeChip };
})(typeof window !== 'undefined' ? window : globalThis);
