/**
 * FAFO on-play tags & star ratings (+ optional Explorer write via localhost:8765)
 * Tag list order: library frequency seed → after first apply this session, session counts win.
 * Loaded after script.js core; hooks into window.FAFOPlayer hooks when available.
 * 6.4.89: Corner Disk LED + tags panel no longer covers top chips/clock.
 * 6.4.75: Salvage ledger JSON for Explorer writes (pending until confirmed on disk).
 * 6.4.74: One random intro clip, faster splash, 1080p promo surface, preload on tab open.
 * 6.4.73: Fast Tag renamed Graffiti Speed Tagging (user-facing).
 * 6.4.72: Fast Tag length / FPS / resolution / size / aspect filter dropdowns with counts.
 * 6.4.71: Fast Tag marquee / Ctrl / Shift multi-select with confirm-to-apply.
 * 6.4.70: Fast Tag create-tag + public/private lists (private chips first; right-click assigns list).
 * 6.4.69: Fast Tag full-library click-to-tag grid (fast-tag.html).
 * 6.4.68: junk-tag filter restored, apply+next keeps focus, honest Explorer badge, smarter autocomplete.
 */
(function () {
    'use strict';

    const TOOLBOX_API = 'http://127.0.0.1:8765/api';

    let mediaMeta = {};
    let tagLibrary = [];       // display names; ordered by count (see sortTagLibrary)
    let tagLastUsed = {};      // kept for compat / secondary tie-break only
    let libraryTagCount = {};  // lower(tag) -> how many library files have this tag (seed)
    /** lower(tag) -> times applied (persisted across reloads; was session-only). */
    let sessionTagCount = {};
    let sessionHasPicks = false; // true once any apply count exists (drives session sort)
    /** 'session' | 'total' — sort + primary ranking; apply-count badges always on tiles */
    let countDisplayMode = 'session';
    /** Clips touched (tag/rating) this browser session — live tracker */
    let sessionVideosTouched = new Set();
    /** Tag apply events this session (not unique names) */
    let sessionApplyEvents = 0;
    let liveStatsTimer = null;
    let countSaveTimer = null;
    let libraryRecountTimer = null;
    let renderLibraryTimer = null;
    /** When true, applying a tag immediately advances to next (bulk tagging). */
    let applyAndNextMode = false;
    let recentTags = []; // last applied tag names (display order)
    let explorerOnline = null; // null=unknown, true/false
    let companionBootFails = 0;
    let explorerPollTimer = null;
    /** Last Explorer write: null=none yet, true=ok, false=failed (badge must not lie). */
    let explorerWriteOk = null;
    let explorerWriteNote = '';
    /**
     * Hotkey matrix: 10 always-visible slots (keys 1–9, 0) × 4 modifier banks.
     * Banks: 0=base, 1=Shift, 2=Shift+Ctrl, 3=Shift+Ctrl+Alt  → 40 assignable tags.
     * Holding modifiers swaps the 10 on-screen buttons in real time.
     */
    const HOTKEY_SLOTS = 10;
    const HOTKEY_BANKS = 4;
    const BANK_LABELS = ['Base', 'Shift', 'Ctrl', 'Alt'];
    const BANK_SHORT = ['', '⇧', '⌃', '⌥'];
    let tagHotkeys = emptyHotkeyBanks(); // user-assigned only — persisted
    /**
     * Session-only auto quick-select fills for empty user slots.
     * Never written to chrome.storage — gone after tab/extension restart.
     */
    let sessionAutoHotkeys = emptyHotkeyBanks();
    /** Tags in order of first apply this session (drives auto-fill). */
    let sessionFirstUsedOrder = [];
    /** After "Clear auto", don't refill until user turns auto back on. */
    let sessionAutoHotkeysPaused = false;
    let liveBank = 0; // currently displayed bank
    /** Sticky bank selected via Tab / bank chips; modifiers temporarily override. */
    let pinnedBank = 0;
    let activeKey = null;
    let activeName = '';
    let activeTags = [];
    let activeRating = 0;
    /** Tags that were on the previous clip (breathing gold highlight). */
    let lastVideoTags = [];
    let prevBindKey = null;
    /** Live typeahead filter from the Add-tag field — narrows library/hotkeys/E-set/recent. */
    let liveTypeFilter = '';
    /** Sprint Tag mode: 5 quick tags + rating runway, untagged-first order. */
    let sprintModeOpen = false;
    let sprintTags = ['', '', '', '', ''];
    let suggestIndex = -1;
    let metaPanelOpen = false;
    let bracketChord = false;
    let bracketTimer = null;
    let ctxMenu = null;
    let els = {};
    /** Multi-select tag names for bulk edit (display names; keys = lower). */
    let multiSelectMode = false;
    /** @type {Map<string, string>} lower -> display name */
    const selectedTags = new Map();
    /** Last rendered library list (display order) for shift-range select. */
    let lastVisibleTagList = [];
    let lastClickedSelectLow = '';
    /** When true, player skips clips that already have tags (then 5+ tags). */
    let skipTaggedMode = false;
    let tagLibraryHeight = 160;
    let panelWidth = 0;
    let panelHeight = 0;
    let resizeDragging = false;
    /** User-hidden tags (still stored on files if already applied; hidden from quick panel lists). */
    let excludedTags = [];
    /**
     * Which menus a tag appears in.
     * public (default) = normal menu only. hidden = hidden menu only. both = both menus.
     * lowercased tag -> 'hidden' | 'both'. Missing key means public.
     */
    let tagMenuScope = {};
    /** Side/under layout is pinning the tags column. Corner dock stays remembered. */
    let stageDockPinned = false;
    /**
     * Private multi-vault (PIN) — fully separate from public tags/media.
     * When locked: private tags + private media never appear in public UI/search/playback.
     * When unlocked + privateSpaceActive: only the ACTIVE vault's tags/media are shown.
     * Multiple vaults each have their own PIN + storage keys. Optional Master PIN can
     * override only vaults created after master was first established (no retroactive backdoor).
     */
    let privateUnlocked = false;       // session only — never persisted
    let privateSpaceActive = false;    // viewing a private vault
    let activeVaultId = null;          // which private vault is open (null = public)
    let activeVaultName = '';
    /** @deprecated legacy vault list fields — kept for migration / soft markers */
    let privatePinHash = '';
    let privatePinSalt = '';
    let privateTags = [];
    let privateMediaKeys = [];
    /**
     * Dual tag/meta libraries: public keys vs per-vault private keys in chrome.storage.
     * EVERY list that can show tag names or ratings must be space-scoped so
     * secret-mode content never appears in normal mode (and vice versa).
     */
    const SPACE_STORAGE = {
        public: (globalThis.FAFOPrivateVaults?.publicStorageKeys?.() || {
            mediaMeta: 'fafoMediaMeta',
            tagLibrary: 'fafoTagLibrary',
            tagLastUsed: 'fafoTagLastUsed',
            tagHotkeys: 'fafoTagHotkeys',
            tagExcluded: 'fafoTagExcluded',
            tagMenuScope: 'fafoTagMenuScope',
            recentTags: 'fafoRecentTags',
            applyCounts: 'fafoTagApplyCounts',
            extraBanks: 'fafoExtraTagBanks',
            sprintTags: 'fafoSprintTags',
            pairs: 'fafoPairs',
            tagColors: 'fafoTagColors',
            tagDb: 'fafoTagDb',
        }),
        /** Legacy default vault keys — multi-vault uses privateStorageKeys(id) */
        private: (globalThis.FAFOPrivateVaults?.privateStorageKeys?.('default') || {
            mediaMeta: 'fafoMediaMetaPrivate',
            tagLibrary: 'fafoTagLibraryPrivate',
            tagLastUsed: 'fafoTagLastUsedPrivate',
            tagHotkeys: 'fafoTagHotkeysPrivate',
            tagExcluded: 'fafoTagExcludedPrivate',
            tagMenuScope: 'fafoTagMenuScopePrivate',
            recentTags: 'fafoRecentTagsPrivate',
            applyCounts: 'fafoTagApplyCountsPrivate',
            extraBanks: 'fafoExtraTagBanksPrivate',
            sprintTags: 'fafoSprintTagsPrivate',
            pairs: 'fafoPairsPrivate',
            tagColors: 'fafoTagColorsPrivate',
            tagDb: 'fafoTagDbPrivate',
        }),
    };
    /** All private-only storage key names (for backup strip / safety). */
    const PRIVATE_STORAGE_KEY_SET = new Set(Object.values(SPACE_STORAGE.private));
    function spaceKeys() {
        if (!privateSpaceActive) {
            return globalThis.FAFOPrivateVaults?.publicStorageKeys?.() || SPACE_STORAGE.public;
        }
        const vid = activeVaultId || globalThis.FAFOPrivateVaults?.DEFAULT_VAULT_ID || 'default';
        return globalThis.FAFOPrivateVaults?.privateStorageKeys?.(vid) || SPACE_STORAGE.private;
    }
    function currentVaultId() {
        return activeVaultId || globalThis.FAFOPrivateVaults?.DEFAULT_VAULT_ID || 'default';
    }

    /**
     * Wipe in-memory session UI that is rebuilt from the active space.
     * Prevents public quick-select / suggestions from bleeding into secret mode.
     */
    function clearSessionSpaceBuffers() {
        sessionAutoHotkeys = emptyHotkeyBanks();
        sessionAutoExtra = emptyExtraBanks();
        sessionFirstUsedOrder = [];
        libraryTagCount = {};
        sessionTagCount = {};
        sessionHasPicks = false;
        suggestIndex = -1;
        try { hideSuggestions(); } catch (_) { /* ignore */ }
        try { selectedTags.clear(); } catch (_) { /* ignore */ }
        // Never leave the other mode's active chip set on screen
        activeTags = [];
        activeRating = 0;
        activeKey = null;
        activeName = '';
        activePairId = '';
    }

    /**
     * Hard wipe of ALL space-scoped in-memory stores (sync, before any await).
     * Private and public never share tag lists, counts, hotkeys, or media meta in RAM.
     */
    function wipeInMemorySpaceData() {
        clearSessionSpaceBuffers();
        mediaMeta = {};
        tagLibrary = [];
        tagLastUsed = {};
        tagHotkeys = emptyHotkeyBanks();
        excludedTags = [];
        tagMenuScope = {};
        recentTags = [];
        extraTagBanks = emptyExtraBanks();
        sprintTags = ['', '', '', '', ''];
        lastVideoTags = [];
        prevBindKey = null;
    }

    /** After hydrating a space: rebuild counts + auto quick-select from THIS space only. */
    function reseedSessionAutosForActiveSpace() {
        rebuildLibraryTagCounts();
        try {
            if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
            else updateHotkeyAutoClearBtn();
        } catch (_) { /* ignore */ }
        try {
            if (!sessionAutoExtraPaused) refillSessionAutoExtra();
            else updateExtraAutoUi();
        } catch (_) { /* ignore */ }
    }
    /** Pair id for current clip (separate field — not a chip). */
    let activePairId = '';
    /**
     * Two independent windows by default:
     * - Quick panel (rating/tags) free-floats
     * - Tag history free-floats (split) — not docked under the other
     */
    let dockPos = 'free';
    let dockX = 18;
    let dockY = 18;
    /** Tag history floating panel position/size (sticky when free). */
    let libX = 18;
    let libY = 80;
    let libW = 380;
    let libH = 560;
    let libPosSaved = false; // true once user moved/resized history panel
    /** When true, free positions never auto-snap (scale/open/sync won't move them). */
    let stickLayout = true;
    /**
     * E-set: separate from hotkey quick tags.
     * 10 slots × 4 modifier banks (Base / Shift / Ctrl+Shift / Alt+Ctrl+Shift).
     * Press E (with modifiers) to apply the whole bank to the current clip.
     */
    const EXTRA_SLOTS = 10;
    const EXTRA_BANKS = 4;
    const EXTRA_BANK_LABELS = ['Base', '⇧ Shift', '⌃ Ctrl', '⌥ Alt'];
    /** User-assigned E-set only — persisted. Auto fills live underneath empty slots. */
    let extraTagBanks = emptyExtraBanks();
    /**
     * Session auto-fill for E-set (not chrome.storage).
     * Bank 0 = most frequent this run → later banks = less frequent / newer (last page).
     */
    let sessionAutoExtra = emptyExtraBanks();
    /** After clear, don't auto-refill E-set until re-enabled. */
    let sessionAutoExtraPaused = false;
    let extraLiveBank = 0;
    let extraPinnedBank = 0;
    /** UI / tags scale. Same 25%–400% range as video zoom. Size is not shrunk to fit the window. */
    const UI_SCALES = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 2, 2.5, 3, 4];
    const UI_SCALE_MIN = 0.25;
    const UI_SCALE_MAX = 4;
    const DEFAULT_UI_SCALE = 1;
    let uiScale = DEFAULT_UI_SCALE;
    let dockDragging = false;
    let dockDragOffX = 0;
    let dockDragOffY = 0;
    let libDragging = false;
    let edgeResizing = false;
    let layoutSaveTimer = null;
    /** When split, library is portaled to <body> so CSS transform on #meta-dock cannot trap it. */
    let libHomeParent = null;
    let libHomeNext = null;
    let settingsSaveTimer = null;
    /**
     * Layout memory (6.4.23+):
     * - Preferred panel sizes survive temporary viewport shrinks (lock only clamps live CSS).
     * - Dual slots: windowed vs fullscreen so TV/FS doesn't clobber desktop placement.
     * - Normalized coords (0–1) + last viewport size for proportional restore after resize/zoom.
     */
    let layoutVpW = 0;
    let layoutVpH = 0;
    let layoutModeActive = 'windowed';
    let layoutMemorySlots = { windowed: null, fullscreen: null };
    let layoutMemoryBootstrapped = false;
    let preferredPanelW = 0;
    let preferredPanelH = 0;

    function emptyHotkeyBanks() {
        return Array.from({ length: HOTKEY_BANKS }, () => Array(HOTKEY_SLOTS).fill(''));
    }

    function emptyExtraBanks() {
        return Array.from({ length: EXTRA_BANKS }, () => Array(EXTRA_SLOTS).fill(''));
    }

    function normalizeExtraBanks(raw) {
        const banks = emptyExtraBanks();
        if (!raw) return banks;
        if (Array.isArray(raw) && raw.length && Array.isArray(raw[0])) {
            for (let b = 0; b < EXTRA_BANKS; b++) {
                const row = raw[b];
                if (!Array.isArray(row)) continue;
                for (let s = 0; s < EXTRA_SLOTS; s++) {
                    banks[b][s] = normalizeTag(row[s] || '');
                }
            }
            return banks;
        }
        // Flat list of up to 10 (legacy / single bank)
        if (Array.isArray(raw) && (raw.length === 0 || typeof raw[0] === 'string')) {
            for (let s = 0; s < Math.min(EXTRA_SLOTS, raw.length); s++) {
                banks[0][s] = normalizeTag(raw[s] || '');
            }
            return banks;
        }
        return banks;
    }

    /** Migrate old 5-slot arrays into the new bank matrix. */
    function normalizeHotkeyBanks(raw) {
        const banks = emptyHotkeyBanks();
        if (!raw) return banks;
        // Nested banks: [4][10] or [4][5+]
        if (Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0])) {
            for (let b = 0; b < HOTKEY_BANKS; b++) {
                const row = raw[b];
                if (!Array.isArray(row)) continue;
                for (let s = 0; s < HOTKEY_SLOTS; s++) {
                    banks[b][s] = normalizeTag(row[s] || '');
                }
            }
            return banks;
        }
        // Flat list of strings (legacy 5, or 10, or 40)
        if (Array.isArray(raw) && (raw.length === 0 || typeof raw[0] === 'string')) {
            if (raw.length >= HOTKEY_BANKS * HOTKEY_SLOTS) {
                for (let b = 0; b < HOTKEY_BANKS; b++) {
                    for (let s = 0; s < HOTKEY_SLOTS; s++) {
                        banks[b][s] = normalizeTag(raw[b * HOTKEY_SLOTS + s] || '');
                    }
                }
            } else {
                // Legacy base bank only (first 5 or 10)
                for (let s = 0; s < Math.min(HOTKEY_SLOTS, raw.length); s++) {
                    banks[0][s] = normalizeTag(raw[s] || '');
                }
            }
            return banks;
        }
        return banks;
    }

    /**
     * Modifier → bank (hotkeys + E-set share this).
     * Priority: Alt → bank 3, Ctrl → bank 2, Shift → bank 1, none → base.
     * (Ctrl/Alt alone work; Shift is not required to reach banks 2–3.)
     */
    function bankFromMods(shift, ctrl, alt) {
        if (alt) return 3;
        if (ctrl) return 2;
        if (shift) return 1;
        return 0;
    }

    function bankFromEvent(e) {
        return bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
    }

    function digitToSlot(key) {
        if (key === '0') return 9;
        if (key >= '1' && key <= '9') return parseInt(key, 10) - 1;
        return -1;
    }

    function slotToDigit(slot) {
        return slot === 9 ? '0' : String(slot + 1);
    }

    function formatHotkeyLabel(bank, slot) {
        return `${BANK_SHORT[bank] || ''}${slotToDigit(slot)}`;
    }

    /** User-assigned hotkey only (persisted). */
    function getUserHotkey(bank, slot) {
        return tagHotkeys[bank]?.[slot] || '';
    }

    /** Effective hotkey: user pick wins; else session auto-fill. */
    function getHotkey(bank, slot) {
        const user = getUserHotkey(bank, slot);
        if (user) return user;
        return sessionAutoHotkeys[bank]?.[slot] || '';
    }

    function isAutoHotkey(bank, slot) {
        return !getUserHotkey(bank, slot) && !!(sessionAutoHotkeys[bank]?.[slot]);
    }

    function setHotkey(bank, slot, tag) {
        if (!tagHotkeys[bank]) tagHotkeys[bank] = Array(HOTKEY_SLOTS).fill('');
        tagHotkeys[bank][slot] = normalizeTag(tag || '');
        // User owns this slot — drop any auto marker underneath
        if (sessionAutoHotkeys[bank]) sessionAutoHotkeys[bank][slot] = '';
    }

    function clearTagFromAllHotkeys(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return;
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    tagHotkeys[b][s] = '';
                }
                if (sessionAutoHotkeys[b]?.[s] && sessionAutoHotkeys[b][s].toLowerCase() === low) {
                    sessionAutoHotkeys[b][s] = '';
                }
            }
        }
    }

    function anyHotkeyAssigned() {
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (getHotkey(b, s)) return true;
            }
        }
        return false;
    }

    function anyAutoHotkeys() {
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (isAutoHotkey(b, s)) return true;
            }
        }
        return false;
    }

    /**
     * Remember first-used tags this session (order kept for ties / history).
     * Auto-fill ranking uses session apply counts, not first-used alone.
     */
    function noteSessionFirstUsed(tags) {
        const list = Array.isArray(tags) ? tags : [tags];
        let added = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            if (typeof isHiddenFromUi === 'function' && isHiddenFromUi(t)) return;
            const low = t.toLowerCase();
            if (sessionFirstUsedOrder.some((x) => x.toLowerCase() === low)) return;
            sessionFirstUsedOrder.push(t);
            added = true;
        });
        if (added || !sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
        if (added || !sessionAutoExtraPaused) refillSessionAutoExtra();
    }

    /**
     * Rank tags for auto quick-select: highest session Uses first, then library total.
     * User-programmed hotkeys are never overwritten and never repeated into auto slots.
     */
    /**
     * @param {Set|null} reservedLow
     * @param {{ includeZero?: boolean }} [opts]  includeZero: keep zero-use tags (for filling later E-set pages)
     */
    function rankedTagsForAutoFill(reservedLow, opts = {}) {
        const reserved = reservedLow instanceof Set ? reservedLow : new Set();
        const includeZero = !!opts.includeZero;
        const seen = new Set();
        const rows = [];
        const consider = (raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            // Never auto-fill from the other section's vocabulary
            if (typeof isTagInCurrentSpace === 'function' && !isTagInCurrentSpace(t)) return;
            if (typeof isHiddenFromUi === 'function' && isHiddenFromUi(t)) return;
            if (typeof isHiddenOnlyTag === 'function' && isHiddenOnlyTag(t)) return;
            const low = t.toLowerCase();
            if (!low || reserved.has(low) || seen.has(low)) return;
            seen.add(low);
            const sc = sessionTagCount[low] || 0;
            const lc = libraryTagCount[low] || 0;
            const firstIdx = sessionFirstUsedOrder.findIndex((x) => x.toLowerCase() === low);
            rows.push({
                tag: t,
                low,
                sc,
                lc,
                firstIdx: firstIdx >= 0 ? firstIdx : 99999,
            });
        };
        // Prefer known vocabulary + anything with apply counts
        tagLibrary.forEach(consider);
        Object.keys(sessionTagCount || {}).forEach(consider);
        Object.keys(libraryTagCount || {}).forEach(consider);
        sessionFirstUsedOrder.forEach(consider);

        rows.sort((a, b) => {
            // Session Uses (apply counts) first when any exist
            if (sessionHasPicks) {
                if (b.sc !== a.sc) return b.sc - a.sc;
            }
            if (b.lc !== a.lc) return b.lc - a.lc;
            // Older first-used earlier; newer later (last page)
            if (a.firstIdx !== b.firstIdx) return a.firstIdx - b.firstIdx;
            return a.tag.localeCompare(b.tag, undefined, { sensitivity: 'base' });
        });
        // Drop zero-score noise when we have real session use (hotkeys)
        // E-set passes includeZero so later pages still populate with library/newer tags
        if (sessionHasPicks && !includeZero) {
            const withUse = rows.filter((r) => r.sc > 0);
            if (withUse.length) return withUse;
        }
        return rows;
    }

    /**
     * Fill every empty (non-user) slot across all banks from highest session use.
     * - User-assigned slots stay locked forever until user clears them
     * - No tag is repeated across banks/slots while auto-filling
     * - Re-ranks whenever session use changes (tags move up/down the list)
     * Auto fills are memory-only (not chrome.storage).
     */
    function refillSessionAutoHotkeys() {
        if (sessionAutoHotkeysPaused) {
            updateHotkeyAutoClearBtn();
            return;
        }
        sessionAutoHotkeys = emptyHotkeyBanks();

        // Reserved = user-programmed selections (never auto, never duplicated)
        const reserved = new Set();
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                const u = normalizeTag(tagHotkeys[b]?.[s] || '').toLowerCase();
                if (u) reserved.add(u);
            }
        }

        const ranked = rankedTagsForAutoFill(reserved);
        let ri = 0;
        // Walk banks → slots so Base fills first, then Shift, Ctrl, Alt
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b]?.[s]) continue; // user selection — leave alone
                while (ri < ranked.length && reserved.has(ranked[ri].low)) ri++;
                if (ri >= ranked.length) break;
                const pick = ranked[ri++];
                sessionAutoHotkeys[b][s] = pick.tag;
                reserved.add(pick.low);
            }
        }
        updateHotkeyAutoClearBtn();
        // Keep E-set pages in sync with the same session ranking
        if (!sessionAutoExtraPaused) refillSessionAutoExtra();
    }

    /**
     * Auto-fill every empty E-set slot across all 4 pages (40 slots).
     * Page 1 (Base) = most frequent this run; last page = less frequent / newer.
     * User-assigned E-set slots stay locked; no tag repeated across E-set.
     */
    function refillSessionAutoExtra() {
        if (sessionAutoExtraPaused) {
            updateExtraAutoUi();
            return;
        }
        sessionAutoExtra = emptyExtraBanks();
        const reserved = new Set();
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                const u = normalizeTag(extraTagBanks[b]?.[s] || '').toLowerCase();
                if (u) reserved.add(u);
            }
        }
        // Full pool: high session use first → library → older first-used → newer last (last page)
        const pool = rankedTagsForAutoFill(reserved, { includeZero: true });
        let ri = 0;
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                if (extraTagBanks[b]?.[s]) continue;
                while (ri < pool.length && reserved.has(pool[ri].low)) ri++;
                if (ri >= pool.length) break;
                const pick = pool[ri++];
                sessionAutoExtra[b][s] = pick.tag;
                reserved.add(pick.low);
            }
        }
        updateExtraAutoUi();
    }

    function clearSessionAutoExtra() {
        sessionAutoExtra = emptyExtraBanks();
        sessionAutoExtraPaused = true;
        updateExtraAutoUi();
        renderExtraTagHud();
        if (els.status) {
            els.status.textContent = 'E-set auto cleared (session) — user slots stay · click Auto E-set to refill';
        }
    }

    function enableSessionAutoExtra() {
        sessionAutoExtraPaused = false;
        refillSessionAutoExtra();
        renderExtraTagHud();
        if (els.status) {
            els.status.textContent = 'E-set auto-fill: page 1 = most used this run · last page = newer / less used';
        }
    }

    function anyAutoExtra() {
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                if (isAutoExtra(b, s)) return true;
            }
        }
        return false;
    }

    function updateExtraAutoUi() {
        const btn = $('meta-eset-auto-btn') || $('hud-eset-auto');
        if (!btn) return;
        const hasAuto = anyAutoExtra();
        if (sessionAutoExtraPaused && !hasAuto) {
            btn.textContent = 'Auto E-set';
            btn.title = 'Fill all E-set pages by session frequency · page 1 most used · last page newer · user slots locked';
            btn.classList.remove('active');
            btn.dataset.mode = 'fill';
        } else {
            btn.textContent = hasAuto ? 'Clear E auto' : 'Clear E auto';
            btn.title = 'Clear auto-filled E-set slots (teal). User-assigned slots stay.';
            btn.classList.toggle('active', hasAuto);
            btn.dataset.mode = 'clear';
        }
    }

    function clearSessionAutoHotkeys() {
        sessionAutoHotkeys = emptyHotkeyBanks();
        sessionAutoHotkeysPaused = true;
        updateHotkeyAutoClearBtn();
        renderHotkeyBar();
        if (els.status) {
            els.status.textContent = 'Auto quick-select cleared (session only — won’t return until Auto-fill)';
        }
    }

    function enableSessionAutoHotkeys() {
        sessionAutoHotkeysPaused = false;
        refillSessionAutoHotkeys();
        renderHotkeyBar();
        if (els.status) {
            els.status.textContent = anyAutoHotkeys()
                ? 'Auto quick-select ranked by session Uses (teal · user slots stay locked)'
                : 'Auto-fill on — empty slots fill by highest session use (no repeats)';
        }
    }

    function updateHotkeyAutoClearBtn() {
        const btn = $('meta-hotkey-clear-auto');
        if (!btn) return;
        const hasAuto = anyAutoHotkeys();
        if (sessionAutoHotkeysPaused && !hasAuto) {
            btn.textContent = 'Auto-fill';
            btn.title = 'Fill empty slots by highest session Uses · user-programmed slots stay · no repeats · teal = auto';
            btn.classList.remove('active');
            btn.dataset.mode = 'fill';
        } else {
            btn.textContent = hasAuto ? 'Clear auto' : 'Clear auto';
            btn.title = 'Clear auto-filled quick tags (teal). User hotkeys stay. Re-ranks as you tag.';
            btn.classList.toggle('active', hasAuto);
            btn.dataset.mode = 'clear';
            if (!hasAuto && !sessionAutoHotkeysPaused) {
                btn.textContent = 'Clear auto';
                btn.title = 'No auto tags right now · user hotkeys stay until you change them';
            }
        }
    }

    function syncLiveBank(e) {
        // Held modifiers temporarily override the pinned bank; otherwise use pin
        let bank = pinnedBank;
        if (e && (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey)) {
            bank = bankFromEvent(e);
        }
        if (bank === liveBank) return;
        liveBank = bank;
        renderHotkeyBar();
        updateBankIndicator();
    }

    /** Tab cycles Base → Shift → Shift+Ctrl → Shift+Ctrl+Alt → Base … */
    function cycleHotkeyBank(dir = 1) {
        pinnedBank = (pinnedBank + dir + HOTKEY_BANKS) % HOTKEY_BANKS;
        liveBank = pinnedBank;
        renderHotkeyBar();
        updateBankIndicator();
        if (els.status) {
            els.status.textContent = `Hotkey bank: ${BANK_LABELS[pinnedBank]} (Tab to cycle)`;
        }
    }

    function $(id) { return document.getElementById(id); }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function escapeAttr(s) { return escapeHtml(s).replace(/'/g, '&#39;'); }
    function normalizeTag(t) {
        if (globalThis.FAFOId?.normalizeTag) return FAFOId.normalizeTag(t);
        return String(t || '').trim().replace(/\s+/g, ' ').replace(/[\u0000-\u001f\u007f]/g, '');
    }

    /** Local fallback — FAFOId.isOversizedOrSuspectTag is canonical (6.4.68). */
    function isOversizedOrSuspectTag(t) {
        if (globalThis.FAFOId?.isOversizedOrSuspectTag) return FAFOId.isOversizedOrSuspectTag(t);
        const s = String(t || '').trim();
        if (!s) return true;
        if (s.length >= 100) return true;
        if (/^[A-Za-z]:[\\/]/.test(s)) return true;
        if (/^\\\\[^\\]/.test(s)) return true;
        if (/System\.(Keywords|Rating|Media|Photo|Item|Prop)/i.test(s)) return true;
        if (/[\t\r\n]/.test(String(t || ''))) return true;
        return false;
    }

    function tagSearchKey(t) {
        return normalizeTag(t).toLowerCase().replace(/[^a-z0-9]+/gi, '');
    }

    function tagMatchesQuery(tag, query) {
        const q = normalizeTag(query).toLowerCase();
        if (!q) return true;
        const t = normalizeTag(tag).toLowerCase();
        if (!t) return false;
        if (t.includes(q) || t.startsWith(q)) return true;
        const tk = tagSearchKey(t);
        const qk = tagSearchKey(q);
        if (qk && tk.includes(qk)) return true;
        return t.split(/[^a-z0-9]+/i).filter(Boolean).some((w) => w.startsWith(q));
    }

    /** List UI only: pair/role always hidden + user exclude list + wrong space. */
    function isHiddenFromUi(tag) {
        if (!isTagInCurrentSpace(tag)) return true;
        if (globalThis.FAFOId?.isHiddenTag) return FAFOId.isHiddenTag(tag, excludedTags);
        return false;
    }

    /** public (normal only) | hidden (hidden menu only) | both. */
    function tagMenuScopeOf(tag) {
        const low = normalizeTag(tag).toLowerCase();
        const v = tagMenuScope[low];
        if (v === 'hidden' || v === 'both') return v;
        return 'public';
    }

    /** Hidden-only tags stay out of the normal menu. Both still shows there. */
    function isHiddenOnlyTag(tag) {
        return tagMenuScopeOf(tag) === 'hidden';
    }

    function hiddenPanelOpen() {
        const panel = $('meta-hidden-panel');
        return !!(panel && !panel.classList.contains('hidden'));
    }

    /**
     * Which menu a tag is allowed to appear in.
     * normal = non-hidden lists and presets (public + both).
     * hidden = hidden lists and presets (hidden + both, plus legacy excluded).
     */
    function isTagListedIn(tag, menu) {
        const t = normalizeTag(tag);
        if (!t) return false;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) return false;
        const low = t.toLowerCase();
        const scope = tagMenuScopeOf(t);
        const excluded = excludedTags.some((x) => normalizeTag(x).toLowerCase() === low);
        if (menu === 'hidden') {
            if (scope === 'public' && !excluded) return false;
            if (scope === 'hidden' || scope === 'both' || excluded) {
                if (!excluded && !isTagInCurrentSpace(t)) return false;
                return true;
            }
            return false;
        }
        if (excluded || isHiddenFromUi(t)) return false;
        return scope !== 'hidden';
    }

    function isInNormalTagMenu(tag) {
        return isTagListedIn(tag, 'normal');
    }

    /** Tag text for a preset slot. Wrong-menu assignments stay stored but are not shown. */
    function presetTagForMenu(tag, menu) {
        const t = normalizeTag(tag);
        if (!t || !isTagListedIn(t, menu === 'hidden' ? 'hidden' : 'normal')) return '';
        return t;
    }

    /** Hidden menu: hidden-only, both, and legacy fully-excluded tags. */
    function hiddenMenuTags() {
        const map = new Map();
        const add = (raw) => {
            const t = normalizeTag(raw);
            if (!t || isOversizedOrSuspectTag(t)) return;
            if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) return;
            const low = t.toLowerCase();
            if (!map.has(low)) map.set(low, t);
        };
        tagLibrary.forEach((t) => {
            if (isTagListedIn(t, 'hidden')) add(t);
        });
        excludedTags.forEach(add);
        return [...map.values()].sort((a, b) =>
            a.localeCompare(b, undefined, { sensitivity: 'base' })
        );
    }

    async function persistTagMenuScope() {
        const sk = spaceKeys();
        const clean = {};
        Object.keys(tagMenuScope || {}).forEach((k) => {
            const low = normalizeTag(k).toLowerCase();
            const v = tagMenuScope[k];
            if (!low) return;
            if (v === 'hidden' || v === 'both') clean[low] = v;
        });
        tagMenuScope = clean;
        try {
            await chrome.storage.local.set({
                [sk.tagMenuScope]: clean,
                [sk.tagExcluded]: excludedTags,
            });
        } catch (e) {
            console.warn('fafoTagMenuScope save failed', e);
        }
        try { await saveStore(); } catch (_) {}
        updateHiddenTagsButton();
    }

    /**
     * Put tags in one menu, both, or the normal menu only.
     * Leaving the hidden-only state also clears a legacy "hide from list" flag.
     */
    async function setTagMenuScope(tags, scope, opts = {}) {
        const list = (Array.isArray(tags) ? tags : [tags]).map(normalizeTag).filter(Boolean);
        if (!list.length) return;
        const mode = scope === 'hidden' || scope === 'both' ? scope : 'public';
        list.forEach((t) => {
            const low = t.toLowerCase();
            if (mode === 'public') delete tagMenuScope[low];
            else tagMenuScope[low] = mode;
            excludedTags = excludedTags.filter((x) => normalizeTag(x).toLowerCase() !== low);
            ensureTagsKnown([t], privateSpaceActive ? { forcePrivate: true } : {});
        });
        await persistTagMenuScope();
        sortTagLibrary();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderRecentTags();
        renderExtraTagHud();
        renderSprintUi();
        renderFileTagChips();
        renderHiddenTagsPanel();
        if (!opts.quiet && els.status) {
            const label = mode === 'hidden'
                ? 'hidden menu only'
                : (mode === 'both' ? 'both menus' : 'normal menu only');
            els.status.textContent = list.length > 1
                ? `${list.length} tags → ${label}`
                : `“${list[0]}” → ${label}`;
        }
    }

    // ─── Private section (isolated vault) ─────────────────────────────────
    function isPrivateTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return false;
        const low = t.toLowerCase();
        return privateTags.some((x) => normalizeTag(x).toLowerCase() === low);
    }

    function isPrivateMediaKey(key) {
        if (!key) return false;
        return privateMediaKeys.includes(key);
    }

    /**
     * True only if this tag belongs to the ACTIVE section.
     * After hydrate, tagLibrary IS the space vocab (public or private).
     * Also allow: active clip tags, recents, and programmed slots (so UI stays usable
     * even if a brief race left library mid-load).
     */
    function isTagInCurrentSpace(tag) {
        const t = normalizeTag(tag);
        if (!t) return false;
        const low = t.toLowerCase();
        if (tagLibrary.some((x) => normalizeTag(x).toLowerCase() === low)) return true;
        if (activeTags.some((x) => normalizeTag(x).toLowerCase() === low)) return true;
        if (recentTags.some((x) => normalizeTag(x).toLowerCase() === low)) return true;
        // Hotkeys / sprint / E-set for THIS space (already loaded with the space)
        try {
            for (let b = 0; b < HOTKEY_BANKS; b++) {
                for (let s = 0; s < HOTKEY_SLOTS; s++) {
                    if (normalizeTag(tagHotkeys[b]?.[s] || '').toLowerCase() === low) return true;
                }
            }
            for (let b = 0; b < EXTRA_BANKS; b++) {
                for (let s = 0; s < EXTRA_SLOTS; s++) {
                    if (normalizeTag(extraTagBanks[b]?.[s] || '').toLowerCase() === low) return true;
                }
            }
            if ((sprintTags || []).some((x) => normalizeTag(x).toLowerCase() === low)) return true;
        } catch (_) { /* ignore */ }
        return false;
    }

    /**
     * Grow-only fold of media/slots into vocabulary — NEVER drops unused tags already known.
     */
    function decontaminateTagLibraryToActiveSpace() {
        scrubTagLibrary();
        const grow = new Map();
        const remember = (raw) => {
            const t = normalizeTag(raw);
            if (!t || isOversizedOrSuspectTag(t)) return;
            if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) return;
            const low = t.toLowerCase();
            if (!grow.has(low)) grow.set(low, t);
        };
        // Keep everything already known (including unused DB tags)
        tagLibrary.forEach(remember);
        Object.values(mediaMeta || {}).forEach((m) => {
            userTagsOnly(m?.tags || []).forEach(remember);
        });
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) remember(tagHotkeys[b]?.[s]);
        }
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) remember(extraTagBanks[b]?.[s]);
        }
        recentTags.forEach(remember);
        (sprintTags || []).forEach(remember);
        activeTags.forEach(remember);
        Object.keys(sessionTagCount || {}).forEach(remember);
        Object.keys(tagLastUsed || {}).forEach(remember);

        tagLibrary = [...grow.values()].sort((a, b) =>
            a.localeCompare(b, undefined, { sensitivity: 'base' })
        );
        sessionHasPicks = Object.keys(sessionTagCount || {}).some((k) => (sessionTagCount[k] || 0) > 0);
    }

    function tagDbStorageKey() {
        const k = spaceKeys();
        if (k.tagDb) return k.tagDb;
        return privateSpaceActive
            ? (globalThis.FAFOTagDb?.privateTagDbKey?.(currentVaultId()) || 'fafoTagDbPrivate')
            : (globalThis.FAFOTagDb?.publicTagDbKey?.() || 'fafoTagDb');
    }

    /**
     * Full vocabulary hydrate for the ACTIVE space:
     *   Tag DB (opaque) → plain fafoTagLibrary → media → counts → recents → slots → colors
     * Unused tags stay. Public boot never pulls private DB (and vice versa).
     */
    async function hydrateTagVocabulary({ render = false } = {}) {
        const TD = globalThis.FAFOTagDb;
        const key = tagDbStorageKey();
        const sk = spaceKeys();
        const before = tagLibrary.length;

        // 1) Opaque Tag DB first
        if (TD?.load) {
            try {
                let db = await TD.load(key);
                // 2) Migrate / absorb plain list (recovery when DB empty or partial)
                const plainBag = await chrome.storage.local.get([sk.tagLibrary]);
                const plainLib = Array.isArray(plainBag[sk.tagLibrary])
                    ? plainBag[sk.tagLibrary]
                    : [];
                // Also try legacy public key once when public
                let legacyPlain = [];
                if (!privateSpaceActive) {
                    try {
                        const leg = await chrome.storage.local.get(['fafoTagLibrary']);
                        if (Array.isArray(leg.fafoTagLibrary)) legacyPlain = leg.fafoTagLibrary;
                    } catch (_) {}
                }
                const seedPlain = [
                    ...tagLibrary,
                    ...plainLib,
                    ...legacyPlain,
                    ...Object.keys(sessionTagCount || {}),
                    ...Object.keys(tagLastUsed || {}),
                    ...recentTags,
                ];
                if (!db.ok || !db.tags.length) {
                    const mig = await TD.migrateFromPlain(
                        key,
                        seedPlain,
                        tagLastUsed,
                        sessionTagCount
                    );
                    if (mig.tags?.length) {
                        db = {
                            tags: mig.tags,
                            lastUsed: tagLastUsed,
                            applyCounts: sessionTagCount,
                            ok: true,
                        };
                    }
                } else if (seedPlain.length) {
                    // Grow existing DB with any plain leftovers
                    try {
                        const merged = await TD.mergeTags(key, seedPlain);
                        db = { ...db, tags: merged, ok: true };
                    } catch (_) {}
                }
                if (db.tags?.length) {
                    const map = new Map();
                    db.tags.forEach((t) => {
                        const n = normalizeTag(t);
                        if (n) map.set(n.toLowerCase(), n);
                    });
                    tagLibrary.forEach((t) => {
                        const n = normalizeTag(t);
                        if (n) map.set(n.toLowerCase(), n);
                    });
                    tagLibrary = [...map.values()];
                }
                if (db.lastUsed && typeof db.lastUsed === 'object') {
                    tagLastUsed = { ...db.lastUsed, ...tagLastUsed };
                }
                if (db.applyCounts && typeof db.applyCounts === 'object') {
                    sessionTagCount = { ...db.applyCounts, ...sessionTagCount };
                    recomputeSessionHasPicks();
                }
            } catch (e) {
                console.warn('hydrateTagVocabulary DB', e);
            }
        }

        // 3) Fold media + slots + recents + counts (grow-only)
        decontaminateTagLibraryToActiveSpace();

        // 4) Colored tags for THIS space (if color map loaded) — unused but colored still list
        try {
            if (globalThis.FAFOTagColors?.getEntry) {
                // paintAll data-tag attributes won't help; load raw map via storage key
                const colorKey = sk.tagColors || (privateSpaceActive ? 'fafoTagColorsPrivate' : 'fafoTagColors');
                const bag = await chrome.storage.local.get([colorKey]);
                const cmap = bag[colorKey];
                if (cmap && typeof cmap === 'object' && !Array.isArray(cmap)) {
                    Object.keys(cmap).forEach((k) => {
                        if (k && !k.startsWith('_')) ensureTagsKnown([k]);
                    });
                }
            }
        } catch (_) {}

        scrubTagLibrary();
        sortTagLibrary();

        // 5) Persist full vocab so next boot is solid
        try { await persistTagDb(); } catch (_) {}
        // Recovery mirror (plain list) so a bad decrypt can't blank the UI forever
        try {
            await chrome.storage.local.set({ [sk.tagLibrary]: tagLibrary.slice() });
        } catch (_) {}

        if (render) {
            try { renderTagLibrary(); } catch (_) {}
            try { renderHotkeyBar(); } catch (_) {}
            try { renderRecentTags(); } catch (_) {}
            try { renderTagSuggestions(els.tagInput?.value || ''); } catch (_) {}
        }

        return tagLibrary.length;
    }

    /** Pull opaque Tag DB into memory (canonical vocabulary for this space). */
    async function loadTagDbIntoMemory() {
        return hydrateTagVocabulary({ render: false });
    }

    /** Write current vocabulary into opaque Tag DB (not human-readable). */
    async function persistTagDb() {
        const TD = globalThis.FAFOTagDb;
        if (!TD?.save) return;
        try {
            await TD.save(tagDbStorageKey(), {
                tags: tagLibrary,
                lastUsed: tagLastUsed,
                applyCounts: sessionTagCount,
            });
        } catch (e) {
            console.warn('persistTagDb', e);
        }
    }

    let tagDbSaveTimer = null;
    function schedulePersistTagDb() {
        clearTimeout(tagDbSaveTimer);
        tagDbSaveTimer = setTimeout(() => {
            persistTagDb().catch(() => {});
            // Keep plain recovery mirror in sync (same space keys)
            try {
                const sk = spaceKeys();
                chrome.storage.local.set({ [sk.tagLibrary]: tagLibrary.slice() }).catch(() => {});
            } catch (_) {}
        }, 280);
    }

    /**
     * Playlist is rebuilt per-space from private/public folders — items in the active
     * playlist are already isolated. Keep key-based checks for legacy vaulted keys.
     */
    function isMediaInCurrentSpace(keyOrItem) {
        // Playlist built via getMediaForSpace — trust current library isolation
        if (privateSpaceActive) {
            // Legacy: if still using privateMediaKeys list, honor it when present
            if (privateMediaKeys.length) {
                let key = null;
                if (typeof keyOrItem === 'string') key = keyOrItem;
                else if (keyOrItem && typeof keyOrItem === 'object') {
                    key = keyOrItem.mediaKey || keyOrItem.key || mediaKeyFromItem(keyOrItem);
                }
                if (key && privateMediaKeys.includes(key)) return true;
                // Private folder library items may not be in privateMediaKeys — allow playlist items
                return true;
            }
            return true;
        }
        // Public: exclude legacy privateMediaKeys if any remain
        let key = null;
        if (typeof keyOrItem === 'string') key = keyOrItem;
        else if (keyOrItem && typeof keyOrItem === 'object') {
            key = keyOrItem.mediaKey || keyOrItem.key || mediaKeyFromItem(keyOrItem);
        }
        if (key && privateMediaKeys.includes(key)) return false;
        return true;
    }

    function mediaKeyFromItem(item) {
        if (!item) return null;
        if (item.mediaKey || item.key) return item.mediaKey || item.key;
        const name = item.handle?.name || item.name || '';
        if (name) {
            const hit = findStoredByName(name);
            if (hit?.key) return hit.key;
        }
        return null;
    }

    async function sha256Hex(str) {
        const data = new TextEncoder().encode(str);
        const buf = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    function randomSalt() {
        const a = new Uint8Array(16);
        crypto.getRandomValues(a);
        return Array.from(a).map((b) => b.toString(16).padStart(2, '0')).join('');
    }

    async function hashPin(pin, salt) {
        return sha256Hex(`${salt}::${String(pin || '')}`);
    }

    function hasPrivatePin() {
        // True if any vault has a PIN, or legacy single-vault hash is present
        return !!(privatePinHash && privatePinSalt);
    }

    async function refreshHasAnyVaultPin() {
        try {
            const PV = globalThis.FAFOPrivateVaults;
            if (!PV?.loadRegistry) return hasPrivatePin();
            const reg = await PV.loadRegistry();
            const any = (reg.vaults || []).some((v) => PV.hasVaultPin(v));
            if (any) {
                // Mirror first vault into legacy fields for older UI checks
                const v = reg.vaults.find((x) => PV.hasVaultPin(x)) || reg.vaults[0];
                if (v) {
                    privatePinHash = v.pinHash || privatePinHash;
                    privatePinSalt = v.pinSalt || privatePinSalt;
                }
            }
            return any || hasPrivatePin();
        } catch {
            return hasPrivatePin();
        }
    }

    async function persistPrivateVault() {
        // Legacy mirror only — real vault PINs live in fafoPrivateVaults
        const payload = {
            fafoPrivateVault: {
                v: 1,
                pinHash: privatePinHash || '',
                salt: privatePinSalt || '',
                tags: privateTags.map(normalizeTag).filter(Boolean),
                mediaKeys: privateMediaKeys.filter(Boolean),
                updatedAt: new Date().toISOString(),
            },
        };
        try {
            await chrome.storage.local.set(payload);
        } catch (e) {
            console.warn('fafoPrivateVault save failed', e);
        }
    }

    /** Session flag so Options / other pages can enter discreet private UI */
    async function persistPrivateSessionFlag() {
        try {
            await chrome.storage.local.set({
                fafoPrivateSession: {
                    active: !!privateSpaceActive,
                    unlocked: !!privateUnlocked,
                    vaultId: privateSpaceActive || privateUnlocked ? currentVaultId() : null,
                    vaultName: privateSpaceActive || privateUnlocked ? (activeVaultName || '') : '',
                    at: Date.now(),
                },
            });
        } catch (e) {
            console.warn('fafoPrivateSession save failed', e);
        }
    }

    function loadPrivateVaultFromRes(res) {
        const v = res?.fafoPrivateVault;
        if (!v || typeof v !== 'object') {
            privatePinHash = '';
            privatePinSalt = '';
            privateTags = [];
            privateMediaKeys = [];
            return;
        }
        privatePinHash = String(v.pinHash || '');
        privatePinSalt = String(v.salt || '');
        privateTags = Array.isArray(v.tags) ? v.tags.map(normalizeTag).filter(Boolean) : [];
        privateMediaKeys = Array.isArray(v.mediaKeys) ? v.mediaKeys.filter(Boolean) : [];
        // Multi-vault registry is loaded async via FAFOPrivateVaults on unlock/options
    }

    async function setPrivatePin(pin, vaultId) {
        const PV = globalThis.FAFOPrivateVaults;
        const p = String(pin || '').trim();
        if (p.length < 4) throw new Error('PIN must be at least 4 characters');
        if (!PV) {
            privatePinSalt = randomSalt();
            privatePinHash = await hashPin(p, privatePinSalt);
            await persistPrivateVault();
            return;
        }
        let vid = vaultId || activeVaultId || PV.DEFAULT_VAULT_ID;
        let reg = await PV.loadRegistry();
        let vault = PV.findVault(reg, vid);
        if (!vault) {
            const shell = await PV.ensureDefaultVaultShell('Private');
            vid = shell.vault.id;
            reg = await PV.loadRegistry();
            vault = PV.findVault(reg, vid);
        }
        if (PV.hasVaultPin(vault)) {
            throw new Error('Vault already has a PIN — change it in Options with the current PIN');
        }
        const res = await PV.setVaultPinInitial(vid, p);
        if (!res.ok) throw new Error(res.error || 'Could not set PIN');
        activeVaultId = vid;
        activeVaultName = vault?.name || 'Private';
        privatePinSalt = randomSalt(); // legacy mirror (not the real salt)
        privatePinHash = 'set';
        await persistPrivateVault();
    }

    async function verifyPrivatePin(pin, vaultId) {
        const PV = globalThis.FAFOPrivateVaults;
        if (!PV) {
            if (!hasPrivatePin()) return false;
            const h = await hashPin(String(pin || '').trim(), privatePinSalt);
            return h === privatePinHash;
        }
        const reg = await PV.loadRegistry();
        const vid = vaultId || activeVaultId || PV.DEFAULT_VAULT_ID;
        const vault = PV.findVault(reg, vid);
        if (!vault) return false;
        return PV.verifyVaultPin(vault, pin);
    }

    async function unlockPrivateSpace(pin, opts = {}) {
        const PV = globalThis.FAFOPrivateVaults;
        const useMaster = !!opts.useMaster;
        let vaultId = opts.vaultId || activeVaultId || PV?.DEFAULT_VAULT_ID || 'default';

        if (!PV) {
            if (!hasPrivatePin()) {
                await setPrivatePin(pin);
                privateUnlocked = true;
                activeVaultId = 'default';
                return { ok: true, created: true, vaultId: 'default' };
            }
            const ok = await verifyPrivatePin(pin);
            if (!ok) return { ok: false, error: 'Wrong PIN' };
            privateUnlocked = true;
            activeVaultId = 'default';
            return { ok: true, created: false, vaultId: 'default' };
        }

        let reg = await PV.loadRegistry();
        if (!reg.vaults.length) {
            // First-time: create default vault + set PIN
            await PV.ensureDefaultVaultShell('Private');
            const set = await PV.setVaultPinInitial(PV.DEFAULT_VAULT_ID, pin);
            if (!set.ok) return { ok: false, error: set.error || 'Could not create vault PIN' };
            privateUnlocked = true;
            activeVaultId = PV.DEFAULT_VAULT_ID;
            activeVaultName = 'Private';
            privatePinHash = 'set';
            await persistPrivateVault();
            return { ok: true, created: true, vaultId: activeVaultId };
        }

        // If only one vault, auto-select it
        if (!opts.vaultId && reg.vaults.length === 1) {
            vaultId = reg.vaults[0].id;
        }
        const vault = PV.findVault(reg, vaultId);
        if (!vault) return { ok: false, error: 'Select a private mode (vault)' };
        if (!PV.hasVaultPin(vault) && !useMaster) {
            const set = await PV.setVaultPinInitial(vault.id, pin);
            if (!set.ok) return { ok: false, error: set.error || 'Could not set PIN' };
            privateUnlocked = true;
            activeVaultId = vault.id;
            activeVaultName = vault.name;
            return { ok: true, created: true, vaultId: vault.id };
        }

        const auth = await PV.authorizeVaultAccess(vault.id, { pin, useMaster });
        if (!auth.ok) return auth;
        privateUnlocked = true;
        activeVaultId = auth.vaultId;
        activeVaultName = auth.vaultName || vault.name;
        return { ok: true, created: false, vaultId: auth.vaultId, via: auth.via };
    }

    async function lockPrivateSpace() {
        if (privateSpaceActive) {
            // Full exit to public library + lock
            await exitPrivateToNormal();
            return;
        }
        privateUnlocked = false;
        activeVaultId = null;
        activeVaultName = '';
        updatePrivateSpaceUi();
        await persistPrivateSessionFlag();
    }

    async function enterPrivateSpace(vaultId) {
        if (!privateUnlocked) return false;
        if (vaultId) activeVaultId = vaultId;
        if (!activeVaultId) {
            activeVaultId = globalThis.FAFOPrivateVaults?.DEFAULT_VAULT_ID || 'default';
        }
        // Drop pending public debounced writes, then flush public fully before flip
        cancelPendingSpaceWrites();
        try { await saveStore(); } catch (_) {}
        // Wipe public lists from RAM before the flag flips so UI never mixes
        wipeInMemorySpaceData();
        privateSpaceActive = true;
        await onPrivateSpaceChanged();
        await persistPrivateSessionFlag();
        return true;
    }

    async function enterPublicSpace() {
        cancelPendingSpaceWrites();
        // Flush PRIVATE store first if we were private
        if (privateSpaceActive) {
            try { await saveStore(); } catch (_) {}
        }
        // Wipe private lists from RAM before the flag flips
        wipeInMemorySpaceData();
        privateSpaceActive = false;
        // Stay unlocked until Lock / double-Esc (same vault can re-enter)
        await onPrivateSpaceChanged();
        await persistPrivateSessionFlag();
        return true;
    }

    /** Exit private completely (view + unlock) — used by double-Escape */
    async function exitPrivateToNormal() {
        // 0) Stop debounced writes that still hold private data in closures/timers
        cancelPendingSpaceWrites();
        // 1) Flush PRIVATE data while still in private mode
        if (privateSpaceActive) {
            try { await saveStore(); } catch (e) { console.warn('exit save private', e); }
        }
        // 2) Wipe private from RAM, then flip flags so spaceKeys() point at public
        wipeInMemorySpaceData();
        privateSpaceActive = false;
        privateUnlocked = false;
        activeVaultId = null;
        activeVaultName = '';
        // 3) Load public tag library + media meta explicitly (force false)
        try {
            await hydrateActiveSpaceData(false);
        } catch (e) {
            console.warn('exit hydrate public', e);
            // Hard fail-safe: never leave private tags in memory after exit
            wipeInMemorySpaceData();
        }
        // 4) Refresh UI against public data only
        updatePrivateSpaceUi();
        rebuildTagLibraryFromMedia();
        reseedSessionAutosForActiveSpace();
        sortTagLibrary();
        try { renderTagLibrary(); } catch (_) {}
        try { renderTagSuggestions(els.tagInput?.value || ''); } catch (_) {}
        try { renderHotkeyBar(); } catch (_) {}
        try { renderExtraTagHud(); } catch (_) {}
        try { renderRecentTags(); } catch (_) {}
        try { renderSprintUi(); } catch (_) {}
        try { renderMetaPanel(); } catch (_) {}
        try {
            if (window.FAFOPlayer?.reloadLibrary) await window.FAFOPlayer.reloadLibrary();
            else window.FAFOPlayer?.refreshLoopMode?.();
        } catch (_) {}
        // Re-bind current public clip so chips/tags match public meta
        try {
            const item = window.FAFOPlayer?.getCurrentItem?.();
            const idx = window.FAFOPlayer?.getCurrentIndex?.() || 0;
            if (item) await bindToItem(item, idx);
        } catch (_) {}
        // Final paint after bind (bind may add known public tags)
        try { renderTagLibrary(); } catch (_) {}
        try { renderHotkeyBar(); } catch (_) {}
        try { renderMetaPanel(); } catch (_) {}
        await persistPrivateSessionFlag();
        if (els.status) {
            els.status.textContent = `Normal mode · ${tagLibrary.length} public tags`;
        }
        try { window.FAFOUndo?.showToast?.('Normal mode'); } catch (_) {}
    }

    async function onPrivateSpaceChanged() {
        cancelPendingSpaceWrites();
        updatePrivateSpaceUi();
        // Swap entire tag/meta library + rebuild media playlist for this space
        try {
            await hydrateActiveSpaceData(privateSpaceActive);
        } catch (e) {
            console.warn('hydrateActiveSpaceData', e);
            wipeInMemorySpaceData();
        }
        // Never import the other section: rebuild vocab + counts from THIS mediaMeta only
        rebuildTagLibraryFromMedia();
        reseedSessionAutosForActiveSpace();
        sortTagLibrary();
        try { renderTagLibrary(); } catch (_) {}
        try { hideSuggestions(); } catch (_) {}
        try { renderHotkeyBar(); } catch (_) {}
        try { renderExtraTagHud(); } catch (_) {}
        try { renderRecentTags(); } catch (_) {}
        try { renderSprintUi(); } catch (_) {}
        try { renderMetaPanel(); } catch (_) {}
        try {
            if (window.FAFOPlayer?.reloadLibrary) {
                await window.FAFOPlayer.reloadLibrary();
            } else {
                window.FAFOPlayer?.refreshLoopMode?.();
            }
        } catch (_) {}
        try {
            const item = window.FAFOPlayer?.getCurrentItem?.();
            const idx = window.FAFOPlayer?.getCurrentIndex?.() || 0;
            if (item) await bindToItem(item, idx);
        } catch (_) {}
        // Re-assert full Tag DB vocabulary for THIS space (unused tags included)
        try {
            await hydrateTagVocabulary({ render: false });
        } catch (_) {
            decontaminateTagLibraryToActiveSpace();
        }
        rebuildLibraryTagCounts();
        try { renderTagLibrary(); } catch (_) {}
        try { renderRecentTags(); } catch (_) {}
        try { renderHotkeyBar(); } catch (_) {}
        try { renderTagSuggestions(''); } catch (_) {}
        try { renderMetaPanel(); } catch (_) {}
        const privFolders = await countPrivateFolders();
        if (els.status) {
            const nTags = tagLibrary.length;
            const nFiles = Object.keys(mediaMeta || {}).length;
            const vLabel = activeVaultName || currentVaultId();
            els.status.textContent = privateSpaceActive
                ? `◈ ${vLabel} only · ${nTags} private tags · ${nFiles} file records`
                : `Public library · ${nTags} tags · private vaults hidden`;
        }
    }

    async function countPrivateFolders() {
        try {
            if (!window.FAFOLibrary?.openDB) return 0;
            const db = await FAFOLibrary.openDB();
            const list = await FAFOLibrary.listFolders(db, {
                space: 'private',
                vaultId: privateSpaceActive ? currentVaultId() : undefined,
            });
            return list.length;
        } catch {
            return 0;
        }
    }

    /** Harvest tag names from loaded mediaMeta into tagLibrary (space-local, grow-only). */
    function rebuildTagLibraryFromMedia() {
        try {
            Object.values(mediaMeta || {}).forEach((m) => {
                if (m && Array.isArray(m.tags)) ensureTagsKnown(m.tags);
            });
            scrubTagLibrary();
            // Grow-only — never wipe unused tags that live only in the Tag DB
            decontaminateTagLibraryToActiveSpace();
        } catch (e) {
            console.warn('rebuildTagLibraryFromMedia', e);
        }
    }

    /**
     * Load tag/meta stores for a space into memory.
     * @param {boolean} [forcePrivate] - if set, use this instead of privateSpaceActive
     */
    async function hydrateActiveSpaceData(forcePrivate) {
        const isPriv = forcePrivate === true || (forcePrivate !== false && privateSpaceActive);
        // Per-vault private keys when a vault is active; legacy default otherwise
        const k = isPriv
            ? (globalThis.FAFOPrivateVaults?.privateStorageKeys?.(currentVaultId()) || SPACE_STORAGE.private)
            : (globalThis.FAFOPrivateVaults?.publicStorageKeys?.() || SPACE_STORAGE.public);
        // CRITICAL: wipe the other mode's lists/counts BEFORE any await so a mid-switch
        // render never paints public tags/counts while privateSpaceActive is already true
        // (and vice versa). Private and public are completely separate in RAM.
        wipeInMemorySpaceData();
        const res = await chrome.storage.local.get([
            k.mediaMeta, k.tagLibrary, k.tagLastUsed, k.tagHotkeys,
            k.tagExcluded, k.tagMenuScope, k.recentTags, k.applyCounts, k.extraBanks,
            k.sprintTags,
        ]);
        const rawMeta = res[k.mediaMeta];
        mediaMeta = rawMeta && typeof rawMeta === 'object' && !Array.isArray(rawMeta)
            ? { ...rawMeta }
            : {};
        tagLibrary = Array.isArray(res[k.tagLibrary]) ? res[k.tagLibrary].slice() : [];
        tagLastUsed = res[k.tagLastUsed] && typeof res[k.tagLastUsed] === 'object' ? { ...res[k.tagLastUsed] } : {};
        tagHotkeys = normalizeHotkeyBanks(res[k.tagHotkeys]);
        excludedTags = Array.isArray(res[k.tagExcluded])
            ? res[k.tagExcluded].map(normalizeTag).filter(Boolean)
            : [];
        tagMenuScope = {};
        const rawScope = res[k.tagMenuScope];
        if (rawScope && typeof rawScope === 'object' && !Array.isArray(rawScope)) {
            Object.keys(rawScope).forEach((key) => {
                const low = normalizeTag(key).toLowerCase();
                const v = rawScope[key];
                if (!low) return;
                if (v === 'hidden' || v === 'both') tagMenuScope[low] = v;
            });
        }
        recentTags = Array.isArray(res[k.recentTags])
            ? res[k.recentTags].map(normalizeTag).filter(Boolean).slice(0, 12)
            : [];
        sessionTagCount = res[k.applyCounts] && typeof res[k.applyCounts] === 'object'
            ? { ...res[k.applyCounts] }
            : {};
        sessionHasPicks = Object.keys(sessionTagCount).length > 0;
        if (Array.isArray(res[k.extraBanks]) && res[k.extraBanks].length) {
            try {
                extraTagBanks = res[k.extraBanks].map((row) =>
                    Array.isArray(row) ? row.slice(0, EXTRA_SLOTS) : Array(EXTRA_SLOTS).fill('')
                );
                while (extraTagBanks.length < EXTRA_BANKS) extraTagBanks.push(Array(EXTRA_SLOTS).fill(''));
            } catch {
                extraTagBanks = emptyExtraBanks();
            }
        } else {
            extraTagBanks = emptyExtraBanks();
        }
        // Sprint quick-5 is per-space so private picks never show in normal mode
        if (Array.isArray(res[k.sprintTags]) && res[k.sprintTags].length) {
            sprintTags = [0, 1, 2, 3, 4].map((i) => normalizeTag(res[k.sprintTags][i] || '') || '');
        } else {
            sprintTags = ['', '', '', '', ''];
        }
        // Migration: old privateTags list → private tag library once
        if (isPriv && !tagLibrary.length && privateTags.length) {
            tagLibrary = privateTags.slice();
            // persist into private keys without flipping space
            try {
                await chrome.storage.local.set({
                    [k.tagLibrary]: tagLibrary,
                });
            } catch (_) {}
        }
        // Repair: older builds wrote private tags into public fafoTagLibrary via
        // scheduleCountSave. Strip private-only vocab from public memory (and disk).
        if (!isPriv) {
            try {
                const defKeys = globalThis.FAFOPrivateVaults?.privateStorageKeys?.('default')
                    || SPACE_STORAGE.private;
                const privRes = await chrome.storage.local.get([
                    defKeys.tagLibrary,
                ]);
                const privLib = Array.isArray(privRes[defKeys.tagLibrary])
                    ? privRes[defKeys.tagLibrary]
                    : [];
                const privOnly = new Set(
                    [...privLib, ...privateTags]
                        .map((t) => normalizeTag(t).toLowerCase())
                        .filter(Boolean)
                );
                if (privOnly.size) {
                    const onPublicFiles = new Set();
                    Object.values(mediaMeta || {}).forEach((m) => {
                        userTagsOnly(m.tags || []).forEach((t) => {
                            onPublicFiles.add(normalizeTag(t).toLowerCase());
                        });
                    });
                    const before = tagLibrary.length;
                    tagLibrary = tagLibrary.filter((t) => {
                        const low = normalizeTag(t).toLowerCase();
                        if (!low) return false;
                        // Keep if it appears on public media, even if also private-named
                        if (onPublicFiles.has(low)) return true;
                        // Drop pure private-vocab leaks
                        return !privOnly.has(low);
                    });
                    // Ensure every tag still on public files is in the vocab
                    Object.values(mediaMeta || {}).forEach((m) => {
                        if (m && Array.isArray(m.tags)) ensureTagsKnown(m.tags);
                    });
                    if (tagLibrary.length !== before) {
                        try {
                            const pubKeys = globalThis.FAFOPrivateVaults?.publicStorageKeys?.()
                                || SPACE_STORAGE.public;
                            await chrome.storage.local.set({
                                [pubKeys.tagLibrary]: tagLibrary,
                            });
                        } catch (_) {}
                    }
                }
            } catch (e) {
                console.warn('public tag decontaminate', e);
            }
        }
        activeKey = null;
        activeTags = [];
        activeRating = 0;
        activeName = '';
        activePairId = '';
        scrubTagLibrary();
        // Full vocabulary from Tag DB (+ recovery sources). Unused tags kept.
        try {
            await hydrateTagVocabulary({ render: false });
        } catch (e) {
            console.warn('hydrate vocab', e);
            decontaminateTagLibraryToActiveSpace();
        }
        // Quick-select autos only from this space's counts/library
        reseedSessionAutosForActiveSpace();
        // Notify pairs / colors modules to swap their space stores
        try {
            window.dispatchEvent(new CustomEvent('fafo-space-changed', {
                detail: { private: !!isPriv, pairsKey: k.pairs, colorsKey: k.tagColors },
            }));
        } catch (_) { /* ignore */ }
    }

    async function persistActiveSpaceMeta() {
        const k = spaceKeys();
        const payload = {
            [k.mediaMeta]: mediaMeta,
            // Plain list kept as recovery mirror; opaque Tag DB is still written
            [k.tagLibrary]: tagLibrary.slice(),
            [k.tagLastUsed]: tagLastUsed,
            [k.tagHotkeys]: tagHotkeys,
            [k.tagExcluded]: excludedTags,
            [k.tagMenuScope]: tagMenuScope,
            [k.recentTags]: recentTags,
            [k.applyCounts]: sessionTagCount,
            [k.extraBanks]: extraTagBanks,
            [k.sprintTags]: sprintTags.slice(),
        };
        await chrome.storage.local.set(payload);
        await persistTagDb();
    }

    async function linkPrivateLibraryFolder(storeName = 'videos') {
        if (!privateUnlocked || !privateSpaceActive) {
            showPrivateUnlockModal();
            return;
        }
        if (!window.showDirectoryPicker || !window.FAFOLibrary?.linkFolder) {
            if (els.status) els.status.textContent = 'Folder picker unavailable in this browser';
            return;
        }
        try {
            const dir = await showDirectoryPicker({
                id: 'fafo-private-library-' + currentVaultId(),
                mode: 'read',
                startIn: 'videos',
            });
            const db = await FAFOLibrary.openDB();
            const result = await FAFOLibrary.linkFolder(db, storeName, dir, {
                space: 'private',
                vaultId: currentVaultId(),
            });
            if (els.status) {
                els.status.textContent =
                    `Private folder linked (${activeVaultName || currentVaultId()}): ${result.folder?.name || dir.name} · ${result.added} file(s)`;
            }
            updatePrivateSpaceUi();
            if (window.FAFOPlayer?.reloadLibrary) await window.FAFOPlayer.reloadLibrary();
        } catch (e) {
            if (e?.name === 'AbortError') return;
            console.warn(e);
            if (els.status) els.status.textContent = 'Link private folder failed: ' + (e.message || e);
        }
    }

    function updatePrivateSpaceUi() {
        const btn = $('meta-private-space-btn');
        const banner = $('meta-private-banner');
        const modal = $('meta-private-modal');
        const label = activeVaultName || 'Private';
        if (btn) {
            if (privateSpaceActive) {
                btn.textContent = '◈ ' + (label.length > 10 ? label.slice(0, 9) + '…' : label);
                btn.classList.add('on', 'private-on');
                btn.title = `Viewing private mode “${label}” · click to return to Public`;
            } else if (privateUnlocked) {
                btn.textContent = '◈ Unlocked';
                btn.classList.add('on');
                btn.classList.remove('private-on');
                btn.title = `Vault “${label}” unlocked · click to enter (or lock)`;
            } else {
                btn.textContent = '◈';
                btn.classList.remove('on', 'private-on');
                btn.title = 'Private modes (PIN) · separate tags & videos · Ctrl+Shift+Alt+P';
            }
        }
        if (banner) {
            banner.classList.toggle('hidden', !privateSpaceActive);
            const title = banner.querySelector('.meta-private-banner-title');
            if (title) title.textContent = `◈ ${label.toUpperCase()}`;
            const counts = banner.querySelector('[data-private-counts]');
            if (counts) {
                counts.textContent = `${tagLibrary.length} tags · vault only`;
            }
        }
        document.body.classList.toggle('fafo-private-space', !!privateSpaceActive);
        if (modal && !modal.classList.contains('hidden') && privateUnlocked && hasPrivatePin()) {
            // leave modal open only during unlock flow
        }
        updateHiddenTagsButton();
    }

    async function populateVaultSelect() {
        const sel = $('meta-private-vault-select');
        if (!sel) return;
        const PV = globalThis.FAFOPrivateVaults;
        sel.innerHTML = '';
        try {
            if (!PV?.loadRegistry) {
                sel.innerHTML = '<option value="default">Private</option>';
                sel.classList.remove('hidden');
                return;
            }
            const reg = await PV.loadRegistry();
            const list = reg.vaults || [];
            if (!list.length) {
                sel.innerHTML = '<option value="default">Private (new)</option>';
                sel.classList.remove('hidden');
                return;
            }
            list.forEach((v) => {
                const opt = document.createElement('option');
                opt.value = v.id;
                opt.textContent = v.name || v.id;
                if (v.id === activeVaultId) opt.selected = true;
                sel.appendChild(opt);
            });
            // Show selector when more than one vault, or always for clarity
            sel.classList.toggle('hidden', list.length < 2);
            if (list.length === 1) sel.value = list[0].id;
        } catch {
            sel.innerHTML = '<option value="default">Private</option>';
        }
    }

    async function showPrivateUnlockModal(mode) {
        // mode: 'unlock' | 'setup' | 'change'
        const modal = $('meta-private-modal');
        if (!modal) return;
        modal.classList.remove('hidden');
        const anyPin = await refreshHasAnyVaultPin();
        modal.dataset.mode = mode || (anyPin ? 'unlock' : 'setup');
        const title = $('meta-private-modal-title');
        const hint = $('meta-private-modal-hint');
        const pin2 = $('meta-private-pin2');
        const pin1 = $('meta-private-pin');
        const useMaster = $('meta-private-use-master');
        if (pin1) pin1.value = '';
        if (pin2) pin2.value = '';
        if (useMaster) useMaster.checked = false;
        await populateVaultSelect();
        // Show master checkbox only if master exists
        try {
            const PV = globalThis.FAFOPrivateVaults;
            const masterRow = useMaster?.closest?.('.meta-private-master-row')
                || document.querySelector('.meta-private-master-row');
            if (PV && masterRow) {
                const reg = await PV.loadRegistry();
                const hasM = PV.hasMaster(reg);
                masterRow.classList.toggle('hidden', !hasM);
                masterRow.style.display = hasM ? 'flex' : 'none';
                if (useMaster && !hasM) useMaster.checked = false;
            }
        } catch (_) {}
        const needSetup = !anyPin || mode === 'setup' || mode === 'change';
        if (pin2) pin2.classList.toggle('hidden', !(mode === 'setup' || mode === 'change' || !anyPin));
        if (title) {
            title.textContent = needSetup && !anyPin
                ? 'Create private PIN'
                : mode === 'change'
                    ? 'Change vault PIN (use Options)'
                    : 'Unlock private mode';
        }
        if (hint) {
            hint.textContent = needSetup && !anyPin
                ? 'Create a PIN for this private mode. Tags & videos stay completely separate from public. Forgot PIN = locked out (unless admin Master can override — only vaults created after Master was set).'
                : 'Enter this vault’s PIN. Optional Master PIN only works for vaults created after Master was established. Manage vaults in Options → Private vaults.';
        }
        setTimeout(() => pin1?.focus(), 50);
    }

    function hidePrivateUnlockModal() {
        const modal = $('meta-private-modal');
        if (modal) modal.classList.add('hidden');
    }

    async function submitPrivateUnlockModal() {
        const pin1 = ($('meta-private-pin')?.value || '').trim();
        const pin2 = ($('meta-private-pin2')?.value || '').trim();
        const mode = $('meta-private-modal')?.dataset?.mode || 'unlock';
        const vaultId = ($('meta-private-vault-select')?.value || '').trim()
            || globalThis.FAFOPrivateVaults?.DEFAULT_VAULT_ID
            || 'default';
        const useMaster = !!$('meta-private-use-master')?.checked;
        const errEl = $('meta-private-modal-err');
        const setErr = (m) => { if (errEl) errEl.textContent = m || ''; };
        setErr('');
        try {
            const anyPin = await refreshHasAnyVaultPin();
            if ((!anyPin || mode === 'setup') && !useMaster) {
                if (pin1.length < 4) { setErr('PIN must be at least 4 characters'); return; }
                if (!$('meta-private-pin2')?.classList.contains('hidden') && pin1 !== pin2) {
                    setErr('PINs do not match');
                    return;
                }
                const res = await unlockPrivateSpace(pin1, { vaultId });
                if (!res.ok) { setErr(res.error || 'Could not unlock'); return; }
                hidePrivateUnlockModal();
                await enterPrivateSpace(res.vaultId || vaultId);
                if (els.status) {
                    els.status.textContent =
                        `Private mode “${activeVaultName || res.vaultId}” ready · link a private folder to add videos`;
                }
                return;
            }
            if (mode === 'change') {
                setErr('Change PINs in Options → Private vaults (requires current PIN or eligible Master)');
                return;
            }
            const res = await unlockPrivateSpace(pin1, { vaultId, useMaster });
            if (!res.ok) { setErr(res.error || 'Wrong PIN'); return; }
            hidePrivateUnlockModal();
            await enterPrivateSpace(res.vaultId || vaultId);
            if (els.status && res.via === 'master') {
                els.status.textContent = `Opened via Master PIN · “${activeVaultName || vaultId}”`;
            }
        } catch (e) {
            setErr(e.message || String(e));
        }
    }

    /**
     * Copy a tag into the PRIVATE vocabulary store and remove it from the PUBLIC
     * library list. Does not strip tags already written on media files.
     * Counts stay space-local (each section only counts its own mediaMeta).
     */
    async function moveTagToPrivate(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (!privateUnlocked) {
            showPrivateUnlockModal();
            if (els.status) els.status.textContent = 'Unlock private section first';
            return;
        }
        const low = t.toLowerCase();
        if (!isPrivateTag(t)) privateTags.push(t);
        try {
            const pk = globalThis.FAFOPrivateVaults?.privateStorageKeys?.(currentVaultId())
                || SPACE_STORAGE.private;
            const uk = globalThis.FAFOPrivateVaults?.publicStorageKeys?.() || SPACE_STORAGE.public;
            const bag = await chrome.storage.local.get([pk.tagLibrary, uk.tagLibrary]);
            let privLib = Array.isArray(bag[pk.tagLibrary]) ? bag[pk.tagLibrary].slice() : [];
            let pubLib = Array.isArray(bag[uk.tagLibrary]) ? bag[uk.tagLibrary].slice() : [];
            if (!privLib.some((x) => normalizeTag(x).toLowerCase() === low)) privLib.push(t);
            pubLib = pubLib.filter((x) => normalizeTag(x).toLowerCase() !== low);
            await chrome.storage.local.set({
                [pk.tagLibrary]: privLib,
                [uk.tagLibrary]: pubLib,
            });
            // Update in-memory for the mode we're currently in
            if (privateSpaceActive) {
                if (!tagLibrary.some((x) => x.toLowerCase() === low)) tagLibrary.push(t);
            } else {
                tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== low);
            }
        } catch (e) {
            console.warn('moveTagToPrivate', e);
            ensureTagsKnown([t], { forcePrivate: true });
        }
        await persistPrivateVault();
        if (privateSpaceActive) {
            try { await persistActiveSpaceMeta(); } catch (_) {}
        } else {
            try { await saveStore(); } catch (_) {}
        }
        renderTagLibrary();
        renderHotkeyBar();
        updatePrivateSpaceUi();
        if (els.status) els.status.textContent = `Moved “${t}” → PRIVATE library (separate counts)`;
    }

    /**
     * Copy a tag into the PUBLIC vocabulary store and remove it from the PRIVATE library.
     */
    async function moveTagToPublic(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        privateTags = privateTags.filter((x) => x.toLowerCase() !== low);
        try {
            const pk = globalThis.FAFOPrivateVaults?.privateStorageKeys?.(currentVaultId())
                || SPACE_STORAGE.private;
            const uk = globalThis.FAFOPrivateVaults?.publicStorageKeys?.() || SPACE_STORAGE.public;
            const bag = await chrome.storage.local.get([pk.tagLibrary, uk.tagLibrary]);
            let privLib = Array.isArray(bag[pk.tagLibrary]) ? bag[pk.tagLibrary].slice() : [];
            let pubLib = Array.isArray(bag[uk.tagLibrary]) ? bag[uk.tagLibrary].slice() : [];
            if (!pubLib.some((x) => normalizeTag(x).toLowerCase() === low)) pubLib.push(t);
            privLib = privLib.filter((x) => normalizeTag(x).toLowerCase() !== low);
            await chrome.storage.local.set({
                [pk.tagLibrary]: privLib,
                [uk.tagLibrary]: pubLib,
            });
            if (privateSpaceActive) {
                tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== low);
            } else if (!tagLibrary.some((x) => x.toLowerCase() === low)) {
                tagLibrary.push(t);
            }
        } catch (e) {
            console.warn('moveTagToPublic', e);
        }
        await persistPrivateVault();
        if (privateSpaceActive) {
            try { await persistActiveSpaceMeta(); } catch (_) {}
        } else {
            try { await saveStore(); } catch (_) {}
        }
        renderTagLibrary();
        renderHotkeyBar();
        updatePrivateSpaceUi();
        if (els.status) els.status.textContent = `Moved “${t}” → PUBLIC library (separate counts)`;
    }

    async function moveMediaToPrivate(key) {
        if (!key) key = activeKey;
        if (!key) {
            if (els.status) els.status.textContent = 'No active media';
            return;
        }
        if (!privateUnlocked) {
            showPrivateUnlockModal();
            return;
        }
        if (!privateMediaKeys.includes(key)) privateMediaKeys.push(key);
        await persistPrivateVault();
        updatePrivateSpaceUi();
        if (els.status) els.status.textContent = 'Video moved to PRIVATE section (hidden in public)';
        // If still in public UI, skip away from this clip
        if (!privateSpaceActive) {
            try { window.FAFOPlayer?.next?.(); } catch (_) {}
        }
    }

    async function moveMediaToPublic(key) {
        if (!key) key = activeKey;
        if (!key) return;
        privateMediaKeys = privateMediaKeys.filter((k) => k !== key);
        await persistPrivateVault();
        updatePrivateSpaceUi();
        if (els.status) els.status.textContent = 'Video moved to PUBLIC section';
        if (privateSpaceActive) {
            try { window.FAFOPlayer?.next?.(); } catch (_) {}
        }
    }

    async function handlePrivateSpaceButtonClick() {
        if (privateSpaceActive) {
            await enterPublicSpace();
            return;
        }
        if (privateUnlocked) {
            await enterPrivateSpace();
            return;
        }
        showPrivateUnlockModal(hasPrivatePin() ? 'unlock' : 'setup');
    }

    /**
     * Storage / file tags: strip pair IDs + role stamps only.
     * User exclusions do NOT remove tags from files or the current clip.
     */
    function userTagsOnly(tags) {
        if (globalThis.FAFOId?.userTagsOnly) return FAFOId.userTagsOnly(tags);
        return (Array.isArray(tags) ? tags : [])
            .map(normalizeTag)
            .filter((t) => t && !(globalThis.FAFOId?.isSystemOrPairTag?.(t)));
    }

    /** Drop pair/role junk from the vocabulary array (not user exclusions). */
    function scrubTagLibrary() {
        tagLibrary = tagLibrary.filter((t) => !(globalThis.FAFOId?.isSystemOrPairTag?.(t)));
    }

    /**
     * Hide a tag from the library list after sync.
     * Does not delete it from files or from this clip's tags.
     */
    async function persistExcludedTags() {
        // Dedicated key + full store so hides survive reloads / backups
        // Must use active space keys — never write private exclusions into public storage
        const list = excludedTags.map(normalizeTag).filter(Boolean);
        excludedTags = list;
        try {
            const sk = spaceKeys();
            await chrome.storage.local.set({ [sk.tagExcluded]: list });
        } catch (e) {
            console.warn('fafoTagExcluded save failed', e);
        }
        // Also fold into main save payload
        try {
            await saveStore();
        } catch (_) {}
        updateHiddenTagsButton();
    }

    async function excludeTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) {
            if (els.status) els.status.textContent = 'Pair/system tags are always hidden from the list';
            return;
        }
        if (!excludedTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
            excludedTags.push(t);
        }
        await persistExcludedTags();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) {
            els.status.textContent = `Hidden from list: ${t} (saved · open Hidden to restore)`;
        }
    }

    async function unexcludeTag(tag) {
        const t = normalizeTag(tag);
        const low = t.toLowerCase();
        excludedTags = excludedTags.filter((x) => x.toLowerCase() !== low);
        ensureTagsKnown([t]);
        await persistExcludedTags();
        sortTagLibrary();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) els.status.textContent = `Restored to list: ${t}`;
    }

    async function unexcludeAllTags() {
        if (!excludedTags.length) return;
        const n = excludedTags.length;
        const restored = excludedTags.slice();
        excludedTags = [];
        ensureTagsKnown(restored);
        await persistExcludedTags();
        sortTagLibrary();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) els.status.textContent = `Restored ${n} hidden tag(s) to the list`;
    }

    function updateHiddenTagsButton() {
        const btn = $('meta-hidden-tags-btn');
        if (!btn) return;
        const n = hiddenMenuTags().length;
        btn.textContent = n ? `Hidden · ${n}` : 'Hidden · 0';
        btn.classList.toggle('has-hidden', n > 0);
        btn.title = n
            ? `${n} tag(s) in the hidden menu · Ctrl+Shift+click a normal tag to move it here`
            : 'Hidden menu is empty · Ctrl+Shift+click a tag to move it here';
    }

    function setHiddenPanelOpen(open) {
        const panel = $('meta-hidden-panel');
        if (!panel) return;
        panel.classList.toggle('hidden', !open);
        if (open) renderHiddenTagsPanel();
    }

    function ensureHiddenPresetHosts() {
        const panel = $('meta-hidden-panel');
        if (!panel || $('meta-hidden-presets')) return;
        const wrap = document.createElement('div');
        wrap.id = 'meta-hidden-presets';
        wrap.className = 'meta-hidden-presets';
        wrap.innerHTML = [
            '<div class="meta-hidden-preset-label">On this file</div>',
            '<div id="meta-hidden-file-tags" class="meta-chip-row"></div>',
            '<div class="meta-hidden-preset-label">Recent</div>',
            '<div id="meta-hidden-recent" class="meta-recent-row"></div>',
            '<div class="meta-hidden-preset-label">Hotkeys</div>',
            '<div id="meta-hidden-hotkeys" class="meta-hotkey-bar"></div>',
            '<div class="meta-hidden-preset-label">E-set</div>',
            '<div id="meta-hidden-eset" class="hud-eset-slots meta-eset-slots"></div>',
            '<div class="meta-hidden-preset-label">Sprint</div>',
            '<div id="meta-hidden-sprint" class="meta-sprint-tags"></div>',
        ].join('');
        const list = $('meta-hidden-list');
        if (list) panel.insertBefore(wrap, list);
        else panel.appendChild(wrap);
    }

    function renderHiddenTagsPanel() {
        updateHiddenTagsButton();
        ensureHiddenPresetHosts();
        const list = $('meta-hidden-list');
        if (!list) return;
        const sorted = hiddenMenuTags();
        if (!sorted.length) {
            list.innerHTML = '<div class="meta-hidden-empty">Nothing in the hidden menu — Ctrl+Shift+click a tag, or right-click → Hidden</div>';
            return;
        }
        list.innerHTML = sorted.map((t) => {
            const scope = tagMenuScopeOf(t);
            const mark = scope === 'both' ? 'both' : 'hidden';
            return `<button type="button" class="meta-hidden-chip" data-tag="${escapeAttr(t)}" data-menu-scope="${mark}" title="Click applies · Ctrl+Shift+click moves “${escapeAttr(t)}” back to the normal menu">${escapeHtml(t)} · ${mark}</button>`;
        }).join('');
        list.querySelectorAll('.meta-hidden-chip').forEach((btn) => {
            try {
                globalThis.FAFOTagColors?.paint?.(btn, btn.dataset.tag, { onVideo: isTagOnVideo(btn.dataset.tag) });
            } catch (_) {}
        });
        if (!hiddenPanelOpen()) return;
        paintCurrentFileTags($('meta-hidden-file-tags'), 'hidden');
        paintRecentTagsInto($('meta-hidden-recent'), 'hidden');
        paintHotkeyBarInto($('meta-hidden-hotkeys'), {
            applyOnly: false,
            className: 'meta-hotkey-bar',
            menu: 'hidden',
        });
        renderExtraTagHud();
        paintSprintInto($('meta-hidden-sprint'), 'hidden');
    }

    function initHiddenMenuInteraction() {
        const list = $('meta-hidden-list');
        if (!list || list.dataset.fafoHiddenWired === '1') return;
        list.dataset.fafoHiddenWired = '1';
        list.addEventListener('click', (e) => {
            const btn = e.target?.closest?.('.meta-hidden-chip');
            if (!btn || !list.contains(btn)) return;
            e.preventDefault();
            e.stopPropagation();
            const tag = normalizeTag(btn.dataset.tag || '');
            if (!tag) return;
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey) {
                setTagMenuScope(tag, 'public').catch((err) => console.warn('menu scope', err));
                return;
            }
            ensureTagsKnown([tag], privateSpaceActive ? { forcePrivate: true } : {});
            toggleLibraryTag(tag, { allowRemove: false }).catch((err) => console.warn('hidden apply', err));
        });
        list.addEventListener('contextmenu', (e) => {
            const btn = e.target?.closest?.('.meta-hidden-chip');
            if (!btn || !list.contains(btn)) return;
            e.preventDefault();
            showTagContextMenu(e, btn.dataset.tag);
        });
    }

    async function moveHiddenOnlyToNormal() {
        const moving = hiddenMenuTags().filter((t) => tagMenuScopeOf(t) !== 'both');
        if (!moving.length) {
            if (els.status) els.status.textContent = 'No hidden-only tags to move (Both stays in both menus)';
            return;
        }
        await setTagMenuScope(moving, 'public');
    }

    /**
     * Count tags across THIS space's mediaMeta only.
     * Private file totals never include public media (and vice versa).
     */
    function rebuildLibraryTagCounts() {
        libraryTagCount = {};
        Object.values(mediaMeta || {}).forEach((m) => {
            userTagsOnly(m.tags || []).forEach((raw) => {
                const tag = normalizeTag(raw);
                if (!tag) return;
                const low = tag.toLowerCase();
                libraryTagCount[low] = (libraryTagCount[low] || 0) + 1;
            });
        });
    }

    /** Debounce expensive recount + re-render for large libraries. */
    function scheduleLibraryRecount(render = true) {
        clearTimeout(libraryRecountTimer);
        libraryRecountTimer = setTimeout(() => {
            rebuildLibraryTagCounts();
            sortTagLibrary();
            if (render) scheduleRenderTagLibrary();
        }, 80);
    }

    function scheduleRenderTagLibrary() {
        clearTimeout(renderLibraryTimer);
        renderLibraryTimer = setTimeout(() => renderTagLibrary(), 40);
    }

    /**
     * Rebuild apply (Uses) counts from library file tags.
     * Sets Uses# = number of files that currently have each tag.
     */
    async function rebuildApplyCountsFromLibrary() {
        const next = {};
        Object.values(mediaMeta || {}).forEach((m) => {
            (m.tags || []).forEach((raw) => {
                const t = normalizeTag(raw);
                if (!t) return;
                const low = t.toLowerCase();
                next[low] = (next[low] || 0) + 1;
                ensureTagsKnown([t]);
            });
        });
        sessionTagCount = next;
        recomputeSessionHasPicks();
        rebuildLibraryTagCounts();
        sortTagLibrary();
        await saveStore();
        renderTagLibrary();
        renderHotkeyBar();
        if (els.status) {
            const n = Object.keys(sessionTagCount).length;
            els.status.textContent = `Rebuilt Uses counts from library (${n} tags)`;
        }
    }

    /**
     * Recover tags/ratings from Windows Explorer file metadata (disk).
     * Requires S2 explorer-meta server. Merges into mediaMeta so wiped Chrome
     * storage / bad snapshots can be restored from what was written to files.
     *
     * @param {{ rescan?: boolean, onlyTagged?: boolean, maxFiles?: number, statusEl?: HTMLElement }} [opts]
     */
    async function rebuildMediaMetaFromDisk(opts = {}) {
        const statusEl = opts.statusEl || els.status;
        const setStatus = (msg) => {
            if (statusEl) statusEl.textContent = msg;
            try { console.info('[FAFO] rebuildFromDisk', msg); } catch (_) {}
        };

        if (!(await toolboxOnline())) {
            const msg = 'Start Explorer meta server (S2) first — explorer-meta\\START_META_SERVER.bat';
            setStatus(msg);
            throw new Error(msg);
        }

        setStatus('Rescanning Explorer library index…');
        try {
            await fetch(`${TOOLBOX_API}/library/rescan`, {
                method: 'POST',
                signal: AbortSignal.timeout(120000),
            });
        } catch (e) {
            console.warn('library rescan', e);
        }

        setStatus('Reading Tags + Rating from disk files…');
        let data;
        try {
            const r = await fetch(`${TOOLBOX_API}/library/export-tags`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    rescan: false,
                    only_tagged: opts.onlyTagged !== false,
                    max_files: Math.max(100, Math.min(50000, opts.maxFiles || 20000)),
                    offset: 0,
                }),
                signal: AbortSignal.timeout(600000),
            });
            if (!r.ok) {
                const t = await r.text().catch(() => '');
                throw new Error(`export-tags failed (${r.status}) ${t.slice(0, 120)}`);
            }
            data = await r.json();
        } catch (e) {
            setStatus('Disk export failed: ' + (e.message || e));
            throw e;
        }

        const items = Array.isArray(data?.items) ? data.items : [];
        let updated = 0;
        let created = 0;
        let tagsAdded = 0;

        for (const item of items) {
            const name = String(item.name || '').trim();
            if (!name) continue;
            const size = item.size != null ? Number(item.size) : null;
            const diskTags = userTagsOnly(item.tags || []);
            const diskRating = Math.max(0, Math.min(5, parseInt(item.rating, 10) || 0));
            if (!diskTags.length && !diskRating) continue;

            let key = null;
            let prev = null;
            if (globalThis.FAFOId?.findStoredMeta) {
                const hit = FAFOId.findStoredMeta(mediaMeta, { name, size, mtime: item.mtime });
                if (hit) {
                    key = hit.key;
                    prev = hit.meta;
                }
            }
            if (!key) {
                const byName = findStoredByName(name);
                if (byName && (size == null || byName.meta?.size == null || byName.meta.size === size)) {
                    key = byName.key;
                    prev = byName.meta;
                }
            }
            if (!key) {
                // Recovery key — stable enough for name+size; FAFOId will rematch later
                key = size != null
                    ? `file:${name}|${size}|0`
                    : `file:${name}|0|0`;
            }

            prev = prev || mediaMeta[key] || {};
            const prevTags = userTagsOnly(prev.tags || []);
            const map = new Map();
            // Disk first (source of truth for recovery), then keep any local-only extras
            diskTags.forEach((t) => map.set(String(t).toLowerCase(), normalizeTag(t)));
            prevTags.forEach((t) => {
                const low = String(t).toLowerCase();
                if (!map.has(low)) map.set(low, normalizeTag(t));
            });
            const merged = [...map.values()].filter(Boolean);
            tagsAdded += Math.max(0, merged.length - prevTags.length);
            const rating = diskRating || prev.rating || 0;
            const wasNew = !mediaMeta[key];

            mediaMeta[key] = {
                ...prev,
                name,
                size: size != null ? size : (prev.size ?? null),
                tags: merged,
                rating,
                path: item.path || prev.path,
                updated: Date.now(),
                recoveredFromDisk: true,
            };
            if (wasNew) created += 1;
            else updated += 1;
            ensureTagsKnown(merged);
        }

        rebuildTagLibraryFromMedia();
        // Grow-only Tag DB dual-write
        try {
            if (window.FAFOTagDb?.mergeTags) {
                await FAFOTagDb.mergeTags(tagDbStorageKey(), tagLibrary);
            }
        } catch (e) {
            console.warn('tag db merge after disk rebuild', e);
        }

        await rebuildApplyCountsFromLibrary();
        await saveStore();
        try {
            if (activeKey && mediaMeta[activeKey]) {
                activeTags = userTagsOnly(mediaMeta[activeKey].tags || []);
                activeRating = mediaMeta[activeKey].rating || 0;
                renderMetaPanel();
            }
        } catch (_) {}

        const msg =
            `Recovered from disk · ${data.scanned || 0} scanned · ${data.with_tags || 0} tagged files · ` +
            `${updated + created} media entries (${created} new) · +${tagsAdded} tag links`;
        setStatus(msg);
        return {
            ok: true,
            scanned: data.scanned || 0,
            withTags: data.with_tags || 0,
            updated,
            created,
            tagsAdded,
            returned: items.length,
        };
    }

    function sessionCountFor(tag) {
        return sessionTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function libraryCountFor(tag) {
        return libraryTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function isTagOnVideo(tag) {
        const low = normalizeTag(tag).toLowerCase();
        return activeTags.some((x) => x.toLowerCase() === low);
    }

    /** True tag chips only — not nested edit/menu controls that also carry data-tag. */
    function isTagChipElement(el) {
        if (!el || !el.classList) return false;
        if (el.classList.contains('meta-tag-act')) return false;
        if (el.closest?.('.meta-tag-actions') && !el.classList.contains('meta-lib-tag')) return false;
        return (
            el.classList.contains('meta-lib-tag') ||
            el.classList.contains('meta-hotkey-slot') ||
            el.classList.contains('meta-recent-tag') ||
            el.classList.contains('meta-chip') ||
            el.classList.contains('hud-eset-slot') ||
            el.classList.contains('meta-sprint-tag')
        );
    }

    /**
     * Keep on-file + multi-select state (and chosen/on-video color) consistent
     * on every panel where a tag chip appears — library, hotkeys, HUD, recents,
     * E-set, sprint, file chips — so you never re-activate a tag that is already on.
     */
    function syncAllTagUiState(root) {
        const scope = root || document;
        let nodes;
        try {
            nodes = scope.querySelectorAll(
                '.meta-lib-tag[data-tag], .meta-hotkey-slot[data-tag], .meta-recent-tag[data-tag], ' +
                '.meta-chip[data-tag], .hud-eset-slot[data-tag], .meta-sprint-tag[data-tag]'
            );
        } catch (_) {
            return;
        }
        nodes.forEach((el) => {
            if (!isTagChipElement(el)) return;
            const raw = el.getAttribute('data-tag') || el.dataset.tag || '';
            const t = normalizeTag(raw);
            if (!t) return;

            const on = isTagOnVideo(t);
            const sel = isTagSelected(t);

            el.classList.toggle('on-video', on);
            el.classList.toggle('state-on-current', on);
            if (el.classList.contains('meta-lib-tag')) {
                el.classList.toggle('off-video', !on);
            }
            el.classList.toggle('selected', sel);
            try {
                el.setAttribute('aria-selected', sel ? 'true' : 'false');
            } catch (_) {}

            const check = el.querySelector?.('.meta-lib-check');
            if (check) check.textContent = sel ? '✓' : '';

            try {
                const isFileChip =
                    el.classList.contains('meta-chip') && !el.classList.contains('meta-chip-pair');
                globalThis.FAFOTagColors?.paint?.(el, t, { onVideo: on || isFileChip });
            } catch (_) {}
        });
    }

    function recomputeSessionHasPicks() {
        sessionHasPicks = Object.values(sessionTagCount).some((n) => n > 0);
    }

    /** Primary sort key from toggle: apply counts (persisted) or library total. */
    function displayCountFor(tag) {
        if (countDisplayMode === 'total') return libraryCountFor(tag);
        if (sessionHasPicks) return sessionCountFor(tag);
        return libraryCountFor(tag); // seed until first apply
    }

    /**
     * Sort tag list by Uses (persisted apply counts) or Total (library frequency).
     */
    function sortTagLibrary() {
        tagLibrary.sort((a, b) => {
            const la = a.toLowerCase();
            const lb = b.toLowerCase();
            if (countDisplayMode === 'session' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ca = libraryTagCount[la] || 0;
            const cb = libraryTagCount[lb] || 0;
            if (cb !== ca) return cb - ca;
            if (countDisplayMode === 'total' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ta = tagLastUsed[la] || 0;
            const tb = tagLastUsed[lb] || 0;
            if (tb !== ta) return tb - ta;
            return a.localeCompare(b, undefined, { sensitivity: 'base' });
        });
    }

    function syncCountModeToggle() {
        const btn = $('meta-count-mode');
        if (!btn) return;
        const isTotal = countDisplayMode === 'total';
        btn.classList.toggle('active', isTotal);
        btn.dataset.mode = countDisplayMode;
        btn.textContent = isTotal ? 'Σ Totals' : 'Uses #';
        btn.title = isTotal
            ? 'Sort by library totals (files with tag) · click for apply counts (saved)'
            : 'Sort by apply counts (saved across reloads) · click for library totals';
    }

    function setCountDisplayMode(mode) {
        countDisplayMode = mode === 'total' ? 'total' : 'session';
        syncCountModeToggle();
        sortTagLibrary();
        renderTagLibrary();
        renderHotkeyBar();
        // Persist preferred sort mode
        chrome.storage.local.set({ fafoTagCountMode: countDisplayMode }).catch(() => {});
    }

    /** Debounced write of apply counts + last-used (cheap path between full saves). */
    function scheduleCountSave() {
        clearTimeout(countSaveTimer);
        countSaveTimer = setTimeout(() => {
            // CRITICAL: always write to the active space keys.
            const sk = spaceKeys();
            chrome.storage.local.set({
                [sk.applyCounts]: sessionTagCount,
                [sk.tagLastUsed]: tagLastUsed,
                [sk.tagLibrary]: tagLibrary.slice(),
            }).catch(() => {});
            schedulePersistTagDb();
        }, 200);
    }

    /** Cancel pending debounced space writes (call before flipping public/private). */
    function cancelPendingSpaceWrites() {
        clearTimeout(countSaveTimer);
        countSaveTimer = null;
        clearTimeout(libraryRecountTimer);
        libraryRecountTimer = null;
        clearTimeout(renderLibraryTimer);
        renderLibraryTimer = null;
        clearTimeout(tagDbSaveTimer);
        tagDbSaveTimer = null;
    }

    /**
     * Bump persisted apply counters when the user tags a clip.
     * Counts survive extension reloads / new tabs.
     */
    function pushRecentTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        recentTags = [t, ...recentTags.filter((x) => x.toLowerCase() !== low)].slice(0, 12);
        const sk = spaceKeys();
        chrome.storage.local.set({ [sk.recentTags]: recentTags }).catch(() => {});
        renderRecentTags();
    }

    function touchTags(tags, when = Date.now()) {
        const list = Array.isArray(tags) ? tags : [tags];
        let any = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            sessionHasPicks = true;
            sessionTagCount[low] = (sessionTagCount[low] || 0) + 1;
            sessionApplyEvents += 1;
            tagLastUsed[low] = when;
            const existing = tagLibrary.find((x) => x.toLowerCase() === low);
            if (!existing) tagLibrary.push(t);
            pushRecentTag(t);
            any = true;
        });
        if (any) {
            if (activeKey) sessionVideosTouched.add(activeKey);
            noteSessionFirstUsed(list);
            sortTagLibrary();
            scheduleCountSave();
            // Keep quick-select auto slots in sync (session only)
            if (!sessionAutoHotkeysPaused) {
                refillSessionAutoHotkeys();
                // Hotkey bar will refresh from renderMetaPanel / callers
            }
            scheduleLiveStats();
        }
    }

    /**
     * Decrement apply counters when the user removes a tag from a clip.
     * Never goes below 0; zeros are dropped from the map.
     * Library (file) totals are handled separately via rebuildLibraryTagCounts().
     */
    function untouchTags(tags) {
        const list = Array.isArray(tags) ? tags : [tags];
        let any = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            const cur = sessionTagCount[low] || 0;
            if (cur <= 0) return;
            const next = cur - 1;
            if (next <= 0) delete sessionTagCount[low];
            else sessionTagCount[low] = next;
            any = true;
        });
        if (any) {
            recomputeSessionHasPicks();
            sortTagLibrary();
            scheduleCountSave();
            scheduleLiveStats();
            if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
        }
    }

    /**
     * Add tags into the known vocabulary WITHOUT bumping apply counters.
     * Use when discovering tags from file metadata or catalog on load/play.
     * Still refreshes library (file) frequency so totals grow as clips appear.
     */
    function ensureTagsKnown(tags, opts = {}) {
        // Never import the other section's catalog into this section's vocabulary
        if (opts.publicCatalogOnly && privateSpaceActive) return false;
        if (opts.blockInPrivate && privateSpaceActive) return false;
        const list = userTagsOnly(Array.isArray(tags) ? tags : [tags]);
        let added = false;
        const forcePrivate = !!opts.forcePrivate || privateSpaceActive || (!!opts.respectSpace && privateSpaceActive);
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            if (isOversizedOrSuspectTag(t)) return;
            const low = t.toLowerCase();
            if (!tagLibrary.some((x) => x.toLowerCase() === low)) {
                tagLibrary.push(t);
                added = true;
            }
            // New / forced tags in private section stay private-only (legacy vault list)
            if (forcePrivate && !isPrivateTag(t)) {
                privateTags.push(t);
            }
        });
        if (added) {
            sortTagLibrary();
            // Grow opaque Tag DB — unused tags stay forever until user deletes
            schedulePersistTagDb();
        }
        if (forcePrivate) persistPrivateVault().catch(() => {});
        return added;
    }

    /**
     * When a video loads with tags, fold them into library frequency counts
     * so totals accumulate as you browse (not only after you re-tag).
     */
    function accumulateTagsFromMedia(tags) {
        const list = userTagsOnly(Array.isArray(tags) ? tags : [tags]);
        const changed = ensureTagsKnown(list);
        // Rebuild from full mediaMeta so we never double-count one file
        scheduleLibraryRecount(true);
        return changed;
    }

    /** Returns display label for a tag's assigned hotkey, or ''. */
    function hotkeySlotForTag(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return '';
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    return formatHotkeyLabel(b, s);
                }
            }
        }
        return '';
    }

    /** First user-assigned bank for a tag (-1 if none). Checks auto slots only if no user assignment. */
    function hotkeyBankForTag(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return -1;
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (normalizeTag(tagHotkeys[b]?.[s] || '').toLowerCase() === low) return b;
            }
        }
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (normalizeTag(sessionAutoHotkeys[b]?.[s] || '').toLowerCase() === low) return b;
            }
        }
        return -1;
    }

    // ─── Editable settings text (survives upgrades / easy hand-edit) ─────────
    function buildSettingsText() {
        const lines = [
            '# FAFO Ultimate Tab — user settings',
            '# Edit values and Import, or keep next to explorer-meta as fafo-user-settings.txt',
            '# Lines starting with # are comments. Format: key=value',
            `version=1`,
            `savedAt=${new Date().toISOString()}`,
            `countMode=${countDisplayMode}`,
            `skipTagged=${skipTaggedMode ? 1 : 0}`,
            `applyAndNext=${applyAndNextMode ? 1 : 0}`,
            `uiScale=${uiScale}`,
            `dockPos=${dockPos}`,
            `dockX=${Math.round(dockX)}`,
            `dockY=${Math.round(dockY)}`,
            `stickLayout=${stickLayout ? 1 : 0}`,
            `split=${$('meta-dock')?.classList.contains('layout-split') ? 1 : 0}`,
            `libX=${Math.round(libX)}`,
            `libY=${Math.round(libY)}`,
            `libW=${Math.round(libW)}`,
            `libH=${Math.round(libH)}`,
            `panelWidth=${Math.round(panelWidth || 0)}`,
            `panelHeight=${Math.round(panelHeight || 0)}`,
            `tagLibraryHeight=${Math.round(tagLibraryHeight)}`,
            `pinnedBank=${pinnedBank}`,
            `extraPinnedBank=${extraPinnedBank}`,
            '# hotkeys: bank.slot=tag  (bank 0=Base 1=Shift 2=Ctrl 3=Alt, slot 0-9)',
        ];
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                const t = tagHotkeys[b]?.[s];
                if (t) lines.push(`hotkey.${b}.${s}=${t}`);
            }
        }
        lines.push('# eset: bank.slot=tag');
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                const t = extraTagBanks[b]?.[s];
                if (t) lines.push(`eset.${b}.${s}=${t}`);
            }
        }
        if (excludedTags.length) {
            lines.push(`excluded=${excludedTags.join('|')}`);
        }
        return lines.join('\n') + '\n';
    }

    function parseSettingsText(text) {
        const out = {};
        const hotkeys = emptyHotkeyBanks();
        const esets = emptyExtraBanks();
        let hasHotkeys = false;
        let hasEset = false;
        String(text || '').split(/\r?\n/).forEach((line) => {
            const raw = line.trim();
            if (!raw || raw.startsWith('#')) return;
            const eq = raw.indexOf('=');
            if (eq < 0) return;
            const key = raw.slice(0, eq).trim();
            const val = raw.slice(eq + 1).trim();
            const hk = /^hotkey\.(\d+)\.(\d+)$/i.exec(key);
            if (hk) {
                const b = parseInt(hk[1], 10);
                const s = parseInt(hk[2], 10);
                if (b >= 0 && b < HOTKEY_BANKS && s >= 0 && s < HOTKEY_SLOTS) {
                    hotkeys[b][s] = normalizeTag(val);
                    hasHotkeys = true;
                }
                return;
            }
            const ek = /^eset\.(\d+)\.(\d+)$/i.exec(key);
            if (ek) {
                const b = parseInt(ek[1], 10);
                const s = parseInt(ek[2], 10);
                if (b >= 0 && b < EXTRA_BANKS && s >= 0 && s < EXTRA_SLOTS) {
                    esets[b][s] = normalizeTag(val);
                    hasEset = true;
                }
                return;
            }
            out[key] = val;
        });
        if (hasHotkeys) out._hotkeys = hotkeys;
        if (hasEset) out._eset = esets;
        return out;
    }

    function applySettingsObject(cfg) {
        if (!cfg || typeof cfg !== 'object') return false;
        let changed = false;
        const num = (k, min, max) => {
            if (cfg[k] == null || cfg[k] === '') return null;
            const n = Number(cfg[k]);
            if (!Number.isFinite(n)) return null;
            return Math.max(min, Math.min(max, n));
        };
        if (cfg.countMode === 'total' || cfg.countMode === 'session') {
            countDisplayMode = cfg.countMode;
            changed = true;
        }
        if (cfg.skipTagged != null) { skipTaggedMode = cfg.skipTagged === '1' || cfg.skipTagged === 'true'; changed = true; }
        if (cfg.applyAndNext != null) { applyAndNextMode = cfg.applyAndNext === '1' || cfg.applyAndNext === 'true'; changed = true; }
        const us = num('uiScale', UI_SCALE_MIN, UI_SCALE_MAX); if (us != null) { uiScale = us; changed = true; }
        if (['br', 'bl', 'tr', 'tl', 'free'].includes(cfg.dockPos)) { dockPos = cfg.dockPos; changed = true; }
        const dx = num('dockX', -5000, 20000); if (dx != null) { dockX = dx; changed = true; }
        const dy = num('dockY', -5000, 20000); if (dy != null) { dockY = dy; changed = true; }
        if (cfg.stickLayout != null) { stickLayout = cfg.stickLayout === '1' || cfg.stickLayout === 'true'; changed = true; }
        const lx = num('libX', -5000, 20000); if (lx != null) { libX = lx; libPosSaved = true; changed = true; }
        const ly = num('libY', -5000, 20000); if (ly != null) { libY = ly; libPosSaved = true; changed = true; }
        const lw = num('libW', 200, 2000); if (lw != null) { libW = lw; changed = true; }
        const lh = num('libH', 120, 2000); if (lh != null) { libH = lh; changed = true; }
        const pw = num('panelWidth', 0, 2000); if (pw != null && pw >= 260) { panelWidth = pw; changed = true; }
        const ph = num('panelHeight', 0, 2000); if (ph != null && ph >= 160) { panelHeight = ph; changed = true; }
        const th = num('tagLibraryHeight', 80, 900); if (th != null) { tagLibraryHeight = th; changed = true; }
        const pb = num('pinnedBank', 0, 3); if (pb != null) { pinnedBank = pb | 0; liveBank = pinnedBank; changed = true; }
        if (cfg.excluded != null) {
            excludedTags = String(cfg.excluded).split('|').map(normalizeTag).filter(Boolean);
            changed = true;
        }
        if (cfg._hotkeys) { tagHotkeys = cfg._hotkeys; changed = true; }
        if (cfg._eset) { extraTagBanks = cfg._eset; changed = true; }
        if (cfg.split != null) {
            const want = cfg.split === '1' || cfg.split === 'true';
            setLibrarySplit(want, { forceDefault: false });
            changed = true;
        }
        return changed;
    }

    async function persistSettingsText(text) {
        const body = text || buildSettingsText();
        try {
            await chrome.storage.local.set({
                fafoUserSettingsText: body,
                fafoUserSettingsAt: Date.now(),
            });
        } catch (_) {}
        // Companion server file (survives extension reloads / reinstalls if explorer-meta is kept)
        try {
            await fetch(`${TOOLBOX_API}/fafo/settings`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: body }),
                signal: AbortSignal.timeout(2500),
            });
        } catch (_) {}
        return body;
    }

    function scheduleSettingsExport() {
        clearTimeout(settingsSaveTimer);
        settingsSaveTimer = setTimeout(() => {
            persistSettingsText().catch(() => {});
        }, 400);
    }

    async function tryLoadSettingsFile() {
        // 1) Companion disk file wins (hand-edited)
        try {
            const r = await fetch(`${TOOLBOX_API}/fafo/settings`, {
                signal: AbortSignal.timeout(2000),
            });
            if (r.ok) {
                const j = await r.json();
                if (j && typeof j.text === 'string' && j.text.trim()) {
                    const cfg = parseSettingsText(j.text);
                    if (applySettingsObject(cfg)) {
                        applyDockLayout();
                        if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
                        renderMetaPanel();
                        if (els.status) els.status.textContent = 'Loaded settings from fafo-user-settings.txt';
                        return true;
                    }
                }
            }
        } catch (_) {}
        // 2) chrome.storage mirror
        try {
            const { fafoUserSettingsText } = await chrome.storage.local.get('fafoUserSettingsText');
            if (fafoUserSettingsText && String(fafoUserSettingsText).trim()) {
                const cfg = parseSettingsText(fafoUserSettingsText);
                if (applySettingsObject(cfg)) {
                    applyDockLayout();
                    if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
                    renderMetaPanel();
                    return true;
                }
            }
        } catch (_) {}
        return false;
    }

    async function downloadSettingsText() {
        const text = await persistSettingsText();
        const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'fafo-user-settings.txt';
        a.click();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
        if (els.status) els.status.textContent = 'Downloaded fafo-user-settings.txt';
    }

    async function importSettingsFromFile(file) {
        if (!file) return;
        const text = await file.text();
        const cfg = parseSettingsText(text);
        if (!applySettingsObject(cfg)) {
            if (els.status) els.status.textContent = 'Settings file had no known keys';
            return;
        }
        await persistSettingsText(text);
        await saveStore();
        applyDockLayout();
        if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
        renderMetaPanel();
        if (els.status) els.status.textContent = 'Imported settings from file';
    }

    function isLastVideoTag(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return false;
        return lastVideoTags.some((t) => t.toLowerCase() === low);
    }

    function matchesLiveTypeFilter(tag) {
        const q = (liveTypeFilter || '').trim();
        if (!q) return true;
        return tagMatchesQuery(tag, q);
    }

    function setLiveTypeFilter(raw) {
        liveTypeFilter = String(raw || '');
        // Keep library filter box in sync when present
        if (els.tagFilter && document.activeElement !== els.tagFilter) {
            els.tagFilter.value = liveTypeFilter;
        }
        renderTagLibrary();
        renderHotkeyBar();
        renderRecentTags();
        renderExtraTagHud();
        renderSprintUi();
    }

    function focusTagInput() {
        setMetaPanelOpen(true);
        const inp = els.tagInput || $('meta-tag-input');
        if (!inp) return;
        try {
            inp.focus();
            inp.select?.();
        } catch (_) {}
        if (els.status) els.status.textContent = 'Type to filter all tag lists · Tab completes · Enter applies';
    }

    function paintRecentTagsInto(row, menu) {
        if (!row) return;
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        const shown = recentTags.filter((t) => isTagListedIn(t, which));
        if (!shown.length) {
            row.innerHTML = which === 'hidden'
                ? '<span class="meta-chip-empty">No hidden-menu recents</span>'
                : '<span class="meta-chip-empty">Recent · apply here</span>';
            wireTagDropTarget(row, { kind: 'file' });
            return;
        }
        row.innerHTML = shown.map((t) => {
            const on = isTagOnVideo(t);
            const last = isLastVideoTag(t);
            const filtered = !matchesLiveTypeFilter(t);
            const cls = [
                'meta-recent-tag',
                on ? 'on-video' : '',
                last ? 'last-video' : '',
                filtered ? 'type-filtered-out' : '',
            ].filter(Boolean).join(' ');
            return `<button type="button" class="${cls}" draggable="true" data-tag="${escapeAttr(t)}" data-drag-src="recent" title="Click apply · right-click edit/delete/color${last ? ' · used on last video' : ''}">${escapeHtml(t)}</button>`;
        }).join('');
        row.querySelectorAll('[data-tag]').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (tagDragMoved) return;
                const t = normalizeTag(btn.dataset.tag);
                if (!t) return;
                if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey) {
                    setTagMenuScope(t, which === 'hidden' ? 'public' : 'hidden')
                        .catch((err) => console.warn('menu scope', err));
                    return;
                }
                // Make sure recents are in the active vocab so apply/autocomplete work
                ensureTagsKnown([t], privateSpaceActive ? { forcePrivate: true } : {});
                toggleLibraryTag(t, { allowRemove: false });
            });
            btn.addEventListener('contextmenu', (e) => showTagContextMenu(e, btn.dataset.tag));
            btn.addEventListener('dblclick', (e) => {
                e.preventDefault();
                e.stopPropagation();
                removeLibraryTagSafe(btn.dataset.tag);
            });
            markTagDragSource(btn, { kind: 'recent', tag: btn.dataset.tag });
            try {
                globalThis.FAFOTagColors?.paint?.(btn, btn.dataset.tag, {
                    onVideo: btn.classList.contains('on-video'),
                });
            } catch (_) {}
        });
        wireTagDropTarget(row, { kind: 'file' });
    }

    function renderRecentTags() {
        paintRecentTagsInto($('meta-recent-tags'), 'normal');
        paintRecentTagsInto($('hud-recent-tags'), 'normal');
        if (hiddenPanelOpen()) paintRecentTagsInto($('meta-hidden-recent'), 'hidden');
    }

    // ── Tag drag & drop (single delegated listeners — no stacked handlers) ──
    const TAG_DND_MIME = 'application/x-fafo-tag';
    /** Pixels of drag before we treat the gesture as a real drag (not a click). */
    const TAG_DRAG_THRESHOLD_PX = 10;
    let tagDragPayload = null;
    let tagDragMoved = false;
    let tagDragOrigin = null; // { x, y }
    let tagDndInited = false;

    /** Mark element as a drag source via data attributes only (no extra listeners per render). */
    function markTagDragSource(el, info) {
        if (!el || !info?.tag) return;
        el.setAttribute('draggable', 'true');
        el.dataset.tagDrag = '1';
        el.dataset.tag = normalizeTag(info.tag);
        el.dataset.dragSrc = info.kind || 'library';
        if (info.bank != null) el.dataset.dragBank = String(info.bank);
        if (info.slot != null) el.dataset.dragSlot = String(info.slot);
    }
    // Back-compat alias used by older call sites
    const wireTagDragSource = markTagDragSource;
    function wireTagDropTarget() { /* no-op: delegated */ }

    function initTagDndDelegation() {
        if (tagDndInited) return;
        tagDndInited = true;

        document.addEventListener('dragstart', (e) => {
            // Never start a tag-drag from edit/menu controls
            if (e.target?.closest?.('.meta-tag-act, .meta-tag-actions, button[data-i], [data-act]')) {
                e.preventDefault();
                return;
            }
            const el = e.target?.closest?.('[data-tag-drag="1"][data-tag]');
            if (!el) return;
            if (e.target.closest?.('button[data-i]')) {
                e.preventDefault();
                return;
            }
            const payload = {
                tag: normalizeTag(el.dataset.tag),
                source: el.dataset.dragSrc || 'library',
                bank: el.dataset.dragBank != null ? parseInt(el.dataset.dragBank, 10) : undefined,
                slot: el.dataset.dragSlot != null ? parseInt(el.dataset.dragSlot, 10) : undefined,
            };
            if (!payload.tag) {
                e.preventDefault();
                return;
            }
            tagDragPayload = payload;
            tagDragMoved = false;
            tagDragOrigin = { x: e.clientX || 0, y: e.clientY || 0 };
            try {
                e.dataTransfer.setData(TAG_DND_MIME, JSON.stringify(payload));
                e.dataTransfer.setData('text/plain', payload.tag);
                e.dataTransfer.effectAllowed = 'copyMove';
            } catch (_) {}
            el.classList.add('tag-dragging');
            document.body.classList.add('fafo-tag-dnd');
        }, true);

        document.addEventListener('drag', (e) => {
            if (!tagDragPayload || !tagDragOrigin) return;
            // Ignore tiny jitter — otherwise click-to-apply never fires on the history list
            const dx = (e.clientX || 0) - tagDragOrigin.x;
            const dy = (e.clientY || 0) - tagDragOrigin.y;
            if ((dx * dx + dy * dy) >= TAG_DRAG_THRESHOLD_PX * TAG_DRAG_THRESHOLD_PX) {
                tagDragMoved = true;
            }
        }, true);

        document.addEventListener('dragend', (e) => {
            const el = e.target?.closest?.('[data-tag-drag="1"]');
            el?.classList.remove('tag-dragging');
            document.body.classList.remove('fafo-tag-dnd');
            document.querySelectorAll('.tag-drop-hover').forEach((n) => n.classList.remove('tag-drop-hover'));
            // Only swallow the ghost click after a real drag (threshold passed)
            if (tagDragMoved && el) {
                const swallow = (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    el.removeEventListener('click', swallow, true);
                };
                el.addEventListener('click', swallow, true);
                setTimeout(() => el.removeEventListener('click', swallow, true), 50);
            }
            tagDragPayload = null;
            tagDragOrigin = null;
            // Keep flag briefly so the synthetic click after dragend is ignored;
            // clear soon so the next real click still works.
            setTimeout(() => { tagDragMoved = false; }, 50);
        }, true);

        document.addEventListener('dragover', (e) => {
            if (!tagDragPayload?.tag && !(e.dataTransfer?.types || []).length) return;
            const zone = resolveDropZoneEl(e.target);
            if (!zone) return;
            e.preventDefault();
            try { e.dataTransfer.dropEffect = 'copy'; } catch (_) {}
            document.querySelectorAll('.tag-drop-hover').forEach((n) => {
                if (n !== zone.el) n.classList.remove('tag-drop-hover');
            });
            zone.el.classList.add('tag-drop-hover');
        }, true);

        document.addEventListener('dragleave', (e) => {
            const el = e.target?.closest?.('.tag-drop-hover');
            if (el && !el.contains(e.relatedTarget)) el.classList.remove('tag-drop-hover');
        }, true);

        document.addEventListener('drop', async (e) => {
            const zone = resolveDropZoneEl(e.target);
            if (!zone) return;
            e.preventDefault();
            e.stopPropagation();
            document.querySelectorAll('.tag-drop-hover').forEach((n) => n.classList.remove('tag-drop-hover'));
            const p = tagDragPayload || readTagDragFallback(e);
            if (!p?.tag) return;
            tagDragMoved = true;
            await handleTagDrop(p, zone.target);
            tagDragPayload = null;
        }, true);
    }

    function readTagDragFallback(e) {
        try {
            const raw = e.dataTransfer?.getData(TAG_DND_MIME) || '';
            if (raw) return JSON.parse(raw);
        } catch (_) {}
        try {
            const t = normalizeTag(e.dataTransfer?.getData('text/plain') || '');
            return t ? { tag: t, source: 'external' } : null;
        } catch (_) {
            return null;
        }
    }

    /** Map DOM node under cursor → single drop target (one drop = one action). */
    function resolveDropZoneEl(start) {
        if (!start || !start.closest) return null;
        // Prefer specific slot/chip targets over containers
        const esetSlot = start.closest('[data-eset-slot]');
        if (esetSlot && (esetSlot.closest('#meta-eset-slots') || esetSlot.closest('#hud-eset-slots'))) {
            const bank = extraLiveBank;
            const slot = parseInt(esetSlot.dataset.esetSlot, 10);
            return { el: esetSlot, target: { kind: 'eset', bank, slot } };
        }
        const hkSlot = start.closest('.meta-hotkey-slot[data-slot]');
        if (hkSlot) {
            return {
                el: hkSlot,
                target: {
                    kind: 'hotkey',
                    bank: parseInt(hkSlot.dataset.bank, 10) || 0,
                    slot: parseInt(hkSlot.dataset.slot, 10) || 0,
                },
            };
        }
        const zoneEl = start.closest('[data-drop-zone]');
        if (!zoneEl) return null;
        const z = zoneEl.dataset.dropZone;
        if (z === 'file') return { el: zoneEl, target: { kind: 'file' } };
        if (z === 'library') return { el: zoneEl, target: { kind: 'library' } };
        if (z === 'eset-auto') {
            const bank = extraLiveBank;
            const row = extraTagBanks[bank] || [];
            let slot = row.findIndex((x) => !normalizeTag(x));
            if (slot < 0) slot = EXTRA_SLOTS - 1; // full → replace last, not fill all
            return { el: zoneEl, target: { kind: 'eset', bank, slot } };
        }
        return null;
    }

    async function handleTagDrop(payload, target) {
        const tag = normalizeTag(payload.tag);
        if (!tag) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(tag)) {
            if (els.status) els.status.textContent = 'Pair/system tags can’t be dropped into user lists';
            return;
        }
        const t = userTagsOnly([tag])[0] || tag;
        if (!t) return;

        // ── Drop onto current file tags ──
        if (target.kind === 'file') {
            if (!activeKey) {
                setMetaPanelOpen(true);
                if (els.status) els.status.textContent = 'No media to tag';
                return;
            }
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                await persistActiveMeta({ touchedTags: [t] });
                if (els.status) els.status.textContent = `Dropped onto file: ${t}`;
            } else if (els.status) {
                els.status.textContent = `Already on file: ${t}`;
            }
            return;
        }

        // ── Drop chip back onto library = remove from file ──
        if (target.kind === 'library') {
            ensureTagsKnown([t]);
            if (payload.source === 'chip' || payload.source === 'file') {
                const idx = activeTags.findIndex((x) => x.toLowerCase() === t.toLowerCase());
                if (idx >= 0) {
                    const [removed] = activeTags.splice(idx, 1);
                    await persistActiveMeta({ removedTags: [removed || t] });
                    if (els.status) els.status.textContent = `Removed from file → list: ${t}`;
                    return;
                }
            }
            await saveStore();
            renderTagLibrary();
            if (els.status) els.status.textContent = `In tag list: ${t}`;
            return;
        }

        // ── Hotkey slot ──
        if (target.kind === 'hotkey') {
            const bank = target.bank | 0;
            const slot = target.slot | 0;
            clearTagFromAllHotkeys(t);
            setHotkey(bank, slot, t);
            await saveStore();
            renderHotkeyBar();
            renderTagLibrary();
            if (els.status) els.status.textContent = `Hotkey ${formatHotkeyLabel(bank, slot)} ← ${t}`;
            // Optional: if dragged from another hotkey slot, clear source
            if (payload.source === 'hotkey' && payload.bank != null && payload.slot != null) {
                if (payload.bank !== bank || payload.slot !== slot) {
                    if (getHotkey(payload.bank, payload.slot)?.toLowerCase() === t.toLowerCase()) {
                        setHotkey(payload.bank, payload.slot, '');
                        await saveStore();
                        renderHotkeyBar();
                    }
                }
            }
            return;
        }

        // ── E-set slot ──
        if (target.kind === 'eset') {
            const bank = target.bank != null ? target.bank : extraLiveBank;
            const slot = target.slot | 0;
            setExtraTag(bank, slot, t);
            ensureTagsKnown([t]);
            await saveStore();
            renderExtraTagHud();
            if (els.status) els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}[${slot + 1}] ← ${t}`;
            if (payload.source === 'eset' && payload.bank != null && payload.slot != null) {
                if (payload.bank !== bank || payload.slot !== slot) {
                    if (getExtraTag(payload.bank, payload.slot)?.toLowerCase() === t.toLowerCase()) {
                        setExtraTag(payload.bank, payload.slot, '');
                        await saveStore();
                        renderExtraTagHud();
                    }
                }
            }
            return;
        }
    }

    function setExplorerHelpOpen(open) {
        const help = $('meta-explorer-help');
        if (!help) return;
        help.classList.toggle('hidden', !open);
        if (open) refreshWatchedFolderHelp();
    }

    function noteExplorerWrite(ok, note) {
        explorerWriteOk = ok == null ? null : !!ok;
        explorerWriteNote = String(note || '');
        updateExplorerStatusUi();
    }

    function explorerStatusPaint(state, text, title) {
        document.querySelectorAll('.meta-explorer-status').forEach((el) => {
            const extra = [];
            if (el.classList.contains('hud-chrome-btn')) extra.push('hud-chrome-btn');
            el.className = ['meta-explorer-status', state].concat(extra).filter(Boolean).join(' ');
            el.textContent = text;
            el.title = title;
        });
        paintDiskPip(state, text, title);
    }

    function paintDiskPip(state, text, title) {
        const pip = $('fafo-disk-pip');
        if (!pip) return;
        pip.className = 'fafo-disk-pip ' + (state || 'unknown');
        pip.title = title || text || 'Disk tag server';
        pip.setAttribute('aria-label', pip.title);
        pip.dataset.state = state || 'unknown';
        const word = pip.querySelector('.fafo-disk-pip-word');
        if (word) {
            word.textContent = ({
                online: 'On',
                offline: 'Off',
                busy: '…',
                pending: 'Wait',
                'write-fail': 'Fail',
                unknown: 'Disk',
            })[state] || 'Disk';
        }
        try {
            document.body.classList.toggle('fafo-disk-online', state === 'online');
            document.body.classList.toggle('fafo-disk-offline', state === 'offline');
        } catch (_) {}
    }

    function ledgerSpace() {
        return privateSpaceActive ? 'private' : 'public';
    }

    function ledgerStatsSafe() {
        try {
            return globalThis.FAFOMetaLedger?.stats?.(ledgerSpace()) || {};
        } catch {
            return {};
        }
    }

    function updateExplorerStatusUi() {
        if (explorerOnline === null) {
            explorerStatusPaint(
                'unknown',
                'Disk · …',
                'Windows file tags server — click to check or launch. (Not library permissions.)'
            );
            return;
        }
        if (!explorerOnline) {
            explorerStatusPaint(
                companionBootFails >= 4 ? 'offline' : 'busy',
                companionBootFails >= 4 ? 'Disk · OFF' : 'Disk · starting…',
                companionBootFails >= 4
                    ? 'File-tag server did not start. Run explorer-meta\\INSTALL_DEPS.bat once, then reload FAFO. Tags still save in FAFO.'
                    : 'File-tag server is launching in the background. Tags still save in FAFO.'
            );
            return;
        }
        const pending = (typeof dirtyDiskKeys !== 'undefined' && dirtyDiskKeys)
            ? dirtyDiskKeys.size
            : 0;
        const reviewN = Number(ledgerStatsSafe().review) || 0;
        if (reviewN > 0) {
            explorerStatusPaint(
                'write-fail',
                'Disk · ' + reviewN + ' FAILED · review',
                reviewN + ' file(s) failed 3 times. Click to review, skip, or drop them from the queue.'
            );
            return;
        }
        if (explorerWriteOk === false) {
            explorerStatusPaint(
                'write-fail',
                pending ? ('Disk · WRITE FAIL · ' + pending) : 'Disk · WRITE FAIL',
                explorerWriteNote
                    ? ('Server is up but last file write failed: ' + explorerWriteNote + '. Click to retry / index play folders.')
                    : 'Server is up but last file write failed. Click to retry.'
            );
            return;
        }
        if (pending) {
            explorerStatusPaint(
                'pending',
                'Disk · PENDING · ' + pending,
                pending + ' clip(s) waiting to write Windows Tags/Rating. Click to flush now.'
            );
            return;
        }
        explorerStatusPaint(
            'online',
            'Disk · ON',
            'Windows Explorer tags ON. Auto-starts with FAFO — no separate server window.'
        );
    }

    async function pollExplorerStatus() {
        const wasOnline = explorerOnline;
        try {
            explorerOnline = await toolboxOnline();
        } catch {
            explorerOnline = false;
        }
        if (explorerOnline) companionBootFails = 0;
        if (!explorerOnline && autoDiskSync && companionBootFails < 4) {
            ensureCompanionRunning({ timeoutMs: 16000 }).then((ok) => {
                explorerOnline = !!ok;
                if (!ok) companionBootFails += 1;
                else companionBootFails = 0;
                updateExplorerStatusUi();
                if (ok) {
                    flushDirtyDiskMeta().catch(() => {});
                    if (els.status) els.status.textContent = 'Disk server on · writing tags to files';
                } else if (companionBootFails >= 4 && els.status) {
                    els.status.textContent = 'Disk server off · run explorer-meta\\INSTALL_DEPS.bat once, then reload';
                }
            }).catch(() => { companionBootFails += 1; });
        } else if (explorerOnline && wasOnline === false && dirtyDiskKeys.size) {
            flushDirtyDiskMeta().catch(() => {});
        }
        updateExplorerStatusUi();
        return explorerOnline;
    }

    function startExplorerPoll() {
        pollExplorerStatus();
        clearInterval(explorerPollTimer);
        explorerPollTimer = setInterval(pollExplorerStatus, 12000);
        try {
            chrome.runtime.onMessage.addListener((msg) => {
                if (!msg || msg.type !== 'fafo-companion-up') return;
                explorerOnline = true;
                updateExplorerStatusUi();
                flushDirtyDiskMeta().catch(() => {});
            });
        } catch (_) {}
    }

    let companionEnsureInFlight = null;

    async function ensureCompanionRunning(opts = {}) {
        const timeoutMs = Number(opts.timeoutMs) || 18000;
        if (await toolboxOnline()) return true;
        if (companionEnsureInFlight) return companionEnsureInFlight;
        explorerStatusPaint('busy', 'Disk · starting…', 'Launching Explorer companion in the background…');
        if (els.status) els.status.textContent = 'Starting file-tag server…';
        companionEnsureInFlight = (async () => {
            try {
                await chrome.runtime.sendMessage({
                    type: 'fafo-boot-stack',
                    reason: opts.user ? 'status-click' : 'poll',
                    force: !!opts.user,
                });
            } catch (_) {}
            const t0 = Date.now();
            while (Date.now() - t0 < timeoutMs) {
                await new Promise((r) => setTimeout(r, 400));
                if (await toolboxOnline()) return true;
            }
            return false;
        })().finally(() => { companionEnsureInFlight = null; });
        return companionEnsureInFlight;
    }

    async function syncPlayFoldersToCompanion() {
        try {
            if (!globalThis.FAFOLibrary?.openDB || !FAFOLibrary.listFolders) return null;
            const db = await FAFOLibrary.openDB();
            const space = privateSpaceActive ? 'private' : 'public';
            const folders = await FAFOLibrary.listFolders(db, {
                space,
                vaultId: privateSpaceActive ? currentVaultId() : undefined,
            });
            const names = [...new Set((folders || []).map((f) => f.name || f.handle?.name).filter(Boolean))];
            if (!names.length) return null;
            const r = await fetch(`${TOOLBOX_API}/library/ensure-folders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ names }),
                signal: AbortSignal.timeout(20000),
            });
            return await r.json().catch(() => ({}));
        } catch (e) {
            console.warn('ensure play folders', e);
            return null;
        }
    }

    function folderLeaf(path) {
        const s = String(path || '').replace(/[\\/]+$/, '');
        const parts = s.split(/[/\\]/);
        return parts[parts.length - 1] || s;
    }

    async function refreshWatchedFolderHelp() {
        const box = $('meta-explorer-watch-list');
        if (!box) return;
        try {
            const r = await fetch(`${TOOLBOX_API}/library`, { signal: AbortSignal.timeout(5000) });
            const data = await r.json().catch(() => ({}));
            const dirs = Array.isArray(data.watched_dirs) ? data.watched_dirs : [];
            if (!dirs.length) {
                box.innerHTML = '<li>None yet — click Add folder…</li>';
                return;
            }
            box.innerHTML = dirs.map((d) => {
                const safe = String(d).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
                return `<li title="${safe}">${safe}</li>`;
            }).join('');
        } catch {
            box.innerHTML = '<li>Server offline — start Disk first</li>';
        }
    }

    /**
     * Open a Windows mini-Explorer picker on the companion.
     * Picked folder includes every subfolder (rolled up).
     */
    async function pickDiskFolderViaCompanion() {
        const pickBtn = $('meta-explorer-add-folder');
        if (pickBtn) pickBtn.disabled = true;
        explorerStatusPaint('busy', 'Disk · pick folder…', 'Windows folder picker — all subfolders included');
        if (els.status) {
            els.status.textContent = 'Opening folder picker… pick the parent (subfolders included)';
        }
        try {
            let online = false;
            try {
                online = await ensureCompanionRunning({ timeoutMs: 14000, user: true });
            } catch {
                online = false;
            }
            explorerOnline = online;
            if (!online) {
                if (els.status) {
                    els.status.textContent = 'Disk server OFF — click Disk to start it, then Add folder…';
                }
                setExplorerHelpOpen(true);
                updateExplorerStatusUi();
                return { online: false };
            }
            const r = await fetch(`${TOOLBOX_API}/library/pick-folder`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: '{}',
                signal: AbortSignal.timeout(180000),
            });
            const data = await r.json().catch(() => ({}));
            if (data.cancelled) {
                if (els.status) els.status.textContent = 'Folder pick cancelled';
                updateExplorerStatusUi();
                return data;
            }
            if (!r.ok || data.ok === false) {
                const detail = data.detail || data.error || r.statusText || 'pick failed';
                throw new Error(typeof detail === 'string' ? detail : JSON.stringify(detail));
            }
            const n = Number(data.files_indexed) || 0;
            const name = folderLeaf(data.path);
            const extra = data.already_covered
                ? ' (already inside a watched parent)'
                : (Array.isArray(data.dropped_children) && data.dropped_children.length
                    ? ` · rolled up ${data.dropped_children.length} nested`
                    : '');
            if (els.status) {
                els.status.textContent = `Watching ${name} · ${n} file(s), subfolders included${extra}`;
            }
            noteExplorerWrite(true, '');
            await refreshWatchedFolderHelp();
            updateExplorerStatusUi();
            return data;
        } catch (e) {
            const msg = e?.message || String(e);
            if (els.status) els.status.textContent = `Folder pick: ${msg}`;
            noteExplorerWrite(false, msg);
            updateExplorerStatusUi();
            return { ok: false, error: msg };
        } finally {
            if (pickBtn) pickBtn.disabled = false;
        }
    }

    /**
     * Check companion server, optional rescan, write current clip tags to disk.
     * This is Windows Explorer Tags/Rating — not Chrome library Restore Access.
     */
    async function syncExplorerNow(opts = {}) {
        const syncBtn = $('meta-explorer-sync');
        const showHelpIfOffline = opts.showHelpIfOffline !== false;

        if (syncBtn) {
            syncBtn.disabled = true;
            syncBtn.textContent = '…';
        }
        explorerStatusPaint('busy', 'Disk · check…', 'Checking file-tag server…');
        if (els.status) {
            els.status.textContent = 'Checking Windows Explorer tag server (127.0.0.1:8765)…';
        }

        let online = false;
        try {
            online = await ensureCompanionRunning({ timeoutMs: 14000, user: true });
        } catch {
            online = false;
        }
        explorerOnline = online;
        updateExplorerStatusUi();

        if (!online) {
            if (syncBtn) {
                syncBtn.disabled = false;
                syncBtn.textContent = 'Sync';
            }
            if (els.status) {
                els.status.textContent =
                    'Disk server starting in the background — tagging still saves in FAFO';
            }
            if (showHelpIfOffline) setExplorerHelpOpen(true);
            return { online: false };
        }

        try {
            explorerStatusPaint('busy', 'Disk · folders…', 'Indexing play folders for tag writes…');
            await syncPlayFoldersToCompanion();
        } catch (_) {}

        setExplorerHelpOpen(false);
        let rescanOk = false;
        try {
            explorerStatusPaint('busy', 'Disk · rescan…', 'Rescanning indexed folders…');
            const r = await fetch(`${TOOLBOX_API}/library/rescan`, {
                method: 'POST',
                signal: AbortSignal.timeout(20000),
            });
            rescanOk = r.ok;
        } catch {
            rescanOk = false;
        }

        // Ensure we have an active clip identity for write (playlist may be ready
        // while bind never ran because getFile/permission failed first).
        let writeMsg = '';
        try {
            if (!activeKey) {
                const item = window.FAFOPlayer?.getCurrentItem?.();
                const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
                if (item) await bindToItem(item, idx);
            }
        } catch (_) {}

        if (activeKey && activeName) {
            try {
                explorerStatusPaint('busy', 'Disk · write…', 'Writing Tags/Rating to this file…');
                // Force immediate write (not only debounced)
                clearTimeout(diskSyncTimer);
                await syncFileMetadataToDiskNow();
                writeMsg = ' · wrote current file';
            } catch (e) {
                writeMsg = ' · write failed';
            }
        } else {
            const plLen = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
            writeMsg = plLen
                ? ' · clip not bound — click Restore Access / play a video first'
                : ' · no media in playlist — link folders in Options';
            if (els.filename) {
                els.filename.textContent = activeName || (plLen ? 'Clip not ready' : 'No media');
            }
        }

        updateExplorerStatusUi();
        if (syncBtn) {
            syncBtn.disabled = false;
            syncBtn.textContent = 'Sync';
        }
        if (els.status) {
            els.status.textContent = rescanOk
                ? `Explorer ON · library rescanned${writeMsg}`
                : `Explorer ON · rescan skipped/failed${writeMsg}`;
        }
        harvestTagsFromServer().catch(() => {});
        return { online: true, rescanOk };
    }

    function updateApplyNextBtn() {
        const btn = $('meta-apply-next');
        if (!btn) return;
        btn.classList.toggle('active', applyAndNextMode);
        btn.setAttribute('aria-pressed', applyAndNextMode ? 'true' : 'false');
        btn.textContent = applyAndNextMode ? 'Apply+Next · ON' : 'Apply+Next';
        btn.title = applyAndNextMode
            ? 'ON: applying a tag advances to next clip. Click to turn off.'
            : 'When ON, applying a tag also goes to Next (bulk tagging)';
    }

    let pendingTagFocusRestore = null;

    function captureTagFocus() {
        const ae = document.activeElement;
        if (ae && (ae.id === 'hud-tag-input' || ae.classList?.contains('hud-tag-input'))) return 'hud';
        if (ae && (ae.id === 'meta-tag-input' || ae.closest?.('#meta-panel, #meta-dock'))) return 'panel';
        if (metaPanelOpen) return 'panel';
        return $('hud-tag-input') ? 'hud' : 'panel';
    }

    function restoreTagFocus(where) {
        const target = where || pendingTagFocusRestore;
        pendingTagFocusRestore = null;
        if (target === 'hud') {
            const inp = $('hud-tag-input');
            if (inp) {
                try { inp.focus(); } catch (_) {}
                return;
            }
        }
        try { focusTagInput(); } catch (_) {}
    }

    async function maybeApplyAndNext() {
        if (!applyAndNextMode) return;
        pendingTagFocusRestore = captureTagFocus();
        try {
            window.FAFOPlayer?.skipTrack?.(1);
        } catch (_) {}
        // bindToItem restores focus; retry if playNext is still opening the file
        setTimeout(() => {
            if (pendingTagFocusRestore) restoreTagFocus(pendingTagFocusRestore);
        }, 280);
    }

    async function exportTagsBackup() {
        if (!globalThis.FAFOBackup?.exportToDownload) {
            if (els.status) els.status.textContent = 'Backup module missing';
            return;
        }
        try {
            await FAFOBackup.exportToDownload({ includeConfig: false });
            const s = await FAFOBackup.statusSummary?.();
            if (els.status) {
                const when = s?.snapshotAt ? new Date(s.snapshotAt).toLocaleString() : 'now';
                els.status.textContent = `Exported tags backup · snapshot ${when}`;
            }
            updateBackupStatusUi();
        } catch (e) {
            if (els.status) els.status.textContent = 'Export failed: ' + (e.message || e);
        }
    }

    /**
     * Realtime tagging stats from in-memory meta + playlist + dirty Explorer queue.
     * Debounced so rapid tagging stays smooth.
     */
    function scheduleLiveStats() {
        clearTimeout(liveStatsTimer);
        liveStatsTimer = setTimeout(() => {
            try { updateLiveStatsUi(); } catch (_) {}
        }, 80);
    }

    function getPlaylistItems() {
        try {
            return window.FAFOPlayer?.getPlaylist?.()
                || window.FAFOPlayer?.playlist
                || window.FAFOPlayer?.getItems?.()
                || window.FAFOPlayer?.items
                || [];
        } catch {
            return [];
        }
    }

    function computeLiveStats() {
        const list = getPlaylistItems();
        const plN = Array.isArray(list) ? list.length : 0;

        let metaTagged = 0;
        let metaUntagged = 0;
        let totalApplies = 0;
        let rated = 0;
        const uniqueOnFiles = new Set();
        Object.values(mediaMeta || {}).forEach((m) => {
            const tags = userTagsOnly(m?.tags || []);
            if (tags.length) {
                metaTagged++;
                tags.forEach((t) => uniqueOnFiles.add(String(t).toLowerCase()));
                totalApplies += tags.length;
            } else {
                metaUntagged++;
            }
            if ((Number(m?.rating) || 0) > 0) rated++;
        });

        // Playlist-aware remaining (best when player has the full list)
        let plTagged = 0;
        let plUntagged = 0;
        if (plN > 0) {
            list.forEach((it) => {
                const n = tagCountForItem(it);
                if (n > 0) plTagged++;
                else plUntagged++;
            });
        }

        const total = plN > 0 ? plN : (metaTagged + metaUntagged);
        const tagged = plN > 0 ? plTagged : metaTagged;
        const remaining = plN > 0 ? plUntagged : metaUntagged;
        const vocab = Array.isArray(tagLibrary) ? tagLibrary.filter((t) => isInNormalTagMenu(t)).length : 0;
        const sessionApplies = Object.values(sessionTagCount || {}).reduce((a, b) => a + (Number(b) || 0), 0);
        const sessionUnique = Object.values(sessionTagCount || {}).filter((n) => (Number(n) || 0) > 0).length;
        const sessionClips = sessionVideosTouched.size;
        const pendingDisk = dirtyDiskKeys?.size || 0;
        const pct = total > 0 ? Math.round((tagged / total) * 1000) / 10 : 0;

        return {
            total,
            tagged,
            remaining,
            pct,
            vocab: vocab || uniqueOnFiles.size,
            uniqueOnFiles: uniqueOnFiles.size,
            totalApplies,
            rated,
            sessionApplies: sessionApplies || sessionApplyEvents,
            sessionUnique,
            sessionClips,
            sessionEvents: sessionApplyEvents,
            pendingDisk,
            autoDiskSync: !!autoDiskSync,
            playlistMode: plN > 0,
            metaEntries: Object.keys(mediaMeta || {}).length,
        };
    }

    function updateLiveStatsUi() {
        const root = $('meta-live-stats');
        if (!root) return;
        const s = computeLiveStats();
        const set = (id, text, cls) => {
            const el = $(id);
            if (!el) return;
            el.textContent = text;
            if (cls !== undefined) {
                el.classList.remove('ok', 'warn', 'danger');
                if (cls) el.classList.add(cls);
            }
        };

        set('mls-tagged', String(s.tagged), 'ok');
        set('mls-tagged-sub', s.playlistMode
            ? `of ${s.total} in playlist · ${s.pct}%`
            : `of ${s.total} meta · ${s.pct}%`);

        set('mls-remaining', String(s.remaining), s.remaining > 0 ? 'warn' : 'ok');
        set('mls-remaining-sub', s.remaining === 0 ? 'all tagged 🎉' : 'still untagged');

        set('mls-tags', String(s.vocab));
        set('mls-tags-sub', `${s.uniqueOnFiles} used on files`);

        set('mls-session', `${s.sessionApplies}`, s.sessionApplies > 0 ? 'ok' : undefined);
        set('mls-session-sub', `${s.sessionUnique} names · ${s.sessionClips} clip(s)`);

        set('mls-pending', String(s.pendingDisk),
            s.pendingDisk > 0 ? 'danger' : (s.autoDiskSync ? 'ok' : 'warn'));
        set('mls-pending-sub', s.pendingDisk > 0
            ? (s.autoDiskSync
                ? 'Explorer write queue · FAFO already saved'
                : 'Auto-sync off · click Sync or turn Auto-sync on')
            : (s.autoDiskSync ? 'disk queue empty · all flushed' : 'Auto-sync off'));

        try { renderFailQueue(); } catch (_) {}

        set('mls-applies', String(s.totalApplies));
        set('mls-applies-sub', `chips on files · ${s.rated} rated · meta ${s.metaEntries}`);

        const bar = $('mls-progress');
        if (bar) bar.style.width = Math.max(0, Math.min(100, s.pct)) + '%';

        const pulse = $('meta-live-stats-pulse');
        if (pulse) pulse.classList.toggle('pending', s.pendingDisk > 0);

        const foldSum = $('meta-fold-tracker-summary');
        if (foldSum) {
            foldSum.textContent = `${s.tagged}/${s.total} tagged · ${s.remaining} left · sess ${s.sessionApplies}`;
        }

        root.title = [
            `TOTAL: ${s.tagged}/${s.total} tagged (${s.pct}%) · ${s.remaining} remaining`,
            `Tags: ${s.vocab} vocabulary · ${s.uniqueOnFiles} on files · ${s.totalApplies} applies`,
            `SESSION: ${s.sessionApplies} applies · ${s.sessionUnique} names · ${s.sessionClips} clips`,
            `NOT ON DISK: ${s.pendingDisk} file(s) waiting for Explorer` +
                (s.autoDiskSync ? ' (auto-sync ON)' : ' (auto-sync OFF)'),
            'FAFO chrome storage saves instantly; “not on disk” = Windows file metadata queue.',
        ].join('\n');
    }

    async function updateBackupStatusUi() {
        scheduleLiveStats();
        const el = $('meta-backup-status');
        if (!el || !globalThis.FAFOBackup?.statusSummary) return;
        try {
            // Prefer player playlist length as library total when available
            let libraryTotal;
            let libraryKeys;
            try {
                const list = getPlaylistItems();
                if (Array.isArray(list) && list.length) {
                    libraryTotal = list.length;
                    libraryKeys = [];
                    for (const it of list) {
                        try {
                            let k = it?.mediaKey || '';
                            if (!k && globalThis.FAFOId?.keyFromFile && it?.file) {
                                k = FAFOId.keyFromFile(it.file, it.name || it.file.name);
                            }
                            if (!k && it?.name && it?.size != null) {
                                k = `file:${it.name}|${it.size}|${it.lastModified || it.mtime || 0}`;
                            }
                            if (!k && it?.name) k = `name:${String(it.name).toLowerCase()}`;
                            if (k) libraryKeys.push(k);
                        } catch (_) {}
                    }
                }
            } catch (_) {}

            const s = await FAFOBackup.statusSummary({ libraryTotal, libraryKeys });
            const c = s.coverage || {};
            const when = s.snapshotAt ? new Date(s.snapshotAt).toLocaleString() : 'never';
            const tagged = c.libraryTagged ?? c.filesWithTags ?? 0;
            const untagged = c.libraryUntagged != null
                ? c.libraryUntagged
                : (c.filesWithoutTagsInMeta ?? 0);
            const libN = c.libraryTotal != null ? c.libraryTotal : (c.mediaMetaEntries ?? s.liveMedia ?? 0);
            const tagsN = c.totalTagsRecorded ?? s.liveTags ?? 0;
            const live = computeLiveStats();

            el.textContent =
                `Backup · ${tagsN} tags · ${tagged} tagged / ${untagged} untagged · lib ${libN}` +
                (live.pendingDisk ? ` · ⏳ ${live.pendingDisk} pending disk` : '') +
                ` · ${when}`;
            el.title = [
                `Tags recorded (vocabulary): ${tagsN}`,
                `Unique tags on files: ${c.uniqueTagsOnFiles ?? 0}`,
                `Total tag applies: ${c.totalTagApplications ?? 0}`,
                `Files with tags: ${c.filesWithTags ?? 0}`,
                `Untagged (library): ${untagged}${c.libraryTotal != null ? ` of ${c.libraryTotal}` : ' (meta only)'}`,
                `Meta records: ${c.mediaMetaEntries ?? 0}`,
                `Rated: ${c.filesWithRating ?? 0} · pairs: ${s.livePairs ?? 0}`,
                `Session: ${live.sessionApplies} applies · ${live.sessionClips} clips`,
                `Explorer pending: ${live.pendingDisk}`,
                `History slots: ${s.historyCount || 0}`,
                `Last snapshot: ${when}`,
            ].join('\n');
        } catch {
            el.textContent = 'Backup · —';
            el.title = '';
        }
    }

    async function loadStore() {
        try {
            // Auto-recover if live meta was wiped but a snapshot/history exists
            if (globalThis.FAFOBackup?.tryRecoverEmptyLive) {
                await FAFOBackup.tryRecoverEmptyLive();
            }
            const res = await chrome.storage.local.get([
                'fafoMediaMeta', 'fafoTagLibrary', 'fafoTagLastUsed', 'fafoTagHotkeys',
                'fafoSkipTaggedMode', 'fafoTagLibraryHeight', 'fafoMetaPanelWidth',
                'fafoMetaPanelHeight', 'fafoMetaDockPos', 'fafoMetaDockX', 'fafoMetaDockY',
                'fafoMetaUiScale', 'fafoChromeScale', 'fafoMetaSplit', 'fafoMetaPanelOpen', 'fafoMetaStickLayout',
                'fafoMetaLibX', 'fafoMetaLibY', 'fafoMetaLibW', 'fafoMetaLibH', 'fafoMetaLibPosSaved',
                'fafoMetaLayoutMemory', 'fafoMetaLayoutVpW', 'fafoMetaLayoutVpH', 'fafoMetaLayoutMode',
                'fafoTagExcluded',
                'fafoTagApplyCounts', 'fafoTagSessionCounts', 'fafoTagCountMode',
                'fafoRecentTags', 'fafoApplyAndNext', 'fafoExtraTagBanks', 'fafoExtraTagSet',
                'fafoPrivateVault',
            ]);
            loadPrivateVaultFromRes(res);
            // Always start in public on load (must re-PIN); clear session flag
            privateUnlocked = false;
            privateSpaceActive = false;
            try {
                await chrome.storage.local.set({
                    fafoPrivateSession: { active: false, unlocked: false, at: Date.now() },
                });
            } catch (_) {}
            // Split preference is remembered, but only applied when user opens Tags
            // (new tabs always start compact — see setMetaPanelOpen / init).
            // Default ON: two separate free windows (tag history not attached under quick)
            window.__fafoMetaSplitPending = ('fafoMetaSplit' in res) ? !!res.fafoMetaSplit : true;
            // One-time migrate: if user never saved free dock, prefer free + split for independent windows
            if (!res.fafoMetaDockPos && !res.fafoLayoutMigratedSeparate) {
                dockPos = 'free';
                window.__fafoMetaSplitPending = true;
                chrome.storage.local.set({ fafoLayoutMigratedSeparate: true, fafoMetaSplit: true, fafoMetaDockPos: 'free' }).catch(() => {});
            }
            // Never auto-expand on load: every new tab starts compact until ★ Tags
            window.__fafoMetaPanelOpenPending = false;
            // Remember last open/closed preference for optional future use (not auto-applied)
            window.__fafoMetaPanelOpenLast = ('fafoMetaPanelOpen' in res) ? !!res.fafoMetaPanelOpen : false;
            // Quick panel dock: default bottom-right if never saved
            if (!res.fafoMetaDockPos) dockPos = 'br';
            excludedTags = Array.isArray(res.fafoTagExcluded)
                ? res.fafoTagExcluded.map(normalizeTag).filter(Boolean)
                : [];
            mediaMeta = res.fafoMediaMeta || {};
            tagLastUsed = res.fafoTagLastUsed && typeof res.fafoTagLastUsed === 'object' ? res.fafoTagLastUsed : {};
            tagLibrary = Array.isArray(res.fafoTagLibrary) ? res.fafoTagLibrary.slice() : [];
            tagHotkeys = normalizeHotkeyBanks(res.fafoTagHotkeys);
            // Session auto quick-select / E-set never restored from disk
            sessionAutoHotkeys = emptyHotkeyBanks();
            sessionAutoExtra = emptyExtraBanks();
            sessionFirstUsedOrder = [];
            sessionAutoHotkeysPaused = false;
            sessionAutoExtraPaused = false;
            skipTaggedMode = !!res.fafoSkipTaggedMode;
            applyAndNextMode = !!res.fafoApplyAndNext;
            recentTags = Array.isArray(res.fafoRecentTags)
                ? res.fafoRecentTags.map(normalizeTag).filter(Boolean).slice(0, 12)
                : [];
            if (typeof res.fafoTagLibraryHeight === 'number' && res.fafoTagLibraryHeight >= 80) {
                tagLibraryHeight = Math.min(res.fafoTagLibraryHeight, Math.round(window.innerHeight * 0.7));
            }
            if (typeof res.fafoMetaPanelWidth === 'number' && res.fafoMetaPanelWidth >= 260) {
                preferredPanelW = res.fafoMetaPanelWidth;
                panelWidth = Math.min(res.fafoMetaPanelWidth, Math.round(window.innerWidth - 16));
            }
            if (typeof res.fafoMetaPanelHeight === 'number' && res.fafoMetaPanelHeight >= 200) {
                preferredPanelH = res.fafoMetaPanelHeight;
                panelHeight = Math.min(res.fafoMetaPanelHeight, Math.round(window.innerHeight * 0.95));
            }
            const allowedDock = ['br', 'bl', 'tr', 'tl', 'free'];
            if (allowedDock.includes(res.fafoMetaDockPos)) dockPos = res.fafoMetaDockPos;
            if (typeof res.fafoMetaDockX === 'number') dockX = res.fafoMetaDockX;
            if (typeof res.fafoMetaDockY === 'number') dockY = res.fafoMetaDockY;
            if (typeof res.fafoMetaUiScale === 'number' && res.fafoMetaUiScale > 0) {
                uiScale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, res.fafoMetaUiScale));
            } else if (typeof res.fafoChromeScale === 'number' && res.fafoChromeScale > 0) {
                uiScale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, res.fafoChromeScale));
            } else {
                uiScale = DEFAULT_UI_SCALE;
            }
            if (typeof res.fafoMetaStickLayout === 'boolean') stickLayout = res.fafoMetaStickLayout;
            else stickLayout = true; // default: stay where you put them
            if (typeof res.fafoMetaLibX === 'number') libX = res.fafoMetaLibX;
            if (typeof res.fafoMetaLibY === 'number') libY = res.fafoMetaLibY;
            if (typeof res.fafoMetaLibW === 'number' && res.fafoMetaLibW >= 200) libW = res.fafoMetaLibW;
            if (typeof res.fafoMetaLibH === 'number' && res.fafoMetaLibH >= 140) libH = res.fafoMetaLibH;
            libPosSaved = !!res.fafoMetaLibPosSaved || (typeof res.fafoMetaLibX === 'number');
            // Dual-slot layout memory (windowed / fullscreen) — prefer mode-matching slot
            if (res.fafoMetaLayoutMemory && typeof res.fafoMetaLayoutMemory === 'object') {
                layoutMemorySlots = {
                    windowed: res.fafoMetaLayoutMemory.windowed || null,
                    fullscreen: res.fafoMetaLayoutMemory.fullscreen || null,
                };
            }
            if (typeof res.fafoMetaLayoutVpW === 'number') layoutVpW = res.fafoMetaLayoutVpW;
            if (typeof res.fafoMetaLayoutVpH === 'number') layoutVpH = res.fafoMetaLayoutVpH;
            {
                const modeNow = currentLayoutMode();
                const slot = layoutMemorySlots[modeNow]
                    || layoutMemorySlots.windowed
                    || layoutMemorySlots.fullscreen
                    || null;
                if (slot) {
                    // Load geometry/scale into state; do not auto-open panels (compact boot)
                    applyLayoutSlotToState(slot, { skipPending: true });
                    if (typeof slot.split === 'boolean') {
                        window.__fafoMetaSplitPending = slot.split;
                    }
                    // Keep last open preference for diagnostics only — never auto-expand
                    if (typeof slot.panelOpen === 'boolean') {
                        window.__fafoMetaPanelOpenLast = slot.panelOpen;
                    }
                } else if (layoutVpW > 0 && layoutVpH > 0) {
                    // Legacy absolute coords: remap if viewport changed a lot
                    const rem = window.FAFOViewport?.fromNorm?.({
                        x: dockX, y: dockY, w: panelWidth, h: panelHeight,
                        vpW: layoutVpW, vpH: layoutVpH,
                    });
                    if (rem) {
                        dockX = rem.x;
                        dockY = rem.y;
                        if (rem.w >= 260) panelWidth = rem.w;
                        if (rem.h >= 200) panelHeight = rem.h;
                    }
                    if (libPosSaved) {
                        const remL = window.FAFOViewport?.fromNorm?.({
                            x: libX, y: libY, w: libW, h: libH,
                            vpW: layoutVpW, vpH: layoutVpH,
                        });
                        if (remL) {
                            libX = remL.x;
                            libY = remL.y;
                            if (remL.w >= 200) libW = remL.w;
                            if (remL.h >= 140) libH = remL.h;
                        }
                    }
                }
            }
            // Hard rule: every new tab starts compact until user hits ★ Tags
            window.__fafoMetaPanelOpenPending = false;
            if (res.fafoExtraTagBanks) {
                extraTagBanks = normalizeExtraBanks(res.fafoExtraTagBanks);
            } else if (res.fafoExtraTagSet) {
                extraTagBanks = normalizeExtraBanks(res.fafoExtraTagSet);
            }
            // Restore apply counts (never wipe on reload)
            const savedCounts = res.fafoTagApplyCounts || res.fafoTagSessionCounts;
            if (savedCounts && typeof savedCounts === 'object' && !Array.isArray(savedCounts)) {
                sessionTagCount = {};
                Object.entries(savedCounts).forEach(([k, v]) => {
                    const n = parseInt(v, 10);
                    if (k && n > 0) sessionTagCount[String(k).toLowerCase()] = n;
                });
            } else {
                sessionTagCount = {};
            }
            recomputeSessionHasPicks();
            if (res.fafoTagCountMode === 'total' || res.fafoTagCountMode === 'session') {
                countDisplayMode = res.fafoTagCountMode;
            }
            // Migrate: strip pair/role tags out of .tags into .pairId; clean vocabulary
            let migrated = false;
            Object.keys(mediaMeta).forEach((k) => {
                const m = mediaMeta[k];
                if (!m || typeof m !== 'object') return;
                const raw = Array.isArray(m.tags) ? m.tags : [];
                const pairFromTags = globalThis.FAFOId?.pairIdFromMeta
                    ? FAFOId.pairIdFromMeta(m)
                    : '';
                const cleaned = userTagsOnly(raw);
                if (pairFromTags && !m.pairId) {
                    m.pairId = pairFromTags;
                    migrated = true;
                }
                if (cleaned.length !== raw.length) {
                    m.tags = cleaned;
                    migrated = true;
                }
            });
            // Always re-harvest known USER tags from saved media (no apply-count bump)
            Object.values(mediaMeta).forEach((m) => ensureTagsKnown(m.tags || []));
            scrubTagLibrary();
            // Tag DB + recovery sources → full public vocabulary (unused tags included)
            try {
                await hydrateTagVocabulary({ render: false });
            } catch (e) {
                console.warn('tag db boot', e);
                decontaminateTagLibraryToActiveSpace();
            }
            rebuildLibraryTagCounts();
            sortTagLibrary();
            // Seed auto slots from persisted Uses (highest first) without repeating user slots
            if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
            if (migrated) {
                chrome.storage.local.set({
                    fafoMediaMeta: mediaMeta,
                    fafoTagLibrary: tagLibrary.slice(),
                }).catch(() => {});
            }
            // Prefer companion / text settings when present (survives reloads & upgrades)
            tryLoadSettingsFile().catch(() => {});
        } catch {
            mediaMeta = {};
            tagLibrary = [];
            tagLastUsed = {};
            libraryTagCount = {};
            sessionTagCount = {};
            sessionHasPicks = false;
            tagHotkeys = emptyHotkeyBanks();
            skipTaggedMode = false;
        }
    }

    async function saveStore() {
        try {
            scrubTagLibrary();
            // Layout/UI prefs always global; tag/meta libraries are space-scoped
            const payload = {
                fafoSkipTaggedMode: skipTaggedMode,
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: preferredPanelW || panelWidth || undefined,
                fafoMetaPanelHeight: preferredPanelH || panelHeight || undefined,
                fafoMetaDockPos: dockPos,
                fafoMetaDockX: dockX,
                fafoMetaDockY: dockY,
                fafoMetaUiScale: uiScale,
                fafoMetaPanelOpen: metaPanelOpen,
                fafoMetaStickLayout: stickLayout,
                fafoMetaLibX: libX,
                fafoMetaLibY: libY,
                fafoMetaLibW: libW,
                fafoMetaLibH: libH,
                fafoMetaLibPosSaved: libPosSaved,
                fafoMetaLayoutMemory: layoutMemorySlots,
                fafoMetaLayoutVpW: layoutVpW || undefined,
                fafoMetaLayoutVpH: layoutVpH || undefined,
                fafoMetaLayoutMode: layoutModeActive,
                fafoTagCountMode: countDisplayMode,
                fafoApplyAndNext: applyAndNextMode,
                // Legacy mirror only — real multi-vault PINs live in fafoPrivateVaults
                fafoPrivateVault: {
                    v: 1,
                    pinHash: privatePinHash || '',
                    salt: privatePinSalt || '',
                    tags: privateTags.map(normalizeTag).filter(Boolean),
                    mediaKeys: privateMediaKeys.filter(Boolean),
                    updatedAt: new Date().toISOString(),
                },
            };
            // Space-isolated tag/meta libraries (public vs private never share storage keys)
            const sk = spaceKeys();
            payload[sk.mediaMeta] = mediaMeta;
            // Plain list = recovery mirror; opaque Tag DB is primary vocabulary
            payload[sk.tagLibrary] = tagLibrary.slice();
            payload[sk.tagLastUsed] = tagLastUsed;
            payload[sk.tagHotkeys] = tagHotkeys;
            payload[sk.tagExcluded] = excludedTags;
            if (sk.tagMenuScope) payload[sk.tagMenuScope] = tagMenuScope;
            payload[sk.recentTags] = recentTags;
            payload[sk.applyCounts] = sessionTagCount;
            payload[sk.extraBanks] = extraTagBanks;
            payload[sk.sprintTags] = sprintTags.slice();
            await chrome.storage.local.set(payload);
            await persistTagDb();
            // Backups: never mix secret-mode lists into the public snapshot/export
            if (globalThis.FAFOBackup?.afterLiveSave) {
                if (privateSpaceActive) {
                    // Private snapshot is PIN-gated and separate from public backup stream
                    FAFOBackup.afterPrivateLiveSave?.(payload, 'tag-save-private').catch((e) =>
                        console.warn('FAFO private backup failed', e)
                    );
                } else {
                    FAFOBackup.afterLiveSave(payload, 'tag-save').catch((e) =>
                        console.warn('FAFO backup failed', e)
                    );
                }
            }
            scheduleSettingsExport();
        } catch (e) {
            console.warn('FAFO meta save failed', e);
            if (els.status) {
                els.status.textContent = 'Save failed — check storage / try Backup → Export tags';
            }
        }
    }

    function currentLayoutMode() {
        try {
            return window.FAFOViewport?.layoutMode?.() || (
                (document.fullscreenElement || document.webkitFullscreenElement) ? 'fullscreen' : 'windowed'
            );
        } catch {
            return 'windowed';
        }
    }

    function currentViewportSize() {
        const vp = window.FAFOViewport?.viewportBox?.();
        if (vp && vp.width > 0 && vp.height > 0) {
            return { w: Math.round(vp.width), h: Math.round(vp.height) };
        }
        return {
            w: Math.round(document.documentElement?.clientWidth || window.innerWidth || 800),
            h: Math.round(document.documentElement?.clientHeight || window.innerHeight || 600),
        };
    }

    /** Build a durable layout slot (absolute + normalized). */
    function buildLayoutSlot(extra = {}) {
        const vp = currentViewportSize();
        const mode = currentLayoutMode();
        const dockNorm = window.FAFOViewport?.toNorm?.(dockX, dockY, panelWidth || preferredPanelW || null, panelHeight || preferredPanelH || null)
            || { nx: 0, ny: 0, nw: null, nh: null, vpW: vp.w, vpH: vp.h, mode };
        const libNorm = window.FAFOViewport?.toNorm?.(libX, libY, libW, libH)
            || { nx: 0, ny: 0, nw: null, nh: null, vpW: vp.w, vpH: vp.h, mode };
        return {
            dockPos,
            dockX,
            dockY,
            panelWidth: preferredPanelW || panelWidth || 0,
            panelHeight: preferredPanelH || panelHeight || 0,
            tagLibraryHeight,
            uiScale,
            stickLayout,
            split: !!$('meta-dock')?.classList.contains('layout-split'),
            panelOpen: !!metaPanelOpen,
            libPosSaved,
            libX,
            libY,
            libW,
            libH,
            // Normalized (survives resize / DPI / zoom better than raw px alone)
            dockNx: dockNorm.nx,
            dockNy: dockNorm.ny,
            dockNw: dockNorm.nw,
            dockNh: dockNorm.nh,
            libNx: libNorm.nx,
            libNy: libNorm.ny,
            libNw: libNorm.nw,
            libNh: libNorm.nh,
            vpW: vp.w,
            vpH: vp.h,
            mode,
            savedAt: Date.now(),
            ...extra,
        };
    }

    function rememberLayoutSlot(opts = {}) {
        const mode = opts.mode || currentLayoutMode();
        const slot = buildLayoutSlot({ mode });
        layoutMemorySlots[mode] = slot;
        layoutModeActive = mode;
        layoutVpW = slot.vpW;
        layoutVpH = slot.vpH;
        return slot;
    }

    /**
     * Apply a saved slot to live state (does not paint — call applyDockLayout after).
     * Uses normalized coords when viewport size differs from when the slot was saved.
     */
    function applyLayoutSlotToState(slot, opts = {}) {
        if (!slot || typeof slot !== 'object') return false;
        const allowed = ['br', 'bl', 'tr', 'tl', 'free'];
        if (allowed.includes(slot.dockPos)) dockPos = slot.dockPos;
        stickLayout = slot.stickLayout !== false;
        if (typeof slot.uiScale === 'number' && slot.uiScale > 0) {
            uiScale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, slot.uiScale));
        }
        if (typeof slot.tagLibraryHeight === 'number' && slot.tagLibraryHeight >= 80) {
            tagLibraryHeight = slot.tagLibraryHeight;
        }

        // Preferred sizes — never lose user intent when viewport is temporarily small
        if (typeof slot.panelWidth === 'number' && slot.panelWidth >= 260) {
            preferredPanelW = slot.panelWidth;
            panelWidth = slot.panelWidth;
        }
        if (typeof slot.panelHeight === 'number' && slot.panelHeight >= 200) {
            preferredPanelH = slot.panelHeight;
            panelHeight = slot.panelHeight;
        }

        const vp = currentViewportSize();
        const dockSlot = {
            x: slot.dockX,
            y: slot.dockY,
            w: slot.panelWidth,
            h: slot.panelHeight,
            nx: slot.dockNx,
            ny: slot.dockNy,
            nw: slot.dockNw,
            nh: slot.dockNh,
            vpW: slot.vpW,
            vpH: slot.vpH,
        };
        const fromDock = window.FAFOViewport?.fromNorm?.(dockSlot) || {
            x: Number(slot.dockX) || 18,
            y: Number(slot.dockY) || 18,
            w: slot.panelWidth,
            h: slot.panelHeight,
        };
        dockX = fromDock.x;
        dockY = fromDock.y;
        if (fromDock.w >= 260) {
            panelWidth = fromDock.w;
            // Keep preferred as the larger of saved preferred and remapped
            preferredPanelW = Math.max(preferredPanelW || 0, slot.panelWidth || 0) || panelWidth;
        }
        if (fromDock.h >= 200) {
            panelHeight = fromDock.h;
            preferredPanelH = Math.max(preferredPanelH || 0, slot.panelHeight || 0) || panelHeight;
        }

        libPosSaved = !!slot.libPosSaved || typeof slot.libX === 'number' || typeof slot.libNx === 'number';
        const libSlot = {
            x: slot.libX,
            y: slot.libY,
            w: slot.libW,
            h: slot.libH,
            nx: slot.libNx,
            ny: slot.libNy,
            nw: slot.libNw,
            nh: slot.libNh,
            vpW: slot.vpW,
            vpH: slot.vpH,
        };
        const fromLib = window.FAFOViewport?.fromNorm?.(libSlot) || {
            x: Number(slot.libX) || 18,
            y: Number(slot.libY) || 80,
            w: slot.libW,
            h: slot.libH,
        };
        if (typeof fromLib.x === 'number') libX = fromLib.x;
        if (typeof fromLib.y === 'number') libY = fromLib.y;
        if (fromLib.w >= 200) libW = fromLib.w;
        else if (slot.libW >= 200) libW = slot.libW;
        if (fromLib.h >= 140) libH = fromLib.h;
        else if (slot.libH >= 140) libH = slot.libH;

        layoutVpW = vp.w;
        layoutVpH = vp.h;
        layoutModeActive = currentLayoutMode();

        if (!opts.skipPending) {
            if (typeof slot.split === 'boolean') window.__fafoMetaSplitPending = slot.split;
            if (typeof slot.panelOpen === 'boolean') window.__fafoMetaPanelOpenPending = slot.panelOpen;
        }
        return true;
    }

    function scheduleLayoutSave() {
        clearTimeout(layoutSaveTimer);
        layoutSaveTimer = setTimeout(() => {
            scheduleSettingsExport();
            // Capture preferred sizes from live state when user-driven
            if (panelWidth >= 260) preferredPanelW = panelWidth;
            if (panelHeight >= 200) preferredPanelH = panelHeight;
            const slot = rememberLayoutSlot();
            const payload = {
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: preferredPanelW || panelWidth || undefined,
                fafoMetaPanelHeight: preferredPanelH || panelHeight || undefined,
                fafoMetaDockPos: dockPos,
                fafoMetaDockX: dockX,
                fafoMetaDockY: dockY,
                fafoMetaUiScale: uiScale,
                fafoMetaStickLayout: stickLayout,
                fafoMetaLibX: libX,
                fafoMetaLibY: libY,
                fafoMetaLibW: libW,
                fafoMetaLibH: libH,
                fafoMetaLibPosSaved: libPosSaved,
                fafoMetaPanelOpen: !!metaPanelOpen,
                fafoMetaSplit: !!$('meta-dock')?.classList.contains('layout-split'),
                fafoMetaLayoutVpW: layoutVpW,
                fafoMetaLayoutVpH: layoutVpH,
                fafoMetaLayoutMode: layoutModeActive,
                fafoMetaLayoutMemory: layoutMemorySlots,
            };
            chrome.storage.local.set(payload).catch(() => {});
        }, 200);
    }

    /**
     * Window resize / fullscreen / zoom — keep free panels proportional when Stick is on.
     * Corner docks re-snap; free floats remap via last viewport size.
     */
    function onViewportGeometryChange(reason) {
        if (dockDragging || libDragging || edgeResizing || resizeDragging) return;
        const mode = currentLayoutMode();
        const vp = currentViewportSize();
        const modeChanged = layoutMemoryBootstrapped && mode !== layoutModeActive;

        // Leaving a mode: stash current placement into that slot first
        if (modeChanged) {
            rememberLayoutSlot({ mode: layoutModeActive });
            const other = layoutMemorySlots[mode];
            if (other) {
                applyLayoutSlotToState(other, { skipPending: true });
                // Only restore expanded layout if tags are already open —
                // never force-expand just because fullscreen flipped
                if (metaPanelOpen) {
                    if (typeof other.split === 'boolean') {
                        window.__fafoMetaSplitPending = other.split;
                        setLibrarySplit(!!other.split, { forceDefault: false, keepCurrent: !!other.libPosSaved });
                    }
                    applyTagLibraryHeight();
                    applyDockLayout();
                    paintExpandedLayout();
                } else {
                    // Stay compact; remember split/geometry for next Tags open
                    if (typeof other.split === 'boolean') window.__fafoMetaSplitPending = other.split;
                    const dock = $('meta-dock');
                    if (dock) dock.style.setProperty('--meta-ui-scale', String(uiScale));
                    applyDockLayout({ scaleOnly: false });
                }
                layoutModeActive = mode;
                layoutVpW = vp.w;
                layoutVpH = vp.h;
                scheduleLayoutSave();
                if (els.status && reason === 'fullscreen') {
                    els.status.textContent = mode === 'fullscreen'
                        ? (metaPanelOpen ? 'Fullscreen layout restored' : 'Fullscreen · tags stay compact until ★ Tags')
                        : (metaPanelOpen ? 'Windowed layout restored' : 'Windowed · tags stay compact until ★ Tags');
                }
                return;
            }
            layoutModeActive = mode;
        }

        // Same mode: proportional remap when Stick ON + free (or always for lib)
        if (stickLayout && dockPos === 'free' && layoutVpW > 0 && layoutVpH > 0) {
            const rem = window.FAFOViewport?.remapOnResize?.(dockX, dockY, layoutVpW, layoutVpH);
            if (rem) {
                dockX = rem.x;
                dockY = rem.y;
            }
        }
        if (libPosSaved && layoutVpW > 0 && layoutVpH > 0) {
            const remL = window.FAFOViewport?.remapOnResize?.(libX, libY, layoutVpW, layoutVpH);
            if (remL) {
                libX = remL.x;
                libY = remL.y;
            }
            // Scale library size gently with viewport when Stick ON
            if (stickLayout && layoutVpW > 40 && layoutVpH > 40) {
                const sw = vp.w / layoutVpW;
                const sh = vp.h / layoutVpH;
                if (Math.abs(sw - 1) > 0.02 || Math.abs(sh - 1) > 0.02) {
                    libW = Math.max(200, Math.round(libW * sw));
                    libH = Math.max(140, Math.round(libH * sh));
                }
            }
        }

        // Restore preferred panel size when viewport grew enough again
        if (preferredPanelW >= 260) panelWidth = preferredPanelW;
        if (preferredPanelH >= 200) panelHeight = preferredPanelH;
        applyTagLibraryHeight();

        if (dockPos === 'free' || ['br', 'bl', 'tr', 'tl'].includes(dockPos)) {
            applyDockLayout();
        }
        if ($('meta-dock')?.classList.contains('layout-split')) {
            applyLibraryPanelGeometry({ forceDefault: false });
            ensureLibraryOnScreen();
        }

        layoutVpW = vp.w;
        layoutVpH = vp.h;
        layoutModeActive = mode;
        // Persist remapped coords so reload matches what user sees after resize
        if (layoutMemoryBootstrapped) scheduleLayoutSave();
    }

    function initLayoutMemoryWatch() {
        if (layoutMemoryBootstrapped) return;
        layoutMemoryBootstrapped = true;
        const vp = currentViewportSize();
        layoutVpW = vp.w;
        layoutVpH = vp.h;
        layoutModeActive = currentLayoutMode();
        try {
            window.FAFOViewport?.watch?.();
            window.FAFOViewport?.onLock?.(() => onViewportGeometryChange('lock'));
        } catch (_) {}
        window.addEventListener('resize', () => onViewportGeometryChange('resize'), { passive: true });
        document.addEventListener('fullscreenchange', () => onViewportGeometryChange('fullscreen'));
        document.addEventListener('webkitfullscreenchange', () => onViewportGeometryChange('fullscreen'));
    }

    function dockLabel(pos) {
        return ({ br: 'BR', bl: 'BL', tr: 'TR', tl: 'TL', free: 'Free' })[pos] || 'BR';
    }

    function updateDockButtons() {
        const posBtn = $('meta-dock-pos');
        if (posBtn) {
            posBtn.textContent = `Dock · ${dockLabel(dockPos)}`;
            posBtn.title = 'Cycle free-float → BR → BL → TR → TL. Drag the ⋮⋮ header anytime to move.';
            posBtn.classList.toggle('active', dockPos === 'free');
        }
        const scaleBtn = $('meta-ui-scale');
        if (scaleBtn) {
            scaleBtn.textContent = `Scale · ${Math.round(uiScale * 100)}%`;
            scaleBtn.title = 'Click to cycle presets · use UI/tags slider below for fine control';
        }
        syncScaleSliders();
        const stickBtn = $('meta-stick-layout');
        if (stickBtn) {
            stickBtn.classList.toggle('active', !!stickLayout);
            stickBtn.textContent = stickLayout ? 'Stick · ON' : 'Stick · off';
            stickBtn.title = stickLayout
                ? 'ON: scale/open won’t jump panels. You can ALWAYS drag headers to move.'
                : 'OFF: Dock button snaps to corners; free panels re-clamp on scale';
        }
        const undockBtn = $('meta-undock-move');
        if (undockBtn) {
            undockBtn.title = 'Force free-float + pull on-screen so you can drag the ⋮⋮ header';
        }
    }

    function setStickLayout(on) {
        stickLayout = !!on;
        updateDockButtons();
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = stickLayout
                ? 'Stick ON — drag still works; scale won’t jump panels'
                : 'Stick off — Dock snaps to corners again';
        }
    }

    /**
     * Keep tags chrome off the top command chips / Disk pip / Options gear.
     */
    function chromeSafeInset(pos) {
        const p = pos || dockPos;
        if (p === 'tr') return { top: 52, right: 118, bottom: 8, left: 8 };
        if (p === 'tl') return { top: 52, right: 8, bottom: 8, left: 8 };
        if (p === 'bl') return { top: 52, right: 8, bottom: 88, left: 8 };
        return { top: 52, right: 8, bottom: 8, left: 8 };
    }

    /**
     * Pre-clamp free coords (scale-aware). Final truth is FAFOViewport.lock()
     * which measures the painted box — correct for windowed and fullscreen.
     */
    function clampFreeXY(x, y, w, h, opts = {}) {
        const inset = opts.inset || chromeSafeInset(opts.pos || dockPos);
        const scale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(opts.scale ?? uiScale) || 1));
        const layoutW = Math.max(40, Number(w) || 360);
        const layoutH = Math.max(40, Number(h) || 200);
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const boxW = layoutW * scale;
        const boxH = layoutH * scale;
        // Keep a grab strip on screen. Do not shrink the panel to force a fit.
        const keep = 72;
        const minX = inset.left + keep - boxW;
        const maxX = Math.max(minX, ww - inset.right - keep);
        const minY = inset.top;
        const maxY = Math.max(minY, wh - inset.bottom - keep);
        return {
            x: Math.round(Math.max(minX, Math.min(maxX, Number(x) || 0))),
            y: Math.round(Math.max(minY, Math.min(maxY, Number(y) || 0))),
            w: Math.round(layoutW),
            h: Math.round(layoutH),
            scale,
        };
    }

    function clampDockFree(x, y) {
        const dock = $('meta-dock');
        const panel = els.panel;
        const w = panel?.offsetWidth || dock?.offsetWidth || 360;
        const h = panel?.offsetHeight || dock?.offsetHeight || 200;
        return clampFreeXY(x, y, w, h);
    }

    function isMostlyOffScreen(x, y, w, h) {
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const scale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1));
        const left = Number(x) || 0;
        const top = Number(y) || 0;
        const right = left + (w || 200) * scale;
        const bottom = top + (h || 120) * scale;
        return left < -1 || top < -1 || right > ww + 1 || bottom > wh + 1;
    }

    /**
     * After scale / resize / fullscreen: lock tags chrome to the real window.
     * Uses FAFOViewport painted-box measurement (same path windowed or fullscreen).
     */
    function pinDockForStage(rect) {
        const dock = $('meta-dock');
        if (!dock) return;
        if (!rect) {
            if (!stageDockPinned) return;
            stageDockPinned = false;
            dock.classList.remove('dock-stage');
            applyDockLayout();
            return;
        }
        stageDockPinned = true;
        if (!metaPanelOpen) setMetaPanelOpen(true);
        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl', 'dock-free');
        dock.classList.add('dock-stage');
        dock.dataset.dock = 'stage';
        const s = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1));
        const layoutW = Math.max(220, Math.round(rect.w / s));
        const layoutH = Math.max(160, Math.round(rect.h / s));
        const panel = els.panel;
        if (panel && !panel.classList.contains('collapsed')) {
            panel.style.width = layoutW + 'px';
            panel.style.height = layoutH + 'px';
            panel.style.maxWidth = layoutW + 'px';
            panel.style.maxHeight = layoutH + 'px';
        }
        dock.style.setProperty('left', `${rect.x}px`, 'important');
        dock.style.setProperty('top', `${rect.y}px`, 'important');
        dock.style.setProperty('right', 'auto', 'important');
        dock.style.setProperty('bottom', 'auto', 'important');
        dock.style.setProperty('transform', `scale(${s})`, 'important');
        dock.style.setProperty('transform-origin', 'top left', 'important');
        dock.style.setProperty('--meta-ui-scale', String(s));
    }

    function reclampAllChromeAfterScale() {
        // Never yank panels while the user is actively dragging
        if (dockDragging || libDragging || edgeResizing || resizeDragging) return;
        if (window.FAFOPlayer?.isStageFramed?.()) {
            try { window.FAFOPlayer.applyStageLayoutNow(); } catch (_) {}
            updateDockButtons();
            return;
        }
        const dock = $('meta-dock');
        if (dockPos === 'free') {
            placeDockAt(dockX, dockY);
        } else if (['br', 'bl', 'tr', 'tl'].includes(dockPos)) {
            const snap = coordsForDockSnap(dockPos);
            placeDockAt(snap.x, snap.y);
        } else {
            placeDockAt(dockX, dockY);
        }

        if (dock?.classList.contains('layout-split') && !libDragging) {
            applyLibraryPanelGeometry({ forceDefault: false });
            ensureLibraryOnScreen();
        }
        updateDockButtons();
    }

    /** Move library out of #meta-dock so position:fixed is viewport-true (dock transform no longer traps it). */
    function detachLibraryPanelToBody() {
        const lib = $('meta-library-panel');
        if (!lib) return;
        if (lib.parentElement === document.body) {
            lib.classList.add('meta-lib-portaled');
            return;
        }
        libHomeParent = lib.parentElement;
        libHomeNext = lib.nextSibling;
        document.body.appendChild(lib);
        lib.classList.add('meta-lib-portaled');
    }

    function reattachLibraryPanelToDock() {
        const lib = $('meta-library-panel');
        if (!lib) return;
        const parent = libHomeParent || $('meta-dock');
        if (!parent) return;
        if (lib.parentElement === parent) {
            lib.classList.remove('meta-lib-portaled');
            return;
        }
        if (libHomeNext && libHomeNext.parentElement === parent) {
            parent.insertBefore(lib, libHomeNext);
        } else {
            parent.appendChild(lib);
        }
        lib.classList.remove('meta-lib-portaled');
        // Clear free geometry styles so stacked layout CSS takes over
        lib.style.position = '';
        lib.style.left = '';
        lib.style.top = '';
        lib.style.right = '';
        lib.style.bottom = '';
        lib.style.width = '';
        lib.style.height = '';
        lib.style.transform = '';
        lib.style.maxWidth = '';
        lib.style.maxHeight = '';
    }

    /**
     * Live drag placement — left/top only, scale-aware clamp, NO lock/resize.
     * Calling FAFOViewport.lock mid-drag was yanking panels off under the cursor.
     */
    function placeDockAtLive(x, y) {
        const dock = $('meta-dock');
        if (!dock) return;
        const panel = els.panel;
        let w = panelWidth > 0 ? panelWidth : (panel?.offsetWidth || dock.offsetWidth || 360);
        let h = panelHeight > 0 ? panelHeight : (panel?.offsetHeight || dock.offsetHeight || 200);
        const c = clampFreeXY(x, y, w, h);
        dockX = c.x;
        dockY = c.y;
        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl');
        dock.classList.add('dock-free');
        dock.dataset.dock = 'free';
        const s = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1));
        dock.style.setProperty('left', `${dockX}px`, 'important');
        dock.style.setProperty('top', `${dockY}px`, 'important');
        dock.style.setProperty('right', 'auto', 'important');
        dock.style.setProperty('bottom', 'auto', 'important');
        dock.style.setProperty('transform', `scale(${s})`, 'important');
        dock.style.setProperty('transform-origin', 'top left', 'important');
        dock.style.setProperty('--meta-ui-scale', String(s));
    }

    /** Place dock with left/top, then lock painted box to the window (not during drag). */
    function placeDockAt(x, y, opts = {}) {
        const dock = $('meta-dock');
        if (!dock) return;
        // During active drag always use lite path
        if (dockDragging || opts.live) {
            placeDockAtLive(x, y);
            return;
        }
        const panel = els.panel;
        let w = panel?.offsetWidth || dock.offsetWidth || 360;
        let h = panel?.offsetHeight || dock.offsetHeight || 200;
        if (panelWidth > 0) w = panelWidth;
        if (panelHeight > 0) h = panelHeight;
        const c = clampFreeXY(x, y, w, h);
        dockX = c.x;
        dockY = c.y;

        if (panel && !panel.classList.contains('collapsed') && !edgeResizing) {
            panel.style.maxWidth = 'none';
            panel.style.maxHeight = 'none';
        }

        dock.style.setProperty('left', `${dockX}px`, 'important');
        dock.style.setProperty('top', `${dockY}px`, 'important');
        dock.style.setProperty('right', 'auto', 'important');
        dock.style.setProperty('bottom', 'auto', 'important');
        const s = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1));
        dock.style.setProperty('transform', `scale(${s})`, 'important');
        dock.style.setProperty('transform-origin', 'top left', 'important');
        dock.style.setProperty('--meta-ui-scale', String(s));

        // Final authority: painted rect vs real window (fullscreen-safe)
        // Skip during edge resize so the panel doesn't jump under the grip
        if (edgeResizing || resizeDragging) return;
        const locked = window.FAFOViewport?.lock?.(dock, {
            margin: 8,
            inset: chromeSafeInset(dockPos),
            canResize: false, minW: 200, minH: 80,
        });
        if (locked) {
            dockX = locked.x;
            dockY = locked.y;
        }
    }

    function setDockFreeStyles(dock, x, y) {
        if (!dock) return;
        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl');
        dock.classList.add('dock-free');
        dock.dataset.dock = 'free';
        // Live while dragging; full lock otherwise
        if (dockDragging) placeDockAtLive(x, y);
        else placeDockAt(x, y);
    }

    function clearDockCornerStyles(dock) {
        // No-op: layout always uses left/top via placeDockAt
        if (!dock) return;
    }

    /** Corner snap → layout left/top so scaled visual box sits fully in that corner. */
    function coordsForDockSnap(pos) {
        const dock = $('meta-dock');
        const panel = els.panel;
        const inset = chromeSafeInset(pos);
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const scale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1));
        const layoutW = Math.max(120, panel?.offsetWidth || dock?.offsetWidth || 360);
        const layoutH = Math.max(48, panel?.offsetHeight || dock?.offsetHeight || 200);
        const w = layoutW * scale;
        const h = layoutH * scale;
        switch (pos) {
            case 'bl': return { x: inset.left, y: Math.max(inset.top, wh - h - inset.bottom) };
            case 'tr': return { x: Math.max(inset.left, ww - w - inset.right), y: inset.top };
            case 'tl': return { x: inset.left, y: inset.top };
            case 'br':
            default: return { x: Math.max(inset.left, ww - w - inset.right), y: Math.max(inset.top, wh - h - inset.bottom) };
        }
    }

    function applyDockLayout(opts = {}) {
        const dock = $('meta-dock');
        if (!dock) return;
        const scaleOnly = !!opts.scaleOnly;
        dock.style.setProperty('--meta-ui-scale', String(uiScale));

        // Scale-only: always reclamp — scale must never push chrome off-screen
        if (scaleOnly) {
            applyTagLibraryHeight();
            reclampAllChromeAfterScale();
            return;
        }

        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl', 'dock-free');
        const pos = ['br', 'bl', 'tr', 'tl', 'free'].includes(dockPos) ? dockPos : 'br';
        dock.classList.add(`dock-${pos}`);
        dock.dataset.dock = pos;

        if (pos === 'free') {
            let x = dockX;
            let y = dockY;
            if (isMostlyOffScreen(x, y, dock.offsetWidth || 360, dock.offsetHeight || 200)) {
                x = Math.max(18, Math.round((window.innerWidth || 800) * 0.55));
                y = Math.max(18, Math.round((window.innerHeight || 600) * 0.12));
            }
            placeDockAt(x, y);
        } else {
            // Snap corners via explicit pixels so nothing can fight with CSS anchors
            const place = () => {
                const c = coordsForDockSnap(pos);
                placeDockAt(c.x, c.y);
            };
            place();
            // After open/sizes settle, re-snap once more
            requestAnimationFrame(place);
        }
        updateDockButtons();
        applyTagLibraryHeight();
        if ($('meta-dock')?.classList.contains('layout-split')) {
            applyLibraryPanelGeometry({ forceDefault: false });
            ensureLibraryOnScreen();
        }
    }

    function ensureLibraryOnScreen() {
        const lib = $('meta-library-panel');
        if (!lib || lib.classList.contains('collapsed')) return;
        if (!$('meta-dock')?.classList.contains('layout-split')) return;
        if (getComputedStyle(lib).position !== 'fixed') return;
        const w = lib.offsetWidth || libW || 360;
        const h = lib.offsetHeight || libH || 400;
        // History panel unscaled
        const c = clampFreeXY(libX, libY, w, h, { scale: 1 });
        libX = c.x;
        libY = c.y;
        if (c.w) libW = c.w;
        if (c.h) libH = c.h;
        lib.style.left = `${libX}px`;
        lib.style.top = `${libY}px`;
        if (c.w) lib.style.width = `${c.w}px`;
        if (c.h) lib.style.height = `${c.h}px`;
        libPosSaved = true;
    }

    function applyLibraryPanelGeometry(opts = {}) {
        const lib = $('meta-library-panel');
        const dock = $('meta-dock');
        if (!lib || !dock?.classList.contains('layout-split')) return;
        if (lib.classList.contains('collapsed')) return;

        const forceDefault = !!opts.forceDefault && !libPosSaved && !stickLayout;
        if (forceDefault || (!libPosSaved && !opts.keepCurrent)) {
            // First-time default: left side, vertically centered
            libW = Math.min(360, Math.round(window.innerWidth * 0.32));
            libH = Math.min(Math.round(window.innerHeight * 0.72), 720);
            libX = 18;
            libY = Math.max(12, Math.round((window.innerHeight - libH) / 2));
        } else if (opts.keepCurrent) {
            const r = lib.getBoundingClientRect();
            if (r.width > 40) {
                libX = Math.round(r.left);
                libY = Math.round(r.top);
                libW = Math.round(r.width);
                libH = Math.round(r.height);
                libPosSaved = true;
            }
        }

        // Library is NOT CSS-scaled (transform none) — clamp at scale 1
        const c = clampFreeXY(libX, libY, libW, libH, { scale: 1 });
        libX = c.x;
        libY = c.y;
        if (c.w) libW = c.w;
        if (c.h) libH = c.h;
        lib.style.position = 'fixed';
        lib.style.left = `${Math.round(libX)}px`;
        lib.style.top = `${Math.round(libY)}px`;
        lib.style.right = 'auto';
        lib.style.bottom = 'auto';
        lib.style.transform = 'none';
        lib.style.width = `${Math.round(libW)}px`;
        lib.style.height = `${Math.round(libH)}px`;
        lib.style.maxWidth = `${Math.max(40, (window.innerWidth || 800) - 8)}px`;
        lib.style.maxHeight = `${Math.max(40, (window.innerHeight || 600) - 8)}px`;
        const locked = window.FAFOViewport?.lock?.(lib, {
            margin: 8,
            inset: { top: 52, right: 8, bottom: 8, left: 8 },
            canResize: true, minW: 200, minH: 120,
        });
        if (locked) {
            libX = locked.x;
            libY = locked.y;
            libW = locked.w;
            libH = locked.h;
            libPosSaved = true;
        }
    }

    function captureLibraryGeometry() {
        const lib = $('meta-library-panel');
        if (!lib || lib.classList.contains('collapsed')) return;
        if (getComputedStyle(lib).position !== 'fixed') return;
        const r = lib.getBoundingClientRect();
        if (r.width < 40 || r.height < 40) return;
        libX = Math.round(r.left);
        libY = Math.round(r.top);
        libW = Math.round(r.width);
        libH = Math.round(r.height);
        libPosSaved = true;
    }

    function cycleDockPos() {
        // Always cycle: free → BR → BL → TR → TL → free …
        // Stick only prevents *automatic* jumps (scale/open), never blocks Dock button or drag-to-move.
        const order = ['free', 'br', 'bl', 'tr', 'tl'];
        const i = Math.max(0, order.indexOf(dockPos));
        dockPos = order[(i + 1) % order.length];
        if (dockPos === 'free') {
            const dock = $('meta-dock');
            const r = dock?.getBoundingClientRect();
            if (r && r.width > 0 && !isMostlyOffScreen(r.left, r.top, r.width, r.height)) {
                dockX = Math.round(r.left);
                dockY = Math.round(r.top);
            } else {
                dockX = Math.max(18, Math.round(window.innerWidth * 0.55));
                dockY = Math.max(18, Math.round(window.innerHeight * 0.15));
            }
            const c = clampDockFree(dockX, dockY);
            dockX = c.x;
            dockY = c.y;
        }
        applyDockLayout();
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = dockPos === 'free'
                ? 'Tags free-float — drag the ⋮⋮ header to move'
                : `Tags dock: ${dockLabel(dockPos)} — drag ⋮⋮ header anytime to free-move`;
        }
    }

    /** Force free-float + on-screen so user can always grab and move. */
    function undockTagsForMove() {
        const dock = $('meta-dock');
        // Open panel so the drag header exists
        if (!metaPanelOpen) setMetaPanelOpen(true);
        const r = dock?.getBoundingClientRect();
        dockPos = 'free';
        if (r && r.width > 0 && !isMostlyOffScreen(r.left, r.top, r.width, r.height)) {
            dockX = Math.round(r.left);
            dockY = Math.round(r.top);
        } else {
            // Safe home on the right if current spot is unusable
            dockX = Math.max(18, Math.round((window.innerWidth || 800) * 0.58));
            dockY = Math.max(18, Math.round((window.innerHeight || 600) * 0.12));
        }
        const c = clampDockFree(dockX, dockY);
        dockX = c.x;
        dockY = c.y;
        applyDockLayout();
        // Also free the history window if split so nothing is corner-locked
        if ($('meta-dock')?.classList.contains('layout-split')) {
            ensureLibraryOnScreen();
        }
        try { window.FAFOPlayer?.undockHudForMove?.(); } catch (_) {}
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = 'Undocked · drag ⋮⋮ headers to place · Stick only blocks auto-jumps';
        }
    }

    /** Continuous UI scale from player chrome controls (wheel / Ctrl±). Does not touch video. */
    function syncScaleSliders() {
        const uiPct = Math.round(Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, uiScale || 1)) * 100);
        const uiSlider = $('meta-slider-ui');
        const uiVal = $('meta-slider-ui-val');
        if (uiSlider && document.activeElement !== uiSlider) uiSlider.value = String(uiPct);
        if (uiVal) uiVal.textContent = uiPct + '%';
        let vidPct = 100;
        try {
            const z = window.FAFOPlayer?.getVideoZoom?.();
            if (typeof z === 'number' && z > 0) vidPct = Math.round(z * 100);
        } catch (_) {}
        const vSlider = $('meta-slider-video');
        const vVal = $('meta-slider-video-val');
        // Match HTML max=400; never fight while dragging
        const sliderBusy = vSlider
            && (document.activeElement === vSlider || vSlider.matches?.(':active'));
        if (vSlider && !sliderBusy) {
            vSlider.value = String(Math.max(25, Math.min(400, vidPct)));
        }
        if (vVal) vVal.textContent = Math.max(25, Math.min(400, vidPct)) + '%';
        const sum = $('meta-fold-scale-summary');
        if (sum) sum.textContent = `UI ${uiPct}% · Video ${Math.max(25, Math.min(400, vidPct))}%`;
        document.querySelectorAll('#meta-scale-presets [data-ui-scale]').forEach((btn) => {
            const n = parseFloat(btn.getAttribute('data-ui-scale'));
            btn.classList.toggle('active', Number.isFinite(n) && Math.abs(n - (uiScale || 1)) < 0.02);
        });
    }

    function applyMetaUiScaleVar() {
        const s = String(Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Number(uiScale) || 1)));
        document.documentElement.style.setProperty('--meta-ui-scale', s);
        document.body?.style.setProperty('--meta-ui-scale', s);
        $('meta-dock')?.style.setProperty('--meta-ui-scale', s);
        $('meta-panel')?.style.setProperty('--meta-ui-scale', s);
        $('meta-library-panel')?.style.setProperty('--meta-ui-scale', s);
    }

    function setUiScale(s, opts = {}) {
        const n = Number(s);
        if (!Number.isFinite(n)) return;
        uiScale = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, Math.round(n * 100) / 100));
        // Apply scale then force everything fully on-screen (size + position)
        applyMetaUiScaleVar();
        applyTagLibraryHeight();
        reclampAllChromeAfterScale();
        if (!opts.fromChrome) {
            try { window.FAFOPlayer?.setChromeScale?.(uiScale, { toast: opts.toast !== false }); } catch (_) {}
        }
        scheduleLayoutSave();
        updateDockButtons();
        syncScaleSliders();
    }

    function bindScaleSliders() {
        const uiSlider = $('meta-slider-ui');
        const vSlider = $('meta-slider-video');
        if (uiSlider && !uiSlider.dataset.bound) {
            uiSlider.dataset.bound = '1';
            // Keep HTML range attributes in sync with continuous scale limits
            uiSlider.min = String(Math.round(UI_SCALE_MIN * 100));
            uiSlider.max = String(Math.round(UI_SCALE_MAX * 100));
            uiSlider.step = '1';
            const applyUi = (toast) => {
                const pct = parseInt(uiSlider.value, 10);
                if (!Number.isFinite(pct)) return;
                const next = Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, pct / 100));
                setUiScale(next, { fromChrome: false, toast: !!toast });
                const uiVal = $('meta-slider-ui-val');
                if (uiVal) uiVal.textContent = Math.round(next * 100) + '%';
            };
            uiSlider.addEventListener('input', () => applyUi(false));
            uiSlider.addEventListener('change', () => applyUi(true));
        }
        if (vSlider && !vSlider.dataset.bound) {
            vSlider.dataset.bound = '1';
            const applyVid = (toast) => {
                const pct = parseInt(vSlider.value, 10);
                if (!Number.isFinite(pct)) return;
                // 25–400% matches HTML range + FAFOPlayer limits
                const next = Math.max(0.25, Math.min(4, pct / 100));
                const vVal = $('meta-slider-video-val');
                if (vVal) vVal.textContent = Math.round(next * 100) + '%';
                try {
                    if (typeof window.FAFOPlayer?.setVideoZoom === 'function') {
                        // fromSlider: no toast spam while dragging; sticky zoom on release
                        window.FAFOPlayer.setVideoZoom(next, { toast: !!toast, fromSlider: true });
                    } else {
                        // Fallback if bridge not ready: write storage so player picks up
                        chrome.storage.local.get('fafoVideoStage').then((res) => {
                            const st = { ...(res.fafoVideoStage || {}), zoom: next };
                            chrome.storage.local.set({ fafoVideoStage: st });
                        }).catch(() => {});
                    }
                } catch (err) {
                    console.warn('video zoom slider', err);
                }
                if (els.status) {
                    els.status.textContent = `Video zoom · ${Math.round(next * 100)}%`;
                }
            };
            // input = every tick while dragging (true realtime)
            vSlider.addEventListener('input', () => applyVid(false));
            // change = pointer release — re-assert once more so zoom cannot snap back
            vSlider.addEventListener('change', () => {
                applyVid(true);
                requestAnimationFrame(() => {
                    try { window.FAFOPlayer?.setVideoZoom?.(parseInt(vSlider.value, 10) / 100, { toast: false }); } catch (_) {}
                });
            });
            vSlider.addEventListener('pointerup', () => {
                applyVid(false);
            });
            // Pointer events: some Windows touch/pen stacks only fire these
            vSlider.addEventListener('pointermove', (e) => {
                if (e.buttons) applyVid(false);
            });
        }
        $('meta-slider-ui-reset')?.addEventListener('click', () => {
            setUiScale(1, { fromChrome: false, toast: true });
            if (els.status) els.status.textContent = 'UI / tags scale → 100%';
        });
        $('meta-slider-video-reset')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.setVideoZoom?.(1, { toast: true }); } catch (_) {}
            syncScaleSliders();
            if (els.status) els.status.textContent = 'Video zoom → 100%';
        });
        $('meta-slider-video-fit')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.fitWholeFrame?.(); } catch (_) {
                try { window.FAFOPlayer?.setVideoZoom?.(1, { toast: true }); } catch (_) {}
            }
            syncScaleSliders();
            if (els.status) els.status.textContent = 'Video · fit whole frame';
        });
        syncScaleSliders();
        const presetRow = $('meta-scale-presets');
        if (presetRow && !presetRow.dataset.bound) {
            presetRow.dataset.bound = '1';
            presetRow.addEventListener('click', (e) => {
                const btn = e.target?.closest?.('[data-ui-scale]');
                if (!btn || !presetRow.contains(btn)) return;
                const next = parseFloat(btn.getAttribute('data-ui-scale'));
                if (!Number.isFinite(next)) return;
                setUiScale(next, { fromChrome: false, toast: true });
                if (els.status) els.status.textContent = `Tag scale · ${Math.round(next * 100)}%`;
            });
        }
        // Keep video slider in sync when wheel-zoom changes it
        if (!window.__fafoScaleSliderPoll) {
            window.__fafoScaleSliderPoll = setInterval(() => {
                if (document.hidden) return;
                try { syncScaleSliders(); } catch (_) {}
            }, 900);
        }
    }

    function cycleUiScale() {
        const presets = UI_SCALES;
        let i = presets.findIndex((s) => Math.abs(s - uiScale) < 0.02);
        if (i < 0) i = 0;
        setUiScale(presets[(i + 1) % presets.length], { fromChrome: false });
        if (els.status) els.status.textContent = `UI scale: ${Math.round(uiScale * 100)}%`;
    }

    function factoryLayoutDefaults() {
        return {
            dockPos: 'free',
            dockX: Math.max(18, Math.round((window.innerWidth || 1200) - 440)),
            dockY: 72,
            uiScale: 1,
            panelWidth: 400,
            panelHeight: 520,
            tagLibraryHeight: 200,
            stickLayout: true,
            /** Always two separate windows — never stack history under quick by default */
            split: true,
            panelOpen: true,
            libPosSaved: true,
            libX: 18,
            libY: 72,
            libW: Math.min(420, Math.round((window.innerWidth || 1200) * 0.34)),
            libH: Math.min(640, Math.round((window.innerHeight || 800) * 0.72)),
        };
    }

    function captureCurrentLayoutSnapshot() {
        capturePanelSize();
        // Live-measure floating library if open (library is unscaled — rect == layout)
        const lib = $('meta-library-panel');
        if (lib && !lib.classList.contains('collapsed') && $('meta-dock')?.classList.contains('layout-split')) {
            if (getComputedStyle(lib).position === 'fixed') {
                const r = lib.getBoundingClientRect();
                if (r.width > 40) {
                    libX = Math.round(r.left);
                    libY = Math.round(r.top);
                    libW = Math.round(lib.offsetWidth || r.width);
                    libH = Math.round(lib.offsetHeight || r.height);
                    libPosSaved = true;
                }
            }
        }
        return buildLayoutSlot();
    }

    /** Named layout presets (multiple savable setups you can switch between). */
    let layoutPresets = []; // { id, name, ...snapshot }
    let activeLayoutPresetId = '';

    async function loadLayoutPresetsStore() {
        try {
            const res = await chrome.storage.local.get(['fafoLayoutPresets', 'fafoLayoutPresetActive']);
            layoutPresets = Array.isArray(res.fafoLayoutPresets) ? res.fafoLayoutPresets : [];
            activeLayoutPresetId = res.fafoLayoutPresetActive || '';
        } catch {
            layoutPresets = [];
            activeLayoutPresetId = '';
        }
        renderLayoutPresetUi();
    }

    async function persistLayoutPresetsStore() {
        try {
            await chrome.storage.local.set({
                fafoLayoutPresets: layoutPresets,
                fafoLayoutPresetActive: activeLayoutPresetId || '',
            });
        } catch (_) {}
        renderLayoutPresetUi();
    }

    function renderLayoutPresetUi() {
        const sel = $('meta-layout-preset-select');
        if (!sel) return;
        const cur = sel.value;
        sel.innerHTML = '<option value="">— Layout presets —</option>' +
            layoutPresets.map((p) =>
                `<option value="${escapeAttr(p.id)}"${p.id === activeLayoutPresetId ? ' selected' : ''}>${escapeHtml(p.name || 'Preset')}</option>`
            ).join('');
        if (cur && layoutPresets.some((p) => p.id === cur)) sel.value = cur;
        else if (activeLayoutPresetId) sel.value = activeLayoutPresetId;
    }

    async function applyLayoutSnapshot(snap, opts = {}) {
        if (!snap || typeof snap !== 'object') return;
        dockPos = ['br', 'bl', 'tr', 'tl', 'free'].includes(snap.dockPos) ? snap.dockPos : 'br';
        dockX = typeof snap.dockX === 'number' ? snap.dockX : 18;
        dockY = typeof snap.dockY === 'number' ? snap.dockY : 18;
        uiScale = (typeof snap.uiScale === 'number' && snap.uiScale > 0)
            ? Math.max(UI_SCALE_MIN, Math.min(UI_SCALE_MAX, snap.uiScale))
            : DEFAULT_UI_SCALE;
        // Prefer dual-slot / normalized restore when snapshot includes norms or vp size
        if (typeof snap.dockNx === 'number' || (snap.vpW > 0 && snap.vpH > 0)) {
            applyLayoutSlotToState(snap, { skipPending: true });
        } else {
            panelWidth = typeof snap.panelWidth === 'number' ? snap.panelWidth : 0;
            panelHeight = typeof snap.panelHeight === 'number' ? snap.panelHeight : 0;
            if (panelWidth >= 260) preferredPanelW = panelWidth;
            if (panelHeight >= 200) preferredPanelH = panelHeight;
            tagLibraryHeight = typeof snap.tagLibraryHeight === 'number' ? snap.tagLibraryHeight : 160;
            stickLayout = snap.stickLayout !== false;
            libPosSaved = !!snap.libPosSaved;
            libX = typeof snap.libX === 'number' ? snap.libX : 18;
            libW = snap.libW > 0 ? snap.libW : Math.min(360, Math.round(window.innerWidth * 0.32));
            libH = snap.libH > 0 ? snap.libH : Math.min(Math.round(window.innerHeight * 0.72), 720);
            libY = typeof snap.libY === 'number' && snap.libY > 0
                ? snap.libY
                : Math.max(12, Math.round((window.innerHeight - libH) / 2));
        }
        if (typeof snap.tagLibraryHeight === 'number') tagLibraryHeight = snap.tagLibraryHeight;
        if (typeof snap.stickLayout === 'boolean') stickLayout = snap.stickLayout;

        if (els.panel) {
            if (panelWidth >= 260) els.panel.style.width = panelWidth + 'px';
            else els.panel.style.width = '';
            if (panelHeight >= 200) els.panel.style.height = panelHeight + 'px';
            else els.panel.style.height = '';
        }
        if (els.library) {
            els.library.style.height = tagLibraryHeight ? tagLibraryHeight + 'px' : '';
        }
        clearDockCornerStyles($('meta-dock'));
        applyDockLayout();
        setLibrarySplit(snap.split !== false, {
            forceDefault: !libPosSaved,
            keepCurrent: libPosSaved,
        });
        setMetaPanelOpen(snap.panelOpen !== false);
        // Always reclamp after applying a saved layout
        requestAnimationFrame(() => {
            reclampAllChromeAfterScale();
            scheduleLayoutSave();
        });
        if (els.status && !opts.silent) {
            els.status.textContent = opts.statusText || 'Layout applied · panels locked on-screen';
        }
    }

    async function saveLayoutAsPreset(name) {
        capturePanelSize();
        try { captureLibraryGeometry(); } catch (_) {}
        const snap = captureCurrentLayoutSnapshot();
        const label = (name || '').trim() || `Layout ${layoutPresets.length + 1}`;
        const id = 'lay_' + Date.now().toString(36);
        const entry = { id, name: label, ...snap };
        layoutPresets = [...layoutPresets.filter((p) => p.name !== label), entry].slice(0, 12);
        activeLayoutPresetId = id;
        await chrome.storage.local.set({ fafoMetaLayoutDefaults: snap });
        await persistLayoutPresetsStore();
        scheduleLayoutSave();
        if (els.status) els.status.textContent = `Saved layout preset “${label}”`;
        return entry;
    }

    async function updateActiveLayoutPreset() {
        if (!activeLayoutPresetId) {
            const name = prompt('Name this layout preset:', `Layout ${layoutPresets.length + 1}`);
            if (name == null) return;
            return saveLayoutAsPreset(name);
        }
        capturePanelSize();
        try { captureLibraryGeometry(); } catch (_) {}
        const snap = captureCurrentLayoutSnapshot();
        layoutPresets = layoutPresets.map((p) =>
            p.id === activeLayoutPresetId ? { ...p, ...snap, name: p.name, id: p.id } : p
        );
        await chrome.storage.local.set({ fafoMetaLayoutDefaults: snap });
        await persistLayoutPresetsStore();
        scheduleLayoutSave();
        const hit = layoutPresets.find((p) => p.id === activeLayoutPresetId);
        if (els.status) els.status.textContent = `Updated preset “${hit?.name || 'layout'}”`;
    }

    async function applyLayoutPresetById(id) {
        const p = layoutPresets.find((x) => x.id === id);
        if (!p) return;
        activeLayoutPresetId = id;
        await persistLayoutPresetsStore();
        await applyLayoutSnapshot(p, { statusText: `Switched to layout “${p.name}”` });
    }

    async function deleteLayoutPreset(id) {
        layoutPresets = layoutPresets.filter((p) => p.id !== id);
        if (activeLayoutPresetId === id) activeLayoutPresetId = '';
        await persistLayoutPresetsStore();
        if (els.status) els.status.textContent = 'Layout preset deleted';
    }

    /** Save current panel placement as the defaults Reset will restore. */
    async function saveLayoutAsDefaults() {
        // Capture live sizes/positions from the current selection on screen
        capturePanelSize();
        try { captureLibraryGeometry(); } catch (_) {}
        const snap = captureCurrentLayoutSnapshot();
        try {
            await chrome.storage.local.set({ fafoMetaLayoutDefaults: snap });
            // Also persist as live layout so reload matches what you see
            scheduleLayoutSave();
            await chrome.storage.local.set({
                fafoMetaSplit: snap.split,
                fafoMetaPanelOpen: snap.panelOpen,
                fafoMetaDockPos: snap.dockPos,
                fafoMetaDockX: snap.dockX,
                fafoMetaDockY: snap.dockY,
                fafoMetaUiScale: snap.uiScale,
                fafoMetaStickLayout: snap.stickLayout,
                fafoMetaPanelWidth: snap.panelWidth || undefined,
                fafoMetaPanelHeight: snap.panelHeight || undefined,
                fafoTagLibraryHeight: snap.tagLibraryHeight,
                fafoMetaLibX: snap.libX,
                fafoMetaLibY: snap.libY,
                fafoMetaLibW: snap.libW,
                fafoMetaLibH: snap.libH,
                fafoMetaLibPosSaved: snap.libPosSaved,
            });
            // Mirror into named presets if one is active, else create/update "Defaults"
            if (activeLayoutPresetId && layoutPresets.some((p) => p.id === activeLayoutPresetId)) {
                layoutPresets = layoutPresets.map((p) =>
                    p.id === activeLayoutPresetId ? { ...p, ...snap, name: p.name, id: p.id } : p
                );
            } else {
                const defId = 'lay_defaults';
                const existing = layoutPresets.find((p) => p.id === defId || p.name === 'Defaults');
                if (existing) {
                    layoutPresets = layoutPresets.map((p) =>
                        p.id === existing.id ? { ...p, ...snap, name: p.name || 'Defaults', id: p.id } : p
                    );
                    activeLayoutPresetId = existing.id;
                } else {
                    layoutPresets = [{ id: defId, name: 'Defaults', ...snap }, ...layoutPresets].slice(0, 12);
                    activeLayoutPresetId = defId;
                }
            }
            await persistLayoutPresetsStore();
            if (els.status) {
                els.status.textContent =
                    'Defaults locked to current panels · Reset layout restores this setup';
            }
            const btn = $('meta-layout-save-defaults');
            if (btn) {
                btn.classList.add('active');
                const prev = btn.textContent;
                btn.textContent = 'Defaults ✓';
                setTimeout(() => {
                    btn.textContent = prev || 'Save defaults';
                    btn.classList.remove('active');
                }, 1600);
            }
        } catch (e) {
            if (els.status) els.status.textContent = 'Could not save defaults: ' + (e.message || e);
        }
    }

    async function loadLayoutDefaults() {
        try {
            const { fafoMetaLayoutDefaults } = await chrome.storage.local.get('fafoMetaLayoutDefaults');
            if (fafoMetaLayoutDefaults && typeof fafoMetaLayoutDefaults === 'object') {
                return { ...factoryLayoutDefaults(), ...fafoMetaLayoutDefaults };
            }
        } catch { /* */ }
        return factoryLayoutDefaults();
    }

    async function resetLayout() {
        const d = await loadLayoutDefaults();
        const isUserDefaults = !!(d.savedAt);
        await applyLayoutSnapshot(d, {
            statusText: isUserDefaults
                ? 'Layout reset to YOUR saved defaults · on-screen locked'
                : 'Layout reset to factory · tags RIGHT · history LEFT · use Save defaults / presets',
        });
        try { window.FAFOPlayer?.resetHudLayout?.(); } catch (_) {}
    }

    function capturePanelSize() {
        if (!els.panel || els.panel.classList.contains('collapsed')) return;
        // Use layout size (offset*), not painted getBoundingClientRect — CSS scale on #meta-dock
        // would otherwise inflate saved width/height by uiScale and grow the panel on every save.
        const layoutW = Math.round(els.panel.offsetWidth || 0);
        const layoutH = Math.round(els.panel.offsetHeight || 0);
        if (layoutW >= 200) {
            panelWidth = layoutW;
            preferredPanelW = layoutW;
        }
        if (layoutH >= 140) {
            panelHeight = layoutH;
            preferredPanelH = layoutH;
        }
        markPanelExplicitSize();
    }

    function applyTagLibraryHeight() {
        if (els.library) {
            els.library.style.height = tagLibraryHeight + 'px';
        }
        if (els.panel) {
            if (panelWidth > 0) els.panel.style.width = panelWidth + 'px';
            if (panelHeight > 0) els.panel.style.height = panelHeight + 'px';
        }
    }

    function initPanelDrag() {
        const handle = $('meta-drag-handle') || document.querySelector('#meta-panel .meta-header');
        const dock = $('meta-dock');
        if (!handle || !dock) return;

        // Ensure handle is always interactive above resize edges
        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.zIndex = '20';

        let activePointerId = null;

        const onMove = (clientX, clientY) => {
            if (!dockDragging) return;
            // Layout coords (transform-origin top-left): painted left ≈ style left
            const c = clampDockFree(clientX - dockDragOffX, clientY - dockDragOffY);
            dockPos = 'free';
            dockX = c.x;
            dockY = c.y;
            placeDockAtLive(dockX, dockY);
            updateDockButtons();
        };

        const endDrag = (e) => {
            if (!dockDragging) return;
            dockDragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            document.removeEventListener('pointermove', onPointerMove, true);
            document.removeEventListener('pointerup', onPointerUp, true);
            document.removeEventListener('pointercancel', onPointerUp, true);
            document.removeEventListener('mousemove', onMouseMove, true);
            document.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            // One solid on-screen lock after the gesture (not mid-drag)
            placeDockAt(dockX, dockY);
            scheduleLayoutSave();
            if (els.status) els.status.textContent = 'Tags free-float position saved · locked on-screen';
        };

        const onPointerMove = (e) => {
            if (!dockDragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            endDrag(e);
        };
        const onMouseMove = (e) => {
            if (dockDragging) onMove(e.clientX, e.clientY);
        };
        const onMouseUp = () => endDrag();

        const startDrag = (clientX, clientY, target) => {
            // Only block pure control clicks (nav arrows / collapse), not the whole header
            if (target && target.closest && target.closest('.meta-nav button, a, input, select, textarea')) {
                return false;
            }
            // If panel collapsed, open so drag has a real box
            if (els.panel?.classList.contains('collapsed')) setMetaPanelOpen(true);
            const rect = dock.getBoundingClientRect();
            dockDragging = true;
            dockDragOffX = clientX - rect.left;
            dockDragOffY = clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Seed free coords from current on-screen rect (works from BR/BL/etc.)
            dockPos = 'free';
            dockX = Math.round(rect.left);
            dockY = Math.round(rect.top);
            setDockFreeStyles(dock, dockX, dockY);
            updateDockButtons();
            return true;
        };

        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (!startDrag(e.clientX, e.clientY, e.target)) return;
            activePointerId = e.pointerId;
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            // Document capture = drag keeps working even if pointer leaves the header
            document.addEventListener('pointermove', onPointerMove, true);
            document.addEventListener('pointerup', onPointerUp, true);
            document.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
        // Mouse fallback (some environments)
        handle.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            if (e.pointerType) return; // already handled by pointer events
            if (!startDrag(e.clientX, e.clientY, e.target)) return;
            document.addEventListener('mousemove', onMouseMove, true);
            document.addEventListener('mouseup', onMouseUp, true);
            e.preventDefault();
            e.stopPropagation();
        });

        // Resize / fullscreen handled by initLayoutMemoryWatch (proportional remap + dual slots)
    }

    function initPanelResizeObserver() {
        // Intentionally no auto-capture: lock()/scale reclamps change offsetWidth temporarily
        // and would permanently shrink preferred size. Sizes are captured only on user drag/resize end.
    }

    /**
     * Resize from any edge/corner. When dock is free-floating, west/north edges
     * also move the dock so the opposite side stays planted (natural window resize).
     */
    function initEdgeResize(panelEl, opts = {}) {
        if (!panelEl) return;
        const handles = panelEl.querySelectorAll('.meta-rh[data-edge]');
        if (!handles.length) return;

        // Allow nearly full-screen free resize on either panel
        const minW = opts.minW || 180;
        const minH = opts.minH || 120;
        const isMain = !!opts.isMainPanel;

        handles.forEach((handle) => {
            const edge = handle.dataset.edge || '';
            const onDown = (e) => {
                if (e.button != null && e.button !== 0) return;
                e.preventDefault();
                e.stopPropagation();
                const clientX = e.clientX ?? e.touches?.[0]?.clientX;
                const clientY = e.clientY ?? e.touches?.[0]?.clientY;
                if (clientX == null) return;

                const rect = panelEl.getBoundingClientRect();
                const dock = $('meta-dock');
                const free = dock?.classList.contains('dock-free') || dockPos === 'free';
                const dockRect = dock?.getBoundingClientRect();
                // Main panel lives under CSS scale on #meta-dock — use layout (offset) size, not painted
                const layoutW = isMain
                    ? Math.round(panelEl.offsetWidth || (rect.width / Math.max(UI_SCALE_MIN, uiScale || 1)))
                    : Math.round(rect.width);
                const layoutH = isMain
                    ? Math.round(panelEl.offsetHeight || (rect.height / Math.max(UI_SCALE_MIN, uiScale || 1)))
                    : Math.round(rect.height);

                edgeResizing = true;
                resizeDragging = true;
                handle.classList.add('dragging');
                document.body.style.userSelect = 'none';
                const cursors = {
                    n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize',
                    ne: 'nesw-resize', sw: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize',
                };
                document.body.style.cursor = cursors[edge] || 'nwse-resize';

                const state = {
                    edge,
                    startX: clientX,
                    startY: clientY,
                    startW: layoutW,
                    startH: layoutH,
                    // Main free-float: resize moves the whole dock; library: resize the panel itself
                    // left/top for free dock match painted origin (= style left/top with transform-origin top left)
                    startLeft: (isMain && free) ? (dockRect?.left ?? rect.left) : rect.left,
                    startTop: (isMain && free) ? (dockRect?.top ?? rect.top) : rect.top,
                    free,
                    isMain,
                };

                const onMove = (ev) => {
                    if (!edgeResizing) return;
                    const cx = ev.clientX ?? ev.touches?.[0]?.clientX;
                    const cy = ev.clientY ?? ev.touches?.[0]?.clientY;
                    if (cx == null) return;
                    const dx = cx - state.startX;
                    const dy = cy - state.startY;
                    let w = state.startW;
                    let h = state.startH;
                    let left = state.startLeft;
                    let top = state.startTop;

                    if (edge.includes('e')) w = state.startW + dx;
                    if (edge.includes('w')) {
                        w = state.startW - dx;
                        left = state.startLeft + dx;
                    }
                    if (edge.includes('s')) h = state.startH + dy;
                    if (edge.includes('n')) {
                        h = state.startH - dy;
                        top = state.startTop + dy;
                    }

                    // Size + position must stay fully inside the viewport
                    const ww = window.innerWidth || 800;
                    const wh = window.innerHeight || 600;
                    const margin = 4;
                    // Grow up to nearly the full remaining viewport (any size that fits)
                    const absMaxW = Math.max(minW, ww - margin * 2);
                    const absMaxH = Math.max(minH, wh - margin * 2);
                    // If west/north resized, re-derive left/top before clamping size to free edge space
                    if (edge.includes('w')) {
                        left = Math.round(state.startLeft + (state.startW - w));
                    }
                    if (edge.includes('n')) {
                        top = Math.round(state.startTop + (state.startH - h));
                    }
                    left = Math.max(margin, Math.min(ww - minW - margin, left));
                    top = Math.max(margin, Math.min(wh - minH - margin, top));
                    const maxW = Math.max(minW, Math.min(absMaxW, ww - left - margin));
                    const maxH = Math.max(minH, Math.min(absMaxH, wh - top - margin));
                    w = Math.max(minW, Math.min(maxW, Math.round(w)));
                    h = Math.max(minH, Math.min(maxH, Math.round(h)));
                    // Re-clamp position after final size so nothing hangs off
                    // Main dock is CSS-scaled; library panel is not
                    const isLib = !state.isMain && panelEl.classList.contains('meta-library-panel');
                    const boxed = clampFreeXY(left, top, w, h, { scale: isLib ? 1 : uiScale });
                    left = boxed.x;
                    top = boxed.y;
                    if (boxed.w) w = boxed.w;
                    if (boxed.h) h = boxed.h;

                    panelEl.style.width = w + 'px';
                    panelEl.style.height = h + 'px';
                    panelEl.style.maxWidth = (ww - margin * 2) + 'px';
                    panelEl.style.maxHeight = (wh - margin * 2) + 'px';

                    if (state.isMain) {
                        panelWidth = w;
                        panelHeight = h;
                        preferredPanelW = w;
                        preferredPanelH = h;
                    }

                    if (state.isMain && state.free && dock) {
                        dockPos = 'free';
                        dockX = left;
                        dockY = top;
                        dock.classList.add('dock-free');
                        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl');
                        // Live only while resizing — full lock on mouseup
                        placeDockAtLive(left, top);
                        updateDockButtons();
                    }

                    // Free-floating library panel: stay fully on-screen
                    if (!state.isMain && panelEl.classList.contains('meta-library-panel')) {
                        if (getComputedStyle(panelEl).position === 'fixed') {
                            panelEl.style.left = left + 'px';
                            panelEl.style.top = top + 'px';
                            panelEl.style.right = 'auto';
                            panelEl.style.bottom = 'auto';
                            libX = left;
                            libY = top;
                            libW = w;
                            libH = h;
                            libPosSaved = true;
                        }
                    }
                };

                const onUp = () => {
                    if (!edgeResizing) return;
                    edgeResizing = false;
                    resizeDragging = false;
                    handle.classList.remove('dragging');
                    document.body.style.cursor = '';
                    document.body.style.userSelect = '';
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    document.removeEventListener('touchmove', onMove);
                    document.removeEventListener('touchend', onUp);
                    if (state.isMain) {
                        capturePanelSize();
                        if (dockPos === 'free') placeDockAt(dockX, dockY);
                        else applyDockLayout();
                    } else {
                        captureLibraryGeometry();
                        ensureLibraryOnScreen();
                        window.FAFOViewport?.lock?.($('meta-library-panel'), {
                            margin: 4, canResize: true, minW: 200, minH: 120,
                        });
                    }
                    scheduleLayoutSave();
                };

                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
                document.addEventListener('touchmove', onMove, { passive: false });
                document.addEventListener('touchend', onUp);
            };

            handle.addEventListener('mousedown', onDown);
            handle.addEventListener('touchstart', onDown, { passive: false });
        });
    }

    function markPanelExplicitSize() {
        if (!els.panel) return;
        const has = (panelWidth > 0) || (panelHeight > 0)
            || !!(els.panel.style.width) || !!(els.panel.style.height);
        els.panel.classList.toggle('has-explicit-size', has);
    }

    function nudgePanelSize(dir) {
        if (!els.panel || els.panel.classList.contains('collapsed')) {
            setMetaPanelOpen(true);
        }
        const rect = els.panel.getBoundingClientRect();
        const step = 56;
        // Use layout size when scaled (offset*), not painted rect
        const layoutW = els.panel.offsetWidth || rect.width;
        const layoutH = els.panel.offsetHeight || rect.height;
        let w = (panelWidth > 0 ? panelWidth : layoutW) + dir * step;
        let h = (panelHeight > 0 ? panelHeight : layoutH) + dir * step;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        w = Math.max(200, Math.min(ww - 8, Math.round(w)));
        h = Math.max(140, Math.min(wh - 8, Math.round(h)));
        panelWidth = w;
        panelHeight = h;
        preferredPanelW = w;
        preferredPanelH = h;
        els.panel.style.width = w + 'px';
        els.panel.style.height = h + 'px';
        els.panel.style.maxWidth = (ww - 8) + 'px';
        els.panel.style.maxHeight = (wh - 8) + 'px';
        markPanelExplicitSize();
        // Keep free dock fully on-screen after size change
        if (dockPos === 'free') {
            placeDockAt(dockX, dockY);
        } else {
            applyDockLayout();
        }
        scheduleLayoutSave();
        if (els.status) els.status.textContent = `Panel size ${w}×${h} · drag edges/corners for free resize`;
    }

    /**
     * Collapsible Tools / Scale / Tracker chrome so the tags workspace gets the room.
     * Open/closed state persists in chrome.storage (fafoMetaFolds).
     */
    function initMetaFolds() {
        // Tools stay collapsed on the quick panel; scale+tracker live on Tag history (open by default)
        const defaults = { tools: false, scale: true, tracker: true };
        let state = { ...defaults };

        const applyOne = (id, open) => {
            const fold = $(`meta-fold-${id}`);
            const body = $(`meta-fold-${id}-body`);
            const btn = $(`meta-fold-${id}-btn`);
            if (!fold || !body || !btn) return;
            fold.classList.toggle('is-collapsed', !open);
            body.hidden = !open;
            btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            state[id] = !!open;
        };

        const persist = () => {
            try {
                chrome.storage.local.set({ fafoMetaFolds: { ...state } }).catch(() => {});
            } catch (_) {}
        };

        const bind = (id) => {
            const btn = $(`meta-fold-${id}-btn`);
            if (!btn || btn.dataset.foldBound) return;
            btn.dataset.foldBound = '1';
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                applyOne(id, !state[id]);
                persist();
            });
        };

        ['tools', 'scale', 'tracker'].forEach(bind);

        chrome.storage.local.get(['fafoMetaFolds'], (res) => {
            try {
                if (res?.fafoMetaFolds && typeof res.fafoMetaFolds === 'object') {
                    state = { ...defaults, ...res.fafoMetaFolds };
                }
            } catch (_) {}
            applyOne('tools', !!state.tools);
            applyOne('scale', !!state.scale);
            applyOne('tracker', !!state.tracker);
        });

        // Double-click Scale · chip in tools opens the scale fold
        $('meta-ui-scale')?.addEventListener('dblclick', () => {
            applyOne('scale', true);
            persist();
        });

        globalThis.FAFOMetaFolds = {
            open: (id) => { applyOne(id, true); persist(); },
            close: (id) => { applyOne(id, false); persist(); },
            toggle: (id) => { applyOne(id, !state[id]); persist(); },
            state: () => ({ ...state }),
        };
    }

    function initLibPanelDrag() {
        const handle = $('meta-lib-drag-handle');
        const lib = $('meta-library-panel');
        if (!handle || !lib) return;
        let dragging = false;
        let offX = 0;
        let offY = 0;
        let activePointerId = null;

        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.zIndex = '20';

        const onMove = (cx, cy) => {
            if (!dragging) return;
            // Ensure split mode while free-dragging history
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            }
            detachLibraryPanelToBody();
            const w = lib.offsetWidth || libW || 360;
            const h = lib.offsetHeight || libH || 400;
            // scale:1 — library is not CSS-scaled; allow full left edge (x=4)
            const c = clampFreeXY(cx - offX, cy - offY, w, h, { scale: 1 });
            lib.style.position = 'fixed';
            lib.style.left = c.x + 'px';
            lib.style.top = c.y + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            lib.style.transform = 'none';
            lib.style.zIndex = '120';
            libX = c.x;
            libY = c.y;
            if (c.w) { libW = c.w; lib.style.width = c.w + 'px'; }
            if (c.h) { libH = c.h; lib.style.height = c.h + 'px'; }
            libPosSaved = true;
        };
        const end = (e) => {
            if (!dragging) return;
            dragging = false;
            libDragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            document.removeEventListener('pointermove', onPointerMove, true);
            document.removeEventListener('pointerup', onPointerUp, true);
            document.removeEventListener('pointercancel', onPointerUp, true);
            document.removeEventListener('mousemove', onMouseMove, true);
            document.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            captureLibraryGeometry();
            ensureLibraryOnScreen();
            try {
                window.FAFOViewport?.lock?.($('meta-library-panel'), {
                    margin: 4, canResize: true, minW: 200, minH: 120,
                });
            } catch (_) {}
            scheduleLayoutSave();
            scheduleSettingsExport();
            if (els.status) {
                els.status.textContent = `Tag history at ${libX},${libY} (saved · locked on-screen)`;
            }
            try { window.dispatchEvent(new CustomEvent('fafo-dock-change')); } catch (_) {}
        };
        const onPointerMove = (e) => {
            if (!dragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            end(e);
        };
        const onMouseMove = (e) => { if (dragging) onMove(e.clientX, e.clientY); };
        const onMouseUp = () => end();

        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (e.target?.closest?.('button, input, a')) return;
            const rect = lib.getBoundingClientRect();
            dragging = true;
            libDragging = true;
            activePointerId = e.pointerId;
            offX = e.clientX - rect.left;
            offY = e.clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Convert to free immediately + portal so left edge works
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            } else {
                detachLibraryPanelToBody();
            }
            lib.style.position = 'fixed';
            lib.style.left = Math.round(rect.left) + 'px';
            lib.style.top = Math.round(rect.top) + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            lib.style.zIndex = '120';
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            document.addEventListener('pointermove', onPointerMove, true);
            document.addEventListener('pointerup', onPointerUp, true);
            document.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
        handle.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            if (e.pointerType) return;
            if (e.target?.closest?.('button, input, a')) return;
            const rect = lib.getBoundingClientRect();
            dragging = true;
            libDragging = true;
            offX = e.clientX - rect.left;
            offY = e.clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            } else {
                detachLibraryPanelToBody();
            }
            lib.style.position = 'fixed';
            lib.style.left = Math.round(rect.left) + 'px';
            lib.style.top = Math.round(rect.top) + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            lib.style.zIndex = '120';
            document.addEventListener('mousemove', onMouseMove, true);
            document.addEventListener('mouseup', onMouseUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
    }

    function updateSkipTaggedBtn() {
        if (!els.skipTagged) return;
        els.skipTagged.classList.toggle('active', skipTaggedMode);
        els.skipTagged.setAttribute('aria-pressed', skipTaggedMode ? 'true' : 'false');
        els.skipTagged.title = skipTaggedMode
            ? 'ON: skip tagged on Next · loop current clip until you press Next. Click to turn off.'
            : 'Skip tagged on Next; loop current clip continuously until you press Next (then 5+ tags when all tagged)';
        els.skipTagged.textContent = skipTaggedMode ? 'Skip tagged · ON' : 'Skip tagged';
    }

    async function setSkipTaggedMode(on) {
        skipTaggedMode = !!on;
        updateSkipTaggedBtn();
        try {
            await chrome.storage.local.set({ fafoSkipTaggedMode: skipTaggedMode });
        } catch { /* ignore */ }
        // Loop current clip while this mode is on — only Next advances
        try { window.FAFOPlayer?.setClipLoop?.(skipTaggedMode); } catch (_) {}
        if (els.status) {
            els.status.textContent = skipTaggedMode
                ? 'Skip tagged ON — loops this clip · Next skips tagged (then 5+ tags)'
                : 'Skip tagged off — auto-advance restored';
        }
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        // If we just turned it on and the current clip is already tagged, advance
        if (skipTaggedMode && activeTags.length > 0) {
            window.FAFOPlayer?.skipTrack?.(1);
        }
    }

    /**
     * Look up tag count for a playlist item (skip-tagged mode).
     * Uses stable FAFOId keys — exact match only (no fuzzy includes).
     */
    function tagCountForItem(item) {
        if (!item) return 0;
        const name = itemDisplayName(item);
        // Prefer live state for the clip currently bound in the panel
        if (activeName && name && activeName.toLowerCase() === String(name).toLowerCase()) {
            return activeTags.length;
        }
        if (item.mediaKey && mediaMeta[item.mediaKey]?.tags) {
            return mediaMeta[item.mediaKey].tags.length;
        }
        const size = item.size ?? item._size ?? null;
        if (globalThis.FAFOId?.findStoredMeta) {
            const hit = FAFOId.findStoredMeta(mediaMeta, { name, size });
            if (hit?.meta?.tags) return hit.meta.tags.length;
        } else {
            const byName = findStoredByName(name);
            if (byName?.meta?.tags) return byName.meta.tags.length;
        }
        return 0;
    }

    function isSkipTaggedMode() {
        return skipTaggedMode;
    }

    /** Pull tag vocabulary from toolbox/server without MRU bump. Public section only. */
    async function harvestTagsFromServer() {
        // Secret mode must never import the public Explorer/catalog tag dump
        if (privateSpaceActive) return;
        if (!(await toolboxOnline())) return;
        try {
            const r = await fetch(`${TOOLBOX_API}/tags`, { signal: AbortSignal.timeout(3000) });
            if (!r.ok) return;
            const tags = await r.json();
            if (Array.isArray(tags) && tags.length) {
                ensureTagsKnown(tags, { publicCatalogOnly: true });
                await saveStore();
                renderTagLibrary();
            }
        } catch { /* optional */ }
    }

    async function fetchTagsForIdentity(id) {
        if (!id?.name || !(await toolboxOnline())) return null;
        try {
            // Always request disk/shell tags (read_tags) so recovery works after storage wipes
            const q = new URLSearchParams({
                search: id.name,
                limit: '5',
                read_tags: 'true',
            });
            const r = await fetch(`${TOOLBOX_API}/media?${q}`, { signal: AbortSignal.timeout(8000) });
            if (!r.ok) return null;
            const data = await r.json();
            const items = data.items || data || [];
            if (!Array.isArray(items)) return null;
            let hit = items.find(m => m.name === id.name && (id.size == null || m.size === id.size));
            if (!hit) hit = items.find(m => m.name === id.name);
            if (!hit) return null;
            // If catalog item has no tags, try direct path read
            let tags = hit.tags || [];
            let rating = hit.rank != null ? Number(hit.rank) : 0;
            if ((!tags.length && !rating) && hit.path) {
                try {
                    const rq = new URLSearchParams({ path: hit.path });
                    const rr = await fetch(`${TOOLBOX_API}/fs/read-metadata?${rq}`, {
                        signal: AbortSignal.timeout(5000),
                    });
                    if (rr.ok) {
                        const meta = await rr.json();
                        tags = meta.tags || tags;
                        rating = meta.rating != null ? Number(meta.rating) : rating;
                    }
                } catch (_) {}
            }
            return { tags, rating, path: hit.path || null };
        } catch {
            return null;
        }
    }

    /** Exact name match only — no fuzzy key.includes(name). */
    function findStoredByName(name) {
        if (!name) return null;
        if (globalThis.FAFOId?.findStoredMeta) {
            return FAFOId.findStoredMeta(mediaMeta, { name }) || null;
        }
        const low = name.toLowerCase();
        const hits = [];
        for (const [k, v] of Object.entries(mediaMeta)) {
            if (v && v.name && String(v.name).toLowerCase() === low) hits.push({ key: k, meta: v });
        }
        return hits.length === 1 ? hits[0] : null;
    }

    function itemDisplayName(item) {
        if (globalThis.FAFOId?.displayNameFromItem) return FAFOId.displayNameFromItem(item);
        if (!item) return 'Unknown';
        if (item.handle?.name) return item.handle.name;
        if (typeof item === 'object' && item.name) return item.name;
        if (item.url) {
            try {
                return decodeURIComponent(item.url.split('?')[0].split('/').pop() || item.url);
            } catch { return item.url; }
        }
        return 'Unknown';
    }

    async function mediaKeyFor(item) {
        if (globalThis.FAFOId?.mediaKeyFor) return FAFOId.mediaKeyFor(item);
        if (!item) return null;
        if (item.handle) {
            try {
                const f = await item.handle.getFile();
                return `file:${f.name}|${f.size}|${f.lastModified}`;
            } catch {
                return 'handle:' + (item.handle.name || 'unknown');
            }
        }
        if (item.url) return 'url:' + item.url;
        return 'unknown:' + itemDisplayName(item);
    }

    async function identityForItem(item) {
        if (globalThis.FAFOId?.identityForItem) return FAFOId.identityForItem(item);
        const name = itemDisplayName(item);
        return { name, size: null, mtime: null };
    }

    async function toolboxOnline() {
        try {
            const r = await fetch(`${TOOLBOX_API}/health`, { signal: AbortSignal.timeout(1200) });
            if (!r.ok) return false;
            const j = await r.json().catch(() => ({}));
            const svc = String((j && j.service) || '');
            if (svc && !/fafo/i.test(svc)) return false;
            return true;
        } catch {
            return false;
        }
    }

    let diskSyncTimer = null;
    let diskSyncInFlight = null;
    let diskBatchTimer = null;
    /** Keys waiting for Explorer write — continuous auto-sync queue */
    const dirtyDiskKeys = new Set();
    /** Auto-write file metadata whenever tags/ratings change (default ON). */
    let autoDiskSync = true;

    function markDiskDirty(key) {
        if (key) dirtyDiskKeys.add(key);
        try {
            chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {});
        } catch (_) {}
        scheduleLiveStats();
        try { updateExplorerStatusUi(); } catch (_) {}
    }

    function updateAutoSyncUi() {
        const btn = $('meta-auto-disk-sync');
        if (!btn) return;
        btn.classList.toggle('active', !!autoDiskSync);
        btn.textContent = autoDiskSync ? 'Auto-sync · ON' : 'Auto-sync · off';
        btn.title = autoDiskSync
            ? 'ON: every tag/rating change writes Windows Explorer metadata. Server auto-starts with FAFO.'
            : 'OFF: tags only save in FAFO until you click Sync or turn Auto-sync on';
    }

    async function setAutoDiskSync(on) {
        autoDiskSync = !!on;
        try { await chrome.storage.local.set({ fafoAutoDiskSync: autoDiskSync }); } catch (_) {}
        updateAutoSyncUi();
        if (autoDiskSync) {
            if (activeKey) markDiskDirty(activeKey);
            scheduleFlushDirtyDisk();
            if (els.status) els.status.textContent = 'Auto-sync ON · file tags write when the disk server is up (it auto-starts)';
        } else if (els.status) {
            els.status.textContent = 'Auto-sync off · use Sync button for Explorer writes';
        }
    }

    /**
     * Debounced write of the active clip. While playing, Windows may lock the file;
     * server retries shell props after unlock.
     */
    function syncFileMetadataToDisk() {
        if (!autoDiskSync) return Promise.resolve();
        if (activeKey) markDiskDirty(activeKey);
        clearTimeout(diskSyncTimer);
        diskSyncTimer = setTimeout(() => {
            diskSyncInFlight = syncFileMetadataToDiskNow().finally(() => {
                diskSyncInFlight = null;
            });
            scheduleFlushDirtyDisk();
        }, 400);
        return diskSyncInFlight || Promise.resolve();
    }

    function scheduleFlushDirtyDisk() {
        if (!autoDiskSync) return;
        clearTimeout(diskBatchTimer);
        diskBatchTimer = setTimeout(() => {
            flushDirtyDiskMeta().catch(() => {});
        }, 1200);
    }

    /** Push all dirty mediaMeta entries to companion batch endpoint. */
    async function flushDirtyDiskMeta() {
        if (!autoDiskSync || !dirtyDiskKeys.size) return;
        if (!(await toolboxOnline())) {
            try { await ensureCompanionRunning({ timeoutMs: 16000 }); } catch (_) {}
        }
        if (!(await toolboxOnline())) return;
        try { await syncPlayFoldersToCompanion(); } catch (_) {}
        const items = [];
        const keys = [...dirtyDiskKeys];
        const L = globalThis.FAFOMetaLedger;
        const space = ledgerSpace();
        keys.forEach((key) => {
            const rec = L?.cache?.[space]?.files?.[key];
            if (rec && L && !L.isAutoEligible(rec)) {
                dirtyDiskKeys.delete(key);
                return;
            }
            const m = mediaMeta[key];
            if (!m?.name) return;
            items.push({
                client_key: key,
                name: m.name,
                size: m.size,
                mtime: m.mtime || m.lastModified,
                tags: userTagsOnly(m.tags || []),
                rating: Number(m.rating) || 0,
                update_catalog: true,
            });
        });
        if (!items.length) {
            dirtyDiskKeys.clear();
            return;
        }
        try {
            const r = await fetch(`${TOOLBOX_API}/fs/write-metadata-batch`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ items: items.slice(0, 200) }),
                signal: AbortSignal.timeout(60000),
            });
            const data = await r.json().catch(() => ({}));
            if (r.ok) {
                const written = Number(data.written);
                const results = Array.isArray(data.results) ? data.results : [];
                const deferred = data.deferred || 0;
                if (results.length) {
                    results.forEach((row) => {
                        if (!row || !row.client_key) return;
                        if (row.ok) {
                            dirtyDiskKeys.delete(row.client_key);
                            try {
                                globalThis.FAFOMetaLedger?.markApplied?.(space, row.client_key, {
                                    path: row.resolved_path,
                                    methods: row.methods,
                                    deferred: row.deferred_shell,
                                });
                            } catch (_) {}
                        } else {
                            let n = 0;
                            try {
                                n = globalThis.FAFOMetaLedger?.markFailed?.(space, row.client_key, row.error, {
                                    name: row.name,
                                }) || 0;
                            } catch (_) {}
                            if (n >= (globalThis.FAFOMetaLedger?.FAIL_LIMIT || 3)) {
                                dirtyDiskKeys.delete(row.client_key);
                                openFailQueue({ highlight: row.client_key });
                            }
                        }
                    });
                } else if (Number.isFinite(written) && written > 0) {
                    keys.forEach((k) => dirtyDiskKeys.delete(k));
                } else if (!('written' in (data || {}))) {
                    keys.forEach((k) => dirtyDiskKeys.delete(k));
                }
                try {
                    chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {});
                } catch (_) {}
                if (Number.isFinite(written) && written <= 0 && items.length) {
                    noteExplorerWrite(false, 'batch wrote 0');
                    scheduleLiveStats();
                    return;
                }
                noteExplorerWrite(true, deferred ? (deferred + ' deferred') : '');
                renderFailQueue();
                scheduleLiveStats();
                if (els.status && document.visibilityState === 'visible') {
                    els.status.textContent = deferred
                        ? `Auto-sync · ${written} file(s) · ${deferred} retry when unlocked`
                        : `Auto-sync · ${written} file(s) written to disk`;
                }
            }
        } catch {
            // keep dirty for next try
        }
    }

    function failQueueSpace() {
        return ledgerSpace();
    }

    function openFailQueue(opts) {
        const box = $('meta-fail-queue');
        if (!box) return;
        box.classList.remove('hidden');
        try { $('meta-fold-tracker-btn')?.setAttribute('aria-expanded', 'true'); } catch (_) {}
        const body = $('meta-fold-tracker-body');
        if (body) body.hidden = false;
        renderFailQueue(opts);
    }

    function closeFailQueue() {
        $('meta-fail-queue')?.classList.add('hidden');
    }

    function fmtFailTime(ms) {
        const n = Number(ms) || 0;
        if (!n) return '';
        try {
            return new Date(n).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
        } catch {
            return '';
        }
    }

    function renderFailQueue(opts) {
        const L = globalThis.FAFOMetaLedger;
        const space = failQueueSpace();
        const card = $('mls-fail-card');
        const logEl = $('meta-fail-log');
        const listEl = $('meta-fail-queue-list');
        const title = $('meta-fail-queue-title');
        const s = L?.stats?.(space) || {};
        const reviewN = Number(s.review) || 0;
        const failedN = Number(s.failed) || 0;
        const snoozedN = Number(s.snoozed) || 0;
        const droppedN = Number(s.dropped) || 0;
        if (card) {
            card.classList.toggle('hidden', !(reviewN || failedN || snoozedN));
        }
        const failsVal = $('mls-fails');
        if (failsVal) {
            failsVal.textContent = String(reviewN || failedN || 0);
            failsVal.classList.toggle('danger', !!(reviewN || failedN));
        }
        const failsSub = $('mls-fails-sub');
        if (failsSub) {
            failsSub.textContent = reviewN
                ? `${reviewN} at 3 strikes · click to review`
                : (failedN ? `${failedN} failed write(s) · log below` : '3 strikes → review / skip');
        }
        if (title) {
            title.textContent = reviewN
                ? `${reviewN} file(s) failed 3 times`
                : 'Failed writes';
        }
        const log = L?.recentFailLog?.(space, 24) || [];
        if (logEl) {
            if (!log.length) {
                logEl.innerHTML = '<div>No write failures logged yet.</div>';
            } else {
                logEl.innerHTML = log.map((row) => {
                    const name = String(row.name || row.key || 'file').replace(/[<>&]/g, '');
                    const err = String(row.error || 'write failed').replace(/[<>&]/g, '');
                    const t = fmtFailTime(row.at);
                    return `<div><span class="ff-name">${name}</span> · ${t} · <span class="ff-err">${err}</span></div>`;
                }).join('');
            }
        }
        if (!listEl) return;
        const review = L?.reviewEntries?.(space) || [];
        const held = (L?.heldEntries?.(space) || []).filter((r) => L.isSnoozed(r) || L.isDropped(r));
        const rows = [...review];
        held.forEach((h) => {
            if (!rows.some((r) => r.key === h.key)) rows.push(h);
        });
        if (!rows.length) {
            listEl.innerHTML = reviewN || failedN
                ? '<div class="meta-fail-row-meta">Under 3 fails — still auto-retrying. Log is above.</div>'
                : '';
            return;
        }
        const hi = opts?.highlight;
        listEl.innerHTML = '';
        rows.forEach((rec) => {
            const ex = rec.explorer || {};
            const n = Number(ex.failCount) || 0;
            const row = document.createElement('div');
            row.className = 'meta-fail-row';
            if (hi && rec.key === hi) row.style.borderColor = '#ff6b81';
            const name = rec.name || rec.key || 'file';
            const hold = ex.hold === 'dropped'
                ? 'dropped from queue'
                : (L.isSnoozed(rec)
                    ? ('skipped until ' + new Date(Number(ex.snoozeUntil) || 0).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }))
                    : `${n} fail(s)`);
            const err = ex.error || 'write failed';
            row.innerHTML = `<div class="meta-fail-row-name"></div>
                <div class="meta-fail-row-meta"></div>
                <div class="meta-fail-row-actions">
                    <button type="button" class="meta-skip-btn" data-act="review">Review</button>
                    <button type="button" class="meta-skip-btn" data-act="retry">Retry</button>
                    <button type="button" class="meta-skip-btn" data-act="snooze">Later</button>
                    <button type="button" class="meta-skip-btn" data-act="drop">Drop</button>
                </div>`;
            row.querySelector('.meta-fail-row-name').textContent = name;
            row.querySelector('.meta-fail-row-meta').textContent = hold + ' · ' + err;
            row.querySelectorAll('[data-act]').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    handleFailQueueAction(rec.key, btn.getAttribute('data-act'));
                });
            });
            listEl.appendChild(row);
        });
    }

    async function handleFailQueueAction(key, act) {
        const L = globalThis.FAFOMetaLedger;
        const space = failQueueSpace();
        if (!L || !key) return;
        const rec = L.cache[space]?.files?.[key];
        if (act === 'review') {
            await reviewFailedFile(rec);
            return;
        }
        if (act === 'retry') {
            L.markHold(space, key, '', { resetFails: true });
            dirtyDiskKeys.add(key);
            try { chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {}); } catch (_) {}
            if (els.status) els.status.textContent = 'Retrying ' + (rec?.name || 'file');
            renderFailQueue();
            scheduleFlushDirtyDisk();
            updateExplorerStatusUi();
            scheduleLiveStats();
            return;
        }
        if (act === 'snooze') {
            L.markHold(space, key, 'snooze');
            dirtyDiskKeys.delete(key);
            if (els.status) els.status.textContent = 'Skipped for 6 hours: ' + (rec?.name || 'file');
        } else if (act === 'drop') {
            L.markHold(space, key, 'dropped');
            dirtyDiskKeys.delete(key);
            if (els.status) els.status.textContent = 'Dropped from queue: ' + (rec?.name || 'file');
        }
        try { chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {}); } catch (_) {}
        renderFailQueue();
        updateExplorerStatusUi();
        scheduleLiveStats();
    }

    async function reviewFailedFile(rec) {
        if (!rec) return;
        openFailQueue({ highlight: rec.key });
        const name = rec.name;
        const list = window.FAFOPlayer?.getPlaylist?.() || [];
        const idx = list.findIndex((it) => (it?.name || it?.handle?.name) === name);
        if (idx >= 0 && window.FAFOPlayer?.playIndex) {
            try { await window.FAFOPlayer.playIndex(idx); } catch (_) {}
            if (els.status) els.status.textContent = 'Reviewing ' + name;
        } else if (els.status) {
            els.status.textContent = 'Not in current playlist · opening folder for ' + (name || 'file');
        }
        try {
            await fetch(`${TOOLBOX_API}/fs/reveal`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: rec.name,
                    size: rec.size,
                    mtime: rec.mtime,
                    path: rec.explorer?.path || '',
                }),
                signal: AbortSignal.timeout(8000),
            });
        } catch (_) {}
    }

    async function retryAllReviewItems() {
        const L = globalThis.FAFOMetaLedger;
        const space = failQueueSpace();
        const rows = [...(L?.reviewEntries?.(space) || []), ...(L?.heldEntries?.(space) || [])];
        rows.forEach((rec) => {
            if (!rec?.key || L.isDropped(rec)) return;
            L.markHold(space, rec.key, '', { resetFails: true });
            dirtyDiskKeys.add(rec.key);
        });
        try { chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {}); } catch (_) {}
        renderFailQueue();
        updateExplorerStatusUi();
        scheduleFlushDirtyDisk();
    }

    async function syncFileMetadataToDiskNow() {
        if (!activeKey) return;
        if (!(await toolboxOnline())) {
            try { await ensureCompanionRunning({ timeoutMs: 16000 }); } catch (_) {}
        }
        if (!(await toolboxOnline())) {
            if (els.status && autoDiskSync) {
                els.status.textContent = 'Saved in FAFO · starting file-tag server in the background';
            }
            return;
        }
        const item = window.FAFOPlayer?.getCurrentItem?.() || null;
        const id = await identityForItem(item);
        const m = mediaMeta[activeKey] || {};
        const name = id?.name || m.name || activeName;
        if (!name) return;
        // Capture snapshot so rapid tag changes still write the latest after debounce
        const payload = {
            name,
            size: id?.size ?? m.size,
            mtime: id?.mtime ?? m.mtime,
            tags: userTagsOnly(activeTags.length ? activeTags : (m.tags || [])),
            rating: activeRating || Number(m.rating) || 0,
            update_catalog: true,
            client_key: activeKey,
        };
        try {
            let r = await fetch(`${TOOLBOX_API}/fs/write-metadata`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            let data = await r.json().catch(() => ({}));
            if (!r.ok) {
                const detail = data.detail || r.statusText;
                const d = typeof detail === 'string' ? detail : JSON.stringify(detail);
                if (/not found in the metadata library/i.test(d)) {
                    try { await syncPlayFoldersToCompanion(); } catch (_) {}
                    try {
                        r = await fetch(`${TOOLBOX_API}/fs/write-metadata`, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload),
                        });
                        data = await r.json().catch(() => ({}));
                    } catch (_) {}
                }
            }
            if (!r.ok) {
                const detail = data.detail || r.statusText;
                const d = typeof detail === 'string' ? detail : JSON.stringify(detail);
                noteExplorerWrite(false, d);
                try {
                    const space = ledgerSpace();
                    const n = globalThis.FAFOMetaLedger?.markFailed?.(space, activeKey, d, { name }) || 0;
                    if (n >= (globalThis.FAFOMetaLedger?.FAIL_LIMIT || 3)) {
                        dirtyDiskKeys.delete(activeKey);
                        openFailQueue({ highlight: activeKey });
                    }
                } catch (_) {}
                renderFailQueue();
                if (els.status) {
                    els.status.textContent = /not found|library/i.test(d)
                        ? 'Saved in FAFO · click Add folder… and pick this library'
                        : `Saved in FAFO · file write: ${d}`;
                }
                return;
            }
            dirtyDiskKeys.delete(activeKey);
            try {
                chrome.storage.local.set({ fafoDiskDirtyKeys: [...dirtyDiskKeys] }).catch(() => {});
            } catch (_) {}
            try {
                const space = privateSpaceActive ? 'private' : 'public';
                globalThis.FAFOMetaLedger?.markApplied?.(space, activeKey, {
                    path: data.resolved_path,
                    methods: data.methods || data.file_write?.methods,
                    deferred: !!(data.file_locked || data.deferred_shell),
                });
            } catch (_) {}
            scheduleLiveStats();
            const methods = data.methods || data.file_write?.methods || [];
            const locked = !!(data.file_locked || data.deferred_shell);
            const hasShell = methods.some((m) => String(m).startsWith('shell'));
            if (els.status) {
                if (data.ok === false && !methods.length) {
                    noteExplorerWrite(false, locked ? 'file busy' : 'write failed');
                    els.status.textContent = locked
                        ? 'Saved in FAFO · file busy (Explorer write when playback unlocks)'
                        : 'Saved · file write failed';
                } else if (locked && !hasShell) {
                    els.status.textContent =
                        `Auto-synced · ${(methods.join(', ') || 'embedded')} · Explorer when file unlocks`;
                } else {
                    noteExplorerWrite(true, (methods.join(', ') || 'ok'));
                    els.status.textContent =
                        `Auto-synced to file · ${(methods.join(', ') || 'ok')}`;
                }
            }
        } catch {
            noteExplorerWrite(false, 'could not reach server');
            if (els.status) els.status.textContent = 'Saved in FAFO · could not reach toolbox server';
        }
    }

    async function persistActiveMeta(opts = {}) {
        if (!activeKey) return;
        const now = Date.now();
        // Quick panel only holds user tags; pairId stays on its own field
        activeTags = userTagsOnly(activeTags);
        const prev = mediaMeta[activeKey] || {};
        // Undo snapshot (skip when restoring from undo or bulk already pushed)
        if (!opts.fromUndo && !opts.skipUndo && globalThis.FAFOUndo?.push) {
            try {
                const labelParts = [];
                if (opts.touchedTags?.length) labelParts.push('+' + opts.touchedTags.join(', '));
                if (opts.removedTags?.length) labelParts.push('−' + opts.removedTags.join(', '));
                if (opts.ratingOnly) labelParts.push('rating');
                FAFOUndo.push({
                    key: activeKey,
                    label: opts.undoLabel || labelParts.join(' ') || (activeName || 'tag edit'),
                    rating: prev.rating ?? 0,
                    tags: Array.isArray(prev.tags) ? prev.tags.slice() : [],
                    pairId: prev.pairId || '',
                });
            } catch (_) {}
        }
        const pairId = activePairId
            || prev.pairId
            || (globalThis.FAFOId?.pairIdFromMeta ? FAFOId.pairIdFromMeta(prev) : '');
        mediaMeta[activeKey] = {
            ...prev,
            rating: activeRating,
            tags: [...activeTags],
            name: activeName,
            size: opts.size != null ? opts.size : prev.size,
            pairId: pairId || prev.pairId || undefined,
            pairRole: prev.pairRole,
            updated: now,
        };
        activePairId = pairId || '';
        // Apply counters: + on apply, − on remove (not for full resaves / rating-only)
        const touched = opts.touchedTags != null ? opts.touchedTags : [];
        const removed = opts.removedTags != null ? opts.removedTags : [];
        if (touched && touched.length) touchTags(touched, now);
        if (removed && removed.length) untouchTags(removed);
        // Ensure every active tag is in the vocabulary without apply-count bumps
        try { ensureTagsKnown(activeTags); } catch (e) { console.warn('ensureTagsKnown', e); }
        // Rebuild library (file) frequency — dropping a tag lowers its total by 1
        rebuildLibraryTagCounts();
        sortTagLibrary();
        if (activeKey) sessionVideosTouched.add(activeKey);
        await saveStore();
        try {
            const space = privateSpaceActive ? 'private' : 'public';
            globalThis.FAFOMetaLedger?.recordConfigured?.(space, activeKey, mediaMeta[activeKey]);
        } catch (_) {}
        renderMetaPanel();
        scheduleLiveStats();
        // Tagging never auto-advances; refresh loop state (untagged loop ends when tagged)
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        if (activeTags.length) clearUntaggedPrompt();
        // Continuous Explorer write — every change, not only manual Sync
        markDiskDirty(activeKey);
        syncFileMetadataToDisk().catch(() => {});
        if (touched && touched.length) await maybeApplyAndNext();
    }

    /**
     * Before painting expanded panels: re-read viewport, re-apply saved scale,
     * then remap last known positions/sizes for this mode (windowed/fullscreen).
     * Call this only when the user opens Tags — not on every new-tab load.
     */
    function prepareLayoutForExpand() {
        const vp = currentViewportSize();
        const mode = currentLayoutMode();
        // Prefer mode-matching memory, then the other mode, then live state
        const slot =
            layoutMemorySlots[mode]
            || layoutMemorySlots.windowed
            || layoutMemorySlots.fullscreen
            || null;
        if (slot) {
            // Apply sizes/positions with fromNorm (handles resize / DPI / zoom)
            applyLayoutSlotToState(slot, { skipPending: true });
            if (typeof slot.split === 'boolean') {
                window.__fafoMetaSplitPending = slot.split;
            }
        } else if (layoutVpW > 0 && layoutVpH > 0 && (layoutVpW !== vp.w || layoutVpH !== vp.h)) {
            // Legacy remap without a full slot
            const rem = window.FAFOViewport?.fromNorm?.({
                x: dockX, y: dockY, w: panelWidth, h: panelHeight,
                vpW: layoutVpW, vpH: layoutVpH,
            });
            if (rem) {
                dockX = rem.x;
                dockY = rem.y;
                if (rem.w >= 260) panelWidth = rem.w;
                if (rem.h >= 200) panelHeight = rem.h;
            }
            if (libPosSaved) {
                const remL = window.FAFOViewport?.fromNorm?.({
                    x: libX, y: libY, w: libW, h: libH,
                    vpW: layoutVpW, vpH: layoutVpH,
                });
                if (remL) {
                    libX = remL.x;
                    libY = remL.y;
                    if (remL.w >= 200) libW = remL.w;
                    if (remL.h >= 140) libH = remL.h;
                }
            }
        }
        // Preferred sizes back after any temporary clamp
        if (preferredPanelW >= 260) panelWidth = preferredPanelW;
        if (preferredPanelH >= 200) panelHeight = preferredPanelH;

        layoutVpW = vp.w;
        layoutVpH = vp.h;
        layoutModeActive = mode;

        // 1) Scale CSS first so painted size matches saved layout math
        applyMetaUiScaleVar();
        applyTagLibraryHeight();
        updateDockButtons();
        syncScaleSliders();
        try { window.FAFOPlayer?.setChromeScale?.(uiScale, { toast: false }); } catch (_) {}
    }

    /**
     * After panel is visible: place dock + library using current scale + remapped coords.
     * Double-rAF so offsetWidth reflects scaled layout before clamp/lock.
     */
    function paintExpandedLayout() {
        // Tag history stays a separate free window unless user explicitly turned Separate off.
        // pending false → attached; anything else (true/null/undefined) → separate (default).
        const pending = window.__fafoMetaSplitPending;
        const wantSplit = pending !== false;

        // Full dock place (not scaleOnly) — uses free coords or corner snap
        applyDockLayout({ scaleOnly: false });

        if (wantSplit) {
            setLibrarySplit(true, { forceDefault: false, keepCurrent: false });
            window.__fafoMetaSplitPending = true;
        } else {
            // Ensure library is visible with dock (non-split) when user didn't hide it
            const lib = $('meta-library-panel');
            if (lib && !lib.dataset.userHidden) {
                lib.classList.remove('collapsed');
                lib.setAttribute('aria-hidden', 'false');
            }
        }

        // After layout paints, reclamp with real measurements
        requestAnimationFrame(() => {
            applyDockLayout({ scaleOnly: false });
            if ($('meta-dock')?.classList.contains('layout-split')) {
                applyLibraryPanelGeometry({ forceDefault: false });
                ensureLibraryOnScreen();
            }
            reclampAllChromeAfterScale();
            requestAnimationFrame(() => {
                if (dockPos === 'free' || ['br', 'bl', 'tr', 'tl'].includes(dockPos)) {
                    applyDockLayout({ scaleOnly: false });
                }
                if ($('meta-dock')?.classList.contains('layout-split')) {
                    ensureLibraryOnScreen();
                }
                reclampAllChromeAfterScale();
                // Persist remapped expand so next open matches what we painted
                scheduleLayoutSave();
            });
        });
    }

    function setMetaPanelOpen(open) {
        if (open) {
            // Scale + remap last known positions BEFORE un-collapsing
            prepareLayoutForExpand();
        }

        metaPanelOpen = open;
        if (els.panel) {
            els.panel.classList.toggle('collapsed', !open);
            els.panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        }
        // Tag history panel tracks the main tags UI (unless user hid it while open)
        const lib = $('meta-library-panel');
        if (lib) {
            if (!open) {
                lib.classList.add('collapsed');
                lib.setAttribute('aria-hidden', 'true');
            } else if (!lib.dataset.userHidden) {
                // May still be collapsed until paintExpandedLayout applies split
                lib.classList.remove('collapsed');
                lib.setAttribute('aria-hidden', 'false');
            }
        }
        if (els.toggle) els.toggle.classList.toggle('open', open);
        if (open) {
            paintExpandedLayout();
            // Ensure history click wiring is live (DOM may have been rebuilt)
            try { initLibraryTagInteraction(); } catch (_) {}
            renderTagLibrary();
            renderTagSuggestions(els.tagInput?.value || '');
        } else {
            hideSuggestions();
            // Capture placement while still measurable (before next expand)
            try {
                if (panelWidth >= 260) preferredPanelW = panelWidth;
                if (panelHeight >= 200) preferredPanelH = panelHeight;
                captureLibraryGeometry();
                rememberLayoutSlot();
            } catch (_) {}
        }
        // Remember open/closed — but boot always starts compact (see loadStore)
        chrome.storage.local.set({ fafoMetaPanelOpen: !!open }).catch(() => {});
        scheduleLayoutSave();
    }

    function setLibrarySplit(split, opts = {}) {
        const dock = $('meta-dock');
        const lib = $('meta-library-panel');
        if (!dock || !lib) return;
        dock.classList.toggle('layout-split', !!split);
        window.__fafoMetaSplitPending = !!split;
        if (split) {
            // Portal out of scaled #meta-dock so left placement is not clamped to the dock box
            detachLibraryPanelToBody();
            lib.classList.remove('collapsed');
            lib.dataset.userHidden = '';
            delete lib.dataset.userHidden;
            // Restore sticky geometry — do NOT jump to defaults if user already placed it
            applyLibraryPanelGeometry({
                forceDefault: !!opts.forceDefault,
                keepCurrent: !!opts.keepCurrent,
            });
            ensureLibraryOnScreen();
            // Never force dock to BR on split — free + stick must keep left/right independent
        } else {
            // Capture geometry before re-attaching so re-split restores it
            captureLibraryGeometry();
            reattachLibraryPanelToDock();
            if (metaPanelOpen) {
                lib.classList.remove('collapsed');
                delete lib.dataset.userHidden;
            }
        }
        chrome.storage.local.set({ fafoMetaSplit: !!split }).catch(() => {});
        scheduleLayoutSave();
        scheduleSettingsExport();
        const btn = $('meta-split-toggle');
        if (btn) {
            btn.classList.toggle('active', !!split);
            btn.textContent = split ? 'Separate · ON' : 'Separate · off';
            btn.title = split
                ? 'Two free windows (history independent). Click to attach under quick panel.'
                : 'History attached under quick. Click for two separate free windows.';
        }
        // Keep secondary split button in sync
        const btn2 = $('meta-split-toggle-2');
        if (btn2) {
            btn2.classList.toggle('active', !!split);
            btn2.title = split ? 'Attach history under quick panel' : 'Separate history as free window';
        }
        try { window.dispatchEvent(new CustomEvent('fafo-dock-change')); } catch (_) {}
    }

    function toggleLibrarySplit() {
        const dock = $('meta-dock');
        const on = !dock?.classList.contains('layout-split');
        setLibrarySplit(on, { forceDefault: false });
        if (on && dockPos !== 'free') {
            // Keep windows independent — free-float the quick panel too
            dockPos = 'free';
            applyDockLayout();
            updateDockButtons();
        }
        if (els.status) {
            els.status.textContent = on
                ? (libPosSaved
                    ? 'Separate windows · history where you left it · drag edges to any size on screen'
                    : 'Separate windows · history left · drag headers / edges freely')
                : 'Tag history attached under quick panel';
        }
    }

    function setRating(r) {
        if (r === activeRating) activeRating = 0;
        else activeRating = Math.max(0, Math.min(5, r));
        persistActiveMeta({ ratingOnly: true });
    }

    /**
     * Restore tags/rating for a media key (undo). Rebinds UI if this is the active clip.
     */
    async function restoreMetaSnapshot(key, snap, opts = {}) {
        if (!key || !snap) return;
        const prev = mediaMeta[key] || {};
        const tags = Array.isArray(snap.tags) ? snap.tags.slice() : [];
        mediaMeta[key] = {
            ...prev,
            rating: Math.max(0, Math.min(5, Number(snap.rating) || 0)),
            tags,
            pairId: snap.pairId || prev.pairId,
            updated: Date.now(),
        };
        // Bring restored tag names back into vocabulary after purge/rename undos
        try { ensureTagsKnown(userTagsOnly(tags)); } catch (_) {}
        if (!opts.deferSave) await saveStore();
        if (key === activeKey) {
            activeRating = mediaMeta[key].rating || 0;
            activeTags = userTagsOnly(mediaMeta[key].tags || []);
            activePairId = mediaMeta[key].pairId || '';
            if (!opts.deferRender) {
                renderMetaPanel();
                markDiskDirty(activeKey);
                syncFileMetadataToDisk().catch(() => {});
                try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
            }
        }
        if (!opts.deferRender) scheduleLiveStats();
        if (opts.fromUndo && els.status && !opts.quiet) {
            els.status.textContent = 'Undid edit on ' + (mediaMeta[key].name || 'clip');
        }
    }

    /** Snapshot every media entry that currently holds any of the given tags (for bulk undo). */
    function snapshotMediaHoldingTags(tagNames) {
        const lows = new Set(
            (Array.isArray(tagNames) ? tagNames : [])
                .map((t) => normalizeTag(t).toLowerCase())
                .filter(Boolean)
        );
        if (!lows.size) return [];
        const items = [];
        Object.keys(mediaMeta).forEach((k) => {
            const m = mediaMeta[k];
            if (!m || !Array.isArray(m.tags)) return;
            const hit = m.tags.some((x) => lows.has(normalizeTag(x).toLowerCase()));
            if (!hit) return;
            items.push({
                key: k,
                rating: m.rating ?? 0,
                tags: m.tags.slice(),
                pairId: m.pairId || '',
            });
        });
        return items;
    }

    function getSelectedTags() {
        return Array.from(selectedTags.values());
    }

    function isTagSelected(tag) {
        return selectedTags.has(normalizeTag(tag).toLowerCase());
    }

    function setTagSelected(tag, on) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        if (on) selectedTags.set(low, t);
        else selectedTags.delete(low);
    }

    function clearTagSelection() {
        selectedTags.clear();
        lastClickedSelectLow = '';
        updateMultiSelectUi();
        // Sync all panels (library, hotkeys, HUD, recents, E-set, sprint…)
        try { syncAllTagUiState(); } catch (_) {}
    }

    function selectAllVisibleTags() {
        const list = lastVisibleTagList.length
            ? lastVisibleTagList
            : tagLibrary.filter((t) => isInNormalTagMenu(t));
        list.forEach((t) => setTagSelected(t, true));
        multiSelectMode = true;
        updateMultiSelectUi();
        renderTagLibrary();
        if (els.status) els.status.textContent = `Selected ${selectedTags.size} tag(s)`;
    }

    function toggleTagInSelection(tag, opts = {}) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        if (opts.range && lastClickedSelectLow && lastVisibleTagList.length) {
            const lows = lastVisibleTagList.map((x) => x.toLowerCase());
            const a = lows.indexOf(lastClickedSelectLow);
            const b = lows.indexOf(low);
            if (a >= 0 && b >= 0) {
                const lo = Math.min(a, b);
                const hi = Math.max(a, b);
                for (let i = lo; i <= hi; i++) setTagSelected(lastVisibleTagList[i], true);
                lastClickedSelectLow = low;
                updateMultiSelectUi();
                renderTagLibrary();
                return;
            }
        }
        if (opts.addOnly) setTagSelected(t, true);
        else setTagSelected(t, !isTagSelected(t));
        lastClickedSelectLow = low;
        updateMultiSelectUi();
        // Sync selected + on-file color on every panel that shows this tag
        try {
            syncAllTagUiState();
        } catch (_) {
            // Fallback: library-only class toggle
            document.querySelectorAll('#meta-tag-library .meta-lib-tag').forEach((btn) => {
                if ((btn.dataset.tag || '').toLowerCase() !== low) return;
                const on = isTagSelected(t);
                btn.classList.toggle('selected', on);
                btn.setAttribute('aria-selected', on ? 'true' : 'false');
                const check = btn.querySelector('.meta-lib-check');
                if (check) check.textContent = on ? '✓' : '';
            });
        }
    }

    function setMultiSelectMode(on) {
        multiSelectMode = !!on;
        if (!multiSelectMode) clearTagSelection();
        else updateMultiSelectUi();
        const btn = $('meta-multi-select');
        if (btn) {
            btn.classList.toggle('active', multiSelectMode);
            btn.textContent = multiSelectMode ? 'Selecting…' : 'Select';
        }
        document.getElementById('meta-library-panel')?.classList.toggle('multi-select-on', multiSelectMode);
        document.getElementById('meta-panel')?.classList.toggle('multi-select-on', multiSelectMode);
        if (els.status) {
            els.status.textContent = multiSelectMode
                ? 'Multi-select ON · click tags · Shift=range · All = visible'
                : 'Multi-select off';
        }
    }

    function updateMultiSelectUi() {
        const bar = $('meta-multi-bar');
        const countEl = $('meta-multi-count');
        const n = selectedTags.size;
        if (countEl) countEl.textContent = n ? `${n} selected` : '0 selected';
        if (bar) bar.classList.toggle('hidden', n === 0 && !multiSelectMode);
        const btn = $('meta-multi-select');
        if (btn) {
            btn.classList.toggle('active', multiSelectMode);
            btn.textContent = multiSelectMode ? (n ? `Select · ${n}` : 'Selecting…') : 'Select';
        }
        updateUndoBackButton();
    }

    function updateUndoBackButton() {
        const btn = $('meta-undo-back');
        if (!btn) return;
        const n = globalThis.FAFOUndo?.stackSize?.() ?? 0;
        const peek = globalThis.FAFOUndo?.peek?.();
        btn.disabled = n <= 0;
        btn.classList.toggle('has-undo', n > 0);
        btn.textContent = n > 0 ? `↩ Back · ${n}` : '↩ Back';
        btn.title = n > 0
            ? `Undo: ${peek?.label || 'last change'} (${n}/${globalThis.FAFOUndo?.max || 50}) · Ctrl+Z`
            : 'Nothing to undo yet · last 50 tag/rating changes are stored';
        // Status chips
        try {
            const chip = document.querySelector('#fafo-status-chips [data-act="undo"]');
            if (chip) {
                chip.textContent = n > 0 ? `Back · ${n}` : 'Back';
                chip.title = btn.title;
                chip.classList.toggle('ok', n > 0);
            }
        } catch (_) {}
    }

    async function bulkApplySelected() {
        const tags = getSelectedTags();
        if (!tags.length) return;
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active to tag';
            return;
        }
        const prev = mediaMeta[activeKey] || {};
        try {
            FAFOUndo.push({
                key: activeKey,
                label: `+${tags.length} tags`,
                rating: prev.rating ?? 0,
                tags: Array.isArray(prev.tags) ? prev.tags.slice() : [],
                pairId: prev.pairId || '',
            });
        } catch (_) {}
        const newly = [];
        tags.forEach((t) => {
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            }
        });
        ensureTagsKnown(tags);
        await persistActiveMeta({ touchedTags: newly, skipUndo: true, undoLabel: `+${tags.length} tags` });
        if (els.status) els.status.textContent = `Applied ${newly.length}/${tags.length} selected tag(s)`;
    }

    async function bulkRemoveSelected() {
        const tags = getSelectedTags();
        if (!tags.length) return;
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active';
            return;
        }
        const lows = new Set(tags.map((t) => t.toLowerCase()));
        const prev = mediaMeta[activeKey] || {};
        try {
            FAFOUndo.push({
                key: activeKey,
                label: `−${tags.length} tags`,
                rating: prev.rating ?? 0,
                tags: Array.isArray(prev.tags) ? prev.tags.slice() : [],
                pairId: prev.pairId || '',
            });
        } catch (_) {}
        const removed = [];
        activeTags = activeTags.filter((x) => {
            if (lows.has(x.toLowerCase())) {
                removed.push(x);
                return false;
            }
            return true;
        });
        await persistActiveMeta({ removedTags: removed, skipUndo: true });
        if (els.status) els.status.textContent = `Removed ${removed.length} tag(s) from this file`;
    }

    async function bulkHideSelected() {
        const tags = getSelectedTags();
        if (!tags.length) return;
        for (const t of tags) {
            if (!excludedTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                excludedTags.push(t);
            }
        }
        await persistExcludedTags();
        clearTagSelection();
        setMultiSelectMode(false);
        renderTagLibrary();
        renderHiddenTagsPanel();
        if (els.status) els.status.textContent = `Hidden ${tags.length} tag(s) from list`;
    }

    async function bulkPurgeSelected() {
        const tags = getSelectedTags();
        if (!tags.length) return;
        const ok = window.confirm(
            `Remove ${tags.length} tag(s) from ALL media?\n\n` +
            tags.slice(0, 12).map((t) => `· ${t}`).join('\n') +
            (tags.length > 12 ? `\n· … +${tags.length - 12} more` : '') +
            `\n\nAlso clears hotkeys / E-set / library entries.\nUse ↩ Back to restore file tags (last 50 ops).`
        );
        if (!ok) return;
        const items = snapshotMediaHoldingTags(tags);
        if (items.length && globalThis.FAFOUndo?.pushBatch) {
            FAFOUndo.pushBatch({ label: `Purge ${tags.length} tags`, items });
        }
        for (const t of tags) {
            await purgeTagEverywhere(t, { skipConfirm: true, skipUndo: true, quiet: true });
        }
        clearTagSelection();
        setMultiSelectMode(false);
        if (els.status) els.status.textContent = `Purged ${tags.length} tag(s) · ${items.length} file(s) · ↩ Back undoes`;
    }

    async function bulkRenameSelected() {
        const tags = getSelectedTags();
        if (!tags.length) return;
        if (tags.length === 1) {
            await renameTagEverywhere(tags[0]);
            return;
        }
        const find = window.prompt(
            `Find text in ${tags.length} selected tag names (case-insensitive):`,
            ''
        );
        if (find == null || !String(find).trim()) {
            if (els.status) els.status.textContent = 'Rename cancelled';
            return;
        }
        const repl = window.prompt(`Replace “${find}” with:`, '');
        if (repl == null) return;
        const needle = String(find);
        const items = snapshotMediaHoldingTags(tags);
        if (items.length && globalThis.FAFOUndo?.pushBatch) {
            FAFOUndo.pushBatch({ label: `Rename ×${tags.length}`, items });
        }
        let n = 0;
        const re = new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig');
        for (const t of tags) {
            const renamed = normalizeTag(String(t).replace(re, repl));
            if (!renamed || renamed.toLowerCase() === t.toLowerCase()) continue;
            await renameTagEverywhere(t, { to: renamed, skipPrompt: true, skipUndo: true, quiet: true });
            n++;
        }
        clearTagSelection();
        renderTagLibrary();
        if (els.status) els.status.textContent = `Renamed ${n}/${tags.length} tag(s) · ↩ Back undoes file tags`;
    }

    async function bulkColorSelected(anchorEvent) {
        const tags = getSelectedTags();
        if (!tags.length) return;
        // Open the normal color context menu on the first tag; after apply, copy slot to all
        const first = tags[0];
        showTagContextMenu(anchorEvent || { clientX: 120, clientY: 120, preventDefault() {}, stopPropagation() {} }, first, {
            bulkTags: tags,
        });
    }

    async function runMultiAction(action, ev) {
        switch (action) {
            case 'apply': return bulkApplySelected();
            case 'remove': return bulkRemoveSelected();
            case 'hide': return bulkHideSelected();
            case 'purge': return bulkPurgeSelected();
            case 'rename': return bulkRenameSelected();
            case 'color': return bulkColorSelected(ev);
            case 'clear':
                clearTagSelection();
                if (!multiSelectMode) updateMultiSelectUi();
                return;
            default: return;
        }
    }

    async function addTagsFromInput() {
        if (!els.tagInput) return;
        const parts = els.tagInput.value.split(/[,;]+/).map(normalizeTag).filter((t) => t && !isOversizedOrSuspectTag(t));
        if (!parts.length) return;
        const newly = [];
        parts.forEach(t => {
            if (!activeTags.some(x => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            } else {
                newly.push(t); // still counts as "used" for MRU order
            }
        });
        els.tagInput.value = '';
        hideSuggestions();
        await persistActiveMeta({ touchedTags: newly });
    }

    /**
     * Apply / remove a library tag.
     * Mouse UI uses apply-only on single click (lists shift — easy to mis-click remove).
     * Removal: double-click, right-click menu, or allowRemove:true (hotkey keys).
     */
    async function toggleLibraryTag(tag, opts = {}) {
        const t = normalizeTag(tag);
        if (!t) return;
        // Always fold into active-space vocabulary first (enables list + autocomplete)
        ensureTagsKnown([t], privateSpaceActive ? { forcePrivate: true } : {});
        if (!activeKey) {
            if (els.status) {
                els.status.textContent =
                    `“${t}” saved to ${privateSpaceActive ? 'private' : 'public'} tag list · open a video to apply it to a file`;
            }
            try { renderTagLibrary(); } catch (_) {}
            try { renderTagSuggestions(els.tagInput?.value || ''); } catch (_) {}
            schedulePersistTagDb();
            return;
        }
        const idx = activeTags.findIndex((x) => x.toLowerCase() === t.toLowerCase());
        const allowRemove = !!opts.allowRemove;
        if (idx >= 0) {
            if (!allowRemove) {
                if (els.status) {
                    els.status.textContent =
                        `“${t}” already on this file · double-click or right-click → Remove to clear`;
                }
                // Re-assert chosen/on-file color on all panels (user may have clicked a stale chip)
                try { syncAllTagUiState(); } catch (_) {}
                return;
            }
            const [removed] = activeTags.splice(idx, 1);
            await persistActiveMeta({ removedTags: [removed || t] });
            if (els.status) els.status.textContent = `Removed “${t}” from this file`;
            return;
        }
        activeTags.push(t);
        await persistActiveMeta({ touchedTags: [t] });
        if (els.status) {
            els.status.textContent = privateSpaceActive
                ? `Applied “${t}” (private library)`
                : `Applied “${t}”`;
        }
    }

    /** Explicit remove (double-click / menu). */
    async function removeLibraryTagSafe(tag) {
        return toggleLibraryTag(tag, { allowRemove: true });
    }

    function hideCtxMenu() {
        if (ctxMenu) {
            ctxMenu.remove();
            ctxMenu = null;
        }
    }

    function showTagContextMenu(e, tag, menuOpts = {}) {
        e.preventDefault?.();
        e.stopPropagation?.();
        hideCtxMenu();
        const t = normalizeTag(tag);
        const bulkTags = Array.isArray(menuOpts.bulkTags)
            ? menuOpts.bulkTags.map(normalizeTag).filter(Boolean)
            : (isTagSelected(t) && selectedTags.size > 1 ? getSelectedTags() : null);
        const bank = liveBank;
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu meta-ctx-menu-wide';
        const slotBtns = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
            const cur = getHotkey(bank, s);
            const active = cur && cur.toLowerCase() === t.toLowerCase();
            const label = formatHotkeyLabel(bank, s);
            return `<button type="button" data-bank="${bank}" data-slot="${s}" class="${active ? 'on' : ''}">
                <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
            </button>`;
        }).join('');
        // Quick bank switch inside menu
        const bankTabs = BANK_LABELS.map((name, b) =>
            `<button type="button" data-pick-bank="${b}" class="meta-ctx-bank ${b === bank ? 'on' : ''}">${escapeHtml(name)}</button>`
        ).join('');
        const onFile = isTagOnVideo(t);
        const TC = globalThis.FAFOTagColors;
        const curEntry = TC?.getEntry?.(t);
        let selectedSlot = (curEntry && typeof curEntry === 'object' && Number.isFinite(curEntry.slot))
            ? Number(curEntry.slot)
            : -1;
        const slotList = (typeof TC?.getSlots === 'function' ? TC.getSlots() : []);
        const dirOpts = (TC?.GRADIENT_DIRS || []).map((d) =>
            `<option value="${escapeAttr(d.id)}">${escapeHtml(d.label)}</option>`
        ).join('');
        const patOpts = (TC?.GRADIENT_PATTERNS || []).map((p) =>
            `<option value="${escapeAttr(p.id)}">${escapeHtml(p.label)}</option>`
        ).join('');
        const tileOpts = (TC?.TILE_PATTERNS || []).map((p) =>
            `<option value="${escapeAttr(p.id)}">${escapeHtml(p.label)}</option>`
        ).join('');

        const renderSlotTiles = () => {
            const list = TC?.getSlots?.() || slotList;
            return list.map((s, i) => {
                const bg = TC?.slotPreviewBackground?.(s) || s.fillA;
                const bd = TC?.slotPreviewBorder?.(s) || s.borderA;
                const on = selectedSlot === i ? ' on' : '';
                return `<button type="button" class="meta-ctx-slot-tile${on}" data-slot-i="${i}" title="${escapeAttr(s.name)} — click to apply">
                    <span class="meta-ctx-slot-tile-swatch" style="background:${escapeAttr(bg)};border-color:${escapeAttr(typeof bd === 'string' && !bd.includes('gradient') ? bd : s.borderA)}"></span>
                    <span class="meta-ctx-slot-tile-name">${escapeHtml(s.name)}</span>
                    <span class="meta-ctx-slot-tile-num">${i + 1}</span>
                </button>`;
            }).join('');
        };

        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">${bulkTags && bulkTags.length > 1
                ? escapeHtml(`${bulkTags.length} tags selected`)
                : escapeHtml(t)}</div>
            ${bulkTags && bulkTags.length > 1
                ? `<div class="meta-ctx-hint">${escapeHtml(bulkTags.slice(0, 8).join(' · '))}${bulkTags.length > 8 ? '…' : ''}</div>
                   <div class="meta-ctx-section">Bulk actions</div>
                   <button type="button" data-bulk-apply="1" class="meta-ctx-clear">Apply all to this file</button>
                   <button type="button" data-bulk-remove="1" class="meta-ctx-clear">Remove all from this file</button>
                   <button type="button" data-bulk-hide="1" class="meta-ctx-clear">Hide all from list</button>
                   <button type="button" data-bulk-rename="1" class="meta-ctx-warn">Find / replace in names…</button>
                   <button type="button" data-bulk-purge="1" class="meta-ctx-danger">Purge all from ALL media…</button>`
                : ''}
            <div class="meta-ctx-section">Edit &amp; delete</div>
            <button type="button" data-rename-tag="1" class="meta-ctx-warn">✎ Edit / rename everywhere…</button>
            ${onFile ? '<button type="button" data-remove-file="1" class="meta-ctx-clear">Remove from this file only</button>' : ''}
            <button type="button" data-hide-tag="1" class="meta-ctx-clear">Hide from list (keep on files)</button>
            <div class="meta-ctx-section">Menus</div>
            <button type="button" data-menu-scope="hidden" class="meta-ctx-clear${tagMenuScopeOf(t) === 'hidden' ? ' on' : ''}">Hidden menu only${tagMenuScopeOf(t) === 'hidden' ? ' ✓' : ''}</button>
            <button type="button" data-menu-scope="public" class="meta-ctx-clear${tagMenuScopeOf(t) === 'public' ? ' on' : ''}">Non-hidden menu only${tagMenuScopeOf(t) === 'public' ? ' ✓' : ''}</button>
            <button type="button" data-menu-scope="both" class="meta-ctx-clear${tagMenuScopeOf(t) === 'both' ? ' on' : ''}">Both menus${tagMenuScopeOf(t) === 'both' ? ' ✓' : ''}</button>
            ${privateSpaceActive
                ? '<button type="button" data-tag-to-public="1" class="meta-ctx-clear">Move tag → Public library (remove from private vocab)</button>'
                : '<button type="button" data-tag-to-private="1" class="meta-ctx-warn">Move tag → Private library (◈ · separate counts)</button>'}
            <button type="button" data-delete-vocab="1" class="meta-ctx-clear">Remove from library list only</button>
            <button type="button" data-purge-tag="1" class="meta-ctx-danger">Delete from ALL media…</button>
            <button type="button" class="meta-ctx-section meta-ctx-fold-toggle" data-color-slots-toggle="1" aria-expanded="false" title="Show or hide color slots">
                <span class="meta-ctx-fold-chevron" aria-hidden="true">▸</span>
                <span class="meta-ctx-fold-label">Color slots</span>
                <span class="meta-ctx-fold-summary" data-color-slots-summary>${(slotList.length || 0)} slots${selectedSlot >= 0 && slotList[selectedSlot] ? ' · ' + escapeHtml(slotList[selectedSlot].name || '') : ''}</span>
            </button>
            <div class="meta-ctx-color-slots-body is-collapsed" data-color-slots-body="1" hidden>
                <div class="meta-ctx-hint">Named slots (Subject, Weapons…) — click a tile to color this tag. Drag the menu corner to widen (names unwrap) or grow taller so you can see everything without nested scroll.</div>
                <div class="meta-ctx-slot-tiles" data-preset-swatches="1">${renderSlotTiles()}</div>
                <div class="meta-ctx-slot-editor" data-slot-editor="1">
                    <div class="meta-ctx-editor-row">
                        <label>Name</label>
                        <input type="text" class="meta-ctx-slot-name" maxlength="40" placeholder="e.g. Subject" />
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label>Scope</label>
                        <select class="meta-ctx-slot-scope" title="Global = all themes · Per-theme = only current tag theme pack">
                            <option value="global">Global (all themes)</option>
                            <option value="per-theme">Per-theme only</option>
                        </select>
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Mode</label>
                        <select class="meta-ctx-fill-mode" title="Solid / soft gradient / tiling pattern">
                            <option value="solid">Solid</option>
                            <option value="gradient">Gradient blend</option>
                            <option value="pattern">Tile pattern</option>
                        </select>
                        <select class="meta-ctx-fill-count" title="How many colors">
                            <option value="1">1 color</option>
                            <option value="2" selected>2 colors</option>
                            <option value="3">3 colors</option>
                        </select>
                    </div>
                    <div class="meta-ctx-hint">Each color has its own opacity (0 = transparent)</div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>C1</label>
                        <input type="color" class="meta-ctx-fill-a" title="Color 1" />
                        <input type="range" class="meta-ctx-fill-alpha" min="0" max="100" value="95" title="Color 1 opacity" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>C2</label>
                        <input type="color" class="meta-ctx-fill-b" title="Color 2" />
                        <input type="range" class="meta-ctx-fill-alpha-b" min="0" max="100" value="85" title="Color 2 opacity" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>C3</label>
                        <input type="color" class="meta-ctx-fill-c" title="Color 3" />
                        <input type="range" class="meta-ctx-fill-alpha-c" min="0" max="100" value="70" title="Color 3 opacity" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Border</label>
                        <select class="meta-ctx-border-mode">
                            <option value="solid">Solid</option>
                            <option value="gradient">Gradient</option>
                            <option value="pattern">Pattern</option>
                            <option value="match-fill">Match fill</option>
                        </select>
                        <input type="color" class="meta-ctx-border-a" title="Border color 1" />
                        <input type="range" class="meta-ctx-border-alpha" min="0" max="100" value="100" title="Border 1 opacity" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Grad</label>
                        <select class="meta-ctx-grad-pattern">${patOpts}</select>
                        <select class="meta-ctx-grad-dir">${dirOpts}</select>
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label title="How soft colors melt together">Soft</label>
                        <input type="range" class="meta-ctx-blend" min="0" max="100" value="55" />
                        <span class="meta-ctx-blend-val">55%</span>
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label title="Position of color 2 in the blend">C2 pos</label>
                        <input type="range" class="meta-ctx-grad-stop" min="5" max="95" value="50" />
                        <span class="meta-ctx-grad-stop-val">50%</span>
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label title="Tile cell size">Scale</label>
                        <input type="range" class="meta-ctx-tile-scale" min="2" max="192" value="16" title="Tile scale (px)" />
                        <span class="meta-ctx-tile-scale-val">16px</span>
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label title="Zoom multiplier">Zoom</label>
                        <input type="range" class="meta-ctx-tile-zoom" min="25" max="400" value="100" title="Second tiling factor 0.25×–4×" />
                        <span class="meta-ctx-tile-zoom-val">1.00×</span>
                    </div>
                    <div class="meta-ctx-editor-row">
                        <label title="Rotate the tile">Rotate</label>
                        <input type="range" class="meta-ctx-tile-rotate" min="0" max="359" value="0" />
                        <span class="meta-ctx-tile-rotate-val">0°</span>
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Text</label>
                        <select class="meta-ctx-text-mode" title="This tile’s idle text color">
                            <option value="inherit">Global type</option>
                            <option value="auto">Auto contrast</option>
                            <option value="custom">Custom</option>
                            <option value="theme">Theme</option>
                            <option value="gradient">Gradient</option>
                        </select>
                        <input type="color" class="meta-ctx-text-color" value="#ffffff" title="Idle text" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>On-clip</label>
                        <select class="meta-ctx-text-on-mode">
                            <option value="inherit">Chosen style</option>
                            <option value="custom">Custom</option>
                            <option value="auto">Auto</option>
                        </select>
                        <input type="color" class="meta-ctx-text-on-color" value="#041018" title="On-clip text" />
                    </div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Bubble</label>
                        <select class="meta-ctx-text-bubble">
                            <option value="auto">Default pill</option>
                            <option value="off">Off</option>
                            <option value="solid">Solid</option>
                            <option value="gradient">Gradient</option>
                        </select>
                        <input type="color" class="meta-ctx-bubble-a" value="#000000" title="Bubble color" />
                    </div>
                    <div class="meta-ctx-hint">This tag’s text override (beats the slot)</div>
                    <div class="meta-ctx-editor-row meta-ctx-editor-split">
                        <label>Tag text</label>
                        <input type="color" class="meta-ctx-tag-text" value="#ffffff" title="Override text for this tag only" />
                        <button type="button" data-tag-text-apply="1" class="meta-ctx-clear">Apply to tag</button>
                        <button type="button" data-tag-text-clear="1" class="meta-ctx-clear">Clear</button>
                    </div>
                    <div class="meta-ctx-hint">Last colors</div>
                    <div class="meta-ctx-recent" data-recent-colors="1"></div>
                    <div class="meta-ctx-hint">Patterns (click) · uses C1–C3 + opacities · zoom &amp; rotate</div>
                    <div class="meta-ctx-pat-gallery" data-pat-gallery="1"></div>
                    <select class="meta-ctx-tile-pattern" style="display:none" aria-hidden="true">${tileOpts}</select>
                    <div class="meta-ctx-color-tools">
                        <button type="button" data-slot-save="1" class="meta-ctx-clear">Save slot</button>
                        <button type="button" data-slot-apply="1" class="meta-ctx-clear">Apply to tag</button>
                        <button type="button" data-color-clear="1" class="meta-ctx-clear">Clear tag color</button>
                        <button type="button" data-color-all-visible="1" class="meta-ctx-clear">Color all visible</button>
                        <button type="button" data-slot-add="1" class="meta-ctx-clear">+ Slot</button>
                        <button type="button" data-preset-reset="1" class="meta-ctx-clear">Reset slots</button>
                    </div>
                </div>
            </div>
            <div class="meta-ctx-section">Hotkey</div>
            <div class="meta-ctx-hint">Assign to slot (hold modifiers to change bank, or pick below)</div>
            <div class="meta-ctx-bank-row">${bankTabs}</div>
            <div class="meta-ctx-slot-list fafo-scrollable" data-for-bank="${bank}">${slotBtns}</div>
            <button type="button" data-clear="1" class="meta-ctx-clear">Clear this tag's hotkey</button>
        `;
        document.body.appendChild(ctxMenu);
        // Resizable wide menu: start compact; drag bottom-right corner to grow (unwrap text / no nested scroll)
        const menuW = Math.min(360, Math.max(280, window.innerWidth - 24));
        const x = Math.min(e.clientX, window.innerWidth - menuW - 8);
        const y = Math.min(e.clientY, window.innerHeight - 160);
        ctxMenu.style.left = Math.max(8, x) + 'px';
        ctxMenu.style.top = Math.max(8, y) + 'px';
        ctxMenu.style.width = menuW + 'px';
        ctxMenu.style.maxWidth = Math.min(920, window.innerWidth - 16) + 'px';
        ctxMenu.style.maxHeight = Math.min(window.innerHeight - 16, 900) + 'px';
        // Keep menu open while using native color pickers / ranges / resize handle
        ctxMenu.addEventListener('mousedown', (ev) => ev.stopPropagation());
        ctxMenu.addEventListener('pointerdown', (ev) => ev.stopPropagation());
        ctxMenu.addEventListener('click', (ev) => ev.stopPropagation());

        // Collapsible Color slots (default collapsed unless this tag already has a slot)
        const colorToggle = ctxMenu.querySelector('[data-color-slots-toggle]');
        const colorBody = ctxMenu.querySelector('[data-color-slots-body]');
        const clampCtxMenuOnScreen = () => {
            if (!ctxMenu) return;
            const r = ctxMenu.getBoundingClientRect();
            if (r.bottom > window.innerHeight - 8) {
                ctxMenu.style.top = Math.max(8, window.innerHeight - r.height - 8) + 'px';
            }
            if (r.right > window.innerWidth - 8) {
                ctxMenu.style.left = Math.max(8, window.innerWidth - r.width - 8) + 'px';
            }
        };
        /** Explicit size so CSS resize:both can grow both axes; fit content when possible. */
        const fitCtxMenuSize = ({ grow = false } = {}) => {
            if (!ctxMenu) return;
            const maxH = Math.min(window.innerHeight - 16, 900);
            const maxW = Math.min(window.innerWidth - 16, 920);
            // Temporarily unlock height to measure natural content
            const prevH = ctxMenu.style.height;
            ctxMenu.style.height = 'auto';
            const needH = Math.ceil(ctxMenu.scrollHeight);
            const needW = Math.ceil(ctxMenu.scrollWidth);
            const cur = ctxMenu.getBoundingClientRect();
            let nextH = Math.min(needH, maxH);
            let nextW = Math.min(Math.max(cur.width || menuW, needW), maxW);
            if (grow) {
                // Prefer showing more content without nested scroll when user expands a section
                nextH = Math.min(Math.max(cur.height, needH), maxH);
                nextW = Math.min(Math.max(cur.width, needW, menuW), maxW);
            } else if (prevH) {
                // Keep user-resized height if larger than content (and still under max)
                const userH = parseFloat(prevH);
                if (Number.isFinite(userH) && userH > nextH) nextH = Math.min(userH, maxH);
            }
            ctxMenu.style.height = nextH + 'px';
            ctxMenu.style.width = nextW + 'px';
            clampCtxMenuOnScreen();
        };
        const setColorSlotsOpen = (open) => {
            if (!colorBody || !colorToggle) return;
            colorBody.hidden = !open;
            colorBody.classList.toggle('is-collapsed', !open);
            colorToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            colorToggle.classList.toggle('is-open', !!open);
        };
        setColorSlotsOpen(selectedSlot >= 0);
        requestAnimationFrame(() => fitCtxMenuSize({ grow: selectedSlot >= 0 }));
        colorToggle?.addEventListener('click', (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const open = colorToggle.getAttribute('aria-expanded') !== 'true';
            setColorSlotsOpen(open);
            requestAnimationFrame(() => fitCtxMenuSize({ grow: open }));
        });

        const refillSlots = (b) => {
            const list = ctxMenu.querySelector('.meta-ctx-slot-list');
            if (!list) return;
            list.dataset.forBank = String(b);
            list.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
                const cur = getHotkey(b, s);
                const active = cur && cur.toLowerCase() === t.toLowerCase();
                const label = formatHotkeyLabel(b, s);
                return `<button type="button" data-bank="${b}" data-slot="${s}" class="${active ? 'on' : ''}">
                    <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
                </button>`;
            }).join('');
            wireSlotAssign(list);
        };

        const wireSlotAssign = (root) => {
            root.querySelectorAll('[data-slot]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    const b = parseInt(btn.dataset.bank, 10);
                    const s = parseInt(btn.dataset.slot, 10);
                    clearTagFromAllHotkeys(t);
                    setHotkey(b, s, t);
                    await saveStore();
                    scheduleSettingsExport();
                    hideCtxMenu();
                    renderTagLibrary();
                    renderHotkeyBar();
                    if (els.status) els.status.textContent = `Hotkey ${formatHotkeyLabel(b, s)} → ${t}`;
                });
            });
        };

        ctxMenu.querySelectorAll('[data-pick-bank]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const b = parseInt(btn.dataset.pickBank, 10);
                ctxMenu.querySelectorAll('[data-pick-bank]').forEach((x) => {
                    x.classList.toggle('on', parseInt(x.dataset.pickBank, 10) === b);
                });
                refillSlots(b);
            });
        });
        wireSlotAssign(ctxMenu.querySelector('.meta-ctx-slot-list'));

        ctxMenu.querySelector('[data-clear]')?.addEventListener('click', async () => {
            clearTagFromAllHotkeys(t);
            await saveStore();
            scheduleSettingsExport();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
        ctxMenu.querySelector('[data-hide-tag]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await excludeTag(t);
        });
        ctxMenu.querySelectorAll('[data-menu-scope]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const scope = btn.getAttribute('data-menu-scope');
                const targets = bulkTags && bulkTags.length ? bulkTags : [t];
                hideCtxMenu();
                await setTagMenuScope(targets, scope);
            });
        });
        ctxMenu.querySelector('[data-tag-to-private]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await moveTagToPrivate(t);
        });
        ctxMenu.querySelector('[data-tag-to-public]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await moveTagToPublic(t);
        });
        ctxMenu.querySelector('[data-rename-tag]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await renameTagEverywhere(t);
        });
        ctxMenu.querySelector('[data-remove-file]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await removeTagFromCurrentFile(t);
        });
        ctxMenu.querySelector('[data-delete-vocab]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await removeTagFromVocabulary(t);
        });
        ctxMenu.querySelector('[data-purge-tag]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await purgeTagEverywhere(t);
        });
        let editorLoading = false;
        let saveTimer = null;

        const applySlotToTag = async (i, { keepOpen = true } = {}) => {
            if (!TC) return;
            selectedSlot = i;
            const targets = bulkTags && bulkTags.length ? bulkTags : [t];
            if (targets.length > 1 && TC.setMany) {
                // setMany accepts slot index as number
                await TC.setMany(targets, i);
            } else {
                for (const name of targets) await TC.setSlotOnTag?.(name, i);
            }
            if (!keepOpen) hideCtxMenu();
            renderMetaPanel();
            globalThis.FAFOTagColors?.paintAll?.(document);
            const name = TC.getSlots?.()?.[i]?.name || `Slot ${i + 1}`;
            if (els.status) {
                els.status.textContent = targets.length > 1
                    ? `${targets.length} tags → ${name}`
                    : `“${t}” → ${name}`;
            }
        };

        ctxMenu.querySelector('[data-bulk-apply]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await bulkApplySelected();
        });
        ctxMenu.querySelector('[data-bulk-remove]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await bulkRemoveSelected();
        });
        ctxMenu.querySelector('[data-bulk-hide]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await bulkHideSelected();
        });
        ctxMenu.querySelector('[data-bulk-rename]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await bulkRenameSelected();
        });
        ctxMenu.querySelector('[data-bulk-purge]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await bulkPurgeSelected();
        });

        const loadEditorFromSlot = (i) => {
            const s = TC?.getSlots?.()?.[i];
            if (!s || !ctxMenu) return;
            editorLoading = true;
            selectedSlot = i;
            const q = (sel) => ctxMenu.querySelector(sel);
            if (q('.meta-ctx-slot-name')) q('.meta-ctx-slot-name').value = s.name || '';
            if (q('.meta-ctx-slot-scope')) q('.meta-ctx-slot-scope').value = s.scope === 'per-theme' ? 'per-theme' : 'global';
            if (q('.meta-ctx-fill-mode')) q('.meta-ctx-fill-mode').value = s.fillMode || 'solid';
            if (q('.meta-ctx-fill-count')) q('.meta-ctx-fill-count').value = String(s.fillColorCount || 2);
            if (q('.meta-ctx-fill-a')) q('.meta-ctx-fill-a').value = s.fillA || '#00e5ff';
            if (q('.meta-ctx-fill-b')) q('.meta-ctx-fill-b').value = s.fillB || '#00ffa8';
            if (q('.meta-ctx-fill-c')) q('.meta-ctx-fill-c').value = s.fillC || '#a78bfa';
            if (q('.meta-ctx-fill-alpha')) q('.meta-ctx-fill-alpha').value = Math.round((s.fillAlpha ?? 0.95) * 100);
            if (q('.meta-ctx-fill-alpha-b')) q('.meta-ctx-fill-alpha-b').value = Math.round((s.fillAlphaB ?? 0.85) * 100);
            if (q('.meta-ctx-fill-alpha-c')) q('.meta-ctx-fill-alpha-c').value = Math.round((s.fillAlphaC ?? 0.7) * 100);
            if (q('.meta-ctx-border-mode')) q('.meta-ctx-border-mode').value = s.borderMode || 'solid';
            if (q('.meta-ctx-border-a')) q('.meta-ctx-border-a').value = s.borderA || s.fillA || '#00e5ff';
            if (q('.meta-ctx-border-alpha')) q('.meta-ctx-border-alpha').value = Math.round((s.borderAlpha ?? 1) * 100);
            if (q('.meta-ctx-grad-pattern')) q('.meta-ctx-grad-pattern').value = s.gradientPattern || 'linear';
            if (q('.meta-ctx-grad-dir')) q('.meta-ctx-grad-dir').value = s.gradientDir || 'to bottom right';
            if (q('.meta-ctx-blend')) q('.meta-ctx-blend').value = s.blendSoftness ?? 55;
            if (q('.meta-ctx-blend-val')) q('.meta-ctx-blend-val').textContent = `${s.blendSoftness ?? 55}%`;
            if (q('.meta-ctx-grad-stop')) q('.meta-ctx-grad-stop').value = s.gradientStop ?? 50;
            if (q('.meta-ctx-grad-stop-val')) q('.meta-ctx-grad-stop-val').textContent = `${s.gradientStop ?? 50}%`;
            if (q('.meta-ctx-tile-pattern')) q('.meta-ctx-tile-pattern').value = s.tilePattern || 'stripes-h';
            if (q('.meta-ctx-tile-scale')) q('.meta-ctx-tile-scale').value = s.tileScale ?? 16;
            if (q('.meta-ctx-tile-scale-val')) q('.meta-ctx-tile-scale-val').textContent = `${s.tileScale ?? 16}px`;
            if (q('.meta-ctx-tile-zoom')) q('.meta-ctx-tile-zoom').value = String(Math.round((s.tileZoom ?? 1) * 100));
            if (q('.meta-ctx-tile-zoom-val')) q('.meta-ctx-tile-zoom-val').textContent = `${Number(s.tileZoom ?? 1).toFixed(2)}×`;
            if (q('.meta-ctx-tile-rotate')) q('.meta-ctx-tile-rotate').value = String(s.tileRotate ?? 0);
            if (q('.meta-ctx-tile-rotate-val')) q('.meta-ctx-tile-rotate-val').textContent = `${s.tileRotate ?? 0}°`;
            if (q('.meta-ctx-text-mode')) q('.meta-ctx-text-mode').value = s.textMode || 'inherit';
            if (q('.meta-ctx-text-color')) q('.meta-ctx-text-color').value = s.textColor || '#ffffff';
            if (q('.meta-ctx-text-on-mode')) q('.meta-ctx-text-on-mode').value = s.textOnMode || 'inherit';
            if (q('.meta-ctx-text-on-color')) q('.meta-ctx-text-on-color').value = s.textColorOn || '#041018';
            if (q('.meta-ctx-text-bubble')) q('.meta-ctx-text-bubble').value = s.textBubble || 'auto';
            if (q('.meta-ctx-bubble-a')) q('.meta-ctx-bubble-a').value = s.textBubbleA || '#000000';
            const tagEntry = TC?.getEntry?.(t);
            if (q('.meta-ctx-tag-text') && tagEntry && typeof tagEntry === 'object' && tagEntry.textColor) {
                q('.meta-ctx-tag-text').value = tagEntry.textColor;
            }
            paintCtxRecent();
            ctxMenu.querySelectorAll('[data-slot-i]').forEach((b) => {
                b.classList.toggle('on', parseInt(b.dataset.slotI, 10) === i);
            });
            paintCtxPatternGallery();
            // allow input events after paint
            requestAnimationFrame(() => { editorLoading = false; });
        };

        const paintCtxRecent = () => {
            const host = ctxMenu.querySelector('[data-recent-colors]');
            if (!host || !TC?.renderRecentBar) return;
            TC.renderRecentBar(host, (item) => {
                const q = (sel) => ctxMenu.querySelector(sel);
                if (item.g) {
                    if (q('.meta-ctx-fill-a')) q('.meta-ctx-fill-a').value = item.a;
                    if (q('.meta-ctx-fill-b')) q('.meta-ctx-fill-b').value = item.b;
                    if (q('.meta-ctx-fill-c')) q('.meta-ctx-fill-c').value = item.c;
                    if (q('.meta-ctx-fill-mode')) q('.meta-ctx-fill-mode').value = 'gradient';
                    schedulePersist();
                    paintCtxPatternGallery();
                    return;
                }
                if (item.hex) {
                    const a = q('.meta-ctx-fill-a');
                    if (a) a.value = item.hex;
                    schedulePersist();
                }
            });
        };

        const paintCtxPatternGallery = () => {
            const host = ctxMenu.querySelector('[data-pat-gallery]');
            if (!host || !TC) return;
            const list = TC.TILE_PATTERNS || [];
            const patch = readEditorPatch();
            const base = { ...patch, fillMode: 'pattern' };
            const sel = patch.tilePattern || 'stripes-h';
            host.innerHTML = list.map((p) =>
                `<button type="button" class="meta-ctx-pat${p.id === sel ? ' on' : ''}" data-pat="${escapeAttr(p.id)}" title="${escapeAttr(p.label)}">
                    <span class="meta-ctx-pat-sw" data-pat-sw="${escapeAttr(p.id)}"></span>
                    <span class="meta-ctx-pat-lab">${escapeHtml(p.label)}</span>
                </button>`
            ).join('');
            list.forEach((p) => {
                const sw = host.querySelector(`[data-pat-sw="${p.id}"]`);
                if (sw) TC.paintFromSlot?.(sw, { ...base, tilePattern: p.id });
            });
            host.querySelectorAll('[data-pat]').forEach((btn) => {
                btn.addEventListener('click', (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    const id = btn.getAttribute('data-pat');
                    const selEl = ctxMenu.querySelector('.meta-ctx-tile-pattern');
                    if (selEl) selEl.value = id;
                    const modeEl = ctxMenu.querySelector('.meta-ctx-fill-mode');
                    if (modeEl) modeEl.value = 'pattern';
                    schedulePersist();
                    paintCtxPatternGallery();
                });
            });
        };

        const readEditorPatch = () => {
            const q = (sel) => ctxMenu.querySelector(sel);
            const num = (sel, d) => {
                const v = parseInt(q(sel)?.value, 10);
                return Number.isFinite(v) ? v / 100 : d;
            };
            const stopRaw = parseInt(q('.meta-ctx-grad-stop')?.value, 10);
            const blendRaw = parseInt(q('.meta-ctx-blend')?.value, 10);
            const tileScale = parseInt(q('.meta-ctx-tile-scale')?.value, 10);
            const tileZoomPct = parseInt(q('.meta-ctx-tile-zoom')?.value, 10);
            const tileRotate = parseInt(q('.meta-ctx-tile-rotate')?.value, 10);
            const fillCount = parseInt(q('.meta-ctx-fill-count')?.value, 10);
            const mode = q('.meta-ctx-fill-mode')?.value || 'solid';
            return {
                name: (q('.meta-ctx-slot-name')?.value || '').trim() || `Slot ${(selectedSlot >= 0 ? selectedSlot : 0) + 1}`,
                scope: q('.meta-ctx-slot-scope')?.value === 'per-theme' ? 'per-theme' : 'global',
                fillMode: ['solid', 'gradient', 'pattern'].includes(mode) ? mode : 'solid',
                fillColorCount: Number.isFinite(fillCount) ? fillCount : 2,
                fillA: q('.meta-ctx-fill-a')?.value || '#00e5ff',
                fillB: q('.meta-ctx-fill-b')?.value || '#00ffa8',
                fillC: q('.meta-ctx-fill-c')?.value || '#a78bfa',
                fillAlpha: num('.meta-ctx-fill-alpha', 0.95),
                fillAlphaB: num('.meta-ctx-fill-alpha-b', 0.85),
                fillAlphaC: num('.meta-ctx-fill-alpha-c', 0.7),
                borderMode: q('.meta-ctx-border-mode')?.value || 'solid',
                borderColorCount: Number.isFinite(fillCount) ? fillCount : 1,
                borderA: q('.meta-ctx-border-a')?.value || '#00e5ff',
                borderAlpha: num('.meta-ctx-border-alpha', 1),
                borderAlphaB: 0.85,
                borderAlphaC: 0.7,
                gradientPattern: q('.meta-ctx-grad-pattern')?.value || 'linear',
                gradientDir: q('.meta-ctx-grad-dir')?.value || 'to bottom right',
                blendSoftness: Number.isFinite(blendRaw) ? blendRaw : 55,
                gradientStop: Number.isFinite(stopRaw) ? stopRaw : 50,
                gradientStopC: 80,
                tilePattern: q('.meta-ctx-tile-pattern')?.value || 'stripes-h',
                tileScale: Number.isFinite(tileScale) ? tileScale : 12,
                tileZoom: Number.isFinite(tileZoomPct) ? Math.max(0.25, Math.min(4, tileZoomPct / 100)) : 1,
                tileRotate: Number.isFinite(tileRotate) ? tileRotate : 0,
                textMode: q('.meta-ctx-text-mode')?.value || 'inherit',
                textColor: q('.meta-ctx-text-color')?.value || '#ffffff',
                textOnMode: q('.meta-ctx-text-on-mode')?.value || 'inherit',
                textColorOn: q('.meta-ctx-text-on-color')?.value || '#041018',
                textBubble: q('.meta-ctx-text-bubble')?.value || 'auto',
                textBubbleA: q('.meta-ctx-bubble-a')?.value || '#000000',
            };
        };

        const repaintTiles = () => {
            const wrap = ctxMenu.querySelector('[data-preset-swatches]');
            if (!wrap || !TC) return;
            wrap.innerHTML = (TC.getSlots?.() || []).map((s, i) => {
                const on = selectedSlot === i ? ' on' : '';
                return `<button type="button" class="meta-ctx-slot-tile${on}" data-slot-i="${i}" title="${escapeAttr(s.name)}">
                    <span class="meta-ctx-slot-tile-swatch" data-slot-sw="${i}"></span>
                    <span class="meta-ctx-slot-tile-name">${escapeHtml(s.name)}</span>
                    <span class="meta-ctx-slot-tile-num">${i + 1}${s.fillMode === 'pattern' ? ' · tile' : ''}</span>
                </button>`;
            }).join('');
            (TC.getSlots?.() || []).forEach((s, i) => {
                const sw = wrap.querySelector(`[data-slot-sw="${i}"]`);
                if (sw) TC.paintFromSlot?.(sw, s);
            });
            wireTiles();
        };

        const persistEditor = async ({ applyToTag = true, toast = true } = {}) => {
            if (!TC || selectedSlot < 0) return;
            const patch = readEditorPatch();
            await TC.updateSlot?.(selectedSlot, patch);
            repaintTiles();
            if (applyToTag) {
                // Keep this tag linked to the slot so gradient sticks on the chip
                await TC.setSlotOnTag?.(t, selectedSlot);
                renderMetaPanel();
                TC.paintAll?.(document);
            }
            if (toast && els.status) {
                els.status.textContent = `Saved “${patch.name}” · ${patch.fillMode}${patch.fillMode === 'gradient' ? ' · ' + patch.gradientPattern : ''}`;
            }
        };

        const schedulePersist = () => {
            if (editorLoading) return;
            clearTimeout(saveTimer);
            saveTimer = setTimeout(() => {
                persistEditor({ applyToTag: true, toast: true });
            }, 280);
        };

        const wireTiles = () => {
            ctxMenu.querySelectorAll('[data-slot-i]').forEach((btn) => {
                btn.addEventListener('click', async (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    // Flush current editor before switching slots
                    if (selectedSlot >= 0 && !editorLoading) {
                        await persistEditor({ applyToTag: false, toast: false });
                    }
                    const i = parseInt(btn.dataset.slotI, 10);
                    loadEditorFromSlot(i);
                    await applySlotToTag(i, { keepOpen: true });
                    repaintTiles();
                });
            });
        };
        wireTiles();

        // Preselect slot if tag already uses one
        if (selectedSlot >= 0) loadEditorFromSlot(selectedSlot);
        else if (slotList.length) loadEditorFromSlot(0);

        // Auto-save every edit (color, gradient, opacity, pattern…)
        const editorRoot = ctxMenu.querySelector('[data-slot-editor]');
        editorRoot?.querySelectorAll('input, select').forEach((el) => {
            el.addEventListener('input', () => {
                if (el.classList.contains('meta-ctx-grad-stop')) {
                    const lab = ctxMenu.querySelector('.meta-ctx-grad-stop-val');
                    if (lab) lab.textContent = `${el.value}%`;
                }
                if (el.classList.contains('meta-ctx-blend')) {
                    const lab = ctxMenu.querySelector('.meta-ctx-blend-val');
                    if (lab) lab.textContent = `${el.value}%`;
                }
                if (el.classList.contains('meta-ctx-tile-scale')) {
                    const lab = ctxMenu.querySelector('.meta-ctx-tile-scale-val');
                    if (lab) lab.textContent = `${el.value}px`;
                    const modeEl = ctxMenu.querySelector('.meta-ctx-fill-mode');
                    if (modeEl && modeEl.value !== 'pattern') modeEl.value = 'pattern';
                    paintCtxPatternGallery();
                }
                if (el.classList.contains('meta-ctx-tile-zoom')) {
                    const lab = ctxMenu.querySelector('.meta-ctx-tile-zoom-val');
                    if (lab) lab.textContent = `${(Number(el.value) / 100).toFixed(2)}×`;
                    const modeEl = ctxMenu.querySelector('.meta-ctx-fill-mode');
                    if (modeEl && modeEl.value !== 'pattern') modeEl.value = 'pattern';
                    paintCtxPatternGallery();
                }
                if (el.classList.contains('meta-ctx-tile-rotate')) {
                    const lab = ctxMenu.querySelector('.meta-ctx-tile-rotate-val');
                    if (lab) lab.textContent = `${el.value}°`;
                    paintCtxPatternGallery();
                    // Live-update selected slot thumbnail in the tile grid
                    try {
                        const patch = { ...readEditorPatch(), fillMode: 'pattern' };
                        const i = selectedSlot >= 0 ? selectedSlot : 0;
                        const sw = ctxMenu.querySelector(`[data-slot-sw="${i}"]`)
                            || ctxMenu.querySelector(`[data-slot-i="${i}"] .meta-ctx-slot-tile-swatch`);
                        if (sw) TC.paintFromSlot?.(sw, patch);
                        // Also re-paint all pattern thumbs already done by gallery
                    } catch (_) {}
                }
                if (el.classList.contains('meta-ctx-fill-mode') || el.classList.contains('meta-ctx-fill-a')
                    || el.classList.contains('meta-ctx-fill-b') || el.classList.contains('meta-ctx-fill-c')
                    || el.classList.contains('meta-ctx-fill-alpha') || el.classList.contains('meta-ctx-fill-alpha-b')
                    || el.classList.contains('meta-ctx-fill-alpha-c') || el.classList.contains('meta-ctx-fill-count')) {
                    paintCtxPatternGallery();
                }
                schedulePersist();
            });
            el.addEventListener('change', () => {
                paintCtxPatternGallery();
                schedulePersist();
            });
        });
        paintCtxPatternGallery();
        paintCtxRecent();

        ctxMenu.querySelector('[data-tag-text-apply]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const hex = ctxMenu.querySelector('.meta-ctx-tag-text')?.value;
            if (!hex) return;
            await TC.setTagTextOverride?.(t, { textMode: 'custom', textColor: hex, textOnMode: 'custom', textColorOn: hex });
            TC.rememberColor?.(hex);
            TC.paintAll?.(document);
            if (els.status) els.status.textContent = `Text override on “${t}”`;
        });
        ctxMenu.querySelector('[data-tag-text-clear]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            const cur = TC.getEntry?.(t);
            if (cur && typeof cur === 'object' && Number.isFinite(cur.slot)) {
                await TC.set?.(t, { slot: cur.slot });
            } else if (cur && typeof cur === 'object') {
                const next = { ...cur };
                delete next.textMode;
                delete next.textColor;
                delete next.textOnMode;
                delete next.textColorOn;
                await TC.set?.(t, next);
            }
            TC.paintAll?.(document);
            if (els.status) els.status.textContent = `Text override cleared on “${t}”`;
        });

        ctxMenu.querySelector('[data-slot-save]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (selectedSlot < 0) selectedSlot = 0;
            await persistEditor({ applyToTag: true, toast: true });
        });
        ctxMenu.querySelector('[data-slot-apply]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (selectedSlot < 0) selectedSlot = 0;
            await persistEditor({ applyToTag: true, toast: true });
        });
        ctxMenu.querySelector('[data-color-clear]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            await TC?.clear?.(t);
            hideCtxMenu();
            renderMetaPanel();
            TC?.paintAll?.(document);
            if (els.status) els.status.textContent = `Color cleared for “${t}”`;
        });
        ctxMenu.querySelector('[data-slot-add]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (selectedSlot >= 0) await persistEditor({ applyToTag: false, toast: false });
            await TC?.addSlot?.({ name: `Slot ${(TC.getSlots?.() || []).length + 1}` });
            const list = TC.getSlots?.() || [];
            selectedSlot = list.length - 1;
            repaintTiles();
            loadEditorFromSlot(selectedSlot);
            if (els.status) els.status.textContent = `Added slot ${selectedSlot + 1}`;
        });
        ctxMenu.querySelector('[data-color-all-visible]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (selectedSlot < 0) {
                if (els.status) els.status.textContent = 'Select a color slot first';
                return;
            }
            await persistEditor({ applyToTag: false, toast: false });
            const visible = [];
            document.querySelectorAll('#meta-tag-library [data-tag]').forEach((el) => {
                const name = el.getAttribute('data-tag') || el.dataset.tag;
                if (name) visible.push(name);
            });
            if (!visible.length) {
                if (els.status) els.status.textContent = 'No visible tags to color';
                return;
            }
            const slotName = TC.getSlots?.()?.[selectedSlot]?.name || `slot ${selectedSlot + 1}`;
            if (!confirm(`Apply “${slotName}” to all ${visible.length} visible tag(s)?`)) return;
            const n = await TC.setMany?.(visible, { slot: selectedSlot });
            renderMetaPanel();
            TC.paintAll?.(document);
            if (els.status) els.status.textContent = `Colored ${n || visible.length} tags → ${slotName}`;
        });
        ctxMenu.querySelector('[data-preset-reset]')?.addEventListener('click', async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (!confirm('Reset all color slots to defaults (names + colors)?')) return;
            await TC?.resetSlots?.() || TC?.resetPresets?.();
            selectedSlot = 0;
            repaintTiles();
            loadEditorFromSlot(0);
            if (els.status) els.status.textContent = 'Color slots reset to defaults';
        });
    }

    /** Remove tag from the active file only (not vocabulary). */
    async function removeTagFromCurrentFile(tag) {
        const t = normalizeTag(tag);
        if (!t || !activeKey) {
            if (els.status) els.status.textContent = 'No active file';
            return;
        }
        const idx = activeTags.findIndex((x) => x.toLowerCase() === t.toLowerCase());
        if (idx < 0) {
            if (els.status) els.status.textContent = `“${t}” is not on this file`;
            return;
        }
        const [removed] = activeTags.splice(idx, 1);
        await persistActiveMeta({ removedTags: [removed || t] });
        if (els.status) els.status.textContent = `Removed “${t}” from this file`;
    }

    /**
     * Remove from tag library list only (does not strip from files that still have it).
     * Optionally hide; if force and unused, drop from vocabulary.
     */
    async function removeTagFromVocabulary(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) {
            if (els.status) els.status.textContent = 'Cannot edit pair/system tags';
            return;
        }
        const low = t.toLowerCase();
        const onFiles = Object.values(mediaMeta).filter((m) =>
            Array.isArray(m?.tags) && m.tags.some((x) => normalizeTag(x).toLowerCase() === low)
        ).length;
        if (onFiles > 0) {
            const hide = window.confirm(
                `“${t}” is still on ${onFiles} file(s).\n\n` +
                `OK = Hide from the list (files keep the tag)\n` +
                `Cancel = do nothing\n\n` +
                `To wipe it from every file, use “Delete from ALL media”.`
            );
            if (!hide) return;
            await excludeTag(t);
            return;
        }
        const ok = window.confirm(`Remove “${t}” from the tag library list?\n\nIt is not on any files.`);
        if (!ok) return;
        tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== low);
        delete sessionTagCount[low];
        delete libraryTagCount[low];
        delete tagLastUsed[low];
        clearTagFromAllHotkeys(t);
        clearTagFromExtraBanks(t);
        try { await globalThis.FAFOTagColors?.remove?.(t); } catch (_) {}
        await saveStore();
        scheduleSettingsExport();
        renderMetaPanel();
        if (els.status) els.status.textContent = `Removed “${t}” from library list`;
    }

    function rewriteTagNameInList(list, fromLow, toName) {
        if (!Array.isArray(list)) return list;
        let hit = false;
        const next = list.map((x) => {
            if (normalizeTag(x).toLowerCase() === fromLow) {
                hit = true;
                return toName;
            }
            return x;
        });
        // Dedup case-insensitively after rename
        if (!hit) return list;
        const seen = new Set();
        return next.filter((x) => {
            const low = normalizeTag(x).toLowerCase();
            if (!low || seen.has(low)) return false;
            seen.add(low);
            return true;
        });
    }

    function clearTagFromExtraBanks(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return;
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                if (normalizeTag(extraTagBanks[b]?.[s] || '').toLowerCase() === low) {
                    extraTagBanks[b][s] = '';
                }
                if (normalizeTag(sessionAutoExtra[b]?.[s] || '').toLowerCase() === low) {
                    sessionAutoExtra[b][s] = '';
                }
            }
        }
        if (!sessionAutoExtraPaused) refillSessionAutoExtra();
    }

    /**
     * Rename a tag on every file, hotkeys, E-set, library, and counts.
     * @param {string} fromTag
     * @param {{ to?:string, skipPrompt?:boolean, skipUndo?:boolean, quiet?:boolean }} [opts]
     */
    async function renameTagEverywhere(fromTag, opts = {}) {
        const from = normalizeTag(fromTag);
        if (!from) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(from)) {
            if (els.status) els.status.textContent = 'Cannot rename pair/system tags';
            return;
        }
        let to;
        if (opts.skipPrompt && opts.to) {
            to = normalizeTag(opts.to);
        } else {
            const toRaw = window.prompt(`Rename tag everywhere:\n\n“${from}” →`, from);
            if (toRaw == null) return;
            to = normalizeTag(toRaw);
        }
        if (!to || to.toLowerCase() === from.toLowerCase()) {
            if (!opts.quiet && els.status) els.status.textContent = 'Rename cancelled';
            return;
        }
        const fromLow = from.toLowerCase();
        const toLow = to.toLowerCase();
        if (!opts.skipUndo) {
            const items = snapshotMediaHoldingTags([from]);
            if (items.length && globalThis.FAFOUndo?.pushBatch) {
                FAFOUndo.pushBatch({ label: `Rename “${from}”→“${to}”`, items });
            } else if (activeKey && globalThis.FAFOUndo?.push) {
                const prev = mediaMeta[activeKey] || {};
                FAFOUndo.push({
                    key: activeKey,
                    label: `Rename “${from}”`,
                    rating: prev.rating ?? 0,
                    tags: Array.isArray(prev.tags) ? prev.tags.slice() : [],
                    pairId: prev.pairId || '',
                });
            }
        }
        let files = 0;
        Object.keys(mediaMeta).forEach((k) => {
            const m = mediaMeta[k];
            if (!m || !Array.isArray(m.tags)) return;
            const before = m.tags.slice();
            m.tags = rewriteTagNameInList(m.tags, fromLow, to);
            if (JSON.stringify(before) !== JSON.stringify(m.tags)) {
                files++;
                m.updated = Date.now();
            }
        });
        tagLibrary = rewriteTagNameInList(tagLibrary, fromLow, to);
        if (!tagLibrary.some((x) => x.toLowerCase() === toLow)) tagLibrary.push(to);
        // Merge apply counts
        const fromCount = sessionTagCount[fromLow] || 0;
        if (fromCount) {
            sessionTagCount[toLow] = (sessionTagCount[toLow] || 0) + fromCount;
            delete sessionTagCount[fromLow];
        }
        if (libraryTagCount[fromLow]) {
            libraryTagCount[toLow] = (libraryTagCount[toLow] || 0) + (libraryTagCount[fromLow] || 0);
            delete libraryTagCount[fromLow];
        }
        if (tagLastUsed[fromLow]) {
            tagLastUsed[toLow] = Math.max(tagLastUsed[toLow] || 0, tagLastUsed[fromLow]);
            delete tagLastUsed[fromLow];
        }
        // Hotkeys + auto + E-set
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (normalizeTag(tagHotkeys[b]?.[s] || '').toLowerCase() === fromLow) tagHotkeys[b][s] = to;
                if (normalizeTag(sessionAutoHotkeys[b]?.[s] || '').toLowerCase() === fromLow) sessionAutoHotkeys[b][s] = to;
            }
        }
        for (let b = 0; b < EXTRA_BANKS; b++) {
            for (let s = 0; s < EXTRA_SLOTS; s++) {
                if (normalizeTag(extraTagBanks[b]?.[s] || '').toLowerCase() === fromLow) extraTagBanks[b][s] = to;
                if (normalizeTag(sessionAutoExtra[b]?.[s] || '').toLowerCase() === fromLow) sessionAutoExtra[b][s] = to;
            }
        }
        sessionFirstUsedOrder = sessionFirstUsedOrder.map((x) =>
            x.toLowerCase() === fromLow ? to : x
        );
        excludedTags = excludedTags.map((x) => (x.toLowerCase() === fromLow ? to : x));
        if (tagMenuScope[fromLow]) {
            if (!tagMenuScope[toLow]) tagMenuScope[toLow] = tagMenuScope[fromLow];
            delete tagMenuScope[fromLow];
        }
        // Active clip
        activeTags = rewriteTagNameInList(activeTags, fromLow, to);
        // Selection map
        if (selectedTags.has(fromLow)) {
            selectedTags.delete(fromLow);
            selectedTags.set(toLow, to);
        }
        try { await globalThis.FAFOTagColors?.rename?.(from, to); } catch (_) {}
        recomputeSessionHasPicks();
        rebuildLibraryTagCounts();
        sortTagLibrary();
        if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
        await saveStore();
        scheduleSettingsExport();
        renderMetaPanel();
        if (!opts.quiet && els.status) {
            els.status.textContent = `Renamed “${from}” → “${to}” on ${files} file(s) · ↩ Back undoes`;
        }
        // Best-effort disk rewrite for active file only (full library needs resync)
        syncFileMetadataToDisk().catch(() => {});
        updateUndoBackButton();
    }

    /**
     * Remove a tag from every media entry, hotkeys, library, and counts.
     * @param {string} tag
     * @param {{ skipConfirm?:boolean, skipUndo?:boolean, quiet?:boolean }} [opts]
     */
    async function purgeTagEverywhere(tag, opts = {}) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) {
            if (els.status) els.status.textContent = 'Cannot purge pair/system tags';
            return;
        }
        const low = t.toLowerCase();
        const onFiles = Object.values(mediaMeta).filter((m) =>
            Array.isArray(m?.tags) && m.tags.some((x) => normalizeTag(x).toLowerCase() === low)
        ).length;
        if (!opts.skipConfirm) {
            const ok = window.confirm(
                `Remove “${t}” from ALL media?\n\n` +
                `Currently on ${onFiles} file(s).\n` +
                `Also clears hotkeys / E-set / library entry.\n\n` +
                `↩ Back restores file tags for the last ${globalThis.FAFOUndo?.max || 50} ops.`
            );
            if (!ok) return;
        }
        if (!opts.skipUndo) {
            const items = snapshotMediaHoldingTags([t]);
            if (items.length && globalThis.FAFOUndo?.pushBatch) {
                FAFOUndo.pushBatch({ label: `Purge “${t}”`, items });
            }
        }
        let files = 0;
        Object.keys(mediaMeta).forEach((k) => {
            const m = mediaMeta[k];
            if (!m || !Array.isArray(m.tags)) return;
            const next = m.tags.filter((x) => normalizeTag(x).toLowerCase() !== low);
            if (next.length !== m.tags.length) {
                m.tags = next;
                m.updated = Date.now();
                files++;
            }
        });
        tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== low);
        delete sessionTagCount[low];
        delete libraryTagCount[low];
        delete tagLastUsed[low];
        clearTagFromAllHotkeys(t);
        clearTagFromExtraBanks(t);
        try { await globalThis.FAFOTagColors?.remove?.(t); } catch (_) {}
        sessionFirstUsedOrder = sessionFirstUsedOrder.filter((x) => x.toLowerCase() !== low);
        excludedTags = excludedTags.filter((x) => x.toLowerCase() !== low);
        delete tagMenuScope[low];
        activeTags = activeTags.filter((x) => x.toLowerCase() !== low);
        selectedTags.delete(low);
        recomputeSessionHasPicks();
        rebuildLibraryTagCounts();
        sortTagLibrary();
        if (!sessionAutoHotkeysPaused) refillSessionAutoHotkeys();
        await saveStore();
        scheduleSettingsExport();
        renderMetaPanel();
        if (!opts.quiet && els.status) {
            els.status.textContent = `Purged “${t}” from ${files} file(s) + hotkeys · ↩ Back undoes`;
        }
        syncFileMetadataToDisk().catch(() => {});
        updateUndoBackButton();
    }

    /** Right-click an empty or filled hotkey slot to pick / reassign a tag. */
    function showHotkeySlotAssignMenu(e, bank, slot, menu) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        const stored = getHotkey(bank, slot);
        const current = presetTagForMenu(stored, which);
        const label = formatHotkeyLabel(bank, slot);
        const candidates = tagLibrary
            .filter((t) => isTagListedIn(t, which))
            .slice(0, 24);
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu';
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">Hotkey ${escapeHtml(label)}</div>
            <div class="meta-ctx-hint">${BANK_LABELS[bank]} · ${current ? 'Currently: ' + escapeHtml(current) : (stored ? 'Slot is in the other menu' : 'Empty — pick a tag')}</div>
            ${candidates.length
                ? candidates.map((t) => {
                    const on = current && current.toLowerCase() === t.toLowerCase();
                    return `<button type="button" data-assign="${escapeAttr(t)}" class="${on ? 'on' : ''}">${escapeHtml(t)}</button>`;
                }).join('')
                : '<div class="meta-ctx-hint">No tags yet — add some first</div>'}
            ${current ? '<button type="button" data-clear-slot="1" class="meta-ctx-clear">Clear this slot</button>' : ''}
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 220);
        const y = Math.min(e.clientY, window.innerHeight - 320);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        ctxMenu.querySelectorAll('[data-assign]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const t = normalizeTag(btn.dataset.assign);
                clearTagFromAllHotkeys(t);
                setHotkey(bank, slot, t);
                await saveStore();
                hideCtxMenu();
                renderTagLibrary();
                renderHotkeyBar();
                if (els.status) els.status.textContent = `Hotkey ${label} → ${t}`;
            });
        });
        ctxMenu.querySelector('[data-clear-slot]')?.addEventListener('click', async () => {
            setHotkey(bank, slot, '');
            await saveStore();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
    }

    function updateBankIndicator() {
        const el = $('meta-hotkey-bank');
        if (!el) return;
        el.innerHTML = BANK_LABELS.map((name, b) =>
            `<span class="meta-bank-chip ${b === liveBank ? 'active' : ''}" data-bank="${b}">${escapeHtml(name)}</span>`
        ).join('');
        el.querySelectorAll('.meta-bank-chip').forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                // Pin bank (sticky until Tab / another chip / modifiers override temporarily)
                pinnedBank = parseInt(chip.dataset.bank, 10);
                liveBank = pinnedBank;
                renderHotkeyBar();
                updateBankIndicator();
            });
        });
    }

    /** Small color-coded bank icon (does not change tag status colors). */
    function bankModIconHtml(bank) {
        const icons = [
            { cls: 'mod-base', sym: '●', title: 'Base bank' },
            { cls: 'mod-shift', sym: '⇧', title: 'Shift bank' },
            { cls: 'mod-ctrl', sym: '⌃', title: 'Ctrl bank' },
            { cls: 'mod-alt', sym: '⌥', title: 'Alt bank' },
        ];
        const info = icons[bank] || icons[0];
        return `<span class="meta-mod-icon ${info.cls}" title="${escapeAttr(info.title)}" aria-hidden="true">${info.sym}</span>`;
    }

    function hotkeyStatusClasses(tag, auto, onVideo) {
        if (!tag) return 'empty';
        const sc = sessionCountFor(tag);
        const lc = libraryCountFor(tag);
        const parts = [];
        if (onVideo) parts.push('on-video');
        else if (auto) parts.push('auto-fill');
        else parts.push('set'); // user-programmed, not on this media
        if (auto) parts.push('auto-fill');
        if (!onVideo && sc > 0) parts.push('has-session');
        if (!onVideo && lc > 0 && sc === 0) parts.push('library-only');
        if (onVideo && auto) parts.push('on-video-auto');
        if (onVideo && !auto) parts.push('on-video-user');
        return parts.join(' ');
    }

    function paintHotkeyBarInto(bar, opts = {}) {
        if (!bar) return;
        const applyOnly = !!opts.applyOnly; // Player HUD: no right-click assign UI
        const bank = liveBank;
        bar.dataset.bank = String(bank);
        bar.className = `${opts.className || 'meta-hotkey-bar'} bank-${bank}`;
        const menu = opts.menu === 'hidden' ? 'hidden' : 'normal';
        bar.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, i) => {
            const stored = getHotkey(bank, i);
            const t = presetTagForMenu(stored, menu);
            const auto = isAutoHotkey(bank, i);
            const userLocked = !!getUserHotkey(bank, i);
            const label = formatHotkeyLabel(bank, i);
            const on = t ? isTagOnVideo(t) : false;
            const last = t ? isLastVideoTag(t) : false;
            const filtered = t && !matchesLiveTypeFilter(t);
            const sc = t ? sessionCountFor(t) : 0;
            const lc = t ? libraryCountFor(t) : 0;
            const statusClass = [
                hotkeyStatusClasses(t, auto, on),
                last ? 'last-video' : '',
                filtered ? 'type-filtered-out' : '',
            ].filter(Boolean).join(' ');
            const countsHtml = t
                ? `<span class="meta-hk-counts">
                    <span class="meta-count-badge session" title="Session Uses">${sc}</span>
                    ${lc > 0 ? `<span class="meta-count-badge total" title="Files with this tag">${lc}</span>` : ''}
                   </span>`
                : '';
            const lockPill = userLocked
                ? '<span class="meta-user-pill" title="User lock">lock</span>'
                : (auto ? '<span class="meta-auto-pill" title="Auto">auto</span>' : '');
            const title = t
                ? `${on ? '● On file · ' : ''}${label} · ${t} · click apply · dbl-click remove`
                : applyOnly
                    ? `Empty · assign in Tags panel · ${BANK_LABELS[bank]}`
                    : `Empty · Right-click to assign · ${BANK_LABELS[bank]}`;
            return `<button type="button" class="meta-hotkey-slot ${statusClass}" data-bank="${bank}" data-slot="${i}" data-auto="${auto ? '1' : '0'}" data-user="${userLocked ? '1' : '0'}" ${t && !applyOnly ? 'draggable="true"' : ''} data-tag="${escapeAttr(t || '')}" title="${escapeAttr(title)}">
                <span class="meta-hk-top">${bankModIconHtml(bank)}<kbd>${escapeHtml(label)}</kbd>${lockPill}${countsHtml}</span>
                <span class="meta-hk-name">${t ? escapeHtml(t) : '—'}</span>
            </button>`;
        }).join('');
        bar.querySelectorAll('.meta-hotkey-slot').forEach((btn) => {
            const b = parseInt(btn.dataset.bank, 10);
            const slot = parseInt(btn.dataset.slot, 10);
            const t = presetTagForMenu(getHotkey(b, slot), menu);
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (tagDragMoved) return;
                applyHotkeyTag(b, slot, { allowRemove: false, menu });
            });
            btn.addEventListener('dblclick', (e) => {
                e.preventDefault();
                e.stopPropagation();
                applyHotkeyTag(b, slot, { allowRemove: true, menu });
            });
            // Configuration only in Tags panel — not on clean Player HUD
            if (!applyOnly) {
                btn.addEventListener('contextmenu', (e) => showHotkeySlotAssignMenu(e, b, slot, menu));
            } else {
                btn.addEventListener('contextmenu', (e) => {
                    e.preventDefault();
                    if (t) showTagContextMenu(e, t);
                });
            }
            if (t && !applyOnly) {
                markTagDragSource(btn, { kind: 'hotkey', tag: t, bank: b, slot });
            }
            if (t) {
                try {
                    globalThis.FAFOTagColors?.paint?.(btn, t, {
                        onVideo: btn.classList.contains('on-video'),
                    });
                } catch (_) {}
            }
        });
    }

    function renderHotkeyBar() {
        if (!sessionAutoHotkeysPaused) {
            refillSessionAutoHotkeys();
        }
        paintHotkeyBarInto($('meta-hotkey-bar'), { applyOnly: false, className: 'meta-hotkey-bar', menu: 'normal' });
        // Player HUD: apply only — configure slots in Tags panel
        paintHotkeyBarInto($('hud-hotkey-bar'), { applyOnly: true, className: 'meta-hotkey-bar hud-hotkey-bar', menu: 'normal' });
        if (hiddenPanelOpen()) {
            paintHotkeyBarInto($('meta-hidden-hotkeys'), { applyOnly: false, className: 'meta-hotkey-bar', menu: 'hidden' });
        }
        const hint = $('hud-bank-hint');
        if (hint) {
            const short = ['Base', '⇧ Shift', '⌃ Ctrl', '⌥ Alt'][liveBank] || 'Base';
            hint.textContent = `1–0 · ${short}`;
        }
        updateBankIndicator();
        updateHotkeyAutoClearBtn();
    }

    async function applyHotkeyTag(bank, slot, opts = {}) {
        // Back-compat: applyHotkeyTag(1..10) treated as base bank
        if (slot == null && typeof bank === 'number' && bank >= 1 && bank <= HOTKEY_SLOTS) {
            slot = bank - 1;
            bank = 0;
        }
        bank = Math.max(0, Math.min(HOTKEY_BANKS - 1, bank | 0));
        slot = Math.max(0, Math.min(HOTKEY_SLOTS - 1, slot | 0));
        const tag = getHotkey(bank, slot);
        const label = formatHotkeyLabel(bank, slot);
        const menu = opts.menu === 'hidden' ? 'hidden' : 'normal';
        if (tag && !isTagListedIn(tag, menu)) {
            if (els.status) els.status.textContent = 'That hotkey is in the other menu';
            return;
        }
        if (!tag) {
            if (els.status) els.status.textContent = `Hotkey ${label} empty — right-click to assign`;
            setMetaPanelOpen(true);
            return;
        }
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active to tag';
            return;
        }
        // Mouse: apply-only. Keyboard (` / 1–0): allowRemove so second press clears.
        const canRemove = opts.allowRemove === true;
        const idx = activeTags.findIndex((x) => x.toLowerCase() === tag.toLowerCase());
        if (idx >= 0) {
            if (!canRemove) {
                if (els.status) {
                    els.status.textContent =
                        `${label} “${tag}” already on · double-click slot or right-click → Remove`;
                }
                return;
            }
            const [removed] = activeTags.splice(idx, 1);
            await persistActiveMeta({ removedTags: [removed || tag] });
            if (els.status) els.status.textContent = `Removed ${label} ${tag}`;
            return;
        }
        activeTags.push(tag);
        await persistActiveMeta({ touchedTags: [tag] });
        if (els.status) els.status.textContent = `Applied ${label} ${tag}`;
    }

    function renderTagLibrary() {
        if (!els.library) return;
        scrubTagLibrary();
        sortTagLibrary();
        syncCountModeToggle();
        updateMultiSelectUi();
        updateUndoBackButton();
        const q = (liveTypeFilter || els.tagFilter?.value || '').trim().toLowerCase();
        // Strict space isolation: private list never includes public vocab (counts separate too)
        const visibleLib = tagLibrary.filter((t) => isInNormalTagMenu(t));
        const list = visibleLib.filter((t) => !q || tagMatchesQuery(t, q));
        lastVisibleTagList = list.slice();
        const modeLabel = countDisplayMode === 'total' ? 'totals' : 'uses';
        const spaceMark = privateSpaceActive ? '◈ private' : 'public';
        if (els.tagCount) {
            const selN = selectedTags.size;
            els.tagCount.textContent = visibleLib.length
                ? (q
                    ? `(${list.length}/${visibleLib.length} · ${spaceMark} · filter “${q}”${selN ? ` · ${selN} sel` : ''})`
                    : `(${visibleLib.length} · ${spaceMark} · sort: ${modeLabel}${selN ? ` · ${selN} sel` : ''})`)
                : (privateSpaceActive ? '(◈ private · 0 tags)' : '');
        }
        if (!list.length) {
            els.library.innerHTML = visibleLib.length
                ? '<div class="meta-lib-empty">No tags match filter · drop chips here to remove from file</div>'
                : (privateSpaceActive
                    ? '<div class="meta-lib-empty">◈ Private library only — public tags are hidden · tag private clips to build this list</div>'
                    : '<div class="meta-lib-empty">Tags appear here · drop a chip here to remove it from the file</div>');
            renderHotkeyBar();
            return;
        }
        els.library.innerHTML = list.map(t => {
            const on = isTagOnVideo(t);
            const last = isLastVideoTag(t);
            const hk = hotkeySlotForTag(t);
            const sc = sessionCountFor(t);
            const lc = libraryCountFor(t);
            const hkBank = hotkeyBankForTag(t);
            const sel = isTagSelected(t);
            const sessionBadge = `<span class="meta-count-badge session" title="Session Uses (apply count)">${sc}</span>`;
            const totalBadge = lc > 0
                ? `<span class="meta-count-badge total" title="Files with this tag">${lc}</span>`
                : '';
            const classes = [
                'meta-lib-tag',
                on ? 'on-video' : 'off-video',
                on ? 'state-on-current' : '',
                last ? 'last-video' : '',
                !on && sc > 0 ? 'has-session state-session' : '',
                !on && sc === 0 && lc > 0 ? 'library-only state-library' : '',
                !on && sc === 0 && lc === 0 ? 'state-unused' : '',
                hk ? 'has-hotkey' : '',
                hkBank > 0 ? `mod-bank-${hkBank}` : '',
                sel ? 'selected' : '',
            ].filter(Boolean).join(' ');
            const modIcon = hkBank >= 0 ? bankModIconHtml(hkBank) : '';
            const titleExtra = last ? ' · used on last video (gold pulse)' : '';
            const colorDot = globalThis.FAFOTagColors?.get?.(t)
                ? `<span class="meta-color-dot" style="background:${escapeAttr(FAFOTagColors.get(t))}" title="Custom color"></span>`
                : '';
            const tipApply = multiSelectMode
                ? 'Click = select · Ctrl+click add · Shift+click range · right-click bulk edit'
                : ((globalThis.FAFOKnowledge?.tip?.('tag.click-apply') || 'Click = apply only') +
                    ' · ' + (globalThis.FAFOKnowledge?.tip?.('tag.dblclick-remove') || 'double-click = remove') +
                    ' · Ctrl+Shift+click → hidden menu · Ctrl+click select · right-click edit/color' + titleExtra);
            const check = `<span class="meta-lib-check" aria-hidden="true">${sel ? '✓' : ''}</span>`;
            // NEVER HTML5-draggable by default — drag fights click-to-apply on the history list.
            // Hold Alt while dragging to drag-drop (wired in initLibraryTagInteraction).
            // Edit/menu are spans (not nested buttons).
            return `<button type="button" class="${classes}" draggable="false" data-tag="${escapeAttr(t)}" data-drag-src="library" data-fafo-tip="tag.click-apply" aria-selected="${sel ? 'true' : 'false'}" title="${escapeAttr(tipApply)}">${check}${colorDot}${modIcon}${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span> ` : ''}<span class="meta-lib-name">${escapeHtml(t)}</span>${sessionBadge}${totalBadge}<span class="meta-tag-actions" title="Edit / more"><span role="button" tabindex="0" class="meta-tag-act" data-act="edit" title="Edit / rename">✎</span><span role="button" tabindex="0" class="meta-tag-act danger" data-act="menu" title="More…">⋯</span></span></button>`;
        }).join('');
        // Clicks are handled by initLibraryTagInteraction (delegated, survives re-render).
        // Only paint colors here.
        els.library.querySelectorAll('.meta-lib-tag').forEach((btn) => {
            try {
                globalThis.FAFOTagColors?.paint?.(btn, btn.dataset.tag, {
                    onVideo: btn.classList.contains('on-video'),
                });
            } catch (_) {}
        });
        try { syncAllTagUiState(els.library); } catch (_) {}
    }

    /**
     * One-time delegated click handler for Tag history.
     * Uses pointerup + movement threshold so HTML5 drag / re-renders cannot kill apply.
     */
    function initLibraryTagInteraction() {
        const lib = els.library || $('meta-tag-library');
        if (!lib || lib.dataset.fafoLibClickWired === '1') return;
        lib.dataset.fafoLibClickWired = '1';

        let ptr = null; // { btn, x, y, id, act }

        const clearPtr = () => { ptr = null; };

        lib.addEventListener('pointerdown', (e) => {
            const btn = e.target?.closest?.('.meta-lib-tag');
            if (!btn || !lib.contains(btn)) return;
            if (e.button != null && e.button !== 0) return;

            const act = e.target?.closest?.('[data-act]');
            // Alt+drag = optional drag-out to hotkey/file (opt-in only)
            if (e.altKey && !multiSelectMode && !act) {
                btn.setAttribute('draggable', 'true');
                markTagDragSource(btn, { kind: 'library', tag: btn.dataset.tag });
            } else {
                btn.setAttribute('draggable', 'false');
                btn.removeAttribute('data-tag-drag');
            }

            ptr = {
                btn,
                x: e.clientX,
                y: e.clientY,
                id: e.pointerId,
                act: act && btn.contains(act) ? act : null,
                t: Date.now(),
            };
        }, true);

        const finish = (e) => {
            if (!ptr) return;
            if (e.pointerId != null && ptr.id != null && e.pointerId !== ptr.id) return;
            const snap = ptr;
            clearPtr();

            // Real drag (panel or tag) — do not apply
            if (tagDragMoved) return;
            const dist = Math.hypot((e.clientX || 0) - snap.x, (e.clientY || 0) - snap.y);
            if (dist > 10) return;

            const btn = snap.btn;
            if (!btn || !lib.contains(btn)) return;
            const tag = normalizeTag(btn.dataset.tag || '');
            if (!tag) return;

            // Edit / more actions
            if (snap.act) {
                e.preventDefault?.();
                e.stopPropagation?.();
                if (snap.act.getAttribute('data-act') === 'edit') {
                    if (selectedTags.size > 1 && isTagSelected(tag)) bulkRenameSelected();
                    else renameTagEverywhere(tag);
                } else {
                    showTagContextMenu(e, tag);
                }
                return;
            }

            e.preventDefault?.();
            e.stopPropagation?.();

            // Ctrl+Shift+click moves the tag into the hidden menu (out of the normal list).
            if ((e.ctrlKey || e.metaKey) && e.shiftKey && !e.altKey) {
                setTagMenuScope(tag, 'hidden').catch((err) => console.warn('menu scope', err));
                return;
            }

            // Multi-select
            if (multiSelectMode || e.ctrlKey || e.metaKey || e.shiftKey) {
                if (!multiSelectMode && (e.ctrlKey || e.metaKey || e.shiftKey)) {
                    multiSelectMode = true;
                    const modeBtn = $('meta-multi-select');
                    if (modeBtn) modeBtn.classList.add('active');
                }
                toggleTagInSelection(tag, {
                    range: !!e.shiftKey,
                    addOnly: !!e.shiftKey,
                });
                return;
            }

            // Apply to current file (primary action)
            toggleLibraryTag(tag, { allowRemove: false }).catch((err) => {
                console.warn('[FAFO] history tag apply', err);
                if (els.status) els.status.textContent = `Could not apply “${tag}”`;
            });
        };

        lib.addEventListener('pointerup', finish, true);
        lib.addEventListener('pointercancel', clearPtr, true);

        // Double-click remove
        lib.addEventListener('dblclick', (e) => {
            const btn = e.target?.closest?.('.meta-lib-tag');
            if (!btn || !lib.contains(btn)) return;
            if (e.target?.closest?.('[data-act]')) return;
            if (multiSelectMode) return;
            e.preventDefault();
            e.stopPropagation();
            removeLibraryTagSafe(btn.dataset.tag);
        }, true);

        // Right-click context
        lib.addEventListener('contextmenu', (e) => {
            const btn = e.target?.closest?.('.meta-lib-tag');
            if (!btn || !lib.contains(btn)) return;
            e.preventDefault();
            if (selectedTags.size > 1 && !isTagSelected(btn.dataset.tag)) {
                setTagSelected(btn.dataset.tag, true);
                updateMultiSelectUi();
                try { syncAllTagUiState(); } catch (_) {}
            }
            showTagContextMenu(e, btn.dataset.tag);
        }, true);

        // Keyboard: arrows move chips; Enter/Space apply (same as click)
        lib.addEventListener('keydown', (e) => {
            const btn = e.target?.closest?.('.meta-lib-tag');
            if (!btn || !lib.contains(btn)) return;
            if (e.target?.closest?.('[data-act]') && (e.key === 'Enter' || e.key === ' ')) return;
            if (e.key === 'ArrowRight' || e.key === 'ArrowLeft' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                e.preventDefault();
                const chips = [...lib.querySelectorAll('.meta-lib-tag')];
                const i = chips.indexOf(btn);
                if (i < 0) return;
                const cols = Math.max(1, Math.floor(lib.clientWidth / Math.max(btn.offsetWidth || 80, 64)));
                let next = i;
                if (e.key === 'ArrowRight') next = Math.min(chips.length - 1, i + 1);
                else if (e.key === 'ArrowLeft') next = Math.max(0, i - 1);
                else if (e.key === 'ArrowDown') next = Math.min(chips.length - 1, i + cols);
                else next = Math.max(0, i - cols);
                chips[next]?.focus();
                return;
            }
            if (e.key !== 'Enter' && e.key !== ' ') return;
            e.preventDefault();
            ptr = { btn, x: 0, y: 0, id: 0, act: null, t: Date.now() };
            finish({
                clientX: 0,
                clientY: 0,
                pointerId: 0,
                ctrlKey: e.ctrlKey,
                metaKey: e.metaKey,
                shiftKey: e.shiftKey,
                preventDefault() {},
                stopPropagation() {},
            });
            // Keep keyboard focus on the same tag after re-render (unless Apply+Next)
            if (!applyAndNextMode) {
                const tag = btn.dataset.tag || '';
                setTimeout(() => {
                    const again = lib.querySelector(`.meta-lib-tag[data-tag="${CSS.escape(tag)}"]`);
                    try { again?.focus(); } catch (_) {}
                }, 50);
            }
        }, true);
    }

    function matchingSuggestions(query) {
        const q = normalizeTag(query).toLowerCase();
        const onVideo = new Set(activeTags.map(t => t.toLowerCase()));
        // Active space vocabulary only — private never suggests public tags (or counts)
        let list = tagLibrary.filter((t) =>
            isInNormalTagMenu(t) && !onVideo.has(t.toLowerCase())
        );
        if (q) {
            list = list.filter((t) => tagMatchesQuery(t, q));
            list.sort((a, b) => {
                const ap = a.toLowerCase().startsWith(q) || tagSearchKey(a).startsWith(tagSearchKey(q)) ? 0 : 1;
                const bp = b.toLowerCase().startsWith(q) || tagSearchKey(b).startsWith(tagSearchKey(q)) ? 0 : 1;
                if (ap !== bp) return ap - bp;
                const ca = displayCountFor(a);
                const cb = displayCountFor(b);
                if (cb !== ca) return cb - ca;
                return a.localeCompare(b, undefined, { sensitivity: 'base' });
            });
        }
        return list.slice(0, 12);
    }

    function hideSuggestions() {
        if (!els.suggest) return;
        els.suggest.hidden = true;
        els.suggest.innerHTML = '';
        suggestIndex = -1;
    }

    function renderTagSuggestions(query) {
        if (!els.suggest) return;
        const matches = matchingSuggestions(query);
        const q = normalizeTag(query);
        if (!matches.length) {
            if (q) {
                const already = activeTags.some((x) => x.toLowerCase() === q.toLowerCase());
                els.suggest.innerHTML = already
                    ? `<div class="hint">\u201c${escapeHtml(q)}\u201d is already on this file</div>`
                    : `<div class="hint">Press Enter to create “${escapeHtml(q)}”</div>`;
                els.suggest.hidden = false;
            } else {
                const top = tagLibrary
                    .filter((t) =>
                        isTagInCurrentSpace(t)
                        && !isHiddenFromUi(t)
                        && !activeTags.some((x) => x.toLowerCase() === t.toLowerCase())
                    )
                    .slice(0, 10);
                if (!top.length) { hideSuggestions(); return; }
                els.suggest.innerHTML = top.map((t, i) =>
                    `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}">${escapeHtml(t)}</div>`
                ).join('');
                wireSuggest();
                els.suggest.hidden = false;
            }
            return;
        }
        els.suggest.innerHTML = matches.map((t, i) =>
            `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}">${escapeHtml(t)}</div>`
        ).join('');
        wireSuggest();
        els.suggest.hidden = false;
    }

    function wireSuggest() {
        els.suggest.querySelectorAll('[data-tag]').forEach(div => {
            div.addEventListener('mousedown', (e) => {
                e.preventDefault();
                pickSuggestion(div.dataset.tag);
            });
        });
    }

    async function pickSuggestion(tag) {
        if (els.tagInput) els.tagInput.value = '';
        hideSuggestions();
        if (!activeTags.some(x => x.toLowerCase() === tag.toLowerCase())) {
            activeTags.push(tag);
        }
        await persistActiveMeta({ touchedTags: [tag] });
        els.tagInput?.focus();
    }

    /** Paint 1–5 star rating into a container (Tags panel and/or Player HUD). */
    function paintRatingStars(container) {
        if (!container) return;
        let html = '';
        for (let i = 1; i <= 5; i++) {
            html += `<span class="meta-star ${i <= activeRating ? 'on' : ''}" data-r="${i}">${i <= activeRating ? '★' : '☆'}</span>`;
        }
        container.innerHTML = html;
        container.querySelectorAll('.meta-star').forEach((st) => {
            st.addEventListener('click', () => setRating(parseInt(st.dataset.r, 10)));
            st.addEventListener('contextmenu', (e) => { e.preventDefault(); setRating(0); });
        });
    }

    function renderFileTagChips() {
        paintCurrentFileTags(els.currentTags, 'normal');
        paintCurrentFileTags(els.hudCurrentTags || $('hud-current-tags'), 'normal');
        if (hiddenPanelOpen()) paintCurrentFileTags($('meta-hidden-file-tags'), 'hidden');
    }

    /** Paint tags-on-this-file chips into a container (Tags panel and/or Player HUD). */
    function paintCurrentFileTags(container, menu) {
        if (!container) return;
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        activeTags = userTagsOnly(activeTags);
        // Never show the other section's tags, or tags that belong to the other menu.
        const chips = activeTags.filter((t) => isTagListedIn(t, which));
        const pairChip = activePairId
            ? `<span class="meta-chip meta-chip-pair" title="Pair ID (not a tag)">${escapeHtml(activePairId)}</span>`
            : '';
        if (!chips.length && !activePairId) {
            container.innerHTML = '<span class="meta-chip-empty">No tags yet</span>';
            return;
        }
        container.innerHTML = pairChip + chips.map((t, i) => {
            const hk = hotkeySlotForTag(t);
            const dim = isHiddenFromUi(t) ? ' meta-chip-hidden-list' : '';
            return `<span class="meta-chip${dim}" draggable="true" data-tag="${escapeAttr(t)}" data-drag-src="chip" title="Double-click or right-click to remove · ✎/menu to rename">${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span>` : ''}<span class="meta-chip-label">${escapeHtml(t)}</span> <button type="button" data-i="${i}" title="Double-click to remove from this file">×</button></span>`;
        }).join('');
        container.querySelectorAll('button[data-i]').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                e.preventDefault();
                if (els.status) {
                    els.status.textContent =
                        'Double-click × (or the chip) to remove · right-click for menu';
                }
            });
            btn.addEventListener('dblclick', async (e) => {
                e.stopPropagation();
                e.preventDefault();
                const i = parseInt(btn.dataset.i, 10);
                if (i < 0 || i >= activeTags.length) return;
                const [removed] = activeTags.splice(i, 1);
                await persistActiveMeta({ removedTags: removed ? [removed] : [] });
            });
        });
        container.querySelectorAll('.meta-chip[data-tag]').forEach((chip) => {
            chip.addEventListener('contextmenu', (e) => showTagContextMenu(e, chip.dataset.tag));
            chip.addEventListener('dblclick', (e) => {
                e.preventDefault();
                if (e.target?.closest?.('button[data-i]')) return;
                removeLibraryTagSafe(chip.dataset.tag);
            });
            markTagDragSource(chip, { kind: 'chip', tag: chip.dataset.tag });
            try {
                globalThis.FAFOTagColors?.paint?.(chip, chip.dataset.tag, { onVideo: true });
            } catch (_) {}
        });
    }

    function renderMetaPanel() {
        if (!els.filename) return;
        const n = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
        const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
        els.filename.textContent = activeName || 'No media';
        els.filename.title = activeName || '';
        if (els.status) {
            if (!activeKey) {
                els.status.textContent = n
                    ? `Playlist ${n} · waiting for clip (Restore Access if video blank)`
                    : 'No media — link folders in Options → Visual Library';
            } else {
                const pairHint = activePairId ? ` · ${activePairId}` : '';
                const hkHint = anyHotkeyAssigned()
                    ? ' · hold Shift/Ctrl/Alt for banks · click or `+1–0'
                    : ' · right-click tag → hotkey / hide';
                els.status.textContent = `Item ${idx + 1} of ${n} · T panel · 1–5 stars${pairHint}${hkHint}`;
            }
        }

        // Rating + file chips: Tags panel AND Player HUD (same data, both interactive)
        paintRatingStars(els.stars);
        paintRatingStars(els.hudStars || $('hud-stars'));
        renderFileTagChips();
        renderRecentTags();
        renderHotkeyBar();
        renderTagLibrary();
        renderExtraTagHud();
        renderSprintUi();
        updateHiddenTagsButton();
        updatePrivateSpaceUi();
        if ($('meta-hidden-panel') && !$('meta-hidden-panel').classList.contains('hidden')) {
            renderHiddenTagsPanel();
        }
        // Final pass: on-file + multi-select look the same on every panel
        try { syncAllTagUiState(); } catch (_) {}
    }

    async function bindToItem(item, index) {
        clearUntaggedPrompt();
        // Capture previous clip's tags for breathing gold "last video" highlight
        const nextKey = await mediaKeyFor(item);
        if (prevBindKey && nextKey && prevBindKey !== nextKey) {
            lastVideoTags = userTagsOnly(activeTags).slice();
        }
        prevBindKey = nextKey || prevBindKey;

        activeName = itemDisplayName(item);
        activeKey = nextKey;
        // Stamp key on playlist item so space filtering works without re-hash
        try {
            if (item && nextKey) item.mediaKey = nextKey;
        } catch (_) {}
        // Libraries are rebuilt per-space — no cross-skip needed when folders are isolated
        const id = await identityForItem(item);
        let stored = (activeKey && mediaMeta[activeKey]) || null;
        // Exact fallback only (name+size or unique name) — no fuzzy includes
        if (!stored || (!(stored.tags && stored.tags.length) && !stored.pairId && !stored.rating)) {
            const byExact = globalThis.FAFOId?.findStoredMeta
                ? FAFOId.findStoredMeta(mediaMeta, {
                    key: activeKey,
                    name: activeName,
                    size: id?.size,
                    mtime: id?.mtime,
                })
                : findStoredByName(activeName);
            if (byExact?.meta) {
                stored = byExact.meta;
                // Prefer stable key from match so quick-panel saves stick
                if (byExact.key) activeKey = byExact.key;
            }
        }
        activeRating = stored?.rating || 0;
        activePairId = globalThis.FAFOId?.pairIdFromMeta
            ? FAFOId.pairIdFromMeta(stored || {})
            : (stored?.pairId || '');
        // Quick panel chips = user tags only (pair IDs / role stamps filtered out)
        activeTags = userTagsOnly(Array.isArray(stored?.tags) ? stored.tags : []);

        // Discover tags from toolbox catalog / file metadata — PUBLIC only.
        // Private mode never pulls public Explorer keywords into secret lists.
        // When local storage was wiped, disk tags are the recovery source of truth.
        let mediaDirty = false;
        if (!privateSpaceActive) {
            const remote = await fetchTagsForIdentity(id);
            if (remote) {
                const remoteUser = userTagsOnly(remote.tags || []);
                if (remoteUser.length || remote.rating) {
                    if (!activeTags.length && remoteUser.length) {
                        activeTags = [...remoteUser];
                        mediaDirty = true;
                    } else if (remoteUser.length) {
                        // Merge disk tags into local (recover missing without dropping local-only)
                        const lows = new Set(activeTags.map((t) => String(t).toLowerCase()));
                        remoteUser.forEach((t) => {
                            if (!lows.has(String(t).toLowerCase())) {
                                activeTags.push(t);
                                lows.add(String(t).toLowerCase());
                                mediaDirty = true;
                            }
                        });
                        ensureTagsKnown(remoteUser, { publicCatalogOnly: true });
                    }
                    if (!activeRating && remote.rating) {
                        activeRating = remote.rating;
                        mediaDirty = true;
                    }
                    if (activeKey && mediaDirty) {
                        mediaMeta[activeKey] = {
                            ...(mediaMeta[activeKey] || {}),
                            rating: activeRating,
                            tags: [...activeTags],
                            name: activeName,
                            size: id?.size ?? null,
                            path: remote.path || mediaMeta[activeKey]?.path,
                            pairId: activePairId || mediaMeta[activeKey]?.pairId,
                            updated: Date.now(),
                            recoveredFromDisk: true,
                        };
                    }
                }
            }
        }

        // Ensure current clip is indexed so library totals + quick panel stick across plays
        if (activeKey) {
            const existing = mediaMeta[activeKey];
            if (!existing && (activeTags.length || activeRating || activePairId)) {
                mediaMeta[activeKey] = {
                    rating: activeRating,
                    tags: [...activeTags],
                    name: activeName,
                    size: id?.size ?? null,
                    pairId: activePairId || undefined,
                    updated: Date.now(),
                };
                mediaDirty = true;
            } else if (existing) {
                if (existing.size == null && id?.size != null) {
                    existing.size = id.size;
                    mediaDirty = true;
                }
                // Keep pairId / cleaned tags on the record
                const cleaned = userTagsOnly(existing.tags || []);
                if (cleaned.length !== (existing.tags || []).length) {
                    existing.tags = cleaned;
                    mediaDirty = true;
                }
                if (activePairId && !existing.pairId) {
                    existing.pairId = activePairId;
                    mediaDirty = true;
                }
            }
        }

        accumulateTagsFromMedia(activeTags);
        if (mediaDirty) await saveStore();

        renderMetaPanel();
        renderSprintUi();
        scheduleLiveStats();
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        if (pendingTagFocusRestore) restoreTagFocus(pendingTagFocusRestore);
    }

    // ── Sprint Tag mode (5 tags + rating, big nav, untagged-first) ─────────
    function isSprintMode() {
        return !!sprintModeOpen;
    }

    function getSprintTags() {
        return sprintTags.map(normalizeTag).filter(Boolean);
    }

    function clipHasAnySprintTag(item) {
        const focus = getSprintTags();
        if (!focus.length) return false;
        const countTags = (() => {
            // Prefer live active clip
            const name = itemDisplayName(item);
            if (activeName && name && activeName.toLowerCase() === String(name).toLowerCase()) {
                return activeTags;
            }
            const n = tagCountForItem(item);
            // Need actual tags for membership — pull from meta
            if (item?.mediaKey && mediaMeta[item.mediaKey]?.tags) {
                return userTagsOnly(mediaMeta[item.mediaKey].tags);
            }
            const size = item?.size ?? item?._size ?? null;
            if (globalThis.FAFOId?.findStoredMeta) {
                const hit = FAFOId.findStoredMeta(mediaMeta, { name, size });
                return userTagsOnly(hit?.meta?.tags || []);
            }
            const byName = findStoredByName(name);
            return userTagsOnly(byName?.meta?.tags || []);
        })();
        const lows = new Set(countTags.map((t) => String(t).toLowerCase()));
        return focus.some((t) => lows.has(t.toLowerCase()));
    }

    /**
     * Sprint queue score for a playlist item:
     * - Prefer clips with fewer tags (0, then 1, then 2…)
     * - Among those, prefer clips that do NOT already have any of the 5 sprint tags
     * Returns lower = earlier in the runway.
     */
    function sprintScoreForItem(item) {
        const n = tagCountForItem(item) | 0;
        const hasFocus = clipHasAnySprintTag(item) ? 1 : 0;
        // hasFocus in high bits so missing-focus comes first within same tag count? 
        // User wants: no tags first, then 1, 2… AND skip ones that already have sprint tags.
        // Score: hasFocus * 10000 + n  → missing focus first, then by tag count
        return hasFocus * 10000 + n;
    }

    function setSprintModeOpen(open) {
        sprintModeOpen = !!open;
        document.body.classList.toggle('fafo-sprint-mode', sprintModeOpen);
        const body = $('meta-sprint-body');
        const btn = $('meta-sprint-toggle');
        if (body) {
            body.classList.toggle('hidden', !sprintModeOpen);
            body.setAttribute('aria-hidden', sprintModeOpen ? 'false' : 'true');
        }
        if (btn) {
            btn.classList.toggle('active', sprintModeOpen);
            btn.setAttribute('aria-expanded', sprintModeOpen ? 'true' : 'false');
            btn.textContent = sprintModeOpen ? 'Sprint Tag · collapse' : 'Sprint Tag · expand';
        }
        renderSprintUi();
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        if (els.status) {
            els.status.textContent = sprintModeOpen
                ? 'Sprint ON · 0 tags first · big ‹ › · 5 tags toggle · skips clips that already have a sprint tag'
                : 'Sprint closed';
        }
        // Persist open state + tags lightly (sprint tag list is space-scoped)
        const sk = spaceKeys();
        chrome.storage.local.set({
            fafoSprintOpen: sprintModeOpen,
            [sk.sprintTags]: sprintTags.slice(),
        }).catch(() => {});
    }

    function paintSprintInto(tagsEl, menu) {
        if (!tagsEl) return;
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        tagsEl.innerHTML = sprintTags.map((raw, i) => {
            const stored = normalizeTag(raw);
            const t = presetTagForMenu(stored, which);
            const on = t && isTagOnVideo(t);
            const last = t && isLastVideoTag(t);
            const filtered = t && !matchesLiveTypeFilter(t);
            const cls = [
                'meta-sprint-tag',
                t ? 'set' : 'empty',
                on ? 'on-video' : '',
                last ? 'last-video' : '',
                filtered ? 'type-filtered-out' : '',
            ].filter(Boolean).join(' ');
            const title = t
                ? `${t} · click apply · double-click remove · right-click change slot`
                : (stored ? 'In the other menu' : 'Click to pick tag · right-click also works');
            const label = t ? escapeHtml(t) : (stored ? '—' : `+ tag ${i + 1}`);
            return `<button type="button" class="${cls}" data-sprint-slot="${i}" title="${escapeAttr(title)}">${label}</button>`;
        }).join('');
        tagsEl.querySelectorAll('[data-sprint-slot]').forEach((btn) => {
            const slot = parseInt(btn.dataset.sprintSlot, 10);
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const storedTag = normalizeTag(sprintTags[slot] || '');
                const t = presetTagForMenu(storedTag, which);
                if (!storedTag) {
                    assignSprintSlot(slot);
                    return;
                }
                if (!t) return;
                toggleLibraryTag(t, { allowRemove: false });
            });
            btn.addEventListener('dblclick', (e) => {
                e.preventDefault();
                const t = presetTagForMenu(sprintTags[slot], which);
                if (t) removeLibraryTagSafe(t);
            });
            btn.addEventListener('contextmenu', (e) => {
                e.preventDefault();
                const storedTag = normalizeTag(sprintTags[slot] || '');
                if (storedTag && !presetTagForMenu(storedTag, which)) return;
                assignSprintSlot(slot);
            });
        });
    }

    function renderSprintUi() {
        const starsEl = $('meta-sprint-stars');
        const statusEl = $('meta-sprint-status');
        if (starsEl) {
            let html = '';
            for (let i = 1; i <= 5; i++) {
                html += `<span class="meta-star ${i <= activeRating ? 'on' : ''}" data-r="${i}">${i <= activeRating ? '★' : '☆'}</span>`;
            }
            starsEl.innerHTML = html;
            starsEl.querySelectorAll('.meta-star').forEach((st) => {
                st.addEventListener('click', () => setRating(parseInt(st.dataset.r, 10)));
                st.addEventListener('contextmenu', (e) => { e.preventDefault(); setRating(0); });
            });
        }
        paintSprintInto($('meta-sprint-tags'), 'normal');
        if (hiddenPanelOpen()) paintSprintInto($('meta-hidden-sprint'), 'hidden');
        if (statusEl) {
            const n = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
            const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
            const focus = getSprintTags().filter((t) => isTagListedIn(t, 'normal'));
            const tc = activeTags.filter((t) => isTagListedIn(t, 'normal')).length;
            statusEl.textContent = n
                ? `Clip ${idx + 1}/${n} · ${tc} tag(s) on file · focus ${focus.length}/5 · queue 0→1→2…`
                : 'No playlist · link media in Options';
        }
    }

    function assignSprintSlot(slot) {
        const cur = normalizeTag(sprintTags[slot] || '');
        const picked = prompt(
            `Sprint tag slot ${slot + 1} — type a tag name (blank to clear):`,
            cur || ''
        );
        if (picked == null) return;
        const t = normalizeTag(picked);
        sprintTags[slot] = t;
        if (t) ensureTagsKnown([t]);
        const sk = spaceKeys();
        chrome.storage.local.set({ [sk.sprintTags]: sprintTags.slice() }).catch(() => {});
        renderSprintUi();
        if (els.status) {
            els.status.textContent = t
                ? `Sprint slot ${slot + 1} = ${t}`
                : `Sprint slot ${slot + 1} cleared`;
        }
    }

    /**
     * Tab = complete the rest of the word when suggestions are narrowed;
     * second Tab / Enter on a full match applies the tag.
     */
    function onTagInputKeydown(e) {
        const visible = els.suggest && !els.suggest.hidden;
        const items = visible ? [...els.suggest.querySelectorAll('[data-tag]')] : [];
        if (e.key === 'ArrowDown' && items.length) {
            e.preventDefault();
            suggestIndex = (suggestIndex + 1) % items.length;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'ArrowUp' && items.length) {
            e.preventDefault();
            suggestIndex = suggestIndex <= 0 ? items.length - 1 : suggestIndex - 1;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (suggestIndex >= 0 && items[suggestIndex]) pickSuggestion(items[suggestIndex].dataset.tag);
            else addTagsFromInput();
            return;
        }
        if (e.key === 'Escape') {
            hideSuggestions();
            els.tagInput?.blur();
            return;
        }
        if (e.key === 'Tab') {
            const qRaw = els.tagInput?.value || '';
            const q = normalizeTag(qRaw);
            const matches = matchingSuggestions(qRaw);
            const highlighted = (suggestIndex >= 0 && items[suggestIndex])
                ? items[suggestIndex].dataset.tag
                : null;
            // Prefer arrow-highlighted row; else best match when narrowed (1 hit or clear prefix)
            let target = highlighted || null;
            if (!target && matches.length === 1) target = matches[0];
            else if (!target && matches.length > 1 && q) {
                // Prefers prefix matches from matchingSuggestions sort
                const top = matches[0];
                if (top && top.toLowerCase().startsWith(q.toLowerCase())) target = top;
            } else if (!target && matches.length && !q) {
                target = matches[0];
            }
            if (!target) return; // nothing to complete — allow focus leave
            e.preventDefault();
            e.stopPropagation();
            const full = normalizeTag(target);
            if (!full) return;
            // Already complete → apply tag (same as Enter)
            if (q && q.toLowerCase() === full.toLowerCase()) {
                pickSuggestion(full);
                return;
            }
            // Fill the rest of the word into the input; keep suggestions open
            if (els.tagInput) els.tagInput.value = full;
            suggestIndex = Math.max(0, matches.findIndex((t) => t.toLowerCase() === full.toLowerCase()));
            if (suggestIndex < 0) suggestIndex = 0;
            renderTagSuggestions(full);
            if (els.status) {
                els.status.textContent = matches.length === 1
                    ? `Completed “${full}” · Enter to apply`
                    : `Completed “${full}” · Tab/Enter to apply · ↓↑ for others`;
            }
        }
    }

    function initTagLibraryResize() {
        const handle = $('meta-tag-resize');
        if (!handle || !els.library) return;

        applyTagLibraryHeight();

        const onMove = (clientY) => {
            if (!resizeDragging) return;
            const rect = els.library.getBoundingClientRect();
            const next = Math.round(clientY - rect.top);
            tagLibraryHeight = Math.max(80, Math.min(Math.round(window.innerHeight * 0.55), next));
            els.library.style.height = tagLibraryHeight + 'px';
        };

        const endDrag = () => {
            if (!resizeDragging) return;
            resizeDragging = false;
            handle.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            capturePanelSize();
            scheduleLayoutSave();
        };

        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            resizeDragging = true;
            handle.classList.add('dragging');
            document.body.style.cursor = 'ns-resize';
            document.body.style.userSelect = 'none';
        });
        document.addEventListener('mousemove', (e) => {
            if (resizeDragging) onMove(e.clientY);
        });
        document.addEventListener('mouseup', endDrag);

        handle.addEventListener('touchstart', (e) => {
            if (!e.touches?.[0]) return;
            e.preventDefault();
            resizeDragging = true;
            handle.classList.add('dragging');
        }, { passive: false });
        document.addEventListener('touchmove', (e) => {
            if (resizeDragging && e.touches?.[0]) onMove(e.touches[0].clientY);
        }, { passive: true });
        document.addEventListener('touchend', endDrag);
    }

    function wireUI() {
        els = {
            toggle: $('meta-toggle'),
            panel: $('meta-panel'),
            filename: $('meta-filename'),
            status: $('meta-status'),
            stars: $('meta-stars'),
            currentTags: $('meta-current-tags'),
            hudStars: $('hud-stars'),
            hudCurrentTags: $('hud-current-tags'),
            tagInput: $('meta-tag-input'),
            tagAdd: $('meta-tag-add'),
            suggest: $('meta-tag-suggest'),
            library: $('meta-tag-library'),
            tagFilter: $('meta-tag-filter'),
            tagCount: $('meta-tag-count'),
            prev: $('meta-prev'),
            next: $('meta-next'),
            collapse: $('meta-collapse'),
            skipTagged: $('meta-skip-tagged'),
        };
        if (!els.toggle) return;

        els.toggle.addEventListener('click', () => setMetaPanelOpen(!metaPanelOpen));
        els.collapse?.addEventListener('click', () => setMetaPanelOpen(false));
        $('meta-help-here')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            try {
                window.FAFOHelp?.setContext?.('newtab.tags');
                window.FAFOHelp?.summon?.({ context: 'newtab.tags', from: e.target });
            } catch (_) {
                window.FAFOKnowledge?.openGuide?.();
            }
        });
        els.prev?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(-1));
        els.next?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(1));
        els.tagAdd?.addEventListener('click', () => addTagsFromInput());
        els.tagInput?.addEventListener('keydown', onTagInputKeydown);

        // Player HUD light tagging: add tags + optional quick tags (no full Tags panel)
        const hudTagInput = $('hud-tag-input');
        const hudTagAdd = $('hud-tag-add');
        const hudSuggest = $('hud-tag-suggest');
        let hudSuggestIndex = -1;

        function hideHudSuggestions() {
            if (!hudSuggest) return;
            hudSuggest.hidden = true;
            hudSuggest.innerHTML = '';
            hudSuggestIndex = -1;
        }

        function renderHudTagSuggestions(query) {
            if (!hudSuggest) return;
            const matches = matchingSuggestions(query);
            const q = normalizeTag(query);
            if (!matches.length) {
                if (q) {
                    const already = activeTags.some((x) => x.toLowerCase() === q.toLowerCase());
                    hudSuggest.innerHTML = already
                        ? `<div class="hint">\u201c${escapeHtml(q)}\u201d is already on this file</div>`
                        : `<div class="hint">Enter to create “${escapeHtml(q)}”</div>`;
                    hudSuggest.hidden = false;
                } else {
                    hideHudSuggestions();
                }
                return;
            }
            hudSuggest.innerHTML = matches.map((t, i) =>
                `<div data-tag="${escapeAttr(t)}" class="${i === hudSuggestIndex ? 'active' : ''}">${escapeHtml(t)}</div>`
            ).join('');
            hudSuggest.querySelectorAll('[data-tag]').forEach((div) => {
                div.addEventListener('mousedown', (e) => {
                    e.preventDefault();
                    pickHudSuggestion(div.dataset.tag);
                });
            });
            hudSuggest.hidden = false;
        }

        async function pickHudSuggestion(tag) {
            const t = normalizeTag(tag);
            if (!t) return;
            if (hudTagInput) hudTagInput.value = '';
            hideHudSuggestions();
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
            }
            ensureTagsKnown([t]);
            await persistActiveMeta({ touchedTags: [t] });
            hudTagInput?.focus();
        }

        const addFromHud = async () => {
            if (!hudTagInput) return;
            const parts = (hudTagInput.value || '').split(/[,;]+/).map(normalizeTag).filter((t) => t && !isOversizedOrSuspectTag(t));
            if (!parts.length) return;
            const newly = [];
            parts.forEach((t) => {
                if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                    activeTags.push(t);
                    newly.push(t);
                }
            });
            hudTagInput.value = '';
            hideHudSuggestions();
            ensureTagsKnown(parts);
            if (newly.length) await persistActiveMeta({ touchedTags: newly });
            else if (parts.length) await persistActiveMeta({ touchedTags: parts });
            schedulePersistTagDb();
        };
        hudTagAdd?.addEventListener('click', () => addFromHud());
        hudTagInput?.addEventListener('input', () => {
            hudSuggestIndex = -1;
            renderHudTagSuggestions(hudTagInput.value || '');
        });
        hudTagInput?.addEventListener('focus', () => {
            renderHudTagSuggestions(hudTagInput.value || '');
        });
        hudTagInput?.addEventListener('blur', () => {
            setTimeout(() => hideHudSuggestions(), 120);
        });
        hudTagInput?.addEventListener('keydown', (e) => {
            const items = hudSuggest && !hudSuggest.hidden
                ? [...hudSuggest.querySelectorAll('[data-tag]')]
                : [];
            if (e.key === 'ArrowDown' && items.length) {
                e.preventDefault();
                hudSuggestIndex = (hudSuggestIndex + 1) % items.length;
                renderHudTagSuggestions(hudTagInput.value || '');
                return;
            }
            if (e.key === 'ArrowUp' && items.length) {
                e.preventDefault();
                hudSuggestIndex = hudSuggestIndex <= 0 ? items.length - 1 : hudSuggestIndex - 1;
                renderHudTagSuggestions(hudTagInput.value || '');
                return;
            }
            if (e.key === 'Tab' && items.length) {
                e.preventDefault();
                const pick = (hudSuggestIndex >= 0 && items[hudSuggestIndex])
                    ? items[hudSuggestIndex].dataset.tag
                    : items[0].dataset.tag;
                if (pick) {
                    hudTagInput.value = pick;
                    hudSuggestIndex = 0;
                    renderHudTagSuggestions(pick);
                }
                return;
            }
            if (e.key === 'Enter') {
                e.preventDefault();
                if (hudSuggestIndex >= 0 && items[hudSuggestIndex]) {
                    pickHudSuggestion(items[hudSuggestIndex].dataset.tag);
                } else {
                    addFromHud();
                }
                return;
            }
            if (e.key === 'Escape') {
                hideHudSuggestions();
            }
        });
        $('hud-open-tags')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            setMetaPanelOpen(true);
        });

        // Quick tags block (hotkeys + recent) toggle — light mode play panel
        let hudQuickTags = false;
        const applyHudQuickTags = (on) => {
            hudQuickTags = !!on;
            const block = $('hud-quick-tags-block');
            const btn = $('hud-quick-tags-toggle');
            block?.classList.toggle('hidden', !hudQuickTags);
            if (btn) {
                btn.classList.toggle('active', hudQuickTags);
                btn.textContent = hudQuickTags ? 'Quick tags · on' : 'Quick tags';
                btn.title = hudQuickTags
                    ? 'Hide quick tags (hotkeys + recent) on the play panel'
                    : 'Show quick tags (hotkeys + recent) on the play panel';
            }
            $('player-hud')?.classList.toggle('hud-light-tag', true);
            if (hudQuickTags) {
                try { renderHotkeyBar(); } catch (_) {}
                try { renderRecentTags(); } catch (_) {}
            }
            try { chrome.storage.local.set({ fafoHudQuickTags: hudQuickTags }); } catch (_) {}
        };
        try {
            chrome.storage.local.get(['fafoHudQuickTags'], (res) => {
                applyHudQuickTags(!!res.fafoHudQuickTags);
            });
        } catch (_) {
            applyHudQuickTags(false);
        }
        $('hud-quick-tags-toggle')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            applyHudQuickTags(!hudQuickTags);
        });

        // Clean mode: hide extra chrome; keep light rate/tag
        let hudClean = true;
        const applyHudClean = (on) => {
            hudClean = !!on;
            const box = $('player-hud');
            box?.classList.toggle('hud-clean', hudClean);
            box?.classList.add('hud-light-tag');
            const btn = $('hud-clean-mode');
            if (btn) {
                btn.classList.toggle('active', hudClean);
                btn.textContent = hudClean ? 'Light' : 'Full';
                btn.title = hudClean
                    ? 'Light: play panel tagging · extras hidden · keys still work'
                    : 'Full: show zoom / place / all tool buttons';
            }
            try { chrome.storage.local.set({ fafoHudClean: hudClean }); } catch (_) {}
        };
        try {
            chrome.storage.local.get(['fafoHudClean'], (res) => {
                applyHudClean(res.fafoHudClean !== false);
            });
        } catch (_) {
            applyHudClean(true);
        }
        $('hud-clean-mode')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            applyHudClean(!hudClean);
        });
        try {
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local') return;
                if (changes.fafoHudClean && typeof changes.fafoHudClean.newValue === 'boolean') {
                    applyHudClean(!!changes.fafoHudClean.newValue);
                }
                if (changes.fafoHudQuickTags && typeof changes.fafoHudQuickTags.newValue === 'boolean') {
                    applyHudQuickTags(!!changes.fafoHudQuickTags.newValue);
                }
                if (changes.fafoAutoDiskSync && typeof changes.fafoAutoDiskSync.newValue === 'boolean') {
                    autoDiskSync = !!changes.fafoAutoDiskSync.newValue;
                    try { updateAutoSyncUi(); } catch (_) {}
                }
            });
        } catch (_) {}
        const moreBtn = $('hud-fold-more');
        const moreBody = $('hud-fold-more-body');
        moreBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            const open = moreBtn.getAttribute('aria-expanded') !== 'true';
            moreBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
            moreBtn.textContent = open ? '▾ More' : '▸ More';
            if (moreBody) {
                moreBody.hidden = !open;
                moreBody.classList.toggle('is-collapsed', !open);
                moreBody.classList.toggle('is-open', open);
            }
        });
        els.tagInput?.addEventListener('input', () => {
            suggestIndex = -1;
            // Live-narrow library, hotkeys, E-set, recent, sprint
            setLiveTypeFilter(els.tagInput.value || '');
            renderTagSuggestions(els.tagInput.value);
        });
        els.tagInput?.addEventListener('focus', () => {
            setLiveTypeFilter(els.tagInput.value || '');
            renderTagSuggestions(els.tagInput.value);
        });
        els.tagFilter?.addEventListener('input', () => {
            if (document.activeElement === els.tagFilter) {
                liveTypeFilter = els.tagFilter.value || '';
            }
            renderTagLibrary();
            renderHotkeyBar();
            renderRecentTags();
            renderExtraTagHud();
            renderSprintUi();
        });
        els.skipTagged?.addEventListener('click', () => setSkipTaggedMode(!skipTaggedMode));
        $('meta-hotkey-clear-auto')?.addEventListener('click', () => {
            const mode = $('meta-hotkey-clear-auto')?.dataset?.mode || 'clear';
            if (mode === 'fill' || sessionAutoHotkeysPaused) enableSessionAutoHotkeys();
            else clearSessionAutoHotkeys();
        });
        const wireExtraAutoBtn = (id) => {
            $(id)?.addEventListener('click', () => {
                const mode = $(id)?.dataset?.mode || 'clear';
                if (mode === 'fill' || sessionAutoExtraPaused) enableSessionAutoExtra();
                else clearSessionAutoExtra();
                renderExtraTagHud();
            });
        };
        wireExtraAutoBtn('meta-eset-auto-btn');
        wireExtraAutoBtn('hud-eset-auto');
        $('meta-undo-back')?.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();
            await globalThis.FAFOUndo?.undo?.();
            updateUndoBackButton();
        });
        $('meta-multi-select')?.addEventListener('click', (e) => {
            e.preventDefault();
            setMultiSelectMode(!multiSelectMode);
            renderTagLibrary();
        });
        $('meta-select-all-tags')?.addEventListener('click', (e) => {
            e.preventDefault();
            selectAllVisibleTags();
        });
        $('meta-multi-bar')?.addEventListener('click', (e) => {
            const btn = e.target?.closest?.('[data-multi]');
            if (!btn) return;
            e.preventDefault();
            e.stopPropagation();
            runMultiAction(btn.getAttribute('data-multi'), e);
        });
        try {
            globalThis.FAFOUndo?.onChange?.(() => updateUndoBackButton());
        } catch (_) {}
        updateUndoBackButton();
        window.addEventListener('fafo:undo', () => updateUndoBackButton());
        window.addEventListener('fafo:undo-stack', () => updateUndoBackButton());

        $('meta-count-mode')?.addEventListener('click', () => {
            setCountDisplayMode(countDisplayMode === 'total' ? 'session' : 'total');
        });
        $('meta-rebuild-counts')?.addEventListener('click', async () => {
            const fromDisk = confirm(
                'Recover tags from disk (Windows Explorer metadata)?\n\n' +
                'OK = read Tags + Rating from real files via Explorer companion (S2)\n' +
                '    and merge into FAFO library (recommended after snapshot/storage loss).\n\n' +
                'Cancel = only recompute Uses counts from tags already in FAFO memory.'
            );
            if (fromDisk) {
                if (els.status) els.status.textContent = 'Rebuilding from disk…';
                try {
                    const r = await rebuildMediaMetaFromDisk({});
                    if (els.status) {
                        els.status.textContent =
                            `Disk recovery done · ${r.withTags || 0} tagged files · ${r.updated + r.created} entries`;
                    }
                } catch (e) {
                    if (els.status) els.status.textContent = e.message || String(e);
                    alert(e.message || String(e));
                }
            } else if (confirm('Rebuild Uses counts from library tags already in FAFO?')) {
                rebuildApplyCountsFromLibrary();
            }
        });
        $('meta-hidden-tags-btn')?.addEventListener('click', () => {
            const panel = $('meta-hidden-panel');
            const currentlyClosed = !panel || panel.classList.contains('hidden');
            setHiddenPanelOpen(currentlyClosed);
        });
        $('meta-hidden-close')?.addEventListener('click', () => setHiddenPanelOpen(false));
        $('meta-hidden-restore-all')?.addEventListener('click', () => {
            const moving = hiddenMenuTags().filter((t) => tagMenuScopeOf(t) !== 'both');
            if (!moving.length) {
                if (els.status) els.status.textContent = 'No hidden-only tags to move';
                return;
            }
            if (confirm(`Move ${moving.length} hidden-only tag(s) back to the normal menu?`)) {
                moveHiddenOnlyToNormal();
            }
        });
        // Private isolated section
        $('meta-private-space-btn')?.addEventListener('click', () => handlePrivateSpaceButtonClick());
        $('meta-private-lock-btn')?.addEventListener('click', async () => {
            await lockPrivateSpace();
            if (els.status) els.status.textContent = 'Private section locked';
        });
        $('meta-private-to-public-btn')?.addEventListener('click', () => enterPublicSpace());
        $('meta-private-link-folder-btn')?.addEventListener('click', () => linkPrivateLibraryFolder('videos'));
        $('meta-private-link-photos-btn')?.addEventListener('click', () => linkPrivateLibraryFolder('photos'));
        $('meta-private-modal-cancel')?.addEventListener('click', () => hidePrivateUnlockModal());
        $('meta-private-modal-ok')?.addEventListener('click', () => submitPrivateUnlockModal());
        $('meta-private-pin')?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const p2 = $('meta-private-pin2');
                if (p2 && !p2.classList.contains('hidden')) p2.focus();
                else submitPrivateUnlockModal();
            }
        });
        $('meta-private-pin2')?.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                submitPrivateUnlockModal();
            }
        });
        // Secret chord: Ctrl+Shift+Alt+P → unlock modal
        // Double Escape (within 700ms) → exit private back to normal
        let escapeTapAt = 0;
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey && e.shiftKey && e.altKey && (e.key === 'p' || e.key === 'P')) {
                e.preventDefault();
                handlePrivateSpaceButtonClick();
                return;
            }
            if (e.key === 'Escape' || e.key === 'Esc') {
                // Don't steal Esc from open modals on first press — close modal first
                const modal = $('meta-private-modal');
                if (modal && !modal.classList.contains('hidden')) {
                    hidePrivateUnlockModal();
                    escapeTapAt = 0;
                    e.preventDefault();
                    return;
                }
                if (!privateSpaceActive && !privateUnlocked) {
                    escapeTapAt = 0;
                    return;
                }
                const now = Date.now();
                if (now - escapeTapAt < 700) {
                    escapeTapAt = 0;
                    e.preventDefault();
                    e.stopPropagation();
                    exitPrivateToNormal().catch((err) => console.warn('exitPrivateToNormal', err));
                } else {
                    escapeTapAt = now;
                    if (els.status && privateSpaceActive) {
                        els.status.textContent = 'Press Escape again to exit private mode';
                    } else if (els.status && privateUnlocked) {
                        els.status.textContent = 'Press Escape again to lock private vault';
                    }
                }
            }
        }, true);
        updatePrivateSpaceUi();
        persistPrivateSessionFlag().catch(() => {});
        $('meta-apply-next')?.addEventListener('click', () => {
            applyAndNextMode = !applyAndNextMode;
            updateApplyNextBtn();
            chrome.storage.local.set({ fafoApplyAndNext: applyAndNextMode }).catch(() => {});
            if (els.status) {
                els.status.textContent = applyAndNextMode
                    ? 'Apply+Next ON — tagging advances to next clip'
                    : 'Apply+Next off';
            }
        });
        $('meta-export-backup')?.addEventListener('click', () => exportTagsBackup());
        $('meta-settings-export')?.addEventListener('click', () => downloadSettingsText());
        $('meta-settings-import')?.addEventListener('click', () => {
            const inp = $('meta-settings-file');
            if (inp) {
                inp.value = '';
                inp.click();
            }
        });
        $('meta-settings-file')?.addEventListener('change', async (e) => {
            const f = e.target?.files?.[0];
            if (f) await importSettingsFromFile(f);
        });
        $('meta-dock-pos')?.addEventListener('click', () => cycleDockPos());
        $('meta-stage-layout')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.cycleStageLayout?.(); } catch (_) {}
        });
        $('meta-stage-width')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.cycleStageWidth?.(); } catch (_) {}
        });
        $('meta-undock-move')?.addEventListener('click', () => undockTagsForMove());
        $('meta-stick-layout')?.addEventListener('click', () => setStickLayout(!stickLayout));
        $('meta-ui-scale')?.addEventListener('click', () => cycleUiScale());
        bindScaleSliders();
        $('meta-size-down')?.addEventListener('click', () => nudgePanelSize(-1));
        $('meta-size-up')?.addEventListener('click', () => nudgePanelSize(1));
        $('meta-layout-save-defaults')?.addEventListener('click', () => {
            saveLayoutAsDefaults();
        });
        $('meta-layout-reset')?.addEventListener('click', () => {
            resetLayout();
        });
        $('meta-layout-preset-select')?.addEventListener('change', (e) => {
            const id = e.target?.value;
            if (id) applyLayoutPresetById(id);
        });
        $('meta-layout-preset-save')?.addEventListener('click', async () => {
            const name = prompt('Name for this layout preset:', `Layout ${layoutPresets.length + 1}`);
            if (name == null || !String(name).trim()) return;
            await saveLayoutAsPreset(String(name).trim());
        });
        $('meta-layout-preset-update')?.addEventListener('click', () => updateActiveLayoutPreset());
        $('meta-layout-preset-delete')?.addEventListener('click', async () => {
            const id = $('meta-layout-preset-select')?.value || activeLayoutPresetId;
            if (!id) {
                if (els.status) els.status.textContent = 'Pick a layout preset to delete';
                return;
            }
            const p = layoutPresets.find((x) => x.id === id);
            if (!p || !confirm(`Delete layout preset “${p.name}”?`)) return;
            await deleteLayoutPreset(id);
        });
        $('meta-auto-disk-sync')?.addEventListener('click', () => setAutoDiskSync(!autoDiskSync));
        $('meta-sprint-toggle')?.addEventListener('click', () => setSprintModeOpen(!sprintModeOpen));
        $('meta-sprint-prev')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.skipTrack?.(-1); } catch (_) {}
            renderSprintUi();
        });
        $('meta-sprint-next')?.addEventListener('click', () => {
            try { window.FAFOPlayer?.skipTrack?.(1); } catch (_) {}
            renderSprintUi();
        });
        $('meta-split-toggle')?.addEventListener('click', () => toggleLibrarySplit());
        $('meta-split-toggle-2')?.addEventListener('click', () => toggleLibrarySplit());
        $('meta-lib-collapse')?.addEventListener('click', () => {
            const lib = $('meta-library-panel');
            if (!lib) return;
            lib.classList.add('collapsed');
            lib.dataset.userHidden = '1';
            lib.setAttribute('aria-hidden', 'true');
        });

        initTagDndDelegation();
        initLibraryTagInteraction();
        initHiddenMenuInteraction();
        initTagLibraryResize();
        initPanelDrag();
        initLibPanelDrag();
        initPanelResizeObserver();
        initEdgeResize($('meta-panel'), { isMainPanel: true, minW: 180, minH: 120 });
        initEdgeResize($('meta-library-panel'), { isMainPanel: false, minW: 180, minH: 120 });
        initMetaFolds();
        $('meta-lib-save-pos')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            try {
                capturePanelSize();
                captureLibraryGeometry();
                rememberLayoutSlot();
            } catch (_) {}
            saveLayoutAsDefaults().then(() => {
                if (els.status) {
                    els.status.textContent =
                        `Positions saved · Tags ${Math.round(dockX)},${Math.round(dockY)} · History ${Math.round(libX)},${Math.round(libY)}`;
                }
            }).catch(() => {
                if (els.status) els.status.textContent = 'Could not save panel positions';
            });
        });
        // Compact chrome only: toolbar visible, panels collapsed until ★ Tags
        setMetaPanelOpen(false);
        // Apply saved scale to dock shell (toolbar) without expanding panels
        {
            const dock = $('meta-dock');
            if (dock) dock.style.setProperty('--meta-ui-scale', String(uiScale));
            applyDockLayout({ scaleOnly: false });
            // Do NOT setLibrarySplit / open panels here — wait for Tags click
        }
        markPanelExplicitSize();
        // Dual-slot + proportional layout memory (resize / fullscreen / zoom)
        initLayoutMemoryWatch();
        // Seed current mode slot (panelOpen:false) without wiping last expanded coords
        rememberLayoutSlot();
        // Avoid immediately overwriting last expanded sizes with a compact snapshot:
        // only save open/closed flag; full geometry saves happen on drag/resize/close expand
        chrome.storage.local.set({ fafoMetaPanelOpen: false }).catch(() => {});
        try {
            chrome.storage.local.get(['fafoTagsPanelStartOpen']).then((res) => {
                if (res?.fafoTagsPanelStartOpen) setMetaPanelOpen(true);
            }).catch(() => {});
        } catch (_) {}
        markPanelExplicitSize();
        updateSkipTaggedBtn();
        updateApplyNextBtn();
        syncCountModeToggle();
        renderRecentTags();
        renderExtraTagHud();
        updateHiddenTagsButton();
        startExplorerPoll();
        updateBackupStatusUi();
        scheduleLiveStats();
        // Keep live tracker fresh while tagging
        setInterval(() => scheduleLiveStats(), 4000);
        $('meta-eset-apply')?.addEventListener('click', () => {
            applyExtraTagBank(extraLiveBank);
        });

        // Explorer status = Windows file Tags/Rating companion (not library permissions)
        document.addEventListener('click', (e) => {
            const btn = e.target.closest?.('.meta-explorer-status, #fafo-disk-pip');
            if (!btn) return;
            e.preventDefault();
            companionBootFails = 0;
            const reviewN = Number(ledgerStatsSafe().review) || 0;
            if (reviewN > 0 && explorerOnline) {
                openFailQueue();
                return;
            }
            syncExplorerNow({ showHelpIfOffline: !explorerOnline });
        });
        $('mls-fail-card')?.addEventListener('click', () => openFailQueue());
        $('meta-fail-queue-hide')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            closeFailQueue();
        });
        $('meta-fail-retry-all')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            retryAllReviewItems();
        });
        $('meta-explorer-sync')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            syncExplorerNow({ showHelpIfOffline: true });
        });
        $('meta-explorer-add-folder')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            pickDiskFolderViaCompanion();
        });
        $('meta-explorer-help-pick')?.addEventListener('click', () => {
            pickDiskFolderViaCompanion();
        });
        $('meta-explorer-help-retry')?.addEventListener('click', () => {
            syncExplorerNow({ showHelpIfOffline: true });
        });
        $('meta-explorer-help-close')?.addEventListener('click', () => {
            setExplorerHelpOpen(false);
        });
        refreshWatchedFolderHelp();

        document.addEventListener('click', (e) => {
            if (els.suggest && !els.suggest.contains(e.target) && e.target !== els.tagInput) {
                hideSuggestions();
            }
            // Don't close color menu when native color picker steals focus / clicks outside briefly
            if (ctxMenu && !ctxMenu.contains(e.target)) {
                const tag = e.target?.tagName;
                // color inputs open OS dialogs that can fire outside clicks
                if (tag === 'INPUT' || tag === 'SELECT' || tag === 'OPTION') return;
                hideCtxMenu();
            }
        });
        // Re-paint custom colors after theme pack changes so slots still override themes
        document.addEventListener('fafo:tag-theme', () => {
            try { globalThis.FAFOTagColors?.paintAll?.(document); } catch (_) {}
        });

        // Live bank switching for BOTH hotkeys and E-set (hold Shift / Ctrl / Alt)
        const onModKeys = (e) => {
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
            syncLiveBank(e);
            // E-set must track the same modifiers (was only wired from script.js keydown)
            syncExtraBankFromEvent(e);
        };
        document.addEventListener('keydown', onModKeys, true);
        document.addEventListener('keyup', onModKeys, true);
        window.addEventListener('blur', () => {
            liveBank = pinnedBank;
            renderHotkeyBar();
            updateBankIndicator();
            extraLiveBank = extraPinnedBank;
            renderExtraTagHud();
        });

        document.addEventListener('keydown', (e) => {
            const t = e.target;
            const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
            if (typing) return;

            // Tab / Shift+Tab: roll hotkey banks only when tags panel is open
            // (avoids stealing browser focus elsewhere)
            if (e.key === 'Tab' && metaPanelOpen) {
                const onChip = t?.closest?.('.meta-lib-tag, .meta-hotkey-slot, .meta-recent-tag, .meta-sprint-tag, .hud-eset-slot, .meta-tag-act, .meta-chip');
                if (onChip) return; // chip keyboard: Tab moves between chips
                e.preventDefault();
                cycleHotkeyBank(e.shiftKey ? -1 : 1);
                return;
            }

            // Keep live bank in sync even when we handle the key
            syncLiveBank(e);

            // Chord: ` / ~ then 1–9 / 0 applies hotkey (modifiers select bank)
            if (e.key === '`' || e.key === '~' || e.code === 'Backquote') {
                e.preventDefault();
                bracketChord = true;
                clearTimeout(bracketTimer);
                bracketTimer = setTimeout(() => { bracketChord = false; }, 2000);
                const bName = BANK_LABELS[liveBank] || 'Base';
                if (els.status) els.status.textContent = `Hotkey (${bName}): press 1–9 or 0…`;
                return;
            }

            const slot = digitToSlot(e.key);
            if (slot >= 0) {
                // Prefer held modifiers; otherwise use the pinned/Tab bank
                const modBank = bankFromEvent(e);
                const bank = modBank > 0 ? modBank : liveBank;

                // Keyboard: allow remove (second press toggles off) — intentional, not a miss-click
                const keyOpts = { allowRemove: true };
                // ` chord + digit → apply that bank/slot
                if (bracketChord) {
                    e.preventDefault();
                    bracketChord = false;
                    clearTimeout(bracketTimer);
                    applyHotkeyTag(bank, slot, keyOpts);
                    return;
                }

                // Modifier banks: hold Shift (etc.) + digit to apply without backtick
                if (modBank > 0) {
                    e.preventDefault();
                    applyHotkeyTag(modBank, slot, keyOpts);
                    return;
                }

                // Pinned bank (from Tab) is non-base: digits apply that bank without `
                if (liveBank > 0 && !metaPanelOpen) {
                    e.preventDefault();
                    applyHotkeyTag(liveBank, slot, keyOpts);
                    return;
                }
                // Panel open + base bank: 1–5 rate; 0 clears. Non-base + panel: still apply hotkey
                if (metaPanelOpen && liveBank > 0) {
                    e.preventDefault();
                    applyHotkeyTag(liveBank, slot, keyOpts);
                    return;
                }

                // Base bank without chord: 1–5 rate when panel open; 0 clears rating
                if (metaPanelOpen && !bracketChord) {
                    if (slot <= 4) {
                        setRating(slot + 1);
                        return;
                    }
                    if (e.key === '0') {
                        setRating(0);
                        return;
                    }
                }
            }

            if (e.key === 't' || e.key === 'T') {
                e.preventDefault();
                setMetaPanelOpen(!metaPanelOpen);
                if (metaPanelOpen) setTimeout(() => els.tagInput?.focus(), 40);
            }
        });

        renderMetaPanel();
        renderHotkeyBar();
        updateBankIndicator();
    }

    async function init() {
        try { await globalThis.FAFOTagColors?.load?.(); } catch (_) {}
        // Boot always public
        privateSpaceActive = false;
        await loadStore();
        try {
            if (globalThis.FAFOMetaLedger) {
                await FAFOMetaLedger.load('public');
                FAFOMetaLedger.harvest('public', mediaMeta);
                const pending = FAFOMetaLedger.pendingEntries('public');
                pending.forEach((row) => { if (row.key) dirtyDiskKeys.add(row.key); });
                if ((FAFOMetaLedger.stats('public').review || 0) > 0) {
                    setTimeout(() => openFailQueue(), 600);
                }
            }
            const bag = await chrome.storage.local.get('fafoDiskDirtyKeys');
            (bag.fafoDiskDirtyKeys || []).forEach((k) => { if (k) dirtyDiskKeys.add(k); });
        } catch (e) {
            console.warn('FAFO ledger boot', e);
        }
        // Guarantee public Tag DB vocabulary is in RAM (unused tags too)
        try {
            await hydrateTagVocabulary({ render: false });
        } catch (e) {
            console.warn('init tag hydrate', e);
        }
        try {
            const { fafoAutoDiskSync } = await chrome.storage.local.get('fafoAutoDiskSync');
            // Default ON — continuous Explorer writes when companion is running
            autoDiskSync = fafoAutoDiskSync !== false;
        } catch { autoDiskSync = true; }
        await loadLayoutPresetsStore();
        try {
            // Boot is always public — only load public sprint slots
            const sk = SPACE_STORAGE.public;
            const sp = await chrome.storage.local.get(['fafoSprintOpen', sk.sprintTags]);
            if (Array.isArray(sp[sk.sprintTags]) && sp[sk.sprintTags].length) {
                sprintTags = Array.from({ length: 5 }, (_, i) => normalizeTag(sp[sk.sprintTags][i] || ''));
            }
            if (sp.fafoSprintOpen) sprintModeOpen = true;
        } catch (_) {}
        wireUI();
        updateAutoSyncUi();
        if (sprintModeOpen) setSprintModeOpen(true);
        else renderSprintUi();
        // Paint tag list / recents / suggestions from hydrated vocab
        try { renderTagLibrary(); } catch (_) {}
        try { renderRecentTags(); } catch (_) {}
        try { renderHotkeyBar(); } catch (_) {}
        try { renderTagSuggestions(''); } catch (_) {}
        harvestTagsFromServer().catch(() => {});
        // Keep retrying dirty disk queue while tab is open
        setInterval(() => {
            if (autoDiskSync && dirtyDiskKeys.size) scheduleFlushDirtyDisk();
        }, 15000);
        setTimeout(() => {
            if (!autoDiskSync) return;
            toolboxOnline().then((on) => {
                if (!on || !globalThis.FAFOMetaLedger) return;
                const n = FAFOMetaLedger.stats('public').pending;
                if (n) {
                    FAFOMetaLedger.applyPending('public').catch(() => {});
                }
            }).catch(() => {});
        }, 2800);
        const item = window.FAFOPlayer?.getCurrentItem?.();
        if (item) await bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
        // Final paint after bind (library must stay populated)
        try { renderTagLibrary(); } catch (_) {}
        try { renderRecentTags(); } catch (_) {}
        // Pull chrome art backgrounds (Options-linked image folder)
        try { window.FAFOChromeArt?.apply?.(); } catch (_) {}
    }

    /** True when the current clip has no tags yet (rating alone does not count). */
    function isUntagged() {
        return !activeTags || activeTags.length === 0;
    }

    function notifyEndNeedsTag() {
        const dock = $('meta-dock');
        dock?.classList.add('untagged-prompt');
        setMetaPanelOpen(true);
        if (els.status) {
            els.status.textContent = skipTaggedMode
                ? 'Looping (skip tagged) — tag if needed, then press Next'
                : 'Untagged · looping — add tags, then press Next to continue';
        }
        if (els.toggle) els.toggle.title = 'Tag this media (T) · Next to leave clip';
    }

    function clearUntaggedPrompt() {
        $('meta-dock')?.classList.remove('untagged-prompt');
        if (els.toggle) els.toggle.title = 'Rate & tag this media (T)';
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
    }

    /** User-assigned E-set only. */
    function getUserExtraTag(bank, slot) {
        return extraTagBanks[bank]?.[slot] || '';
    }

    /** Effective E-set: user pick wins; else session auto-fill. */
    function getExtraTag(bank, slot) {
        const user = getUserExtraTag(bank, slot);
        if (user) return user;
        return sessionAutoExtra[bank]?.[slot] || '';
    }

    function isAutoExtra(bank, slot) {
        return !getUserExtraTag(bank, slot) && !!(sessionAutoExtra[bank]?.[slot]);
    }

    function setExtraTag(bank, slot, tag) {
        if (!extraTagBanks[bank]) extraTagBanks[bank] = Array(EXTRA_SLOTS).fill('');
        extraTagBanks[bank][slot] = normalizeTag(tag || '');
        // User owns this slot — drop auto underneath
        if (sessionAutoExtra[bank]) sessionAutoExtra[bank][slot] = '';
        if (!sessionAutoExtraPaused) refillSessionAutoExtra();
    }

    function setExtraLiveBank(bank) {
        extraLiveBank = Math.max(0, Math.min(EXTRA_BANKS - 1, bank | 0));
        renderExtraTagHud();
    }

    function getExtraLiveBank() {
        return extraLiveBank;
    }

    function syncExtraBankFromEvent(e) {
        let next = extraPinnedBank;
        if (e && (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey)) {
            next = bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
        } else if (!e) {
            next = extraPinnedBank;
        }
        if (next === extraLiveBank) return;
        extraLiveBank = next;
        renderExtraTagHud();
    }

    async function applyExtraTagBank(bank, opts) {
        bank = Math.max(0, Math.min(EXTRA_BANKS - 1, bank == null ? extraLiveBank : bank | 0));
        extraLiveBank = bank;
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active for E-set';
            setMetaPanelOpen(true);
            return { applied: 0 };
        }
        // Effective tags: user slots + session auto-fill (most frequent → first page)
        const row = Array.from({ length: EXTRA_SLOTS }, (_, s) => getExtraTag(bank, s));
        const menu = opts && opts.menu === 'hidden' ? 'hidden' : 'normal';
        const toApply = userTagsOnly(row.filter(Boolean)).filter((t) => isTagListedIn(t, menu));
        if (!toApply.length) {
            if (els.status) {
                const other = row.some(Boolean);
                els.status.textContent = other
                    ? `E-set ${EXTRA_BANK_LABELS[bank]}: nothing from this menu`
                    : `E-set ${EXTRA_BANK_LABELS[bank]} empty — Auto E-set or right-click slots to assign`;
            }
            renderExtraTagHud();
            return { applied: 0 };
        }
        const newly = [];
        toApply.forEach((t) => {
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            }
        });
        if (!newly.length) {
            if (els.status) {
                els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}: already on this clip (${toApply.length})`;
            }
            renderMetaPanel();
            renderExtraTagHud();
            return { applied: 0, already: toApply.length };
        }
        await persistActiveMeta({ touchedTags: newly });
        if (els.status) {
            els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]} applied +${newly.length}: ${newly.join(', ')}`;
        }
        renderExtraTagHud();
        return { applied: newly.length, tags: newly };
    }

    async function toggleExtraSlotTag(bank, slot, menu) {
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        const stored = getExtraTag(bank, slot);
        const tag = presetTagForMenu(stored, which);
        if (!stored) {
            if (els.status) els.status.textContent = `E-set slot ${slot + 1} empty — right-click to assign`;
            return;
        }
        if (!tag) {
            if (els.status) els.status.textContent = 'That E-set slot is in the other menu';
            return;
        }
        if (!activeKey) {
            setMetaPanelOpen(true);
            return;
        }
        await toggleLibraryTag(tag);
        renderExtraTagHud();
    }

    function showExtraSlotAssignMenu(e, bank, slot, menu) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const which = menu === 'hidden' ? 'hidden' : 'normal';
        const stored = getExtraTag(bank, slot);
        const current = presetTagForMenu(stored, which);
        const candidates = tagLibrary.filter((t) => isTagListedIn(t, which)).slice(0, 30);
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu meta-ctx-menu-wide';
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">E-set · ${escapeHtml(EXTRA_BANK_LABELS[bank])} · slot ${slot + 1}</div>
            <div class="meta-ctx-hint">${current ? 'Currently: ' + escapeHtml(current) : (stored ? 'Slot is in the other menu' : 'Empty — pick a tag (not hotkeys)')}</div>
            ${candidates.length
                ? candidates.map((t) => {
                    const on = current && current.toLowerCase() === t.toLowerCase();
                    return `<button type="button" data-eset-assign="${escapeAttr(t)}" class="${on ? 'on' : ''}">${escapeHtml(t)}</button>`;
                }).join('')
                : '<div class="meta-ctx-hint">No tags yet — add some in the Tags panel first</div>'}
            <div class="meta-ctx-hint" style="margin-top:6px">Or type a new tag:</div>
            <div style="display:flex;gap:4px;padding:4px">
                <input type="text" id="eset-custom-input" placeholder="new tag…" style="flex:1;min-width:0;background:#000;border:1px solid #333;color:#fff;border-radius:6px;padding:6px 8px;font-size:12px">
                <button type="button" data-eset-custom="1" class="meta-skip-btn">Set</button>
            </div>
            ${current ? '<button type="button" data-eset-clear="1" class="meta-ctx-clear">Clear slot</button>' : ''}
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 260);
        const y = Math.min(e.clientY, window.innerHeight - 360);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        ctxMenu.querySelectorAll('[data-eset-assign]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                setExtraTag(bank, slot, btn.dataset.esetAssign);
                await saveStore();
                hideCtxMenu();
                renderExtraTagHud();
                if (els.status) els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}[${slot + 1}] = ${btn.dataset.esetAssign}`;
            });
        });
        const customSet = async () => {
            const inp = ctxMenu.querySelector('#eset-custom-input');
            const t = normalizeTag(inp?.value || '');
            if (!t) return;
            setExtraTag(bank, slot, t);
            ensureTagsKnown([t]);
            await saveStore();
            hideCtxMenu();
            renderExtraTagHud();
        };
        ctxMenu.querySelector('[data-eset-custom]')?.addEventListener('click', customSet);
        ctxMenu.querySelector('#eset-custom-input')?.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') { ev.preventDefault(); customSet(); }
        });
        ctxMenu.querySelector('[data-eset-clear]')?.addEventListener('click', async () => {
            setExtraTag(bank, slot, '');
            await saveStore();
            hideCtxMenu();
            renderExtraTagHud();
        });
        setTimeout(() => ctxMenu.querySelector('#eset-custom-input')?.focus(), 30);
    }

    function renderExtraTagHud() {
        // Prefer Tags-panel hosts; fall back to any leftover HUD nodes
        const banksEl = $('meta-eset-banks') || $('hud-eset-banks');
        const slotsEl = $('meta-eset-slots') || $('hud-eset-slots');
        if (banksEl) {
            banksEl.innerHTML = EXTRA_BANK_LABELS.map((name, b) =>
                `<button type="button" class="hud-eset-bank ${b === extraLiveBank ? 'active' : ''}" data-eset-bank="${b}">${escapeHtml(name)}</button>`
            ).join('');
            banksEl.querySelectorAll('[data-eset-bank]').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    extraPinnedBank = parseInt(btn.dataset.esetBank, 10);
                    extraLiveBank = extraPinnedBank;
                    renderExtraTagHud();
                });
            });
        }
        const paintExtraSlots = (host, menu) => {
            if (!host) return;
            const which = menu === 'hidden' ? 'hidden' : 'normal';
            const bank = extraLiveBank;
            host.innerHTML = Array.from({ length: EXTRA_SLOTS }, (_, s) => {
                const stored = getExtraTag(bank, s);
                const t = presetTagForMenu(stored, which);
                const on = t && isTagOnVideo(t);
                const auto = isAutoExtra(bank, s);
                const last = t && isLastVideoTag(t);
                const filtered = t && !matchesLiveTypeFilter(t);
                const cls = [
                    'hud-eset-slot',
                    t ? 'set' : '',
                    on ? 'on-video' : '',
                    auto ? 'auto-fill' : '',
                    last ? 'last-video' : '',
                    filtered ? 'type-filtered-out' : '',
                ].filter(Boolean).join(' ');
                const title = t
                    ? `${t}${auto ? ' · auto' : ' · user'}${last ? ' · last video' : ''} · click toggle · right-click · drag`
                    : (stored ? 'In the other menu' : 'Drop ONE tag here · right-click to assign · Auto E-set fills by frequency');
                return `<button type="button" class="${cls}" data-eset-slot="${s}" data-tag="${escapeAttr(t || '')}" data-auto="${auto ? '1' : '0'}" title="${escapeAttr(title)}">
                    <span class="eset-n">${s === 9 ? '0' : s + 1}${auto ? '·A' : ''}</span>${t ? escapeHtml(t) : '—'}
                </button>`;
            }).join('');
            host.querySelectorAll('[data-eset-slot]').forEach((btn) => {
                const s = parseInt(btn.dataset.esetSlot, 10);
                const tag = presetTagForMenu(getExtraTag(bank, s), which);
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (tagDragMoved) return;
                    toggleExtraSlotTag(extraLiveBank, s, which);
                });
                btn.addEventListener('contextmenu', (e) => showExtraSlotAssignMenu(e, extraLiveBank, s, which));
                if (tag) markTagDragSource(btn, { kind: 'eset', tag, bank, slot: s });
            });
        };
        paintExtraSlots(slotsEl, 'normal');
        if (hiddenPanelOpen()) paintExtraSlots($('meta-hidden-eset'), 'hidden');
        let filled = 0;
        for (let s = 0; s < EXTRA_SLOTS; s++) {
            if (presetTagForMenu(getExtraTag(extraLiveBank, s), 'normal')) filled++;
        }
        const label = filled ? `E-set · ${filled}` : 'E-set';
        const title = `Apply E-set “${EXTRA_BANK_LABELS[extraLiveBank]}” (${filled}/10) · auto + user · key E + modifiers`;
        ['meta-eset-apply', 'hud-extra-apply', 'hud-eset-apply'].forEach((id) => {
            const applyBtn = $(id);
            if (!applyBtn) return;
            applyBtn.textContent = id === 'meta-eset-apply' ? (filled ? `Apply bank (${filled})` : 'Apply bank') : label;
            applyBtn.title = title;
        });
        updateExtraAutoUi();
    }

    window.FAFOMeta = {
        init,
        bindToItem,
        restoreMetaSnapshot,
        toggleLibraryTag,
        removeLibraryTagSafe,
        undoLast: () => globalThis.FAFOUndo?.undo?.(),
        getSelectedTags,
        clearTagSelection,
        setMultiSelectMode,
        selectAllVisibleTags,
        getRecentTags: () => (Array.isArray(recentTags) ? recentTags.filter((t) => isTagListedIn(t, 'normal')) : []),
        getTagLibraryForMenu: (menu) => tagLibrary.filter((t) => isTagListedIn(t, menu === 'hidden' ? 'hidden' : 'normal')),
        setMetaPanelOpen,
        open: () => setMetaPanelOpen(true),
        ensureTagsKnown,
        getTagLibrary: () => tagLibrary.slice(),
        persistTagDb,
        loadTagDbIntoMemory,
        hydrateTagVocabulary,
        getTagDbKey: () => tagDbStorageKey(),
        getSessionTagCounts: () => ({ ...sessionTagCount }),
        getLibraryTagCounts: () => ({ ...libraryTagCount }),
        isSessionCountMode: () => countDisplayMode === 'session',
        getCountDisplayMode: () => countDisplayMode,
        setCountDisplayMode,
        isUntagged,
        /** @deprecated alias */
        needsTagging: isUntagged,
        notifyEndNeedsTag,
        clearUntaggedPrompt,
        getActiveTags: () => activeTags.filter((t) => isTagInCurrentSpace(t)),
        isTagOnVideo,
        isTagSelected,
        syncAllTagUiState,
        getActiveRating: () => activeRating,
        isSkipTaggedMode,
        setSkipTaggedMode,
        isSprintMode,
        getSprintTags,
        sprintScoreForItem,
        clipHasAnySprintTag,
        focusTagInput,
        setLiveTypeFilter,
        getLiveStats: () => computeLiveStats(),
        refreshLiveStats: () => scheduleLiveStats(),
        tagCountForItem,
        rebuildApplyCountsFromLibrary,
        rebuildMediaMetaFromDisk,
        applyExtraTagBank,
        setExtraLiveBank,
        getExtraLiveBank,
        syncExtraBankFromEvent,
        renderExtraTagHud,
        getExtraTagBanks: () => extraTagBanks.map((r) => r.slice()),
        undockTagsForMove,
        pinDockForStage,
        resetLayout,
        setUiScale,
        purgeTagEverywhere,
        renameTagEverywhere,
        removeTagFromCurrentFile,
        removeTagFromVocabulary,
        downloadSettingsText,
        importSettingsFromFile,
        buildSettingsText,
        tryLoadSettingsFile,
        refillSessionAutoHotkeys,
        getUiScale: () => uiScale,
        cycleUiScale,
        reclampAllChromeAfterScale,
        refreshLoopMode: () => {
            try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        },
        // Private multi-vault section
        isPrivateSpaceActive: () => !!privateSpaceActive,
        isPrivateUnlocked: () => !!privateUnlocked,
        getActiveVaultId: () => (privateSpaceActive || privateUnlocked ? currentVaultId() : null),
        getActiveVaultName: () => activeVaultName || '',
        /** Active chrome.storage key map for the current section (public vs active vault). */
        getSpaceStorageKeys: () => ({ ...spaceKeys() }),
        isMediaInCurrentSpace,
        isTagInCurrentSpace,
        isPrivateTag,
        isPrivateMediaKey,
        moveMediaToPrivate,
        moveMediaToPublic,
        lockPrivateSpace,
        enterPublicSpace,
        enterPrivateSpace,
        showPrivateUnlockModal,
        linkPrivateLibraryFolder,
        exitPrivateToNormal,
        persistPrivateSessionFlag,
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => init());
    } else {
        // Player may still be initializing — retry bind shortly
        init().then(() => {
            setTimeout(() => {
                const item = window.FAFOPlayer?.getCurrentItem?.();
                if (item) bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
            }, 800);
        });
    }
})();
