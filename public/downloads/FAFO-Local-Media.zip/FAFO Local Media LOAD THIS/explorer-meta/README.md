# FAFO Explorer Metadata Server

Companion for **FAFO Ultimate Tab**. Writes **Tags** and **star Ratings** into real video files so Windows Explorer and other apps can see them.

## Quick start

1. Double-click **`INSTALL_DEPS.bat`** (once per PC)  
2. Double-click **`START_META_SERVER.bat`** (leave open while using FAFO)  
3. Register your video folders with **`ADD_VIDEO_FOLDER.bat`** (bundled `..\Videos` is auto-indexed)  
4. In FAFO: open new tab → **★ Tags** / press **`T`** → rate & tag while watching  

Full guide (parent folder): **[TAGS_AND_RATINGS.md](../TAGS_AND_RATINGS.md)**

## Dependencies (`requirements.txt`)

| Package | Why |
|---------|-----|
| **pywin32** | Windows `System.Keywords` + `System.Rating` (what Explorer shows) |
| fastapi + uvicorn | Local HTTP API on `127.0.0.1:8765` |
| mutagen | MP4 embedded tags for other players |
| pydantic | Request models |
| Pillow | Optional image test / helpers |

Install manually:

```bat
python -m pip install -r requirements.txt
```

## API (for tools / debugging)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Server up? |
| POST | `/api/fs/write-metadata` | Body: `{name,size,mtime,tags,rating}` or `{path,tags,rating}` |
| GET | `/api/fs/read-metadata?path=` | Read tags/rating from a file |
| POST | `/api/library/add-folder` | Body: `{path}` — index a folder |
| POST | `/api/library/rescan` | Rebuild index |
| GET | `/api/library` | Index stats |

## Port

Default: **8765** (same as AI HTML TOOLBOX). Run only one server on that port.
