#!/usr/bin/env python3
"""Chrome/Edge native messaging host — boots FAFO companion stack fast."""
from __future__ import annotations

import json
import os
import struct
import sys
import threading

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import stack  # noqa: E402


def read_msg():
    raw = sys.stdin.buffer.read(4)
    if len(raw) < 4:
        return None
    n = struct.unpack("<I", raw)[0]
    body = sys.stdin.buffer.read(n)
    return json.loads(body.decode("utf-8") if body else "{}")


def write_msg(obj) -> None:
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    sys.stdout.buffer.write(struct.pack("<I", len(data)))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def main() -> int:
    msg = read_msg() or {}
    op = str(msg.get("op") or "boot").lower()
    try:
        delay = float(msg.get("delay") if msg.get("delay") is not None else 0.3)
    except (TypeError, ValueError):
        delay = 0.3
    try:
        if op in ("boot", "apply", "start", "server"):
            stack.note_s2_demand("native-boot")
            up = stack.health()
            if not up:
                stack.start_server()
                up = stack.wait_health(timeout=14.0)
            if up:
                # Ledger must not block Chrome's native-messaging roundtrip.
                threading.Thread(target=stack.apply_ledger, daemon=True).start()
            write_msg({"ok": bool(up), "op": op, "healthy": bool(up), "delay": delay})
        elif op == "health":
            write_msg({"ok": True, "healthy": stack.health()})
        else:
            write_msg({"ok": False, "error": f"unknown op {op}"})
        return 0
    except Exception as e:
        try:
            write_msg({"ok": False, "error": str(e)})
        except Exception:
            pass
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
