"""CLI: register a video folder with the running FAFO metadata server."""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: python add_folder.py <absolute-folder-path>")
        return 1
    path = sys.argv[1].strip().strip('"')
    data = json.dumps({"path": path}).encode("utf-8")
    req = urllib.request.Request(
        "http://127.0.0.1:8765/api/library/add-folder",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            body = json.loads(r.read().decode("utf-8"))
        print(json.dumps(body, indent=2))
        print("\nFolder registered. FAFO can now write Explorer tags/ratings for files inside it.")
        return 0
    except urllib.error.URLError as e:
        print("ERROR: Could not reach the metadata server.")
        print("  Start it first:  START_META_SERVER.bat")
        print("  Detail:", e)
        return 1
    except Exception as e:
        print("ERROR:", e)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
