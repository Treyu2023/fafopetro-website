/**
 * FAFO on-play tags & star ratings (+ optional Explorer write via localhost:8765)
 * Tag list order: library frequency seed → after first apply this session, session counts win.
 * Loaded after script.js core; hooks into window.FAFOPlayer hooks when available.
 */
(function () {
    'use strict';

    const TOOLBOX_API = 'http://127.0.0.1:8765/api';

    let mediaMeta = {};
    let tagLibrary = [];       // display names; ordered by count (see sortTagLibrary)
    let tagLastUsed = {};      // kept for compat / secondary tie-break only
    let libraryTagCount = {};  // lower(tag) -> how many library files have this tag (seed)
    /** lower(tag) -> times applied (persisted across reloads; was session-only). */
    let sessionTagCount = {};
    let sessionHasPicks = false; // true once any apply count exists (drives session sort)
    /** 'session' | 'total' — sort + primary ranking; apply-count badges always on tiles */
    let countDisplayMode = 'session';
    let countSaveTimer = null;
    let libraryRecountTimer = null;
    let renderLibraryTimer = null;
    /** When true, applying a tag immediately advances to next (bulk tagging). */
    let applyAndNextMode = false;
    let recentTags = []; // last applied tag names (display order)
    let explorerOnline = null; // null=unknown, true/false
    let explorerPollTimer = null;
    /**
     * Hotkey matrix: 10 always-visible slots (keys 1–9, 0) × 4 modifier banks.
     * Banks: 0=base, 1=Shift, 2=Shift+Ctrl, 3=Shift+Ctrl+Alt  → 40 assignable tags.
     * Holding modifiers swaps the 10 on-screen buttons in real time.
     */
    const HOTKEY_SLOTS = 10;
    const HOTKEY_BANKS = 4;
    const BANK_LABELS = ['Base', 'Shift', 'Ctrl', 'Alt'];
    const BANK_SHORT = ['', '⇧', '⌃', '⌥'];
    let tagHotkeys = emptyHotkeyBanks(); // [bank][slot] string
    let liveBank = 0; // currently displayed bank
    /** Sticky bank selected via Tab / bank chips; modifiers temporarily override. */
    let pinnedBank = 0;
    let activeKey = null;
    let activeName = '';
    let activeTags = [];
    let activeRating = 0;
    let suggestIndex = -1;
    let metaPanelOpen = false;
    let bracketChord = false;
    let bracketTimer = null;
    let ctxMenu = null;
    let els = {};
    /** When true, player skips clips that already have tags (then 5+ tags). */
    let skipTaggedMode = false;
    let tagLibraryHeight = 160;
    let panelWidth = 0;
    let panelHeight = 0;
    let resizeDragging = false;
    /** User-hidden tags (still stored on files if already applied; hidden from quick panel lists). */
    let excludedTags = [];
    /** Selected tag for Delete-key remove (confirm). */
    let selectedTag = '';
    /** Pair id for current clip (separate field — not a chip). */
    let activePairId = '';
    /** Quick panel (rating + selection) docks on the RIGHT by default. */
    let dockPos = 'br';
    let dockX = 18;
    let dockY = 18;
    /** Tag history floating panel position/size (sticky when free). */
    let libX = 18;
    let libY = 80;
    let libW = 360;
    let libH = 520;
    let libPosSaved = false; // true once user moved/resized history panel
    /** When true, free positions never auto-snap (scale/open/sync won't move them). */
    let stickLayout = true;
    /**
     * E-set: separate from hotkey quick tags.
     * 10 slots × 4 modifier banks (Base / Shift / Ctrl+Shift / Alt+Ctrl+Shift).
     * Press E (with modifiers) to apply the whole bank to the current clip.
     */
    const EXTRA_SLOTS = 10;
    const EXTRA_BANKS = 4;
    const EXTRA_BANK_LABELS = ['Base', '⇧ Shift', '⌃ Ctrl', '⌥ Alt'];
    let extraTagBanks = emptyExtraBanks();
    let extraLiveBank = 0;
    let extraPinnedBank = 0;
    /** UI scale for tags panel density */
    const UI_SCALES = [0.9, 1, 1.15, 1.3];
    let uiScale = 1;
    let dockDragging = false;
    let dockDragOffX = 0;
    let dockDragOffY = 0;
    let layoutSaveTimer = null;

    function emptyHotkeyBanks() {
        return Array.from({ length: HOTKEY_BANKS }, () => Array(HOTKEY_SLOTS).fill(''));
    }

    function emptyExtraBanks() {
        return Array.from({ length: EXTRA_BANKS }, () => Array(EXTRA_SLOTS).fill(''));
    }

    function normalizeExtraBanks(raw) {
        const banks = emptyExtraBanks();
        if (!raw) return banks;
        if (Array.isArray(raw) && raw.length && Array.isArray(raw[0])) {
            for (let b = 0; b < EXTRA_BANKS; b++) {
                const row = raw[b];
                if (!Array.isArray(row)) continue;
                for (let s = 0; s < EXTRA_SLOTS; s++) {
                    banks[b][s] = normalizeTag(row[s] || '');
                }
            }
            return banks;
        }
        // Flat list of up to 10 (legacy / single bank)
        if (Array.isArray(raw) && (raw.length === 0 || typeof raw[0] === 'string')) {
            for (let s = 0; s < Math.min(EXTRA_SLOTS, raw.length); s++) {
                banks[0][s] = normalizeTag(raw[s] || '');
            }
            return banks;
        }
        return banks;
    }

    /** Migrate old 5-slot arrays into the new bank matrix. */
    function normalizeHotkeyBanks(raw) {
        const banks = emptyHotkeyBanks();
        if (!raw) return banks;
        // Nested banks: [4][10] or [4][5+]
        if (Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0])) {
            for (let b = 0; b < HOTKEY_BANKS; b++) {
                const row = raw[b];
                if (!Array.isArray(row)) continue;
                for (let s = 0; s < HOTKEY_SLOTS; s++) {
                    banks[b][s] = normalizeTag(row[s] || '');
                }
            }
            return banks;
        }
        // Flat list of strings (legacy 5, or 10, or 40)
        if (Array.isArray(raw) && (raw.length === 0 || typeof raw[0] === 'string')) {
            if (raw.length >= HOTKEY_BANKS * HOTKEY_SLOTS) {
                for (let b = 0; b < HOTKEY_BANKS; b++) {
                    for (let s = 0; s < HOTKEY_SLOTS; s++) {
                        banks[b][s] = normalizeTag(raw[b * HOTKEY_SLOTS + s] || '');
                    }
                }
            } else {
                // Legacy base bank only (first 5 or 10)
                for (let s = 0; s < Math.min(HOTKEY_SLOTS, raw.length); s++) {
                    banks[0][s] = normalizeTag(raw[s] || '');
                }
            }
            return banks;
        }
        return banks;
    }

    /**
     * Modifier → bank (hotkeys + E-set share this).
     * Priority: Alt → bank 3, Ctrl → bank 2, Shift → bank 1, none → base.
     * (Ctrl/Alt alone work; Shift is not required to reach banks 2–3.)
     */
    function bankFromMods(shift, ctrl, alt) {
        if (alt) return 3;
        if (ctrl) return 2;
        if (shift) return 1;
        return 0;
    }

    function bankFromEvent(e) {
        return bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
    }

    function digitToSlot(key) {
        if (key === '0') return 9;
        if (key >= '1' && key <= '9') return parseInt(key, 10) - 1;
        return -1;
    }

    function slotToDigit(slot) {
        return slot === 9 ? '0' : String(slot + 1);
    }

    function formatHotkeyLabel(bank, slot) {
        return `${BANK_SHORT[bank] || ''}${slotToDigit(slot)}`;
    }

    function getHotkey(bank, slot) {
        return tagHotkeys[bank]?.[slot] || '';
    }

    function setHotkey(bank, slot, tag) {
        if (!tagHotkeys[bank]) tagHotkeys[bank] = Array(HOTKEY_SLOTS).fill('');
        tagHotkeys[bank][slot] = normalizeTag(tag || '');
    }

    function clearTagFromAllHotkeys(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return;
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    tagHotkeys[b][s] = '';
                }
            }
        }
    }

    function anyHotkeyAssigned() {
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s]) return true;
            }
        }
        return false;
    }

    function syncLiveBank(e) {
        // Held modifiers temporarily override the pinned bank; otherwise use pin
        let bank = pinnedBank;
        if (e && (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey)) {
            bank = bankFromEvent(e);
        }
        if (bank === liveBank) return;
        liveBank = bank;
        renderHotkeyBar();
        updateBankIndicator();
    }

    /** Tab cycles Base → Shift → Shift+Ctrl → Shift+Ctrl+Alt → Base … */
    function cycleHotkeyBank(dir = 1) {
        pinnedBank = (pinnedBank + dir + HOTKEY_BANKS) % HOTKEY_BANKS;
        liveBank = pinnedBank;
        renderHotkeyBar();
        updateBankIndicator();
        if (els.status) {
            els.status.textContent = `Hotkey bank: ${BANK_LABELS[pinnedBank]} (Tab to cycle)`;
        }
    }

    function $(id) { return document.getElementById(id); }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function escapeAttr(s) { return escapeHtml(s).replace(/'/g, '&#39;'); }

    /** Hard cap for real tags. Never truncate dumps into keepable tags. */
    const TAG_MAX_CHARS = 100;
    const TAG_DISPLAY_CHARS = 36;
    const TAG_LIBRARY_RENDER_MAX = 60;

    function normalizeTag(t) {
        if (globalThis.FAFOId?.normalizeTag) return FAFOId.normalizeTag(t);
        return String(t || '')
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[\u0000-\u001f\u007f]/g, '');
    }

    /** Short label for chips / library only (never blows up the panel). */
    function displayTag(t) {
        const s = String(t || '');
        if (s.length <= TAG_DISPLAY_CHARS) return s;
        return s.slice(0, TAG_DISPLAY_CHARS - 1) + '...';
    }

    function isOversizedOrSuspectTag(t) {
        if (globalThis.FAFOId?.isOversizedOrSuspectTag) {
            return FAFOId.isOversizedOrSuspectTag(t);
        }
        const s = String(t || '').trim();
        if (!s) return true;
        if (s.length >= TAG_MAX_CHARS) return true;
        // Windows / AI signature blobs + base64 watermarks
        if (/^signature\s*:/i.test(s) || /^sig\s*:/i.test(s)) return true;
        if (s.length >= 48 && /^[A-Za-z0-9+/_=-]{48,}$/.test(s.replace(/\s/g, ''))) return true;
        // ComfyUI / workflow JSON dumped into MP4 comments
        if (/widgets_values|class_type|comfyui|cliptextencode|ksampler|checkpointloader|cnr_id|frontendVersion/i.test(s)) return true;
        if (/^[\[{]/.test(s) && s.length > 20) return true;
        if (/^[A-Za-z]:[\\/]/.test(s)) return true;
        if (/^\\\\[^\\]/.test(s)) return true;
        if (s.includes('\\\\') && s.length > 40) return true;
        if ((s.match(/[;|{}[\]]/g) || []).length >= 4 && s.length > 40) return true;
        if ((s.match(/[,;]/g) || []).length >= 3 && s.length > 36) return true;
        if (/System\.(Keywords|Rating|Media|Photo|Item|Prop)/i.test(s)) return true;
        if (/\{[^{}]{20,}\}/.test(s)) return true;
        if (/=/.test(s) && s.length > 40 && /[;,]/.test(s)) return true;
        if (/[\t\r\n]/.test(String(t || ''))) return true;
        return false;
    }

    /** List UI only: pair/role always hidden + user exclude list + junk dumps. */
    function isHiddenFromUi(tag) {
        if (isOversizedOrSuspectTag(tag)) return true;
        if (globalThis.FAFOId?.isHiddenTag) return FAFOId.isHiddenTag(tag, excludedTags);
        return false;
    }

    /**
     * Storage / file tags: strip pair IDs, role stamps, and corrupt dumps.
     * User exclusions do NOT remove tags from files or from the current clip.
     */
    function userTagsOnly(tags) {
        const base = globalThis.FAFOId?.userTagsOnly
            ? FAFOId.userTagsOnly(tags)
            : (Array.isArray(tags) ? tags : [])
                .map(normalizeTag)
                .filter((t) => t && !(globalThis.FAFOId?.isSystemOrPairTag?.(t)));
        return base.filter((t) => t && !isOversizedOrSuspectTag(t));
    }

    /** Drop pair/role + corrupt junk from the vocabulary array. */
    function scrubTagLibrary() {
        tagLibrary = tagLibrary.filter((t) => {
            if (isOversizedOrSuspectTag(t)) return false;
            if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) return false;
            return !!normalizeTag(t);
        });
    }

    /**
     * Nuclear clean: strip junk from every file record + vocabulary.
     */
    function scrubCorruptTagsEverywhere() {
        let dropped = 0;
        let files = 0;
        scrubTagLibrary();
        for (const key of Object.keys(mediaMeta || {})) {
            const m = mediaMeta[key];
            if (!m || !Array.isArray(m.tags)) continue;
            const next = userTagsOnly(m.tags);
            if (next.length !== m.tags.length) {
                dropped += m.tags.length - next.length;
                m.tags = next;
                m.updated = Date.now();
                m.diskSyncedAt = 0;
                files++;
            }
        }
        activeTags = userTagsOnly(activeTags);
        rebuildLibraryTagCounts();
        return { dropped, files, library: tagLibrary.length };
    }


    /**
     * Hide a tag from the library list after sync.
     * Does not delete it from files or from this clip's tags.
     */
    async function persistExcludedTags() {
        // Dedicated key + full store so hides survive reloads / backups
        const list = excludedTags.map(normalizeTag).filter(Boolean);
        excludedTags = list;
        try {
            await chrome.storage.local.set({ fafoTagExcluded: list });
        } catch (e) {
            console.warn('fafoTagExcluded save failed', e);
        }
        // Also fold into main save payload
        try {
            await saveStore();
        } catch (_) {}
        updateHiddenTagsButton();
    }

    async function excludeTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(t)) {
            if (els.status) els.status.textContent = 'Pair/system tags are always hidden from the list';
            return;
        }
        if (!excludedTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
            excludedTags.push(t);
        }
        await persistExcludedTags();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) {
            els.status.textContent = `Hidden from list: ${t} (saved · open Hidden to restore)`;
        }
    }

    async function unexcludeTag(tag) {
        const t = normalizeTag(tag);
        const low = t.toLowerCase();
        excludedTags = excludedTags.filter((x) => x.toLowerCase() !== low);
        ensureTagsKnown([t]);
        await persistExcludedTags();
        sortTagLibrary();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) els.status.textContent = `Restored to list: ${t}`;
    }

    async function unexcludeAllTags() {
        if (!excludedTags.length) return;
        const n = excludedTags.length;
        const restored = excludedTags.slice();
        excludedTags = [];
        ensureTagsKnown(restored);
        await persistExcludedTags();
        sortTagLibrary();
        renderTagLibrary();
        renderTagSuggestions(els.tagInput?.value || '');
        renderHotkeyBar();
        renderHiddenTagsPanel();
        if (els.status) els.status.textContent = `Restored ${n} hidden tag(s) to the list`;
    }

    function updateHiddenTagsButton() {
        const btn = $('meta-hidden-tags-btn');
        if (!btn) return;
        const n = excludedTags.length;
        btn.textContent = n ? `Hidden · ${n}` : 'Hidden · 0';
        btn.classList.toggle('has-hidden', n > 0);
        btn.title = n
            ? `${n} tag(s) hidden from the list · click to view / restore`
            : 'No hidden tags · right-click a tag → Hide from list';
    }

    function setHiddenPanelOpen(open) {
        const panel = $('meta-hidden-panel');
        if (!panel) return;
        panel.classList.toggle('hidden', !open);
        if (open) renderHiddenTagsPanel();
    }

    function renderHiddenTagsPanel() {
        updateHiddenTagsButton();
        const list = $('meta-hidden-list');
        if (!list) return;
        if (!excludedTags.length) {
            list.innerHTML = '<div class="meta-hidden-empty">Nothing hidden — right-click any tag → Hide from list</div>';
            return;
        }
        const sorted = excludedTags.slice().sort((a, b) =>
            a.localeCompare(b, undefined, { sensitivity: 'base' })
        );
        list.innerHTML = sorted.map((t) =>
            `<button type="button" class="meta-hidden-chip" data-restore-tag="${escapeAttr(t)}" title="Click to show “${escapeAttr(t)}” in the list again">${escapeHtml(t)} · restore</button>`
        ).join('');
        list.querySelectorAll('[data-restore-tag]').forEach((btn) => {
            btn.addEventListener('click', () => unexcludeTag(btn.dataset.restoreTag));
        });
    }

    /** Count tags across saved media (library frequency seed). */
    function rebuildLibraryTagCounts() {
        libraryTagCount = {};
        Object.values(mediaMeta || {}).forEach((m) => {
            userTagsOnly(m.tags || []).forEach((raw) => {
                const tag = normalizeTag(raw);
                if (!tag) return;
                const low = tag.toLowerCase();
                libraryTagCount[low] = (libraryTagCount[low] || 0) + 1;
            });
        });
    }

    /** Debounce expensive recount + re-render for large libraries. */
    function scheduleLibraryRecount(render = true) {
        clearTimeout(libraryRecountTimer);
        libraryRecountTimer = setTimeout(() => {
            rebuildLibraryTagCounts();
            sortTagLibrary();
            if (render) scheduleRenderTagLibrary();
        }, 80);
    }

    function scheduleRenderTagLibrary() {
        clearTimeout(renderLibraryTimer);
        renderLibraryTimer = setTimeout(() => renderTagLibrary(), 40);
    }

    /**
     * Rebuild apply (Uses) counts from library file tags.
     * Sets Uses# = number of files that currently have each tag.
     */
    async function rebuildApplyCountsFromLibrary() {
        const next = {};
        Object.values(mediaMeta || {}).forEach((m) => {
            (m.tags || []).forEach((raw) => {
                const t = normalizeTag(raw);
                if (!t) return;
                const low = t.toLowerCase();
                next[low] = (next[low] || 0) + 1;
                ensureTagsKnown([t]);
            });
        });
        sessionTagCount = next;
        recomputeSessionHasPicks();
        rebuildLibraryTagCounts();
        sortTagLibrary();
        await saveStore();
        renderTagLibrary();
        renderHotkeyBar();
        if (els.status) {
            const n = Object.keys(sessionTagCount).length;
            els.status.textContent = `Rebuilt Uses counts from library (${n} tags)`;
        }
    }

    function sessionCountFor(tag) {
        return sessionTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function libraryCountFor(tag) {
        return libraryTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function isTagOnVideo(tag) {
        const low = normalizeTag(tag).toLowerCase();
        return activeTags.some((x) => x.toLowerCase() === low);
    }

    function recomputeSessionHasPicks() {
        sessionHasPicks = Object.values(sessionTagCount).some((n) => n > 0);
    }

    /** Primary sort key from toggle: apply counts (persisted) or library total. */
    function displayCountFor(tag) {
        if (countDisplayMode === 'total') return libraryCountFor(tag);
        if (sessionHasPicks) return sessionCountFor(tag);
        return libraryCountFor(tag); // seed until first apply
    }

    /**
     * Sort tag list by Uses (persisted apply counts) or Total (library frequency).
     */
    function sortTagLibrary() {
        tagLibrary.sort((a, b) => {
            const la = a.toLowerCase();
            const lb = b.toLowerCase();
            if (countDisplayMode === 'session' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ca = libraryTagCount[la] || 0;
            const cb = libraryTagCount[lb] || 0;
            if (cb !== ca) return cb - ca;
            if (countDisplayMode === 'total' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ta = tagLastUsed[la] || 0;
            const tb = tagLastUsed[lb] || 0;
            if (tb !== ta) return tb - ta;
            return a.localeCompare(b, undefined, { sensitivity: 'base' });
        });
    }

    function syncCountModeToggle() {
        const btn = $('meta-count-mode');
        if (!btn) return;
        const isTotal = countDisplayMode === 'total';
        btn.classList.toggle('active', isTotal);
        btn.dataset.mode = countDisplayMode;
        btn.textContent = isTotal ? 'Σ Totals' : 'Uses #';
        btn.title = isTotal
            ? 'Sort by library totals (files with tag) · click for apply counts (saved)'
            : 'Sort by apply counts (saved across reloads) · click for library totals';
    }

    function setCountDisplayMode(mode) {
        countDisplayMode = mode === 'total' ? 'total' : 'session';
        syncCountModeToggle();
        sortTagLibrary();
        renderTagLibrary();
        renderHotkeyBar();
        // Persist preferred sort mode
        chrome.storage.local.set({ fafoTagCountMode: countDisplayMode }).catch(() => {});
    }

    /** Debounced write of apply counts + last-used (cheap path between full saves). */
    function scheduleCountSave() {
        clearTimeout(countSaveTimer);
        countSaveTimer = setTimeout(() => {
            chrome.storage.local.set({
                fafoTagApplyCounts: sessionTagCount,
                fafoTagLastUsed: tagLastUsed,
                fafoTagLibrary: tagLibrary,
            }).catch(() => {});
        }, 200);
    }

    /**
     * Bump persisted apply counters when the user tags a clip.
     * Counts survive extension reloads / new tabs.
     */
    function pushRecentTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        const low = t.toLowerCase();
        recentTags = [t, ...recentTags.filter((x) => x.toLowerCase() !== low)].slice(0, 12);
        chrome.storage.local.set({ fafoRecentTags: recentTags }).catch(() => {});
        renderRecentTags();
    }

    function touchTags(tags, when = Date.now()) {
        const list = Array.isArray(tags) ? tags : [tags];
        let any = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            sessionHasPicks = true;
            sessionTagCount[low] = (sessionTagCount[low] || 0) + 1;
            tagLastUsed[low] = when;
            const existing = tagLibrary.find((x) => x.toLowerCase() === low);
            if (!existing) tagLibrary.push(t);
            pushRecentTag(t);
            any = true;
        });
        if (any) {
            sortTagLibrary();
            scheduleCountSave();
        }
    }

    /**
     * Decrement apply counters when the user removes a tag from a clip.
     * Never goes below 0; zeros are dropped from the map.
     * Library (file) totals are handled separately via rebuildLibraryTagCounts().
     */
    function untouchTags(tags) {
        const list = Array.isArray(tags) ? tags : [tags];
        let any = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            const cur = sessionTagCount[low] || 0;
            if (cur <= 0) return;
            const next = cur - 1;
            if (next <= 0) delete sessionTagCount[low];
            else sessionTagCount[low] = next;
            any = true;
        });
        if (any) {
            recomputeSessionHasPicks();
            sortTagLibrary();
            scheduleCountSave();
        }
    }

    /**
     * Add tags into the known vocabulary WITHOUT bumping apply counters.
     * Use when discovering tags from file metadata or catalog on load/play.
     * Still refreshes library (file) frequency so totals grow as clips appear.
     */
    function ensureTagsKnown(tags) {
        const list = userTagsOnly(Array.isArray(tags) ? tags : [tags]);
        let added = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            if (tagLibrary.some((x) => x.toLowerCase() === low)) return;
            tagLibrary.push(t);
            added = true;
        });
        if (added) sortTagLibrary();
        return added;
    }

    /**
     * When a video loads with tags, fold them into library frequency counts
     * so totals accumulate as you browse (not only after you re-tag).
     */
    function accumulateTagsFromMedia(tags) {
        const list = userTagsOnly(Array.isArray(tags) ? tags : [tags]);
        const changed = ensureTagsKnown(list);
        // Rebuild from full mediaMeta so we never double-count one file
        scheduleLibraryRecount(true);
        return changed;
    }

    /** Returns display label for a tag's assigned hotkey, or ''. */
    function hotkeySlotForTag(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return '';
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    return formatHotkeyLabel(b, s);
                }
            }
        }
        return '';
    }

    function renderRecentTags() {
        const row = $('meta-recent-tags');
        if (!row) return;
        if (!recentTags.length) {
            row.innerHTML = '<span class="meta-chip-empty">Recent tags appear here · drop tags here to apply</span>';
            wireTagDropTarget(row, { kind: 'file' });
            return;
        }
        row.innerHTML = recentTags.map((t) => {
            const on = isTagOnVideo(t);
            return `<button type="button" class="meta-recent-tag ${on ? 'on-video' : ''}" draggable="true" data-tag="${escapeAttr(t)}" data-drag-src="recent" title="${escapeAttr(displayTag(t))} · drag">${escapeHtml(displayTag(t))}</button>`;
        }).join('');
        row.querySelectorAll('[data-tag]').forEach((btn) => {
            btn.addEventListener('click', () => {
                if (tagDragMoved) return;
                toggleLibraryTag(btn.dataset.tag);
            });
            markTagDragSource(btn, { kind: 'recent', tag: btn.dataset.tag });
        });
    }

    // ── Tag drag & drop (single delegated listeners — no stacked handlers) ──
    const TAG_DND_MIME = 'application/x-fafo-tag';
    let tagDragPayload = null;
    let tagDragMoved = false;
    let tagDndInited = false;

    /** Mark element as a drag source via data attributes only (no extra listeners per render). */
    function markTagDragSource(el, info) {
        if (!el || !info?.tag) return;
        el.setAttribute('draggable', 'true');
        el.dataset.tagDrag = '1';
        el.dataset.tag = normalizeTag(info.tag);
        el.dataset.dragSrc = info.kind || 'library';
        if (info.bank != null) el.dataset.dragBank = String(info.bank);
        if (info.slot != null) el.dataset.dragSlot = String(info.slot);
    }
    // Back-compat alias used by older call sites
    const wireTagDragSource = markTagDragSource;
    function wireTagDropTarget() { /* no-op: delegated */ }

    function initTagDndDelegation() {
        if (tagDndInited) return;
        tagDndInited = true;

        document.addEventListener('dragstart', (e) => {
            const el = e.target?.closest?.('[data-tag-drag="1"][data-tag]');
            if (!el) return;
            if (e.target.closest?.('button[data-i]')) {
                e.preventDefault();
                return;
            }
            const payload = {
                tag: normalizeTag(el.dataset.tag),
                source: el.dataset.dragSrc || 'library',
                bank: el.dataset.dragBank != null ? parseInt(el.dataset.dragBank, 10) : undefined,
                slot: el.dataset.dragSlot != null ? parseInt(el.dataset.dragSlot, 10) : undefined,
            };
            if (!payload.tag) {
                e.preventDefault();
                return;
            }
            tagDragPayload = payload;
            tagDragMoved = false;
            try {
                e.dataTransfer.setData(TAG_DND_MIME, JSON.stringify(payload));
                e.dataTransfer.setData('text/plain', payload.tag);
                e.dataTransfer.effectAllowed = 'copyMove';
            } catch (_) {}
            el.classList.add('tag-dragging');
            document.body.classList.add('fafo-tag-dnd');
        }, true);

        document.addEventListener('drag', () => {
            if (tagDragPayload) tagDragMoved = true;
        }, true);

        document.addEventListener('dragend', (e) => {
            const el = e.target?.closest?.('[data-tag-drag="1"]');
            el?.classList.remove('tag-dragging');
            document.body.classList.remove('fafo-tag-dnd');
            document.querySelectorAll('.tag-drop-hover').forEach((n) => n.classList.remove('tag-drop-hover'));
            if (tagDragMoved && el) {
                const swallow = (ev) => {
                    ev.preventDefault();
                    ev.stopPropagation();
                    el.removeEventListener('click', swallow, true);
                };
                el.addEventListener('click', swallow, true);
                setTimeout(() => el.removeEventListener('click', swallow, true), 0);
            }
            tagDragPayload = null;
            setTimeout(() => { tagDragMoved = false; }, 0);
        }, true);

        document.addEventListener('dragover', (e) => {
            if (!tagDragPayload?.tag && !(e.dataTransfer?.types || []).length) return;
            const zone = resolveDropZoneEl(e.target);
            if (!zone) return;
            e.preventDefault();
            try { e.dataTransfer.dropEffect = 'copy'; } catch (_) {}
            document.querySelectorAll('.tag-drop-hover').forEach((n) => {
                if (n !== zone.el) n.classList.remove('tag-drop-hover');
            });
            zone.el.classList.add('tag-drop-hover');
        }, true);

        document.addEventListener('dragleave', (e) => {
            const el = e.target?.closest?.('.tag-drop-hover');
            if (el && !el.contains(e.relatedTarget)) el.classList.remove('tag-drop-hover');
        }, true);

        document.addEventListener('drop', async (e) => {
            const zone = resolveDropZoneEl(e.target);
            if (!zone) return;
            e.preventDefault();
            e.stopPropagation();
            document.querySelectorAll('.tag-drop-hover').forEach((n) => n.classList.remove('tag-drop-hover'));
            const p = tagDragPayload || readTagDragFallback(e);
            if (!p?.tag) return;
            tagDragMoved = true;
            await handleTagDrop(p, zone.target);
            tagDragPayload = null;
        }, true);
    }

    function readTagDragFallback(e) {
        try {
            const raw = e.dataTransfer?.getData(TAG_DND_MIME) || '';
            if (raw) return JSON.parse(raw);
        } catch (_) {}
        try {
            const t = normalizeTag(e.dataTransfer?.getData('text/plain') || '');
            return t ? { tag: t, source: 'external' } : null;
        } catch (_) {
            return null;
        }
    }

    /** Map DOM node under cursor → single drop target (one drop = one action). */
    function resolveDropZoneEl(start) {
        if (!start || !start.closest) return null;
        // Prefer specific slot/chip targets over containers
        const esetSlot = start.closest('[data-eset-slot]');
        if (esetSlot && (esetSlot.closest('#meta-eset-slots') || esetSlot.closest('#hud-eset-slots'))) {
            const bank = extraLiveBank;
            const slot = parseInt(esetSlot.dataset.esetSlot, 10);
            return { el: esetSlot, target: { kind: 'eset', bank, slot } };
        }
        const hkSlot = start.closest('.meta-hotkey-slot[data-slot]');
        if (hkSlot) {
            return {
                el: hkSlot,
                target: {
                    kind: 'hotkey',
                    bank: parseInt(hkSlot.dataset.bank, 10) || 0,
                    slot: parseInt(hkSlot.dataset.slot, 10) || 0,
                },
            };
        }
        const zoneEl = start.closest('[data-drop-zone]');
        if (!zoneEl) return null;
        const z = zoneEl.dataset.dropZone;
        if (z === 'file') return { el: zoneEl, target: { kind: 'file' } };
        if (z === 'library') return { el: zoneEl, target: { kind: 'library' } };
        if (z === 'eset-auto') {
            const bank = extraLiveBank;
            const row = extraTagBanks[bank] || [];
            let slot = row.findIndex((x) => !normalizeTag(x));
            if (slot < 0) slot = EXTRA_SLOTS - 1; // full → replace last, not fill all
            return { el: zoneEl, target: { kind: 'eset', bank, slot } };
        }
        return null;
    }

    async function handleTagDrop(payload, target) {
        const tag = normalizeTag(payload.tag);
        if (!tag) return;
        if (globalThis.FAFOId?.isSystemOrPairTag?.(tag)) {
            if (els.status) els.status.textContent = 'Pair/system tags can’t be dropped into user lists';
            return;
        }
        const t = userTagsOnly([tag])[0] || tag;
        if (!t) return;

        // ── Drop onto current file tags ──
        if (target.kind === 'file') {
            if (!activeKey) {
                setMetaPanelOpen(true);
                if (els.status) els.status.textContent = 'No media to tag';
                return;
            }
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                await persistActiveMeta({ touchedTags: [t] });
                if (els.status) els.status.textContent = `Dropped onto file: ${t}`;
            } else if (els.status) {
                els.status.textContent = `Already on file: ${t}`;
            }
            return;
        }

        // ── Drop chip back onto library = remove from file ──
        if (target.kind === 'library') {
            ensureTagsKnown([t]);
            if (payload.source === 'chip' || payload.source === 'file') {
                const idx = activeTags.findIndex((x) => x.toLowerCase() === t.toLowerCase());
                if (idx >= 0) {
                    const [removed] = activeTags.splice(idx, 1);
                    await persistActiveMeta({ removedTags: [removed || t] });
                    if (els.status) els.status.textContent = `Removed from file → list: ${t}`;
                    return;
                }
            }
            await saveStore();
            renderTagLibrary();
            if (els.status) els.status.textContent = `In tag list: ${t}`;
            return;
        }

        // ── Hotkey slot ──
        if (target.kind === 'hotkey') {
            const bank = target.bank | 0;
            const slot = target.slot | 0;
            clearTagFromAllHotkeys(t);
            setHotkey(bank, slot, t);
            await saveStore();
            renderHotkeyBar();
            renderTagLibrary();
            if (els.status) els.status.textContent = `Hotkey ${formatHotkeyLabel(bank, slot)} ← ${t}`;
            // Optional: if dragged from another hotkey slot, clear source
            if (payload.source === 'hotkey' && payload.bank != null && payload.slot != null) {
                if (payload.bank !== bank || payload.slot !== slot) {
                    if (getHotkey(payload.bank, payload.slot)?.toLowerCase() === t.toLowerCase()) {
                        setHotkey(payload.bank, payload.slot, '');
                        await saveStore();
                        renderHotkeyBar();
                    }
                }
            }
            return;
        }

        // ── E-set slot ──
        if (target.kind === 'eset') {
            const bank = target.bank != null ? target.bank : extraLiveBank;
            const slot = target.slot | 0;
            setExtraTag(bank, slot, t);
            ensureTagsKnown([t]);
            await saveStore();
            renderExtraTagHud();
            if (els.status) els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}[${slot + 1}] ← ${t}`;
            if (payload.source === 'eset' && payload.bank != null && payload.slot != null) {
                if (payload.bank !== bank || payload.slot !== slot) {
                    if (getExtraTag(payload.bank, payload.slot)?.toLowerCase() === t.toLowerCase()) {
                        setExtraTag(payload.bank, payload.slot, '');
                        await saveStore();
                        renderExtraTagHud();
                    }
                }
            }
            return;
        }
    }

    function setExplorerHelpOpen(open) {
        const help = $('meta-explorer-help');
        if (!help) return;
        help.classList.toggle('hidden', !open);
    }

    function updateExplorerStatusUi() {
        const el = $('meta-explorer-status');
        if (!el) return;
        if (explorerOnline === null) {
            el.className = 'meta-explorer-status unknown';
            el.textContent = 'Explorer · …';
            el.title = 'Windows file tags server — click to check. (Not library permissions.)';
            return;
        }
        if (explorerOnline) {
            el.className = 'meta-explorer-status online';
            el.textContent = 'Explorer · ON';
            el.title =
                'Windows Explorer tags ON (127.0.0.1:8765). Click or Sync to rescan + write this file’s tags. Not library folder access.';
        } else {
            el.className = 'meta-explorer-status offline';
            el.textContent = 'Explorer · OFF';
            el.title =
                'Windows file-tag server offline. Click for how to start it. Tags still save in FAFO. Not library permissions.';
        }
    }

    async function pollExplorerStatus() {
        try {
            explorerOnline = await toolboxOnline();
        } catch {
            explorerOnline = false;
        }
        updateExplorerStatusUi();
        return explorerOnline;
    }

    function startExplorerPoll() {
        pollExplorerStatus();
        clearInterval(explorerPollTimer);
        explorerPollTimer = setInterval(pollExplorerStatus, 12000);
    }

    /**
     * Check companion server, optional rescan, write current clip tags to disk.
     * This is Windows Explorer Tags/Rating — not Chrome library Restore Access.
     */
    async function syncExplorerNow(opts = {}) {
        const statusBtn = $('meta-explorer-status');
        const syncBtn = $('meta-explorer-sync');
        const showHelpIfOffline = opts.showHelpIfOffline !== false;

        if (syncBtn) {
            syncBtn.disabled = true;
            syncBtn.textContent = '…';
        }
        if (statusBtn) {
            statusBtn.className = 'meta-explorer-status busy';
            statusBtn.textContent = 'Explorer · check…';
        }
        if (els.status) {
            els.status.textContent = 'Checking Windows Explorer tag server (127.0.0.1:8765)…';
        }

        let online = false;
        try {
            online = await toolboxOnline();
        } catch {
            online = false;
        }
        explorerOnline = online;
        updateExplorerStatusUi();

        if (!online) {
            if (syncBtn) {
                syncBtn.disabled = false;
                syncBtn.textContent = 'Sync';
            }
            if (els.status) {
                els.status.textContent =
                    'Explorer OFF — start explorer-meta\\START_META_SERVER.bat (Windows file tags, not library access)';
            }
            if (showHelpIfOffline) setExplorerHelpOpen(true);
            return { online: false };
        }

        setExplorerHelpOpen(false);
        let rescanOk = false;
        try {
            if (statusBtn) statusBtn.textContent = 'Explorer · rescan…';
            const r = await fetch(`${TOOLBOX_API}/library/rescan`, {
                method: 'POST',
                signal: AbortSignal.timeout(20000),
            });
            rescanOk = r.ok;
        } catch {
            rescanOk = false;
        }

        // Ensure we have an active clip identity for write (playlist may be ready
        // while bind never ran because getFile/permission failed first).
        let writeMsg = '';
        try {
            if (!activeKey) {
                const item = window.FAFOPlayer?.getCurrentItem?.();
                const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
                if (item) await bindToItem(item, idx);
            }
        } catch (_) {}

        if (activeKey && activeName) {
            try {
                if (statusBtn) statusBtn.textContent = 'Explorer · write…';
                // Force immediate write (not only debounced)
                clearTimeout(diskSyncTimer);
                await syncFileMetadataToDiskNow();
                writeMsg = ' · wrote current file';
            } catch (e) {
                writeMsg = ' · write failed';
            }
        } else {
            const plLen = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
            writeMsg = plLen
                ? ' · clip not bound — click Restore Access / play a video first'
                : ' · no media in playlist — link folders in Options';
            if (els.filename) {
                els.filename.textContent = activeName || (plLen ? 'Clip not ready' : 'No media');
            }
        }

        updateExplorerStatusUi();
        if (syncBtn) {
            syncBtn.disabled = false;
            syncBtn.textContent = 'Sync';
        }
        if (els.status) {
            els.status.textContent = rescanOk
                ? `Explorer ON · library rescanned${writeMsg}`
                : `Explorer ON · rescan skipped/failed${writeMsg}`;
        }
        harvestTagsFromServer().catch(() => {});
        return { online: true, rescanOk };
    }

    function updateApplyNextBtn() {
        const btn = $('meta-apply-next');
        if (!btn) return;
        btn.classList.toggle('active', applyAndNextMode);
        btn.setAttribute('aria-pressed', applyAndNextMode ? 'true' : 'false');
        btn.textContent = applyAndNextMode ? 'Apply+Next · ON' : 'Apply+Next';
        btn.title = applyAndNextMode
            ? 'ON: applying a tag advances to next clip. Click to turn off.'
            : 'When ON, applying a tag also goes to Next (bulk tagging)';
    }

    async function maybeApplyAndNext() {
        if (!applyAndNextMode) return;
        window.FAFOPlayer?.skipTrack?.(1);
    }

    async function exportTagsBackup() {
        if (!globalThis.FAFOBackup?.exportToDownload) {
            if (els.status) els.status.textContent = 'Backup module missing';
            return;
        }
        try {
            await FAFOBackup.exportToDownload({ includeConfig: false });
            const s = await FAFOBackup.statusSummary?.();
            if (els.status) {
                const when = s?.snapshotAt ? new Date(s.snapshotAt).toLocaleString() : 'now';
                els.status.textContent = `Exported tags backup · snapshot ${when}`;
            }
            updateBackupStatusUi();
        } catch (e) {
            if (els.status) els.status.textContent = 'Export failed: ' + (e.message || e);
        }
    }

    async function updateBackupStatusUi() {
        const el = $('meta-backup-status');
        if (!el || !globalThis.FAFOBackup?.statusSummary) return;
        try {
            const s = await FAFOBackup.statusSummary();
            const when = s.snapshotAt ? new Date(s.snapshotAt).toLocaleString() : 'never';
            el.textContent = `Backup · ${s.liveMedia || 0} files · last ${when}`;
            el.title = `Live: ${s.liveTags || 0} tags · history slots: ${s.historyCount || 0}`;
        } catch {
            el.textContent = 'Backup · —';
        }
    }

    async function loadStore() {
        try {
            // Auto-recover if live meta was wiped but a snapshot/history exists
            if (globalThis.FAFOBackup?.tryRecoverEmptyLive) {
                await FAFOBackup.tryRecoverEmptyLive();
            }
            const res = await chrome.storage.local.get([
                'fafoMediaMeta', 'fafoTagLibrary', 'fafoTagLastUsed', 'fafoTagHotkeys',
                'fafoSkipTaggedMode', 'fafoTagLibraryHeight', 'fafoMetaPanelWidth',
                'fafoMetaPanelHeight', 'fafoMetaDockPos', 'fafoMetaDockX', 'fafoMetaDockY',
                'fafoMetaUiScale', 'fafoMetaSplit', 'fafoMetaPanelOpen', 'fafoMetaStickLayout',
                'fafoMetaLibX', 'fafoMetaLibY', 'fafoMetaLibW', 'fafoMetaLibH', 'fafoMetaLibPosSaved',
                'fafoTagExcluded',
                'fafoTagApplyCounts', 'fafoTagSessionCounts', 'fafoTagCountMode',
                'fafoRecentTags', 'fafoApplyAndNext', 'fafoExtraTagBanks', 'fafoExtraTagSet',
            ]);
            // Defaults (first run): split ON (history LEFT), quick+rating RIGHT, panel open
            window.__fafoMetaSplitPending = ('fafoMetaSplit' in res) ? !!res.fafoMetaSplit : true;
            window.__fafoMetaPanelOpenPending = ('fafoMetaPanelOpen' in res) ? !!res.fafoMetaPanelOpen : true;
            // Quick panel dock: default bottom-right if never saved
            if (!res.fafoMetaDockPos) dockPos = 'br';
            excludedTags = Array.isArray(res.fafoTagExcluded)
                ? res.fafoTagExcluded.map(normalizeTag).filter(Boolean)
                : [];
            mediaMeta = res.fafoMediaMeta || {};
            tagLastUsed = res.fafoTagLastUsed && typeof res.fafoTagLastUsed === 'object' ? res.fafoTagLastUsed : {};
            tagLibrary = Array.isArray(res.fafoTagLibrary) ? res.fafoTagLibrary.slice() : [];
            tagHotkeys = normalizeHotkeyBanks(res.fafoTagHotkeys);
            skipTaggedMode = !!res.fafoSkipTaggedMode;
            applyAndNextMode = !!res.fafoApplyAndNext;
            recentTags = Array.isArray(res.fafoRecentTags)
                ? res.fafoRecentTags.map(normalizeTag).filter(Boolean).slice(0, 12)
                : [];
            if (typeof res.fafoTagLibraryHeight === 'number' && res.fafoTagLibraryHeight >= 80) {
                tagLibraryHeight = Math.min(res.fafoTagLibraryHeight, Math.round(window.innerHeight * 0.7));
            }
            if (typeof res.fafoMetaPanelWidth === 'number' && res.fafoMetaPanelWidth >= 260) {
                panelWidth = Math.min(res.fafoMetaPanelWidth, Math.round(window.innerWidth - 16));
            }
            if (typeof res.fafoMetaPanelHeight === 'number' && res.fafoMetaPanelHeight >= 200) {
                panelHeight = Math.min(res.fafoMetaPanelHeight, Math.round(window.innerHeight * 0.95));
            }
            const allowedDock = ['br', 'bl', 'tr', 'tl', 'free'];
            if (allowedDock.includes(res.fafoMetaDockPos)) dockPos = res.fafoMetaDockPos;
            if (typeof res.fafoMetaDockX === 'number') dockX = res.fafoMetaDockX;
            if (typeof res.fafoMetaDockY === 'number') dockY = res.fafoMetaDockY;
            if (typeof res.fafoMetaUiScale === 'number' && UI_SCALES.includes(res.fafoMetaUiScale)) {
                uiScale = res.fafoMetaUiScale;
            }
            if (typeof res.fafoMetaStickLayout === 'boolean') stickLayout = res.fafoMetaStickLayout;
            else stickLayout = true; // default: stay where you put them
            if (typeof res.fafoMetaLibX === 'number') libX = res.fafoMetaLibX;
            if (typeof res.fafoMetaLibY === 'number') libY = res.fafoMetaLibY;
            if (typeof res.fafoMetaLibW === 'number' && res.fafoMetaLibW >= 200) libW = res.fafoMetaLibW;
            if (typeof res.fafoMetaLibH === 'number' && res.fafoMetaLibH >= 140) libH = res.fafoMetaLibH;
            libPosSaved = !!res.fafoMetaLibPosSaved || (typeof res.fafoMetaLibX === 'number');
            if (res.fafoExtraTagBanks) {
                extraTagBanks = normalizeExtraBanks(res.fafoExtraTagBanks);
            } else if (res.fafoExtraTagSet) {
                extraTagBanks = normalizeExtraBanks(res.fafoExtraTagSet);
            }
            // Restore apply counts (never wipe on reload)
            const savedCounts = res.fafoTagApplyCounts || res.fafoTagSessionCounts;
            if (savedCounts && typeof savedCounts === 'object' && !Array.isArray(savedCounts)) {
                sessionTagCount = {};
                Object.entries(savedCounts).forEach(([k, v]) => {
                    const n = parseInt(v, 10);
                    if (k && n > 0) sessionTagCount[String(k).toLowerCase()] = n;
                });
            } else {
                sessionTagCount = {};
            }
            recomputeSessionHasPicks();
            if (res.fafoTagCountMode === 'total' || res.fafoTagCountMode === 'session') {
                countDisplayMode = res.fafoTagCountMode;
            }
            // Migrate: strip pair/role tags out of .tags into .pairId; clean vocabulary
            let migrated = false;
            Object.keys(mediaMeta).forEach((k) => {
                const m = mediaMeta[k];
                if (!m || typeof m !== 'object') return;
                const raw = Array.isArray(m.tags) ? m.tags : [];
                const pairFromTags = globalThis.FAFOId?.pairIdFromMeta
                    ? FAFOId.pairIdFromMeta(m)
                    : '';
                const cleaned = userTagsOnly(raw);
                if (pairFromTags && !m.pairId) {
                    m.pairId = pairFromTags;
                    migrated = true;
                }
                if (cleaned.length !== raw.length) {
                    m.tags = cleaned;
                    migrated = true;
                }
            });
            // Always re-harvest known USER tags from saved media (no apply-count bump)
            Object.values(mediaMeta).forEach(m => ensureTagsKnown(m.tags || []));
            if (!tagLibrary.length) {
                const set = new Set();
                Object.values(mediaMeta).forEach(m => userTagsOnly(m.tags || []).forEach(t => set.add(t)));
                tagLibrary = [...set];
            }
            scrubTagLibrary();
            // Also delete corrupt / oversized dumps that re-fill the panel
            const scrub = scrubCorruptTagsEverywhere();
            if (scrub.dropped > 0) migrated = true;
            rebuildLibraryTagCounts();
            sortTagLibrary();
            if (migrated) {
                chrome.storage.local.set({
                    fafoMediaMeta: mediaMeta,
                    fafoTagLibrary: tagLibrary,
                }).catch(() => {});
                console.info(
                    'FAFOMeta: scrubbed junk tags',
                    scrub.dropped,
                    'from',
                    scrub.files,
                    'files · library',
                    scrub.library
                );
            }
            // Ask S2 meta server to drop Signature/ComfyUI dumps from tags_cache
            try {
                fetch(`${TOOLBOX_API}/tags/scrub`, { method: 'POST' })
                    .then((r) => (r.ok ? r.json() : null))
                    .then((j) => {
                        if (j && j.removed > 0) {
                            console.info('FAFOMeta: server tag scrub removed', j.removed, 'junk tags');
                        }
                    })
                    .catch(() => {});
            } catch (_) { /* offline */ }
        } catch {
            mediaMeta = {};
            tagLibrary = [];
            tagLastUsed = {};
            libraryTagCount = {};
            sessionTagCount = {};
            sessionHasPicks = false;
            tagHotkeys = emptyHotkeyBanks();
            skipTaggedMode = false;
        }
    }

    async function saveStore() {
        try {
            scrubTagLibrary();
            const payload = {
                fafoMediaMeta: mediaMeta,
                fafoTagLibrary: tagLibrary,
                fafoTagLastUsed: tagLastUsed,
                fafoTagHotkeys: tagHotkeys,
                fafoSkipTaggedMode: skipTaggedMode,
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: panelWidth || undefined,
                fafoMetaPanelHeight: panelHeight || undefined,
                fafoMetaDockPos: dockPos,
                fafoMetaDockX: dockX,
                fafoMetaDockY: dockY,
                fafoMetaUiScale: uiScale,
                fafoMetaPanelOpen: metaPanelOpen,
                fafoMetaStickLayout: stickLayout,
                fafoMetaLibX: libX,
                fafoMetaLibY: libY,
                fafoMetaLibW: libW,
                fafoMetaLibH: libH,
                fafoMetaLibPosSaved: libPosSaved,
                fafoTagExcluded: excludedTags,
                fafoTagApplyCounts: sessionTagCount,
                fafoTagCountMode: countDisplayMode,
                fafoExtraTagBanks: extraTagBanks,
            };
            await chrome.storage.local.set(payload);
            // Durable rolling backups (snapshot + history + optional disk file via companion)
            if (globalThis.FAFOBackup?.afterLiveSave) {
                FAFOBackup.afterLiveSave(payload, 'tag-save').catch((e) =>
                    console.warn('FAFO backup failed', e)
                );
            }
        } catch (e) {
            console.warn('FAFO meta save failed', e);
            if (els.status) {
                els.status.textContent = 'Save failed — check storage / try Backup → Export tags';
            }
        }
    }

    function scheduleLayoutSave() {
        clearTimeout(layoutSaveTimer);
        layoutSaveTimer = setTimeout(() => {
            chrome.storage.local.set({
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: panelWidth || undefined,
                fafoMetaPanelHeight: panelHeight || undefined,
                fafoMetaDockPos: dockPos,
                fafoMetaDockX: dockX,
                fafoMetaDockY: dockY,
                fafoMetaUiScale: uiScale,
                fafoMetaStickLayout: stickLayout,
                fafoMetaLibX: libX,
                fafoMetaLibY: libY,
                fafoMetaLibW: libW,
                fafoMetaLibH: libH,
                fafoMetaLibPosSaved: libPosSaved,
            }).catch(() => {});
        }, 200);
    }

    function dockLabel(pos) {
        return ({ br: 'BR', bl: 'BL', tr: 'TR', tl: 'TL', free: 'Free' })[pos] || 'BR';
    }

    function updateDockButtons() {
        const posBtn = $('meta-dock-pos');
        if (posBtn) {
            posBtn.textContent = `Dock · ${dockLabel(dockPos)}`;
            posBtn.title = 'Cycle free-float → BR → BL → TR → TL. Drag the ⋮⋮ header anytime to move.';
            posBtn.classList.toggle('active', dockPos === 'free');
        }
        const scaleBtn = $('meta-ui-scale');
        if (scaleBtn) {
            scaleBtn.textContent = `Scale · ${Math.round(uiScale * 100)}%`;
            scaleBtn.title = 'UI scale only — does not move free-floating panels when Stick is on';
        }
        const stickBtn = $('meta-stick-layout');
        if (stickBtn) {
            stickBtn.classList.toggle('active', !!stickLayout);
            stickBtn.textContent = stickLayout ? 'Stick · ON' : 'Stick · off';
            stickBtn.title = stickLayout
                ? 'ON: scale/open won’t jump panels. You can ALWAYS drag headers to move.'
                : 'OFF: Dock button snaps to corners; free panels re-clamp on scale';
        }
        const undockBtn = $('meta-undock-move');
        if (undockBtn) {
            undockBtn.title = 'Force free-float + pull on-screen so you can drag the ⋮⋮ header';
        }
    }

    function setStickLayout(on) {
        stickLayout = !!on;
        updateDockButtons();
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = stickLayout
                ? 'Stick ON — drag still works; scale won’t jump panels'
                : 'Stick off — Dock snaps to corners again';
        }
    }

    /** Keep enough of a free panel on-screen to grab (allows partial hang-off). */
    function clampFreeXY(x, y, w, h) {
        const minVis = 72;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const loX = -(Math.max(0, (w || 360) - minVis));
        const hiX = Math.max(0, ww - minVis);
        const loY = 0;
        const hiY = Math.max(0, wh - minVis);
        return {
            x: Math.round(Math.max(loX, Math.min(hiX, Number(x) || 0))),
            y: Math.round(Math.max(loY, Math.min(hiY, Number(y) || 0))),
        };
    }

    function clampDockFree(x, y) {
        const dock = $('meta-dock');
        const w = dock?.offsetWidth || 360;
        const h = dock?.offsetHeight || 200;
        return clampFreeXY(x, y, w, h);
    }

    function isMostlyOffScreen(x, y, w, h) {
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const left = Number(x) || 0;
        const top = Number(y) || 0;
        const right = left + (w || 200);
        const bottom = top + (h || 120);
        const visW = Math.min(right, ww) - Math.max(left, 0);
        const visH = Math.min(bottom, wh) - Math.max(top, 0);
        return visW < 64 || visH < 40;
    }

    /** Place dock with explicit left/top only (CSS never uses right/bottom anymore). */
    function placeDockAt(x, y) {
        const dock = $('meta-dock');
        if (!dock) return;
        const c = clampDockFree(x, y);
        dockX = c.x;
        dockY = c.y;
        dock.style.setProperty('left', `${dockX}px`, 'important');
        dock.style.setProperty('top', `${dockY}px`, 'important');
        dock.style.setProperty('right', 'auto', 'important');
        dock.style.setProperty('bottom', 'auto', 'important');
        dock.style.setProperty('transform', 'none', 'important');
    }

    function setDockFreeStyles(dock, x, y) {
        if (!dock) return;
        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl');
        dock.classList.add('dock-free');
        dock.dataset.dock = 'free';
        placeDockAt(x, y);
    }

    function clearDockCornerStyles(dock) {
        // No-op: layout always uses left/top via placeDockAt
        if (!dock) return;
    }

    /** Corner snap → pixel coords using current dock box size. */
    function coordsForDockSnap(pos) {
        const dock = $('meta-dock');
        const m = 18;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const w = Math.max(120, dock?.offsetWidth || 360);
        const h = Math.max(48, dock?.offsetHeight || 200);
        switch (pos) {
            case 'bl': return { x: m, y: Math.max(m, wh - h - m) };
            case 'tr': return { x: Math.max(m, ww - w - m), y: m };
            case 'tl': return { x: m, y: m };
            case 'br':
            default: return { x: Math.max(m, ww - w - m), y: Math.max(m, wh - h - m) };
        }
    }

    function applyDockLayout(opts = {}) {
        const dock = $('meta-dock');
        if (!dock) return;
        const scaleOnly = !!opts.scaleOnly;
        dock.style.setProperty('--meta-ui-scale', String(uiScale));

        // Scale-only: keep free panels where they are (unless ungrabbable)
        if (scaleOnly) {
            if (dockPos === 'free' || stickLayout) {
                if (isMostlyOffScreen(dockX, dockY, dock.offsetWidth, dock.offsetHeight)) {
                    placeDockAt(dockX, dockY);
                } else {
                    placeDockAt(dockX, dockY);
                }
            } else {
                // snapped corner: recompute from viewport
                const c = coordsForDockSnap(dockPos);
                placeDockAt(c.x, c.y);
            }
            applyTagLibraryHeight();
            applyLibraryPanelGeometry({ forceDefault: false });
            ensureLibraryOnScreen();
            updateDockButtons();
            return;
        }

        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl', 'dock-free');
        const pos = ['br', 'bl', 'tr', 'tl', 'free'].includes(dockPos) ? dockPos : 'br';
        dock.classList.add(`dock-${pos}`);
        dock.dataset.dock = pos;

        if (pos === 'free') {
            let x = dockX;
            let y = dockY;
            if (isMostlyOffScreen(x, y, dock.offsetWidth || 360, dock.offsetHeight || 200)) {
                x = Math.max(18, Math.round((window.innerWidth || 800) * 0.55));
                y = Math.max(18, Math.round((window.innerHeight || 600) * 0.12));
            }
            placeDockAt(x, y);
        } else {
            // Snap corners via explicit pixels so nothing can fight with CSS anchors
            const place = () => {
                const c = coordsForDockSnap(pos);
                placeDockAt(c.x, c.y);
            };
            place();
            // After open/sizes settle, re-snap once more
            requestAnimationFrame(place);
        }
        updateDockButtons();
        applyTagLibraryHeight();
        if ($('meta-dock')?.classList.contains('layout-split')) {
            applyLibraryPanelGeometry({ forceDefault: false });
            ensureLibraryOnScreen();
        }
    }

    function ensureLibraryOnScreen() {
        const lib = $('meta-library-panel');
        if (!lib || lib.classList.contains('collapsed')) return;
        if (!$('meta-dock')?.classList.contains('layout-split')) return;
        if (getComputedStyle(lib).position !== 'fixed') return;
        const w = lib.offsetWidth || libW || 360;
        const h = lib.offsetHeight || libH || 400;
        if (!isMostlyOffScreen(libX, libY, w, h)) {
            const c = clampFreeXY(libX, libY, w, h);
            if (c.x !== libX || c.y !== libY) {
                libX = c.x;
                libY = c.y;
                lib.style.left = `${libX}px`;
                lib.style.top = `${libY}px`;
            }
            return;
        }
        libX = 18;
        libY = Math.max(12, Math.round(((window.innerHeight || 600) - Math.min(h, 520)) / 2));
        const c = clampFreeXY(libX, libY, w, h);
        libX = c.x;
        libY = c.y;
        lib.style.left = `${libX}px`;
        lib.style.top = `${libY}px`;
        libPosSaved = true;
    }

    function applyLibraryPanelGeometry(opts = {}) {
        const lib = $('meta-library-panel');
        const dock = $('meta-dock');
        if (!lib || !dock?.classList.contains('layout-split')) return;
        if (lib.classList.contains('collapsed')) return;

        const forceDefault = !!opts.forceDefault && !libPosSaved && !stickLayout;
        if (forceDefault || (!libPosSaved && !opts.keepCurrent)) {
            // First-time default: left side, vertically centered
            libW = Math.min(360, Math.round(window.innerWidth * 0.32));
            libH = Math.min(Math.round(window.innerHeight * 0.72), 720);
            libX = 18;
            libY = Math.max(12, Math.round((window.innerHeight - libH) / 2));
        } else if (opts.keepCurrent) {
            const r = lib.getBoundingClientRect();
            if (r.width > 40) {
                libX = Math.round(r.left);
                libY = Math.round(r.top);
                libW = Math.round(r.width);
                libH = Math.round(r.height);
                libPosSaved = true;
            }
        }

        // Stick mode: don't rewrite position on scale — only ensure styles applied
        const c = clampFreeXY(libX, libY, libW, libH);
        libX = c.x;
        libY = c.y;
        lib.style.position = 'fixed';
        lib.style.left = `${Math.round(libX)}px`;
        lib.style.top = `${Math.round(libY)}px`;
        lib.style.right = 'auto';
        lib.style.bottom = 'auto';
        lib.style.transform = 'none';
        lib.style.width = `${Math.round(libW)}px`;
        lib.style.height = `${Math.round(libH)}px`;
    }

    function captureLibraryGeometry() {
        const lib = $('meta-library-panel');
        if (!lib || lib.classList.contains('collapsed')) return;
        if (getComputedStyle(lib).position !== 'fixed') return;
        const r = lib.getBoundingClientRect();
        if (r.width < 40 || r.height < 40) return;
        libX = Math.round(r.left);
        libY = Math.round(r.top);
        libW = Math.round(r.width);
        libH = Math.round(r.height);
        libPosSaved = true;
    }

    function cycleDockPos() {
        // Always cycle: free → BR → BL → TR → TL → free …
        // Stick only prevents *automatic* jumps (scale/open), never blocks Dock button or drag-to-move.
        const order = ['free', 'br', 'bl', 'tr', 'tl'];
        const i = Math.max(0, order.indexOf(dockPos));
        dockPos = order[(i + 1) % order.length];
        if (dockPos === 'free') {
            const dock = $('meta-dock');
            const r = dock?.getBoundingClientRect();
            if (r && r.width > 0 && !isMostlyOffScreen(r.left, r.top, r.width, r.height)) {
                dockX = Math.round(r.left);
                dockY = Math.round(r.top);
            } else {
                dockX = Math.max(18, Math.round(window.innerWidth * 0.55));
                dockY = Math.max(18, Math.round(window.innerHeight * 0.15));
            }
            const c = clampDockFree(dockX, dockY);
            dockX = c.x;
            dockY = c.y;
        }
        applyDockLayout();
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = dockPos === 'free'
                ? 'Tags free-float — drag the ⋮⋮ header to move'
                : `Tags dock: ${dockLabel(dockPos)} — drag ⋮⋮ header anytime to free-move`;
        }
    }

    /** Force free-float + on-screen so user can always grab and move. */
    function undockTagsForMove() {
        const dock = $('meta-dock');
        // Open panel so the drag header exists
        if (!metaPanelOpen) setMetaPanelOpen(true);
        const r = dock?.getBoundingClientRect();
        dockPos = 'free';
        if (r && r.width > 0 && !isMostlyOffScreen(r.left, r.top, r.width, r.height)) {
            dockX = Math.round(r.left);
            dockY = Math.round(r.top);
        } else {
            // Safe home on the right if current spot is unusable
            dockX = Math.max(18, Math.round((window.innerWidth || 800) * 0.58));
            dockY = Math.max(18, Math.round((window.innerHeight || 600) * 0.12));
        }
        const c = clampDockFree(dockX, dockY);
        dockX = c.x;
        dockY = c.y;
        applyDockLayout();
        // Also free the history window if split so nothing is corner-locked
        if ($('meta-dock')?.classList.contains('layout-split')) {
            ensureLibraryOnScreen();
        }
        try { window.FAFOPlayer?.undockHudForMove?.(); } catch (_) {}
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = 'Undocked · drag ⋮⋮ headers to place · Stick only blocks auto-jumps';
        }
    }

    function cycleUiScale() {
        const i = UI_SCALES.indexOf(uiScale);
        uiScale = UI_SCALES[(i + 1) % UI_SCALES.length];
        // IMPORTANT: scale must not re-dock / jump the left history window
        applyDockLayout({ scaleOnly: true });
        scheduleLayoutSave();
        if (els.status) els.status.textContent = `Tags panel scale: ${Math.round(uiScale * 100)}%`;
    }

    function resetLayout() {
        // Defaults: rating+quick RIGHT, tag history LEFT (split), scale 100%
        dockPos = 'br';
        dockX = 18;
        dockY = 18;
        uiScale = 1;
        panelWidth = 0;
        panelHeight = 0;
        tagLibraryHeight = 160;
        libPosSaved = false;
        stickLayout = true;
        libX = 18;
        libW = Math.min(360, Math.round(window.innerWidth * 0.32));
        libH = Math.min(Math.round(window.innerHeight * 0.72), 720);
        libY = Math.max(12, Math.round((window.innerHeight - libH) / 2));
        if (els.panel) {
            els.panel.style.width = '';
            els.panel.style.height = '';
            els.panel.style.maxWidth = '';
            els.panel.style.maxHeight = '';
        }
        if (els.library) els.library.style.height = '';
        clearDockCornerStyles($('meta-dock'));
        applyDockLayout();
        setLibrarySplit(true, { forceDefault: true });
        setMetaPanelOpen(true);
        try { window.FAFOPlayer?.resetHudLayout?.(); } catch (_) {}
        scheduleLayoutSave();
        if (els.status) {
            els.status.textContent = 'Layout reset · player mid-right · tags RIGHT · history LEFT · drag ⋮⋮ to move';
        }
    }

    function capturePanelSize() {
        if (!els.panel || els.panel.classList.contains('collapsed')) return;
        const rect = els.panel.getBoundingClientRect();
        if (rect.width >= 260) panelWidth = Math.round(rect.width);
        if (rect.height >= 200) panelHeight = Math.round(rect.height);
    }

    function applyTagLibraryHeight() {
        if (els.library) {
            els.library.style.height = tagLibraryHeight + 'px';
        }
        if (els.panel) {
            if (panelWidth > 0) els.panel.style.width = panelWidth + 'px';
            if (panelHeight > 0) els.panel.style.height = panelHeight + 'px';
        }
    }

    function initPanelDrag() {
        const handle = $('meta-drag-handle') || document.querySelector('#meta-panel .meta-header');
        const dock = $('meta-dock');
        if (!handle || !dock) return;

        // Ensure handle is always interactive above resize edges
        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.zIndex = '20';

        let activePointerId = null;

        const onMove = (clientX, clientY) => {
            if (!dockDragging) return;
            const c = clampDockFree(clientX - dockDragOffX, clientY - dockDragOffY);
            dockPos = 'free';
            dockX = c.x;
            dockY = c.y;
            setDockFreeStyles(dock, dockX, dockY);
            updateDockButtons();
        };

        const endDrag = (e) => {
            if (!dockDragging) return;
            dockDragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            document.removeEventListener('pointermove', onPointerMove, true);
            document.removeEventListener('pointerup', onPointerUp, true);
            document.removeEventListener('pointercancel', onPointerUp, true);
            document.removeEventListener('mousemove', onMouseMove, true);
            document.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            scheduleLayoutSave();
            if (els.status) els.status.textContent = 'Tags free-float position saved';
        };

        const onPointerMove = (e) => {
            if (!dockDragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            endDrag(e);
        };
        const onMouseMove = (e) => {
            if (dockDragging) onMove(e.clientX, e.clientY);
        };
        const onMouseUp = () => endDrag();

        const startDrag = (clientX, clientY, target) => {
            // Only block pure control clicks (nav arrows / collapse), not the whole header
            if (target && target.closest && target.closest('.meta-nav button, a, input, select, textarea')) {
                return false;
            }
            // If panel collapsed, open so drag has a real box
            if (els.panel?.classList.contains('collapsed')) setMetaPanelOpen(true);
            const rect = dock.getBoundingClientRect();
            dockDragging = true;
            dockDragOffX = clientX - rect.left;
            dockDragOffY = clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Seed free coords from current on-screen rect (works from BR/BL/etc.)
            dockPos = 'free';
            dockX = Math.round(rect.left);
            dockY = Math.round(rect.top);
            setDockFreeStyles(dock, dockX, dockY);
            updateDockButtons();
            return true;
        };

        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (!startDrag(e.clientX, e.clientY, e.target)) return;
            activePointerId = e.pointerId;
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            // Document capture = drag keeps working even if pointer leaves the header
            document.addEventListener('pointermove', onPointerMove, true);
            document.addEventListener('pointerup', onPointerUp, true);
            document.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
        // Mouse fallback (some environments)
        handle.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            if (e.pointerType) return; // already handled by pointer events
            if (!startDrag(e.clientX, e.clientY, e.target)) return;
            document.addEventListener('mousemove', onMouseMove, true);
            document.addEventListener('mouseup', onMouseUp, true);
            e.preventDefault();
            e.stopPropagation();
        });

        window.addEventListener('resize', () => {
            if (dockPos === 'free') {
                const c = clampDockFree(dockX, dockY);
                dockX = c.x;
                dockY = c.y;
                applyDockLayout();
            }
            if ($('meta-dock')?.classList.contains('layout-split')) {
                applyLibraryPanelGeometry({ forceDefault: false });
                ensureLibraryOnScreen();
            }
        });
    }

    function initPanelResizeObserver() {
        if (!els.panel || typeof ResizeObserver === 'undefined') return;
        let first = true;
        const ro = new ResizeObserver(() => {
            if (first) { first = false; return; }
            if (resizeDragging || dockDragging || edgeResizing) return;
            if (els.panel.classList.contains('collapsed')) return;
            capturePanelSize();
            scheduleLayoutSave();
        });
        ro.observe(els.panel);
    }

    let edgeResizing = false;

    /**
     * Resize from any edge/corner. When dock is free-floating, west/north edges
     * also move the dock so the opposite side stays planted (natural window resize).
     */
    function initEdgeResize(panelEl, opts = {}) {
        if (!panelEl) return;
        const handles = panelEl.querySelectorAll('.meta-rh[data-edge]');
        if (!handles.length) return;

        const minW = opts.minW || 260;
        const minH = opts.minH || 160;
        const isMain = !!opts.isMainPanel;

        handles.forEach((handle) => {
            const edge = handle.dataset.edge || '';
            const onDown = (e) => {
                if (e.button != null && e.button !== 0) return;
                e.preventDefault();
                e.stopPropagation();
                const clientX = e.clientX ?? e.touches?.[0]?.clientX;
                const clientY = e.clientY ?? e.touches?.[0]?.clientY;
                if (clientX == null) return;

                const rect = panelEl.getBoundingClientRect();
                const dock = $('meta-dock');
                const free = dock?.classList.contains('dock-free') || dockPos === 'free';
                const dockRect = dock?.getBoundingClientRect();

                edgeResizing = true;
                resizeDragging = true;
                handle.classList.add('dragging');
                document.body.style.userSelect = 'none';
                const cursors = {
                    n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize',
                    ne: 'nesw-resize', sw: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize',
                };
                document.body.style.cursor = cursors[edge] || 'nwse-resize';

                const state = {
                    edge,
                    startX: clientX,
                    startY: clientY,
                    startW: rect.width,
                    startH: rect.height,
                    // Main free-float: resize moves the whole dock; library: resize the panel itself
                    startLeft: (isMain && free) ? (dockRect?.left ?? rect.left) : rect.left,
                    startTop: (isMain && free) ? (dockRect?.top ?? rect.top) : rect.top,
                    free,
                    isMain,
                };

                const onMove = (ev) => {
                    if (!edgeResizing) return;
                    const cx = ev.clientX ?? ev.touches?.[0]?.clientX;
                    const cy = ev.clientY ?? ev.touches?.[0]?.clientY;
                    if (cx == null) return;
                    const dx = cx - state.startX;
                    const dy = cy - state.startY;
                    let w = state.startW;
                    let h = state.startH;
                    let left = state.startLeft;
                    let top = state.startTop;

                    if (edge.includes('e')) w = state.startW + dx;
                    if (edge.includes('w')) {
                        w = state.startW - dx;
                        left = state.startLeft + dx;
                    }
                    if (edge.includes('s')) h = state.startH + dy;
                    if (edge.includes('n')) {
                        h = state.startH - dy;
                        top = state.startTop + dy;
                    }

                    const maxW = Math.min(900, window.innerWidth - 8);
                    const maxH = Math.min(window.innerHeight * 0.98, window.innerHeight - 8);
                    w = Math.max(minW, Math.min(maxW, Math.round(w)));
                    h = Math.max(minH, Math.min(maxH, Math.round(h)));

                    // If west/north clamped, re-derive left/top so growth feels stable
                    if (edge.includes('w')) {
                        left = Math.round(state.startLeft + (state.startW - w));
                    }
                    if (edge.includes('n')) {
                        top = Math.round(state.startTop + (state.startH - h));
                    }

                    panelEl.style.width = w + 'px';
                    panelEl.style.height = h + 'px';
                    panelEl.style.maxWidth = 'none';
                    panelEl.style.maxHeight = 'none';

                    if (state.isMain) {
                        panelWidth = w;
                        panelHeight = h;
                    }

                    if (state.isMain && state.free && dock) {
                        left = Math.max(0, Math.min(window.innerWidth - 40, left));
                        top = Math.max(0, Math.min(window.innerHeight - 40, top));
                        dockPos = 'free';
                        dockX = left;
                        dockY = top;
                        dock.classList.add('dock-free');
                        dock.classList.remove('dock-br', 'dock-bl', 'dock-tr', 'dock-tl');
                        dock.style.left = left + 'px';
                        dock.style.top = top + 'px';
                        dock.style.right = 'auto';
                        dock.style.bottom = 'auto';
                        updateDockButtons();
                    }

                    // Free-floating library panel: stay put, only update its own box
                    if (!state.isMain && panelEl.classList.contains('meta-library-panel')) {
                        if (getComputedStyle(panelEl).position === 'fixed') {
                            left = Math.max(0, Math.min(window.innerWidth - 40, left));
                            top = Math.max(0, Math.min(window.innerHeight - 40, top));
                            panelEl.style.left = left + 'px';
                            panelEl.style.top = top + 'px';
                            panelEl.style.right = 'auto';
                            panelEl.style.bottom = 'auto';
                            libX = left;
                            libY = top;
                            libW = w;
                            libH = h;
                            libPosSaved = true;
                        }
                    }
                };

                const onUp = () => {
                    if (!edgeResizing) return;
                    edgeResizing = false;
                    resizeDragging = false;
                    handle.classList.remove('dragging');
                    document.body.style.cursor = '';
                    document.body.style.userSelect = '';
                    document.removeEventListener('mousemove', onMove);
                    document.removeEventListener('mouseup', onUp);
                    document.removeEventListener('touchmove', onMove);
                    document.removeEventListener('touchend', onUp);
                    if (state.isMain) capturePanelSize();
                    else captureLibraryGeometry();
                    scheduleLayoutSave();
                };

                document.addEventListener('mousemove', onMove);
                document.addEventListener('mouseup', onUp);
                document.addEventListener('touchmove', onMove, { passive: false });
                document.addEventListener('touchend', onUp);
            };

            handle.addEventListener('mousedown', onDown);
            handle.addEventListener('touchstart', onDown, { passive: false });
        });
    }

    function nudgePanelSize(dir) {
        if (!els.panel || els.panel.classList.contains('collapsed')) {
            setMetaPanelOpen(true);
        }
        const rect = els.panel.getBoundingClientRect();
        const step = 48;
        let w = (panelWidth > 0 ? panelWidth : rect.width) + dir * step;
        let h = (panelHeight > 0 ? panelHeight : rect.height) + dir * step;
        w = Math.max(260, Math.min(Math.min(900, window.innerWidth - 16), Math.round(w)));
        h = Math.max(180, Math.min(Math.round(window.innerHeight * 0.95), Math.round(h)));
        panelWidth = w;
        panelHeight = h;
        els.panel.style.width = w + 'px';
        els.panel.style.height = h + 'px';
        scheduleLayoutSave();
        if (els.status) els.status.textContent = `Panel size ${w}×${h}`;
    }

    function initLibPanelDrag() {
        const handle = $('meta-lib-drag-handle');
        const lib = $('meta-library-panel');
        if (!handle || !lib) return;
        let dragging = false;
        let offX = 0;
        let offY = 0;
        let activePointerId = null;

        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.zIndex = '20';

        const onMove = (cx, cy) => {
            if (!dragging) return;
            // Ensure split mode while free-dragging history
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            }
            const w = lib.offsetWidth || libW || 360;
            const h = lib.offsetHeight || libH || 400;
            const c = clampFreeXY(cx - offX, cy - offY, w, h);
            lib.style.position = 'fixed';
            lib.style.left = c.x + 'px';
            lib.style.top = c.y + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            lib.style.transform = 'none';
            libX = c.x;
            libY = c.y;
            libPosSaved = true;
        };
        const end = (e) => {
            if (!dragging) return;
            dragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            document.removeEventListener('pointermove', onPointerMove, true);
            document.removeEventListener('pointerup', onPointerUp, true);
            document.removeEventListener('pointercancel', onPointerUp, true);
            document.removeEventListener('mousemove', onMouseMove, true);
            document.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            captureLibraryGeometry();
            scheduleLayoutSave();
            if (els.status) els.status.textContent = 'Tag history position saved';
        };
        const onPointerMove = (e) => {
            if (!dragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            end(e);
        };
        const onMouseMove = (e) => { if (dragging) onMove(e.clientX, e.clientY); };
        const onMouseUp = () => end();

        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (e.target?.closest?.('button, input, a')) return;
            const rect = lib.getBoundingClientRect();
            dragging = true;
            activePointerId = e.pointerId;
            offX = e.clientX - rect.left;
            offY = e.clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Convert to free immediately
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            }
            lib.style.position = 'fixed';
            lib.style.left = Math.round(rect.left) + 'px';
            lib.style.top = Math.round(rect.top) + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            document.addEventListener('pointermove', onPointerMove, true);
            document.addEventListener('pointerup', onPointerUp, true);
            document.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
        handle.addEventListener('mousedown', (e) => {
            if (e.button !== 0) return;
            if (e.pointerType) return;
            if (e.target?.closest?.('button, input, a')) return;
            const rect = lib.getBoundingClientRect();
            dragging = true;
            offX = e.clientX - rect.left;
            offY = e.clientY - rect.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            if (!$('meta-dock')?.classList.contains('layout-split')) {
                setLibrarySplit(true, { keepCurrent: true });
            }
            lib.style.position = 'fixed';
            lib.style.left = Math.round(rect.left) + 'px';
            lib.style.top = Math.round(rect.top) + 'px';
            lib.style.right = 'auto';
            lib.style.bottom = 'auto';
            document.addEventListener('mousemove', onMouseMove, true);
            document.addEventListener('mouseup', onMouseUp, true);
            e.preventDefault();
            e.stopPropagation();
        });
    }

    function updateSkipTaggedBtn() {
        if (!els.skipTagged) return;
        els.skipTagged.classList.toggle('active', skipTaggedMode);
        els.skipTagged.setAttribute('aria-pressed', skipTaggedMode ? 'true' : 'false');
        els.skipTagged.title = skipTaggedMode
            ? 'ON: skip tagged on Next · loop current clip until you press Next. Click to turn off.'
            : 'Skip tagged on Next; loop current clip continuously until you press Next (then 5+ tags when all tagged)';
        els.skipTagged.textContent = skipTaggedMode ? 'Skip tagged · ON' : 'Skip tagged';
    }

    async function setSkipTaggedMode(on) {
        skipTaggedMode = !!on;
        updateSkipTaggedBtn();
        try {
            await chrome.storage.local.set({ fafoSkipTaggedMode: skipTaggedMode });
        } catch { /* ignore */ }
        // Loop current clip while this mode is on — only Next advances
        try { window.FAFOPlayer?.setClipLoop?.(skipTaggedMode); } catch (_) {}
        if (els.status) {
            els.status.textContent = skipTaggedMode
                ? 'Skip tagged ON — loops this clip · Next skips tagged (then 5+ tags)'
                : 'Skip tagged off — auto-advance restored';
        }
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        // If we just turned it on and the current clip is already tagged, advance
        if (skipTaggedMode && activeTags.length > 0) {
            window.FAFOPlayer?.skipTrack?.(1);
        }
    }

    /**
     * Look up tag count for a playlist item (skip-tagged mode).
     * Uses stable FAFOId keys — exact match only (no fuzzy includes).
     */
    function tagCountForItem(item) {
        if (!item) return 0;
        const name = itemDisplayName(item);
        // Prefer live state for the clip currently bound in the panel
        if (activeName && name && activeName.toLowerCase() === String(name).toLowerCase()) {
            return activeTags.length;
        }
        if (item.mediaKey && mediaMeta[item.mediaKey]?.tags) {
            return mediaMeta[item.mediaKey].tags.length;
        }
        const size = item.size ?? item._size ?? null;
        if (globalThis.FAFOId?.findStoredMeta) {
            const hit = FAFOId.findStoredMeta(mediaMeta, { name, size });
            if (hit?.meta?.tags) return hit.meta.tags.length;
        } else {
            const byName = findStoredByName(name);
            if (byName?.meta?.tags) return byName.meta.tags.length;
        }
        return 0;
    }

    function isSkipTaggedMode() {
        return skipTaggedMode;
    }

    /** Pull tag vocabulary from toolbox/server without MRU bump. */
    async function harvestTagsFromServer() {
        if (!(await toolboxOnline())) return;
        try {
            const r = await fetch(`${TOOLBOX_API}/tags`, { signal: AbortSignal.timeout(3000) });
            if (!r.ok) return;
            const tags = await r.json();
            if (Array.isArray(tags) && tags.length) {
                ensureTagsKnown(tags);
                await saveStore();
                renderTagLibrary();
            }
        } catch { /* optional */ }
    }

    async function fetchTagsForIdentity(id) {
        if (!id?.name || !(await toolboxOnline())) return null;
        try {
            // Match catalog by name/size via write-metadata path — use media query if available
            const q = new URLSearchParams({ search: id.name, limit: '5' });
            const r = await fetch(`${TOOLBOX_API}/media?${q}`, { signal: AbortSignal.timeout(3000) });
            if (!r.ok) return null;
            const data = await r.json();
            const items = data.items || data || [];
            if (!Array.isArray(items)) return null;
            let hit = items.find(m => m.name === id.name && (id.size == null || m.size === id.size));
            if (!hit) hit = items.find(m => m.name === id.name);
            if (!hit) return null;
            return {
                tags: hit.tags || [],
                rating: hit.rank != null ? Number(hit.rank) : 0,
            };
        } catch {
            return null;
        }
    }

    /** Exact name match only — no fuzzy key.includes(name). */
    function findStoredByName(name) {
        if (!name) return null;
        if (globalThis.FAFOId?.findStoredMeta) {
            return FAFOId.findStoredMeta(mediaMeta, { name }) || null;
        }
        const low = name.toLowerCase();
        const hits = [];
        for (const [k, v] of Object.entries(mediaMeta)) {
            if (v && v.name && String(v.name).toLowerCase() === low) hits.push({ key: k, meta: v });
        }
        return hits.length === 1 ? hits[0] : null;
    }

    function itemDisplayName(item) {
        if (globalThis.FAFOId?.displayNameFromItem) return FAFOId.displayNameFromItem(item);
        if (!item) return 'Unknown';
        if (item.handle?.name) return item.handle.name;
        if (typeof item === 'object' && item.name) return item.name;
        if (item.url) {
            try {
                return decodeURIComponent(item.url.split('?')[0].split('/').pop() || item.url);
            } catch { return item.url; }
        }
        return 'Unknown';
    }

    async function mediaKeyFor(item) {
        if (globalThis.FAFOId?.mediaKeyFor) return FAFOId.mediaKeyFor(item);
        if (!item) return null;
        if (item.handle) {
            try {
                const f = await item.handle.getFile();
                return `file:${f.name}|${f.size}|${f.lastModified}`;
            } catch {
                return 'handle:' + (item.handle.name || 'unknown');
            }
        }
        if (item.url) return 'url:' + item.url;
        return 'unknown:' + itemDisplayName(item);
    }

    async function identityForItem(item) {
        if (globalThis.FAFOId?.identityForItem) return FAFOId.identityForItem(item);
        const name = itemDisplayName(item);
        return { name, size: null, mtime: null };
    }

    async function toolboxOnline() {
        try {
            const r = await fetch(`${TOOLBOX_API}/health`, { signal: AbortSignal.timeout(1200) });
            return r.ok;
        } catch {
            return false;
        }
    }

    let diskSyncTimer = null;
    let diskSyncInFlight = null;

    /**
     * Debounced write to companion server. While a clip is playing, Windows often
     * locks the file (Explorer shell props fail); server retries after unlock.
     */
    function syncFileMetadataToDisk() {
        clearTimeout(diskSyncTimer);
        diskSyncTimer = setTimeout(() => {
            diskSyncInFlight = syncFileMetadataToDiskNow().finally(() => {
                diskSyncInFlight = null;
            });
        }, 700);
        return diskSyncInFlight || Promise.resolve();
    }

    async function syncFileMetadataToDiskNow() {
        if (!activeKey) return;
        if (!(await toolboxOnline())) {
            if (els.status) {
                els.status.textContent = 'Saved in FAFO · run explorer-meta\\START_META_SERVER.bat for Explorer tags';
            }
            return;
        }
        const item = window.FAFOPlayer?.getCurrentItem?.() || null;
        const id = await identityForItem(item);
        if (!id?.name) return;
        // Capture snapshot so rapid tag changes still write the latest after debounce
        const payload = {
            name: id.name,
            size: id.size,
            mtime: id.mtime,
            tags: userTagsOnly(activeTags),
            rating: activeRating,
            update_catalog: true,
        };
        try {
            const r = await fetch(`${TOOLBOX_API}/fs/write-metadata`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
            });
            const data = await r.json().catch(() => ({}));
            if (!r.ok) {
                const detail = data.detail || r.statusText;
                if (els.status) {
                    const d = typeof detail === 'string' ? detail : JSON.stringify(detail);
                    els.status.textContent = /not found|library/i.test(d)
                        ? 'Saved in FAFO · run ADD_VIDEO_FOLDER.bat for this library'
                        : `Saved in FAFO · file write: ${d}`;
                }
                return;
            }
            const methods = data.methods || data.file_write?.methods || [];
            const locked = !!(data.file_locked || data.deferred_shell);
            const hasShell = methods.some((m) => String(m).startsWith('shell'));
            if (els.status) {
                if (data.ok === false && !methods.length) {
                    els.status.textContent = locked
                        ? 'Saved in FAFO · file busy (Explorer write when playback unlocks)'
                        : 'Saved · file write failed';
                } else if (locked && !hasShell) {
                    els.status.textContent =
                        `Saved · ${(methods.join(', ') || 'embedded')} · Explorer when file unlocks`;
                } else {
                    els.status.textContent =
                        `Saved to file (Explorer) · ${(methods.join(', ') || 'ok')}`;
                }
            }
        } catch {
            if (els.status) els.status.textContent = 'Saved in FAFO · could not reach toolbox server';
        }
    }

    async function persistActiveMeta(opts = {}) {
        if (!activeKey) return;
        const now = Date.now();
        // Quick panel only holds user tags; pairId stays on its own field
        activeTags = userTagsOnly(activeTags);
        const prev = mediaMeta[activeKey] || {};
        const pairId = activePairId
            || prev.pairId
            || (globalThis.FAFOId?.pairIdFromMeta ? FAFOId.pairIdFromMeta(prev) : '');
        mediaMeta[activeKey] = {
            ...prev,
            rating: activeRating,
            tags: [...activeTags],
            name: activeName,
            size: opts.size != null ? opts.size : prev.size,
            pairId: pairId || prev.pairId || undefined,
            pairRole: prev.pairRole,
            updated: now,
        };
        activePairId = pairId || '';
        // Apply counters: + on apply, − on remove (not for full resaves / rating-only)
        const touched = opts.touchedTags != null ? opts.touchedTags : [];
        const removed = opts.removedTags != null ? opts.removedTags : [];
        if (touched && touched.length) touchTags(touched, now);
        if (removed && removed.length) untouchTags(removed);
        // Ensure every active tag is in the vocabulary without apply-count bumps
        ensureTagsKnown(activeTags);
        // Rebuild library (file) frequency — dropping a tag lowers its total by 1
        rebuildLibraryTagCounts();
        sortTagLibrary();
        await saveStore();
        renderMetaPanel();
        // Tagging never auto-advances; refresh loop state (untagged loop ends when tagged)
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        if (activeTags.length) clearUntaggedPrompt();
        syncFileMetadataToDisk().catch(() => {});
        if (touched && touched.length) await maybeApplyAndNext();
    }

    function setMetaPanelOpen(open) {
        metaPanelOpen = open;
        if (els.panel) {
            els.panel.classList.toggle('collapsed', !open);
            els.panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        }
        // Tag history panel tracks the main tags UI (unless user hid it while open)
        const lib = $('meta-library-panel');
        if (lib) {
            if (!open) {
                lib.classList.add('collapsed');
                lib.setAttribute('aria-hidden', 'true');
            } else if (!lib.dataset.userHidden) {
                lib.classList.remove('collapsed');
                lib.setAttribute('aria-hidden', 'false');
            }
        }
        if (els.toggle) els.toggle.classList.toggle('open', open);
        if (open) {
            // scaleOnly-style restore: re-apply scale/sizes without snapping free panels
            applyDockLayout({ scaleOnly: stickLayout || dockPos === 'free' });
            if (!stickLayout && dockPos !== 'free') applyDockLayout();
            if ($('meta-dock')?.classList.contains('layout-split')) {
                applyLibraryPanelGeometry({ forceDefault: false });
            }
            renderTagLibrary();
            renderTagSuggestions(els.tagInput?.value || '');
        } else hideSuggestions();
        // Sticky: remember quick panel open/closed across reloads
        chrome.storage.local.set({ fafoMetaPanelOpen: !!open }).catch(() => {});
    }

    function setLibrarySplit(split, opts = {}) {
        const dock = $('meta-dock');
        const lib = $('meta-library-panel');
        if (!dock || !lib) return;
        dock.classList.toggle('layout-split', !!split);
        if (split) {
            lib.classList.remove('collapsed');
            lib.dataset.userHidden = '';
            delete lib.dataset.userHidden;
            // Restore sticky geometry — do NOT jump to defaults if user already placed it
            applyLibraryPanelGeometry({
                forceDefault: !!opts.forceDefault,
                keepCurrent: !!opts.keepCurrent,
            });
            // Don't force dockPos to BR when stick/free — that was yanking things right
            if (!stickLayout && dockPos !== 'br' && dockPos !== 'tr' && dockPos !== 'free') {
                dockPos = 'br';
                applyDockLayout();
            }
        } else {
            // Capture geometry before re-attaching so re-split restores it
            captureLibraryGeometry();
            lib.style.position = '';
            lib.style.left = '';
            lib.style.top = '';
            lib.style.right = '';
            lib.style.bottom = '';
            lib.style.width = '';
            lib.style.height = '';
            if (metaPanelOpen) {
                lib.classList.remove('collapsed');
                delete lib.dataset.userHidden;
            }
        }
        chrome.storage.local.set({ fafoMetaSplit: !!split }).catch(() => {});
        scheduleLayoutSave();
        const btn = $('meta-split-toggle');
        if (btn) {
            btn.classList.toggle('active', !!split);
            btn.textContent = split ? 'Split · ON' : 'Split tags';
        }
    }

    function toggleLibrarySplit() {
        const dock = $('meta-dock');
        const on = !dock?.classList.contains('layout-split');
        setLibrarySplit(on, { forceDefault: false });
        if (els.status) {
            els.status.textContent = on
                ? (libPosSaved
                    ? 'Tag history restored where you left it'
                    : 'Tag history on left · drag header to place · Stick keeps it there')
                : 'Tag history attached under quick panel';
        }
    }

    function setRating(r) {
        if (r === activeRating) activeRating = 0;
        else activeRating = Math.max(0, Math.min(5, r));
        persistActiveMeta();
    }

    async function addTagsFromInput() {
        if (!els.tagInput) return;
        const parts = els.tagInput.value.split(/[,;]+/).map(normalizeTag).filter(Boolean);
        if (!parts.length) return;
        const newly = [];
        parts.forEach(t => {
            if (!activeTags.some(x => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            } else {
                newly.push(t); // still counts as "used" for MRU order
            }
        });
        els.tagInput.value = '';
        hideSuggestions();
        await persistActiveMeta({ touchedTags: newly });
    }

    async function toggleLibraryTag(tag) {
        const idx = activeTags.findIndex(x => x.toLowerCase() === tag.toLowerCase());
        if (idx >= 0) {
            const [removed] = activeTags.splice(idx, 1);
            await persistActiveMeta({ removedTags: [removed || tag] });
        } else {
            activeTags.push(tag);
            await persistActiveMeta({ touchedTags: [tag] });
        }
    }

    function hideCtxMenu() {
        if (ctxMenu) {
            ctxMenu.remove();
            ctxMenu = null;
        }
    }

    function showTagContextMenu(e, tag) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const t = normalizeTag(tag);
        const bank = liveBank;
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu meta-ctx-menu-wide';
        const slotBtns = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
            const cur = getHotkey(bank, s);
            const active = cur && cur.toLowerCase() === t.toLowerCase();
            const label = formatHotkeyLabel(bank, s);
            return `<button type="button" data-bank="${bank}" data-slot="${s}" class="${active ? 'on' : ''}">
                <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
            </button>`;
        }).join('');
        // Quick bank switch inside menu
        const bankTabs = BANK_LABELS.map((name, b) =>
            `<button type="button" data-pick-bank="${b}" class="meta-ctx-bank ${b === bank ? 'on' : ''}">${escapeHtml(name)}</button>`
        ).join('');
        const onVideo = activeTags.some((x) => x.toLowerCase() === t.toLowerCase());
        const isExcl = excludedTags.some((x) => x.toLowerCase() === t.toLowerCase());
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">${escapeHtml(t)}</div>
            <div class="meta-ctx-actions">
                ${onVideo
                    ? '<button type="button" data-rm-video="1" class="meta-ctx-danger">Remove from this video…</button>'
                    : '<button type="button" data-add-video="1">Add to this video</button>'}
                <button type="button" data-hide-tag="1">${isExcl ? 'Show in lists again' : 'Hide from lists (keep on files)'}</button>
                <button type="button" data-purge-lib="1" class="meta-ctx-danger">Remove from tag library…</button>
                <button type="button" data-strip-all="1" class="meta-ctx-danger">Strip from all videos…</button>
            </div>
            <div class="meta-ctx-hint">Hotkey assign (hold modifiers for banks)</div>
            <div class="meta-ctx-bank-row">${bankTabs}</div>
            <div class="meta-ctx-slot-list" data-for-bank="${bank}">${slotBtns}</div>
            <button type="button" data-clear="1" class="meta-ctx-clear">Clear this tag's hotkey</button>
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 260);
        const y = Math.min(e.clientY, window.innerHeight - 360);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        const refillSlots = (b) => {
            const list = ctxMenu.querySelector('.meta-ctx-slot-list');
            if (!list) return;
            list.dataset.forBank = String(b);
            list.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
                const cur = getHotkey(b, s);
                const active = cur && cur.toLowerCase() === t.toLowerCase();
                const label = formatHotkeyLabel(b, s);
                return `<button type="button" data-bank="${b}" data-slot="${s}" class="${active ? 'on' : ''}">
                    <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
                </button>`;
            }).join('');
            wireSlotAssign(list);
        };

        const wireSlotAssign = (root) => {
            root.querySelectorAll('[data-slot]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    const b = parseInt(btn.dataset.bank, 10);
                    const s = parseInt(btn.dataset.slot, 10);
                    clearTagFromAllHotkeys(t);
                    setHotkey(b, s, t);
                    await saveStore();
                    hideCtxMenu();
                    renderTagLibrary();
                    renderHotkeyBar();
                    if (els.status) els.status.textContent = `Hotkey ${formatHotkeyLabel(b, s)} → ${t}`;
                });
            });
        };

        ctxMenu.querySelectorAll('[data-pick-bank]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const b = parseInt(btn.dataset.pickBank, 10);
                ctxMenu.querySelectorAll('[data-pick-bank]').forEach((x) => {
                    x.classList.toggle('on', parseInt(x.dataset.pickBank, 10) === b);
                });
                refillSlots(b);
            });
        });
        wireSlotAssign(ctxMenu.querySelector('.meta-ctx-slot-list'));

        ctxMenu.querySelector('[data-clear]')?.addEventListener('click', async () => {
            clearTagFromAllHotkeys(t);
            await saveStore();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
        ctxMenu.querySelector('[data-hide-tag]')?.addEventListener('click', async () => {
            hideCtxMenu();
            const isExcl = excludedTags.some((x) => x.toLowerCase() === t.toLowerCase());
            if (isExcl) await unexcludeTag(t);
            else await excludeTag(t);
        });
        ctxMenu.querySelector('[data-rm-video]')?.addEventListener('click', async () => {
            hideCtxMenu();
            await removeTagFromVideoConfirmed(t);
        });
        ctxMenu.querySelector('[data-add-video]')?.addEventListener('click', async () => {
            hideCtxMenu();
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                await persistActiveMeta({ touchedTags: [t] });
            }
        });
        ctxMenu.querySelector('[data-purge-lib]')?.addEventListener('click', async () => {
            if (!confirm('Remove "' + t + '" from the tag library list?\n\nIt stays on videos that already have it until you strip those.')) return;
            tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== t.toLowerCase());
            clearTagFromAllHotkeys(t);
            excludedTags = excludedTags.filter((x) => x.toLowerCase() !== t.toLowerCase());
            if (selectedTag.toLowerCase() === t.toLowerCase()) selectedTag = '';
            await persistExcludedTags();
            hideCtxMenu();
            renderMetaPanel();
        });
        ctxMenu.querySelector('[data-strip-all]')?.addEventListener('click', async () => {
            if (!confirm('Strip "' + t + '" from EVERY video in FAFO storage?\n\nExport a tags backup first. This cannot be undone easily.')) return;
            const low = t.toLowerCase();
            let n = 0;
            Object.keys(mediaMeta).forEach((k) => {
                const m = mediaMeta[k];
                if (!m || !Array.isArray(m.tags)) return;
                const next = m.tags.filter((x) => String(x).toLowerCase() !== low);
                if (next.length !== m.tags.length) {
                    m.tags = next;
                    m.updated = Date.now();
                    m.diskSyncedAt = 0;
                    n++;
                }
            });
            activeTags = activeTags.filter((x) => x.toLowerCase() !== low);
            tagLibrary = tagLibrary.filter((x) => x.toLowerCase() !== low);
            clearTagFromAllHotkeys(t);
            rebuildLibraryTagCounts();
            await saveStore();
            hideCtxMenu();
            renderMetaPanel();
            if (els.status) els.status.textContent = 'Stripped "' + t + '" from ' + n + ' file(s)';
        });
    }

    async function removeTagFromVideoConfirmed(tag) {
        const t = normalizeTag(tag);
        if (!t) return;
        if (!confirm('Remove tag "' + t + '" from this video?')) return;
        const idx = activeTags.findIndex((x) => x.toLowerCase() === t.toLowerCase());
        if (idx < 0) return;
        const [removed] = activeTags.splice(idx, 1);
        if (selectedTag.toLowerCase() === t.toLowerCase()) selectedTag = '';
        await persistActiveMeta({ removedTags: removed ? [removed] : [] });
        if (els.status) els.status.textContent = 'Removed "' + t + '" from this video';
    }

    async function clearAllTagsOnVideo() {
        if (!activeTags.length) return;
        if (!confirm('Clear all ' + activeTags.length + ' tag(s) on this video?')) return;
        const removed = activeTags.slice();
        activeTags = [];
        selectedTag = '';
        await persistActiveMeta({ removedTags: removed });
        if (els.status) els.status.textContent = 'Cleared all tags on this video';
    }

    function selectTag(tag) {
        selectedTag = normalizeTag(tag) || '';
        renderMetaPanel();
        if (els.status && selectedTag) {
            els.status.textContent = 'Selected "' + selectedTag + '" — press Delete to remove (asks first)';
        }
    }

    /** Right-click an empty or filled hotkey slot to pick / reassign a tag. */
    function showHotkeySlotAssignMenu(e, bank, slot) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const current = getHotkey(bank, slot);
        const label = formatHotkeyLabel(bank, slot);
        const candidates = tagLibrary.filter((t) => !isHiddenFromUi(t)).slice(0, 24);
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu';
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">Hotkey ${escapeHtml(label)}</div>
            <div class="meta-ctx-hint">${BANK_LABELS[bank]} · ${current ? 'Currently: ' + escapeHtml(current) : 'Empty — pick a tag'}</div>
            ${candidates.length
                ? candidates.map((t) => {
                    const on = current && current.toLowerCase() === t.toLowerCase();
                    return `<button type="button" data-assign="${escapeAttr(t)}" class="${on ? 'on' : ''}">${escapeHtml(t)}</button>`;
                }).join('')
                : '<div class="meta-ctx-hint">No tags yet — add some first</div>'}
            ${current ? '<button type="button" data-clear-slot="1" class="meta-ctx-clear">Clear this slot</button>' : ''}
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 220);
        const y = Math.min(e.clientY, window.innerHeight - 320);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        ctxMenu.querySelectorAll('[data-assign]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const t = normalizeTag(btn.dataset.assign);
                clearTagFromAllHotkeys(t);
                setHotkey(bank, slot, t);
                await saveStore();
                hideCtxMenu();
                renderTagLibrary();
                renderHotkeyBar();
                if (els.status) els.status.textContent = `Hotkey ${label} → ${t}`;
            });
        });
        ctxMenu.querySelector('[data-clear-slot]')?.addEventListener('click', async () => {
            setHotkey(bank, slot, '');
            await saveStore();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
    }

    function updateBankIndicator() {
        const el = $('meta-hotkey-bank');
        if (!el) return;
        el.innerHTML = BANK_LABELS.map((name, b) =>
            `<span class="meta-bank-chip ${b === liveBank ? 'active' : ''}" data-bank="${b}">${escapeHtml(name)}</span>`
        ).join('');
        el.querySelectorAll('.meta-bank-chip').forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                // Pin bank (sticky until Tab / another chip / modifiers override temporarily)
                pinnedBank = parseInt(chip.dataset.bank, 10);
                liveBank = pinnedBank;
                renderHotkeyBar();
                updateBankIndicator();
            });
        });
    }

    function renderHotkeyBar() {
        const bar = $('meta-hotkey-bar');
        if (!bar) return;
        const bank = liveBank;
        bar.dataset.bank = String(bank);
        bar.className = `meta-hotkey-bar bank-${bank}`;
        bar.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, i) => {
            const t = getHotkey(bank, i);
            const label = formatHotkeyLabel(bank, i);
            const on = t ? isTagOnVideo(t) : false;
            const sc = t ? sessionCountFor(t) : 0;
            const lc = t ? libraryCountFor(t) : 0;
            let statusClass = 'empty';
            if (t && on) statusClass = 'on-video';
            else if (t) statusClass = 'set';
            const countsHtml = t
                ? `<span class="meta-hk-counts">
                    <span class="meta-count-badge session" title="Apply count (saved across reloads)">${sc}</span>
                    ${on ? `<span class="meta-count-badge total" title="Library total (files with this tag)">${lc}</span>` : ''}
                   </span>`
                : '';
            const title = t
                ? `${on ? '● On this video · ' : ''}Uses ${sc} · Library ${lc} · Left-click apply · Right-click reassign · ${BANK_LABELS[bank]}`
                : `Empty · Right-click to assign · ${BANK_LABELS[bank]}`;
            return `<button type="button" class="meta-hotkey-slot ${statusClass}" data-bank="${bank}" data-slot="${i}" ${t ? 'draggable="true"' : ''} data-tag="${escapeAttr(t || '')}" title="${escapeAttr(title + ' · drop a tag here')}">
                <span class="meta-hk-top"><kbd>${escapeHtml(label)}</kbd>${countsHtml}</span>
                <span class="meta-hk-name">${t ? escapeHtml(t) : '—'}</span>
            </button>`;
        }).join('');
        bar.querySelectorAll('.meta-hotkey-slot').forEach((btn) => {
            const b = parseInt(btn.dataset.bank, 10);
            const slot = parseInt(btn.dataset.slot, 10);
            const t = getHotkey(b, slot);
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (tagDragMoved) return;
                applyHotkeyTag(b, slot);
            });
            btn.addEventListener('contextmenu', (e) => showHotkeySlotAssignMenu(e, b, slot));
            if (t) markTagDragSource(btn, { kind: 'hotkey', tag: t, bank: b, slot });
        });
        updateBankIndicator();
    }

    async function applyHotkeyTag(bank, slot) {
        // Back-compat: applyHotkeyTag(1..10) treated as base bank
        if (slot == null && typeof bank === 'number' && bank >= 1 && bank <= HOTKEY_SLOTS) {
            slot = bank - 1;
            bank = 0;
        }
        bank = Math.max(0, Math.min(HOTKEY_BANKS - 1, bank | 0));
        slot = Math.max(0, Math.min(HOTKEY_SLOTS - 1, slot | 0));
        const tag = getHotkey(bank, slot);
        const label = formatHotkeyLabel(bank, slot);
        if (!tag) {
            if (els.status) els.status.textContent = `Hotkey ${label} empty — right-click to assign`;
            setMetaPanelOpen(true);
            return;
        }
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active to tag';
            return;
        }
        // Toggle: second press / click removes the tag
        const idx = activeTags.findIndex((x) => x.toLowerCase() === tag.toLowerCase());
        if (idx >= 0) {
            const [removed] = activeTags.splice(idx, 1);
            await persistActiveMeta({ removedTags: [removed || tag] });
            if (els.status) els.status.textContent = `Removed ${label} ${tag}`;
            return;
        }
        activeTags.push(tag);
        await persistActiveMeta({ touchedTags: [tag] });
        if (els.status) els.status.textContent = `Applied ${label} ${tag}`;
    }

    function renderTagLibrary() {
        if (!els.library) return;
        scrubTagLibrary();
        sortTagLibrary();
        syncCountModeToggle();
        const q = (els.tagFilter?.value || '').trim().toLowerCase();
        const visibleLib = tagLibrary.filter((t) => !isHiddenFromUi(t) && !isOversizedOrSuspectTag(t));
        const filtered = visibleLib.filter(t => !q || t.toLowerCase().includes(q));
        // Cap DOM so one polluted vocabulary cannot freeze the panel
        const list = filtered.slice(0, TAG_LIBRARY_RENDER_MAX);
        const modeLabel = countDisplayMode === 'total' ? 'totals' : 'uses';
        if (els.tagCount) {
            if (!visibleLib.length) {
                els.tagCount.textContent = '';
            } else if (filtered.length > list.length) {
                els.tagCount.textContent =
                    `(showing ${list.length}/${filtered.length} · ${visibleLib.length} total · ${modeLabel})`;
            } else {
                els.tagCount.textContent = `(${visibleLib.length} · sort: ${modeLabel})`;
            }
        }
        if (!list.length) {
            els.library.innerHTML = visibleLib.length
                ? '<div class="meta-lib-empty">No tags match filter · drop chips here to remove from file</div>'
                : '<div class="meta-lib-empty">Tags appear here · drop a chip here to remove it from the file</div>';
            renderHotkeyBar();
            return;
        }
        let html = list.map((t, idx) => {
            const on = isTagOnVideo(t);
            const hk = hotkeySlotForTag(t);
            const sc = sessionCountFor(t);
            const lc = libraryCountFor(t);
            const label = displayTag(t);
            const sessionBadge = `<span class="meta-count-badge session" title="Apply count (saved across reloads)">${sc}</span>`;
            const totalBadge = on
                ? `<span class="meta-count-badge total" title="Library total — files with this tag">${lc}</span>`
                : '';
            const classes = [
                'meta-lib-tag',
                on ? 'on-video' : '',
                sc > 0 ? 'has-session' : '',
                hk ? 'has-hotkey' : '',
            ].filter(Boolean).join(' ');
            // Never put multi-KB strings in attributes — index + node property
            return `<button type="button" class="${classes}" draggable="true" data-lib-i="${idx}" data-drag-src="library" title="${escapeAttr(label)} · drag / click / right-click">${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span> ` : ''}<span class="meta-lib-name">${escapeHtml(label)}</span>${sessionBadge}${totalBadge}</button>`;
        }).join('');
        if (filtered.length > list.length) {
            html += `<div class="meta-lib-empty">+${filtered.length - list.length} more — type in filter to find them</div>`;
        }
        els.library.innerHTML = html;
        els.library.querySelectorAll('.meta-lib-tag').forEach((btn) => {
            const i = parseInt(btn.dataset.libI, 10);
            const full = list[i];
            btn.__fafoTag = full;
            btn.addEventListener('click', () => {
                if (tagDragMoved) return;
                if (full) toggleLibraryTag(full);
            });
            btn.addEventListener('contextmenu', (e) => showTagContextMenu(e, btn.__fafoTag || full));
            markTagDragSource(btn, { kind: 'library', tag: full });
        });
        renderHotkeyBar();
    }

    function matchingSuggestions(query) {
        const q = normalizeTag(query).toLowerCase();
        const onVideo = new Set(activeTags.map(t => t.toLowerCase()));
        // tagLibrary is already count-sorted; when typing, prefer prefix then count
        let list = tagLibrary.filter(t => !isHiddenFromUi(t) && !isOversizedOrSuspectTag(t) && !onVideo.has(t.toLowerCase()));
        if (q) {
            list = list.filter(t => t.toLowerCase().includes(q));
            list.sort((a, b) => {
                const ap = a.toLowerCase().startsWith(q) ? 0 : 1;
                const bp = b.toLowerCase().startsWith(q) ? 0 : 1;
                if (ap !== bp) return ap - bp;
                const ca = displayCountFor(a);
                const cb = displayCountFor(b);
                if (cb !== ca) return cb - ca;
                return a.localeCompare(b, undefined, { sensitivity: 'base' });
            });
        }
        return list.slice(0, 12);
    }

    function hideSuggestions() {
        if (!els.suggest) return;
        els.suggest.hidden = true;
        els.suggest.innerHTML = '';
        suggestIndex = -1;
    }

    function renderTagSuggestions(query) {
        if (!els.suggest) return;
        const matches = matchingSuggestions(query);
        const q = normalizeTag(query);
        if (!matches.length) {
            if (q) {
                els.suggest.innerHTML = `<div class="hint">Press Enter to create “${escapeHtml(q)}”</div>`;
                els.suggest.hidden = false;
            } else {
                const top = tagLibrary.filter(t => !activeTags.some(x => x.toLowerCase() === t.toLowerCase())).slice(0, 10);
                if (!top.length) { hideSuggestions(); return; }
                els.suggest.innerHTML = top.map((t, i) =>
                    `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}" title="${escapeAttr(displayTag(t))}">${escapeHtml(displayTag(t))}</div>`
                ).join('');
                wireSuggest();
                els.suggest.hidden = false;
            }
            return;
        }
        els.suggest.innerHTML = matches.map((t, i) =>
            `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}" title="${escapeAttr(displayTag(t))}">${escapeHtml(displayTag(t))}</div>`
        ).join('');
        wireSuggest();
        els.suggest.hidden = false;
    }

    function wireSuggest() {
        els.suggest.querySelectorAll('[data-tag]').forEach(div => {
            div.addEventListener('mousedown', (e) => {
                e.preventDefault();
                pickSuggestion(div.dataset.tag);
            });
        });
    }

    async function pickSuggestion(tag) {
        if (els.tagInput) els.tagInput.value = '';
        hideSuggestions();
        if (!activeTags.some(x => x.toLowerCase() === tag.toLowerCase())) {
            activeTags.push(tag);
        }
        await persistActiveMeta({ touchedTags: [tag] });
        els.tagInput?.focus();
    }

    function renderMetaPanel() {
        if (!els.filename) return;
        const n = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
        const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
        els.filename.textContent = activeName || 'No media';
        els.filename.title = activeName || '';
        if (els.status) {
            if (!activeKey) {
                els.status.textContent = n
                    ? `Playlist ${n} · waiting for clip (Restore Access if video blank)`
                    : 'No media — link folders in Options → Visual Library';
            } else {
                const pairHint = activePairId ? ` · ${activePairId}` : '';
                const hkHint = anyHotkeyAssigned()
                    ? ' · hold Shift/Ctrl/Alt for banks · click or `+1–0'
                    : ' · right-click tag → hotkey / hide';
                els.status.textContent = `Item ${idx + 1} of ${n} · T panel · 1–5 stars${pairHint}${hkHint}`;
            }
        }

        if (els.stars) {
            let html = '';
            for (let i = 1; i <= 5; i++) {
                html += `<span class="meta-star ${i <= activeRating ? 'on' : ''}" data-r="${i}">${i <= activeRating ? '★' : '☆'}</span>`;
            }
            els.stars.innerHTML = html;
            els.stars.querySelectorAll('.meta-star').forEach(st => {
                st.addEventListener('click', () => setRating(parseInt(st.dataset.r, 10)));
                st.addEventListener('contextmenu', (e) => { e.preventDefault(); setRating(0); });
            });
        }

        if (els.currentTags) {
            // Quick panel chips: real user tags only — never paint corrupt dumps full-width
            const beforeLen = activeTags.length;
            activeTags = userTagsOnly(activeTags);
            if (activeTags.length !== beforeLen && activeKey) {
                // Persist scrub so junk does not reappear every navigation
                mediaMeta[activeKey] = {
                    ...(mediaMeta[activeKey] || {}),
                    rating: activeRating,
                    tags: [...activeTags],
                    name: activeName,
                    pairId: activePairId || mediaMeta[activeKey]?.pairId || '',
                    updated: Date.now(),
                    diskSyncedAt: 0,
                };
                saveStore().catch(() => {});
            }
            const chips = activeTags;
            const pairChip = activePairId
                ? `<span class="meta-chip meta-chip-pair" title="Pair ID (not a tag)">${escapeHtml(displayTag(activePairId))}</span>`
                : '';
            if (!chips.length && !activePairId) {
                els.currentTags.innerHTML = '<span class="meta-chip-empty">No tags — type, drag from list, or drop here</span>';
            } else {
                els.currentTags.innerHTML = pairChip + chips.map((t, i) => {
                    const hk = hotkeySlotForTag(t);
                    const label = displayTag(t);
                    const suspect = isOversizedOrSuspectTag(t);
                    const dim = isHiddenFromUi(t) ? ' meta-chip-hidden-list' : '';
                    const sus = suspect ? ' suspect' : '';
                    // data-i only — full string on node.__fafoTag (attributes break on multi-KB dumps)
                    return `<span class="meta-chip${dim}${sus}" draggable="true" data-i="${i}" data-drag-src="chip" title="${escapeAttr(label)}${suspect ? ' · CORRUPT' : ''} · drag / right-click">${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span>` : ''}<span class="meta-chip-text">${escapeHtml(label)}</span><button type="button" data-i="${i}" title="Remove">×</button></span>`;
                }).join('');
                els.currentTags.querySelectorAll('.meta-chip[data-i]').forEach((chip) => {
                    const i = parseInt(chip.dataset.i, 10);
                    const full = activeTags[i];
                    chip.__fafoTag = full;
                    if (selectedTag && full && selectedTag.toLowerCase() === String(full).toLowerCase()) {
                        chip.classList.add('is-selected');
                    }
                    chip.addEventListener('click', (e) => {
                        if (e.target.closest('button')) return;
                        selectTag(full);
                    });
                    chip.addEventListener('contextmenu', (e) => {
                        e.preventDefault();
                        showTagContextMenu(e, chip.__fafoTag ?? activeTags[parseInt(chip.dataset.i, 10)]);
                    });
                    markTagDragSource(chip, { kind: 'chip', tag: full });
                });
                els.currentTags.querySelectorAll('button[data-i]').forEach((btn) => {
                    btn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        const i = parseInt(btn.dataset.i, 10);
                        const full = activeTags[i];
                        await removeTagFromVideoConfirmed(full);
                    });
                });
            }
        }
        renderTagLibrary();
        renderExtraTagHud();
        updateHiddenTagsButton();
        if ($('meta-hidden-panel') && !$('meta-hidden-panel').classList.contains('hidden')) {
            renderHiddenTagsPanel();
        }
    }

    async function bindToItem(item, index) {
        clearUntaggedPrompt();
        activeName = itemDisplayName(item);
        activeKey = await mediaKeyFor(item);
        const id = await identityForItem(item);
        let stored = (activeKey && mediaMeta[activeKey]) || null;
        // Exact fallback only (name+size or unique name) — no fuzzy includes
        if (!stored || (!(stored.tags && stored.tags.length) && !stored.pairId && !stored.rating)) {
            const byExact = globalThis.FAFOId?.findStoredMeta
                ? FAFOId.findStoredMeta(mediaMeta, {
                    key: activeKey,
                    name: activeName,
                    size: id?.size,
                    mtime: id?.mtime,
                })
                : findStoredByName(activeName);
            if (byExact?.meta) {
                stored = byExact.meta;
                // Prefer stable key from match so quick-panel saves stick
                if (byExact.key) activeKey = byExact.key;
            }
        }
        activeRating = stored?.rating || 0;
        activePairId = globalThis.FAFOId?.pairIdFromMeta
            ? FAFOId.pairIdFromMeta(stored || {})
            : (stored?.pairId || '');
        // Quick panel chips = user tags only (pair IDs / role stamps filtered out)
        activeTags = userTagsOnly(Array.isArray(stored?.tags) ? stored.tags : []);

        // Discover tags from toolbox catalog / file metadata — vocabulary only, no apply-count bump
        const remote = await fetchTagsForIdentity(id);
        let mediaDirty = false;
        if (remote) {
            const remoteUser = userTagsOnly(remote.tags || []);
            if (!activeTags.length && remoteUser.length) {
                activeTags = [...remoteUser];
                if (!activeRating && remote.rating) activeRating = remote.rating;
                if (activeKey) {
                    mediaMeta[activeKey] = {
                        ...(mediaMeta[activeKey] || {}),
                        rating: activeRating,
                        tags: [...activeTags],
                        name: activeName,
                        size: id?.size ?? null,
                        pairId: activePairId || mediaMeta[activeKey]?.pairId,
                        updated: Date.now(),
                    };
                    mediaDirty = true;
                }
            } else if (remoteUser.length) {
                ensureTagsKnown(remoteUser);
            }
        }

        // Ensure current clip is indexed so library totals + quick panel stick across plays
        if (activeKey) {
            const existing = mediaMeta[activeKey];
            if (!existing && (activeTags.length || activeRating || activePairId)) {
                mediaMeta[activeKey] = {
                    rating: activeRating,
                    tags: [...activeTags],
                    name: activeName,
                    size: id?.size ?? null,
                    pairId: activePairId || undefined,
                    updated: Date.now(),
                };
                mediaDirty = true;
            } else if (existing) {
                if (existing.size == null && id?.size != null) {
                    existing.size = id.size;
                    mediaDirty = true;
                }
                // Keep pairId / cleaned tags on the record
                const cleaned = userTagsOnly(existing.tags || []);
                if (cleaned.length !== (existing.tags || []).length) {
                    existing.tags = cleaned;
                    mediaDirty = true;
                }
                if (activePairId && !existing.pairId) {
                    existing.pairId = activePairId;
                    mediaDirty = true;
                }
            }
        }

        accumulateTagsFromMedia(activeTags);
        if (mediaDirty) await saveStore();

        renderMetaPanel();
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
    }

    function onTagInputKeydown(e) {
        const visible = els.suggest && !els.suggest.hidden;
        const items = visible ? [...els.suggest.querySelectorAll('[data-tag]')] : [];
        if (e.key === 'ArrowDown' && items.length) {
            e.preventDefault();
            suggestIndex = (suggestIndex + 1) % items.length;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'ArrowUp' && items.length) {
            e.preventDefault();
            suggestIndex = suggestIndex <= 0 ? items.length - 1 : suggestIndex - 1;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (suggestIndex >= 0 && items[suggestIndex]) pickSuggestion(items[suggestIndex].dataset.tag);
            else addTagsFromInput();
            return;
        }
        if (e.key === 'Escape') {
            hideSuggestions();
            els.tagInput?.blur();
            return;
        }
        if (e.key === 'Tab' && suggestIndex >= 0 && items[suggestIndex]) {
            e.preventDefault();
            pickSuggestion(items[suggestIndex].dataset.tag);
        }
    }

    function initTagLibraryResize() {
        const handle = $('meta-tag-resize');
        if (!handle || !els.library) return;

        applyTagLibraryHeight();

        const onMove = (clientY) => {
            if (!resizeDragging) return;
            const rect = els.library.getBoundingClientRect();
            const next = Math.round(clientY - rect.top);
            tagLibraryHeight = Math.max(80, Math.min(Math.round(window.innerHeight * 0.55), next));
            els.library.style.height = tagLibraryHeight + 'px';
        };

        const endDrag = () => {
            if (!resizeDragging) return;
            resizeDragging = false;
            handle.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            capturePanelSize();
            scheduleLayoutSave();
        };

        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            resizeDragging = true;
            handle.classList.add('dragging');
            document.body.style.cursor = 'ns-resize';
            document.body.style.userSelect = 'none';
        });
        document.addEventListener('mousemove', (e) => {
            if (resizeDragging) onMove(e.clientY);
        });
        document.addEventListener('mouseup', endDrag);

        handle.addEventListener('touchstart', (e) => {
            if (!e.touches?.[0]) return;
            e.preventDefault();
            resizeDragging = true;
            handle.classList.add('dragging');
        }, { passive: false });
        document.addEventListener('touchmove', (e) => {
            if (resizeDragging && e.touches?.[0]) onMove(e.touches[0].clientY);
        }, { passive: true });
        document.addEventListener('touchend', endDrag);
    }

    function wireUI() {
        els = {
            toggle: $('meta-toggle'),
            panel: $('meta-panel'),
            filename: $('meta-filename'),
            status: $('meta-status'),
            stars: $('meta-stars'),
            currentTags: $('meta-current-tags'),
            tagInput: $('meta-tag-input'),
            tagAdd: $('meta-tag-add'),
            suggest: $('meta-tag-suggest'),
            library: $('meta-tag-library'),
            tagFilter: $('meta-tag-filter'),
            tagCount: $('meta-tag-count'),
            prev: $('meta-prev'),
            next: $('meta-next'),
            collapse: $('meta-collapse'),
            skipTagged: $('meta-skip-tagged'),
        };
        if (!els.toggle) return;

        els.toggle.addEventListener('click', () => setMetaPanelOpen(!metaPanelOpen));
        els.collapse?.addEventListener('click', () => setMetaPanelOpen(false));
        els.prev?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(-1));
        els.next?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(1));
        els.tagAdd?.addEventListener('click', () => addTagsFromInput());
        els.tagInput?.addEventListener('keydown', onTagInputKeydown);
        els.tagInput?.addEventListener('input', () => {
            suggestIndex = -1;
            renderTagSuggestions(els.tagInput.value);
        });
        els.tagInput?.addEventListener('focus', () => renderTagSuggestions(els.tagInput.value));
        els.tagFilter?.addEventListener('input', () => renderTagLibrary());
        els.skipTagged?.addEventListener('click', () => setSkipTaggedMode(!skipTaggedMode));
        $('meta-count-mode')?.addEventListener('click', () => {
            setCountDisplayMode(countDisplayMode === 'total' ? 'session' : 'total');
        });
        $('meta-rebuild-counts')?.addEventListener('click', () => {
            if (confirm('Rebuild Uses counts from library tags?\n\nThis sets each tag’s Uses # to how many files currently have it.')) {
                rebuildApplyCountsFromLibrary();
            }
        });
        $('meta-clear-tags')?.addEventListener('click', () => clearAllTagsOnVideo());
        $('meta-hidden-tags-btn')?.addEventListener('click', () => {
            const panel = $('meta-hidden-panel');
            const currentlyClosed = !panel || panel.classList.contains('hidden');
            setHiddenPanelOpen(currentlyClosed);
        });
        $('meta-hidden-close')?.addEventListener('click', () => setHiddenPanelOpen(false));
        $('meta-hidden-restore-all')?.addEventListener('click', () => {
            if (!excludedTags.length) return;
            if (confirm(`Restore all ${excludedTags.length} hidden tag(s) to the list?`)) {
                unexcludeAllTags();
            }
        });
        $('meta-apply-next')?.addEventListener('click', () => {
            applyAndNextMode = !applyAndNextMode;
            updateApplyNextBtn();
            chrome.storage.local.set({ fafoApplyAndNext: applyAndNextMode }).catch(() => {});
            if (els.status) {
                els.status.textContent = applyAndNextMode
                    ? 'Apply+Next ON — tagging advances to next clip'
                    : 'Apply+Next off';
            }
        });
        $('meta-export-backup')?.addEventListener('click', () => exportTagsBackup());
        $('meta-dock-pos')?.addEventListener('click', () => cycleDockPos());
        $('meta-undock-move')?.addEventListener('click', () => undockTagsForMove());
        $('meta-stick-layout')?.addEventListener('click', () => setStickLayout(!stickLayout));
        $('meta-ui-scale')?.addEventListener('click', () => cycleUiScale());
        $('meta-size-down')?.addEventListener('click', () => nudgePanelSize(-1));
        $('meta-size-up')?.addEventListener('click', () => nudgePanelSize(1));
        $('meta-layout-reset')?.addEventListener('click', () => {
            resetLayout();
        });
        $('meta-split-toggle')?.addEventListener('click', () => toggleLibrarySplit());
        $('meta-split-toggle-2')?.addEventListener('click', () => toggleLibrarySplit());
        $('meta-lib-collapse')?.addEventListener('click', () => {
            const lib = $('meta-library-panel');
            if (!lib) return;
            lib.classList.add('collapsed');
            lib.dataset.userHidden = '1';
            lib.setAttribute('aria-hidden', 'true');
        });

        initTagDndDelegation();
        initTagLibraryResize();
        initPanelDrag();
        initLibPanelDrag();
        initPanelResizeObserver();
        initEdgeResize($('meta-panel'), { isMainPanel: true, minW: 260, minH: 180 });
        initEdgeResize($('meta-library-panel'), { isMainPanel: false, minW: 240, minH: 160 });
        applyDockLayout();
        if (window.__fafoMetaSplitPending) setLibrarySplit(true);
        // Sticky quick panel: reopen if it was open last session
        if (window.__fafoMetaPanelOpenPending) setMetaPanelOpen(true);
        updateSkipTaggedBtn();
        updateApplyNextBtn();
        syncCountModeToggle();
        renderRecentTags();
        renderExtraTagHud();
        updateHiddenTagsButton();
        startExplorerPoll();
        updateBackupStatusUi();
        $('meta-eset-apply')?.addEventListener('click', () => {
            applyExtraTagBank(extraLiveBank);
        });

        // Explorer status = Windows file Tags/Rating companion (not library permissions)
        $('meta-explorer-status')?.addEventListener('click', () => {
            if (explorerOnline) {
                syncExplorerNow({ showHelpIfOffline: false });
            } else {
                setExplorerHelpOpen(true);
                syncExplorerNow({ showHelpIfOffline: true });
            }
        });
        $('meta-explorer-sync')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            syncExplorerNow({ showHelpIfOffline: true });
        });
        $('meta-explorer-help-retry')?.addEventListener('click', () => {
            syncExplorerNow({ showHelpIfOffline: true });
        });
        $('meta-explorer-help-close')?.addEventListener('click', () => {
            setExplorerHelpOpen(false);
        });

        document.addEventListener('click', (e) => {
            if (els.suggest && !els.suggest.contains(e.target) && e.target !== els.tagInput) {
                hideSuggestions();
            }
            if (ctxMenu && !ctxMenu.contains(e.target)) hideCtxMenu();
        });

        // Live bank switching for BOTH hotkeys and E-set (hold Shift / Ctrl / Alt)
        const onModKeys = (e) => {
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
            syncLiveBank(e);
            // E-set must track the same modifiers (was only wired from script.js keydown)
            syncExtraBankFromEvent(e);
        };
        document.addEventListener('keydown', onModKeys, true);
        document.addEventListener('keyup', onModKeys, true);
        window.addEventListener('blur', () => {
            liveBank = pinnedBank;
            renderHotkeyBar();
            updateBankIndicator();
            extraLiveBank = extraPinnedBank;
            renderExtraTagHud();
        });

        document.addEventListener('keydown', (e) => {
            const t = e.target;
            const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
            if (typing) return;

            // Tab / Shift+Tab: roll hotkey banks only when tags panel is open
            // (avoids stealing browser focus elsewhere)
            if (e.key === 'Tab' && metaPanelOpen) {
                e.preventDefault();
                cycleHotkeyBank(e.shiftKey ? -1 : 1);
                return;
            }

            // Keep live bank in sync even when we handle the key
            syncLiveBank(e);

            // Delete / Backspace: remove selected tag (confirm)
            if ((e.key === 'Delete' || e.key === 'Backspace') && selectedTag && metaPanelOpen) {
                e.preventDefault();
                removeTagFromVideoConfirmed(selectedTag);
                return;
            }

            // Chord: ` / ~ then 1–9 / 0 applies hotkey (modifiers select bank)
            if (e.key === '`' || e.key === '~' || e.code === 'Backquote') {
                e.preventDefault();
                bracketChord = true;
                clearTimeout(bracketTimer);
                bracketTimer = setTimeout(() => { bracketChord = false; }, 2000);
                const bName = BANK_LABELS[liveBank] || 'Base';
                if (els.status) els.status.textContent = `Hotkey (${bName}): press 1–9 or 0…`;
                return;
            }

            const slot = digitToSlot(e.key);
            if (slot >= 0) {
                // Prefer held modifiers; otherwise use the pinned/Tab bank
                const modBank = bankFromEvent(e);
                const bank = modBank > 0 ? modBank : liveBank;

                // ` chord + digit → apply that bank/slot
                if (bracketChord) {
                    e.preventDefault();
                    bracketChord = false;
                    clearTimeout(bracketTimer);
                    applyHotkeyTag(bank, slot);
                    return;
                }

                // Modifier banks: hold Shift (etc.) + digit to apply without backtick
                if (modBank > 0) {
                    e.preventDefault();
                    applyHotkeyTag(modBank, slot);
                    return;
                }

                // Pinned bank (from Tab) is non-base: digits apply that bank without `
                if (liveBank > 0 && !metaPanelOpen) {
                    e.preventDefault();
                    applyHotkeyTag(liveBank, slot);
                    return;
                }
                // Panel open + base bank: 1–5 rate; 0 clears. Non-base + panel: still apply hotkey
                if (metaPanelOpen && liveBank > 0) {
                    e.preventDefault();
                    applyHotkeyTag(liveBank, slot);
                    return;
                }

                // Base bank without chord: 1–5 rate when panel open; 0 clears rating
                if (metaPanelOpen && !bracketChord) {
                    if (slot <= 4) {
                        setRating(slot + 1);
                        return;
                    }
                    if (e.key === '0') {
                        setRating(0);
                        return;
                    }
                }
            }

            if (e.key === 't' || e.key === 'T') {
                e.preventDefault();
                setMetaPanelOpen(!metaPanelOpen);
                if (metaPanelOpen) setTimeout(() => els.tagInput?.focus(), 40);
            }
        });

        renderMetaPanel();
        renderHotkeyBar();
        updateBankIndicator();
    }

    async function init() {
        await loadStore();
        wireUI();
        harvestTagsFromServer().catch(() => {});
        const item = window.FAFOPlayer?.getCurrentItem?.();
        if (item) await bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
    }

    /** True when the current clip has no tags yet (rating alone does not count). */
    function isUntagged() {
        return !activeTags || activeTags.length === 0;
    }

    function notifyEndNeedsTag() {
        const dock = $('meta-dock');
        dock?.classList.add('untagged-prompt');
        setMetaPanelOpen(true);
        if (els.status) {
            els.status.textContent = skipTaggedMode
                ? 'Looping (skip tagged) — tag if needed, then press Next'
                : 'Untagged · looping — add tags, then press Next to continue';
        }
        if (els.toggle) els.toggle.title = 'Tag this media (T) · Next to leave clip';
    }

    function clearUntaggedPrompt() {
        $('meta-dock')?.classList.remove('untagged-prompt');
        if (els.toggle) els.toggle.title = 'Rate & tag this media (T)';
        try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
    }

    function getExtraTag(bank, slot) {
        return extraTagBanks[bank]?.[slot] || '';
    }

    function setExtraTag(bank, slot, tag) {
        if (!extraTagBanks[bank]) extraTagBanks[bank] = Array(EXTRA_SLOTS).fill('');
        extraTagBanks[bank][slot] = normalizeTag(tag || '');
    }

    function setExtraLiveBank(bank) {
        extraLiveBank = Math.max(0, Math.min(EXTRA_BANKS - 1, bank | 0));
        renderExtraTagHud();
    }

    function getExtraLiveBank() {
        return extraLiveBank;
    }

    function syncExtraBankFromEvent(e) {
        let next = extraPinnedBank;
        if (e && (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey)) {
            next = bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
        } else if (!e) {
            next = extraPinnedBank;
        }
        if (next === extraLiveBank) return;
        extraLiveBank = next;
        renderExtraTagHud();
    }

    async function applyExtraTagBank(bank) {
        bank = Math.max(0, Math.min(EXTRA_BANKS - 1, bank == null ? extraLiveBank : bank | 0));
        extraLiveBank = bank;
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active for E-set';
            setMetaPanelOpen(true);
            return { applied: 0 };
        }
        const row = extraTagBanks[bank] || [];
        const toApply = userTagsOnly(row.filter(Boolean));
        if (!toApply.length) {
            if (els.status) {
                els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]} empty — right-click slots on the player to assign`;
            }
            renderExtraTagHud();
            return { applied: 0 };
        }
        const newly = [];
        toApply.forEach((t) => {
            if (!activeTags.some((x) => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            }
        });
        if (!newly.length) {
            if (els.status) {
                els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}: already on this clip (${toApply.length})`;
            }
            renderMetaPanel();
            renderExtraTagHud();
            return { applied: 0, already: toApply.length };
        }
        await persistActiveMeta({ touchedTags: newly });
        if (els.status) {
            els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]} applied +${newly.length}: ${newly.join(', ')}`;
        }
        renderExtraTagHud();
        return { applied: newly.length, tags: newly };
    }

    async function toggleExtraSlotTag(bank, slot) {
        const tag = getExtraTag(bank, slot);
        if (!tag) {
            if (els.status) els.status.textContent = `E-set slot ${slot + 1} empty — right-click to assign`;
            return;
        }
        if (!activeKey) {
            setMetaPanelOpen(true);
            return;
        }
        await toggleLibraryTag(tag);
        renderExtraTagHud();
    }

    function showExtraSlotAssignMenu(e, bank, slot) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const current = getExtraTag(bank, slot);
        const candidates = tagLibrary.filter((t) => !isHiddenFromUi(t)).slice(0, 30);
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu meta-ctx-menu-wide';
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">E-set · ${escapeHtml(EXTRA_BANK_LABELS[bank])} · slot ${slot + 1}</div>
            <div class="meta-ctx-hint">${current ? 'Currently: ' + escapeHtml(current) : 'Empty — pick a tag (not hotkeys)'}</div>
            ${candidates.length
                ? candidates.map((t) => {
                    const on = current && current.toLowerCase() === t.toLowerCase();
                    return `<button type="button" data-eset-assign="${escapeAttr(t)}" class="${on ? 'on' : ''}">${escapeHtml(t)}</button>`;
                }).join('')
                : '<div class="meta-ctx-hint">No tags yet — add some in the Tags panel first</div>'}
            <div class="meta-ctx-hint" style="margin-top:6px">Or type a new tag:</div>
            <div style="display:flex;gap:4px;padding:4px">
                <input type="text" id="eset-custom-input" placeholder="new tag…" style="flex:1;min-width:0;background:#000;border:1px solid #333;color:#fff;border-radius:6px;padding:6px 8px;font-size:12px">
                <button type="button" data-eset-custom="1" class="meta-skip-btn">Set</button>
            </div>
            ${current ? '<button type="button" data-eset-clear="1" class="meta-ctx-clear">Clear slot</button>' : ''}
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 260);
        const y = Math.min(e.clientY, window.innerHeight - 360);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        ctxMenu.querySelectorAll('[data-eset-assign]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                setExtraTag(bank, slot, btn.dataset.esetAssign);
                await saveStore();
                hideCtxMenu();
                renderExtraTagHud();
                if (els.status) els.status.textContent = `E-set ${EXTRA_BANK_LABELS[bank]}[${slot + 1}] = ${btn.dataset.esetAssign}`;
            });
        });
        const customSet = async () => {
            const inp = ctxMenu.querySelector('#eset-custom-input');
            const t = normalizeTag(inp?.value || '');
            if (!t) return;
            setExtraTag(bank, slot, t);
            ensureTagsKnown([t]);
            await saveStore();
            hideCtxMenu();
            renderExtraTagHud();
        };
        ctxMenu.querySelector('[data-eset-custom]')?.addEventListener('click', customSet);
        ctxMenu.querySelector('#eset-custom-input')?.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') { ev.preventDefault(); customSet(); }
        });
        ctxMenu.querySelector('[data-eset-clear]')?.addEventListener('click', async () => {
            setExtraTag(bank, slot, '');
            await saveStore();
            hideCtxMenu();
            renderExtraTagHud();
        });
        setTimeout(() => ctxMenu.querySelector('#eset-custom-input')?.focus(), 30);
    }

    function renderExtraTagHud() {
        // Prefer Tags-panel hosts; fall back to any leftover HUD nodes
        const banksEl = $('meta-eset-banks') || $('hud-eset-banks');
        const slotsEl = $('meta-eset-slots') || $('hud-eset-slots');
        if (banksEl) {
            banksEl.innerHTML = EXTRA_BANK_LABELS.map((name, b) =>
                `<button type="button" class="hud-eset-bank ${b === extraLiveBank ? 'active' : ''}" data-eset-bank="${b}">${escapeHtml(name)}</button>`
            ).join('');
            banksEl.querySelectorAll('[data-eset-bank]').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    extraPinnedBank = parseInt(btn.dataset.esetBank, 10);
                    extraLiveBank = extraPinnedBank;
                    renderExtraTagHud();
                });
            });
        }
        if (slotsEl) {
            const bank = extraLiveBank;
            slotsEl.innerHTML = Array.from({ length: EXTRA_SLOTS }, (_, s) => {
                const t = getExtraTag(bank, s);
                const on = t && isTagOnVideo(t);
                const cls = ['hud-eset-slot', t ? 'set' : '', on ? 'on-video' : ''].filter(Boolean).join(' ');
                return `<button type="button" class="${cls}" data-eset-slot="${s}" data-tag="${escapeAttr(t || '')}" title="${t ? escapeAttr(t + ' · drag · click toggle · right-click') : 'Drop ONE tag here · right-click to assign'}">
                    <span class="eset-n">${s === 9 ? '0' : s + 1}</span>${t ? escapeHtml(t) : '—'}
                </button>`;
            }).join('');
            slotsEl.querySelectorAll('[data-eset-slot]').forEach((btn) => {
                const s = parseInt(btn.dataset.esetSlot, 10);
                const tag = getExtraTag(bank, s);
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    if (tagDragMoved) return;
                    toggleExtraSlotTag(extraLiveBank, s);
                });
                btn.addEventListener('contextmenu', (e) => showExtraSlotAssignMenu(e, extraLiveBank, s));
                if (tag) markTagDragSource(btn, { kind: 'eset', tag, bank, slot: s });
            });
        }
        const filled = (extraTagBanks[extraLiveBank] || []).filter(Boolean).length;
        const label = filled ? `E-set · ${filled}` : 'E-set';
        const title = `Apply E-set “${EXTRA_BANK_LABELS[extraLiveBank]}” (${filled}/10) · key E + modifiers`;
        ['meta-eset-apply', 'hud-extra-apply', 'hud-eset-apply'].forEach((id) => {
            const applyBtn = $(id);
            if (!applyBtn) return;
            applyBtn.textContent = id === 'meta-eset-apply' ? (filled ? `Apply bank (${filled})` : 'Apply bank') : label;
            applyBtn.title = title;
        });
    }

    window.FAFOMeta = {
        init,
        bindToItem,
        setMetaPanelOpen,
        open: () => setMetaPanelOpen(true),
        ensureTagsKnown,
        getTagLibrary: () => tagLibrary.slice(),
        getSessionTagCounts: () => ({ ...sessionTagCount }),
        getLibraryTagCounts: () => ({ ...libraryTagCount }),
        isSessionCountMode: () => countDisplayMode === 'session',
        getCountDisplayMode: () => countDisplayMode,
        setCountDisplayMode,
        isUntagged,
        /** @deprecated alias */
        needsTagging: isUntagged,
        notifyEndNeedsTag,
        clearUntaggedPrompt,
        getActiveTags: () => activeTags.slice(),
        getActiveRating: () => activeRating,
        isSkipTaggedMode,
        setSkipTaggedMode,
        tagCountForItem,
        rebuildApplyCountsFromLibrary,
        applyExtraTagBank,
        setExtraLiveBank,
        getExtraLiveBank,
        syncExtraBankFromEvent,
        renderExtraTagHud,
        getExtraTagBanks: () => extraTagBanks.map((r) => r.slice()),
        undockTagsForMove,
        resetLayout,
        refreshLoopMode: () => {
            try { window.FAFOPlayer?.refreshLoopMode?.(); } catch (_) {}
        },
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => init());
    } else {
        // Player may still be initializing — retry bind shortly
        init().then(() => {
            setTimeout(() => {
                const item = window.FAFOPlayer?.getCurrentItem?.();
                if (item) bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
            }, 800);
        });
    }
})();
