/**
 * FAFO Chrome Art — folder of images for new-tab background + panel textures.
 *
 * Default behavior:
 *   - Background: random image from the folder on every apply / new tab
 *   - Panels: either random too, OR a user-picked crop locked as panel default
 *
 * Toggle "Lock panels to my crop" → pick image → drag crop → save as default.
 * Only the background keeps rotating when panels are locked.
 */
(function (global) {
    'use strict';

    const ART_FOLDER_ID = 'chrome-art';
    const IMG_RE = /\.(jpe?g|png|webp|gif|bmp)$/i;
    const blobUrls = [];

    const DEFAULTS = {
        enabled: true,
        dim: 0.42,
        bgOpacity: 0.55,
        bannerOpacity: 0.5,
        sideOpacity: 0.34,
        panelOpacity: 0.3,
        glowUnderArt: 0.35,

        /** Background always randomizes when true (recommended). */
        bgRandom: true,
        /** Optional fixed bg filename when bgRandom is false */
        bgName: '',

        /**
         * panelMode:
         *   'random' — pick random folder images for side/tags/library/hud
         *   'locked' — use saved crop (panelLock.dataUrl) for all panels
         */
        panelMode: 'random',
        /**
         * panelLock: { dataUrl, name, savedAt } — cropped JPEG/WebP for panels
         */
        panelLock: null,
        /** Banner follows panels when locked; otherwise random */
        bannerFollowPanels: true,
        bannerName: '',

        /** Random crop zoom for random (non-locked) panel pieces */
        randomSlices: true,
        /** @deprecated — mapped to panelMode / bgRandom for older configs */
        usePrimaryEverywhere: false,
        randomFiles: true,
        sideName: '',
        panelName: '',

        /** Tiled CSS wallpaper when no photo folder (or as a stand-alone look). */
        tileFallback: true,
        tilePattern: 'circuit',
        tileScale: 28,
    };

    function revokeAll() {
        while (blobUrls.length) {
            try { URL.revokeObjectURL(blobUrls.pop()); } catch (_) {}
        }
    }

    function normalizeConfig(raw) {
        const cfg = { ...DEFAULTS, ...(raw && typeof raw === 'object' ? raw : {}) };
        // Migrate older flags
        if (raw && raw.panelMode == null) {
            if (raw.usePrimaryEverywhere && raw.bgName) {
                cfg.panelMode = 'random';
                cfg.bgRandom = !raw.bgName;
            }
            if (raw.usePrimaryEverywhere === true && !raw.panelLock) {
                // old default: same art everywhere with slices — treat as random slices of random bg
                cfg.bgRandom = true;
                cfg.panelMode = 'random';
            }
        }
        if (cfg.panelLock && typeof cfg.panelLock === 'object' && cfg.panelLock.dataUrl) {
            // ok
        } else {
            cfg.panelLock = null;
        }
        if (cfg.panelMode !== 'locked') cfg.panelMode = 'random';
        cfg.tileFallback = cfg.tileFallback !== false;
        const tileIds = (global.FAFOTilePatterns?.CATALOG || []).map((p) => p.id);
        cfg.tilePattern = tileIds.includes(cfg.tilePattern) ? cfg.tilePattern : (cfg.tilePattern || 'circuit');
        const ts = Number(cfg.tileScale);
        cfg.tileScale = Number.isFinite(ts) ? Math.max(8, Math.min(64, Math.round(ts))) : 28;
        return cfg;
    }

    async function readConfig() {
        try {
            const { fafoChromeArt } = await chrome.storage.local.get('fafoChromeArt');
            return normalizeConfig(fafoChromeArt);
        } catch {
            return { ...DEFAULTS };
        }
    }

    async function writeConfig(partial) {
        const cur = await readConfig();
        const next = normalizeConfig({ ...cur, ...partial });
        await chrome.storage.local.set({ fafoChromeArt: next });
        return next;
    }

    async function getArtFolder(db) {
        if (!global.FAFOLibrary?.listFolders) return null;
        try {
            if (!db) db = await FAFOLibrary.openDB();
            const folders = await FAFOLibrary.listFolders(db);
            return folders.find((f) => f.id === ART_FOLDER_ID || f.kind === 'chrome-art') || null;
        } catch {
            return null;
        }
    }

    async function listArtImages(folder) {
        if (!folder?.handle) return [];
        const ok = await FAFOLibrary.ensurePermission(folder.handle, 'read');
        if (!ok) return [];
        const out = [];
        try {
            for await (const entry of folder.handle.values()) {
                if (entry.kind === 'file' && IMG_RE.test(entry.name)) out.push(entry);
            }
        } catch (e) {
            console.warn('FAFO chrome art list', e);
        }
        out.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
        return out;
    }

    async function fileToUrl(fileHandle) {
        const file = await fileHandle.getFile();
        const url = URL.createObjectURL(file);
        blobUrls.push(url);
        return url;
    }

    function pickByName(handles, name, fallbackIndex) {
        if (name) {
            const hit = handles.find((h) => h.name.toLowerCase() === String(name).toLowerCase());
            if (hit) return hit;
            const soft = handles.find((h) => h.name.toLowerCase().includes(String(name).toLowerCase()));
            if (soft) return soft;
        }
        if (fallbackIndex != null && handles[fallbackIndex]) return handles[fallbackIndex];
        return null;
    }

    function pickRandom(handles, excludeName) {
        if (!handles.length) return null;
        const pool = excludeName
            ? handles.filter((h) => h.name.toLowerCase() !== String(excludeName).toLowerCase())
            : handles.slice();
        const list = pool.length ? pool : handles;
        return list[Math.floor(Math.random() * list.length)];
    }

    function randomSliceStyle() {
        const size = 140 + Math.floor(Math.random() * 120);
        const x = Math.floor(Math.random() * 100);
        const y = Math.floor(Math.random() * 100);
        return {
            backgroundSize: `${size}% auto`,
            backgroundPosition: `${x}% ${y}%`,
        };
    }

    function setLayerBg(el, url, opacity, sliceStyle) {
        if (!el) return;
        if (!url) {
            el.style.backgroundImage = '';
            el.style.removeProperty('background-size');
            el.style.removeProperty('background-position');
            el.classList.add('hidden');
            el.setAttribute('aria-hidden', 'true');
            return;
        }
        el.style.backgroundImage = `url("${url}")`;
        el.style.opacity = String(opacity);
        if (sliceStyle) {
            el.style.backgroundSize = sliceStyle.backgroundSize || 'cover';
            el.style.backgroundPosition = sliceStyle.backgroundPosition || 'center center';
        } else {
            el.style.backgroundSize = 'cover';
            el.style.backgroundPosition = 'center center';
        }
        el.classList.remove('hidden');
        el.setAttribute('aria-hidden', 'false');
    }

    function applySurfaceArt(el, className, url, opacity, sliceStyle) {
        if (!el) return;
        if (!url) {
            el.classList.remove(className);
            el.style.removeProperty('--fafo-art-url');
            el.style.removeProperty('--fafo-art-opacity');
            el.style.removeProperty('--fafo-art-size');
            el.style.removeProperty('--fafo-art-pos');
            return;
        }
        el.classList.add(className);
        el.style.setProperty('--fafo-art-url', `url("${url}")`);
        el.style.setProperty('--fafo-art-opacity', String(opacity));
        el.style.setProperty('--fafo-art-size', sliceStyle?.backgroundSize || 'cover');
        el.style.setProperty('--fafo-art-pos', sliceStyle?.backgroundPosition || 'center center');
    }

    function applyTileFallback(cfg, bgEl) {
        const body = document.body;
        if (!bgEl || cfg?.tileFallback === false) {
            body?.classList.remove('fafo-chrome-tiled');
            return false;
        }
        const TP = global.FAFOTilePatterns;
        const TC = global.FAFOTagColors;
        const id = cfg.tilePattern || 'circuit';
        const scale = Math.round(Number(cfg.tileScale) || 28);
        let spec = null;
        if (TP && typeof TP.wallpaperSpec === 'function') {
            spec = TP.wallpaperSpec(id, { scale, alphaA: 0.5, alphaB: 0.34, alphaC: 0.22 });
        } else if (TC && typeof TC.buildTilePattern === 'function') {
            spec = TC.buildTilePattern({
                tilePattern: id,
                tileScale: scale,
                fillA: '#00e5ff',
                fillB: '#7c5cff',
                fillC: '#00ffa8',
                fillAlpha: 0.5,
                fillAlphaB: 0.34,
                fillAlphaC: 0.22,
                fillColorCount: 3,
            });
        }
        if (!spec || !spec.image) {
            body?.classList.remove('fafo-chrome-tiled');
            return false;
        }
        bgEl.classList.remove('hidden');
        bgEl.style.backgroundImage = spec.image;
        bgEl.style.backgroundSize = spec.size || `${scale}px ${scale}px`;
        bgEl.style.backgroundRepeat = spec.repeat || 'repeat';
        bgEl.style.backgroundPosition = spec.position || '0 0';
        /* Never use the tile's paint color as a solid sheet — that went fully
           opaque over Options after a color change. Keep a dark under-fill. */
        bgEl.style.backgroundColor = '#05060a';
        const op = Number(cfg.bgOpacity);
        bgEl.style.opacity = String(Number.isFinite(op) ? Math.max(0.12, Math.min(0.72, op)) : 0.55);
        body?.classList.add('fafo-chrome-tiled');
        return true;
    }

    function clearTileFallback(bgEl) {
        document.body?.classList.remove('fafo-chrome-tiled');
        if (!bgEl) return;
        bgEl.style.removeProperty('background-size');
        bgEl.style.removeProperty('background-repeat');
        bgEl.style.removeProperty('background-position');
        bgEl.style.removeProperty('background-color');
    }

    async function apply(opts = {}) {
        const cfg = normalizeConfig(opts.config || (await readConfig()));
        const root = document.documentElement;
        const body = document.body;
        const bgEl = document.getElementById('fafo-chrome-bg');
        const bannerEl = document.getElementById('fafo-chrome-banner');

        revokeAll();

        if (!cfg.enabled) {
            body?.classList.remove('fafo-chrome-art');
            root.style.removeProperty('--fafo-chrome-dim');
            root.style.removeProperty('--fafo-chrome-glow-under');
            setLayerBg(bannerEl, '', 0);
            const tiled = applyTileFallback(cfg, bgEl);
            if (!tiled) {
                setLayerBg(bgEl, '', 0);
                clearTileFallback(bgEl);
            }
            [
                document.getElementById('meta-dock'),
                document.getElementById('meta-panel'),
                document.getElementById('meta-library-panel'),
                document.getElementById('player-hud'),
            ].forEach((el) => {
                el?.classList.remove('fafo-art-side', 'fafo-art-panel', 'fafo-art-surface');
            });
            return { ok: true, enabled: false, tiled };
        }

        let db = null;
        try { db = await FAFOLibrary.openDB(); } catch { /* */ }
        const folder = await getArtFolder(db);
        if (!folder) {
            body?.classList.remove('fafo-chrome-art');
            setLayerBg(bannerEl, '', 0);
            const tiled = applyTileFallback(cfg, bgEl);
            if (!tiled) {
                setLayerBg(bgEl, '', 0);
                clearTileFallback(bgEl);
            }
            return { ok: true, enabled: true, images: 0, note: 'no-folder', tiled };
        }

        const handles = await listArtImages(folder);
        if (!handles.length) {
            body?.classList.remove('fafo-chrome-art');
            const tiled = applyTileFallback(cfg, bgEl);
            if (!tiled) clearTileFallback(bgEl);
            return { ok: true, enabled: true, images: 0, note: 'empty', tiled };
        }

        const panelsLocked = cfg.panelMode === 'locked' && cfg.panelLock?.dataUrl;
        const doSlices = cfg.randomSlices !== false;

        // --- Background: random every load (default), or fixed name ---
        let bgH = null;
        if (cfg.bgRandom !== false) {
            bgH = pickRandom(handles, null);
        } else {
            bgH = pickByName(handles, cfg.bgName, 0) || pickRandom(handles, null);
        }

        // --- Panels: locked crop OR random files ---
        let panelUrl = '';
        let sideUrl = '';
        let bannerUrl = '';
        let panelSource = 'none';
        let bgUrl = '';

        try {
            if (bgH) bgUrl = await fileToUrl(bgH);

            if (panelsLocked) {
                panelUrl = cfg.panelLock.dataUrl;
                sideUrl = panelUrl;
                bannerUrl = cfg.bannerFollowPanels !== false
                    ? panelUrl
                    : (cfg.bannerName
                        ? await fileToUrl(pickByName(handles, cfg.bannerName, null) || pickRandom(handles, bgH?.name))
                        : await fileToUrl(pickRandom(handles, bgH?.name) || bgH));
                panelSource = 'locked-crop';
            } else {
                const urlCache = new Map();
                if (bgH) urlCache.set(bgH.name, bgUrl);
                const urlFor = async (h) => {
                    if (!h) return '';
                    if (urlCache.has(h.name)) return urlCache.get(h.name);
                    const u = await fileToUrl(h);
                    urlCache.set(h.name, u);
                    return u;
                };
                const sideH = cfg.sideName
                    ? pickByName(handles, cfg.sideName, null) || pickRandom(handles, bgH?.name)
                    : pickRandom(handles, bgH?.name);
                const panelH = cfg.panelName
                    ? pickByName(handles, cfg.panelName, null) || pickRandom(handles, sideH?.name)
                    : pickRandom(handles, sideH?.name || bgH?.name);
                const bannerH = cfg.bannerName
                    ? pickByName(handles, cfg.bannerName, null) || pickRandom(handles, null)
                    : pickRandom(handles, panelH?.name);
                sideUrl = await urlFor(sideH);
                panelUrl = await urlFor(panelH);
                bannerUrl = await urlFor(bannerH);
                panelSource = 'random';
            }
        } catch (e) {
            console.warn('FAFO chrome art load', e);
        }

        const dim = Math.max(0.1, Math.min(0.85, Number(cfg.dim) ?? DEFAULTS.dim));
        const glowUnder = Math.max(0.1, Math.min(1, Number(cfg.glowUnderArt) ?? DEFAULTS.glowUnderArt));
        root.style.setProperty('--fafo-chrome-dim', String(dim));
        root.style.setProperty('--fafo-chrome-glow-under', String(glowUnder));
        body?.classList.add('fafo-chrome-art');

        const bgOp = Math.max(0.12, Math.min(0.95, Number(cfg.bgOpacity) ?? DEFAULTS.bgOpacity));
        const banOp = Math.max(0.08, Math.min(0.95, Number(cfg.bannerOpacity) ?? DEFAULTS.bannerOpacity));
        const sideOp = Math.max(0.05, Math.min(0.85, Number(cfg.sideOpacity) ?? DEFAULTS.sideOpacity));
        const panelOp = Math.max(0.05, Math.min(0.85, Number(cfg.panelOpacity) ?? DEFAULTS.panelOpacity));

        // Full-bleed random background — cover, no tight crop
        if (bgUrl) {
            clearTileFallback(bgEl);
            setLayerBg(bgEl, bgUrl, bgOp, null);
        } else {
            const tiled = applyTileFallback(cfg, bgEl);
            if (!tiled) setLayerBg(bgEl, '', 0);
        }
        setLayerBg(
            bannerEl,
            bannerUrl,
            banOp,
            !panelsLocked && doSlices && bannerUrl ? randomSliceStyle() : null
        );

        const dock = document.getElementById('meta-dock');
        const panel = document.getElementById('meta-panel');
        const lib = document.getElementById('meta-library-panel');
        const hud = document.getElementById('player-hud');

        // Locked panels: fixed cover crop (user already cropped). Random: optional slices.
        const sideSlice = !panelsLocked && doSlices && sideUrl ? randomSliceStyle() : null;
        const panelSlice = !panelsLocked && doSlices && panelUrl ? randomSliceStyle() : null;
        const hudSlice = !panelsLocked && doSlices && panelUrl ? randomSliceStyle() : null;

        applySurfaceArt(dock, 'fafo-art-side', sideUrl, sideOp, sideSlice);
        applySurfaceArt(panel, 'fafo-art-panel', panelUrl, panelOp, panelSlice);
        applySurfaceArt(lib, 'fafo-art-panel', panelUrl, panelOp, panelSlice);
        applySurfaceArt(hud, 'fafo-art-surface', panelUrl || sideUrl || bgUrl, Math.min(panelOp, 0.22), hudSlice);

        return {
            ok: true,
            enabled: true,
            images: handles.length,
            names: handles.map((h) => h.name),
            used: {
                bg: bgH?.name || null,
                bgRandom: cfg.bgRandom !== false,
                panelMode: cfg.panelMode,
                panelSource,
                panelLockName: cfg.panelLock?.name || null,
                slices: !!(doSlices && !panelsLocked),
            },
        };
    }

    /**
     * Interactive crop: load image File → drag selection → JPEG data URL.
     * opts: { maxOutW=1400, quality=0.86, aspect=null }
     * Returns { dataUrl, name, width, height } or null if cancelled.
     */
    function openCropper(file, opts = {}) {
        return new Promise((resolve) => {
            if (!file) { resolve(null); return; }
            const maxOutW = opts.maxOutW || 1400;
            const quality = opts.quality != null ? opts.quality : 0.86;
            const name = file.name || 'panel-art.jpg';

            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => {
                const overlay = document.createElement('div');
                overlay.className = 'fafo-art-crop-overlay';
                overlay.innerHTML = `
                  <div class="fafo-art-crop-modal" role="dialog" aria-label="Crop panel art">
                    <div class="fafo-art-crop-head">
                      <strong>Crop for panels</strong>
                      <span class="fafo-art-crop-sub">Drag to set crop · this becomes the locked panel default</span>
                    </div>
                    <div class="fafo-art-crop-stage">
                      <canvas class="fafo-art-crop-canvas"></canvas>
                      <div class="fafo-art-crop-sel"></div>
                    </div>
                    <div class="fafo-art-crop-actions">
                      <button type="button" class="btn btn-ghost fafo-art-crop-cancel">Cancel</button>
                      <button type="button" class="btn btn-primary fafo-art-crop-save">Save to panels</button>
                    </div>
                  </div>`;
                // Minimal styles if options page has no sheet
                if (!document.getElementById('fafo-art-crop-css')) {
                    const st = document.createElement('style');
                    st.id = 'fafo-art-crop-css';
                    st.textContent = `
                      .fafo-art-crop-overlay{position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.72);
                        display:flex;align-items:center;justify-content:center;padding:16px}
                      .fafo-art-crop-modal{background:#12141a;border:1px solid #2a2a32;border-radius:14px;
                        max-width:min(920px,96vw);width:100%;padding:16px 18px;box-shadow:0 20px 60px #000}
                      .fafo-art-crop-head{margin-bottom:10px}
                      .fafo-art-crop-head strong{color:#fff;font-size:1.05rem}
                      .fafo-art-crop-sub{display:block;color:#888;font-size:.82rem;margin-top:4px}
                      .fafo-art-crop-stage{position:relative;max-height:min(62vh,560px);overflow:auto;
                        background:#0a0a0e;border-radius:10px;user-select:none}
                      .fafo-art-crop-canvas{display:block;max-width:100%;height:auto;cursor:crosshair}
                      .fafo-art-crop-sel{position:absolute;border:2px solid #00e5ff;box-shadow:0 0 0 9999px rgba(0,0,0,.45);
                        pointer-events:none;display:none}
                      .fafo-art-crop-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:14px}
                    `;
                    document.head.appendChild(st);
                }
                document.body.appendChild(overlay);

                const canvas = overlay.querySelector('.fafo-art-crop-canvas');
                const sel = overlay.querySelector('.fafo-art-crop-sel');
                const stage = overlay.querySelector('.fafo-art-crop-stage');
                const ctx = canvas.getContext('2d');

                // Fit canvas display size
                const maxDispW = Math.min(860, window.innerWidth - 48);
                const scale = Math.min(1, maxDispW / img.naturalWidth);
                const dispW = Math.round(img.naturalWidth * scale);
                const dispH = Math.round(img.naturalHeight * scale);
                canvas.width = img.naturalWidth;
                canvas.height = img.naturalHeight;
                canvas.style.width = dispW + 'px';
                canvas.style.height = dispH + 'px';
                ctx.drawImage(img, 0, 0);

                // Default crop = center 70%
                let crop = {
                    x: Math.round(img.naturalWidth * 0.15),
                    y: Math.round(img.naturalHeight * 0.15),
                    w: Math.round(img.naturalWidth * 0.7),
                    h: Math.round(img.naturalHeight * 0.7),
                };

                function paintSel() {
                    const r = canvas.getBoundingClientRect();
                    const stageR = stage.getBoundingClientRect();
                    const sx = r.width / img.naturalWidth;
                    const sy = r.height / img.naturalHeight;
                    sel.style.display = 'block';
                    sel.style.left = (r.left - stageR.left + stage.scrollLeft + crop.x * sx) + 'px';
                    sel.style.top = (r.top - stageR.top + stage.scrollTop + crop.y * sy) + 'px';
                    sel.style.width = Math.max(8, crop.w * sx) + 'px';
                    sel.style.height = Math.max(8, crop.h * sy) + 'px';
                }
                paintSel();

                let dragging = false;
                let startX = 0;
                let startY = 0;

                function canvasPos(ev) {
                    const r = canvas.getBoundingClientRect();
                    const x = ((ev.clientX - r.left) / r.width) * img.naturalWidth;
                    const y = ((ev.clientY - r.top) / r.height) * img.naturalHeight;
                    return {
                        x: Math.max(0, Math.min(img.naturalWidth, x)),
                        y: Math.max(0, Math.min(img.naturalHeight, y)),
                    };
                }

                canvas.addEventListener('pointerdown', (ev) => {
                    dragging = true;
                    canvas.setPointerCapture(ev.pointerId);
                    const p = canvasPos(ev);
                    startX = p.x;
                    startY = p.y;
                    crop = { x: startX, y: startY, w: 1, h: 1 };
                    paintSel();
                });
                canvas.addEventListener('pointermove', (ev) => {
                    if (!dragging) return;
                    const p = canvasPos(ev);
                    const x1 = Math.min(startX, p.x);
                    const y1 = Math.min(startY, p.y);
                    const x2 = Math.max(startX, p.x);
                    const y2 = Math.max(startY, p.y);
                    crop = {
                        x: Math.round(x1),
                        y: Math.round(y1),
                        w: Math.max(8, Math.round(x2 - x1)),
                        h: Math.max(8, Math.round(y2 - y1)),
                    };
                    paintSel();
                });
                canvas.addEventListener('pointerup', () => { dragging = false; });
                window.addEventListener('resize', paintSel);

                function cleanup(result) {
                    try { URL.revokeObjectURL(url); } catch (_) {}
                    overlay.remove();
                    resolve(result);
                }

                overlay.querySelector('.fafo-art-crop-cancel').onclick = () => cleanup(null);
                overlay.querySelector('.fafo-art-crop-save').onclick = () => {
                    const out = document.createElement('canvas');
                    let tw = crop.w;
                    let th = crop.h;
                    if (tw > maxOutW) {
                        const f = maxOutW / tw;
                        tw = maxOutW;
                        th = Math.round(th * f);
                    }
                    out.width = Math.max(32, tw);
                    out.height = Math.max(32, th);
                    const octx = out.getContext('2d');
                    octx.drawImage(
                        img,
                        crop.x, crop.y, crop.w, crop.h,
                        0, 0, out.width, out.height
                    );
                    let dataUrl;
                    try {
                        dataUrl = out.toDataURL('image/jpeg', quality);
                    } catch (e) {
                        dataUrl = out.toDataURL('image/png');
                    }
                    cleanup({
                        dataUrl,
                        name,
                        width: out.width,
                        height: out.height,
                        crop,
                        savedAt: Date.now(),
                    });
                };
            };
            img.onerror = () => {
                try { URL.revokeObjectURL(url); } catch (_) {}
                resolve(null);
            };
            img.src = url;
        });
    }

    /** File picker + crop → save as panel lock default */
    async function pickAndLockPanelCrop() {
        return new Promise((resolve, reject) => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/jpeg,image/png,image/webp,image/gif,image/bmp';
            input.onchange = async () => {
                const file = input.files && input.files[0];
                if (!file) { resolve(null); return; }
                try {
                    const cropResult = await openCropper(file);
                    if (!cropResult) { resolve(null); return; }
                    const cfg = await writeConfig({
                        panelMode: 'locked',
                        panelLock: {
                            dataUrl: cropResult.dataUrl,
                            name: cropResult.name,
                            width: cropResult.width,
                            height: cropResult.height,
                            savedAt: cropResult.savedAt,
                        },
                        // Background keeps randomizing
                        bgRandom: true,
                    });
                    try { await apply({ config: cfg }); } catch (_) {}
                    resolve(cfg);
                } catch (e) {
                    reject(e);
                }
            };
            input.click();
        });
    }

    async function clearPanelLock() {
        return writeConfig({ panelMode: 'random', panelLock: null });
    }

    async function linkFolder() {
        if (!global.showDirectoryPicker) {
            throw new Error('Folder picker not supported in this browser');
        }
        const handle = await showDirectoryPicker({ id: 'fafo-chrome-art', mode: 'read' });
        const db = await FAFOLibrary.openDB();
        try {
            if (db.objectStoreNames.contains('folders')) {
                const tx = db.transaction('folders', 'readwrite');
                tx.objectStore('folders').put({
                    id: ART_FOLDER_ID,
                    name: handle.name || 'Chrome Art',
                    handle,
                    kind: 'chrome-art',
                    storeName: null,
                    addedAt: Date.now(),
                    lastSyncedAt: Date.now(),
                });
                await new Promise((res, rej) => {
                    tx.oncomplete = () => res();
                    tx.onerror = () => rej(tx.error);
                });
            }
        } catch (e) {
            throw e;
        }
        const cfg = await writeConfig({ enabled: true, bgRandom: true });
        const result = await apply({ config: cfg });
        return { folderName: handle.name, ...result };
    }

    async function clearFolder() {
        try {
            const db = await FAFOLibrary.openDB();
            if (db.objectStoreNames.contains('folders')) {
                const tx = db.transaction('folders', 'readwrite');
                tx.objectStore('folders').delete(ART_FOLDER_ID);
                await new Promise((res) => { tx.oncomplete = () => res(); tx.onerror = () => res(); });
            }
        } catch (_) {}
        revokeAll();
        document.body?.classList.remove('fafo-chrome-art');
        setLayerBg(document.getElementById('fafo-chrome-bg'), '', 0);
        setLayerBg(document.getElementById('fafo-chrome-banner'), '', 0);
        return writeConfig({ enabled: false });
    }

    global.FAFOChromeArt = {
        ART_FOLDER_ID,
        DEFAULTS,
        readConfig,
        writeConfig,
        getArtFolder,
        listArtImages,
        apply,
        applyTileFallback,
        linkFolder,
        clearFolder,
        pickAndLockPanelCrop,
        clearPanelLock,
        openCropper,
        normalizeConfig,
    };
})(typeof window !== 'undefined' ? window : globalThis);
