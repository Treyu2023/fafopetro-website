@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist "%~dp0Launch-ExplorerMeta.vbs" (
  start "" wscript.exe //B "%~dp0Launch-ExplorerMeta.vbs" %*
  exit /b 0
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Launch-ExplorerMeta.ps1" %*
exit /b 0
