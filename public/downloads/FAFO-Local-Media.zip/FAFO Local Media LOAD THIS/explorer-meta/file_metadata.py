"""
Write / read Windows Explorer-visible file metadata (Tags + Rating).

Order of writers (first success wins for shell props; mutagen always tried as bonus):
  1. pywin32 IPropertyStore  → System.Keywords + System.Rating  (what Explorer shows)
  2. PowerShell + C# COM     → same property store without pywin32
  3. mutagen / ffmpeg        → embedded atoms (apps that read MP4 tags/comments)

Rating scale: UI stars 0–5 map to System.Rating 0 / 1 / 25 / 50 / 75 / 99.
"""
from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any
import re

log = logging.getLogger("aitoolbox.file_metadata")

# Windows Explorer star → System.Rating (UInt32)
STAR_TO_RATING = {0: 0, 1: 1, 2: 25, 3: 50, 4: 75, 5: 99}
RATING_TO_STAR = {0: 0, 1: 1, 25: 2, 50: 3, 75: 4, 99: 5}


def stars_to_system_rating(stars: int | None) -> int:
    if stars is None:
        return 0
    try:
        s = max(0, min(5, int(stars)))
    except (TypeError, ValueError):
        return 0
    return STAR_TO_RATING.get(s, 0)


def system_rating_to_stars(value: int | None) -> int:
    if value is None:
        return 0
    try:
        v = int(value)
    except (TypeError, ValueError):
        return 0
    if v in RATING_TO_STAR:
        return RATING_TO_STAR[v]
    if v <= 0:
        return 0
    # nearest bucket
    best = 0
    best_d = 999
    for rating, stars in RATING_TO_STAR.items():
        d = abs(rating - v)
        if d < best_d:
            best_d = d
            best = stars
    return best


# Hard cap for real human tags. ComfyUI / Signature / AI prompt dumps are huge.
TAG_MAX_CHARS = 80
TAGS_MAX = 40


def re_fullmatch_b64ish(s: str) -> bool:
    """Long base64-looking strings without spaces are never user tags."""
    if len(s) < 48:
        return False
    body = s
    if ":" in s[:20]:
        body = s.split(":", 1)[-1].strip()
    if len(body) < 48:
        return False
    allowed = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=_-")
    sample = body[:200]
    if sum(1 for c in sample if c in allowed) / max(1, len(sample)) < 0.92:
        return False
    return body.count(" ") <= 2


def is_prompt_blob(s: str) -> bool:
    """True for AI prompt soup / multi-keyword dumps (from remote 6.3.4 hardening)."""
    if not s:
        return True
    seps = s.count(",") + s.count(";") + s.count("|")
    if len(s) > 80 and seps >= 3:
        return True
    if len(s) > 50 and seps >= 5:
        return True
    if re.search(
        r"\b(cinematic|photorealistic|masterpiece|negative prompt|best quality|"
        r"ultra detailed|highly detailed|volumetric|octane render|unreal engine|"
        r"trending on artstation|prompt|seed|cfg scale|lora|checkpoint|8k|4k uhd)\b",
        s,
        re.I,
    ):
        return True
    return False


def is_junk_tag(tag: str | None) -> bool:
    """True for metadata pollution that must never enter the tag vocabulary or Explorer tags.

    Sources: ComfyUI workflow JSON, Signature/base64 blobs, paths, property dumps,
    AI prompt blobs (merged from upstream 6.3.4).
    """
    if tag is None:
        return True
    s = str(tag).strip()
    if not s:
        return True
    if len(s) > TAG_MAX_CHARS:
        return True
    if is_prompt_blob(s):
        return True
    low = s.lower()
    if low.startswith("signature:") or low.startswith("sig:") or "signature:" in low[:24]:
        return True
    if re_fullmatch_b64ish(s):
        return True
    if re.match(r"^[A-Za-z]:[\\/]", s) or s.startswith("\\\\"):
        return True
    if "\\" in s and len(s) > 24:
        return True
    if any(tok in low for tok in (
        "widgets_values", "node name for s&r", '"class_type"',
        "comfyui", "cliptextencode", "ksampler", "checkpointloader",
        "cnr_id", "bounding", "frontendversion",
    )):
        return True
    if s.lstrip()[:1] in "{[" and len(s) > 20:
        return True
    if (s.count("{") + s.count("}") + s.count("[")) >= 4 and len(s) > 30:
        return True
    if "system." in low and any(x in low for x in ("keywords", "rating", "media", "photo", "item")):
        return True
    if len(s) > 36 and (s.count(";") + s.count("|") + s.count(",")) >= 3:
        return True
    if re.search(
        r"\b(codec|bitrate|fps|resolution|duration|encoder|muxer|handler_name|major_brand)\b",
        s,
        re.I,
    ):
        return True
    alnum = sum(ch.isalnum() for ch in s)
    if len(s) > 8 and alnum / len(s) < 0.4:
        return True
    if len(s) > 60 and s.count(" ") >= 8:
        return True
    if len(s.split()) > 6:
        return True
    if "\x00" in s or any(ord(c) < 32 and c not in "\t" for c in s):
        return True
    return False


def normalize_tags(tags: list[str] | None) -> list[str]:
    """Sanitize tags: hard cap, drop dumps / prompts / binary noise, max TAGS_MAX tags."""
    if not tags:
        return []
    out: list[str] = []
    seen: set[str] = set()
    for t in tags:
        raw = str(t or "")
        if is_prompt_blob(raw) or is_junk_tag(raw):
            # Still try splitting short multi-tag fields ("Angel; Fire")
            if ";" not in raw and "," not in raw and "|" not in raw and "\n" not in raw:
                continue
        pieces = re.split(r"[,;|\n\r]+", raw)
        if len(pieces) >= 6 and len(raw) > 60:
            continue
        for piece in pieces:
            s = re.sub(r"[\x00-\x1f\x7f]", " ", piece)
            s = re.sub(r"\s+", " ", s).strip()
            if not s or is_junk_tag(s) or is_prompt_blob(s):
                continue
            key = s.lower()
            if key in seen:
                continue
            seen.add(key)
            out.append(s)
            if len(out) >= TAGS_MAX:
                return out
    return out


def _is_file_in_use_error(exc: BaseException | str) -> bool:
    """True for Windows sharing violations (file open in Chrome/player)."""
    s = str(exc)
    if "being used by another process" in s.lower():
        return True
    if "0x80070020" in s or "-2147024864" in s or "0x80070020" in s.upper():
        return True
    # HRESULT ERROR_SHARING_VIOLATION
    if "32," in s and "WinError" in s:
        return True
    try:
        if isinstance(exc, OSError) and getattr(exc, "winerror", None) == 32:
            return True
    except Exception:
        pass
    return False


def write_file_metadata(
    path: str | Path,
    tags: list[str] | None = None,
    rating: int | None = None,
    *,
    retries: int = 4,
    retry_delay_s: float = 0.35,
) -> dict[str, Any]:
    """
    Write tags and/or rating into the real file so Explorer and other apps see them.

    When Chrome (or another app) has the video open, Windows shell property
    writes often hit ERROR_SHARING_VIOLATION. We retry briefly, fall back to
    mutagen when possible, and set result['file_locked']=True so the server
    can schedule a deferred shell write.

    Returns { ok, path, methods: [...], errors: [...], tags, rating, file_locked? }.
    """
    import time as _time

    p = Path(path)
    result: dict[str, Any] = {
        "ok": False,
        "path": str(p),
        "methods": [],
        "errors": [],
        "tags": normalize_tags(tags) if tags is not None else None,
        "rating": None if rating is None else max(0, min(5, int(rating))),
        "file_locked": False,
    }
    if not p.is_file():
        result["errors"].append("File not found")
        return result

    tag_list = normalize_tags(tags) if tags is not None else None
    stars = result["rating"]
    attempts = max(1, int(retries))

    # 1) Windows Property System (Explorer Tags + Rating columns) — with retry
    if sys.platform == "win32" and (tag_list is not None or stars is not None):
        shell_ok = False
        last_lock = False
        for attempt in range(attempts):
            # Fresh error list for this attempt so retries don't stack noise
            attempt_result: dict[str, Any] = {"methods": [], "errors": []}
            if _write_shell_props_pywin32(p, tag_list, stars, attempt_result):
                result["methods"].extend(attempt_result["methods"])
                shell_ok = True
                break
            if _write_shell_props_powershell(p, tag_list, stars, attempt_result):
                result["methods"].extend(attempt_result["methods"])
                shell_ok = True
                break
            locked = any(_is_file_in_use_error(e) for e in attempt_result.get("errors") or [])
            last_lock = locked
            if locked and attempt < attempts - 1:
                _time.sleep(retry_delay_s * (attempt + 1))
                continue
            # Keep last non-lock errors; for lock, one clean note is enough
            if locked:
                result["file_locked"] = True
                if "file in use (Explorer write deferred)" not in result["errors"]:
                    result["errors"].append("file in use (Explorer write deferred)")
            else:
                for e in attempt_result.get("errors") or []:
                    if e not in result["errors"]:
                        result["errors"].append(e)
            break
        if last_lock and not shell_ok:
            result["file_locked"] = True

    # 2) Embedded containers (mutagen) — often works even while video is playing (read share)
    if tag_list is not None or stars is not None:
        mut_result: dict[str, Any] = {"methods": [], "errors": []}
        if _write_mutagen(p, tag_list, stars, mut_result):
            result["methods"].extend(mut_result["methods"])
        else:
            for e in mut_result.get("errors") or []:
                if _is_file_in_use_error(e):
                    result["file_locked"] = True
                    if "file in use (Explorer write deferred)" not in result["errors"]:
                        result["errors"].append("file in use (mutagen also locked)")
                elif e not in result["errors"]:
                    result["errors"].append(e)

    result["ok"] = len(result["methods"]) > 0
    if not result["ok"] and not result["errors"]:
        result["errors"].append("No writer succeeded for this file type")
    return result


def read_file_metadata(path: str | Path) -> dict[str, Any]:
    """Read tags + rating from file (shell first, then mutagen)."""
    p = Path(path)
    out: dict[str, Any] = {"path": str(p), "tags": [], "rating": 0, "methods": []}
    if not p.is_file():
        return out

    if sys.platform == "win32":
        shell = _read_shell_props(p)
        if shell:
            out["tags"] = shell.get("tags") or []
            out["rating"] = shell.get("rating") or 0
            out["methods"].append(shell.get("method", "shell"))

    if not out["tags"] or not out["rating"]:
        emb = _read_mutagen(p)
        if emb:
            if not out["tags"] and emb.get("tags"):
                out["tags"] = emb["tags"]
            if not out["rating"] and emb.get("rating"):
                out["rating"] = emb["rating"]
            out["methods"].append("mutagen")
    return out


# ---------------------------------------------------------------------------
# Windows Property System via pywin32
# ---------------------------------------------------------------------------

def _write_shell_props_pywin32(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    try:
        import pythoncom
        from win32com.propsys import propsys
        from win32com.shell import shellcon
    except ImportError:
        return False
    try:
        pythoncom.CoInitialize()
        try:
            ps = propsys.SHGetPropertyStoreFromParsingName(
                str(path), None, shellcon.GPS_READWRITE, propsys.IID_IPropertyStore
            )
            if tags is not None:
                pk = propsys.PSGetPropertyKeyFromName("System.Keywords")
                if tags:
                    ps.SetValue(pk, propsys.PROPVARIANTType(tags, pythoncom.VT_VECTOR | pythoncom.VT_BSTR))
                else:
                    # Clear keywords
                    try:
                        ps.SetValue(pk, propsys.PROPVARIANTType(None, pythoncom.VT_EMPTY))
                    except Exception:
                        ps.SetValue(pk, propsys.PROPVARIANTType([], pythoncom.VT_VECTOR | pythoncom.VT_BSTR))
            if stars is not None:
                pk_r = propsys.PSGetPropertyKeyFromName("System.Rating")
                rating_val = stars_to_system_rating(stars)
                if rating_val <= 0:
                    try:
                        ps.SetValue(pk_r, propsys.PROPVARIANTType(None, pythoncom.VT_EMPTY))
                    except Exception:
                        ps.SetValue(pk_r, propsys.PROPVARIANTType(0, pythoncom.VT_UI4))
                else:
                    ps.SetValue(pk_r, propsys.PROPVARIANTType(rating_val, pythoncom.VT_UI4))
            ps.Commit()
            result["methods"].append("shell-pywin32")
            return True
        finally:
            pythoncom.CoUninitialize()
    except Exception as e:
        result["errors"].append(f"shell-pywin32: {e}")
        if _is_file_in_use_error(e):
            log.info("shell-pywin32 skipped (file in use): %s", path.name)
        else:
            log.warning("shell-pywin32 write failed for %s: %s", path, e)
        return False


def _read_shell_props(path: Path) -> dict[str, Any] | None:
    try:
        import pythoncom
        from win32com.propsys import propsys
        from win32com.shell import shellcon
    except ImportError:
        return _read_shell_props_powershell(path)
    try:
        pythoncom.CoInitialize()
        try:
            ps = propsys.SHGetPropertyStoreFromParsingName(
                str(path), None, shellcon.GPS_DEFAULT, propsys.IID_IPropertyStore
            )
            tags: list[str] = []
            rating = 0
            try:
                pk = propsys.PSGetPropertyKeyFromName("System.Keywords")
                val = ps.GetValue(pk).GetValue()
                if val:
                    if isinstance(val, (list, tuple)):
                        tags = [str(x) for x in val if x]
                    else:
                        tags = [str(val)]
            except Exception:
                pass
            try:
                pk_r = propsys.PSGetPropertyKeyFromName("System.Rating")
                val = ps.GetValue(pk_r).GetValue()
                if val is not None:
                    rating = system_rating_to_stars(int(val))
            except Exception:
                pass
            return {"tags": normalize_tags(tags), "rating": rating, "method": "shell-pywin32"}
        finally:
            pythoncom.CoUninitialize()
    except Exception:
        return _read_shell_props_powershell(path)


# ---------------------------------------------------------------------------
# PowerShell + C# IPropertyStore fallback (no pywin32)
# ---------------------------------------------------------------------------

_PS_HELPER = r'''
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [string]$TagsJson = $null,
  [string]$RatingStars = $null,
  [switch]$ReadOnly
)
$ErrorActionPreference = "Stop"
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class ShellProps {
  [StructLayout(LayoutKind.Sequential, Pack=4)]
  public struct PROPERTYKEY {
    public Guid fmtid;
    public uint pid;
  }

  [StructLayout(LayoutKind.Sequential)]
  public struct PROPVARIANT {
    public ushort vt;
    public ushort wReserved1;
    public ushort wReserved2;
    public ushort wReserved3;
    public IntPtr p;
    public int p2;
  }

  [ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IPropertyStore {
    uint GetCount(out uint cProps);
    uint GetAt(uint iProp, out PROPERTYKEY pkey);
    uint GetValue(ref PROPERTYKEY key, out PROPVARIANT pv);
    uint SetValue(ref PROPERTYKEY key, ref PROPVARIANT pv);
    uint Commit();
  }

  [DllImport("shell32.dll", CharSet=CharSet.Unicode, PreserveSig=false)]
  public static extern void SHGetPropertyStoreFromParsingName(
    string pszPath, IntPtr pbc, uint flags, ref Guid riid, out IPropertyStore ppv);

  [DllImport("propsys.dll", CharSet=CharSet.Unicode, PreserveSig=false)]
  public static extern void PSGetPropertyKeyFromName(string pszName, out PROPERTYKEY ppropkey);

  [DllImport("ole32.dll")]
  public static extern int PropVariantClear(ref PROPVARIANT pvar);

  public const ushort VT_EMPTY = 0;
  public const ushort VT_UI4 = 19;
  public const ushort VT_LPWSTR = 31;
  public const ushort VT_VECTOR = 0x1000;
  public const uint GPS_DEFAULT = 0;
  public const uint GPS_READWRITE = 2;

  public static readonly Guid IID_IPropertyStore = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");

  public static IPropertyStore Open(string path, bool write) {
    Guid iid = IID_IPropertyStore;
    IPropertyStore ps;
    SHGetPropertyStoreFromParsingName(path, IntPtr.Zero, write ? GPS_READWRITE : GPS_DEFAULT, ref iid, out ps);
    return ps;
  }

  public static void SetKeywords(IPropertyStore ps, string[] tags) {
    PROPERTYKEY key;
    PSGetPropertyKeyFromName("System.Keywords", out key);
    PROPVARIANT pv = new PROPVARIANT();
    if (tags == null || tags.Length == 0) {
      pv.vt = VT_EMPTY;
    } else {
      // VT_VECTOR|VT_LPWSTR via PropVariant helper in managed form is awkward;
      // set as semicolon-joined System.Comment fallback handled elsewhere.
      // Use InitPropVariantFromStringAsVector via propsys if available.
      InitStringVector(tags, out pv);
    }
    ps.SetValue(ref key, ref pv);
    PropVariantClear(ref pv);
  }

  [DllImport("propsys.dll", CharSet=CharSet.Unicode, PreserveSig=false)]
  private static extern void InitPropVariantFromStringAsVector(
    [MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPWStr)] string[] prgsz,
    uint cElems, out PROPVARIANT ppropvar);

  public static void InitStringVector(string[] tags, out PROPVARIANT pv) {
    InitPropVariantFromStringAsVector(tags, (uint)tags.Length, out pv);
  }

  public static void SetRating(IPropertyStore ps, uint rating) {
    PROPERTYKEY key;
    PSGetPropertyKeyFromName("System.Rating", out key);
    PROPVARIANT pv = new PROPVARIANT();
    if (rating == 0) {
      pv.vt = VT_EMPTY;
    } else {
      pv.vt = VT_UI4;
      pv.p = new IntPtr(rating);
    }
    ps.SetValue(ref key, ref pv);
    PropVariantClear(ref pv);
  }

  public static string[] GetKeywords(IPropertyStore ps) {
    PROPERTYKEY key;
    PSGetPropertyKeyFromName("System.Keywords", out key);
    PROPVARIANT pv;
    ps.GetValue(ref key, out pv);
    try {
      if (pv.vt == VT_EMPTY) return new string[0];
      // Best-effort: PropVariantToStringVector
      return PropVariantToStrings(ref pv);
    } finally {
      PropVariantClear(ref pv);
    }
  }

  [DllImport("propsys.dll", CharSet=CharSet.Unicode, PreserveSig=false)]
  private static extern void PropVariantToStringVector(
    ref PROPVARIANT propvar,
    [Out, MarshalAs(UnmanagedType.LPArray, ArraySubType=UnmanagedType.LPWStr, SizeParamIndex=2)] out string[] prgsz,
    out uint pcElem);

  public static string[] PropVariantToStrings(ref PROPVARIANT pv) {
    try {
      string[] arr;
      uint n;
      PropVariantToStringVector(ref pv, out arr, out n);
      return arr ?? new string[0];
    } catch {
      return new string[0];
    }
  }

  public static uint GetRating(IPropertyStore ps) {
    PROPERTYKEY key;
    PSGetPropertyKeyFromName("System.Rating", out key);
    PROPVARIANT pv;
    ps.GetValue(ref key, out pv);
    try {
      if (pv.vt == VT_UI4) return (uint)pv.p.ToInt64();
      return 0;
    } finally {
      PropVariantClear(ref pv);
    }
  }
}
"@

if ($ReadOnly) {
  $ps = [ShellProps]::Open($Path, $false)
  $tags = [ShellProps]::GetKeywords($ps)
  $rating = [ShellProps]::GetRating($ps)
  $obj = @{ tags = @($tags); rating = [int]$rating }
  $obj | ConvertTo-Json -Compress
  exit 0
}

$ps = [ShellProps]::Open($Path, $true)
if ($null -ne $TagsJson -and $TagsJson -ne "") {
  $tagArr = @()
  if ($TagsJson -ne "[]") {
    $tagArr = @(ConvertFrom-Json $TagsJson)
  }
  [ShellProps]::SetKeywords($ps, [string[]]$tagArr)
}
if ($null -ne $RatingStars -and $RatingStars -ne "") {
  $stars = [int]$RatingStars
  $map = @{ 0 = 0; 1 = 1; 2 = 25; 3 = 50; 4 = 75; 5 = 99 }
  $r = 0
  if ($map.ContainsKey($stars)) { $r = [uint32]$map[$stars] }
  [ShellProps]::SetRating($ps, $r)
}
$ps.Commit()
Write-Output "OK"
'''


def _write_shell_props_powershell(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    script_path = Path(__file__).with_name("_shell_props.ps1")
    try:
        if not script_path.exists() or script_path.stat().st_size < 100:
            script_path.write_text(_PS_HELPER, encoding="utf-8")
    except Exception as e:
        result["errors"].append(f"ps-helper-write: {e}")
        return False

    cmd = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", str(script_path),
        "-Path", str(path),
    ]
    if tags is not None:
        cmd += ["-TagsJson", json.dumps(tags)]
    if stars is not None:
        cmd += ["-RatingStars", str(int(stars))]
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        if proc.returncode == 0 and "OK" in (proc.stdout or ""):
            result["methods"].append("shell-powershell")
            return True
        err = (proc.stderr or proc.stdout or "unknown error").strip()
        result["errors"].append(f"shell-powershell: {err[:300]}")
        if _is_file_in_use_error(err):
            log.info("shell-powershell skipped (file in use): %s", path.name)
        else:
            log.warning("powershell write failed for %s: %s", path, err[:300])
        return False
    except Exception as e:
        result["errors"].append(f"shell-powershell: {e}")
        if _is_file_in_use_error(e):
            log.info("shell-powershell skipped (file in use): %s", path.name)
        return False


def _read_shell_props_powershell(path: Path) -> dict[str, Any] | None:
    script_path = Path(__file__).with_name("_shell_props.ps1")
    try:
        if not script_path.exists():
            script_path.write_text(_PS_HELPER, encoding="utf-8")
        proc = subprocess.run(
            [
                "powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                "-File", str(script_path), "-Path", str(path), "-ReadOnly",
            ],
            capture_output=True, text=True, timeout=30,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        if proc.returncode != 0:
            return None
        data = json.loads(proc.stdout.strip() or "{}")
        tags = data.get("tags") or []
        if isinstance(tags, str):
            tags = [tags]
        rating = system_rating_to_stars(data.get("rating", 0))
        return {"tags": normalize_tags(list(tags)), "rating": rating, "method": "shell-powershell"}
    except Exception:
        return None


# ---------------------------------------------------------------------------
# mutagen embedded tags (MP4/JPEG etc.)
# ---------------------------------------------------------------------------

def _write_mutagen(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    ext = path.suffix.lower()
    try:
        if ext in (".mp4", ".m4v", ".mov"):
            return _write_mutagen_mp4(path, tags, stars, result)
        if ext in (".jpg", ".jpeg", ".tif", ".tiff", ".png", ".webp"):
            return _write_mutagen_image(path, tags, stars, result)
        if ext in (".mp3",):
            return _write_mutagen_mp3(path, tags, stars, result)
        if ext in (".mkv", ".webm") and tags is not None:
            return _write_ffmpeg_comment(path, tags, result)
    except Exception as e:
        result["errors"].append(f"mutagen: {e}")
        log.warning("mutagen write failed for %s: %s", path, e)
    return False


def _write_mutagen_mp4(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    from mutagen.mp4 import MP4, MP4FreeForm

    mp4 = MP4(path)
    if mp4.tags is None:
        mp4.add_tags()
    if tags is not None:
        # Comment (widely visible) + freeform keywords
        mp4.tags["\xa9cmt"] = ["; ".join(tags)] if tags else []
        # iTunes-style keywords freeform
        try:
            joined = "; ".join(tags).encode("utf-8")
            mp4.tags["----:com.apple.iTunes:Keywords"] = [MP4FreeForm(joined)]
        except Exception:
            pass
        # Some handlers read ©gen / label — skip
    if stars is not None:
        # 0–100 scale used by many players; 0 clears
        rate = 0 if stars <= 0 else min(100, stars * 20)
        try:
            mp4.tags["rate"] = [rate]
        except Exception:
            pass
        # Windows sometimes maps tmpo — skip
    mp4.save()
    result["methods"].append("mutagen-mp4")
    return True


def _write_mutagen_image(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    """Images rely primarily on Windows shell props; mutagen/PIL path is optional."""
    # Shell write already attempted. For JPEG, also try XPKeywords via piexif if present.
    if path.suffix.lower() not in (".jpg", ".jpeg"):
        return False
    try:
        import piexif  # optional
        exif_dict = piexif.load(str(path))
        if tags is not None:
            # XPKeywords is UCS2LE null-separated in 0x9C9E
            joined = ";".join(tags)
            exif_dict.setdefault("0th", {})[piexif.ImageIFD.XPKeywords] = joined.encode("utf-16le")
        if stars is not None:
            # XPRating 0-5 in 0x4746 sometimes under EXIF — Windows uses Rating in XMP/shell mainly
            pass
        piexif.insert(piexif.dump(exif_dict), str(path))
        result["methods"].append("piexif-xpkeywords")
        return True
    except Exception:
        # Not fatal — shell writer is the real Explorer path
        return False


def _write_mutagen_mp3(
    path: Path,
    tags: list[str] | None,
    stars: int | None,
    result: dict[str, Any],
) -> bool:
    from mutagen.id3 import ID3, COMM, POPM, TXXX, ID3NoHeaderError
    try:
        id3 = ID3(path)
    except ID3NoHeaderError:
        id3 = ID3()
    if tags is not None:
        id3.delall("COMM")
        if tags:
            id3.add(COMM(encoding=3, lang="eng", desc="Tags", text="; ".join(tags)))
        id3.delall("TXXX:KEYWORDS")
        if tags:
            id3.add(TXXX(encoding=3, desc="KEYWORDS", text="; ".join(tags)))
    if stars is not None:
        id3.delall("POPM")
        if stars > 0:
            # POPM rating 0-255
            id3.add(POPM(email="WindowsMediaPlayer", rating=min(255, stars * 51), count=0))
    id3.save(path)
    result["methods"].append("mutagen-mp3")
    return True


def _find_ffmpeg() -> str | None:
    import shutil
    for name in ("ffmpeg", "ffmpeg.exe"):
        p = shutil.which(name)
        if p:
            return p
    for candidate in (
        Path(r"C:\ffmpeg\bin\ffmpeg.exe"),
        Path(r"C:\Program Files\ffmpeg\bin\ffmpeg.exe"),
    ):
        if candidate.exists():
            return str(candidate)
    return None


def _write_ffmpeg_comment(path: Path, tags: list[str], result: dict[str, Any]) -> bool:
    ffmpeg = _find_ffmpeg()
    if not ffmpeg:
        result["errors"].append("ffmpeg not found for mkv/webm tag write")
        return False
    tag_str = "; ".join(tags)
    tmp = path.with_suffix(path.suffix + ".tagging.tmp")
    try:
        subprocess.run(
            [ffmpeg, "-y", "-i", str(path), "-c", "copy",
             "-metadata", f"comment={tag_str}",
             "-metadata", f"keywords={tag_str}",
             str(tmp)],
            check=True, capture_output=True, timeout=180,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0,
        )
        tmp.replace(path)
        result["methods"].append("ffmpeg-comment")
        return True
    except Exception as e:
        result["errors"].append(f"ffmpeg: {e}")
        if tmp.exists():
            tmp.unlink(missing_ok=True)
        return False


def _read_mutagen(path: Path) -> dict[str, Any] | None:
    ext = path.suffix.lower()
    try:
        if ext in (".mp4", ".m4v", ".mov"):
            from mutagen.mp4 import MP4
            mp4 = MP4(path)
            tags: list[str] = []
            raw = (mp4.tags or {}).get("\xa9cmt") or []
            if raw:
                for item in raw:
                    blob = str(item)
                    # AI prompt dumps often land in ©cmt — skip unless tiny keyword list
                    if len(blob) > 100:
                        continue
                    if blob.count(",") + blob.count(";") >= 3:
                        continue
                    if re.search(
                        r"\b(cinematic|photorealistic|masterpiece|prompt|8k|lora)\b",
                        blob,
                        re.I,
                    ):
                        continue
                    for part in blob.replace("|", ";").replace(",", ";").split(";"):
                        part = part.strip()
                        if part:
                            tags.append(part)
                tags = normalize_tags(tags)
            rating = 0
            rate = (mp4.tags or {}).get("rate")
            if rate:
                try:
                    r = int(rate[0])
                    rating = max(0, min(5, round(r / 20))) if r else 0
                except Exception:
                    pass
            return {"tags": tags, "rating": rating}
    except Exception:
        pass
    return None
