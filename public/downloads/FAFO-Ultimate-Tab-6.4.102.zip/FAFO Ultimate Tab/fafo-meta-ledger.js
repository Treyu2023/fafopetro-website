/**
 * FAFO metadata salvage ledger.
 *
 * Every tag/rating change is recorded here as pending until Windows Explorer
 * confirms the write. Chrome storage holds a live copy; the companion writes
 * explorer-meta/fafo-meta-ledger.json so nothing sits in limbo if the tab dies
 * or the server was down. Apply later with Options → Apply salvage ledger
 * or explorer-meta/APPLY_PENDING_LEDGER.bat.
 */
(function (global) {
    'use strict';

    const KIND = 'fafo-meta-ledger';
    const VERSION = 1;
    const TOOLBOX = 'http://127.0.0.1:8765/api';
    const PENDING = new Set(['pending', 'failed', 'deferred', '']);
    const FAIL_LIMIT = 3;
    const SNOOZE_MS = 6 * 60 * 60 * 1000;
    const FAIL_LOG_KEEP = 20;

    function storageKey(space) {
        return space === 'private' ? 'fafoMetaLedgerPrivate' : 'fafoMetaLedger';
    }

    function emptyLedger(space) {
        return { kind: KIND, version: VERSION, space: space === 'private' ? 'private' : 'public', updatedAt: 0, files: {} };
    }

    const cache = {
        public: emptyLedger('public'),
        private: emptyLedger('private'),
    };
    const loaded = { public: false, private: false };
    let chromeTimer = null;
    let diskTimer = null;

    function spaceOf(s) {
        return s === 'private' ? 'private' : 'public';
    }

    function tagsEqual(a, b) {
        const aa = (Array.isArray(a) ? a : []).map((t) => String(t).toLowerCase()).sort();
        const bb = (Array.isArray(b) ? b : []).map((t) => String(t).toLowerCase()).sort();
        return aa.length === bb.length && aa.every((t, i) => t === bb[i]);
    }

    function cloneExplorer(ex, patch) {
        return {
            status: 'pending',
            lastAttempt: 0,
            lastApplied: 0,
            error: '',
            path: '',
            methods: [],
            failCount: 0,
            failLog: [],
            hold: '',
            snoozeUntil: 0,
            ...(ex || {}),
            ...(patch || {}),
        };
    }

    function isDropped(rec) {
        const ex = rec?.explorer || {};
        return ex.hold === 'dropped' || ex.status === 'dropped';
    }

    function isSnoozed(rec) {
        const ex = rec?.explorer || {};
        if (isDropped(rec)) return false;
        if (ex.hold !== 'snooze') return false;
        return Number(ex.snoozeUntil || 0) > Date.now();
    }

    function isHeld(rec) {
        return isDropped(rec) || isSnoozed(rec);
    }

    function needsReview(rec) {
        if (!rec || isDropped(rec)) return false;
        return (Number(rec.explorer?.failCount) || 0) >= FAIL_LIMIT;
    }

    function isAutoEligible(rec) {
        if (!rec || isHeld(rec) || needsReview(rec)) return false;
        const st = String(rec.explorer?.status || 'pending');
        return PENDING.has(st);
    }

    function recordConfigured(space, key, meta, opts) {
        if (!key || !meta) return;
        space = spaceOf(space);
        const led = cache[space];
        const prev = led.files[key] || {};
        const prevEx = prev.explorer || {};
        const tags = Array.isArray(meta.tags) ? meta.tags.slice() : [];
        const rating = Number(meta.rating) || 0;
        const unchanged = prevEx.status === 'applied'
            && tagsEqual(prev.tags, tags)
            && Number(prev.rating) === rating;
        led.files[key] = {
            key,
            name: meta.name || prev.name || '',
            size: meta.size != null ? meta.size : (prev.size ?? null),
            mtime: meta.mtime != null ? meta.mtime : (meta.lastModified != null ? meta.lastModified : (prev.mtime ?? null)),
            tags,
            rating,
            pairId: meta.pairId || prev.pairId || '',
            updatedAt: Date.now(),
            explorer: cloneExplorer(prevEx, unchanged
                ? { status: 'applied' }
                : { status: (opts && opts.status) || 'pending', error: '', lastAttempt: 0 }),
        };
        led.updatedAt = Date.now();
        schedulePersist(space);
    }

    function harvest(space, mediaMeta) {
        space = spaceOf(space);
        if (!mediaMeta || typeof mediaMeta !== 'object') return 0;
        let n = 0;
        Object.keys(mediaMeta).forEach((key) => {
            const m = mediaMeta[key];
            if (!m || (!m.name && !(m.tags || []).length && !m.rating)) return;
            recordConfigured(space, key, m);
            n += 1;
        });
        return n;
    }

    function markExplorer(space, key, patch) {
        space = spaceOf(space);
        const rec = cache[space].files[key];
        if (!rec) return;
        rec.explorer = cloneExplorer(rec.explorer, patch);
        rec.updatedAt = Date.now();
        cache[space].updatedAt = Date.now();
        schedulePersist(space);
    }

    function markApplied(space, key, info) {
        markExplorer(space, key, {
            status: info?.deferred ? 'deferred' : 'applied',
            lastApplied: Date.now(),
            lastAttempt: Date.now(),
            error: '',
            path: info?.path || '',
            methods: info?.methods || [],
            failCount: 0,
            hold: '',
            snoozeUntil: 0,
        });
    }

    function markFailed(space, key, error, extra) {
        space = spaceOf(space);
        let rec = cache[space].files[key];
        if (!rec) {
            recordConfigured(space, key, {
                name: extra?.name || '',
                size: extra?.size,
                tags: extra?.tags || [],
                rating: extra?.rating || 0,
            }, { status: 'failed' });
            rec = cache[space].files[key];
        }
        if (!rec) return 0;
        if (extra?.name && !rec.name) rec.name = extra.name;
        const prev = rec.explorer || {};
        const count = (Number(prev.failCount) || 0) + 1;
        const log = Array.isArray(prev.failLog) ? prev.failLog.slice() : [];
        log.push({
            at: Date.now(),
            error: String(error || 'write failed'),
            name: rec.name || extra?.name || '',
        });
        if (log.length > FAIL_LOG_KEEP) log.splice(0, log.length - FAIL_LOG_KEEP);
        markExplorer(space, key, {
            status: 'failed',
            lastAttempt: Date.now(),
            error: String(error || 'write failed'),
            failCount: count,
            failLog: log,
            hold: prev.hold === 'dropped' ? 'dropped' : (prev.hold || ''),
            snoozeUntil: prev.hold === 'snooze' ? prev.snoozeUntil : 0,
        });
        return count;
    }

    function markHold(space, key, hold, opts) {
        space = spaceOf(space);
        const rec = cache[space].files[key];
        if (!rec) return;
        if (hold === 'dropped') {
            markExplorer(space, key, {
                status: 'dropped',
                hold: 'dropped',
                snoozeUntil: 0,
                error: rec.explorer?.error || 'dropped from queue',
            });
            return;
        }
        if (hold === 'snooze') {
            const until = Number(opts?.until) || (Date.now() + SNOOZE_MS);
            markExplorer(space, key, {
                hold: 'snooze',
                snoozeUntil: until,
                status: 'failed',
            });
            return;
        }
        markExplorer(space, key, {
            hold: '',
            snoozeUntil: 0,
            status: rec.explorer?.status === 'dropped' ? 'failed' : (rec.explorer?.status || 'pending'),
            failCount: opts?.resetFails ? 0 : (Number(rec.explorer?.failCount) || 0),
        });
    }

    function pendingEntries(space) {
        space = spaceOf(space);
        return Object.values(cache[space].files).filter((f) => isAutoEligible(f));
    }

    function reviewEntries(space) {
        space = spaceOf(space);
        return Object.values(cache[space].files).filter((f) => needsReview(f) && !isDropped(f));
    }

    function heldEntries(space) {
        space = spaceOf(space);
        return Object.values(cache[space].files).filter((f) => isHeld(f));
    }

    function recentFailLog(space, limit) {
        space = spaceOf(space);
        const rows = [];
        Object.values(cache[space].files).forEach((f) => {
            const log = f.explorer?.failLog;
            if (!Array.isArray(log)) return;
            log.forEach((entry) => {
                rows.push({
                    key: f.key,
                    name: f.name || entry.name || '',
                    at: entry.at,
                    error: entry.error,
                    failCount: Number(f.explorer?.failCount) || 0,
                    hold: f.explorer?.hold || '',
                    path: f.explorer?.path || '',
                    size: f.size,
                });
            });
        });
        rows.sort((a, b) => (b.at || 0) - (a.at || 0));
        return rows.slice(0, limit || 80);
    }

    function stats(space) {
        space = spaceOf(space);
        const files = Object.values(cache[space].files);
        const pending = files.filter((f) => isAutoEligible(f));
        return {
            total: files.length,
            pending: pending.length,
            applied: files.filter((f) => f.explorer?.status === 'applied').length,
            failed: files.filter((f) => f.explorer?.status === 'failed' && !isHeld(f)).length,
            deferred: files.filter((f) => f.explorer?.status === 'deferred').length,
            review: files.filter((f) => needsReview(f) && !isDropped(f)).length,
            snoozed: files.filter((f) => isSnoozed(f)).length,
            dropped: files.filter((f) => isDropped(f)).length,
            updatedAt: cache[space].updatedAt,
        };
    }

    function schedulePersist(space) {
        space = spaceOf(space);
        clearTimeout(chromeTimer);
        chromeTimer = setTimeout(() => persistChrome(space).catch(() => {}), 250);
        clearTimeout(diskTimer);
        diskTimer = setTimeout(() => persistDisk(space).catch(() => {}), 700);
    }

    async function persistChrome(space) {
        space = spaceOf(space);
        await chrome.storage.local.set({ [storageKey(space)]: cache[space] });
    }

    async function persistDisk(space) {
        space = spaceOf(space);
        const r = await fetch(`${TOOLBOX}/fafo/ledger`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ space, ledger: cache[space] }),
            signal: AbortSignal.timeout(8000),
        });
        if (!r.ok) throw new Error('ledger disk write ' + r.status);
        return r.json().catch(() => ({}));
    }

    function mergeLedger(into, incoming) {
        if (!incoming || typeof incoming !== 'object') return into;
        const files = { ...(into.files || {}) };
        const src = incoming.files && typeof incoming.files === 'object' ? incoming.files : {};
        Object.keys(src).forEach((k) => {
            const rec = src[k];
            if (!rec || typeof rec !== 'object') return;
            const prev = files[k];
            if (!prev || (rec.updatedAt || 0) >= (prev.updatedAt || 0)) files[k] = rec;
        });
        into.files = files;
        into.updatedAt = Math.max(into.updatedAt || 0, incoming.updatedAt || 0, Date.now());
        return into;
    }

    async function load(space) {
        space = spaceOf(space);
        if (!loaded[space]) {
            try {
                const bag = await chrome.storage.local.get(storageKey(space));
                const got = bag[storageKey(space)];
                if (got && typeof got === 'object') mergeLedger(cache[space], got);
            } catch (_) {}
            loaded[space] = true;
        }
        try {
            const r = await fetch(`${TOOLBOX}/fafo/ledger?space=${encodeURIComponent(space)}`, {
                signal: AbortSignal.timeout(2500),
            });
            if (r.ok) {
                const data = await r.json();
                if (data && data.ledger) mergeLedger(cache[space], data.ledger);
            }
        } catch (_) {}
        return cache[space];
    }

    async function applyPending(space) {
        space = spaceOf(space);
        await load(space);
        const r = await fetch(`${TOOLBOX}/fafo/ledger/apply`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ space, ledger: cache[space] }),
            signal: AbortSignal.timeout(120000),
        });
        const data = await r.json().catch(() => ({}));
        if (data && data.ledger) {
            cache[space] = mergeLedger(emptyLedger(space), data.ledger);
            await persistChrome(space);
        }
        return data;
    }

    async function downloadCopy(space) {
        space = spaceOf(space);
        await load(space);
        const blob = new Blob([JSON.stringify(cache[space], null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = space === 'private' ? 'fafo-meta-ledger-private.json' : 'fafo-meta-ledger.json';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 1500);
    }

    global.FAFOMetaLedger = {
        KIND,
        FAIL_LIMIT,
        SNOOZE_MS,
        recordConfigured,
        harvest,
        markApplied,
        markFailed,
        markHold,
        markExplorer,
        pendingEntries,
        reviewEntries,
        heldEntries,
        recentFailLog,
        isAutoEligible,
        isHeld,
        isDropped,
        isSnoozed,
        needsReview,
        stats,
        load,
        persistChrome,
        persistDisk,
        applyPending,
        downloadCopy,
        cache,
    };
})(typeof window !== 'undefined' ? window : globalThis);
