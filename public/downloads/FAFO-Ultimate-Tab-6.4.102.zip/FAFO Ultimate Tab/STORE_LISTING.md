# FAFO Ultimate Tab — Chrome Web Store Listing (v6.4.0)

Use this copy when updating the Chrome Web Store listing.  
**Previous public version:** 2.9 → **This release:** **6.4.0**  
**Note:** Dirty versioning on purpose. Users did not see every intermediate number on the store.

### Version honesty (put in “What’s new” if you want)

```text
Version jump: 2.9 → 6.4.0. Yeah, we skipped a bunch of numbers.
Those intermediate versions weren’t all public store drops — a lot of work shipped as unpacked / internal builds.
You’re not missing secret 3.x–5.x store releases. 6.4.0 is the big catch-up.
```

---

## Store fields (ready to paste)

### Extension name
```text
FAFO Ultimate Tab
```

### Short description (132 characters max — stay under limit)
```text
Cinematic new-tab media center: local library, tags & ratings, smart playlists, pairing, FX. Privacy-first—media stays on your PC.
```
*(count ~118 chars)*

### Detailed description
```text
FAFO Ultimate Tab turns every new tab into a full media center for YOUR local videos and photos—cinema-quality playback, professional tagging, smart playlists, and before/after pairing. Built for creators, collectors, and anyone who wants a beautiful, private media hub instead of a blank new tab.

━━━━━━━━━━━━━━━━━━━━
▶ LOCAL MEDIA, ZERO CLOUD
━━━━━━━━━━━━━━━━━━━━
• Link video and photo folders once; folder handles persist across browser restarts
• One-click Restore Access after Chrome forgets permissions (no full re-link)
• Resync folders to pick up new files
• Optional bundled library.json for demos
• Right-click images/videos on the web → “Add to FAFO Library”
• Nothing is uploaded—playback and tags stay on your device

━━━━━━━━━━━━━━━━━━━━
▶ CINEMA PLAYER
━━━━━━━━━━━━━━━━━━━━
• Full-screen cinema layout with ambilight blur or solid backdrop
• Grid, carousel, and collage layouts
• HUD: prev / play-pause / next, seek bar, volume, mute, shuffle, speed, PiP, fullscreen
• Playback speed persists across clips (0.25×–2×)
• Instant Next/Prev navigation with play history (true “last clip” back)
• Fisher–Yates shuffle
• Ken Burns on photos; configurable photo duration
• Performance mode and toggles to lighten ambilight, particles, and neon audio

━━━━━━━━━━━━━━━━━━━━
▶ TAGS, RATINGS & WORKFLOW
━━━━━━━━━━━━━━━━━━━━
• On-play ★ Tags panel (press T): stars 1–5, freeform tags, smart suggestions
• Untagged clips LOOP until you press Next—tagging never auto-advances
• Skip tagged mode: Next jumps past already-tagged clips (then 5+ tags)
• Apply+Next bulk mode for fast tagging passes
• Graffiti Speed Tagging: full-library thumbnail grid — arm tags, click tiles, multi-select, length / FPS / resolution filters
• 40 hotkey slots: 10 keys × 4 modifier banks (Base / Shift / Ctrl+Shift / Alt+…)
• Tab cycles banks; left-click toggles a tag on/off; right-click assigns
• Persistent “Uses” counts (survive reloads) + library totals; Rebuild tool
• Recent tags row; resizable tags panel
• Explorer sync status (optional local companion writes Windows Tags/Rating)
• Shared tags between new-tab player and Options library modal

━━━━━━━━━━━━━━━━━━━━
▶ SMART PLAYLISTS & LIBRARY
━━━━━━━━━━━━━━━━━━━━
• Manual playlists and smart playlists (min rating, tags, untagged-only)
• Library grid with ratings/tag badges, search, pagination
• Per-file volume and scaling overrides
• Quick “add current clip to playlist” from the player (L)

━━━━━━━━━━━━━━━━━━━━
▶ PAIRING & COMPARE
━━━━━━━━━━━━━━━━━━━━
• Create before/after pairs from your library
• Slider, side-by-side, and blend compare for video and images
• Duplicate scanner (size / similar names)
• Thumbnail seek time control for library and pair thumbs

━━━━━━━━━━━━━━━━━━━━
▶ VISUAL FX & THEME
━━━━━━━━━━━━━━━━━━━━
• Theme engine (accent color) with live Options preview
• Particle FX: snow, rain, embers, smoke, sparks, neon
• Audio-reactive neon border: chase, dual chase, strobe, pulse, wave, spectrum, stack, flicker
• Clock & date HUD with position, size, font, 12h/seconds options

━━━━━━━━━━━━━━━━━━━━
▶ BACKUP & SAFETY
━━━━━━━━━━━━━━━━━━━━
• Tags/ratings auto-save to Chrome storage
• Rolling snapshots + history restore
• One-click JSON export/import for tags, hotkeys, pairs
• Separate export for theme/layout/FX config

━━━━━━━━━━━━━━━━━━━━
▶ OPTIONAL WINDOWS COMPANION
━━━━━━━━━━━━━━━━━━━━
For File Explorer Tags + star ratings in the actual files, run the free Explorer Metadata Companion (local only, 127.0.0.1). Download from the FAFO website—not required for the extension to work.

━━━━━━━━━━━━━━━━━━━━
▶ PERMISSIONS (WHY)
━━━━━━━━━━━━━━━━━━━━
• storage / unlimitedStorage — library settings, tags, playlists, backups
• contextMenus — “Add to FAFO Library” on web media
• localhost:8765 — optional local metadata server only (never remote)

Privacy: no account, no tracking SDK, no cloud sync of your media.

Open a new tab to play. Gear icon → Options for library, FX, tagging defaults, and backup.
```

### Category
Primary: **Productivity** (or **Entertainment** if that fits your listing history better)

### Language
English

### Version
```text
6.4.0
```

### What’s new (release notes for 6.4.0)
```text
2.9 → 6.4.0. Dirty version jump — you didn’t see every number in between (and that’s fine).

• Version: last public was 2.9; 6.4.0 is the catch-up release (skipped intermediate store versions)
• Tagging: untagged clips loop until Next; Skip tagged & Apply+Next; 40 hotkey slots (10×4 banks)
• pair_ID_##### stamped on both files in a pair; name/Grok-UUID pair suggestions (approve / skip)
• Pro compare: slider / side / blend, sweep, zoom, frame step, speed, mute, fullscreen
• Stable media IDs; persistent tag counts + Rebuild; Explorer sync status button
• Player: volume no longer skips tracks; speed sticks; faster Next; better shuffle & seek
• Backups, smart playlists, neon FX, library restore/resync, Options Tags & About pages
```

---

## Feature inventory (full capability list)

Use for “features” bullets, website, or support docs.

### Core experience
| Feature | Notes |
|---------|--------|
| New Tab override | Full media center on every new tab |
| Cinema layout | Primary fullscreen player |
| Grid / carousel / collage | Multi-view layouts |
| Empty state + Options CTA | Guides first-time setup |
| Toolbar icon → Options | Quick access to settings |

### Library
| Feature | Notes |
|---------|--------|
| Link video folders | File System Access + persistent handles |
| Link photo folders | Same |
| Restore Access | Re-grant permission without re-picking |
| Resync All / per-folder resync | Detect new/removed files |
| Wipe library | Nuclear reset |
| Web clipper | Context menu add image/video/audio |
| Bundled library.json | Optional demo list |
| Library grid | Thumbs, badges, pagination |
| Per-asset modal | Tags, rating, volume/scale overrides, playlist add |

### Playback controls
| Feature | Notes |
|---------|--------|
| Play / pause / prev / next | Mouse + keyboard |
| Seek bar | Click/drag; no false end-skip |
| Volume + mute | Debounced save; no playlist rebuild |
| Shuffle | Fisher–Yates |
| Speed 0.25×–2× | Persists across clips |
| Loops per clip | For tagged auto-advance |
| PiP / fullscreen | Standard APIs |
| Play history | Prev returns last watched |
| Instant manual skip | No artificial delay on Next |
| Untagged loop | Until Next |
| Photo duration + Ken Burns | Configurable |

### Tagging & ratings
| Feature | Notes |
|---------|--------|
| ★ panel (T) | Stars, tags, filter, suggestions |
| Hotkeys 10×4 banks | Base/Shift/Ctrl+Shift/Alt+… |
| Click toggle hotkeys | Apply/remove |
| Right-click assign | Slot or tag context menus |
| Skip tagged | Next filter + loop |
| Apply+Next | Bulk tagging |
| Recent tags | Quick re-apply |
| Uses # + Σ totals | Sort modes; rebuild |
| Count up/down on remove | Accurate counters |
| Stable IDs | Exact match only |
| Explorer companion | Optional pywin32 + local API |
| Sync status LED | Online/offline on dock |

### Playlists
| Feature | Notes |
|---------|--------|
| Manual playlists | Add from library or player |
| Smart playlists | Rating / tags / untagged rules |
| Active playlist selector | Drive what plays on new tab |

### Pairing
| Feature | Notes |
|---------|--------|
| Before/After pairs | Create, list, open |
| Compare modes | Slider / side-by-side / blend |
| Sync play/pause | Video pairs |
| Duplicates | Size / name heuristics |
| Thumb seek time | Shared with library thumbs |

### Visuals
| Feature | Notes |
|---------|--------|
| Accent theme | Live Options + new tab |
| Ambilight | Blur or solid |
| Neon border | 8 patterns, audio reactive |
| Particles | 6 systems with density/size/blur |
| Clock HUD | Position, font, date, 12h, seconds |
| Performance toggles | Ambience, particles, neon audio, filters |

### Data & backup
| Feature | Notes |
|---------|--------|
| Chrome storage | Tags, config, pairs |
| Auto snapshot + history | Restore after wipe |
| Export/import tags JSON | Full backup |
| Export/import config JSON | Theme/FX only |
| Options About page | Version + changelog |

### Privacy & network
| Feature | Notes |
|---------|--------|
| No cloud media upload | Local only |
| localhost:8765 only | Optional companion |
| No account required | — |

---

## Packaging checklist (store zip)

**Include**
- `manifest.json` (version **6.4.0**)
- `newtab.html`, `script.js`, `styles.css`
- `options.html`, `options.js`
- `background.js`
- `fafo-id.js`, `fafo-library.js`, `fafo-meta.js`, `fafo-backup.js`, `fafo-pairs.js`
- `neon-border.js`, `particle-fx.js`
- `icon_128.png` (and any required sizes)
- Optional small `library.json` (no huge Videos folder)
- Optional short `readme.txt` / privacy snippet

**Exclude**
- `Videos\` (large MP4 library)
- `explorer-meta\`, `dist-website\`, installers, `unins000.*`, `Output\`
- `__pycache__`, developer-only notes if desired

**Store privacy practices**
- Single purpose: new-tab local media player + library tools  
- Data: local storage only; optional localhost metadata  
- No remote code; no selling user data  

---

## Screenshots to capture (recommended set)

1. Cinema mode playing a video with neon/HUD  
2. Tags panel open (hotkeys + tag library)  
3. Options → Visual Library with folder linked  
4. Smart playlist / library grid with ratings  
5. Pairing compare slider  
6. Particles + theme  
7. Backup / Export screen  
8. About / v6.4 release panel  

---

## Support / website blurb (short)

```text
FAFO Ultimate Tab 6.4.0 is a privacy-first new-tab media center for local videos and photos—cinema playback, tags & ratings, smart playlists, and before/after pairing. Optional Windows companion writes Explorer tags. Your media never leaves your PC.
```
