# FAFO — Vista+ Explorer-style folder picker.
# Prints the selected path to stdout. Empty stdout = cancelled / failed.
param(
    [string]$Title = "FAFO — pick a folder (all subfolders included)",
    [string]$StartPath = ""
)

$ErrorActionPreference = "Continue"

$code = @"
using System;
using System.Runtime.InteropServices;

public static class FafoFolderPick {
    [ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
    private class FileOpenDialogCOM {}

    [ComImport, Guid("42f85136-db7e-439c-85f1-e4075d135fc8"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IFileDialog {
        [PreserveSig] int Show(IntPtr parent);
        void SetFileTypes(uint cFileTypes, IntPtr rgFilterSpec);
        void SetFileTypeIndex(uint iFileType);
        void GetFileTypeIndex(out uint piFileType);
        void Advise(IntPtr pfde, out uint pdwCookie);
        void Unadvise(uint dwCookie);
        void SetOptions(uint fos);
        void GetOptions(out uint pfos);
        void SetDefaultFolder(IShellItem psi);
        void SetFolder(IShellItem psi);
        void GetFolder(out IShellItem ppsi);
        void GetCurrentSelection(out IShellItem ppsi);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);
        void GetResult(out IShellItem ppsi);
        void AddPlace(IShellItem psi, int fdap);
        void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);
        void Close(int hr);
        void SetClientGuid(ref Guid guid);
        void ClearClientData();
        void SetFilter(IntPtr pFilter);
    }

    [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"),
     InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IShellItem {
        void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
        void GetParent(out IShellItem ppsi);
        void GetDisplayName(uint sigdnName, out IntPtr ppszName);
        void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);
        void Compare(IShellItem psi, uint hint, out int piOrder);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    private static extern void SHCreateItemFromParsingName(
        [MarshalAs(UnmanagedType.LPWStr)] string pszPath,
        IntPtr pbc,
        [In] ref Guid riid,
        out IShellItem ppv);

    [DllImport("ole32.dll")]
    private static extern void CoTaskMemFree(IntPtr pv);

    const uint FOS_PICKFOLDERS = 0x20;
    const uint FOS_FORCEFILESYSTEM = 0x40;
    const uint SIGDN_FILESYSPATH = 0x80058000;

    public static string Pick(string title, string startPath) {
        var dlg = (IFileDialog)new FileOpenDialogCOM();
        dlg.SetOptions(FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM);
        if (!string.IsNullOrEmpty(title)) dlg.SetTitle(title);
        if (!string.IsNullOrEmpty(startPath) && System.IO.Directory.Exists(startPath)) {
            IShellItem folder;
            var iid = new Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE");
            SHCreateItemFromParsingName(startPath, IntPtr.Zero, ref iid, out folder);
            dlg.SetFolder(folder);
        }
        int hr = dlg.Show(IntPtr.Zero);
        if (hr != 0) return "";
        IShellItem result;
        dlg.GetResult(out result);
        IntPtr psz;
        result.GetDisplayName(SIGDN_FILESYSPATH, out psz);
        string path = Marshal.PtrToStringUni(psz);
        CoTaskMemFree(psz);
        return path ?? "";
    }
}
"@

function Show-FallbackDialog {
    Add-Type -AssemblyName System.Windows.Forms | Out-Null
    $d = New-Object System.Windows.Forms.FolderBrowserDialog
    $d.Description = $Title
    $d.ShowNewFolderButton = $true
    try { $d.UseDescriptionForTitle = $true } catch {}
    try { $d.AutoUpgradeEnabled = $true } catch {}
    if ($StartPath -and (Test-Path -LiteralPath $StartPath)) {
        try { $d.SelectedPath = $StartPath } catch {}
    }
    $form = New-Object System.Windows.Forms.Form
    $form.TopMost = $true
    $form.ShowInTaskbar = $false
    $form.StartPosition = "CenterScreen"
    $form.Size = New-Object System.Drawing.Size(1, 1)
    $form.Opacity = 0
    [void]$form.Show()
    $form.Activate()
    $r = $d.ShowDialog($form)
    $form.Close()
    $form.Dispose()
    if ($r -eq [System.Windows.Forms.DialogResult]::OK) {
        [Console]::Out.Write($d.SelectedPath)
    }
}

try {
    if (-not ("FafoFolderPick" -as [type])) {
        Add-Type -TypeDefinition $code -Language CSharp -ErrorAction Stop
    }
    $picked = [FafoFolderPick]::Pick($Title, $StartPath)
    if ($picked) { [Console]::Out.Write($picked) }
} catch {
    Show-FallbackDialog
}
