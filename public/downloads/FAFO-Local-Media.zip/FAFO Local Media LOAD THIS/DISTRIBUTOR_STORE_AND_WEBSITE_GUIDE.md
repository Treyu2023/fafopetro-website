# FAFO Ultimate Tab — Distributor Guide  
## Chrome Web Store + FAFOPetro.com (Website Companion)

**Who this is for:** You (the publisher), when updating the **Chrome Web Store** listing and/or **www.FAFOPetro.com**.  
**Not for end users** — they use `TAGS_AND_RATINGS.md` and `explorer-meta\README.md`.

| Item | Location |
|------|----------|
| This guide | `DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md` (this file) |
| End-user tags/ratings setup | `TAGS_AND_RATINGS.md` |
| Companion package source | `explorer-meta\` |
| Ready-to-host zip | `dist-website\FAFO_Explorer_Metadata_Companion.zip` |
| Extension manifest | `manifest.json` |
| Public site | https://www.FAFOPetro.com (Google Sites) |

---

## 1. Product split (remember this)

| Deliverable | Channel | What users get |
|-------------|---------|----------------|
| **Browser extension** | Chrome Web Store (Edge can sideload/store later) | New-tab player, ★ Tags UI, tags/ratings saved **in the extension** |
| **Explorer Metadata Companion** | FAFOPetro.com (Drive link) | Optional Windows helper that writes **Tags + Rating into real files** for File Explorer |

- Do **not** put the full `Videos\` library in the Web Store package (size + review risk).
- Do **not** require the companion for the extension to install; it is **optional**.
- Google **Play** = Android apps. Browser extensions go to the **Chrome Web Store**.

---

## 2. Folder map (what to ship where)

```
FAFO_Ultimate_Tab/   (or your release root)
│
├── DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md  ← YOU: store + website updates
├── TAGS_AND_RATINGS.md                    ← USERS: tags/ratings how-to
├── readme.txt                             ← quick install (extension)
│
├── manifest.json                          ← Web Store package core
├── newtab.html, script.js, styles.css
├── options.html, options.js
├── library.json, Icon.ico, …
│
├── explorer-meta/                         ← companion SOURCE (also zip contents)
│   ├── INSTALL_DEPS.bat
│   ├── START_META_SERVER.bat
│   ├── ADD_VIDEO_FOLDER.bat
│   ├── server.py, file_metadata.py
│   ├── requirements.txt, README.md, …
│   └── TAGS_AND_RATINGS.md (copied into zip)
│
├── dist-website/
│   └── FAFO_Explorer_Metadata_Companion.zip   ← upload this to Drive / site
│
└── Videos/   (optional local/bundled media — usually NOT for Web Store zip)
```

**Beta / other copies** may also live under:

- `Desktop\FAFO Local Media Beta\Beta_Release_V5_(distribution checked_video only)\`
- `Desktop\FAFO Local Media Beta\New_Tab_Local_Media_V1.2\`

Prefer treating **`FAFO_Ultimate_Tab`** (or one clear release folder) as the source of truth before each publish.

---

## 3. Chrome Web Store — update checklist

### 3.1 What to package for the store

Include **only** extension files, for example:

- `manifest.json`
- `newtab.html`, `script.js`, `styles.css`
- `options.html`, `options.js`
- `library.json` (if small / needed)
- Icons (`Icon.ico` / PNG if store requires PNG — convert if review complains about `.ico`)
- Optional tiny `readme` for users is fine

**Usually exclude from the store zip:**

| Exclude | Why |
|---------|-----|
| `Videos\` (hundreds of MP4s) | Package size, privacy, review |
| `explorer-meta\` | Ship on website instead |
| `dist-website\` | Distributor-only |
| `Output\`, installers, `unins000.*` | Not needed for MV3 store item |
| This distributor guide | Optional; not required in package |

### 3.2 Manifest notes (keep these)

Current relevant settings (verify in `manifest.json` before upload):

- **MV3** `manifest_version: 3`
- **New Tab** override: `chrome_url_overrides.newtab`
- **Permissions:** `storage`, `unlimitedStorage`
- **Host permissions (required for companion):**
  - `http://127.0.0.1:8765/*`
  - `http://localhost:8765/*`  
  These let the extension call the local metadata server. They are **localhost-only** — justify in the listing privacy/description as “optional local helper on the user’s PC.”

Bump **`version`** in `manifest.json` on every store upload (e.g. `5.2.1` → `5.2.2`).

### 3.3 Listing text (suggested)

**Short description (store limit ~132 chars):**  
Something like:  
*4K HDR video new tab. Rate and tag clips while they play. Optional Windows companion adds Explorer Tags & Ratings.*

**Detailed description — include:**

1. What FAFO does (new tab video player, cinema/grid/carousel if still accurate).  
2. On-play **★ Tags** panel (`T` key).  
3. Tags/ratings work in the extension without extra software.  
4. **Optional:** Windows Explorer sync via free companion on **https://www.FAFOPetro.com**.  
5. Companion needs Python once; runs a local server on `127.0.0.1:8765` only.  
6. Link to FAFOPetro for support / companion download.

**Single purpose / permission justification (review):**

- `storage` / `unlimitedStorage` — save library handles, tag/rating prefs.  
- `host_permissions` localhost:8765 — optional local metadata writer; no cloud.  
- New Tab override — product is a video new tab.

### 3.4 Upload steps (Chrome Web Store Developer Dashboard)

1. Zip the **extension-only** folder (no Videos, no explorer-meta unless you intentionally want them).  
2. Go to [Chrome Web Store Developer Dashboard](https://chrome.google.com/webstore/devconsole).  
3. Open the FAFO item → **Package** → Upload new package.  
4. Update listing text, screenshots, website URL → **https://www.FAFOPetro.com**.  
5. Submit for review.  
6. After publish, note the public store URL for the Sites page.

### 3.5 Screenshots to keep updated

- New tab with video playing  
- **★ Tags** panel open (stars + tags)  
- Options / add folder (if useful)  
- Optional: File Explorer showing Tags/Rating columns (caption: “with optional companion from FAFOPetro.com”)

---

## 4. Website (FAFOPetro.com / Google Sites) — companion download

### 4.1 Why Drive + Sites link

Google Sites is poor for large binaries. Pattern that works:

1. Host **`FAFO_Explorer_Metadata_Companion.zip`** on **Google Drive**.  
2. Share: **Anyone with the link → Viewer**.  
3. On Sites, button/link → that Drive file (or “Open in Drive”).

Zip location on your machine:

```text
FAFO_Ultimate_Tab\dist-website\FAFO_Explorer_Metadata_Companion.zip
```

Size is tiny (~tens of KB) — fine for Drive and Sites.

### 4.2 Rebuild the website zip after code changes

From PowerShell (adjust path if your folder moved):

```powershell
$src = "C:\Users\rkey2\FAFO_Ultimate_Tab"
$stage = Join-Path $env:TEMP "FAFO_explorer_meta_stage"
$zipDir = Join-Path $src "dist-website"
$zipPath = Join-Path $zipDir "FAFO_Explorer_Metadata_Companion.zip"

New-Item -ItemType Directory -Path $zipDir -Force | Out-Null
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path $stage -Force | Out-Null

Copy-Item "$src\explorer-meta\*" $stage -Force
Copy-Item "$src\TAGS_AND_RATINGS.md" "$stage\TAGS_AND_RATINGS.md" -Force
Get-ChildItem $stage -Filter "library_index.json" -ErrorAction SilentlyContinue | Remove-Item -Force
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

Compress-Archive -Path "$stage\*" -DestinationPath $zipPath -Force
Get-Item $zipPath
```

Then **replace** the file on Google Drive (same link if you replace in place; otherwise update the Sites link).

### 4.3 Suggested Sites page section

**Title:** Optional: Windows Explorer Tags & Star Ratings  

**Body (copy/paste):**

> The FAFO Chrome extension can rate and tag videos while they play.  
>  
> Tags and stars are always saved **inside the extension**.  
>  
> To also write **Tags** and **Rating** into the real video files (so Windows File Explorer and Windows Search can see them):  
>  
> 1. Install FAFO from the Chrome Web Store.  
> 2. Download the free **Explorer Metadata Companion** (zip below).  
> 3. Unzip anywhere.  
> 4. Run **`INSTALL_DEPS.bat`** once (requires [Python](https://www.python.org/downloads/) with “Add to PATH”).  
> 5. Run **`START_META_SERVER.bat`** whenever you want Explorer sync (leave the window open).  
> 6. Run **`ADD_VIDEO_FOLDER.bat`** for your video folders (the server must already be running).  
> 7. In FAFO: open a new tab → **★ Tags** or press **T** while a video plays.  
>  
> Full instructions are in **`TAGS_AND_RATINGS.md`** inside the zip.  
>  
> The companion only listens on this PC (`127.0.0.1`) — nothing is uploaded to the cloud.

**Button labels that work well:**

- Download Explorer Metadata Companion  
- Chrome Web Store — FAFO Ultimate Tab  
- Support / docs (link to same page section or TAGS summary)

### 4.4 What must be inside the companion zip

Confirm after each rebuild:

- `INSTALL_DEPS.bat`
- `START_META_SERVER.bat`
- `ADD_VIDEO_FOLDER.bat`
- `add_folder.py`
- `server.py`
- `file_metadata.py`
- `requirements.txt` (includes **pywin32**)
- `config.json`
- `README.md`
- `TAGS_AND_RATINGS.md`

---

## 5. How the pieces talk (for your own debugging)

```
[Chrome extension — Web Store]
        │  rate / tag while video plays
        │  also saves to chrome.storage
        ▼
  fetch http://127.0.0.1:8765/api/fs/write-metadata
        │
        ▼
[Companion OR AI HTML TOOLBOX server — only ONE on port 8765]
        │
        ▼
  Windows file properties:
    System.Keywords  → Explorer Tags
    System.Rating    → Explorer stars (1–5)
```

- If companion is **not** running: FAFO still works; status may say run `START_META_SERVER.bat`.  
- If file **not indexed**: user must `ADD_VIDEO_FOLDER.bat` (browser cannot send full paths for security).  
- Port **8765**: same as AI HTML TOOLBOX — users run **one** of those servers, not both.

---

## 6. Release checklist (print / reuse every time)

### A. Code ready

- [ ] Features tested with **Load unpacked**  
- [ ] `manifest.json` **version** bumped  
- [ ] `host_permissions` still include localhost:8765  
- [ ] Description/options still mention companion + FAFOPetro if needed  

### B. Web Store

- [ ] Extension-only zip built (no Videos, no explorer-meta)  
- [ ] Uploaded in Developer Dashboard  
- [ ] Listing + screenshots + homepage URL updated  
- [ ] Submitted / published  

### C. Website companion

- [ ] `explorer-meta` changes tested (`INSTALL_DEPS` + `START_META_SERVER`)  
- [ ] `dist-website\FAFO_Explorer_Metadata_Companion.zip` rebuilt  
- [ ] Zip replaced on Google Drive  
- [ ] FAFOPetro.com link still works  
- [ ] Sites blurb still matches current bat file names  

### D. Optional

- [ ] Sync same files into Beta release folders if you still ship installers  
- [ ] Test a clean PC mental path: Store install → companion zip → Python → tag → Explorer columns  

---

## 7. User-facing docs (do not rewrite every time)

| Audience | File |
|----------|------|
| End users (tags + Explorer) | `TAGS_AND_RATINGS.md` |
| Companion-only quick start | `explorer-meta\README.md` |
| Extension load unpacked | `readme.txt` |
| **You** (store + site) | **`DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md`** (this file) |

When you change bat names, ports, or product names, update:

1. This distributor guide  
2. `TAGS_AND_RATINGS.md`  
3. Sites blurb on FAFOPetro.com  
4. Chrome Web Store description  

---

## 8. Dependencies reminder (companion)

Installed by `INSTALL_DEPS.bat` / `requirements.txt`:

| Package | Role |
|---------|------|
| **pywin32** | Windows Explorer Tags + Rating (`System.Keywords`, `System.Rating`) |
| fastapi + uvicorn | Local HTTP server |
| mutagen | Extra MP4 embedded tags |
| pydantic | API models |
| Pillow | Optional/helpers |

Python **3.10+** recommended; **Add python.exe to PATH** during install.

---

## 9. Support answers (quick)

**“Tags don’t show in Explorer.”**  
Companion not running, or folder not registered with `ADD_VIDEO_FOLDER.bat`.

**“Python not found.”**  
Install Python from python.org with PATH checked; reopen the bat.

**“Port in use.”**  
AI HTML TOOLBOX or another FAFO meta server already on 8765 — use that one.

**“I only installed from the Chrome Store.”**  
That’s enough for in-extension tags. Explorer file write needs the free companion from FAFOPetro.com.

---

## 10. Version log (fill in as you publish)

| Date | Extension version | Companion notes | Store | Website zip |
|------|-------------------|-----------------|-------|-------------|
| (example) 2026-__-__ | 5.2.1 | Initial explorer-meta + host_permissions | ☐ | ☐ |
|  |  |  | ☐ | ☐ |
|  |  |  | ☐ | ☐ |

---

*Last structured for FAFO Ultimate Tab with optional Explorer companion on port 8765 and distribution via Chrome Web Store + www.FAFOPetro.com.*
