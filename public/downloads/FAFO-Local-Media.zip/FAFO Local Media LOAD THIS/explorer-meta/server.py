"""
FAFO Explorer Metadata Server
-----------------------------
Lightweight local companion for FAFO Ultimate Tab.

Listens on http://127.0.0.1:8765 and writes real Windows file metadata
(System.Keywords tags + System.Rating stars) so File Explorer and other
apps can see ratings/tags set while videos play.

Compatible API subset used by FAFO:
  GET  /api/health
  GET  /api/media?search=&limit=   (Toolbox-compatible catalog search)
  GET  /api/tags                  (Toolbox-compatible tag vocabulary)
  POST /api/fs/write-metadata
  POST /api/fs/write-metadata-batch   (bulk Explorer push for many files)
  GET  /api/fs/read-metadata
  POST /api/library/add-folder
  GET  /api/library
  POST /api/library/rescan

Runs on 127.0.0.1:8765. AI HTML TOOLBOX uses 127.0.0.87:18765 — both can run at once.
"""
from __future__ import annotations

import json
import logging
import os
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

# Ensure local imports work when launched from any CWD
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from file_metadata import (
    write_file_metadata,
    read_file_metadata,
    normalize_tags,
    is_junk_tag,
)

HOST = "127.0.0.1"
PORT = 8765
CONFIG_PATH = ROOT / "config.json"
INDEX_PATH = ROOT / "library_index.json"
TAGS_CACHE_PATH = ROOT / "tags_cache.json"

VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi", ".wmv", ".ts"}
SKIP_DIRS = {"$recycle.bin", "system volume information", ".git", "node_modules", "__pycache__"}

# FAFO polls these constantly — hide successful responses so the console doesn't scroll forever.
# Errors (4xx/5xx) and write/rescan traffic still print.
_QUIET_OK_PATHS = (
    "/api/health",
    "/api/media",
    "/api/tags",
    "/api/library",
    "/openapi.json",
    "/docs",
    "/favicon.ico",
)


class _QuietPollFilter(logging.Filter):
    """Drop uvicorn access lines for noisy successful polls."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        # Typical: '127.0.0.1:1234 - "GET /api/health HTTP/1.1" 200 OK'
        is_ok = '" 200' in msg or msg.rstrip().endswith(" 200") or " 200 OK" in msg
        if not is_ok:
            return True  # always show errors / non-200
        for path in _QUIET_OK_PATHS:
            # match path as request target, not as random substring of a longer route
            if f" {path} " in msg or f" {path}?" in msg or f'"{path} ' in msg or f'"{path}?' in msg:
                return False
            if f" {path} HTTP" in msg or f'"{path} HTTP' in msg:
                return False
        return True


def _install_quiet_access_logs() -> None:
    filt = _QuietPollFilter()
    for name in ("uvicorn.access", "uvicorn.asgi"):
        logging.getLogger(name).addFilter(filt)


app = FastAPI(title="FAFO Explorer Metadata Server", version="1.2.1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_lock = threading.Lock()
_index: dict[str, list[dict[str, Any]]] = {}  # name_lower -> [{path, size, mtime, name}]
_config: dict[str, Any] = {"watched_dirs": [], "version": 1}
# lower(tag) -> display form; filled by write-metadata + optional reads
_tag_vocab: dict[str, str] = {}
# Deferred Explorer shell writes when Chrome has the file open
_pending_shell: dict[str, dict[str, Any]] = {}  # path -> {tags, rating, tries}
_pending_shell_thread: threading.Thread | None = None


def load_config() -> dict[str, Any]:
    global _config
    if CONFIG_PATH.exists():
        try:
            _config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            _config = {"watched_dirs": [], "version": 1}
    else:
        _config = {"watched_dirs": [], "version": 1}
    _config.setdefault("watched_dirs", [])
    return _config


def save_config() -> None:
    CONFIG_PATH.write_text(json.dumps(_config, indent=2), encoding="utf-8")


def load_index() -> None:
    global _index
    if INDEX_PATH.exists():
        try:
            data = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
            _index = data.get("by_name") or {}
            return
        except Exception:
            pass
    _index = {}


def save_index() -> None:
    INDEX_PATH.write_text(
        json.dumps({"by_name": _index, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )


def load_tag_vocab() -> None:
    global _tag_vocab
    if TAGS_CACHE_PATH.exists():
        try:
            raw = TAGS_CACHE_PATH.read_text(encoding="utf-8-sig")
            data = json.loads(raw)
            tags = data.get("tags") or []
            _tag_vocab = {}
            dirty = False
            for t in tags:
                s = str(t).strip()
                if not s or is_junk_tag(s):
                    dirty = True
                    continue
                for part in normalize_tags([s]):
                    _tag_vocab[part.lower()] = part
            # Rewrite cache if we dropped junk so pollution does not re-seed the UI
            if dirty or len(_tag_vocab) != len(tags):
                try:
                    save_tag_vocab()
                except Exception:
                    pass
            return
        except Exception:
            pass
    _tag_vocab = {}


def save_tag_vocab() -> None:
    tags = sorted(
        (t for t in _tag_vocab.values() if t and not is_junk_tag(t)),
        key=str.lower,
    )
    TAGS_CACHE_PATH.write_text(
        json.dumps({"tags": tags, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )


def remember_tags(tags: list[str] | None) -> None:
    if not tags:
        return
    changed = False
    with _lock:
        for t in normalize_tags(tags):
            if is_junk_tag(t):
                continue
            low = t.lower()
            if low not in _tag_vocab:
                _tag_vocab[low] = t
                changed = True
    if changed:
        try:
            save_tag_vocab()
        except Exception:
            pass


def all_entries() -> list[dict[str, Any]]:
    with _lock:
        out: list[dict[str, Any]] = []
        for bucket in _index.values():
            out.extend(bucket)
        return out


def search_index(search: str, limit: int = 80) -> tuple[list[dict[str, Any]], int]:
    """
    Fast in-memory search over the indexed name map.
    ~3k files is trivial; no disk walk on each request.
    Returns (page_items, total_matches).
    """
    limit = max(1, min(int(limit or 80), 500))
    q = (search or "").strip().lower()
    entries = all_entries()
    if not q:
        # Newest-ish first when no query
        entries = sorted(entries, key=lambda e: float(e.get("mtime") or 0), reverse=True)
        return entries[:limit], len(entries)

    # Rank: exact name > startswith > contains (name or path)
    exact: list[dict[str, Any]] = []
    starts: list[dict[str, Any]] = []
    contains: list[dict[str, Any]] = []
    for e in entries:
        name = str(e.get("name") or "")
        path = str(e.get("path") or "")
        nl = name.lower()
        pl = path.lower()
        if nl == q or nl == q + ".mp4":
            exact.append(e)
        elif nl.startswith(q) or Path(nl).stem.startswith(q.rstrip(".mp4")):
            starts.append(e)
        elif q in nl or q in pl:
            contains.append(e)

    ranked = exact + starts + contains
    # De-dupe by path while preserving order
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for e in ranked:
        p = str(e.get("path") or "")
        if not p or p in seen:
            continue
        seen.add(p)
        out.append(e)
    return out[:limit], len(out)


def entry_to_media_item(e: dict[str, Any], *, read_tags: bool = False) -> dict[str, Any]:
    """Shape compatible with FAFO / Toolbox media query consumers."""
    name = e.get("name") or Path(str(e.get("path") or "")).name
    item: dict[str, Any] = {
        "id": str(e.get("path") or name),
        "name": name,
        "path": e.get("path"),
        "size": e.get("size"),
        "mtime": e.get("mtime"),
        "type": "video",
        "tags": [],
        "rank": 0,
    }
    if read_tags and e.get("path"):
        try:
            meta = read_file_metadata(e["path"])
            item["tags"] = meta.get("tags") or []
            item["rank"] = int(meta.get("rating") or 0)
            remember_tags(item["tags"])
        except Exception:
            pass
    return item


def scan_dir(root: Path) -> int:
    """Index video files under root. Returns count added/updated."""
    count = 0
    root = root.resolve()
    if not root.is_dir():
        return 0

    for dirpath, dirnames, filenames in os.walk(root):
        # prune junk
        dirnames[:] = [
            d for d in dirnames
            if d.lower() not in SKIP_DIRS and not d.startswith(".")
        ]
        for name in filenames:
            ext = Path(name).suffix.lower()
            if ext not in VIDEO_EXTS:
                continue
            full = Path(dirpath) / name
            try:
                st = full.stat()
            except OSError:
                continue
            entry = {
                "path": str(full),
                "name": name,
                "size": st.st_size,
                "mtime": st.st_mtime,
            }
            key = name.lower()
            with _lock:
                bucket = _index.setdefault(key, [])
                # replace same path
                bucket = [e for e in bucket if e.get("path") != entry["path"]]
                bucket.append(entry)
                _index[key] = bucket
            count += 1
    return count


def rebuild_index() -> int:
    global _index
    with _lock:
        _index = {}
    total = 0
    for d in list(_config.get("watched_dirs") or []):
        total += scan_dir(Path(d))
    # Bundled/default Videos/ is intentionally NOT auto-indexed.
    # Add folders via Options / ADD_VIDEO_FOLDER / POST /api/library/add-folder only.
    save_index()
    return total


def find_by_identity(
    name: str | None,
    size: int | None,
    mtime: float | None,
    path: str | None = None,
) -> Path | None:
    if path:
        p = Path(path)
        if p.is_file():
            return p

    if not name:
        return None

    key = name.lower()
    with _lock:
        candidates = list(_index.get(key) or [])

    # Partial / truncated filename (common when logs/UI cut long names)
    if not candidates:
        hits, _total = search_index(name, limit=20)
        candidates = hits

    if not candidates:
        # last resort: live rglob only for exact basename (avoid walking 3k on every miss)
        base = Path(name).name
        for d in list(_config.get("watched_dirs") or []):
            root = Path(d)
            if not root.is_dir():
                continue
            try:
                for hit in root.rglob(base):
                    if hit.is_file():
                        candidates.append({
                            "path": str(hit),
                            "name": hit.name,
                            "size": hit.stat().st_size,
                            "mtime": hit.stat().st_mtime,
                        })
                        break
            except OSError:
                continue
            if candidates:
                break

    if not candidates:
        return None

    if size is not None:
        sized = [c for c in candidates if int(c.get("size") or 0) == int(size)]
        if sized:
            candidates = sized

    if mtime is not None and len(candidates) > 1:
        mt = float(mtime)
        if mt > 1e12:
            mt = mt / 1000.0
        candidates = sorted(candidates, key=lambda c: abs(float(c.get("mtime") or 0) - mt))

    p = Path(candidates[0]["path"])
    return p if p.is_file() else None


class FileMetaWrite(BaseModel):
    path: str | None = None
    name: str | None = None
    size: int | None = None
    mtime: float | None = None
    tags: list[str] | None = None
    rating: int | None = None
    update_catalog: bool = True
    # Optional client key so bulk results map back to chrome.storage entries
    client_key: str | None = None


class FileMetaWriteBatch(BaseModel):
    items: list[FileMetaWrite] = Field(default_factory=list)
    stop_on_error: bool = False


class AddFolder(BaseModel):
    path: str = Field(..., description="Absolute folder path to index for metadata writes")


@app.on_event("startup")
def on_startup() -> None:
    # Re-apply after uvicorn configures loggers
    _install_quiet_access_logs()
    load_config()
    load_index()
    load_tag_vocab()
    # Auto-index bundled Videos + configured dirs
    try:
        n = rebuild_index()
        print(f"[FAFO Meta] Indexed {n} video files from watched folders.")
        print(f"[FAFO Meta] Tag vocabulary: {len(_tag_vocab)} tags")
        print("[FAFO Meta] Quiet poll logs ON (health/media/tags success hidden).")
    except Exception as e:
        print(f"[FAFO Meta] Index warning: {e}")


@app.get("/api/health")
def health():
    with _lock:
        file_count = sum(len(v) for v in _index.values())
        tag_count = len(_tag_vocab)
        pending_n = len(_pending_shell)
    return {
        "ok": True,
        "service": "fafo-explorer-meta",
        "version": "1.2.1",
        "role": "S2 FAFO Local Media Tagger (Chrome extension tags/ratings companion)",
        "endpoint": f"http://{HOST}:{PORT}",
        "watched_dirs": _config.get("watched_dirs") or [],
        "indexed_names": len(_index),
        "file_count": file_count,
        "tag_count": tag_count,
        "pending_shell_writes": pending_n,
        "features": [
            "media_search",
            "tags",
            "tag_scrub",
            "fs_write_metadata",
            "fs_write_metadata_batch",
            "quiet_poll_logs",
            "no_bundled_videos",
        ],
    }


@app.get("/api/media")
def api_media(
    search: str = "",
    limit: int = 80,
    page: int = 0,
    read_tags: bool = False,
):
    """
    Toolbox-compatible media search used by FAFO (fetchTagsForIdentity, etc.).
    Always returns 200 with items[] — never 404 for empty results.
    Search is pure memory over the index (fast with thousands of files).
    """
    limit = max(1, min(int(limit or 80), 500))
    page = max(0, int(page or 0))
    # FAFO usually asks for limit=5; still compute full match total in memory
    need = limit * (page + 1)
    hits, total = search_index(search, limit=max(need, limit))
    # If paging beyond first window, re-fetch enough rows
    if need > limit:
        hits, total = search_index(search, limit=need)
    start = page * limit
    page_hits = hits[start : start + limit]
    # Only read shell tags for the small result page when requested or limit is tiny
    do_read = read_tags or (bool(search) and limit <= 10)
    items = [entry_to_media_item(e, read_tags=do_read) for e in page_hits]
    return {
        "items": items,
        "total": total,
        "page": page,
        "limit": limit,
        "search": search,
    }


@app.get("/api/tags")
def api_tags():
    """Toolbox-compatible tag list. Returns [] until tags are written / harvested."""
    with _lock:
        tags = sorted(
            (t for t in _tag_vocab.values() if t and not is_junk_tag(t)),
            key=str.lower,
        )
    return tags


@app.post("/api/tags/scrub")
def api_tags_scrub():
    """Drop junk tags from vocabulary + tags_cache (Signature/ComfyUI dumps, etc.)."""
    global _tag_vocab
    removed = 0
    with _lock:
        keep: dict[str, str] = {}
        for low, display in list(_tag_vocab.items()):
            if is_junk_tag(display) or is_junk_tag(low):
                removed += 1
                continue
            for part in normalize_tags([display]):
                keep[part.lower()] = part
        _tag_vocab = keep
        remaining = len(_tag_vocab)
        tags_out = sorted(_tag_vocab.values(), key=str.lower)
    try:
        save_tag_vocab()
    except Exception as e:
        raise HTTPException(500, f"Failed to save cleaned tags: {e}") from e
    return {
        "ok": True,
        "removed": removed,
        "remaining": remaining,
        "tags": tags_out,
    }


@app.get("/api/library")
def library_info():
    with _lock:
        file_count = sum(len(v) for v in _index.values())
    return {
        "watched_dirs": _config.get("watched_dirs") or [],
        "file_count": file_count,
        "unique_names": len(_index),
    }


@app.post("/api/library/add-folder")
def add_folder(body: AddFolder):
    p = Path(body.path).expanduser()
    if not p.is_dir():
        raise HTTPException(404, f"Folder not found: {body.path}")
    resolved = str(p.resolve())
    dirs = list(_config.get("watched_dirs") or [])
    if resolved not in dirs:
        dirs.append(resolved)
        _config["watched_dirs"] = dirs
        save_config()
    n = scan_dir(p)
    save_index()
    return {"ok": True, "path": resolved, "files_indexed": n, "watched_dirs": _config["watched_dirs"]}


@app.post("/api/library/rescan")
def rescan():
    n = rebuild_index()
    return {"ok": True, "files_indexed": n, "watched_dirs": _config.get("watched_dirs") or []}


def _schedule_shell_retry(path: Path, tags: list[str] | None, rating: int | None) -> None:
    """Retry Explorer shell props after Chrome releases the file lock."""
    global _pending_shell_thread
    key = str(path.resolve())
    with _lock:
        _pending_shell[key] = {
            "tags": tags,
            "rating": rating,
            "tries": 0,
            "name": path.name,
        }

    def worker() -> None:
        # Wait for playback lock to clear; re-check queue each cycle
        for _ in range(24):  # ~2 minutes max
            time.sleep(5)
            with _lock:
                items = list(_pending_shell.items())
            if not items:
                return
            for pstr, job in items:
                p = Path(pstr)
                if not p.is_file():
                    with _lock:
                        _pending_shell.pop(pstr, None)
                    continue
                res = write_file_metadata(
                    p,
                    tags=job.get("tags"),
                    rating=job.get("rating"),
                    retries=2,
                    retry_delay_s=0.4,
                )
                methods = res.get("methods") or []
                shell_ok = any(str(m).startswith("shell") for m in methods)
                if shell_ok or not res.get("file_locked"):
                    with _lock:
                        _pending_shell.pop(pstr, None)
                    if shell_ok:
                        print(f"[FAFO Meta] Deferred Explorer write OK → {job.get('name')}")
                    continue
                with _lock:
                    if pstr in _pending_shell:
                        _pending_shell[pstr]["tries"] = int(_pending_shell[pstr].get("tries") or 0) + 1
                        if _pending_shell[pstr]["tries"] >= 20:
                            _pending_shell.pop(pstr, None)
                            print(f"[FAFO Meta] Gave up deferred Explorer write → {job.get('name')}")
        with _lock:
            _pending_shell.clear()

    if _pending_shell_thread is None or not _pending_shell_thread.is_alive():
        _pending_shell_thread = threading.Thread(target=worker, daemon=True, name="fafo-shell-retry")
        _pending_shell_thread.start()


def _write_one(body: FileMetaWrite, *, log: bool = True) -> dict[str, Any]:
    """Shared single-file write used by single + batch endpoints."""
    if body.tags is None and body.rating is None:
        raise HTTPException(400, "Provide tags and/or rating")

    target = find_by_identity(body.name, body.size, body.mtime, body.path)
    if not target:
        raise HTTPException(
            404,
            "File not found in the metadata library. "
            "Add the video folder (ADD_VIDEO_FOLDER.bat / POST /api/library/add-folder) "
            "or pass an absolute path.",
        )

    tags = normalize_tags(body.tags) if body.tags is not None else None
    rating = body.rating
    if rating is not None:
        try:
            rating = max(0, min(5, int(rating)))
        except (TypeError, ValueError):
            rating = 0

    result = write_file_metadata(target, tags=tags, rating=rating, retries=4, retry_delay_s=0.4)
    result["ok"] = True
    result["resolved_path"] = str(target)
    result["name"] = target.name
    if body.client_key:
        result["client_key"] = body.client_key
    if tags is not None:
        remember_tags(tags)

    # Chrome often locks the playing file — queue Explorer shell write for later
    methods = result.get("methods") or []
    shell_ok = any(str(m).startswith("shell") for m in methods)
    if result.get("file_locked") and not shell_ok:
        _schedule_shell_retry(target, tags, rating)
        result["deferred_shell"] = True

    # Refresh this entry in index
    try:
        st = target.stat()
        key = target.name.lower()
        entry = {"path": str(target), "name": target.name, "size": st.st_size, "mtime": st.st_mtime}
        with _lock:
            bucket = [e for e in (_index.get(key) or []) if e.get("path") != entry["path"]]
            bucket.append(entry)
            _index[key] = bucket
        save_index()
    except Exception:
        pass
    methods_s = ", ".join(methods) or "ok"
    if log:
        if result.get("deferred_shell"):
            print(f"[FAFO Meta] Wrote (partial) → {target.name}  ({methods_s}; Explorer retry queued)")
        else:
            print(f"[FAFO Meta] Wrote tags/rating → {target.name}  ({methods_s})")
    return result


@app.post("/api/fs/write-metadata")
def api_write_metadata(body: FileMetaWrite):
    return _write_one(body, log=True)


@app.post("/api/fs/write-metadata-batch")
def api_write_metadata_batch(body: FileMetaWriteBatch):
    """
    Bulk write tags/ratings to many files (Explorer + shell props).
    Used by FAFO "Sync all pending to Explorer" so users do not have to
    visit each clip to push disk metadata.
    """
    items = body.items or []
    if not items:
        raise HTTPException(400, "items[] required")
    if len(items) > 2000:
        raise HTTPException(400, "Max 2000 items per batch")

    results: list[dict[str, Any]] = []
    written = 0
    failed = 0
    deferred = 0
    not_found = 0

    print(f"[FAFO Meta] Batch write starting · {len(items)} item(s)")
    for i, item in enumerate(items):
        try:
            r = _write_one(item, log=False)
            if r.get("deferred_shell"):
                deferred += 1
            written += 1
            results.append({
                "ok": True,
                "client_key": item.client_key,
                "name": r.get("name") or item.name,
                "resolved_path": r.get("resolved_path"),
                "methods": r.get("methods") or [],
                "deferred_shell": bool(r.get("deferred_shell")),
                "file_locked": bool(r.get("file_locked")),
            })
        except HTTPException as he:
            failed += 1
            detail = he.detail
            if he.status_code == 404:
                not_found += 1
            results.append({
                "ok": False,
                "client_key": item.client_key,
                "name": item.name,
                "error": detail if isinstance(detail, str) else str(detail),
                "status": he.status_code,
            })
            if body.stop_on_error:
                break
        except Exception as e:
            failed += 1
            results.append({
                "ok": False,
                "client_key": item.client_key,
                "name": item.name,
                "error": str(e),
                "status": 500,
            })
            if body.stop_on_error:
                break
        # Light yield so the server stays responsive during large pushes
        if (i + 1) % 25 == 0:
            time.sleep(0.05)

    print(
        f"[FAFO Meta] Batch write done · ok={written} fail={failed} "
        f"not_found={not_found} deferred={deferred}"
    )
    return {
        "ok": failed == 0,
        "total": len(items),
        "written": written,
        "failed": failed,
        "not_found": not_found,
        "deferred_shell": deferred,
        "results": results,
        "service": "fafo-explorer-meta",
        "endpoint": f"http://{HOST}:{PORT}",
    }


class RevealBody(BaseModel):
    path: str | None = None
    name: str | None = None
    size: int | None = None
    mtime: float | None = None


@app.post("/api/fs/reveal")
def api_reveal(body: RevealBody):
    """Open Windows Explorer with the file selected (or its parent folder)."""
    target = find_by_identity(body.name, body.size, body.mtime, body.path)
    if not target or not target.is_file():
        raise HTTPException(
            404,
            "File not found in index. Add the folder (ADD_VIDEO_FOLDER) or pass an absolute path.",
        )
    try:
        # /select, highlights the file in Explorer
        subprocess.Popen(
            ["explorer", f"/select,{target}"],
            shell=False,
        )
        return {
            "ok": True,
            "path": str(target),
            "folder": str(target.parent),
        }
    except OSError as e:
        raise HTTPException(500, f"Could not open Explorer: {e}") from e


@app.get("/api/fs/read-metadata")
def api_read_metadata(path: str = Query(...)):
    p = Path(path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    return read_file_metadata(p)


def main() -> None:
    _install_quiet_access_logs()
    print("=" * 56)
    print("  FAFO Explorer Metadata Server")
    print(f"  http://{HOST}:{PORT}")
    print("  Keep this window open while using FAFO tags/ratings.")
    print("  Quiet mode: health/media/tags polls are not printed.")
    print("  Still shows: tag writes, rescans, and errors.")
    print("  Press Ctrl+C to stop.")
    print("=" * 56)
    # access log stays on; QuietPollFilter hides successful poll spam
    uvicorn.run(app, host=HOST, port=PORT, log_level="info", access_log=True)


if __name__ == "__main__":
    main()
