/**
 * FAFO persistent tag/meta backup & restore.
 * - Live data: chrome.storage.local (fafoMediaMeta, hotkeys, pairs, …)
 * - Latest snapshot: fafoTagsSnapshot
 * - Rolling history: fafoTagsBackupHistory (up to 12)
 * - Downloadable JSON export / import
 */
(function (global) {
    'use strict';

    const KIND = 'fafo-tags-backup';
    const VERSION = 2;
    const HISTORY_KEY = 'fafoTagsBackupHistory';
    const SNAPSHOT_KEY = 'fafoTagsSnapshot';
    const HISTORY_MAX = 12;
    const HISTORY_MIN_MS = 45 * 1000; // don't flood history more than every 45s

    const LIVE_KEYS = [
        'fafoMediaMeta',
        'fafoTagLibrary',
        'fafoTagLastUsed',
        'fafoTagHotkeys',
        'fafoTagApplyCounts',
        'fafoTagCountMode',
        'fafoSkipTaggedMode',
        'fafoTagLibraryHeight',
        'fafoMetaPanelWidth',
        'fafoTagExcluded',
        'fafoExtraTagBanks',
        'fafoPairs',
        'mediaConfig',
    ];

    let lastHistoryWrite = 0;

    function metaEntryCount(meta) {
        return meta && typeof meta === 'object' ? Object.keys(meta).length : 0;
    }

    async function readLive() {
        const data = await chrome.storage.local.get(LIVE_KEYS);
        return {
            fafoMediaMeta: data.fafoMediaMeta || {},
            fafoTagLibrary: Array.isArray(data.fafoTagLibrary) ? data.fafoTagLibrary : [],
            fafoTagLastUsed: data.fafoTagLastUsed || {},
            fafoTagHotkeys: data.fafoTagHotkeys || null,
            fafoTagApplyCounts: data.fafoTagApplyCounts || {},
            fafoTagCountMode: data.fafoTagCountMode || 'session',
            fafoSkipTaggedMode: !!data.fafoSkipTaggedMode,
            fafoTagLibraryHeight: data.fafoTagLibraryHeight,
            fafoMetaPanelWidth: data.fafoMetaPanelWidth,
            fafoTagExcluded: Array.isArray(data.fafoTagExcluded) ? data.fafoTagExcluded : [],
            fafoExtraTagBanks: data.fafoExtraTagBanks || null,
            fafoPairs: Array.isArray(data.fafoPairs) ? data.fafoPairs : [],
            mediaConfig: data.mediaConfig || {},
        };
    }

    function buildBundle(live, reason) {
        const meta = live.fafoMediaMeta || {};
        return {
            kind: KIND,
            version: VERSION,
            savedAt: Date.now(),
            reason: reason || 'auto',
            stats: {
                mediaEntries: metaEntryCount(meta),
                tagCount: (live.fafoTagLibrary || []).length,
                pairCount: (live.fafoPairs || []).length,
                applyCountKeys: live.fafoTagApplyCounts
                    ? Object.keys(live.fafoTagApplyCounts).length
                    : 0,
            },
            data: {
                fafoMediaMeta: live.fafoMediaMeta || {},
                fafoTagLibrary: live.fafoTagLibrary || [],
                fafoTagLastUsed: live.fafoTagLastUsed || {},
                fafoTagHotkeys: live.fafoTagHotkeys,
                fafoTagApplyCounts: live.fafoTagApplyCounts || {},
                fafoTagCountMode: live.fafoTagCountMode || 'session',
                fafoSkipTaggedMode: !!live.fafoSkipTaggedMode,
                fafoTagLibraryHeight: live.fafoTagLibraryHeight,
                fafoMetaPanelWidth: live.fafoMetaPanelWidth,
                fafoTagExcluded: live.fafoTagExcluded || [],
                fafoExtraTagBanks: live.fafoExtraTagBanks || null,
                fafoPairs: live.fafoPairs || [],
                // Optional: keep config in full exports (not required for tag restore)
                mediaConfig: live.mediaConfig || undefined,
            },
        };
    }

    /**
     * After a successful live save — refresh snapshot + maybe history.
     * Pass optional partial live override (from in-memory meta module).
     */
    async function afterLiveSave(partial, reason) {
        try {
            const live = { ...(await readLive()), ...(partial || {}) };
            const bundle = buildBundle(live, reason || 'auto');
            await chrome.storage.local.set({ [SNAPSHOT_KEY]: bundle });

            const now = Date.now();
            const forceHistory = reason === 'manual' || reason === 'export' || reason === 'pre-restore' || reason === 'post-restore';
            if (now - lastHistoryWrite < HISTORY_MIN_MS && !forceHistory) {
                return bundle;
            }
            lastHistoryWrite = now;

            const res = await chrome.storage.local.get([HISTORY_KEY]);
            let history = Array.isArray(res[HISTORY_KEY]) ? res[HISTORY_KEY] : [];
            const entry = {
                id: 'bak_' + now.toString(36),
                ...bundle,
            };
            // Avoid storing full mediaConfig in every history slot (size)
            if (entry.data) delete entry.data.mediaConfig;
            history = [entry, ...history.filter((h) => h && h.id !== entry.id)].slice(0, HISTORY_MAX);
            await chrome.storage.local.set({ [HISTORY_KEY]: history });
            return bundle;
        } catch (e) {
            console.warn('FAFO backup afterLiveSave failed', e);
            return null;
        }
    }

    async function getSnapshot() {
        const res = await chrome.storage.local.get([SNAPSHOT_KEY]);
        return res[SNAPSHOT_KEY] || null;
    }

    async function listHistory() {
        const res = await chrome.storage.local.get([HISTORY_KEY]);
        return Array.isArray(res[HISTORY_KEY]) ? res[HISTORY_KEY] : [];
    }

    function applyBundleToStoragePayload(bundle, opts = {}) {
        const d = bundle?.data || bundle;
        if (!d || typeof d !== 'object') throw new Error('Invalid backup data');
        const out = {};
        if (d.fafoMediaMeta != null) out.fafoMediaMeta = d.fafoMediaMeta;
        if (d.fafoTagLibrary != null) out.fafoTagLibrary = d.fafoTagLibrary;
        if (d.fafoTagLastUsed != null) out.fafoTagLastUsed = d.fafoTagLastUsed;
        if (d.fafoTagHotkeys != null) out.fafoTagHotkeys = d.fafoTagHotkeys;
        if (d.fafoTagApplyCounts != null) out.fafoTagApplyCounts = d.fafoTagApplyCounts;
        if (d.fafoTagCountMode != null) out.fafoTagCountMode = d.fafoTagCountMode;
        if (d.fafoSkipTaggedMode != null) out.fafoSkipTaggedMode = !!d.fafoSkipTaggedMode;
        if (d.fafoTagLibraryHeight != null) out.fafoTagLibraryHeight = d.fafoTagLibraryHeight;
        if (d.fafoMetaPanelWidth != null) out.fafoMetaPanelWidth = d.fafoMetaPanelWidth;
        if (d.fafoTagExcluded != null) out.fafoTagExcluded = d.fafoTagExcluded;
        if (d.fafoExtraTagBanks != null) out.fafoExtraTagBanks = d.fafoExtraTagBanks;
        if (d.fafoPairs != null) out.fafoPairs = d.fafoPairs;
        if (opts.includeConfig && d.mediaConfig) out.mediaConfig = d.mediaConfig;
        return out;
    }

    async function restoreBundle(bundle, opts = {}) {
        const payload = applyBundleToStoragePayload(bundle, opts);
        if (!Object.keys(payload).length) throw new Error('Backup has no tag data');
        // Safety snapshot of current state first
        await afterLiveSave(null, 'pre-restore');
        await chrome.storage.local.set(payload);
        await afterLiveSave(payload, 'post-restore');
        return {
            mediaEntries: metaEntryCount(payload.fafoMediaMeta),
            tags: (payload.fafoTagLibrary || []).length,
            pairs: (payload.fafoPairs || []).length,
        };
    }

    async function restoreLatestSnapshot() {
        const snap = await getSnapshot();
        if (!snap?.data) throw new Error('No snapshot available yet — tag something first');
        return restoreBundle(snap);
    }

    async function restoreHistoryId(id) {
        const history = await listHistory();
        const hit = history.find((h) => h.id === id);
        if (!hit) throw new Error('Backup not found');
        return restoreBundle(hit);
    }

    /**
     * If live media meta is empty but a snapshot has data, recover automatically.
     * Returns recovered bundle data or null.
     */
    async function tryRecoverEmptyLive() {
        try {
            const live = await readLive();
            if (metaEntryCount(live.fafoMediaMeta) > 0) return null;
            const snap = await getSnapshot();
            if (!snap?.data || metaEntryCount(snap.data.fafoMediaMeta) === 0) {
                // try history
                const history = await listHistory();
                const hit = history.find((h) => metaEntryCount(h?.data?.fafoMediaMeta) > 0);
                if (!hit) return null;
                await chrome.storage.local.set(applyBundleToStoragePayload(hit));
                console.info('FAFO recovered tags from backup history', hit.id);
                return hit;
            }
            await chrome.storage.local.set(applyBundleToStoragePayload(snap));
            console.info('FAFO recovered tags from latest snapshot');
            return snap;
        } catch (e) {
            console.warn('FAFO tryRecoverEmptyLive', e);
            return null;
        }
    }

    async function exportToDownload(opts = {}) {
        const live = await readLive();
        const bundle = buildBundle(live, opts.reason || 'export');
        if (!opts.includeConfig) {
            delete bundle.data.mediaConfig;
        }
        const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
        const a = document.createElement('a');
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        a.href = URL.createObjectURL(blob);
        a.download = opts.filename || `fafo-tags-backup-${stamp}.json`;
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 2000);
        await afterLiveSave(live, 'export');
        return bundle;
    }

    async function importFromObject(obj, opts = {}) {
        // Accept full bundle or raw { fafoMediaMeta, ... } or legacy mediaConfig-only
        if (!obj || typeof obj !== 'object') throw new Error('Invalid JSON');

        if (obj.kind === KIND || obj.data?.fafoMediaMeta || obj.fafoMediaMeta) {
            const bundle = obj.data ? obj : { data: obj, kind: KIND, version: VERSION, savedAt: Date.now() };
            return restoreBundle(bundle, opts);
        }

        // Legacy: pure mediaConfig export
        if (obj.layout || obj.useLocal != null || obj.fxSnow != null) {
            await chrome.storage.local.set({ mediaConfig: obj });
            return { mediaEntries: 0, tags: 0, pairs: 0, configOnly: true };
        }

        throw new Error('Unrecognized backup format');
    }

    async function importFromFile(file, opts = {}) {
        const text = await file.text();
        const obj = JSON.parse(text);
        return importFromObject(obj, opts);
    }

    async function statusSummary() {
        const live = await readLive();
        const snap = await getSnapshot();
        const history = await listHistory();
        return {
            liveMedia: metaEntryCount(live.fafoMediaMeta),
            liveTags: (live.fafoTagLibrary || []).length,
            livePairs: (live.fafoPairs || []).length,
            snapshotAt: snap?.savedAt || null,
            snapshotMedia: metaEntryCount(snap?.data?.fafoMediaMeta),
            historyCount: history.length,
            history: history.map((h) => ({
                id: h.id,
                savedAt: h.savedAt,
                reason: h.reason,
                mediaEntries: h.stats?.mediaEntries ?? metaEntryCount(h.data?.fafoMediaMeta),
                tagCount: h.stats?.tagCount ?? (h.data?.fafoTagLibrary || []).length,
                pairCount: h.stats?.pairCount ?? (h.data?.fafoPairs || []).length,
            })),
        };
    }

    global.FAFOBackup = {
        KIND,
        VERSION,
        LIVE_KEYS,
        readLive,
        afterLiveSave,
        getSnapshot,
        listHistory,
        restoreBundle,
        restoreLatestSnapshot,
        restoreHistoryId,
        tryRecoverEmptyLive,
        exportToDownload,
        importFromObject,
        importFromFile,
        statusSummary,
        buildBundle,
    };
})(typeof window !== 'undefined' ? window : globalThis);
