/**
 * FAFO Pairing & Compare — pairs, slider/blend comparator, duplicates, thumb seek time.
 * Loaded on options.html after fafo-library.js / with options.js.
 */
(function (global) {
    'use strict';

    const $ = (id) => document.getElementById(id);
    const STORAGE_PAIRS = 'fafoPairs';
    const STORAGE_CFG = 'mediaConfig';

    let db = null;
    let pairs = [];
    let draft = { before: null, after: null }; // { store, key, name, type, handle, file, thumbUrl }
    let pickTarget = null; // 'before' | 'after'
    let cmp = {
        before: null,
        after: null,
        mediaB: null,
        mediaA: null,
        urls: [],
        sliderPct: 50,
        dragging: false,
    };
    let thumbSeekSec = 1;
    let showToast = (msg) => console.log(msg);
    let genThumb = null; // (file, seekSec) => Promise<dataUrl>

    function fmtTime(s) {
        if (!isFinite(s) || s < 0) return '0:00';
        const m = Math.floor(s / 60);
        const sec = Math.floor(s % 60);
        return `${m}:${String(sec).padStart(2, '0')}`;
    }

    function nextPairCode() {
        let max = 0;
        pairs.forEach((p) => {
            const m = String(p.code || '').match(/UP-(\d+)/i);
            if (m) max = Math.max(max, parseInt(m[1], 10));
        });
        return 'UP-' + String(max + 1).padStart(4, '0');
    }

    async function loadPairs() {
        try {
            const res = await chrome.storage.local.get([STORAGE_PAIRS]);
            pairs = Array.isArray(res[STORAGE_PAIRS]) ? res[STORAGE_PAIRS] : [];
        } catch {
            pairs = [];
        }
        return pairs;
    }

    async function savePairs() {
        await chrome.storage.local.set({ [STORAGE_PAIRS]: pairs });
        if (global.FAFOBackup?.afterLiveSave) {
            FAFOBackup.afterLiveSave({ fafoPairs: pairs }, 'pairs-save').catch(() => {});
        }
    }

    async function loadThumbSeek() {
        try {
            const { mediaConfig = {} } = await chrome.storage.local.get(STORAGE_CFG);
            const v = Number(mediaConfig.thumbSeekSec);
            thumbSeekSec = Number.isFinite(v) && v >= 0 ? v : 1;
        } catch {
            thumbSeekSec = 1;
        }
        syncThumbSeekUI();
        return thumbSeekSec;
    }

    async function saveThumbSeek(sec) {
        thumbSeekSec = Math.max(0, Number(sec) || 0);
        const { mediaConfig = {} } = await chrome.storage.local.get(STORAGE_CFG);
        mediaConfig.thumbSeekSec = thumbSeekSec;
        await chrome.storage.local.set({ mediaConfig });
        syncThumbSeekUI();
        if ($('thumb-seek-status')) {
            $('thumb-seek-status').textContent =
                `Saved: thumbnails capture at ${thumbSeekSec}s into each video (capped to duration).`;
        }
        showToast(`Thumbnail time: ${thumbSeekSec}s`);
    }

    function syncThumbSeekUI() {
        if ($('thumb-seek-sec')) $('thumb-seek-sec').value = String(thumbSeekSec);
        if ($('thumb-seek-sec-num')) $('thumb-seek-sec-num').value = String(thumbSeekSec);
        if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = String(thumbSeekSec);
    }

    async function generateThumbnail(file, seekOverride) {
        if (genThumb) return genThumb(file, seekOverride != null ? seekOverride : thumbSeekSec);
        if (!file || !String(file.type || '').startsWith('video') && !/\.(mp4|webm|mkv|mov|m4v)$/i.test(file.name || '')) {
            if (file && String(file.type || '').startsWith('image')) {
                return URL.createObjectURL(file);
            }
            return null;
        }
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.muted = true;
            video.playsInline = true;
            const url = URL.createObjectURL(file);
            video.src = url;
            const seek = seekOverride != null ? seekOverride : thumbSeekSec;
            video.onloadeddata = () => {
                const cap = Math.max(0, (video.duration || 1) - 0.05);
                video.currentTime = Math.min(Math.max(0, seek), cap || 0);
            };
            video.onseeked = () => {
                try {
                    const canvas = document.createElement('canvas');
                    const scale = 4;
                    canvas.width = Math.max(1, Math.floor(video.videoWidth / scale));
                    canvas.height = Math.max(1, Math.floor(video.videoHeight / scale));
                    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.72);
                    URL.revokeObjectURL(url);
                    video.remove();
                    resolve(dataUrl);
                } catch {
                    URL.revokeObjectURL(url);
                    video.remove();
                    resolve(null);
                }
            };
            video.onerror = () => {
                URL.revokeObjectURL(url);
                video.remove();
                resolve(null);
            };
        });
    }

    async function resolveEntry(ref) {
        if (!db || !ref) return null;
        const storeName = ref.store || ref.storeName || 'videos';
        try {
            const tx = db.transaction(storeName, 'readonly');
            const raw = await new Promise((res, rej) => {
                const r = tx.objectStore(storeName).get(ref.key);
                r.onsuccess = () => res(r.result);
                r.onerror = () => rej(r.error);
            });
            const entry = global.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(raw) : null;
            if (!entry?.handle) return null;
            if (global.FAFOLibrary) {
                await FAFOLibrary.ensurePermission(entry.handle, 'read');
            }
            let file = null;
            if (entry.handle instanceof File) file = entry.handle;
            else if (typeof entry.handle.getFile === 'function') file = await entry.handle.getFile();
            return {
                store: storeName,
                key: ref.key,
                name: file?.name || entry.name || ref.name || 'Unknown',
                type: storeName === 'photos' ? 'photo' : 'video',
                handle: entry.handle,
                file,
            };
        } catch (e) {
            console.warn('resolveEntry', e);
            return null;
        }
    }

    async function listLibraryFlat() {
        if (!db || !global.FAFOLibrary) return [];
        const out = [];
        for (const store of ['videos', 'photos']) {
            const rows = await FAFOLibrary.getAllMediaEntries(db, store);
            for (const row of rows) {
                out.push({
                    store,
                    key: row.key,
                    name: row.name,
                    type: store === 'photos' ? 'photo' : 'video',
                    handle: row.handle,
                    parentFolderId: row.parentFolderId,
                });
            }
        }
        return out;
    }

    function setSubtab(name) {
        document.querySelectorAll('.pair-subtab').forEach((b) => {
            b.classList.toggle('active', b.dataset.pairTab === name);
        });
        document.querySelectorAll('.pair-pane').forEach((p) => {
            p.classList.toggle('active', p.id === 'pair-pane-' + name);
        });
    }

    function renderSlot(side) {
        const item = draft[side];
        const nameEl = $(`pair-name-${side}`);
        const thumbEl = $(`pair-thumb-${side}`);
        const slot = $(`pair-slot-${side}`);
        if (!item) {
            if (nameEl) nameEl.textContent = 'Not selected';
            if (thumbEl) thumbEl.innerHTML = '—';
            slot?.classList.remove('filled');
            return;
        }
        if (nameEl) nameEl.textContent = item.name;
        slot?.classList.add('filled');
        if (thumbEl) {
            if (item.thumbUrl) {
                thumbEl.innerHTML = `<img src="${item.thumbUrl}" alt="">`;
            } else {
                thumbEl.textContent = item.type === 'photo' ? '🖼' : '🎬';
            }
        }
    }

    async function fillDraftFromRef(side, ref) {
        const resolved = await resolveEntry(ref);
        if (!resolved?.file) {
            showToast('Could not open file — Restore Access?', 'error');
            return;
        }
        let thumbUrl = null;
        if (resolved.type === 'photo') {
            thumbUrl = URL.createObjectURL(resolved.file);
        } else {
            thumbUrl = await generateThumbnail(resolved.file, thumbSeekSec);
        }
        draft[side] = { ...resolved, thumbUrl };
        renderSlot(side);
    }

    async function openPicker(side) {
        pickTarget = side;
        const modal = $('pair-picker-modal');
        const grid = $('pair-picker-grid');
        const title = $('pair-picker-title');
        if (!modal || !grid) return;
        if (title) title.textContent = side === 'before' ? 'Pick BEFORE / source' : 'Pick AFTER / upscaled';
        modal.classList.remove('hidden');
        grid.innerHTML = '<div style="color:#666;grid-column:1/-1;padding:20px;text-align:center;">Loading library…</div>';
        const items = await listLibraryFlat();
        const filter = ($('pair-picker-filter')?.value || '').trim().toLowerCase();
        const list = filter ? items.filter((i) => (i.name || '').toLowerCase().includes(filter)) : items;
        if (!list.length) {
            grid.innerHTML = '<div style="color:#666;grid-column:1/-1;padding:20px;text-align:center;">No library items. Link folders in Visual Library first.</div>';
            return;
        }
        grid.innerHTML = '';
        for (const item of list.slice(0, 200)) {
            const card = document.createElement('div');
            card.className = 'pair-pick-card';
            card.innerHTML = `<div class="pt"></div><div class="pn">${escapeHtml(item.name || '')}</div>`;
            const pt = card.querySelector('.pt');
            card.onclick = async () => {
                modal.classList.add('hidden');
                await fillDraftFromRef(pickTarget, item);
            };
            grid.appendChild(card);
            // lazy thumb
            (async () => {
                try {
                    if (global.FAFOLibrary) await FAFOLibrary.ensurePermission(item.handle, 'read');
                    const file = item.handle instanceof File ? item.handle : await item.handle.getFile();
                    let url = null;
                    if (item.type === 'photo') url = URL.createObjectURL(file);
                    else url = await generateThumbnail(file, thumbSeekSec);
                    if (url && pt) pt.innerHTML = `<img src="${url}" alt="">`;
                } catch { /* ignore */ }
            })();
        }
    }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    async function createPair() {
        if (!draft.before || !draft.after) {
            showToast('Pick both Before and After', 'error');
            return;
        }
        if (draft.before.store === draft.after.store && String(draft.before.key) === String(draft.after.key)) {
            showToast('Before and After must be different files', 'error');
            return;
        }
        const code = nextPairCode();
        const name =
            ($('pair-create-name')?.value || '').trim() ||
            `${draft.before.name} ↔ ${draft.after.name}`;
        const pair = {
            id: 'pair_' + Date.now().toString(36),
            code,
            name,
            before: {
                store: draft.before.store,
                key: draft.before.key,
                name: draft.before.name,
            },
            after: {
                store: draft.after.store,
                key: draft.after.key,
                name: draft.after.name,
            },
            created: Date.now(),
            thumbSeekSec,
            thumbBefore: draft.before.thumbUrl || null,
            thumbAfter: draft.after.thumbUrl || null,
        };
        pairs.unshift(pair);
        await savePairs();

        if ($('pair-write-tags')?.checked) {
            await writePairTags(pair, draft.before, draft.after);
        }

        showToast(`Created ${code}`);
        renderPairList();
        await loadCompareFromPair(pair);
        setSubtab('compare');
        draft = { before: null, after: null };
        renderSlot('before');
        renderSlot('after');
        if ($('pair-create-name')) $('pair-create-name').value = '';
    }

    async function writePairTags(pair, beforeItem, afterItem) {
        try {
            const res = await chrome.storage.local.get(['fafoMediaMeta']);
            const mediaMeta = res.fafoMediaMeta || {};
            const stamp = async (item, roleTags) => {
                if (!item?.file) return;
                const key = `file:${item.file.name}|${item.file.size}|${item.file.lastModified}`;
                const prev = mediaMeta[key] || {};
                const tags = new Set([...(prev.tags || []), pair.code, ...roleTags]);
                mediaMeta[key] = {
                    ...prev,
                    name: item.file.name,
                    tags: [...tags],
                    rating: prev.rating || 0,
                    updated: Date.now(),
                };
            };
            await stamp(beforeItem, ['source', 'before', 'original-video']);
            await stamp(afterItem, ['upscaled', 'after', 'vsr', 'upscaled-video']);
            await chrome.storage.local.set({ fafoMediaMeta: mediaMeta });
        } catch (e) {
            console.warn('writePairTags', e);
        }
    }

    function renderPairList() {
        const box = $('pair-list');
        const count = $('pair-list-count');
        if (count) count.textContent = pairs.length ? `(${pairs.length})` : '';
        if (!box) return;
        if (!pairs.length) {
            box.innerHTML = '<div style="color:#555;padding:16px;text-align:center;">No pairs yet — create one above.</div>';
            return;
        }
        box.innerHTML = pairs
            .map(
                (p) => `
            <div class="pair-card" data-id="${escapeHtml(p.id)}">
                <div class="pair-card-thumbs">
                    <div class="pt before">${p.thumbBefore ? `<img src="${p.thumbBefore}" alt="">` : '①'}</div>
                    <div class="pt after">${p.thumbAfter ? `<img src="${p.thumbAfter}" alt="">` : '②'}</div>
                </div>
                <div class="pair-card-meta">
                    <strong>${escapeHtml(p.code)} · ${escapeHtml(p.name || '')}</strong>
                    <span>Before: ${escapeHtml(p.before?.name || '—')}</span><br>
                    <span>After: ${escapeHtml(p.after?.name || '—')}</span>
                </div>
                <div class="pair-card-actions">
                    <button class="btn btn-primary small" data-act="compare">Compare</button>
                    <button class="btn btn-ghost small" data-act="regen">Thumbs</button>
                    <button class="btn btn-danger small" data-act="delete">Delete</button>
                </div>
            </div>`
            )
            .join('');

        box.querySelectorAll('.pair-card').forEach((card) => {
            const id = card.dataset.id;
            const p = pairs.find((x) => x.id === id);
            if (!p) return;
            card.querySelector('[data-act="compare"]')?.addEventListener('click', () => {
                loadCompareFromPair(p).then(() => setSubtab('compare'));
            });
            card.querySelector('[data-act="regen"]')?.addEventListener('click', () => regenPairThumbs(p));
            card.querySelector('[data-act="delete"]')?.addEventListener('click', async () => {
                if (!confirm(`Delete pair ${p.code}?`)) return;
                pairs = pairs.filter((x) => x.id !== id);
                await savePairs();
                renderPairList();
                showToast('Pair deleted');
            });
        });
    }

    async function regenPairThumbs(pair) {
        const b = await resolveEntry(pair.before);
        const a = await resolveEntry(pair.after);
        if (b?.file) {
            pair.thumbBefore =
                b.type === 'photo' ? URL.createObjectURL(b.file) : await generateThumbnail(b.file, thumbSeekSec);
        }
        if (a?.file) {
            pair.thumbAfter =
                a.type === 'photo' ? URL.createObjectURL(a.file) : await generateThumbnail(a.file, thumbSeekSec);
        }
        pair.thumbSeekSec = thumbSeekSec;
        await savePairs();
        renderPairList();
        showToast(`Thumbs refreshed @ ${thumbSeekSec}s`);
    }

    function revokeCmpUrls() {
        (cmp.urls || []).forEach((u) => {
            try {
                URL.revokeObjectURL(u);
            } catch { /* */ }
        });
        cmp.urls = [];
    }

    function clearCompareStages() {
        revokeCmpUrls();
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (sb) sb.innerHTML = '';
        if (sa) sa.innerHTML = '';
        cmp.mediaB = null;
        cmp.mediaA = null;
        cmp.before = null;
        cmp.after = null;
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: —';
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: —';
    }

    function mountMedia(stageEl, file, type) {
        const url = URL.createObjectURL(file);
        cmp.urls.push(url);
        if (type === 'photo' || String(file.type || '').startsWith('image')) {
            const img = document.createElement('img');
            img.src = url;
            stageEl.appendChild(img);
            return img;
        }
        const video = document.createElement('video');
        video.src = url;
        video.playsInline = true;
        video.controls = false;
        video.muted = false;
        video.preload = 'auto';
        stageEl.appendChild(video);
        return video;
    }

    async function loadCompareFromPair(pair) {
        clearCompareStages();
        const b = await resolveEntry(pair.before);
        const a = await resolveEntry(pair.after);
        if (!b?.file || !a?.file) {
            showToast('Could not load pair files — Restore Access?', 'error');
            return;
        }
        cmp.before = b;
        cmp.after = a;
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (!sb || !sa) return;
        cmp.mediaB = mountMedia(sb, b.file, b.type);
        cmp.mediaA = mountMedia(sa, a.file, a.type);
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: ' + b.name;
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: ' + a.name;
        wireCompareMedia();
        applyCompareMode();
        setSliderPct(50);
    }

    function wireCompareMedia() {
        const v = cmp.mediaA?.tagName === 'VIDEO' ? cmp.mediaA : cmp.mediaB?.tagName === 'VIDEO' ? cmp.mediaB : null;
        const timeline = $('cmp-timeline');
        if (!v || !timeline) return;
        const onMeta = () => {
            const d = v.duration || 0;
            if ($('cmp-time-tot')) $('cmp-time-tot').textContent = fmtTime(d);
        };
        v.addEventListener('loadedmetadata', onMeta);
        if (v.readyState >= 1) onMeta();
        v.addEventListener('timeupdate', () => {
            const d = v.duration || 1;
            timeline.value = String(Math.round((v.currentTime / d) * 1000));
            if ($('cmp-time-cur')) $('cmp-time-cur').textContent = fmtTime(v.currentTime);
            // soft-sync other
            const other = v === cmp.mediaA ? cmp.mediaB : cmp.mediaA;
            if (other?.tagName === 'VIDEO' && Math.abs(other.currentTime - v.currentTime) > 0.12) {
                try {
                    other.currentTime = v.currentTime;
                } catch { /* */ }
            }
        });
        timeline.oninput = () => {
            const d = v.duration || 1;
            const t = (parseInt(timeline.value, 10) / 1000) * d;
            [cmp.mediaA, cmp.mediaB].forEach((m) => {
                if (m?.tagName === 'VIDEO') {
                    try {
                        m.currentTime = t;
                    } catch { /* */ }
                }
            });
        };
    }

    function applyCompareMode() {
        const mode = $('cmp-mode')?.value || 'slider';
        const viewer = $('cmp-viewer');
        if (viewer) viewer.dataset.mode = mode;
        if (mode === 'blend') {
            const op = (parseInt($('cmp-blend')?.value || '50', 10) / 100);
            const wrapB = $('cmp-wrap-before');
            if (wrapB) wrapB.style.opacity = String(op);
        } else {
            const wrapB = $('cmp-wrap-before');
            if (wrapB) wrapB.style.opacity = '';
        }
        if (mode === 'slider') setSliderPct(cmp.sliderPct);
    }

    function setSliderPct(pct) {
        cmp.sliderPct = Math.max(0, Math.min(100, pct));
        const wrapB = $('cmp-wrap-before');
        const line = $('cmp-slider-line');
        if (wrapB && $('cmp-viewer')?.dataset.mode === 'slider') {
            wrapB.style.clipPath = `inset(0 ${100 - cmp.sliderPct}% 0 0)`;
        }
        if (line) line.style.left = cmp.sliderPct + '%';
    }

    function wireSliderDrag() {
        const viewer = $('cmp-viewer');
        if (!viewer) return;
        const onMove = (clientX) => {
            if (!cmp.dragging) return;
            if (viewer.dataset.mode !== 'slider') return;
            const rect = viewer.getBoundingClientRect();
            const pct = ((clientX - rect.left) / rect.width) * 100;
            setSliderPct(pct);
        };
        viewer.addEventListener('pointerdown', (e) => {
            if (viewer.dataset.mode !== 'slider') return;
            cmp.dragging = true;
            viewer.setPointerCapture(e.pointerId);
            onMove(e.clientX);
        });
        viewer.addEventListener('pointermove', (e) => onMove(e.clientX));
        viewer.addEventListener('pointerup', () => {
            cmp.dragging = false;
        });
        viewer.addEventListener('pointercancel', () => {
            cmp.dragging = false;
        });
    }

    function playBoth() {
        [cmp.mediaA, cmp.mediaB].forEach((m) => {
            if (m?.tagName === 'VIDEO') m.play().catch(() => {});
        });
    }
    function pauseBoth() {
        [cmp.mediaA, cmp.mediaB].forEach((m) => {
            if (m?.tagName === 'VIDEO') m.pause();
        });
    }
    function syncBoth() {
        const master =
            cmp.mediaA?.tagName === 'VIDEO' ? cmp.mediaA : cmp.mediaB?.tagName === 'VIDEO' ? cmp.mediaB : null;
        if (!master) return;
        const t = master.currentTime;
        [cmp.mediaA, cmp.mediaB].forEach((m) => {
            if (m?.tagName === 'VIDEO') {
                try {
                    m.currentTime = t;
                } catch { /* */ }
            }
        });
        showToast('Synced to ' + fmtTime(t));
    }
    function swapCompare() {
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (!sb || !sa) return;
        // swap DOM children and refs
        const tmpH = sb.innerHTML;
        sb.innerHTML = sa.innerHTML;
        sa.innerHTML = tmpH;
        const tmpM = cmp.mediaB;
        cmp.mediaB = cmp.mediaA;
        cmp.mediaA = tmpM;
        // re-query elements
        cmp.mediaB = sb.querySelector('video,img');
        cmp.mediaA = sa.querySelector('video,img');
        const tmpI = cmp.before;
        cmp.before = cmp.after;
        cmp.after = tmpI;
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: ' + (cmp.before?.name || '—');
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: ' + (cmp.after?.name || '—');
        wireCompareMedia();
    }

    // --- Duplicates ---
    function nameStem(name) {
        return String(name || '')
            .toLowerCase()
            .replace(/\.[a-z0-9]+$/i, '')
            .replace(/[_\-\s]+/g, ' ')
            .replace(/\b(upscaled|upscale|vsr|after|before|source|original|x2|x4|4k|2k|remaster)\b/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function similarName(a, b) {
        const sa = nameStem(a);
        const sb = nameStem(b);
        if (!sa || !sb) return false;
        if (sa === sb) return true;
        if (sa.includes(sb) || sb.includes(sa)) return true;
        // simple token overlap
        const ta = new Set(sa.split(' ').filter((t) => t.length > 2));
        const tb = new Set(sb.split(' ').filter((t) => t.length > 2));
        if (!ta.size || !tb.size) return false;
        let inter = 0;
        ta.forEach((t) => {
            if (tb.has(t)) inter++;
        });
        return inter / Math.min(ta.size, tb.size) >= 0.7;
    }

    async function scanDuplicates() {
        const status = $('dupe-status');
        const box = $('dupe-results');
        if (status) status.textContent = 'Scanning library…';
        if (box) box.innerHTML = '';
        const mode = $('dupe-mode')?.value || 'both';
        const items = await listLibraryFlat();
        const enriched = [];
        for (const it of items) {
            try {
                if (global.FAFOLibrary) await FAFOLibrary.ensurePermission(it.handle, 'read');
                const file = it.handle instanceof File ? it.handle : await it.handle.getFile();
                enriched.push({
                    ...it,
                    file,
                    size: file.size,
                    name: file.name,
                });
            } catch {
                enriched.push({ ...it, size: null });
            }
        }

        const groups = [];
        const used = new Set();

        if (mode === 'size' || mode === 'both') {
            const bySize = new Map();
            enriched.forEach((it, i) => {
                if (it.size == null) return;
                if (!bySize.has(it.size)) bySize.set(it.size, []);
                bySize.get(it.size).push(i);
            });
            bySize.forEach((idxs, size) => {
                if (idxs.length < 2) return;
                const key = 'size:' + size;
                groups.push({
                    key,
                    reason: `Exact size ${formatBytes(size)}`,
                    indices: idxs,
                });
                idxs.forEach((i) => used.add(i));
            });
        }

        if (mode === 'name' || mode === 'both') {
            for (let i = 0; i < enriched.length; i++) {
                for (let j = i + 1; j < enriched.length; j++) {
                    if (!similarName(enriched[i].name, enriched[j].name)) continue;
                    // skip if already in same size group only when both size match and mode both?
                    const gkey = 'name:' + [nameStem(enriched[i].name), nameStem(enriched[j].name)].sort().join('|');
                    let g = groups.find((x) => x.key === gkey);
                    if (!g) {
                        g = { key: gkey, reason: 'Similar filename', indices: [i, j] };
                        groups.push(g);
                    } else {
                        if (!g.indices.includes(i)) g.indices.push(i);
                        if (!g.indices.includes(j)) g.indices.push(j);
                    }
                }
            }
        }

        // dedupe overlapping name groups lightly
        const finalGroups = groups.filter((g) => g.indices.length >= 2);

        if (status) {
            status.textContent = finalGroups.length
                ? `Found ${finalGroups.length} group(s). Review before deleting.`
                : 'No duplicate groups found.';
        }
        if (!box) return;
        if (!finalGroups.length) {
            box.innerHTML = '<div style="color:#666;padding:12px;">No matches.</div>';
            return;
        }

        box.innerHTML = '';
        for (const g of finalGroups.slice(0, 40)) {
            const el = document.createElement('div');
            el.className = 'dupe-group';
            el.innerHTML = `<h4>${escapeHtml(g.reason)} · ${g.indices.length} files</h4><div class="dupe-items"></div>`;
            const itemsEl = el.querySelector('.dupe-items');
            for (const idx of g.indices) {
                const it = enriched[idx];
                const card = document.createElement('div');
                card.className = 'dupe-item';
                card.innerHTML = `<div class="dt"></div><div class="dn">${escapeHtml(it.name || '')}</div>
                    <div class="da">
                        <button class="btn btn-ghost small" data-a="pair-b">As Before</button>
                        <button class="btn btn-ghost small" data-a="pair-a">As After</button>
                        <button class="btn btn-primary small" data-a="del">Remove from lib</button>
                    </div>`;
                itemsEl.appendChild(card);
                const dt = card.querySelector('.dt');
                (async () => {
                    if (!it.file) return;
                    let url = null;
                    if (it.type === 'photo') url = URL.createObjectURL(it.file);
                    else url = await generateThumbnail(it.file, thumbSeekSec);
                    if (url) dt.innerHTML = `<img src="${url}" alt="">`;
                })();
                card.querySelector('[data-a="pair-b"]')?.addEventListener('click', async () => {
                    await fillDraftFromRef('before', it);
                    setSubtab('pairs');
                    showToast('Set as Before');
                });
                card.querySelector('[data-a="pair-a"]')?.addEventListener('click', async () => {
                    await fillDraftFromRef('after', it);
                    setSubtab('pairs');
                    showToast('Set as After');
                });
                card.querySelector('[data-a="del"]')?.addEventListener('click', async () => {
                    if (!confirm(`Remove ${it.name} from library index? (does not delete disk file)`)) return;
                    try {
                        const tx = db.transaction(it.store, 'readwrite');
                        tx.objectStore(it.store).delete(it.key);
                        await new Promise((res) => {
                            tx.oncomplete = res;
                        });
                        card.style.opacity = '0.35';
                        showToast('Removed from library');
                    } catch (e) {
                        showToast(e.message || 'Delete failed', 'error');
                    }
                });
            }
            box.appendChild(el);
        }
    }

    function formatBytes(n) {
        if (n == null) return '—';
        const u = ['B', 'KB', 'MB', 'GB'];
        let i = 0;
        let v = n;
        while (v >= 1024 && i < u.length - 1) {
            v /= 1024;
            i++;
        }
        return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
    }

    function wireUI() {
        document.querySelectorAll('.pair-subtab').forEach((b) => {
            b.addEventListener('click', () => setSubtab(b.dataset.pairTab));
        });
        $('pair-pick-before')?.addEventListener('click', () => openPicker('before'));
        $('pair-pick-after')?.addEventListener('click', () => openPicker('after'));
        $('pair-create-btn')?.addEventListener('click', () => createPair());
        $('pair-refresh-btn')?.addEventListener('click', async () => {
            await loadPairs();
            renderPairList();
            showToast('Pairs refreshed');
        });
        $('pair-scan-dupes-btn')?.addEventListener('click', () => {
            setSubtab('dupes');
            scanDuplicates();
        });
        $('dupe-run-btn')?.addEventListener('click', () => scanDuplicates());

        $('cmp-mode')?.addEventListener('change', applyCompareMode);
        $('cmp-blend')?.addEventListener('input', applyCompareMode);
        $('cmp-play')?.addEventListener('click', playBoth);
        $('cmp-pause')?.addEventListener('click', pauseBoth);
        $('cmp-sync')?.addEventListener('click', syncBoth);
        $('cmp-swap')?.addEventListener('click', swapCompare);
        $('cmp-clear')?.addEventListener('click', clearCompareStages);
        wireSliderDrag();

        $('thumb-seek-sec')?.addEventListener('input', (e) => {
            if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = e.target.value;
            if ($('thumb-seek-sec-num')) $('thumb-seek-sec-num').value = e.target.value;
        });
        $('thumb-seek-sec-num')?.addEventListener('input', (e) => {
            if ($('thumb-seek-sec')) $('thumb-seek-sec').value = e.target.value;
            if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = e.target.value;
        });
        $('thumb-seek-save')?.addEventListener('click', () => {
            const v = parseFloat($('thumb-seek-sec-num')?.value || $('thumb-seek-sec')?.value || '1');
            saveThumbSeek(v);
        });
        $('thumb-regen-pair')?.addEventListener('click', async () => {
            if (draft.before?.file) {
                draft.before.thumbUrl =
                    draft.before.type === 'photo'
                        ? URL.createObjectURL(draft.before.file)
                        : await generateThumbnail(draft.before.file, thumbSeekSec);
                renderSlot('before');
            }
            if (draft.after?.file) {
                draft.after.thumbUrl =
                    draft.after.type === 'photo'
                        ? URL.createObjectURL(draft.after.file)
                        : await generateThumbnail(draft.after.file, thumbSeekSec);
                renderSlot('after');
            }
            showToast('Pair slot thumbs regenerated');
        });

        $('pair-picker-close')?.addEventListener('click', () => {
            $('pair-picker-modal')?.classList.add('hidden');
        });
        $('pair-picker-modal')?.addEventListener('click', (e) => {
            if (e.target.id === 'pair-picker-modal') e.target.classList.add('hidden');
        });
        let filterTimer = null;
        $('pair-picker-filter')?.addEventListener('input', () => {
            clearTimeout(filterTimer);
            filterTimer = setTimeout(() => {
                if (pickTarget) openPicker(pickTarget);
            }, 250);
        });
    }

    async function init(opts = {}) {
        db = opts.db || null;
        if (typeof opts.showToast === 'function') showToast = opts.showToast;
        if (typeof opts.generateThumbnail === 'function') genThumb = opts.generateThumbnail;
        await loadThumbSeek();
        await loadPairs();
        wireUI();
        renderPairList();
        renderSlot('before');
        renderSlot('after');
        applyCompareMode();
    }

    async function onActivate(opts = {}) {
        if (opts.db) db = opts.db;
        await loadThumbSeek();
        await loadPairs();
        renderPairList();
    }

    function getThumbSeekSec() {
        return thumbSeekSec;
    }

    global.FAFOPairs = {
        init,
        onActivate,
        getThumbSeekSec,
        generateThumbnail,
        loadCompareFromPair,
        setSubtab,
    };
})(typeof window !== 'undefined' ? window : globalThis);
