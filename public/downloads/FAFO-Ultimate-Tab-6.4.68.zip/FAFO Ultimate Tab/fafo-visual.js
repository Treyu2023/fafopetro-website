/**
 * FAFO Visual Engine — user-customizable colors, 3-stop gradients,
 * background / mouse / tag animations (Options → Theme + Visual FX).
 */
(function (global) {
    'use strict';

    const DEFAULTS = {
        colors: {
            accent: '#00e5ff',
            accent2: '#2dd4bf',
            accent3: '#a78bfa',
            useAccentGradient: false,
            bg: '#050505',
            bg2: '#0a0a12',
            bg3: '#050510',
            useBgGradient: false,
            text: '#eeeeee',
            textDim: '#888888',
            panelBg: '#0c0c12',
            panelBorder: '#00e5ff',
            tagSelected: '#00ffa8',
            tagLastVideo: '#ffc107',
            tagSession: '#2dd4bf',
            tagLibrary: '#a78bfa',
            tagUnused: '#666666',
            sprint: '#ffc107',
            neon: '#00e5ff',
            mouseGlow: '#00e5ff',
        },
        gradients: {
            accentAngle: 135,
            bgAngle: 160,
            panelAngle: 180,
        },
        anim: {
            background: 'none', // none | aurora | pulse | drift | grid | orbs | waves | stars | plasma | lattice | rain
            backgroundSpeed: 1,
            backgroundIntensity: 0.45,
            mouse: 'none', // legacy follow glow (still works)
            mouseSize: 140,
            mouseOpacity: 0.35,
            tagSelected: 'neon',
            tagLastVideo: 'breathe-gold',
            panelPulse: false,
            hudBreath: false,
            reduceMotion: false,
        },
        /**
         * Unique cursor FX — independently selectable in custom themes.
         * 'theme' = use signature set for the active pack (cyan→circuit, amber→ember, …).
         * hover / leftClick / rightClick each pick a unique effect (not just recolors).
         */
        cursor: {
            profile: 'theme', // theme | custom | none
            themeId: 'cyan',  // which pack signature when profile=theme
            hover: 'theme',   // theme | none | circuit-trail | ember-rise | …
            leftClick: 'theme',
            rightClick: 'theme',
            intensity: 0.75,
            size: 1,
        },
        borders: {
            // UI chrome / tags panels
            style: 'glow', // none | solid | double | dashed | glow | neon-run | gradient-spin | pulse-edge | corners
            width: 1,
            radius: 14,
            glow: 10,
            color: '#00e5ff',
            color2: '#a78bfa',
            color3: '#2dd4bf',
            animSpeed: 1,
            // Video frame overlay border (in addition to mediaConfig border)
            frameStyle: 'match', // match | none | solid | glow | neon-run | gradient-spin | pulse-edge | double
            frameWidth: 0, // 0 = use mediaConfig / leave alone unless style forces
            frameGlow: 0,
        },
        lights: {
            vignette: false,
            vignetteStrength: 0.4,
            bloom: false,
            bloomStrength: 0.3,
            scanlines: false,
            scanlinesOpacity: 0.07,
            crt: false,
            ambient: 'none', // none | soft | rim | spotlight | bokeh
            ambientStrength: 0.35,
            colorWash: false,
            colorWashOpacity: 0.12,
            flicker: false,
            godRays: false,
            godRaysStrength: 0.25,
        },
    };

    /** Signature FX per built-in theme pack — unique mechanics, not just color swaps */
    const THEME_CURSOR = {
        cyan:    { hover: 'circuit-trail', leftClick: 'hex-shock',     rightClick: 'data-burst' },
        amber:   { hover: 'ember-rise',    leftClick: 'magma-splash',  rightClick: 'ash-ring' },
        violet:  { hover: 'rune-orbit',    leftClick: 'portal-bloom',  rightClick: 'void-pull' },
        green:   { hover: 'matrix-rain',   leftClick: 'terminal-box',  rightClick: 'glitch-shatter' },
        steel:   { hover: 'metal-dust',    leftClick: 'impact-ring',   rightClick: 'weld-sparks' },
        ice:     { hover: 'frost-trail',   leftClick: 'freeze-ring',   rightClick: 'ice-shards' },
        rose:    { hover: 'petal-float',   leftClick: 'bloom-burst',   rightClick: 'confetti-spray' },
        crimson: { hover: 'heat-haze',     leftClick: 'flare-blast',   rightClick: 'slash-marks' },
    };

    /** All independently selectable unique effects */
    const CURSOR_FX_LIST = [
        { id: 'none', label: 'None' },
        { id: 'theme', label: 'Follow theme signature' },
        // Hover-oriented
        { id: 'circuit-trail', label: 'Circuit arc trail' },
        { id: 'ember-rise', label: 'Rising embers' },
        { id: 'rune-orbit', label: 'Orbiting runes' },
        { id: 'matrix-rain', label: 'Matrix glyphs' },
        { id: 'metal-dust', label: 'Metallic dust' },
        { id: 'frost-trail', label: 'Frost crystals' },
        { id: 'petal-float', label: 'Floating petals' },
        { id: 'heat-haze', label: 'Heat haze pulse' },
        { id: 'sonar-ping', label: 'Sonar pings' },
        { id: 'ink-ribbon', label: 'Ink ribbon' },
        // Click-oriented (also usable as hover for custom)
        { id: 'hex-shock', label: 'Hex shockwave' },
        { id: 'magma-splash', label: 'Magma splash' },
        { id: 'portal-bloom', label: 'Portal bloom' },
        { id: 'terminal-box', label: 'Terminal expand' },
        { id: 'impact-ring', label: 'Impact ring' },
        { id: 'freeze-ring', label: 'Freeze ring' },
        { id: 'bloom-burst', label: 'Bloom burst' },
        { id: 'flare-blast', label: 'Flare blast' },
        { id: 'data-burst', label: 'Data matrix burst' },
        { id: 'ash-ring', label: 'Ash ring' },
        { id: 'void-pull', label: 'Void pull-in' },
        { id: 'glitch-shatter', label: 'Glitch shatter' },
        { id: 'weld-sparks', label: 'Weld sparks' },
        { id: 'ice-shards', label: 'Ice shards' },
        { id: 'confetti-spray', label: 'Confetti spray' },
        { id: 'slash-marks', label: 'Slash marks' },
        { id: 'pixel-explode', label: 'Pixel explode' },
        { id: 'lightning-fork', label: 'Lightning fork' },
        { id: 'magnetic-field', label: 'Magnetic field' },
        { id: 'smoke-puff', label: 'Smoke puff' },
    ];

    let applied = null;
    let mouseEl = null;
    let trailEls = [];
    let bgLayer = null;
    let lightLayer = null;
    let frameBorderEl = null;
    let cursorLayer = null;
    let raf = 0;
    let mouseX = 0;
    let mouseY = 0;
    let trail = [];
    let listenersBound = false;
    let lastHoverSpawn = 0;
    let hoverParticles = [];

    function deepMerge(base, over) {
        const out = JSON.parse(JSON.stringify(base || {}));
        if (!over || typeof over !== 'object') return out;
        Object.keys(over).forEach((k) => {
            if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k])) {
                out[k] = deepMerge(out[k] || {}, over[k]);
            } else if (over[k] !== undefined) {
                out[k] = over[k];
            }
        });
        return out;
    }

    function hexToRgb(hex) {
        if (!hex) return null;
        let h = String(hex).replace('#', '').trim();
        if (h.length === 3) h = h.split('').map((c) => c + c).join('');
        if (h.length !== 6) return null;
        const n = parseInt(h, 16);
        if (Number.isNaN(n)) return null;
        return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }

    function rgba(hex, a) {
        const rgb = hexToRgb(hex);
        if (!rgb) return `rgba(0,229,255,${a})`;
        return `rgba(${rgb.r},${rgb.g},${rgb.b},${a})`;
    }

    function gradient(c1, c2, c3, angle, use3) {
        const a = Number(angle) || 135;
        if (use3 && c3) {
            return `linear-gradient(${a}deg, ${c1} 0%, ${c2 || c1} 50%, ${c3} 100%)`;
        }
        if (c2) return `linear-gradient(${a}deg, ${c1} 0%, ${c2} 100%)`;
        return c1;
    }

    function normalize(cfg) {
        return deepMerge(DEFAULTS, cfg || {});
    }

    async function loadFromStorage() {
        try {
            const { fafoVisual, mediaConfig } = await chrome.storage.local.get(['fafoVisual', 'mediaConfig']);
            if (fafoVisual && typeof fafoVisual === 'object') return normalize(fafoVisual);
            if (mediaConfig?.visual && typeof mediaConfig.visual === 'object') {
                return normalize(mediaConfig.visual);
            }
        } catch (_) {}
        return normalize(null);
    }

    async function saveToStorage(cfg) {
        const visual = normalize(cfg);
        try {
            await chrome.storage.local.set({ fafoVisual: visual });
            const { mediaConfig } = await chrome.storage.local.get('mediaConfig');
            if (mediaConfig && typeof mediaConfig === 'object') {
                mediaConfig.visual = visual;
                await chrome.storage.local.set({ mediaConfig });
            }
        } catch (_) {}
        return visual;
    }

    function ensureLayers() {
        if (!bgLayer) {
            bgLayer = document.getElementById('fafo-visual-bg');
            if (!bgLayer) {
                bgLayer = document.createElement('div');
                bgLayer.id = 'fafo-visual-bg';
                bgLayer.className = 'fafo-visual-bg';
                bgLayer.setAttribute('aria-hidden', 'true');
                document.body.prepend(bgLayer);
            }
        }
        if (!lightLayer) {
            lightLayer = document.getElementById('fafo-visual-lights');
            if (!lightLayer) {
                lightLayer = document.createElement('div');
                lightLayer.id = 'fafo-visual-lights';
                lightLayer.className = 'fafo-visual-lights';
                lightLayer.setAttribute('aria-hidden', 'true');
                lightLayer.innerHTML =
                    '<div class="fvl-vignette"></div>' +
                    '<div class="fvl-bloom"></div>' +
                    '<div class="fvl-scanlines"></div>' +
                    '<div class="fvl-crt"></div>' +
                    '<div class="fvl-ambient"></div>' +
                    '<div class="fvl-wash"></div>' +
                    '<div class="fvl-rays"></div>' +
                    '<div class="fvl-flicker"></div>';
                document.body.appendChild(lightLayer);
            }
        }
        if (!frameBorderEl) {
            frameBorderEl = document.getElementById('fafo-visual-frame-border');
            if (!frameBorderEl) {
                frameBorderEl = document.createElement('div');
                frameBorderEl.id = 'fafo-visual-frame-border';
                frameBorderEl.className = 'fafo-visual-frame-border';
                frameBorderEl.setAttribute('aria-hidden', 'true');
                document.body.appendChild(frameBorderEl);
            }
        }
        if (!cursorLayer) {
            cursorLayer = document.getElementById('fafo-cursor-fx');
            if (!cursorLayer) {
                cursorLayer = document.createElement('div');
                cursorLayer.id = 'fafo-cursor-fx';
                cursorLayer.className = 'fafo-cursor-fx';
                cursorLayer.setAttribute('aria-hidden', 'true');
                document.body.appendChild(cursorLayer);
            }
        }
        if (!mouseEl) {
            mouseEl = document.getElementById('fafo-visual-mouse');
            if (!mouseEl) {
                mouseEl = document.createElement('div');
                mouseEl.id = 'fafo-visual-mouse';
                mouseEl.className = 'fafo-visual-mouse';
                mouseEl.setAttribute('aria-hidden', 'true');
                document.body.appendChild(mouseEl);
            }
        }
        if (!trailEls.length) {
            for (let i = 0; i < 8; i++) {
                const d = document.createElement('div');
                d.className = 'fafo-visual-trail-dot';
                d.setAttribute('aria-hidden', 'true');
                document.body.appendChild(d);
                trailEls.push(d);
            }
        }
    }

    function stripPrefixedClasses(el, prefixes) {
        if (!el) return;
        [...el.classList].forEach((cls) => {
            if (prefixes.some((p) => cls === p || cls.startsWith(p + '-'))) {
                el.classList.remove(cls);
            }
        });
    }

    function applyCssVars(v) {
        const root = document.documentElement;
        const c = v.colors;
        const g = v.gradients;
        const a = v.anim;
        const b = v.borders || DEFAULTS.borders;
        const L = v.lights || DEFAULTS.lights;

        const accent = c.accent || DEFAULTS.colors.accent;
        const rgb = hexToRgb(accent) || { r: 0, g: 229, b: 255 };

        root.style.setProperty('--accent', accent);
        root.style.setProperty('--accent-dim', `rgba(${rgb.r},${rgb.g},${rgb.b},0.15)`);
        root.style.setProperty('--accent-glow', `rgba(${rgb.r},${rgb.g},${rgb.b},0.6)`);
        root.style.setProperty('--text', c.text || DEFAULTS.colors.text);
        root.style.setProperty('--text-dim', c.textDim || DEFAULTS.colors.textDim);
        root.style.setProperty('--bg', c.bg || DEFAULTS.colors.bg);

        // Tag status colors
        root.style.setProperty('--tag-selected', c.tagSelected || DEFAULTS.colors.tagSelected);
        root.style.setProperty('--tag-selected-glow', rgba(c.tagSelected || DEFAULTS.colors.tagSelected, 0.45));
        root.style.setProperty('--tag-last-video', c.tagLastVideo || DEFAULTS.colors.tagLastVideo);
        root.style.setProperty('--tag-last-video-glow', rgba(c.tagLastVideo || DEFAULTS.colors.tagLastVideo, 0.55));
        root.style.setProperty('--tag-session', c.tagSession || DEFAULTS.colors.tagSession);
        root.style.setProperty('--tag-library', c.tagLibrary || DEFAULTS.colors.tagLibrary);
        root.style.setProperty('--tag-unused', c.tagUnused || DEFAULTS.colors.tagUnused);
        root.style.setProperty('--sprint-accent', c.sprint || DEFAULTS.colors.sprint);
        root.style.setProperty('--neon-color-user', c.neon || accent);
        root.style.setProperty('--mouse-glow', c.mouseGlow || accent);

        // Gradients
        if (c.useAccentGradient) {
            const ag = gradient(c.accent, c.accent2 || c.accent, c.accent3 || c.accent2, g.accentAngle, true);
            root.style.setProperty('--accent-gradient', ag);
            root.style.setProperty('--accent-fill', ag);
        } else {
            root.style.setProperty('--accent-gradient', accent);
            root.style.setProperty('--accent-fill', accent);
        }

        if (c.useBgGradient) {
            const bg = gradient(c.bg, c.bg2 || c.bg, c.bg3 || c.bg2, g.bgAngle, true);
            root.style.setProperty('--bg-fill', bg);
            document.body.style.background = bg;
        } else {
            root.style.setProperty('--bg-fill', c.bg || '#050505');
            document.body.style.backgroundColor = c.bg || '#050505';
            document.body.style.backgroundImage = '';
        }

        // Panel border can follow custom color
        if (c.panelBorder) {
            const br = hexToRgb(c.panelBorder);
            if (br) {
                root.style.setProperty('--ui-panel-border-rgb', `${br.r},${br.g},${br.b}`);
            }
        }

        // Borders
        const bColor = b.color || c.panelBorder || accent;
        const b2 = b.color2 || c.accent2 || accent;
        const b3 = b.color3 || c.accent3 || b2;
        root.style.setProperty('--fafo-border-color', bColor);
        root.style.setProperty('--fafo-border-color-2', b2);
        root.style.setProperty('--fafo-border-color-3', b3);
        root.style.setProperty('--fafo-border-width', `${Math.max(0, Math.min(12, Number(b.width) || 1))}px`);
        root.style.setProperty('--fafo-border-radius', `${Math.max(0, Math.min(40, Number(b.radius) || 14))}px`);
        root.style.setProperty('--fafo-border-glow', `${Math.max(0, Math.min(48, Number(b.glow) || 0))}px`);
        root.style.setProperty('--fafo-border-speed', String(Math.max(0.25, Math.min(3, Number(b.animSpeed) || 1))));
        root.style.setProperty('--fafo-border-gradient', gradient(bColor, b2, b3, 90, true));

        // Lights
        root.style.setProperty('--fafo-vignette', String(Math.max(0, Math.min(0.9, Number(L.vignetteStrength) || 0.4))));
        root.style.setProperty('--fafo-bloom', String(Math.max(0, Math.min(0.9, Number(L.bloomStrength) || 0.3))));
        root.style.setProperty('--fafo-scanlines', String(Math.max(0, Math.min(0.4, Number(L.scanlinesOpacity) || 0.07))));
        root.style.setProperty('--fafo-ambient', String(Math.max(0, Math.min(1, Number(L.ambientStrength) || 0.35))));
        root.style.setProperty('--fafo-wash', String(Math.max(0, Math.min(0.5, Number(L.colorWashOpacity) || 0.12))));
        root.style.setProperty('--fafo-rays', String(Math.max(0, Math.min(0.8, Number(L.godRaysStrength) || 0.25))));

        // Animation / class flags on body
        const body = document.body;
        stripPrefixedClasses(body, [
            'fafo-bg', 'fafo-mouse', 'fafo-tag', 'fafo-last',
            'fafo-border', 'fafo-frame', 'fafo-light', 'fafo-ambient',
            'fafo-reduce-motion', 'fafo-panel-pulse', 'fafo-hud-breath',
            'fafo-light-vignette', 'fafo-light-bloom', 'fafo-light-scanlines',
            'fafo-light-crt', 'fafo-light-wash', 'fafo-light-flicker', 'fafo-light-rays',
        ]);

        body.classList.add(`fafo-bg-${a.background || 'none'}`);
        body.classList.add(`fafo-mouse-${a.mouse || 'none'}`);
        body.classList.add(`fafo-tag-${a.tagSelected || 'neon'}`);
        if (a.tagLastVideo === 'breathe-gold') body.classList.add('fafo-last-breathe-gold');
        else if (a.tagLastVideo === 'pulse') body.classList.add('fafo-last-pulse');
        else if (a.tagLastVideo === 'flash') body.classList.add('fafo-last-flash');
        else body.classList.add('fafo-last-static');
        if (a.reduceMotion) body.classList.add('fafo-reduce-motion');
        if (a.panelPulse) body.classList.add('fafo-panel-pulse');
        if (a.hudBreath) body.classList.add('fafo-hud-breath');

        body.classList.add(`fafo-border-${b.style || 'glow'}`);
        const frameStyle = b.frameStyle === 'match' ? (b.style || 'glow') : (b.frameStyle || 'none');
        body.classList.add(`fafo-frame-${frameStyle}`);

        if (L.vignette) body.classList.add('fafo-light-vignette');
        if (L.bloom) body.classList.add('fafo-light-bloom');
        if (L.scanlines) body.classList.add('fafo-light-scanlines');
        if (L.crt) body.classList.add('fafo-light-crt');
        if (L.colorWash) body.classList.add('fafo-light-wash');
        if (L.flicker) body.classList.add('fafo-light-flicker');
        if (L.godRays) body.classList.add('fafo-light-rays');
        body.classList.add(`fafo-ambient-${L.ambient || 'none'}`);

        root.style.setProperty('--fafo-anim-speed', String(Math.max(0.25, Math.min(3, Number(a.backgroundSpeed) || 1))));
        root.style.setProperty('--fafo-anim-intensity', String(Math.max(0.05, Math.min(1, Number(a.backgroundIntensity) || 0.45))));
        root.style.setProperty('--fafo-mouse-size', `${Math.max(40, Math.min(400, Number(a.mouseSize) || 140))}px`);
        root.style.setProperty('--fafo-mouse-opacity', String(Math.max(0.05, Math.min(0.9, Number(a.mouseOpacity) || 0.35))));
    }

    function resolveCursorFx(slot) {
        const cur = applied?.cursor || DEFAULTS.cursor;
        if (!cur || cur.profile === 'none') return 'none';
        let pick = cur[slot] || 'theme';
        if (pick === 'theme' || cur.profile === 'theme') {
            const tid = cur.themeId || 'cyan';
            const sig = THEME_CURSOR[tid] || THEME_CURSOR.cyan;
            if (pick === 'theme') pick = sig[slot] || 'none';
        }
        return pick || 'none';
    }

    function cursorIntensity() {
        return Math.max(0.15, Math.min(1.2, Number(applied?.cursor?.intensity) || 0.75));
    }

    function cursorSize() {
        return Math.max(0.5, Math.min(2, Number(applied?.cursor?.size) || 1));
    }

    function bindMouse() {
        if (listenersBound) return;
        listenersBound = true;
        document.addEventListener('pointermove', (e) => {
            mouseX = e.clientX;
            mouseY = e.clientY;
            if (applied?.anim?.reduceMotion) return;

            // Legacy follow glow still optional
            const mode = applied?.anim?.mouse || 'none';
            if (mode !== 'none' && mouseEl) {
                mouseEl.style.transform = `translate(${mouseX}px, ${mouseY}px) translate(-50%, -50%)`;
                mouseEl.classList.add('active');
            }
            if (mode === 'spotlight' || applied?.lights?.ambient === 'spotlight') {
                document.documentElement.style.setProperty('--fafo-spot-x', mouseX + 'px');
                document.documentElement.style.setProperty('--fafo-spot-y', mouseY + 'px');
            }
            if (mode === 'trail' || mode === 'spark') {
                trail.unshift({ x: mouseX, y: mouseY, t: performance.now() });
                if (trail.length > 16) trail.length = 16;
            }
            if (mode === 'ripple' && e.buttons === 0 && Math.random() < 0.04) spawnRipple(mouseX, mouseY);
            if (mode === 'spark' && Math.random() < 0.12) spawnSpark(mouseX, mouseY);

            // Unique theme/custom hover FX (throttled)
            const hoverFx = resolveCursorFx('hover');
            if (hoverFx && hoverFx !== 'none') {
                const now = performance.now();
                const gap = hoverFx.includes('orbit') || hoverFx.includes('rune') ? 90 : 55;
                if (now - lastHoverSpawn > gap) {
                    lastHoverSpawn = now;
                    spawnCursorFx(hoverFx, mouseX, mouseY, 'hover');
                }
            }
        }, { passive: true });

        document.addEventListener('pointerdown', (e) => {
            if (applied?.anim?.reduceMotion) return;
            // Don't steal context menu on right click — only spawn FX
            const slot = e.button === 2 ? 'rightClick' : 'leftClick';
            // Middle click uses left-style
            const fx = resolveCursorFx(slot);
            if (fx && fx !== 'none') {
                spawnCursorFx(fx, e.clientX, e.clientY, slot);
            }
            // Legacy
            const mode = applied?.anim?.mouse;
            if (mode === 'ripple') spawnRipple(e.clientX, e.clientY);
            if (mode === 'spark') {
                for (let i = 0; i < 5; i++) spawnSpark(e.clientX, e.clientY);
            }
        }, { passive: true });

        // Prevent browser context menu only when a right-click FX is active? No — keep menu.
        document.addEventListener('contextmenu', (e) => {
            // still allow FX on contextmenu event as backup for some browsers
            if (applied?.anim?.reduceMotion) return;
            const fx = resolveCursorFx('rightClick');
            if (fx && fx !== 'none') spawnCursorFx(fx, e.clientX, e.clientY, 'rightClick');
        }, { passive: true });

        document.addEventListener('pointerleave', () => {
            mouseEl?.classList.remove('active');
        });
    }

    function spawnRipple(x, y) {
        const r = document.createElement('div');
        r.className = 'fafo-visual-ripple';
        r.style.left = x + 'px';
        r.style.top = y + 'px';
        (cursorLayer || document.body).appendChild(r);
        setTimeout(() => r.remove(), 900);
    }

    function spawnSpark(x, y) {
        const s = document.createElement('div');
        s.className = 'fafo-visual-spark';
        const ang = Math.random() * Math.PI * 2;
        const dist = 12 + Math.random() * 40;
        s.style.left = x + 'px';
        s.style.top = y + 'px';
        s.style.setProperty('--sx', Math.cos(ang) * dist + 'px');
        s.style.setProperty('--sy', Math.sin(ang) * dist + 'px');
        (cursorLayer || document.body).appendChild(s);
        setTimeout(() => s.remove(), 500);
    }

    function elFx(cls, x, y, extra = {}) {
        const d = document.createElement('div');
        d.className = `fafo-cfx ${cls}`;
        d.style.left = x + 'px';
        d.style.top = y + 'px';
        const sz = cursorSize();
        const inten = cursorIntensity();
        d.style.setProperty('--cfx-size', String(sz));
        d.style.setProperty('--cfx-i', String(inten));
        Object.keys(extra).forEach((k) => d.style.setProperty(k, extra[k]));
        (cursorLayer || document.body).appendChild(d);
        return d;
    }

    function spawnCursorFx(type, x, y, slot) {
        if (!type || type === 'none' || type === 'theme') return;
        ensureLayers();
        const host = cursorLayer || document.body;
        const life = (ms, node) => setTimeout(() => node?.remove(), ms);
        const rnd = () => Math.random();
        const ang = () => rnd() * Math.PI * 2;

        switch (type) {
            case 'circuit-trail': {
                const n = elFx('cfx-circuit', x, y, {
                    '--rot': `${rnd() * 360}deg`,
                    '--len': `${18 + rnd() * 28}px`,
                });
                life(420, n);
                break;
            }
            case 'ember-rise': {
                for (let i = 0; i < 3; i++) {
                    const n = elFx('cfx-ember', x + (rnd() - 0.5) * 10, y, {
                        '--dx': `${(rnd() - 0.5) * 24}px`,
                        '--dy': `${-(30 + rnd() * 50)}px`,
                        '--delay': `${i * 40}ms`,
                    });
                    life(700, n);
                }
                break;
            }
            case 'rune-orbit': {
                const n = elFx('cfx-rune', x, y, { '--phase': `${rnd() * 360}deg` });
                n.textContent = ['ᚠ', 'ᚢ', 'ᚦ', '✦', '✧', '⬡'][Math.floor(rnd() * 6)];
                life(650, n);
                break;
            }
            case 'matrix-rain': {
                const n = elFx('cfx-matrix', x, y);
                n.textContent = String.fromCharCode(0x30A0 + Math.floor(rnd() * 96));
                life(550, n);
                break;
            }
            case 'metal-dust': {
                for (let i = 0; i < 4; i++) {
                    const a = ang();
                    const n = elFx('cfx-dust', x, y, {
                        '--dx': `${Math.cos(a) * (8 + rnd() * 20)}px`,
                        '--dy': `${Math.sin(a) * (8 + rnd() * 20)}px`,
                    });
                    life(500, n);
                }
                break;
            }
            case 'frost-trail': {
                const n = elFx('cfx-frost', x, y, { '--rot': `${rnd() * 60 - 30}deg` });
                life(600, n);
                break;
            }
            case 'petal-float': {
                const n = elFx('cfx-petal', x, y, {
                    '--dx': `${(rnd() - 0.5) * 40}px`,
                    '--dy': `${-(20 + rnd() * 40)}px`,
                    '--rot': `${rnd() * 180}deg`,
                });
                life(800, n);
                break;
            }
            case 'heat-haze': {
                const n = elFx('cfx-haze', x, y);
                life(480, n);
                break;
            }
            case 'sonar-ping': {
                const n = elFx('cfx-sonar', x, y);
                life(700, n);
                break;
            }
            case 'ink-ribbon': {
                const n = elFx('cfx-ribbon', x, y, { '--rot': `${rnd() * 360}deg` });
                life(550, n);
                break;
            }
            case 'hex-shock': {
                const n = elFx('cfx-hex', x, y);
                life(750, n);
                break;
            }
            case 'magma-splash': {
                for (let i = 0; i < 8; i++) {
                    const a = ang();
                    const d = 20 + rnd() * 50;
                    const n = elFx('cfx-magma', x, y, {
                        '--dx': `${Math.cos(a) * d}px`,
                        '--dy': `${Math.sin(a) * d}px`,
                    });
                    life(650, n);
                }
                break;
            }
            case 'portal-bloom': {
                const n = elFx('cfx-portal', x, y);
                life(900, n);
                break;
            }
            case 'terminal-box': {
                const n = elFx('cfx-terminal', x, y);
                n.innerHTML = '<span>&gt;_</span>';
                life(700, n);
                break;
            }
            case 'impact-ring': {
                const n = elFx('cfx-impact', x, y);
                life(550, n);
                break;
            }
            case 'freeze-ring': {
                const n = elFx('cfx-freeze', x, y);
                life(800, n);
                break;
            }
            case 'bloom-burst': {
                for (let i = 0; i < 10; i++) {
                    const a = (i / 10) * Math.PI * 2;
                    const n = elFx('cfx-bloom', x, y, {
                        '--dx': `${Math.cos(a) * 40}px`,
                        '--dy': `${Math.sin(a) * 40}px`,
                    });
                    life(700, n);
                }
                break;
            }
            case 'flare-blast': {
                const n = elFx('cfx-flare', x, y);
                life(600, n);
                break;
            }
            case 'data-burst': {
                for (let i = 0; i < 12; i++) {
                    const n = elFx('cfx-data', x, y, {
                        '--dx': `${(rnd() - 0.5) * 80}px`,
                        '--dy': `${(rnd() - 0.5) * 80}px`,
                    });
                    n.textContent = rnd() > 0.5 ? '1' : '0';
                    life(600, n);
                }
                break;
            }
            case 'ash-ring': {
                const n = elFx('cfx-ash', x, y);
                life(700, n);
                break;
            }
            case 'void-pull': {
                const n = elFx('cfx-void', x, y);
                life(750, n);
                break;
            }
            case 'glitch-shatter': {
                for (let i = 0; i < 6; i++) {
                    const n = elFx('cfx-glitch', x + (rnd() - 0.5) * 20, y + (rnd() - 0.5) * 20, {
                        '--dx': `${(rnd() - 0.5) * 60}px`,
                        '--dy': `${(rnd() - 0.5) * 40}px`,
                        '--w': `${8 + rnd() * 24}px`,
                    });
                    life(450, n);
                }
                break;
            }
            case 'weld-sparks': {
                for (let i = 0; i < 14; i++) {
                    const a = ang();
                    const d = 15 + rnd() * 55;
                    const n = elFx('cfx-weld', x, y, {
                        '--dx': `${Math.cos(a) * d}px`,
                        '--dy': `${Math.sin(a) * d}px`,
                    });
                    life(500, n);
                }
                break;
            }
            case 'ice-shards': {
                for (let i = 0; i < 8; i++) {
                    const a = ang();
                    const d = 20 + rnd() * 45;
                    const n = elFx('cfx-shard', x, y, {
                        '--dx': `${Math.cos(a) * d}px`,
                        '--dy': `${Math.sin(a) * d}px`,
                        '--rot': `${rnd() * 180}deg`,
                    });
                    life(600, n);
                }
                break;
            }
            case 'confetti-spray': {
                for (let i = 0; i < 16; i++) {
                    const a = ang();
                    const d = 25 + rnd() * 60;
                    const n = elFx('cfx-confetti', x, y, {
                        '--dx': `${Math.cos(a) * d}px`,
                        '--dy': `${Math.sin(a) * d - 20}px`,
                        '--hue': `${Math.floor(rnd() * 360)}deg`,
                    });
                    life(750, n);
                }
                break;
            }
            case 'slash-marks': {
                for (let i = 0; i < 3; i++) {
                    const n = elFx('cfx-slash', x, y, {
                        '--rot': `${-40 + i * 40 + (rnd() - 0.5) * 15}deg`,
                        '--delay': `${i * 40}ms`,
                    });
                    life(500, n);
                }
                break;
            }
            case 'pixel-explode': {
                for (let i = 0; i < 16; i++) {
                    const a = ang();
                    const d = 10 + rnd() * 50;
                    const n = elFx('cfx-pixel', x, y, {
                        '--dx': `${Math.cos(a) * d}px`,
                        '--dy': `${Math.sin(a) * d}px`,
                    });
                    life(500, n);
                }
                break;
            }
            case 'lightning-fork': {
                const n = elFx('cfx-lightning', x, y, { '--rot': `${rnd() * 360}deg` });
                life(400, n);
                break;
            }
            case 'magnetic-field': {
                const n = elFx('cfx-magnetic', x, y);
                life(700, n);
                break;
            }
            case 'smoke-puff': {
                const n = elFx('cfx-smoke', x, y);
                life(800, n);
                break;
            }
            default:
                spawnRipple(x, y);
        }
    }

    function tickTrail() {
        const mode = applied?.anim?.mouse;
        if (!applied || (mode !== 'trail' && mode !== 'spark') || applied.anim?.reduceMotion) {
            trailEls.forEach((el) => { el.style.opacity = '0'; });
            return;
        }
        const now = performance.now();
        trail = trail.filter((p) => now - p.t < 500);
        trailEls.forEach((el, i) => {
            const p = trail[i * 2];
            if (!p) {
                el.style.opacity = '0';
                return;
            }
            const age = (now - p.t) / 500;
            el.style.opacity = String(Math.max(0, 0.55 * (1 - age)));
            el.style.transform = `translate(${p.x}px, ${p.y}px) translate(-50%, -50%) scale(${1 - age * 0.6})`;
        });
    }

    function startLoop() {
        cancelAnimationFrame(raf);
        const loop = () => {
            tickTrail();
            raf = requestAnimationFrame(loop);
        };
        raf = requestAnimationFrame(loop);
    }

    function apply(cfg) {
        applied = normalize(cfg);
        ensureLayers();
        applyCssVars(applied);

        const bgMode = applied.anim.background || 'none';
        if (bgLayer) {
            bgLayer.className = `fafo-visual-bg mode-${bgMode}`;
            bgLayer.dataset.mode = bgMode;
            // Seed CSS colors for animated layers
            const c = applied.colors;
            bgLayer.style.setProperty('--v-c1', c.accent || '#00e5ff');
            bgLayer.style.setProperty('--v-c2', c.accent2 || c.tagSession || '#2dd4bf');
            bgLayer.style.setProperty('--v-c3', c.accent3 || c.tagLibrary || '#a78bfa');
        }

        const mouseMode = applied.anim.mouse || 'none';
        if (mouseEl) {
            mouseEl.className = `fafo-visual-mouse mode-${mouseMode}`;
            const glow = rgba(applied.colors.mouseGlow || applied.colors.accent, 0.55);
            if (mouseMode === 'spotlight') {
                mouseEl.style.background = `radial-gradient(circle, ${glow} 0%, transparent 55%)`;
            } else {
                mouseEl.style.background = `radial-gradient(circle, ${glow} 0%, transparent 70%)`;
            }
        }
        trailEls.forEach((el) => {
            el.style.background = rgba(applied.colors.mouseGlow || applied.colors.accent, 0.7);
        });

        if (lightLayer) {
            lightLayer.className = 'fafo-visual-lights';
            const L = applied.lights || {};
            lightLayer.dataset.ambient = L.ambient || 'none';
        }
        if (frameBorderEl) {
            const b = applied.borders || {};
            const fs = b.frameStyle === 'match' ? (b.style || 'glow') : (b.frameStyle || 'none');
            frameBorderEl.className = `fafo-visual-frame-border style-${fs}`;
            frameBorderEl.style.display = fs === 'none' ? 'none' : '';
        }

        bindMouse();
        startLoop();
        return applied;
    }

    async function init() {
        const v = await loadFromStorage();
        apply(v);
        try {
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local') return;
                if (changes.fafoVisual?.newValue) apply(changes.fafoVisual.newValue);
                else if (changes.mediaConfig?.newValue?.visual) apply(changes.mediaConfig.newValue.visual);
            });
        } catch (_) {}
        return v;
    }

    global.FAFOVisual = {
        DEFAULTS,
        THEME_CURSOR,
        CURSOR_FX_LIST,
        normalize,
        loadFromStorage,
        saveToStorage,
        apply,
        init,
        hexToRgb,
        gradient,
        resolveCursorFx,
        spawnCursorFx,
        getApplied: () => applied,
        /** Apply theme pack signature cursor FX into a visual config object */
        applyThemeCursor(visual, themeId) {
            const v = normalize(visual || {});
            const tid = themeId || 'cyan';
            v.cursor = v.cursor || { ...DEFAULTS.cursor };
            v.cursor.profile = 'theme';
            v.cursor.themeId = tid;
            v.cursor.hover = 'theme';
            v.cursor.leftClick = 'theme';
            v.cursor.rightClick = 'theme';
            return v;
        },
    };
})(typeof window !== 'undefined' ? window : globalThis);
