document.addEventListener('DOMContentLoaded', async () => {
    const $ = id => document.getElementById(id);
    let db = null;
    let currentConfig = {};
    let editingFile = null;

    // --- STATE ---
    let currentPage = 1;
    let itemsPerPage = 50;
    let allLibraryItems = []; 
    let activePlaylistView = 'all'; 

    // --- TOAST NOTIFICATION SYSTEM ---
    function showToast(msg, type = 'success') {
        const status = $('save-status');
        if (!status) return;
        status.textContent = msg;
        status.style.borderColor = type === 'error' ? '#ff4444' : '#00e5ff';
        status.style.color = type === 'error' ? '#ff4444' : '#00e5ff';
        status.style.display = 'block';
        setTimeout(() => status.style.display = 'none', 3000);
    }

    // --- THUMBNAIL QUEUE SYSTEM ---
    const thumbQueue = {
        active: 0, queue: [], limit: 3,
        add: function(file, imgElement) { this.queue.push({file, imgElement}); this.process(); },
        process: async function() {
            if (this.active >= this.limit || this.queue.length === 0) return;
            this.active++;
            const task = this.queue.shift();
            try {
                const url = await generateThumbnail(task.file);
                if (url) task.imgElement.src = url;
            } catch(e) { console.log("Thumb gen failed", e); } finally { this.active--; this.process(); }
        }
    };

    // --- TABS SYSTEM ---
    document.querySelectorAll('.tab').forEach(t => {
        t.onclick = () => {
            document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
            document.querySelectorAll('.view-section').forEach(x => x.classList.remove('active'));
            t.classList.add('active');
            const target = $(t.dataset.target);
            if(target) target.classList.add('active');
            if (t.dataset.target === 'view-library') loadLibraryGrid();
            if (t.dataset.target === 'view-playlists') loadPlaylistsUI();
        };
    });

    // --- SLIDERS UI ---
    function initSliders() {
        document.querySelectorAll('input[type=range]').forEach(el => {
            const span = document.getElementById(el.id + '-val');
            if(span) {
                span.textContent = el.value;
                el.addEventListener('input', () => span.textContent = el.value);
            }
        });
    }

    // --- THEME ENGINE ---
    function applyTheme(hex) {
        if (!hex) return;
        const root = document.documentElement;
        const hexToRgb = (h) => {
            const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
            h = h.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h);
            return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null;
        };
        const rgb = hexToRgb(hex);
        if (rgb) {
            root.style.setProperty('--accent', hex);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }
    }

    // --- DB INIT ---
    async function openDB() {
        return new Promise((res, rej) => {
            const req = indexedDB.open('NewTabMediaDB', 3);
            req.onblocked = () => alert("Database Upgrade Blocked! Close other New Tab pages and reload.");
            req.onupgradeneeded = e => {
                const d = e.target.result;
                ['videos', 'photos'].forEach(s => {
                   if(!d.objectStoreNames.contains(s)) d.createObjectStore(s, {autoIncrement: true});
                });
                if(!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', {keyPath: 'id'});
            };
            req.onsuccess = () => { db = req.result; res(db); };
            req.onerror = (e) => { console.error("DB Error", e); res(null); };
        });
    }

    // --- LOAD SETTINGS ---
    async function loadSettings() {
        await openDB();
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        
        const defaults = {
            useLocal: true, usePhotos: true, urls: [], 
            layout: 'cinema', scaling: 'scale-capped',
            gridCols: 4, gridRows: 1, 
            carouselRadius: 650, carouselTilt: 0, carouselSpeed: 40,
            reflectOpacity: 30, reflectOffset: 0,

            neonBorder: false, neonPattern: 'chase', neonSegments: 24,
            neonSpeed: 1, neonAudio: true, neonStrobe: 0.8,
            neonSensitivity: 1.2, neonWidth: 4, neonUseAccent: true, neonColor: '#00e5ff',
            
            // FX DEFAULTS
            fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
            fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
            fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
            fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
            fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
            fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,

            brightness: 100, contrast: 100, saturate: 100, sepia: 0, grayscale: 0,
            ambiScale: 1.0, ambiOpacity: 0.25, ambiBlur: 5, ambiMode: 'blur',
            borderSize: 0, borderColor: '#44858d', borderGlow: 15,
            volume: 0.0, photoDuration: 3, shuffle: true,
            clockSize: 25, font: "'Arial Black', sans-serif", pos: 'pos-bottom-left',
            showDate: true, format12h: true, showSeconds: false,
            accentColor: '#00e5ff', activePlaylistId: 'all', overrides: {}
        };

        currentConfig = {...defaults, ...mediaConfig};
        applyTheme(currentConfig.accentColor);

        const set = (id, val, type) => {
            const el = $(id);
            if(!el) return;
            if (type === 'check') el.checked = val;
            else if (type === 'val') el.value = val;
            else if (type === 'array') el.value = (val || []).join('\n'); 
            else el.value = val;
            
            if(el.type === 'range') {
                const span = document.getElementById(el.id + '-val');
                if(span) span.textContent = val;
            }
        };

        // Basic fields
        Object.keys(currentConfig).forEach(k => {
            if(k === 'overrides') return;
            const el = $(k);
            if(el) set(k, currentConfig[k], el.type === 'checkbox' ? 'check' : (k === 'urls' ? 'array' : 'val'));
        });
        
        // Manual Mappings
        set('grid-cols', currentConfig.gridCols); set('grid-rows', currentConfig.gridRows);
        set('carousel-radius', currentConfig.carouselRadius); set('carousel-tilt', currentConfig.carouselTilt);
        set('carousel-speed', currentConfig.carouselSpeed); set('reflect-opacity', currentConfig.reflectOpacity);
        set('reflect-offset', currentConfig.reflectOffset);

        // Dynamic FX Loading
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            set(`fx-${type}`, currentConfig[camelCase(`fx-${type}`)], 'check');
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                set(id, currentConfig[camelCase(id)]);
            });
        });

        set('ambi-mode', currentConfig.ambiMode);
        set('ambi-scale', currentConfig.ambiScale);
        set('ambi-opacity', currentConfig.ambiOpacity);
        set('ambi-blur', currentConfig.ambiBlur);
        set('border-color', currentConfig.borderColor);
        set('border-glow', currentConfig.borderGlow);
        set('photo-duration', currentConfig.photoDuration);
        set('clock-pos', currentConfig.pos);
        set('clock-size', currentConfig.clockSize);
        set('font-family', currentConfig.font);
        set('show-date', currentConfig.showDate, 'check');
        set('format-12h', currentConfig.format12h, 'check');
        set('show-seconds', currentConfig.showSeconds, 'check');
        set('use-local', currentConfig.useLocal, 'check');
        set('use-photos', currentConfig.usePhotos, 'check');
        set('urls', currentConfig.urls, 'array');
        set('accent-color', currentConfig.accentColor);

        set('neon-border', currentConfig.neonBorder, 'check');
        set('neon-pattern', currentConfig.neonPattern);
        set('neon-segments', currentConfig.neonSegments);
        set('neon-speed', currentConfig.neonSpeed);
        set('neon-audio', currentConfig.neonAudio, 'check');
        set('neon-strobe', currentConfig.neonStrobe);
        set('neon-sensitivity', currentConfig.neonSensitivity);
        set('neon-width', currentConfig.neonWidth);
        set('neon-use-accent', currentConfig.neonUseAccent, 'check');
        set('neon-color', currentConfig.neonColor);
        set('border-size', currentConfig.borderSize);
        
        if (db) await loadPlaylistsUI();
        
        if($('active-playlist-selector')) {
             $('active-playlist-selector').value = currentConfig.activePlaylistId || 'all';
             activePlaylistView = currentConfig.activePlaylistId || 'all';
        }

        if (db) loadLibraryGrid();
        initSliders();
    }

    function camelCase(str) { return str.replace(/-([a-z])/g, (g) => g[1].toUpperCase()); }

    async function generateThumbnail(file) {
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.preload = 'metadata'; video.muted = true; video.playsInline = true;
            const url = URL.createObjectURL(file);
            video.src = url;
            video.onloadeddata = () => { video.currentTime = Math.min(4, video.duration); };
            video.onseeked = () => {
                const canvas = document.createElement('canvas');
                canvas.width = video.videoWidth / 4; canvas.height = video.videoHeight / 4;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                URL.revokeObjectURL(url); video.remove(); resolve(dataUrl);
            };
            video.onerror = () => { URL.revokeObjectURL(url); video.remove(); resolve(null); };
        });
    }

    async function getPlaylists() {
        if (!db) return [];
        return new Promise(res => {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            const req = store.getAll();
            req.onsuccess = () => res(req.result || []);
            req.onerror = () => res([]);
        });
    }

    async function loadPlaylistsUI() {
        const playlists = await getPlaylists();
        const container = $('playlist-list');
        const select = $('active-playlist-selector');
        const modalSelect = $('modal-playlist-select');
        
        if(container) container.innerHTML = '';
        
        if(select) {
            const currentSelectVal = select.value || 'all';
            select.innerHTML = '<option value="all">📚 All Library</option>';
            playlists.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = `🎼 ${p.name} (${p.items.length})`;
                select.appendChild(opt);
            });
            select.value = currentSelectVal;
        }

        if(modalSelect) {
            modalSelect.innerHTML = '<option value="">Select Playlist...</option>';
            playlists.forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = p.name;
                modalSelect.appendChild(opt);
            });
        }

        if(container) {
            if(playlists.length === 0) container.innerHTML = '<span style="color:#666">No collections created yet.</span>';
            playlists.forEach(p => {
                const chip = document.createElement('div');
                chip.className = 'playlist-chip';
                chip.innerHTML = `${p.name} <span style="color:#666">(${p.items.length})</span>`;
                const del = document.createElement('button');
                del.textContent = '×';
                del.onclick = async () => {
                    if(confirm(`Delete playlist "${p.name}"?`)) {
                        const tx = db.transaction('playlists', 'readwrite');
                        tx.objectStore('playlists').delete(p.id);
                        tx.oncomplete = () => loadPlaylistsUI();
                    }
                };
                chip.appendChild(del);
                container.appendChild(chip);
            });
        }
    }

    const createBtn = $('create-playlist-btn');
    if (createBtn) {
        createBtn.onclick = () => {
            if (!db) { showToast("Database Not Ready", "error"); return; }
            const nameInput = $('new-playlist-name');
            const name = nameInput ? nameInput.value.trim() : "";
            if(!name) return;
            const tx = db.transaction('playlists', 'readwrite');
            const id = crypto.randomUUID();
            tx.objectStore('playlists').add({ id, name, items: [] });
            tx.oncomplete = () => {
                if(nameInput) nameInput.value = '';
                showToast(`Created playlist: ${name}`);
                loadPlaylistsUI();
            };
        };
    }

    const activeSelector = $('active-playlist-selector');
    if(activeSelector) {
        activeSelector.onchange = (e) => {
            activePlaylistView = e.target.value;
            currentConfig.activePlaylistId = activePlaylistView;
            chrome.storage.local.set({mediaConfig: currentConfig});
            currentPage = 1;
            allLibraryItems = []; 
            loadLibraryGrid();
        };
    }

    async function loadLibraryGrid() {
        if (!db) return;
        const grid = $('library-grid');
        if (!grid) return;
        grid.innerHTML = ''; 
        
        if (allLibraryItems.length === 0) {
             const getAllData = (name) => {
                return new Promise((resolve) => {
                    const tx = db.transaction(name, 'readonly');
                    const store = tx.objectStore(name);
                    const items = [];
                    const req = store.openCursor();
                    req.onsuccess = e => {
                        const cursor = e.target.result;
                        if(cursor) {
                            items.push({val: cursor.value, key: cursor.key});
                            cursor.continue();
                        } else {
                            resolve(items);
                        }
                    };
                    req.onerror = () => resolve([]);
                });
            };

            const [videos, photos] = await Promise.all([getAllData('videos'), getAllData('photos')]);
            let rawItems = [
                ...videos.map(v => ({...v, type: 'video', storeName: 'videos'})),
                ...photos.map(p => ({...p, type: 'photo', storeName: 'photos'}))
            ];

            if (activePlaylistView !== 'all') {
                const playlists = await getPlaylists();
                const pl = playlists.find(p => p.id === activePlaylistView);
                if (pl) {
                    const allowedKeys = new Set(pl.items.map(i => `${i.store}_${i.key}`));
                    rawItems = rawItems.filter(item => allowedKeys.has(`${item.storeName}_${item.key}`));
                }
            }
            allLibraryItems = rawItems;
        }

        const totalItems = allLibraryItems.length;
        if (totalItems === 0) {
            grid.innerHTML = '<div style="color:#555; padding:20px; grid-column: 1/-1; text-align:center;">No items found in this source.</div>';
            updatePaginationControls(0);
            return;
        }

        const startIdx = (currentPage - 1) * itemsPerPage;
        const endIdx = startIdx + itemsPerPage;
        const pageItems = allLibraryItems.slice(startIdx, endIdx);

        updatePaginationControls(totalItems);

        for (let i = 0; i < pageItems.length; i++) {
            const item = pageItems[i];
            const globalIndex = startIdx + i + 1; 
            await createGridItem(item.val, item.key, item.storeName, item.type, globalIndex);
        }
    }

    function updatePaginationControls(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        if (currentPage > totalPages && totalPages > 0) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        if($('lib-total-count')) $('lib-total-count').textContent = `${totalItems} Items`;
        if($('lib-page-display')) $('lib-page-display').textContent = `${currentPage}/${totalPages || 1}`;
        
        const prev = $('lib-prev');
        const next = $('lib-next');
        
        if(prev) {
            prev.disabled = currentPage <= 1;
            prev.style.opacity = currentPage <= 1 ? 0.5 : 1;
            prev.onclick = () => { if (currentPage > 1) { currentPage--; loadLibraryGrid(); }};
        }
        if(next) {
            next.disabled = currentPage >= totalPages;
            next.style.opacity = currentPage >= totalPages ? 0.5 : 1;
            next.onclick = () => { 
                const totalPages = Math.ceil(allLibraryItems.length / itemsPerPage);
                if (currentPage < totalPages) { currentPage++; loadLibraryGrid(); }
            };
        }
    }

    const perPageSelect = $('lib-per-page');
    if(perPageSelect) {
        perPageSelect.addEventListener('change', (e) => {
            itemsPerPage = parseInt(e.target.value);
            currentPage = 1;
            loadLibraryGrid();
        });
    }

    async function createGridItem(item, key, storeName, type, index) {
        const grid = $('library-grid');
        const card = document.createElement('div');
        card.className = 'media-card';
        
        let src = '', name = 'Unknown';
        let fileObj = null;
        try {
            if(item instanceof File) {
                fileObj = item;
                src = URL.createObjectURL(item);
                name = item.name;
            } else if (item.kind === 'file') {
                fileObj = await item.getFile();
                src = URL.createObjectURL(fileObj); 
                name = item.name; 
            }
        } catch(e) { card.style.opacity = 0.5; name = "⚠️ Permission Lost"; }

        if (currentConfig.overrides && currentConfig.overrides[name]) card.classList.add('has-override');

        const el = document.createElement('img');
        el.style.objectFit = 'cover';
        if (type === 'photo') el.src = src;
        else {
            el.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NCIgaGVpZ2h0PSI2NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzIyMiIvPjwvc3ZnPg==';
            if (fileObj) thumbQueue.add(fileObj, el);
            const vidIcon = document.createElement('div');
            vidIcon.textContent = '🎬';
            vidIcon.style.cssText = 'position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); font-size:2rem; text-shadow: 0 2px 5px rgba(0,0,0,0.8);';
            card.appendChild(vidIcon);
        }

        const badge = document.createElement('div');
        badge.className = 'item-index-badge';
        badge.textContent = `#${index}`;
        card.appendChild(badge);

        const title = document.createElement('div');
        title.textContent = name;
        title.style.cssText = 'position:absolute; bottom:0; left:0; width:100%; padding:5px; background:linear-gradient(transparent, rgba(0,0,0,0.9)); color:white; font-size:0.7rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;';

        const delBtn = document.createElement('button');
        delBtn.innerHTML = '×';
        delBtn.style.cssText = 'position:absolute; top:5px; right:5px; background:rgba(255,0,0,0.7); color:white; border:none; border-radius:50%; width:24px; height:24px; cursor:pointer; display:none; align-items:center; justify-content:center; font-weight:bold; z-index:10;';
        delBtn.onclick = (e) => {
            e.stopPropagation();
            if(confirm(`Delete ${name}?`)) {
                const tx = db.transaction(storeName, 'readwrite');
                tx.objectStore(storeName).delete(key);
                tx.oncomplete = () => { card.remove(); showToast('Deleted item'); allLibraryItems = []; loadLibraryGrid(); };
            }
        };
        
        card.onmouseover = () => delBtn.style.display = 'flex';
        card.onmouseout = () => delBtn.style.display = 'none';

        card.appendChild(el); card.appendChild(title); card.appendChild(delBtn);
        card.onclick = () => openModal(name, src, type, key, storeName);
        grid.appendChild(card);
    }

    const modal = $('file-modal');
    function openModal(fileName, src, type, key, storeName) {
        editingFile = { fileName, key, storeName };
        if($('modal-title')) $('modal-title').textContent = fileName;
        const previewBox = $('modal-preview-box');
        if(previewBox) {
            previewBox.innerHTML = '';
            const el = type === 'video' ? document.createElement('video') : document.createElement('img');
            el.src = src; el.controls = true; 
            previewBox.appendChild(el);
        }

        const overrides = currentConfig.overrides?.[fileName] || {};
        if($('modal-volume')) $('modal-volume').value = overrides.volume !== undefined ? overrides.volume : -1;
        if($('modal-scaling')) $('modal-scaling').value = overrides.scaling || 'default';
        if($('modal-playlist-select')) $('modal-playlist-select').value = "";
        
        if(modal) modal.style.display = 'flex';
    }

    function closeModal() {
        if(modal) modal.style.display = 'none';
        if($('modal-preview-box')) $('modal-preview-box').innerHTML = ''; 
    }

    if($('modal-save')) {
        $('modal-save').onclick = async () => {
            if (!currentConfig.overrides) currentConfig.overrides = {};
            const vol = parseFloat($('modal-volume').value);
            const scale = $('modal-scaling').value;
            
            if (vol === -1 && scale === 'default') delete currentConfig.overrides[editingFile.fileName];
            else currentConfig.overrides[editingFile.fileName] = {
                volume: vol === -1 ? undefined : vol,
                scaling: scale === 'default' ? undefined : scale
            };

            const playlistId = $('modal-playlist-select') ? $('modal-playlist-select').value : null;
            if(playlistId && db) {
                const tx = db.transaction('playlists', 'readwrite');
                const store = tx.objectStore('playlists');
                const p = await new Promise(res => { 
                    store.get(playlistId).onsuccess = e => res(e.target.result); 
                });
                
                if(p) {
                    const exists = p.items.some(i => i.key === editingFile.key && i.store === editingFile.storeName);
                    if(!exists) {
                        p.items.push({ store: editingFile.storeName, key: editingFile.key });
                        store.put(p);
                        showToast(`Added to ${p.name}`);
                    }
                }
            }
            await saveAll();
            closeModal();
            allLibraryItems = []; 
            loadLibraryGrid();
        };
    }

    if($('modal-delete')) {
        $('modal-delete').onclick = async () => {
            if(!confirm("Remove this file from library?")) return;
            const tx = db.transaction(editingFile.storeName, 'readwrite');
            tx.objectStore(editingFile.storeName).delete(editingFile.key);
            tx.oncomplete = () => { closeModal(); allLibraryItems = []; loadLibraryGrid(); };
        };
    }
    if($('modal-cancel')) $('modal-cancel').onclick = closeModal;

    async function saveAll() {
        const get = (id, type) => {
            const el = $(id);
            if (!el) return undefined;
            if(type === 'check') return el.checked;
            if(type === 'float') return parseFloat(el.value);
            if(type === 'array') return el.value.split('\n').map(l => l.trim()).filter(Boolean);
            return type === 'int' ? parseInt(el.value) : el.value;
        };

        const newConfig = {
            ...currentConfig,
            useLocal: get('use-local', 'check'),
            usePhotos: get('use-photos', 'check'),
            urls: get('urls', 'array'),
            
            layout: get('layout'),
            scaling: get('scaling'),
            gridCols: get('grid-cols', 'int'),
            gridRows: get('grid-rows', 'int'),
            carouselRadius: get('carousel-radius', 'int'),
            carouselTilt: get('carousel-tilt', 'int'),
            carouselSpeed: get('carousel-speed', 'int'),
            reflectOpacity: get('reflect-opacity', 'int'),
            reflectOffset: get('reflect-offset', 'int'),
            
            // bokehEnable REMOVED - Controlled by individual switches now
            
            brightness: get('brightness', 'int'),
            contrast: get('contrast', 'int'),
            saturate: get('saturate', 'int'),
            sepia: get('sepia', 'int'),
            grayscale: get('grayscale', 'int'),
            
            ambiScale: get('ambi-scale', 'float'),
            ambiOpacity: get('ambi-opacity', 'float'),
            ambiBlur: get('ambi-blur', 'int'),
            ambiMode: get('ambi-mode'),
            borderColor: get('border-color'),
            borderGlow: get('border-glow', 'int'),
            borderSize: get('border-size', 'int'),

            neonBorder: get('neon-border', 'check'),
            neonPattern: get('neon-pattern'),
            neonSegments: get('neon-segments', 'int'),
            neonSpeed: get('neon-speed', 'float'),
            neonAudio: get('neon-audio', 'check'),
            neonStrobe: get('neon-strobe', 'float'),
            neonSensitivity: get('neon-sensitivity', 'float'),
            neonWidth: get('neon-width', 'int'),
            neonUseAccent: get('neon-use-accent', 'check'),
            neonColor: get('neon-color'),
            
            volume: get('volume', 'float'),
            photoDuration: get('photo-duration', 'int'),
            shuffle: get('shuffle', 'check'),
            kenburns: get('kenburns', 'check'),
            
            pos: get('clock-pos'),
            clockSize: get('clock-size', 'int'),
            font: get('font-family'),
            showDate: get('show-date', 'check'),
            format12h: get('format-12h', 'check'),
            showSeconds: get('show-seconds', 'check'),
            
            accentColor: get('accent-color'),
            activePlaylistId: activePlaylistView
        };
        
        // Dynamic FX Saving
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            const checkId = `fx-${type}`;
            if($(checkId)) newConfig[camelCase(checkId)] = $(checkId).checked;
            
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                if($(id)) newConfig[camelCase(id)] = parseInt($(id).value);
            });
        });

        await chrome.storage.local.set({mediaConfig: newConfig});
        currentConfig = newConfig;
        applyTheme(newConfig.accentColor);
        showToast('System Configuration Saved');
    }
    
    if($('save-all-btn')) $('save-all-btn').onclick = saveAll;

    if($('export-btn')) $('export-btn').onclick = () => {
        const blob = new Blob([JSON.stringify(currentConfig, null, 2)], {type: 'application/json'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'fafo-media-config.json'; a.click();
    };
    if($('import-btn')) $('import-btn').onclick = () => $('import-file').click();
    if($('import-file')) $('import-file').onchange = e => {
        const r = new FileReader();
        r.onload = async (evt) => {
            try { 
                await chrome.storage.local.set({mediaConfig: JSON.parse(evt.target.result)}); 
                showToast('Config Loaded! Reloading...'); setTimeout(() => location.reload(), 1000);
            } catch(err) { showToast('Invalid Config File', 'error'); }
        };
        r.readAsText(e.target.files[0]);
    };
    
    async function addFolder(storeName, regex, btnId) {
        if (!db) { showToast("Database Not Ready", "error"); return; }
        const btn = $(btnId); const originalText = btn.textContent;
        try {
            const dirHandle = await showDirectoryPicker({mode: 'read'});
            btn.textContent = 'Scanning...'; btn.disabled = true; btn.style.opacity = 0.5;
            const handles = [];
            async function scan(dir) {
                for await (const entry of dir.values()) {
                    if (entry.kind === 'file' && regex.test(entry.name)) handles.push(entry);
                    else if (entry.kind === 'directory') await scan(entry);
                }
            }
            await scan(dirHandle);
            if (handles.length === 0) { showToast('No files found', 'error'); btn.textContent = originalText; btn.disabled = false; btn.style.opacity = 1; return; }
            const tx = db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            let added = 0;
            handles.forEach(h => { store.put(h, crypto.randomUUID()); added++; });
            tx.oncomplete = () => { showToast(`Added ${added} files`); allLibraryItems = []; loadLibraryGrid(); btn.textContent = originalText; btn.disabled = false; btn.style.opacity = 1; };
        } catch(e) { console.log(e); btn.textContent = originalText; btn.disabled = false; btn.style.opacity = 1; }
    }

    if($('add-vid-btn')) $('add-vid-btn').onclick = () => addFolder('videos', /\.(mp4|webm|mkv|mov|avi)$/i, 'add-vid-btn');
    if($('add-img-btn')) $('add-img-btn').onclick = () => addFolder('photos', /\.(jpg|jpeg|png|webp|gif|bmp)$/i, 'add-img-btn');
    if($('refresh-lib')) $('refresh-lib').onclick = () => { showToast('Refreshing Library...'); allLibraryItems = []; loadLibraryGrid(); };
    if($('wipe-db')) $('wipe-db').onclick = async () => {
        if (!db) return;
        if(confirm("⚠️ WIPE LIBRARY?")) {
            const tx = db.transaction(['videos', 'photos', 'playlists'], 'readwrite');
            tx.objectStore('videos').clear(); tx.objectStore('photos').clear(); tx.objectStore('playlists').clear();
            tx.oncomplete = () => { showToast('Library Wiped', 'error'); allLibraryItems = []; loadLibraryGrid(); loadPlaylistsUI(); };
        }
    };

    loadSettings();
});