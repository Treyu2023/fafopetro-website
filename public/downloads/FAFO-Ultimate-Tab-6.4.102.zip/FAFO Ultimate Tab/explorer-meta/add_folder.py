"""CLI: register a video folder with the running FAFO metadata server.

  python add_folder.py --pick          # mini Explorer window (subfolders included)
  python add_folder.py "D:\\MyClips"   # explicit path still works
"""
from __future__ import annotations

import json
import sys
import urllib.error
import urllib.request

API = "http://127.0.0.1:8765/api"


def _post(route: str, payload: dict | None = None, timeout: int = 180) -> dict:
    data = json.dumps(payload or {}).encode("utf-8")
    req = urllib.request.Request(
        f"{API}{route}",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def main() -> int:
    arg = sys.argv[1].strip().strip('"') if len(sys.argv) > 1 else "--pick"
    pick = arg.lower() in {"--pick", "-p", "/pick", ""}
    try:
        if pick:
            print("Opening folder picker… (all subfolders will be included)")
            print("Look for the Windows dialog — it may be behind other windows.")
            body = _post("/library/pick-folder", {}, timeout=300)
            if body.get("cancelled"):
                print("Cancelled — no folder added.")
                return 1
        else:
            body = _post("/library/add-folder", {"path": arg}, timeout=180)
    except urllib.error.URLError as e:
        print("ERROR: Could not reach the metadata server.")
        print("  Start it first:  START_META_SERVER.bat")
        print("  Detail:", e)
        return 1
    except Exception as e:
        print("ERROR:", e)
        return 1

    print(json.dumps(body, indent=2))
    if not body.get("ok"):
        return 1
    path = body.get("path") or ""
    n = body.get("files_indexed")
    dropped = body.get("dropped_children") or []
    print()
    print(f"Watching: {path}")
    print(f"Indexed {n} file(s) — this folder and every subfolder.")
    if body.get("already_covered"):
        print("Already covered by a parent watch folder (rolled up).")
    if dropped:
        print(f"Rolled up {len(dropped)} nested watch folder(s) into this parent.")
    print("FAFO can now write Explorer tags/ratings for files inside it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
