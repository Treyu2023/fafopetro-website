/**
 * FAFO Local Media — force correct video fit & center (browser page zoom safe — no 100vw)
 *
 * script.js applyCinemaObjectFit still writes absolute left/top/px sizes.
 * This module continuously strips those and applies real layout:
 *   #scene-root = available rectangle (shrinks when Tags panels open)
 *   #bg-video   = max 100% of that box, object-fit contain, flex-centered
 */
(function () {
  'use strict';

  let timer = null;
  let styleEl = null;
  let lastWallInsetKey = '';

  function ensureCss() {
    if (styleEl && document.contains(styleEl)) return;
    styleEl = document.getElementById('fafo-scale-fix-css');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'fafo-scale-fix-css';
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = `
      :root {
        --safe-left: 0px;
        --safe-right: 0px;
        --safe-top: 0px;
        --safe-bottom: 0px;
      }

      /* Media stage = remaining free rectangle (includes breathing-room padding) */
      #scene-root.layout-cinema,
      #scene-root:not(.layout-grid):not(.layout-carousel):not(.layout-collage) {
        position: fixed !important;
        top: var(--safe-top) !important;
        right: var(--safe-right) !important;
        bottom: var(--safe-bottom) !important;
        left: var(--safe-left) !important;
        width: auto !important;
        height: auto !important;
        margin: 0 !important;
        display: flex !important;
        /* Top-center: hang from top of the padded stage, stay centered horizontally */
        align-items: flex-start !important;
        justify-content: center !important;
        overflow: hidden !important;
        box-sizing: border-box !important;
        /* Above chrome-art (art is z 0–1). Do NOT use z-index:1 or art covers the video. */
        z-index: 6 !important;
        background: transparent !important;
      }

      /* When chrome art is active, keep video stage solid black under pixels only */
      body.fafo-chrome-art .cinema-stage {
        background: #000 !important;
        opacity: 1 !important;
        z-index: 3 !important;
      }
      body.fafo-chrome-art .cinema-stage #bg-video,
      body.fafo-chrome-art .cinema-stage > video,
      body.fafo-chrome-art .cinema-stage > img.is-photo {
        opacity: 1 !important;
        background: #000 !important;
      }

      /*
       * Only style #bg-video when there is NO cinema-stage.
       * Cinema stage + script.js own zoom (--video-zoom / transform:scale).
       * Fighting those rules made the slider snap back on release.
       */
      #scene-root:not(:has(.cinema-stage)) #bg-video,
      body:not(:has(.cinema-stage)) #bg-video {
        position: relative !important;
        inset: auto !important;
        left: auto !important;
        top: auto !important;
        right: auto !important;
        bottom: auto !important;
        margin: 0 auto !important;
        width: auto !important;
        height: auto !important;
        max-width: 100% !important;
        max-height: 100% !important;
        object-fit: contain !important;
        object-position: center top !important;
        transform: scale(var(--video-zoom, 1)) !important;
        transform-origin: center top !important;
        display: block !important;
        flex: 0 1 auto !important;
      }

      /* Reinforce sticky zoom when cinema stage is present */
      .cinema-stage #bg-video,
      .cinema-stage > video,
      .cinema-stage > img.is-photo {
        transform: scale(var(--video-zoom, 1)) !important;
        transform-origin: center top !important;
      }

      /* Ambience full-screen behind the main stage (not over chrome art when art is on) */
      #scene-root .ambience,
      .ambience {
        position: fixed !important;
        inset: 0 !important;
        width: 100% !important;
        height: 100% !important;
        max-width: none !important;
        max-height: none !important;
        object-fit: cover !important;
        transform: none !important;
        left: 0 !important;
        top: 0 !important;
        margin: 0 !important;
        z-index: 0 !important;
        pointer-events: none !important;
      }
      body.fafo-chrome-art #scene-root .ambience,
      body.fafo-chrome-art .ambience {
        /* Soft only — art is the visible backdrop; video stage is the focus */
        opacity: 0.2 !important;
      }
    `;
  }

  function panelOpen(el) {
    if (!el) return false;
    if (el.classList.contains('collapsed') || el.classList.contains('hidden')) return false;
    if (el.getAttribute('aria-hidden') === 'true') return false;
    const r = el.getBoundingClientRect();
    return r.width >= 60 && r.height >= 60;
  }

  function measureInsets() {
    const ww = window.innerWidth || 1920;
    let left = 0;
    let right = 0;

    const panels = [
      document.getElementById('meta-panel'),
      document.getElementById('meta-library-panel'),
    ];

    for (const el of panels) {
      if (!panelOpen(el)) continue;
      const r = el.getBoundingClientRect();
      // Right side
      if (r.left > ww * 0.28) {
        right = Math.max(right, Math.round(ww - r.left) + 12);
      }
      // Left side
      else if (r.right < ww * 0.72) {
        left = Math.max(left, Math.round(r.right) + 12);
      }
      // Free-float covering a side
      else {
        if (r.left < ww * 0.22) left = Math.max(left, Math.round(r.right) + 12);
        if (r.right > ww * 0.78) right = Math.max(right, Math.round(ww - r.left) + 12);
      }
    }

    // Keep at least 320px of stage width
    const maxL = Math.max(0, ww - 320 - right);
    const maxR = Math.max(0, ww - 320 - left);
    left = Math.min(left, maxL);
    right = Math.min(right, maxR);

    // Breathing room so the picture doesn’t feel flush/cut against the window edge
    const wh = window.innerHeight || 1080;
    const padTop = Math.round(Math.max(28, wh * 0.032));
    const padX = Math.round(Math.max(18, ww * 0.022));
    const padBottom = Math.round(Math.max(20, wh * 0.024));

    return {
      left: left + padX,
      right: right + padX,
      top: padTop,
      bottom: padBottom,
    };
  }

  function stripInline(video) {
    if (!video) return;
    // Layout only — preserve live zoom transform / origin from script.js
    const keepTransform = video.style.getPropertyValue('transform');
    const keepOrigin = video.style.getPropertyValue('transform-origin');
    video.style.removeProperty('width');
    video.style.removeProperty('height');
    video.style.removeProperty('max-width');
    video.style.removeProperty('max-height');
    video.style.removeProperty('left');
    video.style.removeProperty('top');
    video.style.removeProperty('right');
    video.style.removeProperty('bottom');
    video.style.removeProperty('inset');
    video.style.removeProperty('margin');
    video.style.removeProperty('object-fit');
    video.style.removeProperty('position');
    if (keepTransform) video.style.setProperty('transform', keepTransform, 'important');
    if (keepOrigin) video.style.setProperty('transform-origin', keepOrigin || 'center top', 'important');
  }

  function killOldPlaceHandlers(video) {
    // script.js stores place() on the element and listens to resize/loadedmetadata
    if (video && typeof video._fafoPlaceCapped === 'function') {
      try {
        video.removeEventListener('loadedmetadata', video._fafoPlaceCapped);
        window.removeEventListener('resize', video._fafoPlaceCapped);
      } catch (_) {}
      // Replace with a no-op so future calls do nothing harmful
      video._fafoPlaceCapped = function () {};
      video._fafoCappedBound = true;
    }
  }

  function apply() {
    ensureCss();
    const insets = measureInsets();
    const root = document.documentElement;
    root.style.setProperty('--safe-left', insets.left + 'px');
    root.style.setProperty('--safe-right', insets.right + 'px');
    root.style.setProperty('--safe-top', insets.top + 'px');
    root.style.setProperty('--safe-bottom', insets.bottom + 'px');

    // Wall mode: reflow tiles into free content box (not under Tags/HUD)
    if (document.body.classList.contains('fafo-wall-mode')) {
      const key = [insets.left, insets.right, insets.top, insets.bottom].join('|');
      if (key !== lastWallInsetKey) {
        lastWallInsetKey = key;
        try {
          if (typeof window.FAFOPlayer?.reflowWallLayout === 'function') {
            window.FAFOPlayer.reflowWallLayout({ skipRebuild: true });
          }
        } catch (_) { /* ignore */ }
      }
      return;
    }

    // Cinema stage owns layout + live zoom + padding; don't fight it
    const stage = document.querySelector('.cinema-stage');    if (stage) {
      // Still publish safe insets for any CSS that reads them
      return;
    }

    const video = document.getElementById('bg-video');
    if (video) {
      killOldPlaceHandlers(video);
      stripInline(video);
    }
  }

  function schedule() {
    clearTimeout(timer);
    timer = setTimeout(apply, 40);
  }

  function boot() {
    ensureCss();
    apply();

    window.addEventListener('resize', schedule);
    window.addEventListener('fafo-dock-change', schedule);

    // Watch scene for new video nodes
    const scene = document.getElementById('scene-root');
    if (scene) {
      try {
        new MutationObserver(() => {
          schedule();
          const v = document.getElementById('bg-video');
          if (v) {
            killOldPlaceHandlers(v);
            v.addEventListener('loadedmetadata', schedule);
            v.addEventListener('loadeddata', schedule);
            v.addEventListener('play', schedule);
          }
        }).observe(scene, { childList: true, subtree: true });
      } catch (_) {}
    }

    // Watch Tags dock open/close/move
    const dock = document.getElementById('meta-dock');
    if (dock) {
      try {
        new MutationObserver(schedule).observe(dock, {
          attributes: true,
          attributeFilter: ['class', 'style', 'data-dock'],
          childList: true,
          subtree: true,
        });
      } catch (_) {}
    }

    // Beat script.js: it re-applies layout on play / metadata — we re-strip after
    setInterval(apply, 400);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(boot, 200));
  } else {
    setTimeout(boot, 200);
  }

  window.FAFOScaleFix = { refresh: schedule, apply };
})();
