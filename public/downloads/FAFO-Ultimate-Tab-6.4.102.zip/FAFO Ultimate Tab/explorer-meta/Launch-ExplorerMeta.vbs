Option Explicit
Dim sh, fso, here, ps1, cmd, i, extra
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
here = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = here & "\Launch-ExplorerMeta.ps1"
extra = ""
For i = 0 To WScript.Arguments.Count - 1
  extra = extra & " " & Chr(34) & WScript.Arguments(i) & Chr(34)
Next
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """" & extra
sh.Run cmd, 0, False
WScript.Quit 0
