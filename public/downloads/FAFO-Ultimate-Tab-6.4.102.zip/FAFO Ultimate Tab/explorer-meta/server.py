"""
FAFO Explorer Metadata Server
-----------------------------
Lightweight local companion for FAFO Ultimate Tab.

Listens on http://127.0.0.1:8765 and writes real Windows file metadata
(System.Keywords tags + System.Rating stars) so File Explorer and other
apps can see ratings/tags set while videos play.

Compatible API subset used by FAFO:
  GET  /api/health
  GET  /api/media?search=&limit=   (Toolbox-compatible catalog search)
  GET  /api/tags                  (Toolbox-compatible tag vocabulary)
  POST /api/fs/write-metadata
  POST /api/fs/write-metadata-batch   (bulk Explorer push for many files)
  GET  /api/fs/read-metadata
  POST /api/library/add-folder
  POST /api/library/pick-folder     (mini Explorer window; subfolders rolled up)
  POST /api/library/remove-folder
  GET  /api/library
  POST /api/library/rescan
  POST /api/library/export-tags   (bulk disk Tags/Rating for FAFO rebuild recovery)

Runs on 127.0.0.1:8765. AI HTML TOOLBOX uses 127.0.0.87:18765 — both can run at once.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any

# Ensure local imports work when launched from any CWD
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from fastapi import Body, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

from file_metadata import (
    write_file_metadata,
    read_file_metadata,
    normalize_tags,
    is_junk_tag,
)

HOST = "127.0.0.1"
PORT = 8765
CONFIG_PATH = ROOT / "config.json"
INDEX_PATH = ROOT / "library_index.json"
TAGS_CACHE_PATH = ROOT / "tags_cache.json"

VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".webm", ".avi", ".wmv", ".ts"}
SKIP_DIRS = {"$recycle.bin", "system volume information", ".git", "node_modules", "__pycache__"}

# FAFO polls these constantly — hide successful responses so the console doesn't scroll forever.
# Errors (4xx/5xx) and write/rescan traffic still print.
_QUIET_OK_PATHS = (
    "/api/health",
    "/api/media",
    "/api/tags",
    "/api/library",
    "/openapi.json",
    "/docs",
    "/favicon.ico",
)


class _QuietPollFilter(logging.Filter):
    """Drop uvicorn access lines for noisy successful polls."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            msg = record.getMessage()
        except Exception:
            return True
        # Typical: '127.0.0.1:1234 - "GET /api/health HTTP/1.1" 200 OK'
        is_ok = '" 200' in msg or msg.rstrip().endswith(" 200") or " 200 OK" in msg
        if not is_ok:
            return True  # always show errors / non-200
        for path in _QUIET_OK_PATHS:
            # match path as request target, not as random substring of a longer route
            if f" {path} " in msg or f" {path}?" in msg or f'"{path} ' in msg or f'"{path}?' in msg:
                return False
            if f" {path} HTTP" in msg or f'"{path} HTTP' in msg:
                return False
        return True


def _install_quiet_access_logs() -> None:
    filt = _QuietPollFilter()
    for name in ("uvicorn.access", "uvicorn.asgi"):
        logging.getLogger(name).addFilter(filt)


app = FastAPI(title="FAFO Explorer Metadata Server", version="1.2.7")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

_lock = threading.Lock()
_index: dict[str, list[dict[str, Any]]] = {}  # name_lower -> [{path, size, mtime, name}]
_config: dict[str, Any] = {"watched_dirs": [], "version": 1}
_indexing = False
_pick_lock = threading.Lock()
# lower(tag) -> display form; filled by write-metadata + optional reads
_tag_vocab: dict[str, str] = {}
# Deferred Explorer shell writes when Chrome has the file open
_pending_shell: dict[str, dict[str, Any]] = {}  # path -> {tags, rating, tries}
_pending_shell_thread: threading.Thread | None = None
_last_demand_write = 0.0


def _note_s2_demand(app: str = "fafo-local-media") -> None:
    """Tell the toolbox watchdog FAFO is using S2 so it starts/keeps this server."""
    global _last_demand_write
    now = time.time()
    if now - _last_demand_write < 15:
        return
    _last_demand_write = now
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local"))
        path = base / "FAFO" / "demand-s2.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"at": now, "app": app, "which": "s2"}, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError:
        pass


@app.middleware("http")
async def _demand_on_real_traffic(request, call_next):
    """Any real FAFO API call (not watchdog health) keeps S2 awake."""
    path = request.url.path or ""
    if "/health" not in path and path not in ("/docs", "/redoc", "/openapi.json"):
        _note_s2_demand()
    return await call_next(request)


def load_config() -> dict[str, Any]:
    global _config
    if CONFIG_PATH.exists():
        try:
            _config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            _config = {"watched_dirs": [], "version": 1}
    else:
        _config = {"watched_dirs": [], "version": 1}
    _config.setdefault("watched_dirs", [])
    return _config


def save_config() -> None:
    CONFIG_PATH.write_text(json.dumps(_config, indent=2), encoding="utf-8")


def load_index() -> None:
    global _index
    if INDEX_PATH.exists():
        try:
            data = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
            _index = data.get("by_name") or {}
            return
        except Exception:
            pass
    _index = {}


def save_index() -> None:
    INDEX_PATH.write_text(
        json.dumps({"by_name": _index, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )


def load_tag_vocab() -> None:
    global _tag_vocab
    if TAGS_CACHE_PATH.exists():
        try:
            raw = TAGS_CACHE_PATH.read_text(encoding="utf-8-sig")
            data = json.loads(raw)
            tags = data.get("tags") or []
            _tag_vocab = {}
            dirty = False
            for t in tags:
                s = str(t).strip()
                if not s or is_junk_tag(s):
                    dirty = True
                    continue
                for part in normalize_tags([s]):
                    _tag_vocab[part.lower()] = part
            # Rewrite cache if we dropped junk so pollution does not re-seed the UI
            if dirty or len(_tag_vocab) != len(tags):
                try:
                    save_tag_vocab()
                except Exception:
                    pass
            return
        except Exception:
            pass
    _tag_vocab = {}


def save_tag_vocab() -> None:
    tags = sorted(
        (t for t in _tag_vocab.values() if t and not is_junk_tag(t)),
        key=str.lower,
    )
    TAGS_CACHE_PATH.write_text(
        json.dumps({"tags": tags, "updated": time.time()}, indent=2),
        encoding="utf-8",
    )


def remember_tags(tags: list[str] | None) -> None:
    if not tags:
        return
    changed = False
    with _lock:
        for t in normalize_tags(tags):
            if is_junk_tag(t):
                continue
            low = t.lower()
            if low not in _tag_vocab:
                _tag_vocab[low] = t
                changed = True
    if changed:
        try:
            save_tag_vocab()
        except Exception:
            pass


def all_entries() -> list[dict[str, Any]]:
    with _lock:
        out: list[dict[str, Any]] = []
        for bucket in _index.values():
            out.extend(bucket)
        return out


def search_index(search: str, limit: int = 80) -> tuple[list[dict[str, Any]], int]:
    """
    Fast in-memory search over the indexed name map.
    ~3k files is trivial; no disk walk on each request.
    Returns (page_items, total_matches).
    """
    limit = max(1, min(int(limit or 80), 500))
    q = (search or "").strip().lower()
    entries = all_entries()
    if not q:
        # Newest-ish first when no query
        entries = sorted(entries, key=lambda e: float(e.get("mtime") or 0), reverse=True)
        return entries[:limit], len(entries)

    # Rank: exact name > startswith > contains (name or path)
    exact: list[dict[str, Any]] = []
    starts: list[dict[str, Any]] = []
    contains: list[dict[str, Any]] = []
    for e in entries:
        name = str(e.get("name") or "")
        path = str(e.get("path") or "")
        nl = name.lower()
        pl = path.lower()
        if nl == q or nl == q + ".mp4":
            exact.append(e)
        elif nl.startswith(q) or Path(nl).stem.startswith(q.rstrip(".mp4")):
            starts.append(e)
        elif q in nl or q in pl:
            contains.append(e)

    ranked = exact + starts + contains
    # De-dupe by path while preserving order
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for e in ranked:
        p = str(e.get("path") or "")
        if not p or p in seen:
            continue
        seen.add(p)
        out.append(e)
    return out[:limit], len(out)


def entry_to_media_item(e: dict[str, Any], *, read_tags: bool = False) -> dict[str, Any]:
    """Shape compatible with FAFO / Toolbox media query consumers."""
    name = e.get("name") or Path(str(e.get("path") or "")).name
    item: dict[str, Any] = {
        "id": str(e.get("path") or name),
        "name": name,
        "path": e.get("path"),
        "size": e.get("size"),
        "mtime": e.get("mtime"),
        "type": "video",
        "tags": [],
        "rank": 0,
    }
    if read_tags and e.get("path"):
        try:
            meta = read_file_metadata(e["path"])
            item["tags"] = meta.get("tags") or []
            item["rank"] = int(meta.get("rating") or 0)
            remember_tags(item["tags"])
        except Exception:
            pass
    return item


def scan_dir(root: Path, into: dict[str, list[dict[str, Any]]] | None = None) -> int:
    """Index video files under root. Returns count added/updated."""
    target = into if into is not None else _index
    count = 0
    root = root.resolve()
    if not root.is_dir():
        return 0

    for dirpath, dirnames, filenames in os.walk(root):
        # prune junk
        dirnames[:] = [
            d for d in dirnames
            if d.lower() not in SKIP_DIRS and not d.startswith(".")
        ]
        for name in filenames:
            ext = Path(name).suffix.lower()
            if ext not in VIDEO_EXTS:
                continue
            full = Path(dirpath) / name
            try:
                st = full.stat()
            except OSError:
                continue
            entry = {
                "path": str(full),
                "name": name,
                "size": st.st_size,
                "mtime": st.st_mtime,
            }
            key = name.lower()
            if into is None:
                with _lock:
                    bucket = target.setdefault(key, [])
                    bucket = [e for e in bucket if e.get("path") != entry["path"]]
                    bucket.append(entry)
                    target[key] = bucket
            else:
                bucket = target.setdefault(key, [])
                bucket = [e for e in bucket if e.get("path") != entry["path"]]
                bucket.append(entry)
                target[key] = bucket
            count += 1
    return count


def rebuild_index() -> int:
    """Rebuild a fresh index, then swap it in so live writes keep working."""
    global _index
    built: dict[str, list[dict[str, Any]]] = {}
    total = 0
    for d in list(_config.get("watched_dirs") or []):
        total += scan_dir(Path(d), into=built)
    # Bundled/default Videos/ is intentionally NOT auto-indexed.
    # Add folders via Options / ADD_VIDEO_FOLDER / POST /api/library/add-folder only.
    with _lock:
        _index = built
    save_index()
    return total


def find_by_identity(
    name: str | None,
    size: int | None,
    mtime: float | None,
    path: str | None = None,
) -> Path | None:
    if path:
        p = Path(path)
        if p.is_file():
            return p

    if not name:
        return None

    key = name.lower()
    with _lock:
        candidates = list(_index.get(key) or [])

    # Partial / truncated filename (common when logs/UI cut long names)
    if not candidates:
        hits, _total = search_index(name, limit=20)
        candidates = hits

    if not candidates:
        # last resort: live rglob only for exact basename (avoid walking 3k on every miss)
        base = Path(name).name
        for d in list(_config.get("watched_dirs") or []):
            root = Path(d)
            if not root.is_dir():
                continue
            try:
                for hit in root.rglob(base):
                    if hit.is_file():
                        candidates.append({
                            "path": str(hit),
                            "name": hit.name,
                            "size": hit.stat().st_size,
                            "mtime": hit.stat().st_mtime,
                        })
                        break
            except OSError:
                continue
            if candidates:
                break

    if not candidates:
        discovered = _discover_unwatched_file(name)
        if discovered:
            try:
                st = discovered.stat()
                candidates = [{
                    "path": str(discovered),
                    "name": discovered.name,
                    "size": st.st_size,
                    "mtime": st.st_mtime,
                }]
            except OSError:
                candidates = []

    if not candidates:
        return None

    if size is not None:
        sized = [c for c in candidates if int(c.get("size") or 0) == int(size)]
        if sized:
            candidates = sized

    if mtime is not None and len(candidates) > 1:
        mt = float(mtime)
        if mt > 1e12:
            mt = mt / 1000.0
        candidates = sorted(candidates, key=lambda c: abs(float(c.get("mtime") or 0) - mt))

    p = Path(candidates[0]["path"])
    return p if p.is_file() else None


class FileMetaWrite(BaseModel):
    path: str | None = None
    name: str | None = None
    size: int | None = None
    mtime: float | None = None
    tags: list[str] | None = None
    rating: int | None = None
    update_catalog: bool = True
    # Optional client key so bulk results map back to chrome.storage entries
    client_key: str | None = None


class FileMetaWriteBatch(BaseModel):
    items: list[FileMetaWrite] = Field(default_factory=list)
    stop_on_error: bool = False


class AddFolder(BaseModel):
    path: str = Field(..., description="Absolute folder path to index for metadata writes")
    # Recursive is always on — picking a folder rolls in every subfolder.


def _path_key(p: Path | str) -> str:
    try:
        return str(Path(p).resolve()).rstrip("\\/").lower()
    except OSError:
        return str(p).rstrip("\\/").lower()


def _is_under(child: Path, parent: Path) -> bool:
    try:
        c = child.resolve()
        p = parent.resolve()
        c.relative_to(p)
        return c != p
    except (ValueError, OSError):
        return False


def rollup_watched_dirs(dirs: list[str], incoming: str) -> tuple[list[str], list[str], bool]:
    """Keep parents only. Adding a root drops children already covered.

    Returns (watched_list, dropped_children, already_covered_by_parent).
    """
    new_p = Path(incoming).resolve()
    dropped: list[str] = []
    kept: list[str] = []
    already_in = False
    under_parent = False
    for d in dirs:
        try:
            cur = Path(d).resolve()
        except OSError:
            kept.append(str(d))
            continue
        if cur == new_p:
            already_in = True
            kept.append(str(cur))
            continue
        if _is_under(cur, new_p):
            dropped.append(str(cur))
            continue
        if _is_under(new_p, cur):
            under_parent = True
            kept.append(str(cur))
            continue
        kept.append(str(cur))
    if not already_in and not under_parent:
        kept.append(str(new_p))
    out: list[str] = []
    seen: set[str] = set()
    for x in kept:
        k = x.rstrip("\\/").lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(x)
    return out, dropped, under_parent


def _default_picker_start() -> str:
    for cand in (
        Path(r"D:\OUTPUTS\__X_GROK"),
        Path(r"D:\OUTPUTS"),
        Path.home() / "Videos",
        Path.home(),
    ):
        try:
            if cand.is_dir():
                return str(cand)
        except OSError:
            continue
    return str(Path.home())


def pick_directory(
    title: str = "FAFO — pick a folder (all subfolders included)",
) -> str:
    """Open a mini Explorer folder window. Empty string if cancelled."""
    script = ROOT / "pick_folder.ps1"
    if not script.is_file():
        raise HTTPException(
            500,
            "pick_folder.ps1 missing next to the companion — re-run Launch-ExplorerMeta.bat",
        )
    start = _default_picker_start()
    hosts = [
        os.path.expandvars(r"%ProgramFiles%\PowerShell\7\pwsh.exe"),
        os.path.expandvars(r"%ProgramFiles%\PowerShell\7-preview\pwsh.exe"),
        "pwsh",
        os.path.expandvars(r"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"),
    ]
    exe = None
    for h in hosts:
        if Path(h).is_file() or (not os.path.splitext(h)[1] and shutil.which(h)):
            exe = h if Path(h).is_file() else (shutil.which(h) or h)
            break
        which = shutil.which(h)
        if which:
            exe = which
            break
    if not exe:
        exe = os.path.expandvars(r"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe")
    cmd = [
        exe,
        "-STA",
        "-NoProfile",
        "-WindowStyle",
        "Hidden",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(script),
        "-Title",
        title,
        "-StartPath",
        start,
    ]
    try:
        r = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=300,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        out = (r.stdout or "").strip().strip('"')
        if not out:
            return ""
        p = Path(out)
        if p.is_dir():
            return str(p)
        err = ((r.stderr or "") + "\n" + out).strip()[:300]
        raise HTTPException(500, f"Folder picker failed: {err}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Folder picker failed: {e}") from e


class EnsureFolders(BaseModel):
    names: list[str] = Field(default_factory=list, description="Directory names from FAFO play folders")
    paths: list[str] = Field(default_factory=list, description="Absolute paths if known")


def _bg_refresh_index() -> None:
    """Full disk walk after listen, so /api/health is up immediately."""
    global _indexing
    _indexing = True
    try:
        n = rebuild_index()
        print(f"[FAFO Meta] Indexed {n} video files from watched folders.")
        print(f"[FAFO Meta] Tag vocabulary: {len(_tag_vocab)} tags")
        try:
            pub = _load_ledger("public")
            nled = len(pub.get("files") or {})
            if nled:
                print(f"[FAFO Meta] Salvage ledger: {nled} file(s) in {LEDGER_PUBLIC_PATH.name}")
        except Exception:
            pass
    except Exception as e:
        print(f"[FAFO Meta] Index warning: {e}")
    finally:
        _indexing = False


@app.on_event("startup")
def on_startup() -> None:
    # Re-apply after uvicorn configures loggers
    _install_quiet_access_logs()
    load_config()
    load_index()
    load_tag_vocab()
    with _lock:
        cached = sum(len(v) for v in _index.values())
    print(f"[FAFO Meta] Cached index ready · {cached} file(s). Background refresh starting.")
    print("[FAFO Meta] Quiet poll logs ON (health/media/tags success hidden).")
    _note_s2_demand("fafo-meta-startup")
    threading.Thread(target=_bg_refresh_index, daemon=True, name="fafo-reindex").start()


# Editable FAFO UI settings (survives extension reloads when companion is running)
SETTINGS_TXT_PATH = ROOT / "fafo-user-settings.txt"
# Structured backup vault (created automatically on first write)
# FAFO-Backups/
#   README.txt
#   latest/full.json          — always current full snapshot
#   latest/visual.json        — visual / theme snapshot when present
#   rolling/<type>/*.json     — rotated history per type (keep limits below)
#   themes/*.json             — named custom themes
BACKUP_VAULT = ROOT / "FAFO-Backups"
BACKUP_JSON_PATH = BACKUP_VAULT / "latest" / "full.json"  # compat path for latest
BACKUP_HISTORY_DIR = BACKUP_VAULT / "rolling" / "legacy"  # old flat history still pruned
# keep last N files per rolling bucket (user asked ~5–10)
BACKUP_KEEP = {
    "auto": 10,
    "tags": 10,
    "options": 10,
    "export": 10,
    "manual": 10,
    "visual": 5,
    "playlists": 10,
    "restore": 5,
    "themes": 20,
    "legacy": 5,
}

LEDGER_PUBLIC_PATH = ROOT / "fafo-meta-ledger.json"
LEDGER_PRIVATE_PATH = ROOT / "fafo-meta-ledger-private.json"
LEDGER_VAULT_PATH = BACKUP_VAULT / "latest" / "meta-ledger.json"
FAIL_LOG_PATH = ROOT / "logs" / "write-failures.jsonl"
FAIL_LIMIT = 3


def _log_write_failure(
    *,
    name: str | None,
    error: str,
    path: str | None = None,
    client_key: str | None = None,
    fail_count: int | None = None,
) -> None:
    rec = {
        "at": _now_ms(),
        "name": name or "",
        "path": path or "",
        "error": str(error or "write failed"),
        "key": client_key or "",
        "failCount": fail_count,
    }
    try:
        FAIL_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with FAIL_LOG_PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except OSError:
        pass
    shown = name or path or client_key or "?"
    print(f"[FAFO Meta] FAIL  {shown}  {error}")


def _bump_fail_explorer(ex: dict[str, Any], error: str) -> dict[str, Any]:
    log = list(ex.get("failLog") or [])
    count = int(ex.get("failCount") or 0) + 1
    log.append({"at": _now_ms(), "error": error})
    if len(log) > 20:
        log = log[-20:]
    nxt = dict(ex)
    nxt.update({
        "status": "failed",
        "lastAttempt": _now_ms(),
        "error": error,
        "failCount": count,
        "failLog": log,
    })
    return nxt


def _backup_bucket_for_reason(reason: str) -> str:
    r = (reason or "auto").lower()
    if r in ("export",):
        return "export"
    if r in ("manual", "snapshot"):
        return "manual"
    if r in ("options-save", "chrome-art", "config"):
        return "options"
    if r in ("visual-fx", "visual", "theme"):
        return "visual"
    if r.startswith("playlist"):
        return "playlists"
    if r in ("pre-restore", "post-restore", "restore"):
        return "restore"
    if r in ("tag-save", "tags", "pairs-save", "pairs-tags"):
        return "tags"
    if r in ("theme-save", "custom-theme"):
        return "themes"
    return "auto"


def _ensure_backup_vault() -> None:
    """Create FAFO-Backups tree + README once."""
    import json as _json
    (BACKUP_VAULT / "latest").mkdir(parents=True, exist_ok=True)
    (BACKUP_VAULT / "themes").mkdir(parents=True, exist_ok=True)
    for bucket in BACKUP_KEEP:
        (BACKUP_VAULT / "rolling" / bucket).mkdir(parents=True, exist_ok=True)
    readme = BACKUP_VAULT / "README.txt"
    if not readme.exists():
        readme.write_text(
            "FAFO Ultimate Tab — backup vault\n"
            "================================\n"
            "Created automatically by explorer-meta companion.\n\n"
            "Structure:\n"
            "  latest/full.json     Always the newest full snapshot\n"
            "  latest/visual.json   Latest visual / theme settings (when saved)\n"
            "  rolling/<type>/      Rotating history (oldest deleted after keep limit)\n"
            "    auto/     (10)  everyday tag autosaves\n"
            "    tags/     (10)  tag-focused saves\n"
            "    options/  (10)  Options / SAVE SYSTEM\n"
            "    export/   (10)  manual Export from UI\n"
            "    manual/   (10)  Snapshot now\n"
            "    visual/   (5)   visual FX / colors / animations\n"
            "    playlists/(10)  playlist edits\n"
            "    restore/  (5)   pre/post restore safety copies\n"
            "  themes/              Named custom themes (keep 20)\n\n"
            "Safe to copy this whole folder to USB / Drive.\n",
            encoding="utf-8",
        )


def _prune_dir(folder, keep: int) -> None:
    if keep < 1 or not folder.exists():
        return
    files = sorted(
        [p for p in folder.glob("*.json") if p.is_file()],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for old in files[keep:]:
        try:
            old.unlink()
        except Exception:
            pass


def _write_structured_backup(payload: dict, reason: str) -> dict:
    """Write latest + rolling bucket entry; prune. Returns paths written."""
    import json as _json
    from datetime import datetime

    _ensure_backup_vault()
    text = _json.dumps(payload if isinstance(payload, dict) else {}, ensure_ascii=False, indent=2)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    bucket = _backup_bucket_for_reason(reason)
    keep = BACKUP_KEEP.get(bucket, 10)

    latest = BACKUP_VAULT / "latest" / "full.json"
    latest.write_text(text, encoding="utf-8")

    # Split visual snapshot when present for easy theme recovery
    visual = None
    try:
        data = payload.get("data") if isinstance(payload, dict) else None
        visual = (data or {}).get("fafoVisual") or (data or {}).get("mediaConfig", {}).get("visual")
    except Exception:
        visual = None
    if visual is not None:
        (BACKUP_VAULT / "latest" / "visual.json").write_text(
            _json.dumps(visual, ensure_ascii=False, indent=2), encoding="utf-8"
        )

    roll_dir = BACKUP_VAULT / "rolling" / bucket
    roll_dir.mkdir(parents=True, exist_ok=True)
    safe_reason = re.sub(r"[^a-z0-9_-]+", "-", (reason or "auto").lower())[:32]
    hist = roll_dir / f"{stamp}-{safe_reason or 'auto'}.json"
    hist.write_text(text, encoding="utf-8")
    _prune_dir(roll_dir, keep)

    # themes bucket also copies named visual-only if payload is a theme
    if bucket == "themes" and isinstance(payload, dict) and payload.get("name"):
        tname = re.sub(r"[^a-zA-Z0-9._-]+", "_", str(payload.get("name")))[:48] or "theme"
        tpath = BACKUP_VAULT / "themes" / f"{tname}.json"
        tpath.write_text(text, encoding="utf-8")
        _prune_dir(BACKUP_VAULT / "themes", BACKUP_KEEP.get("themes", 20))

    return {
        "vault": str(BACKUP_VAULT),
        "latest": str(latest),
        "rolling": str(hist),
        "bucket": bucket,
        "keep": keep,
    }


def _now_ms() -> int:
    return int(time.time() * 1000)


def _empty_ledger(space: str) -> dict[str, Any]:
    return {
        "kind": "fafo-meta-ledger",
        "version": 1,
        "space": "private" if space == "private" else "public",
        "updatedAt": 0,
        "files": {},
    }


def _ledger_path(space: str) -> Path:
    return LEDGER_PRIVATE_PATH if space == "private" else LEDGER_PUBLIC_PATH


def _load_ledger(space: str) -> dict[str, Any]:
    path = _ledger_path(space)
    if not path.exists():
        return _empty_ledger(space)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return _empty_ledger(space)
        data.setdefault("files", {})
        if not isinstance(data["files"], dict):
            data["files"] = {}
        data["space"] = "private" if space == "private" else "public"
        data["kind"] = "fafo-meta-ledger"
        return data
    except Exception:
        return _empty_ledger(space)


def _save_ledger(space: str, ledger: dict[str, Any]) -> Path:
    _ensure_backup_vault()
    ledger = dict(ledger or {})
    ledger["kind"] = "fafo-meta-ledger"
    ledger["version"] = int(ledger.get("version") or 1)
    ledger["space"] = "private" if space == "private" else "public"
    ledger["updatedAt"] = int(ledger.get("updatedAt") or _now_ms())
    ledger.setdefault("files", {})
    text = json.dumps(ledger, ensure_ascii=False, indent=2)
    path = _ledger_path(space)
    path.write_text(text, encoding="utf-8")
    if space != "private":
        LEDGER_VAULT_PATH.write_text(text, encoding="utf-8")
    return path


def _merge_ledger(disk: dict[str, Any], incoming: dict[str, Any] | None) -> dict[str, Any]:
    out = _empty_ledger(disk.get("space") or "public")
    out["files"] = dict(disk.get("files") or {})
    out["updatedAt"] = int(disk.get("updatedAt") or 0)
    if not incoming or not isinstance(incoming, dict):
        return out
    src = incoming.get("files") if isinstance(incoming.get("files"), dict) else {}
    for key, rec in src.items():
        if not key or not isinstance(rec, dict):
            continue
        prev = out["files"].get(key) or {}
        if int(rec.get("updatedAt") or 0) >= int(prev.get("updatedAt") or 0):
            out["files"][key] = rec
        else:
            out["files"][key] = prev
    out["updatedAt"] = max(int(out["updatedAt"] or 0), int(incoming.get("updatedAt") or 0), _now_ms())
    return out


class FafoLedgerBody(BaseModel):
    space: str = "public"
    ledger: dict[str, Any] | None = None


@app.get("/api/fafo/ledger")
def get_fafo_ledger(space: str = Query(default="public")):
    sp = "private" if space == "private" else "public"
    path = _ledger_path(sp)
    ledger = _load_ledger(sp)
    files = ledger.get("files") or {}
    pending = 0
    applied = 0
    failed = 0
    for rec in files.values():
        st = str((rec or {}).get("explorer", {}).get("status") or "pending")
        if st == "applied":
            applied += 1
        elif st == "failed":
            failed += 1
            pending += 1
        else:
            pending += 1
    return {
        "ok": True,
        "exists": path.exists(),
        "path": str(path),
        "space": sp,
        "total": len(files),
        "pending": pending,
        "applied": applied,
        "failed": failed,
        "updatedAt": ledger.get("updatedAt"),
        "ledger": ledger,
    }


@app.get("/api/fafo/fail-log")
def get_write_fail_log(limit: int = Query(default=80, ge=1, le=500)):
    """Recent Explorer write failures (file name + reason)."""
    rows: list[dict[str, Any]] = []
    if FAIL_LOG_PATH.exists():
        try:
            lines = FAIL_LOG_PATH.read_text(encoding="utf-8").splitlines()
            for line in lines[-limit:]:
                line = line.strip()
                if not line:
                    continue
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        except OSError:
            pass
    rows.reverse()
    return {
        "ok": True,
        "path": str(FAIL_LOG_PATH),
        "count": len(rows),
        "items": rows,
    }


@app.post("/api/fafo/ledger")
def post_fafo_ledger(body: FafoLedgerBody):
    sp = "private" if body.space == "private" else "public"
    merged = _merge_ledger(_load_ledger(sp), body.ledger)
    path = _save_ledger(sp, merged)
    return {
        "ok": True,
        "path": str(path),
        "space": sp,
        "total": len(merged.get("files") or {}),
        "updatedAt": merged.get("updatedAt"),
    }


@app.post("/api/fafo/ledger/apply")
def apply_fafo_ledger(body: FafoLedgerBody | None = Body(default=None)):
    """Write pending/failed/deferred ledger rows onto Windows Explorer files."""
    body = body or FafoLedgerBody()
    sp = "private" if body.space == "private" else "public"
    ledger = _merge_ledger(_load_ledger(sp), body.ledger)
    files = ledger.get("files") or {}
    applied = 0
    failed = 0
    deferred = 0
    skipped = 0
    pending_states = {"pending", "failed", "deferred", "", "none"}

    print(f"[FAFO Meta] Ledger apply · {sp} · {len(files)} tracked")
    for key, rec in list(files.items()):
        if not isinstance(rec, dict):
            continue
        ex = rec.get("explorer") if isinstance(rec.get("explorer"), dict) else {}
        status = str(ex.get("status") or "pending")
        if status not in pending_states and status != "applied":
            # unknown → treat as pending
            status = "pending"
        if status == "applied":
            skipped += 1
            continue
        hold = str(ex.get("hold") or "")
        if hold == "dropped" or status == "dropped":
            skipped += 1
            continue
        if hold == "snooze" and int(ex.get("snoozeUntil") or 0) > _now_ms():
            skipped += 1
            continue
        if int(ex.get("failCount") or 0) >= FAIL_LIMIT and hold != "retry":
            skipped += 1
            continue
        name = rec.get("name")
        if not name:
            rec["explorer"] = {
                **ex,
                "status": "failed",
                "error": "missing file name",
                "lastAttempt": _now_ms(),
            }
            rec["updatedAt"] = _now_ms()
            failed += 1
            continue
        try:
            item = FileMetaWrite(
                name=str(name),
                size=int(rec["size"]) if rec.get("size") is not None else None,
                mtime=float(rec["mtime"]) if rec.get("mtime") is not None else None,
                path=str(ex.get("path") or "") or None,
                tags=list(rec.get("tags") or []),
                rating=int(rec.get("rating") or 0),
                update_catalog=True,
                client_key=str(key),
            )
            result = _write_one(item, log=False)
            is_deferred = bool(result.get("deferred_shell"))
            rec["explorer"] = {
                **ex,
                "status": "deferred" if is_deferred else "applied",
                "lastAttempt": _now_ms(),
                "lastApplied": _now_ms(),
                "error": "",
                "path": result.get("resolved_path") or "",
                "methods": result.get("methods") or [],
                "failCount": 0,
                "hold": "",
                "snoozeUntil": 0,
            }
            rec["updatedAt"] = _now_ms()
            if is_deferred:
                deferred += 1
            applied += 1
        except HTTPException as he:
            err = he.detail if isinstance(he.detail, str) else str(he.detail)
            rec["explorer"] = _bump_fail_explorer(ex, err)
            rec["updatedAt"] = _now_ms()
            _log_write_failure(
                name=str(name or ""),
                error=err,
                path=str(ex.get("path") or ""),
                client_key=str(key),
                fail_count=int(rec["explorer"].get("failCount") or 0),
            )
            failed += 1
        except Exception as e:
            rec["explorer"] = _bump_fail_explorer(ex, str(e))
            rec["updatedAt"] = _now_ms()
            _log_write_failure(
                name=str(name or ""),
                error=str(e),
                path=str(ex.get("path") or ""),
                client_key=str(key),
                fail_count=int(rec["explorer"].get("failCount") or 0),
            )
            failed += 1

    ledger["files"] = files
    ledger["updatedAt"] = _now_ms()
    path = _save_ledger(sp, ledger)
    print(
        f"[FAFO Meta] Ledger apply done · applied={applied} deferred={deferred} "
        f"failed={failed} skipped_ok={skipped} -> {path}"
    )
    return {
        "ok": failed == 0,
        "space": sp,
        "path": str(path),
        "applied": applied,
        "deferred": deferred,
        "failed": failed,
        "skipped": skipped,
        "total": len(files),
        "ledger": ledger,
    }


@app.get("/api/fafo/settings")
def get_fafo_settings():
    """Human-editable key=value settings used by the Tags UI on boot."""
    if not SETTINGS_TXT_PATH.exists():
        return {"ok": True, "text": "", "path": str(SETTINGS_TXT_PATH), "exists": False}
    try:
        text = SETTINGS_TXT_PATH.read_text(encoding="utf-8")
    except Exception as e:
        return {"ok": False, "error": str(e), "text": "", "path": str(SETTINGS_TXT_PATH)}
    return {
        "ok": True,
        "text": text,
        "path": str(SETTINGS_TXT_PATH),
        "exists": True,
        "mtime": SETTINGS_TXT_PATH.stat().st_mtime,
    }


class FafoSettingsBody(BaseModel):
    text: str = Field(..., description="Full fafo-user-settings.txt contents")


@app.post("/api/fafo/settings")
def post_fafo_settings(body: FafoSettingsBody):
    try:
        SETTINGS_TXT_PATH.write_text(body.text or "", encoding="utf-8")
    except Exception as e:
        return {"ok": False, "error": str(e), "path": str(SETTINGS_TXT_PATH)}
    return {
        "ok": True,
        "path": str(SETTINGS_TXT_PATH),
        "bytes": len((body.text or "").encode("utf-8")),
    }


class FafoBackupBody(BaseModel):
    bundle: dict = Field(..., description="Full FAFO backup JSON bundle")
    reason: str = Field(default="auto", description="Why this backup was written")


@app.get("/api/fafo/backup")
def get_fafo_backup():
    """Latest full auto-backup (tags, options, playlists, library catalog)."""
    if not BACKUP_JSON_PATH.exists():
        return {"ok": True, "exists": False, "path": str(BACKUP_JSON_PATH), "bundle": None}
    try:
        import json as _json
        text = BACKUP_JSON_PATH.read_text(encoding="utf-8")
        bundle = _json.loads(text) if text.strip() else None
    except Exception as e:
        return {"ok": False, "error": str(e), "path": str(BACKUP_JSON_PATH), "bundle": None}
    return {
        "ok": True,
        "exists": True,
        "path": str(BACKUP_JSON_PATH),
        "bytes": BACKUP_JSON_PATH.stat().st_size,
        "mtime": BACKUP_JSON_PATH.stat().st_mtime,
        "bundle": bundle,
    }


@app.post("/api/fafo/backup")
def post_fafo_backup(body: FafoBackupBody):
    """
    Persist full JSON into FAFO-Backups/ vault:
      latest/full.json + rolling/<type>/ with keep limits (5–10).
    """
    try:
        payload = body.bundle if isinstance(body.bundle, dict) else {}
        reason = body.reason or "auto"
        # Always update latest; rolling history for all reasons (throttled client-side)
        paths = _write_structured_backup(payload, reason)
        text_len = len(
            __import__("json").dumps(payload, ensure_ascii=False).encode("utf-8")
        )
    except Exception as e:
        return {"ok": False, "error": str(e), "path": str(BACKUP_JSON_PATH)}
    return {
        "ok": True,
        "path": paths.get("latest") or str(BACKUP_JSON_PATH),
        "vault": paths.get("vault"),
        "bucket": paths.get("bucket"),
        "rolling": paths.get("rolling"),
        "keep": paths.get("keep"),
        "bytes": text_len,
        "reason": body.reason or "auto",
    }


class FafoThemeBody(BaseModel):
    theme: dict = Field(..., description="Named custom theme JSON")
    name: str = Field(default="", description="Theme display name")


@app.post("/api/fafo/theme")
def post_fafo_theme(body: FafoThemeBody):
    """Save a named custom theme into FAFO-Backups/themes/ (keep last 20)."""
    import json as _json
    try:
        _ensure_backup_vault()
        theme = body.theme if isinstance(body.theme, dict) else {}
        name = body.name or theme.get("name") or "custom-theme"
        theme = {**theme, "name": name, "savedAt": theme.get("savedAt") or __import__("time").time() * 1000}
        paths = _write_structured_backup(theme, "custom-theme")
        # Also always write stable name file
        safe = re.sub(r"[^a-zA-Z0-9._-]+", "_", name)[:48] or "theme"
        tpath = BACKUP_VAULT / "themes" / f"{safe}.json"
        tpath.write_text(_json.dumps(theme, ensure_ascii=False, indent=2), encoding="utf-8")
        _prune_dir(BACKUP_VAULT / "themes", BACKUP_KEEP.get("themes", 20))
        return {"ok": True, "path": str(tpath), "vault": paths.get("vault"), "name": name}
    except Exception as e:
        return {"ok": False, "error": str(e)}


@app.get("/api/fafo/backup/status")
def get_fafo_backup_status():
    """Vault paths + counts per rolling bucket."""
    _ensure_backup_vault()
    buckets = {}
    for name, keep in BACKUP_KEEP.items():
        d = BACKUP_VAULT / "rolling" / name
        n = len(list(d.glob("*.json"))) if d.exists() else 0
        buckets[name] = {"count": n, "keep": keep, "path": str(d)}
    themes_dir = BACKUP_VAULT / "themes"
    return {
        "ok": True,
        "vault": str(BACKUP_VAULT),
        "latest": str(BACKUP_JSON_PATH),
        "latest_exists": BACKUP_JSON_PATH.exists(),
        "buckets": buckets,
        "themes": len(list(themes_dir.glob("*.json"))) if themes_dir.exists() else 0,
    }


@app.get("/api/health")
def health(probe: int = 0):
    # probe=1 is the watchdog / tray ping — do NOT treat it as "user is using FAFO"
    # or S2 can never go idle.
    if not probe:
        _note_s2_demand()
    with _lock:
        file_count = sum(len(v) for v in _index.values())
        tag_count = len(_tag_vocab)
        pending_n = len(_pending_shell)
    idle_for = time.time() - float(_last_demand_write or 0) if _last_demand_write else 0
    return {
        "ok": True,
        "service": "fafo-explorer-meta",
        "version": "1.2.7",
        "role": "S2 FAFO Local Media Tagger (Chrome extension tags/ratings companion)",
        "endpoint": f"http://{HOST}:{PORT}",
        "watched_dirs": _config.get("watched_dirs") or [],
        "indexed_names": len(_index),
        "file_count": file_count,
        "tag_count": tag_count,
        "pending_shell_writes": pending_n,
        "indexing": _indexing,
        "idleForSec": int(idle_for) if _last_demand_write else 0,
        "settings_path": str(SETTINGS_TXT_PATH),
        "backup_path": str(BACKUP_JSON_PATH),
        "backup_vault": str(BACKUP_VAULT),
        "features": [
            "media_search",
            "tags",
            "tag_scrub",
            "fs_write_metadata",
            "fs_write_metadata_batch",
            "library_export_tags",
            "quiet_poll_logs",
            "no_bundled_videos",
            "fafo_settings",
            "fafo_json_backup",
            "orphan_discover",
            "bg_index",
            "folder_picker",
            "recursive_rollup",
            "write_fail_log",
            "idle_when_unused",
        ],
    }



@app.get("/api/media")
def api_media(
    search: str = "",
    limit: int = 80,
    page: int = 0,
    read_tags: bool = False,
):
    """
    Toolbox-compatible media search used by FAFO (fetchTagsForIdentity, etc.).
    Always returns 200 with items[] — never 404 for empty results.
    Search is pure memory over the index (fast with thousands of files).
    """
    limit = max(1, min(int(limit or 80), 500))
    page = max(0, int(page or 0))
    # FAFO usually asks for limit=5; still compute full match total in memory
    need = limit * (page + 1)
    hits, total = search_index(search, limit=max(need, limit))
    # If paging beyond first window, re-fetch enough rows
    if need > limit:
        hits, total = search_index(search, limit=need)
    start = page * limit
    page_hits = hits[start : start + limit]
    # Only read shell tags for the small result page when requested or limit is tiny
    do_read = read_tags or (bool(search) and limit <= 10)
    items = [entry_to_media_item(e, read_tags=do_read) for e in page_hits]
    return {
        "items": items,
        "total": total,
        "page": page,
        "limit": limit,
        "search": search,
    }


@app.get("/api/tags")
def api_tags():
    """Toolbox-compatible tag list. Returns [] until tags are written / harvested."""
    with _lock:
        tags = sorted(
            (t for t in _tag_vocab.values() if t and not is_junk_tag(t)),
            key=str.lower,
        )
    return tags


class TagScrubBody(BaseModel):
    """Bulk junk-tag cleanup. dry_run=scan only; rewrite_files=write cleaned tags to disk."""
    dry_run: bool = False
    # Default True so a plain POST /tags/scrub actually cleans files (fix-all).
    rewrite_files: bool = True
    max_files: int = Field(default=50000, ge=1, le=50000)


@app.post("/api/tags/scrub")
def api_tags_scrub(body: TagScrubBody | None = Body(default=None)):
    """
    Drop junk tags from vocabulary + tags_cache (Signature/ComfyUI dumps, etc.).

    When rewrite_files=true (or dry_run=true), also walk the indexed library, read
    each file's tags, drop unusual/junk entries, and optionally write clean tags back
    so Explorer no longer shows multi-KB Signature/Comfy dumps.
    """
    global _tag_vocab
    opts = body or TagScrubBody()
    removed = 0
    with _lock:
        keep: dict[str, str] = {}
        for low, display in list(_tag_vocab.items()):
            if is_junk_tag(display) or is_junk_tag(low):
                removed += 1
                continue
            for part in normalize_tags([display]):
                keep[part.lower()] = part
        _tag_vocab = keep
        remaining = len(_tag_vocab)
        tags_out = sorted(_tag_vocab.values(), key=str.lower)
    try:
        save_tag_vocab()
    except Exception as e:
        raise HTTPException(500, f"Failed to save cleaned tags: {e}") from e

    files_scanned = 0
    files_dirty = 0
    tags_removed_from_files = 0
    files_rewritten = 0
    files_failed = 0
    samples: list[str] = []
    longest = 0

    do_scan = bool(opts.rewrite_files or opts.dry_run)
    if do_scan:
        entries = all_entries()
        limit = int(opts.max_files or 5000)
        print(
            f"[FAFO Meta] Tag scrub file scan · {min(len(entries), limit)}/{len(entries)} "
            f"({'dry-run' if opts.dry_run and not opts.rewrite_files else 'rewrite' if opts.rewrite_files else 'scan'})"
        )
        for entry in entries[:limit]:
            path_s = entry.get("path") or ""
            if not path_s:
                continue
            p = Path(path_s)
            if not p.is_file():
                continue
            files_scanned += 1
            try:
                meta = read_file_metadata(p)
                raw_tags = list(meta.get("tags") or [])
                if not raw_tags:
                    continue
                clean = normalize_tags(raw_tags)
                # Count drops (case-insensitive multiset-ish)
                clean_low = {t.lower() for t in clean}
                dropped_here = []
                for t in raw_tags:
                    s = str(t or "").strip()
                    if not s:
                        continue
                    if s.lower() in clean_low:
                        continue
                    if is_junk_tag(s) or len(s) >= 100:
                        dropped_here.append(s)
                # Also treat any length reduction as dirty
                if len(clean) == len(raw_tags) and not dropped_here:
                    # exact same membership after normalize?
                    raw_norm = [str(t).strip() for t in raw_tags if str(t).strip()]
                    if {x.lower() for x in raw_norm} == clean_low and len(raw_norm) == len(clean):
                        continue

                files_dirty += 1
                tags_removed_from_files += max(0, len(raw_tags) - len(clean))
                for s in dropped_here:
                    longest = max(longest, len(s))
                    if len(samples) < 12:
                        preview = s if len(s) <= 72 else s[:69] + "…"
                        samples.append(f"{preview} ({len(s)} chars)")

                if opts.rewrite_files and not opts.dry_run:
                    rating = meta.get("rating") or 0
                    try:
                        r = write_file_metadata(
                            p,
                            tags=clean,
                            rating=int(rating) if rating else 0,
                            retries=2,
                            retry_delay_s=0.25,
                        )
                        if r.get("ok") is False and not (r.get("methods") or []):
                            files_failed += 1
                        else:
                            files_rewritten += 1
                            remember_tags(clean)
                    except Exception:
                        files_failed += 1
            except Exception:
                files_failed += 1

        if opts.rewrite_files and not opts.dry_run:
            try:
                save_tag_vocab()
            except Exception:
                pass
            print(
                f"[FAFO Meta] Tag scrub rewrite done · dirty={files_dirty} "
                f"rewritten={files_rewritten} failed={files_failed}"
            )

    return {
        "ok": True,
        "removed": removed,
        "remaining": remaining,
        "tags": tags_out,
        "files_scanned": files_scanned,
        "files_dirty": files_dirty,
        "tags_removed_from_files": tags_removed_from_files,
        "files_rewritten": files_rewritten,
        "files_failed": files_failed,
        "longest_junk": longest,
        "samples": samples,
        "dry_run": bool(opts.dry_run),
        "rewrite_files": bool(opts.rewrite_files),
    }


@app.get("/api/library")
def library_info():
    with _lock:
        file_count = sum(len(v) for v in _index.values())
    return {
        "watched_dirs": _config.get("watched_dirs") or [],
        "file_count": file_count,
        "unique_names": len(_index),
    }


@app.post("/api/library/add-folder")
def add_folder(body: AddFolder):
    p = Path(body.path).expanduser()
    if not p.is_dir():
        raise HTTPException(404, f"Folder not found: {body.path}")
    resolved = str(p.resolve())
    dirs = list(_config.get("watched_dirs") or [])
    rolled, dropped, covered = rollup_watched_dirs(dirs, resolved)
    if rolled != dirs:
        _config["watched_dirs"] = rolled
        save_config()
    # Always walk this tree (and every subfolder) so new files show up.
    n = scan_dir(p)
    save_index()
    print(
        f"[FAFO Meta] Watch folder · {resolved} · indexed {n} "
        f"(subfolders included; dropped {len(dropped)} nested)"
    )
    return {
        "ok": True,
        "path": resolved,
        "files_indexed": n,
        "recursive": True,
        "already_covered": covered,
        "dropped_children": dropped,
        "watched_dirs": _config.get("watched_dirs") or [],
    }


class RemoveFolder(BaseModel):
    path: str


@app.post("/api/library/remove-folder")
def remove_folder(body: RemoveFolder):
    want = _path_key(body.path)
    dirs = list(_config.get("watched_dirs") or [])
    kept = [d for d in dirs if _path_key(d) != want]
    if len(kept) == len(dirs):
        raise HTTPException(404, f"Folder not in watch list: {body.path}")
    _config["watched_dirs"] = kept
    save_config()
    threading.Thread(target=_bg_refresh_index, daemon=True, name="fafo-reindex").start()
    return {
        "ok": True,
        "removed": body.path,
        "watched_dirs": kept,
    }


@app.post("/api/library/pick-folder")
def pick_and_add_folder():
    """Mini Explorer window. Picked folder includes all subdirectories."""
    if not _pick_lock.acquire(blocking=False):
        raise HTTPException(409, "A folder picker is already open")
    try:
        path = pick_directory()
        if not path:
            return {"ok": False, "cancelled": True, "recursive": True}
        return add_folder(AddFolder(path=path))
    finally:
        _pick_lock.release()


def _candidate_roots() -> list[Path]:
    roots: list[Path] = []
    for d in list(_config.get("watched_dirs") or []):
        p = Path(d)
        roots.append(p)
        if p.parent:
            roots.append(p.parent)
            if p.parent.parent:
                roots.append(p.parent.parent)
    home = Path(os.environ.get("USERPROFILE") or os.path.expanduser("~"))
    roots.extend([
        home / "Videos",
        home / "Downloads",
        home / "Documents",
        Path("D:/OUTPUTS"),
        Path("D:/"),
        Path("E:/"),
        Path("C:/"),
    ])
    if os.name == "nt":
        for letter in "CDEFGHIJ":
            roots.append(Path(f"{letter}:/"))
    out: list[Path] = []
    seen: set[str] = set()
    for r in roots:
        try:
            if not r.exists() or not r.is_dir():
                continue
            key = str(r.resolve()).lower()
        except OSError:
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def find_dir_named(name: str) -> Path | None:
    want = (name or "").strip()
    if not want:
        return None
    low = want.lower()
    for d in list(_config.get("watched_dirs") or []):
        p = Path(d)
        try:
            if p.is_dir() and p.name.lower() == low:
                return p
            child = p / want
            if child.is_dir():
                return child
        except OSError:
            continue
    for root in _candidate_roots():
        try:
            cand = root / want
            if cand.is_dir():
                return cand
        except OSError:
            pass
        try:
            for child in root.iterdir():
                if not child.is_dir():
                    continue
                if child.name.lower() == low:
                    return child
                nested = child / want
                try:
                    if nested.is_dir():
                        return nested
                except OSError:
                    continue
        except OSError:
            continue
    return None


def _orphan_search_roots() -> list[Path]:
    """Folders to walk when a write misses the index (not drive roots)."""
    roots: list[Path] = []
    for d in list(_config.get("watched_dirs") or []):
        p = Path(d)
        try:
            if p.parent and p.parent.name:
                roots.append(p.parent)
            gp = p.parent.parent if p.parent else None
            if gp is not None and gp.name:
                roots.append(gp)
        except OSError:
            continue
    roots.extend([
        Path(r"D:\OUTPUTS"),
        Path(r"D:\OUTPUTS\__X_GROK"),
        Path(r"D:\OUTPUTS\toolbox"),
    ])
    out: list[Path] = []
    seen: set[str] = set()
    for r in roots:
        try:
            if not r.exists() or not r.is_dir():
                continue
            if r.parent == r:
                continue
            key = str(r.resolve()).lower()
        except OSError:
            continue
        if key in seen:
            continue
        seen.add(key)
        out.append(r)
    return out


def _play_folder_for(path: Path) -> Path:
    folder = path.parent
    try:
        if folder.name.startswith("_") and folder.parent.name:
            folder = folder.parent
    except OSError:
        pass
    return folder


def _remember_index_entry(path: Path) -> None:
    try:
        st = path.stat()
    except OSError:
        return
    entry = {
        "path": str(path),
        "name": path.name,
        "size": st.st_size,
        "mtime": st.st_mtime,
    }
    key = path.name.lower()
    with _lock:
        bucket = [e for e in (_index.get(key) or []) if e.get("path") != entry["path"]]
        bucket.append(entry)
        _index[key] = bucket


def _discover_unwatched_file(name: str) -> Path | None:
    """Find a clip outside watched_dirs and auto-index its play folder."""
    base = Path(name).name
    if not base or base in {".", ".."}:
        return None
    hit: Path | None = None
    for root in _orphan_search_roots():
        try:
            for p in root.rglob(base):
                try:
                    if p.is_file() and p.name.lower() == base.lower():
                        hit = p
                        break
                except OSError:
                    continue
            if hit:
                break
        except OSError:
            continue
    if not hit:
        return None
    folder = _play_folder_for(hit)
    try:
        add_folder(AddFolder(path=str(folder)))
        print(f"[FAFO Meta] Auto-indexed play folder · {folder}")
    except Exception as e:
        print(f"[FAFO Meta] Auto-index skipped · {folder}: {e}")
        _remember_index_entry(hit)
    return hit


@app.post("/api/library/ensure-folders")
def ensure_folders(body: EnsureFolders):
    """Index FAFO play folders by absolute path or directory name so tag writes can resolve."""
    added: list[str] = []
    missing: list[str] = []
    for path in body.paths or []:
        p = Path(str(path)).expanduser()
        if p.is_dir():
            add_folder(AddFolder(path=str(p)))
            added.append(str(p.resolve()))
        else:
            missing.append(str(path))
    for name in body.names or []:
        n = str(name or "").strip()
        if not n:
            continue
        hit = find_dir_named(n)
        if hit:
            add_folder(AddFolder(path=str(hit)))
            added.append(str(hit.resolve()))
        else:
            missing.append(n)
    return {
        "ok": True,
        "added": added,
        "missing": missing,
        "watched_dirs": _config.get("watched_dirs") or [],
    }


@app.post("/api/library/rescan")
def rescan():
    n = rebuild_index()
    return {"ok": True, "files_indexed": n, "watched_dirs": _config.get("watched_dirs") or []}


def _schedule_shell_retry(path: Path, tags: list[str] | None, rating: int | None) -> None:
    """Retry Explorer shell props after Chrome releases the file lock."""
    global _pending_shell_thread
    key = str(path.resolve())
    with _lock:
        _pending_shell[key] = {
            "tags": tags,
            "rating": rating,
            "tries": 0,
            "name": path.name,
        }

    def worker() -> None:
        # Wait for playback lock to clear; re-check queue each cycle
        for _ in range(24):  # ~2 minutes max
            time.sleep(5)
            with _lock:
                items = list(_pending_shell.items())
            if not items:
                return
            for pstr, job in items:
                p = Path(pstr)
                if not p.is_file():
                    with _lock:
                        _pending_shell.pop(pstr, None)
                    continue
                res = write_file_metadata(
                    p,
                    tags=job.get("tags"),
                    rating=job.get("rating"),
                    retries=2,
                    retry_delay_s=0.4,
                )
                methods = res.get("methods") or []
                shell_ok = any(str(m).startswith("shell") for m in methods)
                if shell_ok or not res.get("file_locked"):
                    with _lock:
                        _pending_shell.pop(pstr, None)
                    if shell_ok:
                        print(f"[FAFO Meta] Deferred Explorer write OK -> {job.get('name')}")
                    continue
                with _lock:
                    if pstr in _pending_shell:
                        _pending_shell[pstr]["tries"] = int(_pending_shell[pstr].get("tries") or 0) + 1
                        if _pending_shell[pstr]["tries"] >= 20:
                            _pending_shell.pop(pstr, None)
                            print(f"[FAFO Meta] Gave up deferred Explorer write -> {job.get('name')}")
        with _lock:
            _pending_shell.clear()

    if _pending_shell_thread is None or not _pending_shell_thread.is_alive():
        _pending_shell_thread = threading.Thread(target=worker, daemon=True, name="fafo-shell-retry")
        _pending_shell_thread.start()


def _write_one(body: FileMetaWrite, *, log: bool = True) -> dict[str, Any]:
    """Shared single-file write used by single + batch endpoints."""
    if body.tags is None and body.rating is None:
        raise HTTPException(400, "Provide tags and/or rating")

    target = find_by_identity(body.name, body.size, body.mtime, body.path)
    if not target:
        raise HTTPException(
            404,
            "File not found in the metadata library. "
            "Add the video folder (ADD_VIDEO_FOLDER.bat / POST /api/library/add-folder) "
            "or pass an absolute path.",
        )

    tags = normalize_tags(body.tags) if body.tags is not None else None
    rating = body.rating
    if rating is not None:
        try:
            rating = max(0, min(5, int(rating)))
        except (TypeError, ValueError):
            rating = 0

    result = write_file_metadata(target, tags=tags, rating=rating, retries=4, retry_delay_s=0.4)
    result["ok"] = True
    result["resolved_path"] = str(target)
    result["name"] = target.name
    if body.client_key:
        result["client_key"] = body.client_key
    if tags is not None:
        remember_tags(tags)

    # Chrome often locks the playing file — queue Explorer shell write for later
    methods = result.get("methods") or []
    shell_ok = any(str(m).startswith("shell") for m in methods)
    if result.get("file_locked") and not shell_ok:
        _schedule_shell_retry(target, tags, rating)
        result["deferred_shell"] = True

    # Refresh this entry in index
    try:
        st = target.stat()
        key = target.name.lower()
        entry = {"path": str(target), "name": target.name, "size": st.st_size, "mtime": st.st_mtime}
        with _lock:
            bucket = [e for e in (_index.get(key) or []) if e.get("path") != entry["path"]]
            bucket.append(entry)
            _index[key] = bucket
        save_index()
    except Exception:
        pass
    methods_s = ", ".join(methods) or "ok"
    if log:
        if result.get("deferred_shell"):
            print(f"[FAFO Meta] Wrote (partial) -> {target.name}  ({methods_s}; Explorer retry queued)")
        else:
            print(f"[FAFO Meta] Wrote tags/rating -> {target.name}  ({methods_s})")
    return result


@app.post("/api/fs/write-metadata")
def api_write_metadata(body: FileMetaWrite):
    return _write_one(body, log=True)


@app.post("/api/fs/write-metadata-batch")
def api_write_metadata_batch(body: FileMetaWriteBatch):
    """
    Bulk write tags/ratings to many files (Explorer + shell props).
    Used by FAFO "Sync all pending to Explorer" so users do not have to
    visit each clip to push disk metadata.
    """
    items = body.items or []
    if not items:
        raise HTTPException(400, "items[] required")
    if len(items) > 2000:
        raise HTTPException(400, "Max 2000 items per batch")

    results: list[dict[str, Any]] = []
    written = 0
    failed = 0
    deferred = 0
    not_found = 0

    print(f"[FAFO Meta] Batch write starting · {len(items)} item(s)")
    for i, item in enumerate(items):
        try:
            r = _write_one(item, log=False)
            if r.get("deferred_shell"):
                deferred += 1
            written += 1
            results.append({
                "ok": True,
                "client_key": item.client_key,
                "name": r.get("name") or item.name,
                "resolved_path": r.get("resolved_path"),
                "methods": r.get("methods") or [],
                "deferred_shell": bool(r.get("deferred_shell")),
                "file_locked": bool(r.get("file_locked")),
            })
        except HTTPException as he:
            failed += 1
            detail = he.detail
            err = detail if isinstance(detail, str) else str(detail)
            if he.status_code == 404:
                not_found += 1
            _log_write_failure(
                name=item.name,
                error=err,
                path=item.path,
                client_key=item.client_key,
            )
            results.append({
                "ok": False,
                "client_key": item.client_key,
                "name": item.name,
                "error": err,
                "status": he.status_code,
            })
            if body.stop_on_error:
                break
        except Exception as e:
            failed += 1
            _log_write_failure(
                name=item.name,
                error=str(e),
                path=item.path,
                client_key=item.client_key,
            )
            results.append({
                "ok": False,
                "client_key": item.client_key,
                "name": item.name,
                "error": str(e),
                "status": 500,
            })
            if body.stop_on_error:
                break
        # Light yield so the server stays responsive during large pushes
        if (i + 1) % 25 == 0:
            time.sleep(0.05)

    print(
        f"[FAFO Meta] Batch write done · ok={written} fail={failed} "
        f"not_found={not_found} deferred={deferred}"
    )
    return {
        "ok": failed == 0,
        "total": len(items),
        "written": written,
        "failed": failed,
        "not_found": not_found,
        "deferred_shell": deferred,
        "results": results,
        "service": "fafo-explorer-meta",
        "endpoint": f"http://{HOST}:{PORT}",
    }


class RevealBody(BaseModel):
    path: str | None = None
    name: str | None = None
    size: int | None = None
    mtime: float | None = None


@app.post("/api/fs/reveal")
def api_reveal(body: RevealBody):
    """Open Windows Explorer with the file selected (or its parent folder)."""
    target = find_by_identity(body.name, body.size, body.mtime, body.path)
    if not target or not target.is_file():
        raise HTTPException(
            404,
            "File not found in index. Add the folder (ADD_VIDEO_FOLDER) or pass an absolute path.",
        )
    try:
        # /select, highlights the file in Explorer
        subprocess.Popen(
            ["explorer", f"/select,{target}"],
            shell=False,
        )
        return {
            "ok": True,
            "path": str(target),
            "folder": str(target.parent),
        }
    except OSError as e:
        raise HTTPException(500, f"Could not open Explorer: {e}") from e


@app.get("/api/fs/read-metadata")
def api_read_metadata(path: str = Query(...)):
    p = Path(path)
    if not p.is_file():
        raise HTTPException(404, "File not found")
    return read_file_metadata(p)


class ExportTagsBody(BaseModel):
    """Bulk export of Explorer/disk tags for FAFO rebuild recovery."""
    # Re-walk watched folders before export (slower, fresher paths)
    rescan: bool = False
    # Only return files that have tags and/or a star rating
    only_tagged: bool = True
    max_files: int = Field(default=20000, ge=1, le=50000)
    # Skip first N files (pagination)
    offset: int = Field(default=0, ge=0)


@app.post("/api/library/export-tags")
def api_library_export_tags(body: ExportTagsBody | None = Body(default=None)):
    """
    Read Tags + Rating from indexed files on disk (Windows shell / mutagen).

    Used by FAFO “Rebuild from disk” when chrome.storage or snapshots lose tags
    but Explorer metadata on the real files is still intact.
    """
    opts = body or ExportTagsBody()
    if opts.rescan:
        try:
            n = rebuild_index()
            print(f"[FAFO Meta] export-tags rescan indexed {n} files")
        except Exception as e:
            print(f"[FAFO Meta] export-tags rescan failed: {e}")

    entries = all_entries()
    # Stable order for offset pagination
    entries = sorted(entries, key=lambda e: str(e.get("path") or e.get("name") or "").lower())
    total = len(entries)
    start = int(opts.offset or 0)
    window = entries[start : start + int(opts.max_files)]

    items: list[dict[str, Any]] = []
    scanned = 0
    with_tags = 0
    errors = 0
    t0 = time.time()
    print(
        f"[FAFO Meta] export-tags · scanning {len(window)}/{total} files "
        f"(only_tagged={opts.only_tagged})…"
    )
    for e in window:
        scanned += 1
        path = e.get("path")
        if not path:
            continue
        try:
            meta = read_file_metadata(path)
            tags = list(meta.get("tags") or [])
            # normalize / drop junk
            try:
                tags = [t for t in normalize_tags(tags) if t and not is_junk_tag(t)]
            except Exception:
                tags = [str(t).strip() for t in tags if str(t).strip() and not is_junk_tag(str(t))]
            rating = int(meta.get("rating") or 0)
            if opts.only_tagged and not tags and not rating:
                continue
            if tags:
                remember_tags(tags)
                with_tags += 1
            items.append(
                {
                    "name": e.get("name") or Path(str(path)).name,
                    "path": path,
                    "size": e.get("size"),
                    "mtime": e.get("mtime"),
                    "tags": tags,
                    "rating": rating,
                }
            )
        except Exception:
            errors += 1
            continue

    elapsed = round(time.time() - t0, 2)
    print(
        f"[FAFO Meta] export-tags done · scanned={scanned} tagged={with_tags} "
        f"returned={len(items)} errors={errors} in {elapsed}s"
    )
    return {
        "ok": True,
        "items": items,
        "scanned": scanned,
        "with_tags": with_tags,
        "returned": len(items),
        "errors": errors,
        "total_indexed": total,
        "offset": start,
        "elapsed_sec": elapsed,
        "only_tagged": opts.only_tagged,
    }


def main() -> None:
    _install_quiet_access_logs()
    print("=" * 56)
    print("  FAFO Explorer Metadata Server")
    print(f"  http://{HOST}:{PORT}")
    print("  Keep this window open while using FAFO tags/ratings.")
    print("  Quiet mode: health/media/tags polls are not printed.")
    print("  Still shows: tag writes, rescans, and errors.")
    print("  Press Ctrl+C to stop.")
    print("=" * 56)
    # access log stays on; QuietPollFilter hides successful poll spam
    uvicorn.run(app, host=HOST, port=PORT, log_level="info", access_log=True)


def _no_window_flags() -> int:
    if os.name != "nt":
        return 0
    return int(
        getattr(subprocess, "CREATE_NO_WINDOW", 0)
        | getattr(subprocess, "DETACHED_PROCESS", 0)
        | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
    )


def _pid_alive(pid: int) -> bool:
    if int(pid or 0) <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x100000, False, int(pid))
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False
    except Exception:
        return False


def _health_ok() -> bool:
    try:
        with urllib.request.urlopen(f"http://{HOST}:{PORT}/api/health?probe=1", timeout=1.5) as r:
            return 200 <= r.status < 300
    except Exception:
        return False


def _demand_fresh(ttl_sec: float = 8 * 60) -> bool:
    try:
        base = Path(os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local"))
        path = base / "FAFO" / "demand-s2.json"
        raw = json.loads(path.read_text(encoding="utf-8"))
        at = float((raw or {}).get("at") or 0)
        return at > 0 and (time.time() - at) <= ttl_sec
    except Exception:
        return False


def run_watch() -> None:
    """Keep the Explorer metadata HTTP server up. Separate process from uvicorn."""
    data = Path(os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")) / "FAFO" / "ExplorerMeta"
    try:
        data.mkdir(parents=True, exist_ok=True)
    except OSError:
        data = ROOT
    mutex = None
    if os.name == "nt":
        try:
            import ctypes
            mutex = ctypes.windll.kernel32.CreateMutexW(None, True, "Local\\FAFOExplorerMetaWatch")
            if ctypes.windll.kernel32.GetLastError() == 183:
                return
        except Exception:
            mutex = None
    lock = data / "meta-watch.pid"
    stop = data / "stop.flag"
    me = os.getpid()
    if lock.is_file():
        try:
            old = int((lock.read_text(encoding="utf-8") or "0").strip() or 0)
        except ValueError:
            old = 0
        if old and old != me and _pid_alive(old):
            return
    try:
        lock.write_text(str(me), encoding="utf-8")
    except OSError:
        pass
    if stop.is_file():
        try:
            stop.unlink()
        except OSError:
            pass
    script = Path(__file__).resolve()
    cwd = str(script.parent)
    py = sys.executable
    stdout = data / "stdout.log"
    stderr = data / "stderr.log"
    child = None
    try:
        while not stop.is_file():
            if _health_ok():
                if not _demand_fresh():
                    if child is not None and child.poll() is None:
                        try:
                            child.terminate()
                        except Exception:
                            try:
                                child.kill()
                            except Exception:
                                pass
                        child = None
                    time.sleep(10)
                    continue
                time.sleep(8)
                continue
            if not _demand_fresh():
                time.sleep(10)
                continue
            if child is not None and child.poll() is None:
                try:
                    child.kill()
                except Exception:
                    pass
                child = None
                time.sleep(0.4)
            with stdout.open("a", encoding="utf-8") as out, stderr.open("a", encoding="utf-8") as err:
                kwargs: dict[str, Any] = {
                    "cwd": cwd,
                    "stdout": out,
                    "stderr": err,
                }
                if os.name == "nt":
                    kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
                child = subprocess.Popen([py, "-u", script.name], **kwargs)
            try:
                (data / "meta-server.pid").write_text(str(child.pid), encoding="utf-8")
            except OSError:
                pass
            for _ in range(50):
                if _health_ok() or child.poll() is not None or stop.is_file():
                    break
                time.sleep(0.2)
            while child.poll() is None and not stop.is_file():
                time.sleep(8)
                if not _demand_fresh():
                    try:
                        child.terminate()
                    except Exception:
                        pass
                    break
                if not _health_ok():
                    try:
                        child.kill()
                    except Exception:
                        pass
                    break
            time.sleep(1)
    finally:
        if child is not None and child.poll() is None:
            try:
                child.terminate()
            except Exception:
                pass
        try:
            if lock.is_file() and lock.read_text(encoding="utf-8").strip() == str(me):
                lock.unlink()
        except OSError:
            pass
        if mutex is not None:
            pass


if __name__ == "__main__":
    if "--watch" in sys.argv:
        run_watch()
    else:
        main()
