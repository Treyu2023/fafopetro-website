/**
 * FAFO library persistence — directory handles, permission restore, resync, smart playlists.
 * Shared by options.js and new-tab script.js.
 */
(function (global) {
    'use strict';

    const DB_NAME = 'NewTabMediaDB';
    /** v5: folder.space = 'public' | 'private' (isolated libraries)
     *  Private multi-vault: folder.vaultId (default 'default' when private + missing) */
    const DB_VERSION = 5;
    const VIDEO_RE = /\.(mp4|webm|mkv|mov|avi|m4v)$/i;
    const PHOTO_RE = /\.(jpg|jpeg|png|webp|gif|bmp)$/i;
    const DEFAULT_VAULT_ID = 'default';

    function normalizeSpace(space) {
        return space === 'private' ? 'private' : 'public';
    }

    function normalizeVaultId(vaultId) {
        const id = String(vaultId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 40);
        return id || DEFAULT_VAULT_ID;
    }

    function folderSpace(folder) {
        return normalizeSpace(folder?.space);
    }

    function folderVaultId(folder) {
        if (folderSpace(folder) !== 'private') return null;
        return normalizeVaultId(folder?.vaultId || DEFAULT_VAULT_ID);
    }

    function openDB() {
        return new Promise((resolve, reject) => {
            const req = indexedDB.open(DB_NAME, DB_VERSION);
            req.onblocked = () => console.warn('FAFO DB upgrade blocked — close other FAFO tabs');
            req.onupgradeneeded = (e) => {
                const d = e.target.result;
                ['videos', 'photos'].forEach((s) => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) {
                    d.createObjectStore('playlists', { keyPath: 'id' });
                }
                if (!d.objectStoreNames.contains('folders')) {
                    d.createObjectStore('folders', { keyPath: 'id' });
                }
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error || new Error('IDB open failed'));
        });
    }

    function idbReq(req) {
        return new Promise((resolve, reject) => {
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => reject(req.error);
        });
    }

    function txDone(tx) {
        return new Promise((resolve, reject) => {
            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
            tx.onabort = () => reject(tx.error || new Error('aborted'));
        });
    }

    /** Normalize stored video/photo record → { handle, name, parentFolderId, ... } */
    function unwrapFileEntry(val) {
        if (!val) return null;
        if (val instanceof File) {
            return { handle: val, name: val.name, size: val.size, lastModified: val.lastModified, legacy: true };
        }
        // New shape: { handle, name, parentFolderId, ... }
        if (val.handle && (typeof val.handle.getFile === 'function' || val.handle.kind === 'file')) {
            return {
                handle: val.handle,
                name: val.name || val.handle.name || 'Unknown',
                size: val.size,
                lastModified: val.lastModified,
                parentFolderId: val.parentFolderId || null,
                addedAt: val.addedAt,
            };
        }
        // Legacy: raw FileSystemFileHandle
        if (typeof val.getFile === 'function' || val.kind === 'file') {
            return { handle: val, name: val.name || 'Unknown', parentFolderId: null, legacy: true };
        }
        return null;
    }

    function withTimeout(promise, ms, label) {
        let t;
        const timeout = new Promise((resolve) => {
            t = setTimeout(() => resolve('__timeout__'), ms);
        });
        return Promise.race([promise, timeout]).then((v) => {
            clearTimeout(t);
            if (v === '__timeout__') {
                console.warn('permission wait timed out', label || '', ms);
                return 'timeout';
            }
            return v;
        });
    }

    /** True if Chrome will let us read this handle without a visible prompt. */
    async function canReadHandle(handle) {
        if (!handle) return false;
        if (handle instanceof File) return true;
        try {
            if (typeof handle.getFile === 'function') {
                await handle.getFile();
                return true;
            }
            if (typeof handle.values === 'function') {
                await handle.values().next();
                return true;
            }
            if (typeof handle.entries === 'function') {
                await handle.entries().next();
                return true;
            }
        } catch (_) {
            return false;
        }
        return false;
    }

    async function ensurePermission(handle, mode = 'read') {
        if (!handle) return false;
        // Blob File objects don't need permission
        if (handle instanceof File) return true;
        if (typeof handle.queryPermission !== 'function') return true;
        try {
            const opts = { mode };
            let state = await handle.queryPermission(opts);
            if (state === 'granted') return true;
            // Already readable (Chrome set not to re-prompt after setup)
            if (await canReadHandle(handle)) return true;
            // Always *request* grant. If Chrome shows Allow, user can click it.
            // If Chrome never shows a dialog (already allowed / prompts disabled),
            // requestPermission can hang — we keep that promise running and still
            // continue once the handle is readable or the request resolves.
            if (typeof handle.requestPermission !== 'function') return false;
            const permPromise = handle.requestPermission(opts);
            state = await withTimeout(permPromise, 4000, 'requestPermission');
            if (state === 'granted') return true;
            if (state !== 'timeout') {
                return state === 'granted' || (await canReadHandle(handle));
            }
            if (await canReadHandle(handle)) return true;
            state = await withTimeout(permPromise, 6000, 'requestPermission-late');
            if (state === 'granted') return true;
            return canReadHandle(handle);
        } catch (e) {
            console.warn('ensurePermission', e);
            return canReadHandle(handle);
        }
    }

    async function queryPermissionOnly(handle, mode = 'read') {
        if (!handle || handle instanceof File) return 'granted';
        if (typeof handle.queryPermission !== 'function') return 'granted';
        try {
            return await handle.queryPermission({ mode });
        } catch {
            return 'denied';
        }
    }

    async function getAllWithKeys(db, storeName) {
        return new Promise((resolve) => {
            try {
                const tx = db.transaction(storeName, 'readonly');
                const store = tx.objectStore(storeName);
                const items = [];
                const req = store.openCursor();
                req.onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor) {
                        items.push({ key: cursor.key, val: cursor.value });
                        cursor.continue();
                    } else resolve(items);
                };
                req.onerror = () => resolve([]);
            } catch {
                resolve([]);
            }
        });
    }

    /**
     * @param {IDBDatabase} db
     * @param {{ space?: 'public'|'private'|'all', vaultId?: string }} [opts]
     *   space omitted or 'all' → every folder; 'public'|'private' → filter (missing space = public)
     *   vaultId (private only): only folders for that private vault
     */
    async function listFolders(db, opts = {}) {
        if (!db.objectStoreNames.contains('folders')) return [];
        const rows = await getAllWithKeys(db, 'folders');
        const all = rows.map((r) => r.val).filter(Boolean);
        const space = opts.space;
        if (!space || space === 'all') return all;
        const want = normalizeSpace(space);
        let list = all.filter((f) => folderSpace(f) === want);
        if (want === 'private' && opts.vaultId) {
            const vid = normalizeVaultId(opts.vaultId);
            list = list.filter((f) => folderVaultId(f) === vid);
        }
        return list;
    }

    async function putFolder(db, folder) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').put(folder);
        await txDone(tx);
    }

    async function deleteFolderRecord(db, folderId) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').delete(folderId);
        await txDone(tx);
    }

    async function scanDirectory(dirHandle, regex) {
        const files = [];
        async function walk(dir) {
            for await (const entry of dir.values()) {
                if (entry.kind === 'file' && regex.test(entry.name)) {
                    files.push(entry);
                } else if (entry.kind === 'directory') {
                    try {
                        await walk(entry);
                    } catch (e) {
                        console.warn('scan skip dir', entry.name, e);
                    }
                }
            }
        }
        await walk(dirHandle);
        return files;
    }

    /**
     * Link a directory: persist the directory handle + index file handles under it.
     * @param {'videos'|'photos'} storeName
     * @param {FileSystemDirectoryHandle} dirHandle
     * @param {{ space?: 'public'|'private', vaultId?: string }} [opts]
     *   private folders never mix into public library; vaultId scopes multi private modes
     */
    async function linkFolder(db, storeName, dirHandle, opts = {}) {
        const kind = storeName === 'photos' ? 'photo' : 'video';
        const regex = kind === 'photo' ? PHOTO_RE : VIDEO_RE;
        const folderId = 'fld_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
        const ok = await ensurePermission(dirHandle, 'read');
        if (!ok) throw new Error('Permission denied for folder');
        try { await ensurePermission(dirHandle, 'readwrite'); } catch (_) {}
        const space = normalizeSpace(opts.space);
        const vaultId = space === 'private' ? normalizeVaultId(opts.vaultId || DEFAULT_VAULT_ID) : null;

        const fileHandles = await scanDirectory(dirHandle, regex);
        const folder = {
            id: folderId,
            kind,
            storeName,
            name: dirHandle.name || 'Folder',
            handle: dirHandle,
            space,
            vaultId: vaultId || undefined,
            addedAt: Date.now(),
            lastSyncedAt: Date.now(),
            fileCount: fileHandles.length,
        };
        await putFolder(db, folder);
        try {
            fetch('http://127.0.0.1:8765/api/library/ensure-folders', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ names: [dirHandle.name || folder.name].filter(Boolean) }),
                signal: AbortSignal.timeout(8000),
            }).catch(() => {});
        } catch (_) {}

        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        let added = 0;
        for (const fh of fileHandles) {
            const key = crypto.randomUUID();
            store.put(
                {
                    handle: fh,
                    name: fh.name,
                    parentFolderId: folderId,
                    space,
                    vaultId: vaultId || undefined,
                    addedAt: Date.now(),
                },
                key
            );
            added++;
        }
        await txDone(tx);
        return { folder, added };
    }

    /**
     * Media rows belonging to folders in the given space / private vault.
     * Legacy rows without parentFolderId / space count as public only.
     * @param {'public'|'private'} space
     * @param {{ vaultId?: string }} [opts] — required for multi private modes (defaults to 'default')
     */
    async function getMediaForSpace(db, storeName, space, opts = {}) {
        const want = normalizeSpace(space);
        const wantVault = want === 'private' ? normalizeVaultId(opts.vaultId || DEFAULT_VAULT_ID) : null;
        const privateFolders = await listFolders(db, { space: 'private' });
        const privateIds = new Set(
            privateFolders
                .filter((f) => !wantVault || folderVaultId(f) === wantVault)
                .map((f) => f.id)
        );
        const allPrivateIds = new Set(privateFolders.map((f) => f.id));
        const publicIds = new Set(
            (await listFolders(db, { space: 'public' })).map((f) => f.id)
        );
        const rows = await getAllWithKeys(db, storeName);
        const out = [];
        for (const row of rows) {
            const entry = unwrapFileEntry(row.val);
            if (!entry) continue;
            const raw = row.val && typeof row.val === 'object' ? row.val : {};
            const pf = entry.parentFolderId || raw.parentFolderId || null;
            const rowSpace = raw.space || entry.space || null;
            const rowVault = normalizeVaultId(raw.vaultId || entry.vaultId || DEFAULT_VAULT_ID);
            let include = false;
            if (want === 'private') {
                // This private vault only — never other private vaults or public
                if (pf && privateIds.has(pf)) include = true;
                else if (rowSpace === 'private' && rowVault === wantVault) include = true;
                else include = false;
            } else {
                // Public: never any private folder / private-marked rows
                if (rowSpace === 'private') include = false;
                else if (pf && allPrivateIds.has(pf)) include = false;
                else if (pf && publicIds.has(pf)) include = true;
                else if (!pf) include = true; // legacy unscoped → public
                else include = true; // unknown parent → treat public
            }
            if (include) {
                out.push({
                    key: row.key,
                    handle: entry.handle,
                    name: entry.name,
                    size: entry.size,
                    lastModified: entry.lastModified,
                    parentFolderId: pf,
                    space: want,
                    vaultId: wantVault || undefined,
                    storeName,
                    addedAt: entry.addedAt,
                });
            }
        }
        return out;
    }

    /** Remove all media rows that belong to a parent folder id. */
    async function clearMediaForFolder(db, storeName, folderId) {
        const rows = await getAllWithKeys(db, storeName);
        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        for (const row of rows) {
            const entry = unwrapFileEntry(row.val);
            if (entry?.parentFolderId === folderId) {
                store.delete(row.key);
            }
        }
        await txDone(tx);
    }

    /**
     * Re-scan a saved directory handle into the media store (does not re-pick folder).
     */
    async function resyncFolder(db, folderId, opts = {}) {
        const folders = await listFolders(db);
        const folder = folders.find((f) => f.id === folderId);
        if (!folder?.handle) throw new Error('Folder not found or missing handle');

        const granted = opts.skipPermission || (await ensurePermission(folder.handle, 'read'));
        if (!granted) throw new Error('Permission not granted — click Restore Access first');

        const regex = folder.kind === 'photo' ? PHOTO_RE : VIDEO_RE;
        const storeName = folder.storeName || (folder.kind === 'photo' ? 'photos' : 'videos');
        const fileHandles = await scanDirectory(folder.handle, regex);

        await clearMediaForFolder(db, storeName, folderId);

        const tx = db.transaction(storeName, 'readwrite');
        const store = tx.objectStore(storeName);
        for (const fh of fileHandles) {
            store.put(
                {
                    handle: fh,
                    name: fh.name,
                    parentFolderId: folderId,
                    addedAt: Date.now(),
                },
                crypto.randomUUID()
            );
        }
        await txDone(tx);

        folder.fileCount = fileHandles.length;
        folder.lastSyncedAt = Date.now();
        await putFolder(db, folder);
        return { folder, count: fileHandles.length };
    }

    async function resyncAllFolders(db, opts = {}) {
        const folders = await listFolders(db);
        const results = [];
        for (const f of folders) {
            // Chrome art is not a media library folder
            if (f.kind === 'chrome-art' || f.id === 'chrome-art') {
                results.push({ id: f.id, name: f.name, ok: true, count: 0, skipped: 'chrome-art' });
                continue;
            }
            try {
                const r = await resyncFolder(db, f.id, opts);
                results.push({ id: f.id, name: f.name, ok: true, count: r.count });
            } catch (e) {
                results.push({ id: f.id, name: f.name, ok: false, error: e.message || String(e) });
            }
        }
        return results;
    }

    /**
     * Request permission on every saved folder (+ sample file handles if no folders).
     * Must be called from a user gesture.
     */
    async function restoreAccess(db) {
        const folders = await listFolders(db);
        let grantedFolders = 0;
        let deniedFolders = 0;
        for (const f of folders) {
            if (!f.handle) {
                deniedFolders++;
                continue;
            }
            const ok = await ensurePermission(f.handle, 'read');
            if (ok) grantedFolders++;
            else deniedFolders++;
        }

        // Also re-authorize individual file handles (legacy libraries without folder records)
        let grantedFiles = 0;
        let deniedFiles = 0;
        for (const storeName of ['videos', 'photos']) {
            const rows = await getAllWithKeys(db, storeName);
            for (const row of rows) {
                const entry = unwrapFileEntry(row.val);
                if (!entry?.handle || entry.handle instanceof File) continue;
                // Skip if already covered by a granted parent folder
                if (entry.parentFolderId && folders.some((f) => f.id === entry.parentFolderId)) {
                    continue;
                }
                const ok = await ensurePermission(entry.handle, 'read');
                if (ok) grantedFiles++;
                else deniedFiles++;
            }
        }

        return { grantedFolders, deniedFolders, grantedFiles, deniedFiles, folderCount: folders.length };
    }

    /** Check if any library handle currently lacks permission (no prompt). */
    async function libraryAccessStatus(db) {
        const folders = await listFolders(db);
        let folderGranted = 0;
        let folderPrompt = 0;
        let folderDenied = 0;
        for (const f of folders) {
            const st = await queryPermissionOnly(f.handle);
            if (st === 'granted' || await canReadHandle(f.handle)) folderGranted++;
            else if (st === 'prompt') folderPrompt++;
            else folderDenied++;
        }

        let sampleOk = 0;
        let sampleBad = 0;
        for (const storeName of ['videos', 'photos']) {
            const rows = await getAllWithKeys(db, storeName);
            const sample = rows.slice(0, 8);
            for (const row of sample) {
                const entry = unwrapFileEntry(row.val);
                if (!entry?.handle) continue;
                if (entry.handle instanceof File) {
                    sampleOk++;
                    continue;
                }
                const st = await queryPermissionOnly(entry.handle);
                if (st === 'granted' || await canReadHandle(entry.handle)) sampleOk++;
                else sampleBad++;
            }
        }

        const needsRestore =
            folderPrompt > 0 ||
            folderDenied > 0 ||
            (folders.length === 0 && sampleBad > 0) ||
            (sampleOk === 0 && sampleBad > 0);

        return {
            folders: folders.length,
            folderGranted,
            folderPrompt,
            folderDenied,
            sampleOk,
            sampleBad,
            needsRestore,
        };
    }

    // --- Smart playlists ---

    function normalizeTags(list) {
        if (!list) return [];
        if (typeof list === 'string') {
            return list
                .split(/[,;]+/)
                .map((t) => t.trim())
                .filter(Boolean);
        }
        return (Array.isArray(list) ? list : []).map((t) => String(t).trim()).filter(Boolean);
    }

    function metaForFile(mediaMeta, name, size, lastModified) {
        if (!mediaMeta) return null;
        if (name != null && size != null && lastModified != null) {
            const key = `file:${name}|${size}|${lastModified}`;
            if (mediaMeta[key]) return mediaMeta[key];
        }
        const low = String(name || '').toLowerCase();
        for (const v of Object.values(mediaMeta)) {
            if (v && v.name && String(v.name).toLowerCase() === low) return v;
        }
        return null;
    }

    function matchesSmartRules(meta, rules) {
        if (!rules) return true;
        const rating = meta?.rating != null ? Number(meta.rating) : 0;
        const tags = (meta?.tags || []).map((t) => String(t).toLowerCase());

        if (rules.untaggedOnly) {
            if (tags.length > 0) return false;
        }
        if (rules.minRating != null && rules.minRating > 0) {
            if (rating < Number(rules.minRating)) return false;
        }
        if (rules.maxRating != null && rules.maxRating !== '' && Number(rules.maxRating) >= 0) {
            if (rating > Number(rules.maxRating)) return false;
        }
        const want = normalizeTags(rules.tags).map((t) => t.toLowerCase());
        if (want.length) {
            const mode = rules.tagsMode === 'all' ? 'all' : 'any';
            if (mode === 'all') {
                if (!want.every((t) => tags.includes(t))) return false;
            } else if (!want.some((t) => tags.includes(t))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Expand a smart playlist against library rows + fafoMediaMeta.
     * @returns {Promise<Array<{type, handle, name, key, storeName}>>}
     */
    async function resolveSmartPlaylist(db, playlist, mediaMeta) {
        if (!playlist || playlist.type !== 'smart') return [];
        const rules = playlist.rules || {};
        const media = rules.media || 'video';
        const stores = [];
        if (media === 'photo' || media === 'both' || media === 'all') stores.push(['photos', 'photo']);
        if (media === 'video' || media === 'both' || media === 'all' || !rules.media) stores.push(['videos', 'video']);

        const out = [];
        for (const [storeName, type] of stores) {
            const rows = await getAllWithKeys(db, storeName);
            for (const row of rows) {
                const entry = unwrapFileEntry(row.val);
                if (!entry?.handle) continue;
                let name = entry.name;
                let size = entry.size;
                let lm = entry.lastModified;
                try {
                    if (typeof entry.handle.getFile === 'function') {
                        const f = await entry.handle.getFile();
                        name = f.name;
                        size = f.size;
                        lm = f.lastModified;
                    }
                } catch {
                    // permission missing — still try name-only meta match
                }
                const meta = metaForFile(mediaMeta, name, size, lm);
                if (matchesSmartRules(meta, rules)) {
                    out.push({
                        type,
                        handle: entry.handle,
                        name,
                        key: row.key,
                        storeName,
                    });
                }
            }
        }
        return out;
    }

    /** Manual playlist items → handles */
    async function resolveManualPlaylist(db, playlist) {
        if (!playlist?.items?.length) return [];
        const out = [];
        for (const ref of playlist.items) {
            const storeName = ref.store || ref.storeName || 'videos';
            try {
                const tx = db.transaction(storeName, 'readonly');
                const raw = await idbReq(tx.objectStore(storeName).get(ref.key));
                const entry = unwrapFileEntry(raw);
                if (entry?.handle) {
                    out.push({
                        type: storeName === 'photos' ? 'photo' : 'video',
                        handle: entry.handle,
                        name: entry.name,
                        key: ref.key,
                        storeName,
                    });
                }
            } catch {
                /* skip */
            }
        }
        return out;
    }

    async function resolvePlaylist(db, playlist, mediaMeta) {
        if (!playlist) return [];
        if (playlist.type === 'smart') return resolveSmartPlaylist(db, playlist, mediaMeta || {});
        return resolveManualPlaylist(db, playlist);
    }

    async function getAllMediaEntries(db, storeName) {
        const rows = await getAllWithKeys(db, storeName);
        return rows
            .map((r) => {
                const entry = unwrapFileEntry(r.val);
                if (!entry) return null;
                return { key: r.key, ...entry, storeName };
            })
            .filter(Boolean);
    }

    /**
     * Serializable catalog for JSON backup (no FileSystemHandles — those cannot be restored from JSON).
     * Playlists + file index (name/size/keys) + folder metadata.
     */
    async function exportSerializableCatalog(db) {
        if (!db) {
            try { db = await openDB(); } catch { return null; }
        }
        const playlists = db.objectStoreNames.contains('playlists')
            ? (await getAllWithKeys(db, 'playlists')).map((r) => r.val).filter(Boolean)
            : [];
        const serializeMedia = async (storeName) => {
            if (!db.objectStoreNames.contains(storeName)) return [];
            const rows = await getAllWithKeys(db, storeName);
            return rows.map(({ key, val }) => {
                const u = unwrapFileEntry(val);
                return {
                    store: storeName,
                    key,
                    name: u?.name || val?.name || '',
                    size: u?.size ?? val?.size ?? null,
                    lastModified: u?.lastModified ?? val?.lastModified ?? null,
                    parentFolderId: u?.parentFolderId || val?.parentFolderId || null,
                    addedAt: u?.addedAt || val?.addedAt || null,
                };
            });
        };
        const videos = await serializeMedia('videos');
        const photos = await serializeMedia('photos');
        let folders = [];
        if (db.objectStoreNames.contains('folders')) {
            const rows = await getAllWithKeys(db, 'folders');
            folders = rows.map(({ val }) => ({
                id: val?.id,
                name: val?.name || val?.label || '',
                pathHint: val?.pathHint || val?.path || '',
                addedAt: val?.addedAt || null,
                kind: val?.kind || 'directory',
                // handles intentionally omitted
            })).filter((f) => f.id);
        }
        return {
            playlists,
            libraryCatalog: {
                videos,
                photos,
                folders,
                videoCount: videos.length,
                photoCount: photos.length,
                exportedAt: Date.now(),
            },
        };
    }

    async function importPlaylistsFromBackup(db, playlists, opts = {}) {
        if (!db || !Array.isArray(playlists) || !playlists.length) return 0;
        const merge = opts.merge !== false;
        const tx = db.transaction('playlists', 'readwrite');
        const store = tx.objectStore('playlists');
        if (!merge) {
            await idbReq(store.clear());
        }
        let n = 0;
        for (const p of playlists) {
            if (!p || !p.id) continue;
            store.put(p);
            n++;
        }
        await txDone(tx);
        return n;
    }

    global.FAFOLibrary = {
        DB_NAME,
        DB_VERSION,
        VIDEO_RE,
        PHOTO_RE,
        openDB,
        unwrapFileEntry,
        ensurePermission,
        canReadHandle,
        queryPermissionOnly,
        getAllWithKeys,
        listFolders,
        putFolder,
        deleteFolderRecord,
        scanDirectory,
        linkFolder,
        getMediaForSpace,
        normalizeSpace,
        normalizeVaultId,
        folderSpace,
        folderVaultId,
        DEFAULT_VAULT_ID,
        resyncFolder,
        resyncAllFolders,
        restoreAccess,
        libraryAccessStatus,
        normalizeTags,
        metaForFile,
        matchesSmartRules,
        resolveSmartPlaylist,
        resolveManualPlaylist,
        resolvePlaylist,
        getAllMediaEntries,
        clearMediaForFolder,
        exportSerializableCatalog,
        importPlaylistsFromBackup,
    };
})(typeof window !== 'undefined' ? window : globalThis);
