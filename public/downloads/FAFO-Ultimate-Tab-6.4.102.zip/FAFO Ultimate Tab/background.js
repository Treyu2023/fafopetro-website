// FAFO Ultimate Tab — service worker (context menu + action + companion auto-start)

// Open Options when the toolbar icon is clicked
chrome.action.onClicked.addListener(() => {
    const url = chrome.runtime.getURL('options.html');
    chrome.windows.create({
        url,
        type: 'normal',
        focused: true,
        state: 'maximized'
    }, (win) => {
        if (chrome.runtime.lastError || !win) {
            try { chrome.runtime.openOptionsPage(); }
            catch (e) { chrome.tabs.create({ url }); }
        }
    });
});

// 1. Init Context Menu
chrome.runtime.onInstalled.addListener(() => {
    try {
        chrome.contextMenus.removeAll(() => {
            chrome.contextMenus.create({
                id: "fafo-save-media",
                title: "⚡ Add to FAFO Library",
                contexts: ["image", "video", "audio"]
            });
        });
    } catch (e) {
        chrome.contextMenus.create({
            id: "fafo-save-media",
            title: "⚡ Add to FAFO Library",
            contexts: ["image", "video", "audio"]
        });
    }
});

// 2. Handle Clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === "fafo-save-media") {
        const url = info.srcUrl;
        if (!url) return;

        // Notify user via badge
        chrome.action.setBadgeText({text: "⬇️"});
        chrome.action.setBadgeBackgroundColor({ color: "#00e5ff" });
        
        try {
            const type = info.mediaType === 'video' ? 'videos' : 'photos';
            await downloadAndStore(url, type);
            
            chrome.action.setBadgeText({text: "✔"});
            chrome.action.setBadgeBackgroundColor({ color: "#00ff00" });
            
            setTimeout(() => chrome.action.setBadgeText({text: ""}), 3000);
        } catch (e) {
            console.error("Save failed", e);
            chrome.action.setBadgeText({text: "ERR"});
            chrome.action.setBadgeBackgroundColor({ color: "#ff0000" });
            setTimeout(() => chrome.action.setBadgeText({text: ""}), 5000);
        }
    }
});

// 3. Download & Store Logic
async function downloadAndStore(url, storeName) {
    try {
        // Fetch blob
        const resp = await fetch(url);
        if (!resp.ok) throw new Error(`HTTP error! status: ${resp.status}`);
        const blob = await resp.blob();
        
        // Generate filename from URL or Timestamp
        const typePart = blob.type.split('/')[1] || 'dat';
        // Clean URL to make a safe filename
        const cleanUrl = url.split('/').pop().split('?')[0].substring(0, 30).replace(/[^a-zA-Z0-9._-]/g, '_');
        const filename = `webclip_${Date.now()}_${cleanUrl}.${typePart}`;
        
        // Create File object (Shim for IndexedDB storage)
        const file = new File([blob], filename, { type: blob.type });

        // Open DB & Save
        return new Promise((resolve, reject) => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            
            req.onupgradeneeded = e => {
                const d = e.target.result;
                if (!d.objectStoreNames.contains('videos')) d.createObjectStore('videos', {autoIncrement: true});
                if (!d.objectStoreNames.contains('photos')) d.createObjectStore('photos', {autoIncrement: true});
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', {keyPath: 'id'});
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', {keyPath: 'id'});
            };

            req.onsuccess = () => {
                const db = req.result;
                const tx = db.transaction(storeName, 'readwrite');
                const store = tx.objectStore(storeName);
                store.put(file, crypto.randomUUID());
                
                tx.oncomplete = () => resolve();
                tx.onerror = e => reject(e);
            };
            
            req.onerror = e => reject(e);
        });
    } catch (err) {
        throw err;
    }
}

const COMPANION_HEALTH = 'http://127.0.0.1:8765/api/health';
const COMPANION_APPLY = 'http://127.0.0.1:8765/api/fafo/ledger/apply';
const NATIVE_HOST = 'com.fafo.companion';

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

async function companionHealthy(probe) {
    try {
        const url = COMPANION_HEALTH + (probe ? '?probe=1' : '');
        const r = await fetch(url, { signal: AbortSignal.timeout(1500) });
        if (!r.ok) return false;
        const j = await r.json().catch(() => ({}));
        const svc = String((j && j.service) || '');
        if (svc && !/fafo/i.test(svc)) return false;
        return true;
    } catch {
        return false;
    }
}

async function applySalvageLedger() {
    for (const space of ['public', 'private']) {
        try {
            await fetch(COMPANION_APPLY, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ space }),
                signal: AbortSignal.timeout(120000),
            });
        } catch (_) {}
    }
}

function nativeBoot(delay) {
    return new Promise((resolve) => {
        try {
            chrome.runtime.sendNativeMessage(
                NATIVE_HOST,
                { op: 'boot', delay: delay || 0.3 },
                (res) => {
                    if (chrome.runtime.lastError) {
                        resolve({ ok: false, error: chrome.runtime.lastError.message });
                        return;
                    }
                    resolve(res && typeof res === 'object' ? res : { ok: true });
                }
            );
        } catch (e) {
            resolve({ ok: false, error: e.message || String(e) });
        }
    });
}

const PROTOCOL_MIN_MS = 60000;
const PROTOCOL_MAX_ATTEMPTS = 2;
const USER_BOOT_REASONS = new Set(['status-click', 's2-chip', 'graffiti-pip']);
const selfProtocolTabIds = new Set();

let companionKickBusy = false;
let lastProtocolKick = 0;
let protocolAttempts = 0;

function nativeLooksUp(native) {
    return !!(native && (native.ok || native.healthy));
}

async function protocolBoot() {
    const now = Date.now();
    if (protocolAttempts >= PROTOCOL_MAX_ATTEMPTS) return false;
    if (now - lastProtocolKick < PROTOCOL_MIN_MS) return false;
    lastProtocolKick = now;
    protocolAttempts += 1;
    const id = chrome.runtime.id || '';
    const url = 'fafo-companion://boot/' + id;
    try {
        const tab = await chrome.tabs.create({ url, active: false });
        if (tab && tab.id) selfProtocolTabIds.add(tab.id);
        setTimeout(() => {
            if (tab && tab.id) {
                chrome.tabs.remove(tab.id).catch(() => {});
                selfProtocolTabIds.delete(tab.id);
            }
        }, 600);
        return true;
    } catch {
        return false;
    }
}

const POLL_ONLY_REASONS = new Set(['alarm', 'sw-boot', 'startup']);

async function bootCompanionStack(reason, opts = {}) {
    const userForce = !!(opts && opts.force) && USER_BOOT_REASONS.has(reason);
    const pollOnly = POLL_ONLY_REASONS.has(reason) && !userForce;
    // Watchdog / SW ticks use probe=1 so they do not keep S2 "in use" forever.
    if (await companionHealthy(true)) {
        if (!pollOnly) {
            setTimeout(() => { applySalvageLedger().catch(() => {}); }, 800);
        }
        return { ok: true, via: 'already-up', reason };
    }
    if (pollOnly) {
        return { ok: false, via: 'idle', reason };
    }
    if (companionKickBusy) {
        return { ok: false, via: 'busy', reason };
    }
    companionKickBusy = true;
    try {
        const native = await nativeBoot(0.3).catch(() => ({ ok: false }));
        if (nativeLooksUp(native)) {
            applySalvageLedger().catch(() => {});
            try { chrome.runtime.sendMessage({ type: 'fafo-companion-up' }).catch(() => {}); } catch (_) {}
            return { ok: true, via: 'native', reason };
        }
        // Protocol tabs must never run from tab-created / poll / alarm.
        // Opening fafo-companion:// via tabs.create used to bounce into newtab.html
        // and retrigger this boot (tab storm).
        const allowProtocol = userForce || reason === 'installed' || reason === 'newtab';
        if (allowProtocol) {
            await protocolBoot();
        }
        for (let i = 0; i < 22; i += 1) {
            await sleep(400);
            if (await companionHealthy(false) || nativeLooksUp(native)) {
                applySalvageLedger().catch(() => {});
                try { chrome.runtime.sendMessage({ type: 'fafo-companion-up' }).catch(() => {}); } catch (_) {}
                return { ok: true, via: allowProtocol ? 'protocol' : 'native', reason };
            }
        }
        return { ok: false, via: (native && native.error) || 'offline', reason };
    } finally {
        companionKickBusy = false;
    }
}

chrome.runtime.onStartup.addListener(() => { bootCompanionStack('startup'); });
chrome.runtime.onInstalled.addListener(() => { bootCompanionStack('installed'); });
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.type !== 'fafo-boot-stack') return;
    bootCompanionStack(msg.reason || 'newtab', { force: !!msg.force }).then((r) => {
        try { sendResponse(r); } catch (_) {}
    });
    return true;
});

try {
    chrome.alarms.create('fafo-companion-watch', { periodInMinutes: 1 });
} catch (_) {}
chrome.alarms.onAlarm.addListener((alarm) => {
    if (!alarm || alarm.name !== 'fafo-companion-watch') return;
    bootCompanionStack('alarm');
});
chrome.tabs.onCreated.addListener((tab) => {
    try {
        if (tab && selfProtocolTabIds.has(tab.id)) return;
        const url = String(tab.url || tab.pendingUrl || '');
        if (!url || url.startsWith('fafo-companion:')) return;
        const extNewtab = chrome.runtime.getURL('newtab.html');
        if (url.startsWith('chrome://newtab') || url === extNewtab || url.endsWith('/newtab.html')) {
            bootCompanionStack('tab-created');
        }
    } catch (_) {}
});
chrome.tabs.onRemoved.addListener((tabId) => {
    selfProtocolTabIds.delete(tabId);
});

bootCompanionStack('sw-boot').catch(() => {});
