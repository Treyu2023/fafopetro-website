/**
 * FAFO Undo — last N tag/rating mutations (Ctrl+Z / Back button).
 * Supports single-file and multi-file batch restores.
 */
(function (global) {
  'use strict';

  const MAX = 50;
  /**
   * @type {{
   *   id:string,
   *   label:string,
   *   key?:string,
   *   before?:{rating:number,tags:string[],pairId?:string},
   *   batch?:{key:string,before:{rating:number,tags:string[],pairId?:string}}[],
   *   at:number
   * }[]}
   */
  const stack = [];
  let toastEl = null;
  let toastTimer = null;
  const listeners = new Set();

  function ensureToast() {
    if (toastEl && document.contains(toastEl)) return toastEl;
    toastEl = document.createElement('div');
    toastEl.id = 'fafo-undo-toast';
    toastEl.className = 'fafo-undo-toast hidden';
    toastEl.innerHTML =
      '<span class="fafo-undo-msg"></span>' +
      '<button type="button" class="fafo-undo-btn">Back · Undo</button>';
    document.body.appendChild(toastEl);
    toastEl.querySelector('.fafo-undo-btn')?.addEventListener('click', () => {
      undo();
    });
    return toastEl;
  }

  function showToast(msg) {
    const el = ensureToast();
    const m = el.querySelector('.fafo-undo-msg');
    if (m) m.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.classList.add('hidden'), 4200);
  }

  function snapshotMeta(key, rating, tags, pairId) {
    return {
      rating: Math.max(0, Math.min(5, Number(rating) || 0)),
      tags: Array.isArray(tags) ? tags.slice() : [],
      pairId: pairId || '',
    };
  }

  function notify() {
    try {
      global.dispatchEvent(new CustomEvent('fafo:undo-stack', {
        detail: { size: stack.length, canUndo: stack.length > 0, peek: peek() },
      }));
    } catch (_) {}
    listeners.forEach((fn) => {
      try { fn({ size: stack.length, canUndo: stack.length > 0, peek: peek() }); } catch (_) {}
    });
  }

  /**
   * Push before a mutation. Call with the *previous* state of one file.
   */
  function push(entry) {
    if (!entry || !entry.key) return;
    stack.push({
      id: 'u_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6),
      label: entry.label || 'Edit',
      key: entry.key,
      before: snapshotMeta(entry.key, entry.rating, entry.tags, entry.pairId),
      at: Date.now(),
    });
    while (stack.length > MAX) stack.shift();
    notify();
  }

  /**
   * Push a multi-file batch (one Back undoes the whole bulk op).
   * @param {{ label?:string, items:{key:string,rating?:number,tags?:string[],pairId?:string}[] }} entry
   */
  function pushBatch(entry) {
    const items = Array.isArray(entry?.items) ? entry.items : [];
    const batch = items
      .filter((it) => it && it.key)
      .map((it) => ({
        key: it.key,
        before: snapshotMeta(it.key, it.rating, it.tags, it.pairId),
      }));
    if (!batch.length) return;
    // Single-file batch degrades to normal push shape for simplicity
    if (batch.length === 1) {
      push({
        key: batch[0].key,
        label: entry.label || 'Edit',
        rating: batch[0].before.rating,
        tags: batch[0].before.tags,
        pairId: batch[0].before.pairId,
      });
      return;
    }
    stack.push({
      id: 'u_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 6),
      label: entry.label || `Bulk · ${batch.length} files`,
      batch,
      at: Date.now(),
    });
    while (stack.length > MAX) stack.shift();
    notify();
  }

  function canUndo() {
    return stack.length > 0;
  }

  function peek() {
    return stack.length ? stack[stack.length - 1] : null;
  }

  async function undo() {
    const item = stack.pop();
    notify();
    if (!item) {
      showToast('Nothing to undo');
      return { ok: false, empty: true };
    }
    try {
      if (!global.FAFOMeta?.restoreMetaSnapshot) {
        showToast('Undo unavailable');
        return { ok: false };
      }
      if (Array.isArray(item.batch) && item.batch.length) {
        // Restore oldest→newest within the batch so last write wins on shared keys
        for (const part of item.batch) {
          await FAFOMeta.restoreMetaSnapshot(part.key, part.before, { fromUndo: true });
        }
        showToast(`Undid: ${item.label} (${item.batch.length} files) · ${stack.length} left`);
      } else if (item.key && item.before) {
        await FAFOMeta.restoreMetaSnapshot(item.key, item.before, { fromUndo: true });
        showToast(`Undid: ${item.label} · ${stack.length} left`);
      } else {
        showToast('Undo entry incomplete');
        return { ok: false };
      }
      try {
        global.dispatchEvent(new CustomEvent('fafo:undo', { detail: item }));
      } catch (_) {}
      notify();
      return { ok: true, item };
    } catch (e) {
      console.warn('FAFO undo', e);
      showToast('Undo failed');
      return { ok: false, error: e };
    }
  }

  function clear() {
    stack.length = 0;
    notify();
  }

  function onChange(fn) {
    if (typeof fn === 'function') listeners.add(fn);
    return () => listeners.delete(fn);
  }

  global.FAFOUndo = {
    push,
    pushBatch,
    undo,
    canUndo,
    peek,
    clear,
    showToast,
    stackSize: () => stack.length,
    max: MAX,
    onChange,
  };
})(typeof window !== 'undefined' ? window : globalThis);
