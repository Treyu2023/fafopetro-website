document.addEventListener('DOMContentLoaded', async () => {
    const $ = id => document.getElementById(id);
    let db = null;
    let currentConfig = {};
    let editingFile = null;

    // --- STATE ---
    let currentPage = 1;
    let itemsPerPage = 50;
    let allLibraryItems = []; 
    let activePlaylistView = 'all'; 

    // --- TOAST NOTIFICATION SYSTEM ---
    function showToast(msg, type = 'success') {
        const status = $('save-status');
        if (!status) return;
        status.textContent = msg;
        status.style.borderColor = type === 'error' ? '#ff4444' : '#00e5ff';
        status.style.color = type === 'error' ? '#ff4444' : '#00e5ff';
        status.style.display = 'block';
        setTimeout(() => status.style.display = 'none', 3000);
    }

    // --- THUMBNAIL QUEUE SYSTEM ---
    const thumbQueue = {
        active: 0, queue: [], limit: 3,
        add: function(file, imgElement) { this.queue.push({file, imgElement}); this.process(); },
        process: async function() {
            if (this.active >= this.limit || this.queue.length === 0) return;
            this.active++;
            const task = this.queue.shift();
            try {
                const url = await generateThumbnail(task.file);
                if (url) task.imgElement.src = url;
            } catch(e) { console.log("Thumb gen failed", e); } finally { this.active--; this.process(); }
        }
    };

    // --- TABS SYSTEM ---
    document.querySelectorAll('.tab').forEach(t => {
        t.onclick = () => {
            document.querySelectorAll('.tab').forEach(x => x.classList.remove('active'));
            document.querySelectorAll('.view-section').forEach(x => x.classList.remove('active'));
            t.classList.add('active');
            const target = $(t.dataset.target);
            if(target) target.classList.add('active');
            if (t.dataset.target === 'view-library') loadLibraryGrid();
            if (t.dataset.target === 'view-playlists') loadPlaylistsUI();
            if (t.dataset.target === 'view-pairing' && window.FAFOPairs) {
                FAFOPairs.onActivate({ db });
            }
            if (t.dataset.target === 'view-backup') refreshTagsBackupUI();
        };
    });

    // --- SLIDERS UI ---
    function initSliders() {
        document.querySelectorAll('input[type=range]').forEach(el => {
            const span = document.getElementById(el.id + '-val');
            if(span) {
                span.textContent = el.value;
                el.addEventListener('input', () => span.textContent = el.value);
            }
        });
    }

    // --- THEME ENGINE ---
    function applyTheme(hex) {
        if (!hex) return;
        const root = document.documentElement;
        const hexToRgb = (h) => {
            const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
            h = h.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
            const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(h);
            return result ? { r: parseInt(result[1], 16), g: parseInt(result[2], 16), b: parseInt(result[3], 16) } : null;
        };
        const rgb = hexToRgb(hex);
        if (rgb) {
            root.style.setProperty('--accent', hex);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }
    }

    // --- DB INIT (v4: folders store for persistent directory handles) ---
    async function openDB() {
        try {
            if (window.FAFOLibrary?.openDB) {
                db = await FAFOLibrary.openDB();
                return db;
            }
        } catch (e) {
            console.error('FAFOLibrary openDB', e);
            if (/blocked|version/i.test(String(e))) {
                alert('Database upgrade blocked — close other FAFO / New Tab windows and reload Options.');
            }
        }
        return new Promise((res) => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            req.onblocked = () => alert('Database Upgrade Blocked! Close other New Tab pages and reload.');
            req.onupgradeneeded = (e) => {
                const d = e.target.result;
                ['videos', 'photos'].forEach((s) => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', { keyPath: 'id' });
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = () => { db = req.result; res(db); };
            req.onerror = (e) => { console.error('DB Error', e); res(null); };
        });
    }

    // --- LOAD SETTINGS ---
    async function loadSettings() {
        await openDB();
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        
        const defaults = {
            useLocal: true, usePhotos: true, urls: [], 
            layout: 'cinema', scaling: 'scale-capped',
            gridCols: 4, gridRows: 1, 
            carouselRadius: 650, carouselTilt: 0, carouselSpeed: 40,
            reflectOpacity: 30, reflectOffset: 0,

            neonBorder: false, neonPattern: 'chase', neonSegments: 24,
            neonSpeed: 1, neonAudio: true, neonStrobe: 0.8,
            neonSensitivity: 1.2, neonWidth: 4, neonUseAccent: true, neonColor: '#00e5ff',
            
            // FX DEFAULTS
            fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
            fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
            fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
            fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
            fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
            fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,

            brightness: 100, contrast: 100, saturate: 100, sepia: 0, grayscale: 0,
            ambiScale: 1.0, ambiOpacity: 0.25, ambiBlur: 5, ambiMode: 'blur',
            borderSize: 0, borderColor: '#44858d', borderGlow: 15,
            volume: 0.0, photoDuration: 3, shuffle: true,
            clockSize: 25, font: "'Arial Black', sans-serif", pos: 'pos-bottom-left',
            showDate: true, format12h: true, showSeconds: false,
            accentColor: '#00e5ff', activePlaylistId: 'all', overrides: {},
            performanceMode: false,
            maxDisplayHeight: 1080,
            disableAmbience: false,
            disableParticles: false,
            disableCssFilters: false,
            disableNeonAudio: false,
        };

        currentConfig = {...defaults, ...mediaConfig};
        applyTheme(currentConfig.accentColor);

        const set = (id, val, type) => {
            const el = $(id);
            if(!el) return;
            if (type === 'check') el.checked = val;
            else if (type === 'val') el.value = val;
            else if (type === 'array') el.value = (val || []).join('\n'); 
            else el.value = val;
            
            if(el.type === 'range') {
                const span = document.getElementById(el.id + '-val');
                if(span) span.textContent = val;
            }
        };

        // Basic fields
        Object.keys(currentConfig).forEach(k => {
            if(k === 'overrides') return;
            const el = $(k);
            if(el) set(k, currentConfig[k], el.type === 'checkbox' ? 'check' : (k === 'urls' ? 'array' : 'val'));
        });
        
        // Manual Mappings
        set('grid-cols', currentConfig.gridCols); set('grid-rows', currentConfig.gridRows);
        set('carousel-radius', currentConfig.carouselRadius); set('carousel-tilt', currentConfig.carouselTilt);
        set('carousel-speed', currentConfig.carouselSpeed); set('reflect-opacity', currentConfig.reflectOpacity);
        set('reflect-offset', currentConfig.reflectOffset);

        // Dynamic FX Loading
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            set(`fx-${type}`, currentConfig[camelCase(`fx-${type}`)], 'check');
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                set(id, currentConfig[camelCase(id)]);
            });
        });

        set('ambi-mode', currentConfig.ambiMode);
        set('ambi-scale', currentConfig.ambiScale);
        set('ambi-opacity', currentConfig.ambiOpacity);
        set('ambi-blur', currentConfig.ambiBlur);
        set('border-color', currentConfig.borderColor);
        set('performanceMode', currentConfig.performanceMode, 'check');
        set('maxDisplayHeight', currentConfig.maxDisplayHeight ?? 1080);
        set('disableAmbience', currentConfig.disableAmbience, 'check');
        set('disableParticles', currentConfig.disableParticles, 'check');
        set('disableCssFilters', currentConfig.disableCssFilters, 'check');
        set('disableNeonAudio', currentConfig.disableNeonAudio, 'check');
        set('border-glow', currentConfig.borderGlow);
        set('photo-duration', currentConfig.photoDuration);
        set('clock-pos', currentConfig.pos);
        set('clock-size', currentConfig.clockSize);
        set('font-family', currentConfig.font);
        set('show-date', currentConfig.showDate, 'check');
        set('format-12h', currentConfig.format12h, 'check');
        set('show-seconds', currentConfig.showSeconds, 'check');
        set('use-local', currentConfig.useLocal, 'check');
        set('use-photos', currentConfig.usePhotos, 'check');
        set('urls', currentConfig.urls, 'array');
        set('accent-color', currentConfig.accentColor);

        set('neon-border', currentConfig.neonBorder, 'check');
        set('neon-pattern', currentConfig.neonPattern);
        set('neon-segments', currentConfig.neonSegments);
        set('neon-speed', currentConfig.neonSpeed);
        set('neon-audio', currentConfig.neonAudio, 'check');
        set('neon-strobe', currentConfig.neonStrobe);
        set('neon-sensitivity', currentConfig.neonSensitivity);
        set('neon-width', currentConfig.neonWidth);
        set('neon-use-accent', currentConfig.neonUseAccent, 'check');
        set('neon-color', currentConfig.neonColor);
        set('border-size', currentConfig.borderSize);
        
        if (db) await loadPlaylistsUI();
        
        if($('active-playlist-selector')) {
             $('active-playlist-selector').value = currentConfig.activePlaylistId || 'all';
             activePlaylistView = currentConfig.activePlaylistId || 'all';
        }

        if (db) loadLibraryGrid();
        initSliders();
    }

    function camelCase(str) { return str.replace(/-([a-z])/g, (g) => g[1].toUpperCase()); }

    function getThumbSeekSec() {
        if (window.FAFOPairs?.getThumbSeekSec) return FAFOPairs.getThumbSeekSec();
        const v = Number(currentConfig?.thumbSeekSec);
        return Number.isFinite(v) && v >= 0 ? v : 1;
    }

    async function generateThumbnail(file, seekSec) {
        if (!file) return null;
        if (String(file.type || '').startsWith('image') || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(file.name || '')) {
            return URL.createObjectURL(file);
        }
        const seek = seekSec != null ? seekSec : getThumbSeekSec();
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.muted = true;
            video.playsInline = true;
            const url = URL.createObjectURL(file);
            video.src = url;
            video.onloadeddata = () => {
                const cap = Math.max(0, (video.duration || 1) - 0.05);
                video.currentTime = Math.min(Math.max(0, seek), cap || 0);
            };
            video.onseeked = () => {
                try {
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1, Math.floor(video.videoWidth / 4));
                    canvas.height = Math.max(1, Math.floor(video.videoHeight / 4));
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    const dataUrl = canvas.toDataURL('image/jpeg', 0.7);
                    URL.revokeObjectURL(url);
                    video.remove();
                    resolve(dataUrl);
                } catch {
                    URL.revokeObjectURL(url);
                    video.remove();
                    resolve(null);
                }
            };
            video.onerror = () => {
                URL.revokeObjectURL(url);
                video.remove();
                resolve(null);
            };
        });
    }

    async function getPlaylists() {
        if (!db) return [];
        return new Promise(res => {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            const req = store.getAll();
            req.onsuccess = () => res(req.result || []);
            req.onerror = () => res([]);
        });
    }

    async function smartPlaylistCount(p) {
        if (!db || p.type !== 'smart' || !window.FAFOLibrary) return null;
        try {
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            const items = await FAFOLibrary.resolveSmartPlaylist(db, p, fafoMediaMeta);
            return items.length;
        } catch {
            return null;
        }
    }

    async function loadPlaylistsUI() {
        const playlists = await getPlaylists();
        const container = $('playlist-list');
        const select = $('active-playlist-selector');
        const modalSelect = $('modal-playlist-select');
        
        if(container) container.innerHTML = '';
        
        if(select) {
            const currentSelectVal = select.value || 'all';
            select.innerHTML = '<option value="all">📚 All Library</option>';
            for (const p of playlists) {
                const opt = document.createElement('option');
                opt.value = p.id;
                const n = p.type === 'smart' ? await smartPlaylistCount(p) : (p.items || []).length;
                const icon = p.type === 'smart' ? '✨' : '🎼';
                opt.textContent = `${icon} ${p.name} (${n != null ? n : '…'})`;
                select.appendChild(opt);
            }
            select.value = currentSelectVal;
        }

        if(modalSelect) {
            modalSelect.innerHTML = '<option value="">Select Playlist...</option>';
            playlists.filter(p => p.type !== 'smart').forEach(p => {
                const opt = document.createElement('option');
                opt.value = p.id;
                opt.textContent = p.name;
                modalSelect.appendChild(opt);
            });
        }

        if(container) {
            if(playlists.length === 0) container.innerHTML = '<span style="color:#666">No collections created yet.</span>';
            for (const p of playlists) {
                const chip = document.createElement('div');
                chip.className = 'playlist-chip';
                const n = p.type === 'smart' ? await smartPlaylistCount(p) : (p.items || []).length;
                const badge = p.type === 'smart' ? '✨ smart' : 'manual';
                let rulesHint = '';
                if (p.type === 'smart' && p.rules) {
                    const bits = [];
                    if (p.rules.minRating) bits.push('*' + p.rules.minRating + '+');
                    if (p.rules.untaggedOnly) bits.push('untagged');
                    if (p.rules.tags?.length) bits.push(p.rules.tags.join(','));
                    rulesHint = bits.length ? ` · ${bits.join(' · ')}` : '';
                }
                chip.innerHTML = `<span>${p.name}</span> <span style="color:#666">(${n != null ? n : '…'}) ${badge}${rulesHint}</span>`;
                const del = document.createElement('button');
                del.textContent = '×';
                del.onclick = async () => {
                    if(confirm(`Delete playlist "${p.name}"?`)) {
                        const tx = db.transaction('playlists', 'readwrite');
                        tx.objectStore('playlists').delete(p.id);
                        tx.oncomplete = () => loadPlaylistsUI();
                    }
                };
                chip.appendChild(del);
                container.appendChild(chip);
            }
        }
    }

    const createBtn = $('create-playlist-btn');
    if (createBtn) {
        createBtn.onclick = () => {
            if (!db) { showToast("Database Not Ready", "error"); return; }
            const nameInput = $('new-playlist-name');
            const name = nameInput ? nameInput.value.trim() : "";
            if(!name) return;
            const tx = db.transaction('playlists', 'readwrite');
            const id = crypto.randomUUID();
            tx.objectStore('playlists').add({ id, name, type: 'manual', items: [] });
            tx.oncomplete = () => {
                if(nameInput) nameInput.value = '';
                showToast(`Created playlist: ${name}`);
                loadPlaylistsUI();
            };
        };
    }

    async function createSmartPlaylist(preset) {
        if (!db) { showToast('Database Not Ready', 'error'); return; }
        let name = $('smart-pl-name')?.value?.trim() || '';
        let minRating = parseInt($('smart-pl-min-rating')?.value || '0', 10) || 0;
        let media = $('smart-pl-media')?.value || 'video';
        let tagsMode = $('smart-pl-tags-mode')?.value || 'any';
        let untaggedOnly = !!$('smart-pl-untagged')?.checked;
        let tags = window.FAFOLibrary
            ? FAFOLibrary.normalizeTags($('smart-pl-tags')?.value || '')
            : ($('smart-pl-tags')?.value || '').split(/[,;]+/).map(t => t.trim()).filter(Boolean);

        if (preset === '4star') {
            name = name || '4-star favorites';
            minRating = 4;
            untaggedOnly = false;
        } else if (preset === 'untagged') {
            name = name || 'Untagged';
            minRating = 0;
            tags = [];
            untaggedOnly = true;
        }

        if (!name) {
            showToast('Enter a smart playlist name', 'error');
            return;
        }
        if (!untaggedOnly && minRating <= 0 && !tags.length) {
            showToast('Set min rating, tags, or Untagged only', 'error');
            return;
        }

        const id = 'smart_' + crypto.randomUUID();
        const pl = {
            id,
            name,
            type: 'smart',
            items: [],
            rules: {
                minRating,
                tags,
                tagsMode,
                untaggedOnly,
                media,
            },
            created: Date.now(),
        };
        const tx = db.transaction('playlists', 'readwrite');
        tx.objectStore('playlists').put(pl);
        tx.oncomplete = () => {
            if ($('smart-pl-name')) $('smart-pl-name').value = '';
            showToast(`Smart playlist: ${name}`);
            loadPlaylistsUI();
        };
    }

    $('create-smart-pl-btn')?.addEventListener('click', () => createSmartPlaylist());
    $('preset-smart-4star')?.addEventListener('click', () => createSmartPlaylist('4star'));
    $('preset-smart-untagged')?.addEventListener('click', () => createSmartPlaylist('untagged'));

    const activeSelector = $('active-playlist-selector');
    if(activeSelector) {
        activeSelector.onchange = (e) => {
            activePlaylistView = e.target.value;
            currentConfig.activePlaylistId = activePlaylistView;
            chrome.storage.local.set({mediaConfig: currentConfig});
            currentPage = 1;
            allLibraryItems = []; 
            loadLibraryGrid();
        };
    }

    async function loadLibraryGrid() {
        if (!db) return;
        const grid = $('library-grid');
        if (!grid) return;
        grid.innerHTML = ''; 
        
        if (allLibraryItems.length === 0) {
             const getAllData = (name) => {
                return new Promise((resolve) => {
                    const tx = db.transaction(name, 'readonly');
                    const store = tx.objectStore(name);
                    const items = [];
                    const req = store.openCursor();
                    req.onsuccess = e => {
                        const cursor = e.target.result;
                        if(cursor) {
                            items.push({val: cursor.value, key: cursor.key});
                            cursor.continue();
                        } else {
                            resolve(items);
                        }
                    };
                    req.onerror = () => resolve([]);
                });
            };

            const [videos, photos] = await Promise.all([getAllData('videos'), getAllData('photos')]);
            let rawItems = [
                ...videos.map(v => ({...v, type: 'video', storeName: 'videos'})),
                ...photos.map(p => ({...p, type: 'photo', storeName: 'photos'}))
            ];

            if (activePlaylistView !== 'all') {
                const playlists = await getPlaylists();
                const pl = playlists.find(p => p.id === activePlaylistView);
                if (pl) {
                    if (pl.type === 'smart' && window.FAFOLibrary) {
                        const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
                        const resolved = await FAFOLibrary.resolveSmartPlaylist(db, pl, fafoMediaMeta);
                        const allowedKeys = new Set(resolved.map(i => `${i.storeName}_${i.key}`));
                        rawItems = rawItems.filter(item => allowedKeys.has(`${item.storeName}_${item.key}`));
                    } else {
                        const allowedKeys = new Set((pl.items || []).map(i => `${i.store || i.storeName}_${i.key}`));
                        rawItems = rawItems.filter(item => allowedKeys.has(`${item.storeName}_${item.key}`));
                    }
                }
            }
            allLibraryItems = rawItems;
        }

        const totalItems = allLibraryItems.length;
        if (totalItems === 0) {
            grid.innerHTML = '<div style="color:#555; padding:20px; grid-column: 1/-1; text-align:center;">No items found in this source.</div>';
            updatePaginationControls(0);
            return;
        }

        const startIdx = (currentPage - 1) * itemsPerPage;
        const endIdx = startIdx + itemsPerPage;
        const pageItems = allLibraryItems.slice(startIdx, endIdx);

        updatePaginationControls(totalItems);

        for (let i = 0; i < pageItems.length; i++) {
            const item = pageItems[i];
            const globalIndex = startIdx + i + 1; 
            await createGridItem(item.val, item.key, item.storeName, item.type, globalIndex);
        }
    }

    function updatePaginationControls(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        if (currentPage > totalPages && totalPages > 0) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        if($('lib-total-count')) $('lib-total-count').textContent = `${totalItems} Items`;
        if($('lib-page-display')) $('lib-page-display').textContent = `${currentPage}/${totalPages || 1}`;
        
        const prev = $('lib-prev');
        const next = $('lib-next');
        
        if(prev) {
            prev.disabled = currentPage <= 1;
            prev.style.opacity = currentPage <= 1 ? 0.5 : 1;
            prev.onclick = () => { if (currentPage > 1) { currentPage--; loadLibraryGrid(); }};
        }
        if(next) {
            next.disabled = currentPage >= totalPages;
            next.style.opacity = currentPage >= totalPages ? 0.5 : 1;
            next.onclick = () => { 
                const totalPages = Math.ceil(allLibraryItems.length / itemsPerPage);
                if (currentPage < totalPages) { currentPage++; loadLibraryGrid(); }
            };
        }
    }

    const perPageSelect = $('lib-per-page');
    if(perPageSelect) {
        perPageSelect.addEventListener('change', (e) => {
            itemsPerPage = parseInt(e.target.value);
            currentPage = 1;
            loadLibraryGrid();
        });
    }

    async function createGridItem(item, key, storeName, type, index) {
        const grid = $('library-grid');
        const card = document.createElement('div');
        card.className = 'media-card';
        
        let src = '', name = 'Unknown';
        let fileObj = null;
        const entry = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(item) : null;
        const fileHandle = entry?.handle || item;
        try {
            if (fileHandle instanceof File) {
                fileObj = fileHandle;
                src = URL.createObjectURL(fileHandle);
                name = fileHandle.name;
            } else if (fileHandle && typeof fileHandle.getFile === 'function') {
                name = entry?.name || fileHandle.name || 'Unknown';
                const granted = window.FAFOLibrary
                    ? await FAFOLibrary.ensurePermission(fileHandle, 'read')
                    : true;
                if (!granted) throw new Error('permission');
                fileObj = await fileHandle.getFile();
                src = URL.createObjectURL(fileObj);
                name = fileObj.name;
            } else if (item instanceof File) {
                fileObj = item;
                src = URL.createObjectURL(item);
                name = item.name;
            } else if (item?.kind === 'file') {
                fileObj = await item.getFile();
                src = URL.createObjectURL(fileObj);
                name = item.name;
            }
        } catch (e) {
            card.style.opacity = 0.5;
            name = entry?.name || item?.name || '⚠️ Permission Lost';
        }

        if (currentConfig.overrides && currentConfig.overrides[name]) card.classList.add('has-override');

        const el = document.createElement('img');
        el.style.objectFit = 'cover';
        if (type === 'photo') el.src = src;
        else {
            el.src = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI2NCIgaGVpZ2h0PSI2NCI+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0iIzIyMiIvPjwvc3ZnPg==';
            if (fileObj) thumbQueue.add(fileObj, el);
            const vidIcon = document.createElement('div');
            vidIcon.textContent = '🎬';
            vidIcon.style.cssText = 'position:absolute; top:50%; left:50%; transform:translate(-50%, -50%); font-size:2rem; text-shadow: 0 2px 5px rgba(0,0,0,0.8);';
            card.appendChild(vidIcon);
        }

        const badge = document.createElement('div');
        badge.className = 'item-index-badge';
        badge.textContent = `#${index}`;
        card.appendChild(badge);

        // Tag/rating badge from fafoMediaMeta (shared with new-tab player)
        try {
            const metaKey = fileObj ? `file:${name}|${fileObj.size}|${fileObj.lastModified}` : null;
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            let entry = metaKey ? fafoMediaMeta[metaKey] : null;
            if (!entry) {
                entry = Object.values(fafoMediaMeta).find(m => m && m.name === name);
            }
            if (entry && ((entry.tags && entry.tags.length) || entry.rating)) {
                const tagBadge = document.createElement('div');
                tagBadge.style.cssText = 'position:absolute;top:5px;left:5px;background:rgba(0,0,0,0.75);color:#ffc107;font-size:0.65rem;padding:2px 6px;border-radius:4px;max-width:70%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;z-index:5;';
                const stars = entry.rating ? '*'.repeat(entry.rating) : '';
                const t0 = (entry.tags || [])[0] || '';
                tagBadge.textContent = `${stars}${stars && t0 ? ' ' : ''}${t0}${(entry.tags||[]).length > 1 ? '…' : ''}`;
                card.appendChild(tagBadge);
            }
        } catch (_) {}

        const title = document.createElement('div');
        title.textContent = name;
        title.style.cssText = 'position:absolute; bottom:0; left:0; width:100%; padding:5px; background:linear-gradient(transparent, rgba(0,0,0,0.9)); color:white; font-size:0.7rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;';

        const delBtn = document.createElement('button');
        delBtn.innerHTML = '×';
        delBtn.style.cssText = 'position:absolute; top:5px; right:5px; background:rgba(255,0,0,0.7); color:white; border:none; border-radius:50%; width:24px; height:24px; cursor:pointer; display:none; align-items:center; justify-content:center; font-weight:bold; z-index:10;';
        delBtn.onclick = (e) => {
            e.stopPropagation();
            if(confirm(`Delete ${name}?`)) {
                const tx = db.transaction(storeName, 'readwrite');
                tx.objectStore(storeName).delete(key);
                tx.oncomplete = () => { card.remove(); showToast('Deleted item'); allLibraryItems = []; loadLibraryGrid(); };
            }
        };
        
        card.onmouseover = () => delBtn.style.display = 'flex';
        card.onmouseout = () => delBtn.style.display = 'none';

        card.appendChild(el); card.appendChild(title); card.appendChild(delBtn);
        card.onclick = () => openModal(name, src, type, key, storeName, fileObj);
        grid.appendChild(card);
    }

    const modal = $('file-modal');
    let modalRank = 0;
    let modalTags = [];

    function metaKeyFromFile(fileObj, fileName) {
        if (fileObj) return `file:${fileName}|${fileObj.size}|${fileObj.lastModified}`;
        return `handle:${fileName}`;
    }

    function renderModalRank() {
        const box = $('modal-rank');
        if (!box) return;
        box.querySelectorAll('[data-r]').forEach(st => {
            const r = parseInt(st.dataset.r, 10);
            st.style.color = r <= modalRank ? '#ffc107' : '#444';
        });
    }

    function renderModalTagChips() {
        const box = $('modal-tag-chips');
        if (!box) return;
        box.innerHTML = modalTags.map((t, i) =>
            `<span style="font-size:11px;padding:3px 8px;border-radius:999px;background:rgba(0,229,255,0.15);color:#7ef7ff;cursor:pointer;" data-i="${i}">${t} ×</span>`
        ).join('');
        box.querySelectorAll('[data-i]').forEach(chip => {
            chip.onclick = () => {
                modalTags.splice(parseInt(chip.dataset.i, 10), 1);
                renderModalTagChips();
                if ($('modal-tags')) $('modal-tags').value = modalTags.join(', ');
            };
        });
    }

    async function refreshModalTagSuggestions() {
        const dl = $('modal-tag-suggestions');
        if (!dl) return;
        const { fafoTagLibrary = [], fafoMediaMeta = {} } = await chrome.storage.local.get(['fafoTagLibrary', 'fafoMediaMeta']);
        const set = new Set(Array.isArray(fafoTagLibrary) ? fafoTagLibrary : []);
        Object.values(fafoMediaMeta || {}).forEach(m => (m.tags || []).forEach(t => set.add(t)));
        try {
            const r = await fetch('http://127.0.0.1:8765/api/tags', { signal: AbortSignal.timeout(1500) });
            if (r.ok) {
                const tags = await r.json();
                if (Array.isArray(tags)) tags.forEach(t => set.add(t));
            }
        } catch (_) {}
        dl.innerHTML = [...set].slice(0, 200).map(t => `<option value="${String(t).replace(/"/g, '&quot;')}">`).join('');
    }

    function openModal(fileName, src, type, key, storeName, fileObj) {
        editingFile = { fileName, key, storeName, fileObj };
        if($('modal-title')) $('modal-title').textContent = fileName;
        const previewBox = $('modal-preview-box');
        if(previewBox) {
            previewBox.innerHTML = '';
            const el = type === 'video' ? document.createElement('video') : document.createElement('img');
            el.src = src; el.controls = true; 
            previewBox.appendChild(el);
        }

        const overrides = currentConfig.overrides?.[fileName] || {};
        if($('modal-volume')) $('modal-volume').value = overrides.volume !== undefined ? overrides.volume : -1;
        if($('modal-scaling')) $('modal-scaling').value = overrides.scaling || 'default';
        if($('modal-playlist-select')) $('modal-playlist-select').value = "";

        // Load shared FAFO tags/rating for this asset
        (async () => {
            const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
            const mk = metaKeyFromFile(fileObj, fileName);
            let entry = fafoMediaMeta[mk];
            if (!entry) entry = Object.values(fafoMediaMeta).find(m => m && m.name === fileName);
            modalRank = entry?.rating || 0;
            modalTags = Array.isArray(entry?.tags) ? [...entry.tags] : [];
            if ($('modal-tags')) $('modal-tags').value = modalTags.join(', ');
            renderModalRank();
            renderModalTagChips();
            await refreshModalTagSuggestions();
        })();
        
        if(modal) modal.style.display = 'flex';
    }

    // Modal rank stars
    if ($('modal-rank')) {
        $('modal-rank').querySelectorAll('[data-r]').forEach(st => {
            st.onclick = () => {
                const r = parseInt(st.dataset.r, 10);
                modalRank = modalRank === r ? 0 : r;
                renderModalRank();
            };
        });
    }
    if ($('modal-tags')) {
        $('modal-tags').addEventListener('change', () => {
            modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
            renderModalTagChips();
        });
        $('modal-tags').addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
                renderModalTagChips();
            }
        });
    }

    function closeModal() {
        if(modal) modal.style.display = 'none';
        if($('modal-preview-box')) $('modal-preview-box').innerHTML = ''; 
    }

    if($('modal-save')) {
        $('modal-save').onclick = async () => {
            if (!currentConfig.overrides) currentConfig.overrides = {};
            const vol = parseFloat($('modal-volume').value);
            const scale = $('modal-scaling').value;
            
            if (vol === -1 && scale === 'default') delete currentConfig.overrides[editingFile.fileName];
            else currentConfig.overrides[editingFile.fileName] = {
                volume: vol === -1 ? undefined : vol,
                scaling: scale === 'default' ? undefined : scale
            };

            const playlistId = $('modal-playlist-select') ? $('modal-playlist-select').value : null;
            if(playlistId && db) {
                const tx = db.transaction('playlists', 'readwrite');
                const store = tx.objectStore('playlists');
                const p = await new Promise(res => { 
                    store.get(playlistId).onsuccess = e => res(e.target.result); 
                });
                
                if(p) {
                    const exists = p.items.some(i => i.key === editingFile.key && i.store === editingFile.storeName);
                    if(!exists) {
                        p.items.push({ store: editingFile.storeName, key: editingFile.key });
                        store.put(p);
                        showToast(`Added to ${p.name}`);
                    }
                }
            }

            // Save tags/rating into shared fafoMediaMeta (same keys as new-tab player)
            if ($('modal-tags')) {
                modalTags = $('modal-tags').value.split(/[,;]+/).map(s => s.trim()).filter(Boolean);
            }
            const { fafoMediaMeta = {}, fafoTagLibrary = [] } = await chrome.storage.local.get(['fafoMediaMeta', 'fafoTagLibrary']);
            const mk = metaKeyFromFile(editingFile.fileObj, editingFile.fileName);
            fafoMediaMeta[mk] = {
                rating: modalRank || 0,
                tags: modalTags,
                name: editingFile.fileName,
                updated: Date.now(),
            };
            // Grow vocabulary without reordering MRU timestamps (options page doesn't touch lastUsed)
            const lib = Array.isArray(fafoTagLibrary) ? fafoTagLibrary.slice() : [];
            modalTags.forEach(t => {
                if (!lib.some(x => String(x).toLowerCase() === t.toLowerCase())) lib.push(t);
            });
            await chrome.storage.local.set({ fafoMediaMeta, fafoTagLibrary: lib });

            // Best-effort write to disk via toolbox/explorer-meta server
            try {
                const f = editingFile.fileObj;
                await fetch('http://127.0.0.1:8765/api/fs/write-metadata', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: editingFile.fileName,
                        size: f ? f.size : null,
                        mtime: f ? f.lastModified : null,
                        tags: modalTags,
                        rating: modalRank || 0,
                        update_catalog: true,
                    }),
                    signal: AbortSignal.timeout(4000),
                });
            } catch (_) {}

            await saveAll();
            closeModal();
            allLibraryItems = []; 
            loadLibraryGrid();
            showToast('Saved tags & overrides');
        };
    }

    if($('modal-delete')) {
        $('modal-delete').onclick = async () => {
            if(!confirm("Remove this file from library?")) return;
            const tx = db.transaction(editingFile.storeName, 'readwrite');
            tx.objectStore(editingFile.storeName).delete(editingFile.key);
            tx.oncomplete = () => { closeModal(); allLibraryItems = []; loadLibraryGrid(); };
        };
    }
    if($('modal-cancel')) $('modal-cancel').onclick = closeModal;

    async function saveAll() {
        const get = (id, type) => {
            const el = $(id);
            if (!el) return undefined;
            if(type === 'check') return el.checked;
            if(type === 'float') return parseFloat(el.value);
            if(type === 'array') return el.value.split('\n').map(l => l.trim()).filter(Boolean);
            return type === 'int' ? parseInt(el.value) : el.value;
        };

        const newConfig = {
            ...currentConfig,
            useLocal: get('use-local', 'check'),
            usePhotos: get('use-photos', 'check'),
            urls: get('urls', 'array'),
            thumbSeekSec: window.FAFOPairs?.getThumbSeekSec?.() ?? currentConfig.thumbSeekSec ?? 1,
            
            layout: get('layout'),
            scaling: get('scaling'),
            gridCols: get('grid-cols', 'int'),
            gridRows: get('grid-rows', 'int'),
            carouselRadius: get('carousel-radius', 'int'),
            carouselTilt: get('carousel-tilt', 'int'),
            carouselSpeed: get('carousel-speed', 'int'),
            reflectOpacity: get('reflect-opacity', 'int'),
            reflectOffset: get('reflect-offset', 'int'),
            
            // bokehEnable REMOVED - Controlled by individual switches now
            
            brightness: get('brightness', 'int'),
            contrast: get('contrast', 'int'),
            saturate: get('saturate', 'int'),
            sepia: get('sepia', 'int'),
            grayscale: get('grayscale', 'int'),
            
            ambiScale: get('ambi-scale', 'float'),
            ambiOpacity: get('ambi-opacity', 'float'),
            ambiBlur: get('ambi-blur', 'int'),
            ambiMode: get('ambi-mode'),
            borderColor: get('border-color'),
            borderGlow: get('border-glow', 'int'),
            borderSize: get('border-size', 'int'),

            neonBorder: get('neon-border', 'check'),
            neonPattern: get('neon-pattern'),
            neonSegments: get('neon-segments', 'int'),
            neonSpeed: get('neon-speed', 'float'),
            neonAudio: get('neon-audio', 'check'),
            neonStrobe: get('neon-strobe', 'float'),
            neonSensitivity: get('neon-sensitivity', 'float'),
            neonWidth: get('neon-width', 'int'),
            neonUseAccent: get('neon-use-accent', 'check'),
            neonColor: get('neon-color'),
            
            volume: get('volume', 'float'),
            photoDuration: get('photo-duration', 'int'),
            shuffle: get('shuffle', 'check'),
            kenburns: get('kenburns', 'check'),
            
            pos: get('clock-pos'),
            clockSize: get('clock-size', 'int'),
            font: get('font-family'),
            showDate: get('show-date', 'check'),
            format12h: get('format-12h', 'check'),
            showSeconds: get('show-seconds', 'check'),
            
            accentColor: get('accent-color'),
            activePlaylistId: activePlaylistView,

            performanceMode: !!get('performanceMode', 'check'),
            maxDisplayHeight: parseInt(get('maxDisplayHeight') ?? 1080, 10) || 0,
            disableAmbience: !!get('disableAmbience', 'check'),
            disableParticles: !!get('disableParticles', 'check'),
            disableCssFilters: !!get('disableCssFilters', 'check'),
            disableNeonAudio: !!get('disableNeonAudio', 'check'),
        };
        
        // Dynamic FX Saving
        const particleTypes = ['embers', 'smoke', 'snow', 'rain', 'sparks', 'neon'];
        const particleAttrs = ['speed', 'density', 'size', 'blur'];
        
        particleTypes.forEach(type => {
            // Checkbox
            const checkId = `fx-${type}`;
            if($(checkId)) newConfig[camelCase(checkId)] = $(checkId).checked;
            
            // Sliders
            particleAttrs.forEach(attr => {
                const id = `fx-${type}-${attr}`;
                if($(id)) newConfig[camelCase(id)] = parseInt($(id).value);
            });
        });

        await chrome.storage.local.set({mediaConfig: newConfig});
        currentConfig = newConfig;
        applyTheme(newConfig.accentColor);
        showToast('System Configuration Saved');
    }
    
    if($('save-all-btn')) $('save-all-btn').onclick = saveAll;

    function fmtBackupTime(ts) {
        if (!ts) return '—';
        try { return new Date(ts).toLocaleString(); } catch { return String(ts); }
    }

    async function refreshTagsBackupUI() {
        const status = $('tags-backup-status');
        const list = $('tags-backup-history');
        if (!window.FAFOBackup) {
            if (status) status.textContent = 'Backup module missing (fafo-backup.js).';
            return;
        }
        try {
            const s = await FAFOBackup.statusSummary();
            if (status) {
                status.innerHTML =
                    `<strong>Live:</strong> ${s.liveMedia} media with tags/ratings · ${s.liveTags} known tags · ${s.livePairs} pairs<br>` +
                    `<strong>Latest snapshot:</strong> ${s.snapshotAt ? fmtBackupTime(s.snapshotAt) + ` (${s.snapshotMedia} media)` : 'none yet'} · ` +
                    `<strong>History:</strong> ${s.historyCount} slot(s)`;
            }
            if (!list) return;
            if (!s.history.length) {
                list.innerHTML = '<span style="color:#666;font-size:0.85rem;">No history yet — tag a file or click Snapshot now.</span>';
                return;
            }
            list.innerHTML = s.history.map((h) => `
                <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:10px 12px;border:1px solid #333;border-radius:10px;background:rgba(0,0,0,0.35);">
                    <div style="flex:1;min-width:180px;font-size:0.8rem;color:#ccc;">
                        <strong style="color:#fff;">${fmtBackupTime(h.savedAt)}</strong>
                        <span style="color:#666;"> · ${escapeHtmlBackup(h.reason || 'auto')}</span><br>
                        <span style="color:#888;">${h.mediaEntries || 0} media · ${h.tagCount || 0} tags · ${h.pairCount || 0} pairs</span>
                    </div>
                    <button class="btn btn-primary small" data-restore-id="${escapeHtmlBackup(h.id)}">Restore</button>
                </div>
            `).join('');
            list.querySelectorAll('[data-restore-id]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    if (!confirm('Restore this backup? Current tags will be snapshotted first, then replaced.')) return;
                    try {
                        btn.disabled = true;
                        const r = await FAFOBackup.restoreHistoryId(btn.dataset.restoreId);
                        showToast(`Restored: ${r.mediaEntries} media, ${r.tags} tags, ${r.pairs} pairs`);
                        await refreshTagsBackupUI();
                    } catch (e) {
                        showToast(e.message || 'Restore failed', 'error');
                    } finally {
                        btn.disabled = false;
                    }
                });
            });
        } catch (e) {
            if (status) status.textContent = 'Could not load backup status: ' + (e.message || e);
        }
    }

    function escapeHtmlBackup(s) {
        return String(s ?? '')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/"/g, '&quot;');
    }

    if ($('export-tags-btn')) {
        $('export-tags-btn').onclick = async () => {
            if (!window.FAFOBackup) return showToast('Backup module missing', 'error');
            try {
                await FAFOBackup.exportToDownload({ includeConfig: false });
                showToast('Tags backup downloaded');
                await refreshTagsBackupUI();
            } catch (e) {
                showToast(e.message || 'Export failed', 'error');
            }
        };
    }
    if ($('import-tags-btn')) $('import-tags-btn').onclick = () => $('import-tags-file')?.click();
    if ($('import-tags-file')) {
        $('import-tags-file').onchange = async (e) => {
            const file = e.target.files?.[0];
            e.target.value = '';
            if (!file || !window.FAFOBackup) return;
            if (!confirm('Import tags backup? Live data will be snapshotted, then replaced from the file.')) return;
            try {
                const r = await FAFOBackup.importFromFile(file, { includeConfig: false });
                if (r.configOnly) {
                    showToast('That file was config-only — use Import config JSON', 'error');
                    return;
                }
                showToast(`Imported: ${r.mediaEntries} media, ${r.tags} tags, ${r.pairs} pairs — reloading…`);
                setTimeout(() => location.reload(), 900);
            } catch (err) {
                showToast(err.message || 'Import failed', 'error');
            }
        };
    }
    if ($('backup-now-btn')) {
        $('backup-now-btn').onclick = async () => {
            if (!window.FAFOBackup) return;
            try {
                await FAFOBackup.afterLiveSave(null, 'manual');
                showToast('Snapshot saved to history');
                await refreshTagsBackupUI();
            } catch (e) {
                showToast(e.message || 'Snapshot failed', 'error');
            }
        };
    }
    if ($('restore-latest-btn')) {
        $('restore-latest-btn').onclick = async () => {
            if (!window.FAFOBackup) return;
            if (!confirm('Restore the latest auto-snapshot? Current live data is snapshotted first.')) return;
            try {
                const r = await FAFOBackup.restoreLatestSnapshot();
                showToast(`Restored latest: ${r.mediaEntries} media — reloading…`);
                setTimeout(() => location.reload(), 900);
            } catch (e) {
                showToast(e.message || 'Restore failed', 'error');
            }
        };
    }

    if($('export-btn')) $('export-btn').onclick = () => {
        const blob = new Blob([JSON.stringify(currentConfig, null, 2)], {type: 'application/json'});
        const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'fafo-media-config.json'; a.click();
    };
    if($('import-btn')) $('import-btn').onclick = () => $('import-file').click();
    if($('import-file')) $('import-file').onchange = e => {
        const r = new FileReader();
        r.onload = async (evt) => {
            try {
                const obj = JSON.parse(evt.target.result);
                // Smart import: tags backup vs config
                if (window.FAFOBackup && (obj.kind === FAFOBackup.KIND || obj.fafoMediaMeta || obj.data?.fafoMediaMeta)) {
                    const res = await FAFOBackup.importFromObject(obj, { includeConfig: !!obj.data?.mediaConfig });
                    showToast(res.configOnly ? 'Config loaded' : `Tags imported (${res.mediaEntries} media) — reloading…`);
                    setTimeout(() => location.reload(), 900);
                    return;
                }
                await chrome.storage.local.set({mediaConfig: obj});
                showToast('Config Loaded! Reloading...'); setTimeout(() => location.reload(), 1000);
            } catch(err) { showToast('Invalid Config File', 'error'); }
        };
        r.readAsText(e.target.files[0]);
    };
    
    async function addFolder(storeName, btnId) {
        if (!db) { showToast('Database Not Ready', 'error'); return; }
        const btn = $(btnId);
        const originalText = btn.textContent;
        try {
            const dirHandle = await showDirectoryPicker({ mode: 'read' });
            btn.textContent = 'Scanning…';
            btn.disabled = true;
            btn.style.opacity = 0.5;

            if (window.FAFOLibrary?.linkFolder) {
                const { folder, added } = await FAFOLibrary.linkFolder(db, storeName, dirHandle);
                showToast(`Linked “${folder.name}” — ${added} files (saved for resync)`);
            } else {
                // Fallback without shared module
                const regex = storeName === 'photos'
                    ? /\.(jpg|jpeg|png|webp|gif|bmp)$/i
                    : /\.(mp4|webm|mkv|mov|avi|m4v)$/i;
                const handles = [];
                async function scan(dir) {
                    for await (const entry of dir.values()) {
                        if (entry.kind === 'file' && regex.test(entry.name)) handles.push(entry);
                        else if (entry.kind === 'directory') await scan(entry);
                    }
                }
                await scan(dirHandle);
                if (!handles.length) {
                    showToast('No files found', 'error');
                    return;
                }
                const tx = db.transaction(storeName, 'readwrite');
                const store = tx.objectStore(storeName);
                handles.forEach((h) => store.put({ handle: h, name: h.name, addedAt: Date.now() }, crypto.randomUUID()));
                await new Promise((res) => { tx.oncomplete = res; });
                showToast(`Added ${handles.length} files`);
            }
            allLibraryItems = [];
            await loadLibraryGrid();
            await refreshLinkedFoldersUI();
        } catch (e) {
            if (e?.name !== 'AbortError') {
                console.warn(e);
                showToast(e.message || 'Link cancelled / failed', 'error');
            }
        } finally {
            btn.textContent = originalText;
            btn.disabled = false;
            btn.style.opacity = 1;
        }
    }

    async function refreshLinkedFoldersUI() {
        const list = $('linked-folders-list');
        const statusEl = $('library-access-status');
        if (!db || !list) return;

        if (!window.FAFOLibrary) {
            list.innerHTML = '<span style="color:#666;font-size:0.85rem">Update incomplete — fafo-library.js missing.</span>';
            return;
        }

        const folders = await FAFOLibrary.listFolders(db);
        const st = await FAFOLibrary.libraryAccessStatus(db);
        if (statusEl) {
            if (!folders.length && st.sampleOk === 0 && st.sampleBad === 0) {
                statusEl.textContent = 'No folders linked yet — use + Link Video/Photo Folder below.';
                statusEl.style.color = '#888';
            } else if (st.needsRestore) {
                statusEl.textContent = `Access needs restore: ${st.folderPrompt + st.folderDenied} folder(s) pending · sample files ok ${st.sampleOk} / bad ${st.sampleBad}. Click 🔓 Restore Access.`;
                statusEl.style.color = '#ffc107';
            } else {
                statusEl.textContent = `Access OK — ${folders.length} saved folder(s), ${st.folderGranted} granted. Resync picks up new files without re-picking.`;
                statusEl.style.color = 'var(--accent)';
            }
        }

        if (!folders.length) {
            list.innerHTML = '<span style="color:#555;font-size:0.85rem">No persistent folders yet. Newly linked folders appear here.</span>';
            return;
        }

        list.innerHTML = '';
        for (const f of folders) {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:8px 10px;background:rgba(255,255,255,0.03);border:1px solid #333;border-radius:8px;';
            const when = f.lastSyncedAt ? new Date(f.lastSyncedAt).toLocaleString() : '—';
            const perm = await FAFOLibrary.queryPermissionOnly(f.handle);
            row.innerHTML = `
                <span style="flex:1;min-width:140px;color:#eee;font-size:0.85rem;">📁 ${f.name}
                    <span style="color:#666"> · ${f.kind} · ${f.fileCount ?? '?'} files · ${perm}</span><br>
                    <span style="color:#555;font-size:0.75rem">Last sync: ${when}</span>
                </span>`;
            const resyncBtn = document.createElement('button');
            resyncBtn.className = 'btn btn-ghost small';
            resyncBtn.textContent = '↻ Resync';
            resyncBtn.title = 'Re-scan this saved folder';
            resyncBtn.onclick = async () => {
                try {
                    resyncBtn.disabled = true;
                    resyncBtn.textContent = '…';
                    await FAFOLibrary.ensurePermission(f.handle, 'read');
                    const r = await FAFOLibrary.resyncFolder(db, f.id);
                    showToast(`Resynced “${f.name}” — ${r.count} files`);
                    allLibraryItems = [];
                    await loadLibraryGrid();
                    await refreshLinkedFoldersUI();
                } catch (e) {
                    showToast(e.message || 'Resync failed', 'error');
                } finally {
                    resyncBtn.disabled = false;
                    resyncBtn.textContent = '↻ Resync';
                }
            };
            const unlinkBtn = document.createElement('button');
            unlinkBtn.className = 'btn btn-danger small';
            unlinkBtn.textContent = 'Unlink';
            unlinkBtn.onclick = async () => {
                if (!confirm(`Unlink folder “${f.name}” and remove its indexed files?`)) return;
                try {
                    const storeName = f.storeName || (f.kind === 'photo' ? 'photos' : 'videos');
                    await FAFOLibrary.clearMediaForFolder(db, storeName, f.id);
                    await FAFOLibrary.deleteFolderRecord(db, f.id);
                    showToast(`Unlinked ${f.name}`);
                    allLibraryItems = [];
                    await loadLibraryGrid();
                    await refreshLinkedFoldersUI();
                } catch (e) {
                    showToast(e.message || 'Unlink failed', 'error');
                }
            };
            row.appendChild(resyncBtn);
            row.appendChild(unlinkBtn);
            list.appendChild(row);
        }
    }

    if ($('add-vid-btn')) $('add-vid-btn').onclick = () => addFolder('videos', 'add-vid-btn');
    if ($('add-img-btn')) $('add-img-btn').onclick = () => addFolder('photos', 'add-img-btn');
    if ($('refresh-lib')) $('refresh-lib').onclick = () => {
        showToast('Refreshing Library…');
        allLibraryItems = [];
        loadLibraryGrid();
        refreshLinkedFoldersUI();
    };
    if ($('restore-access-btn')) {
        $('restore-access-btn').onclick = async () => {
            if (!db || !window.FAFOLibrary) return;
            try {
                showToast('Requesting folder permissions…');
                const r = await FAFOLibrary.restoreAccess(db);
                showToast(
                    `Restored: ${r.grantedFolders}/${r.folderCount} folders` +
                        (r.grantedFiles ? `, ${r.grantedFiles} legacy files` : '') +
                        (r.deniedFolders ? ` · ${r.deniedFolders} denied` : '')
                );
                allLibraryItems = [];
                await loadLibraryGrid();
                await refreshLinkedFoldersUI();
            } catch (e) {
                showToast(e.message || 'Restore failed', 'error');
            }
        };
    }
    if ($('resync-all-btn')) {
        $('resync-all-btn').onclick = async () => {
            if (!db || !window.FAFOLibrary) return;
            try {
                showToast('Resyncing all saved folders…');
                await FAFOLibrary.restoreAccess(db);
                const results = await FAFOLibrary.resyncAllFolders(db, { skipPermission: false });
                const ok = results.filter((x) => x.ok);
                const bad = results.filter((x) => !x.ok);
                const total = ok.reduce((s, x) => s + (x.count || 0), 0);
                showToast(
                    bad.length
                        ? `Resynced ${ok.length} folder(s) (${total} files); ${bad.length} failed — Restore Access first`
                        : `Resynced ${ok.length} folder(s) — ${total} files`
                );
                allLibraryItems = [];
                await loadLibraryGrid();
                await refreshLinkedFoldersUI();
            } catch (e) {
                showToast(e.message || 'Resync failed', 'error');
            }
        };
    }
    if ($('wipe-db')) {
        $('wipe-db').onclick = async () => {
            if (!db) return;
            if (!confirm('⚠️ WIPE LIBRARY? Removes files, folders, and playlists.')) return;
            const stores = ['videos', 'photos', 'playlists'];
            if (db.objectStoreNames.contains('folders')) stores.push('folders');
            const tx = db.transaction(stores, 'readwrite');
            stores.forEach((s) => tx.objectStore(s).clear());
            tx.oncomplete = () => {
                showToast('Library wiped', 'error');
                allLibraryItems = [];
                loadLibraryGrid();
                loadPlaylistsUI();
                refreshLinkedFoldersUI();
            };
        };
    }

    loadSettings().then(async () => {
        await refreshLinkedFoldersUI();
        if (window.FAFOBackup?.tryRecoverEmptyLive) {
            await FAFOBackup.tryRecoverEmptyLive();
        }
        if (window.FAFOPairs) {
            await FAFOPairs.init({
                db,
                showToast,
                generateThumbnail: (file, seek) => generateThumbnail(file, seek),
            });
        }
        if (window.FAFOBackup) refreshTagsBackupUI();
    });
});