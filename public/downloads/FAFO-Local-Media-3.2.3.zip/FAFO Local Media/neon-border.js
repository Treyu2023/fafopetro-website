/**
 * Audio-reactive neon border engine v2 — smoothed bass, beat detect, spectrum & dual chase.
 */
class NeonBorderEngine {
    constructor(frameEl, getConfig) {
        this.frame = frameEl;
        this.getConfig = getConfig;
        this.segments = [];
        this.rafId = null;
        this.audioCtx = null;
        this.analyser = null;
        this.audioData = null;
        this.connectedVideo = null;
        this.stackProgress = 0;
        this.smoothAudio = 0;
        this.beatEnergy = 0;
        this.lastBeatTime = 0;
        this.beatFlash = 0;
    }

    getColor(cfg) {
        return cfg.neonUseAccent !== false ? (cfg.accentColor || '#00e5ff') : (cfg.neonColor || '#00e5ff');
    }

    hexToRgb(hex) {
        const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return m ? { r: +m[1], g: +m[2], b: +m[3] } : { r: 0, g: 229, b: 255 };
    }

    rebuild() {
        const cfg = this.getConfig();
        if (!this.frame) return;
        this.frame.innerHTML = '';
        this.segments = [];
        if (!cfg.neonBorder) {
            this.frame.classList.add('hidden');
            return;
        }
        this.frame.classList.remove('hidden');
        const count = cfg.neonSegments || 24;
        const color = this.getColor(cfg);
        const w = cfg.neonWidth || 4;
        for (let i = 0; i < count; i++) {
            const seg = document.createElement('div');
            seg.className = 'neon-segment';
            seg.dataset.index = i;
            seg.style.setProperty('--neon-color', color);
            seg.style.setProperty('--neon-width', `${w}px`);
            this.frame.appendChild(seg);
            this.segments.push(seg);
        }
        this.layoutSegments(count);
        this.addCornerNodes(color, w);
    }

    addCornerNodes(color, w) {
        if (!this.frame) return;
        ['tl', 'tr', 'br', 'bl'].forEach((pos) => {
            const node = document.createElement('div');
            node.className = `neon-corner neon-corner-${pos}`;
            node.style.setProperty('--neon-color', color);
            node.style.setProperty('--neon-width', `${w * 2}px`);
            this.frame.appendChild(node);
        });
    }

    layoutSegments(count) {
        const perSide = Math.max(2, Math.ceil(count / 4));
        if (this.frame) this.frame.style.setProperty('--seg-span', String(perSide));
        this.segments.forEach((seg, i) => {
            const side = Math.min(3, Math.floor(i / perSide));
            const pos = (i % perSide) / Math.max(1, perSide - 1);
            seg.style.opacity = '0.06';
            seg.classList.remove('top', 'bottom', 'left', 'right');
            seg.style.left = '';
            seg.style.right = '';
            seg.style.top = '';
            seg.style.bottom = '';
            if (side === 0) { seg.classList.add('top'); seg.style.left = `${pos * 100}%`; }
            else if (side === 1) { seg.classList.add('right'); seg.style.top = `${pos * 100}%`; }
            else if (side === 2) { seg.classList.add('bottom'); seg.style.left = `${(1 - pos) * 100}%`; }
            else { seg.classList.add('left'); seg.style.top = `${(1 - pos) * 100}%`; }
        });
    }

    async connectAudio(videoEl) {
        if (!videoEl || videoEl === this.connectedVideo) return;
        const cfg = this.getConfig();
        if (!cfg.neonBorder || cfg.neonAudio === false) return;
        this.disconnectAudio();
        this.connectedVideo = videoEl;
        try {
            this.audioCtx = new AudioContext();
            if (this.audioCtx.state === 'suspended') await this.audioCtx.resume();
            const source = this.audioCtx.createMediaElementSource(videoEl);
            this.analyser = this.audioCtx.createAnalyser();
            this.analyser.fftSize = 512;
            this.analyser.smoothingTimeConstant = 0.65;
            source.connect(this.analyser);
            this.analyser.connect(this.audioCtx.destination);
            this.audioData = new Uint8Array(this.analyser.frequencyBinCount);
        } catch (e) {
            console.warn('Neon audio connect failed', e);
            this.disconnectAudio();
        }
    }

    disconnectAudio() {
        if (this.audioCtx) {
            try { this.audioCtx.close(); } catch (_) {}
        }
        this.audioCtx = null;
        this.analyser = null;
        this.audioData = null;
        this.connectedVideo = null;
        this.smoothAudio = 0;
        this.beatEnergy = 0;
    }

    getAudioLevel() {
        if (!this.analyser || !this.audioData) return { bass: 0, mids: 0, highs: 0, raw: 0, bins: null };
        this.analyser.getByteFrequencyData(this.audioData);
        const cfg = this.getConfig();
        const sens = cfg.neonSensitivity || 1.2;
        const len = this.audioData.length;
        const bassEnd = Math.floor(len * 0.12);
        const midEnd = Math.floor(len * 0.45);
        let bass = 0, mids = 0, highs = 0;
        for (let i = 0; i < bassEnd; i++) bass += this.audioData[i];
        for (let i = bassEnd; i < midEnd; i++) mids += this.audioData[i];
        for (let i = midEnd; i < len; i++) highs += this.audioData[i];
        bass = Math.min(1, (bass / bassEnd / 255) * sens);
        mids = Math.min(1, (mids / (midEnd - bassEnd) / 255) * sens);
        highs = Math.min(1, (highs / (len - midEnd) / 255) * sens);
        return { bass, mids, highs, raw: bass, bins: this.audioData };
    }

    updateBeat(bass, time) {
        this.beatEnergy = this.beatEnergy * 0.92 + bass * 0.08;
        const threshold = 0.28 + (this.getConfig().neonStrobe || 0.8) * 0.12;
        if (bass > threshold && bass > this.beatEnergy * 1.15 && time - this.lastBeatTime > 0.12) {
            this.lastBeatTime = time;
            this.beatFlash = 1;
        }
        this.beatFlash *= 0.88;
    }

    start() {
        this.stop();
        this.rebuild();
        const loop = (time) => {
            this.tick(time * 0.001);
            this.rafId = requestAnimationFrame(loop);
        };
        this.rafId = requestAnimationFrame(loop);
    }

    stop() {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = null;
    }

    destroy() {
        this.stop();
        this.disconnectAudio();
        if (this.frame) this.frame.innerHTML = '';
        this.segments = [];
    }

    setSegmentBrightness(seg, level, color, extraGlow = 0) {
        const glow = 6 + level * 35 + extraGlow * 25;
        const rgb = this.hexToRgb(color);
        const hot = Math.min(1, level + extraGlow * 0.5);
        seg.style.opacity = String(0.05 + hot * 0.95);
        seg.style.background = `linear-gradient(135deg, rgba(${rgb.r},${rgb.g},${rgb.b},1), rgba(255,255,255,${hot * 0.4}))`;
        seg.style.boxShadow = [
            `0 0 ${glow}px ${color}`,
            `0 0 ${glow * 1.8}px rgba(${rgb.r},${rgb.g},${rgb.b},0.5)`,
            `inset 0 0 ${glow * 0.4}px rgba(255,255,255,${hot * 0.3})`
        ].join(', ');
    }

    setCornerPulse(level, color) {
        if (!this.frame) return;
        this.frame.querySelectorAll('.neon-corner').forEach((node) => {
            const glow = 8 + level * 30;
            node.style.opacity = String(0.1 + level * 0.9);
            node.style.boxShadow = `0 0 ${glow}px ${color}, 0 0 ${glow * 2}px ${color}`;
        });
    }

    tick(time) {
        const cfg = this.getConfig();
        if (!cfg.neonBorder || !this.segments.length) return;

        const color = this.getColor(cfg);
        const count = this.segments.length;
        const speed = (cfg.neonSpeed || 1) * 2;
        const audioData = cfg.neonAudio !== false ? this.getAudioLevel() : { bass: 0, mids: 0, highs: 0, raw: 0, bins: null };
        const audio = audioData.bass;
        this.smoothAudio += (audio - this.smoothAudio) * 0.18;
        this.updateBeat(audio, time);
        const strobeAmt = cfg.neonStrobe || 0.8;
        const pattern = cfg.neonPattern || 'chase';
        const beatBoost = this.beatFlash * strobeAmt;

        this.segments.forEach(s => s.style.setProperty('--neon-color', color));
        this.frame?.querySelectorAll('.neon-corner').forEach(n => n.style.setProperty('--neon-color', color));

        switch (pattern) {
            case 'strobe': {
                const beat = audio > (0.22 - strobeAmt * 0.12) || this.beatFlash > 0.4;
                const flash = beat ? 0.55 + audio * 0.45 + beatBoost * 0.3 : 0.04;
                this.segments.forEach(seg => this.setSegmentBrightness(seg, flash, color, beatBoost));
                this.setCornerPulse(flash, color);
                break;
            }
            case 'pulse': {
                const pulse = 0.3 + this.smoothAudio * 0.55 + Math.sin(time * speed * 2.5) * 0.15 + beatBoost * 0.2;
                this.segments.forEach(seg => this.setSegmentBrightness(seg, Math.min(1, pulse), color));
                this.setCornerPulse(pulse * 0.8, color);
                break;
            }
            case 'wave': {
                this.segments.forEach((seg, i) => {
                    const wave = (Math.sin(time * speed * 2.2 + (i / count) * Math.PI * 2) + 1) / 2;
                    this.setSegmentBrightness(seg, wave * (0.35 + this.smoothAudio * 0.65), color);
                });
                this.setCornerPulse(this.smoothAudio, color);
                break;
            }
            case 'stack': {
                this.stackProgress += 0.014 * speed * (1 + this.smoothAudio * 0.5);
                if (this.stackProgress > count + 2) this.stackProgress = 0;
                const lit = Math.floor(this.stackProgress);
                this.segments.forEach((seg, i) => {
                    let level = i < lit ? 0.8 : 0.05;
                    if (i === lit) level = 0.35 + audio * 0.65;
                    if (this.beatFlash > 0.3 && i === lit) level = 1;
                    this.setSegmentBrightness(seg, level, color, i === lit ? beatBoost : 0);
                });
                break;
            }
            case 'flicker': {
                this.segments.forEach((seg, i) => {
                    const seed = Math.sin(time * 12 + i * 7.3) * 0.5 + 0.5;
                    const flick = seed < (0.12 - audio * 0.08) ? 0.9 + audio * 0.1 : 0.06 + audio * 0.15;
                    this.setSegmentBrightness(seg, Math.min(1, flick), color);
                });
                break;
            }
            case 'spectrum': {
                const bins = audioData.bins;
                this.segments.forEach((seg, i) => {
                    let level = 0.06;
                    if (bins) {
                        const bin = Math.floor((i / count) * bins.length * 0.6);
                        level = 0.08 + (bins[bin] / 255) * 0.85 * (cfg.neonSensitivity || 1.2);
                    }
                    level = Math.min(1, level + beatBoost * 0.25);
                    this.setSegmentBrightness(seg, level, color);
                });
                this.setCornerPulse(this.smoothAudio + beatBoost * 0.3, color);
                break;
            }
            case 'dual': {
                const head1 = Math.floor((time * speed * 3.5) % count);
                const head2 = (head1 + Math.floor(count / 2)) % count;
                const tail = 4;
                this.segments.forEach((seg, i) => {
                    let d1 = Math.abs(i - head1);
                    let d2 = Math.abs(i - head2);
                    if (d1 > count / 2) d1 = count - d1;
                    if (d2 > count / 2) d2 = count - d2;
                    const l1 = d1 === 0 ? 1 : d1 <= tail ? 0.75 - d1 * 0.15 : 0;
                    const l2 = d2 === 0 ? 1 : d2 <= tail ? 0.75 - d2 * 0.15 : 0;
                    let level = Math.max(l1, l2, 0.05) + this.smoothAudio * strobeAmt * 0.35;
                    this.setSegmentBrightness(seg, Math.min(1, level), color, (l1 > 0.8 || l2 > 0.8) ? beatBoost : 0);
                });
                break;
            }
            case 'chase':
            default: {
                const head = Math.floor((time * speed * 4) % count);
                const tail = 4;
                this.segments.forEach((seg, i) => {
                    let dist = Math.abs(i - head);
                    if (dist > count / 2) dist = count - dist;
                    let level = dist === 0 ? 1 : dist <= tail ? 0.72 - dist * 0.16 : 0.05;
                    level = Math.min(1, level + this.smoothAudio * strobeAmt * 0.45 + (dist === 0 ? beatBoost * 0.3 : 0));
                    this.setSegmentBrightness(seg, level, color, dist === 0 ? beatBoost : 0);
                });
                break;
            }
        }
    }
}