@echo off
setlocal EnableExtensions
title FAFO — restart meta server
cd /d "%~dp0"

echo.
echo  Restarting FAFO Explorer Metadata Server...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$con = Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue;" ^
  "if ($con) {" ^
  "  $con | Select-Object -ExpandProperty OwningProcess -Unique | ForEach-Object {" ^
  "    if ($_ -gt 0) {" ^
  "      $n = (Get-Process -Id $_ -ErrorAction SilentlyContinue).ProcessName;" ^
  "      Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue;" ^
  "      Write-Host ('  Stopped PID {0} ({1})' -f $_, $n)" ^
  "    }" ^
  "  }; Start-Sleep -Seconds 1" ^
  "} else { Write-Host '  Port 8765 was already free.' }"

where python >nul 2>&1
if errorlevel 1 (
  echo Python not found.
  pause
  exit /b 1
)

echo.
echo  Starting on http://127.0.0.1:8765
echo  Leave this window open while you use FAFO.
echo.

python "%~dp0server.py"
if errorlevel 1 (
  echo.
  echo  Start failed.
  pause
)
