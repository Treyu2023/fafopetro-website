/**
 * FAFO persistent tag/meta backup & restore.
 * - Live data: chrome.storage.local (fafoMediaMeta, hotkeys, pairs, …)
 * - Latest snapshot: fafoTagsSnapshot
 * - Rolling history: fafoTagsBackupHistory (up to 12)
 * - Downloadable JSON export / import
 */
(function (global) {
    'use strict';

    const KIND = 'fafo-tags-backup';
    const VERSION = 3;
    const HISTORY_KEY = 'fafoTagsBackupHistory';
    const SNAPSHOT_KEY = 'fafoTagsSnapshot';
    const HISTORY_MAX = 12;
    const HISTORY_MIN_MS = 45 * 1000; // don't flood history more than every 45s
    const TOOLBOX_API = 'http://127.0.0.1:8765/api';

    /** Public live keys only — secret-mode data is NEVER mixed into public backups/exports. */
    const LIVE_KEYS = [
        'fafoMediaMeta',
        'fafoTagLibrary',
        'fafoTagLastUsed',
        'fafoTagHotkeys',
        'fafoTagApplyCounts',
        'fafoTagCountMode',
        'fafoSkipTaggedMode',
        'fafoApplyAndNext',
        'fafoTagsPanelStartOpen',
        'fafoHudDock',
        'fafoHudPinned',
        'fafoHudClean',
        'fafoHudQuickTags',
        'fafoManualRepeat',
        'fafoTagLibraryHeight',
        'fafoMetaPanelWidth',
        'fafoMetaPanelHeight',
        'fafoMetaDockPos',
        'fafoMetaDockX',
        'fafoMetaDockY',
        'fafoMetaUiScale',
        'fafoChromeScale',
        'fafoMetaStickLayout',
        'fafoMetaLibX',
        'fafoMetaLibY',
        'fafoMetaLibW',
        'fafoMetaLibH',
        'fafoMetaLibPosSaved',
        'fafoMetaPanelOpen',
        'fafoMetaSplit',
        'fafoMetaLayoutMemory',
        'fafoMetaLayoutVpW',
        'fafoMetaLayoutVpH',
        'fafoMetaLayoutMode',
        'fafoVideoStage',
        'fafoScaleDefaultsV2',
        'fafoTagExcluded',
        'fafoExtraTagBanks',
        'fafoRecentTags',
        'fafoSprintTags',
        'fafoPairs',
        'mediaConfig',
        'fafoPlaylistsBackup',
        'fafoLibraryCatalog',
        'fafoUserSettingsText',
        'fafoChromeArt',
        'fafoLayoutPresets',
        'fafoLayoutPresetActive',
        'fafoAutoDiskSync',
        'fafoMetaLedger',
        'fafoVisual',
        'fafoCustomThemes',
        'fafoActiveCustomThemeId',
        // Tag colors / slots / themes (public)
        'fafoTagColors',
        'fafoTagColorPresets',
        'fafoTagColorSlots',
        'fafoTagColorSlotsByTheme',
        'fafoTagChosenStyle',
        'fafoTagTypeStyle',
        'fafoTagTheme',
        'fafoTagThemeCustom',
        'fafoTagThemeUserPacks',
        // Named full-system configs catalog
        'fafoNamedConfigs',
        'fafoConfigsFolderPath',
    ];

    /** Private vault keys — stored only in fafoTagsSnapshotPrivate, never public export. */
    const PRIVATE_LIVE_KEYS = [
        'fafoMediaMetaPrivate',
        'fafoTagLibraryPrivate',
        'fafoTagLastUsedPrivate',
        'fafoTagHotkeysPrivate',
        'fafoTagExcludedPrivate',
        'fafoRecentTagsPrivate',
        'fafoTagApplyCountsPrivate',
        'fafoExtraTagBanksPrivate',
        'fafoSprintTagsPrivate',
        'fafoPairsPrivate',
        'fafoTagColorsPrivate',
        'fafoMetaLedgerPrivate',
    ];
    const PRIVATE_KEY_SET = new Set(PRIVATE_LIVE_KEYS);
    const SNAPSHOT_PRIVATE_KEY = 'fafoTagsSnapshotPrivate';

    function stripPrivateKeys(obj) {
        if (!obj || typeof obj !== 'object') return obj;
        const out = { ...obj };
        Object.keys(out).forEach((k) => {
            // Legacy *Private + multi-vault *Private_{id} + vault registry
            if (
                PRIVATE_KEY_SET.has(k)
                || /Private($|_)/i.test(k)
                || k === 'fafoPrivateVaults'
                || k === 'fafoPrivateVault'
                || k === 'fafoPrivateSession'
                || k === 'fafoTdK'
                || /^fafoTagDb/i.test(k)
            ) {
                delete out[k];
            }
        });
        return out;
    }

    const NAMED_CONFIGS_KEY = 'fafoNamedConfigs';
    const CONFIGS_PATH_KEY = 'fafoConfigsFolderPath';
    const DEFAULT_CONFIGS_PATH =
        'C:\\_Git\\repos\\html\\fafo-chrome-extensions\\FAFO Local Media LOAD THIS\\configs';
    const FULL_CONFIG_KIND = 'fafo-full-system-config';

    let lastHistoryWrite = 0;
    let lastDiskWrite = 0;
    const DISK_MIN_MS = 8 * 1000; // throttle companion disk JSON writes

    function metaEntryCount(meta) {
        return meta && typeof meta === 'object' ? Object.keys(meta).length : 0;
    }

    async function readLive() {
        const data = await chrome.storage.local.get(LIVE_KEYS);
        // Full dump of known keys (omit undefined)
        const out = {};
        LIVE_KEYS.forEach((k) => {
            if (data[k] !== undefined) out[k] = data[k];
        });
        // Normalized aliases used by older restore paths
        out.fafoMediaMeta = data.fafoMediaMeta || {};
        out.fafoTagLibrary = Array.isArray(data.fafoTagLibrary) ? data.fafoTagLibrary : [];
        out.fafoTagLastUsed = data.fafoTagLastUsed || {};
        out.fafoTagHotkeys = data.fafoTagHotkeys || null;
        out.fafoTagApplyCounts = data.fafoTagApplyCounts || {};
        out.fafoTagCountMode = data.fafoTagCountMode || 'session';
        out.fafoSkipTaggedMode = !!data.fafoSkipTaggedMode;
        out.fafoApplyAndNext = !!data.fafoApplyAndNext;
        out.fafoTagsPanelStartOpen = !!data.fafoTagsPanelStartOpen;
        out.fafoTagExcluded = Array.isArray(data.fafoTagExcluded) ? data.fafoTagExcluded : [];
        out.fafoExtraTagBanks = data.fafoExtraTagBanks || null;
        out.fafoPairs = Array.isArray(data.fafoPairs) ? data.fafoPairs : [];
        out.mediaConfig = data.mediaConfig || {};
        out.playlists = Array.isArray(data.fafoPlaylistsBackup) ? data.fafoPlaylistsBackup : [];
        out.libraryCatalog = data.fafoLibraryCatalog || null;
        out.fafoUserSettingsText = data.fafoUserSettingsText || '';
        out.fafoChromeArt = data.fafoChromeArt || null;
        out.fafoLayoutPresets = Array.isArray(data.fafoLayoutPresets) ? data.fafoLayoutPresets : [];
        out.fafoLayoutPresetActive = data.fafoLayoutPresetActive || '';
        out.fafoAutoDiskSync = data.fafoAutoDiskSync !== false;
        out.fafoVisual = data.fafoVisual || null;
        out.fafoCustomThemes = Array.isArray(data.fafoCustomThemes) ? data.fafoCustomThemes : [];
        out.fafoActiveCustomThemeId = data.fafoActiveCustomThemeId || '';
        return out;
    }

    /**
     * Pull playlists + file catalog from IndexedDB when FAFOLibrary is available.
     * Always re-mirrors into chrome.storage so every save has a JSON-ready copy.
     */
    async function enrichLiveFromIdb(live) {
        const out = { ...live };
        try {
            if (global.FAFOLibrary?.exportSerializableCatalog) {
                const cat = await FAFOLibrary.exportSerializableCatalog();
                if (cat) {
                    if (Array.isArray(cat.playlists)) out.playlists = cat.playlists;
                    if (cat.libraryCatalog) out.libraryCatalog = cat.libraryCatalog;
                    // Persist mirrors so export works even if IDB is busy later
                    await chrome.storage.local.set({
                        fafoPlaylistsBackup: out.playlists || [],
                        fafoLibraryCatalog: out.libraryCatalog || null,
                    });
                }
            }
        } catch (e) {
            console.warn('FAFO backup IDB enrich failed', e);
        }
        return out;
    }

    function buildBundle(live, reason) {
        const meta = live.fafoMediaMeta || {};
        const catalog = live.libraryCatalog || null;
        const playlists = Array.isArray(live.playlists) ? live.playlists : [];
        return {
            kind: KIND,
            version: VERSION,
            savedAt: Date.now(),
            reason: reason || 'auto',
            stats: {
                mediaEntries: metaEntryCount(meta),
                tagCount: (live.fafoTagLibrary || []).length,
                pairCount: (live.fafoPairs || []).length,
                applyCountKeys: live.fafoTagApplyCounts
                    ? Object.keys(live.fafoTagApplyCounts).length
                    : 0,
                playlistCount: playlists.length,
                libraryVideoCount: catalog?.videoCount ?? catalog?.videos?.length ?? 0,
                libraryPhotoCount: catalog?.photoCount ?? catalog?.photos?.length ?? 0,
                hasMediaConfig: !!(live.mediaConfig && Object.keys(live.mediaConfig).length),
            },
            data: {
                fafoMediaMeta: live.fafoMediaMeta || {},
                fafoTagLibrary: live.fafoTagLibrary || [],
                fafoTagLastUsed: live.fafoTagLastUsed || {},
                fafoTagHotkeys: live.fafoTagHotkeys,
                fafoTagApplyCounts: live.fafoTagApplyCounts || {},
                fafoTagCountMode: live.fafoTagCountMode || 'session',
                fafoSkipTaggedMode: !!live.fafoSkipTaggedMode,
                fafoTagLibraryHeight: live.fafoTagLibraryHeight,
                fafoMetaPanelWidth: live.fafoMetaPanelWidth,
                fafoTagExcluded: live.fafoTagExcluded || [],
                fafoExtraTagBanks: live.fafoExtraTagBanks || null,
                fafoPairs: live.fafoPairs || [],
                // Always include options + playlists + file index (unless wipe cleared them)
                mediaConfig: live.mediaConfig || {},
                playlists,
                libraryCatalog: catalog,
                fafoUserSettingsText: live.fafoUserSettingsText || '',
                fafoChromeArt: live.fafoChromeArt || null,
                fafoLayoutPresets: live.fafoLayoutPresets || [],
                fafoLayoutPresetActive: live.fafoLayoutPresetActive || '',
                fafoAutoDiskSync: live.fafoAutoDiskSync !== false,
                fafoVisual: live.fafoVisual || null,
                fafoCustomThemes: live.fafoCustomThemes || [],
                fafoActiveCustomThemeId: live.fafoActiveCustomThemeId || '',
            },
        };
    }

    /**
     * Write structured vault on companion disk:
     *   FAFO-Backups/latest/full.json
     *   FAFO-Backups/rolling/<type>/… (keep 5–10 each)
     */
    async function writeDiskBackup(bundle, force) {
        try {
            const now = Date.now();
            if (!force && now - lastDiskWrite < DISK_MIN_MS) return false;
            lastDiskWrite = now;
            const reason = bundle?.reason || 'auto';
            const r = await fetch(`${TOOLBOX_API}/fafo/backup`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ bundle, reason }),
                signal: AbortSignal.timeout(6000),
            });
            if (!r.ok) return false;
            const j = await r.json().catch(() => ({}));
            // Also try user-picked backup folder (File System Access) when available
            tryWriteUserBackupFolder(bundle, reason).catch(() => {});
            return j;
        } catch {
            return false;
        }
    }

    /** Optional: user-selected backup root (IDB handle kind=backup-vault). */
    async function tryWriteUserBackupFolder(bundle, reason) {
        if (!global.FAFOLibrary?.openDB || !global.FAFOLibrary?.listFolders) return false;
        try {
            const db = await FAFOLibrary.openDB();
            const folders = await FAFOLibrary.listFolders(db);
            const vault = folders.find((f) => f.id === 'backup-vault' || f.kind === 'backup-vault');
            if (!vault?.handle) return false;
            const ok = await FAFOLibrary.ensurePermission(vault.handle, 'readwrite');
            if (!ok) return false;
            await writeBundleToDirectoryHandle(vault.handle, bundle, reason);
            return true;
        } catch (e) {
            console.warn('FAFO user backup folder write', e);
            return false;
        }
    }

    function bucketForReason(reason) {
        const r = String(reason || 'auto').toLowerCase();
        if (r === 'export') return 'export';
        if (r === 'manual' || r === 'snapshot') return 'manual';
        if (r === 'options-save' || r === 'chrome-art' || r === 'config') return 'options';
        if (r === 'visual-fx' || r === 'visual' || r === 'theme') return 'visual';
        if (r.startsWith('playlist')) return 'playlists';
        if (r.includes('restore')) return 'restore';
        if (r.includes('tag') || r.includes('pair')) return 'tags';
        if (r.includes('theme')) return 'themes';
        return 'auto';
    }

    const KEEP_BY_BUCKET = {
        auto: 10, tags: 10, options: 10, export: 10, manual: 10,
        visual: 5, playlists: 10, restore: 5, themes: 20,
    };

    async function ensureDir(parent, name) {
        return parent.getDirectoryHandle(name, { create: true });
    }

    async function writeFile(dir, name, text) {
        const fh = await dir.getFileHandle(name, { create: true });
        const w = await fh.createWritable();
        await w.write(text);
        await w.close();
    }

    async function pruneDir(dir, keep) {
        const entries = [];
        for await (const [name, handle] of dir.entries()) {
            if (handle.kind === 'file' && name.endsWith('.json')) {
                try {
                    const f = await handle.getFile();
                    entries.push({ name, mtime: f.lastModified });
                } catch {
                    entries.push({ name, mtime: 0 });
                }
            }
        }
        entries.sort((a, b) => b.mtime - a.mtime);
        for (const old of entries.slice(Math.max(1, keep))) {
            try { await dir.removeEntry(old.name); } catch (_) {}
        }
    }

    async function writeBundleToDirectoryHandle(rootHandle, bundle, reason) {
        const text = JSON.stringify(bundle, null, 2);
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        const bucket = bucketForReason(reason);
        const keep = KEEP_BY_BUCKET[bucket] || 10;

        // README once
        try {
            const existing = await rootHandle.getFileHandle('README.txt').catch(() => null);
            if (!existing) {
                await writeFile(rootHandle, 'README.txt',
                    'FAFO Ultimate Tab backups\n' +
                    'latest/full.json — newest snapshot\n' +
                    'rolling/<type>/ — last 5–10 per type (auto-pruned)\n' +
                    'themes/ — named custom themes\n'
                );
            }
        } catch (_) {}

        const latest = await ensureDir(rootHandle, 'latest');
        await writeFile(latest, 'full.json', text);
        try {
            const visual = bundle?.data?.fafoVisual || bundle?.data?.mediaConfig?.visual;
            if (visual) await writeFile(latest, 'visual.json', JSON.stringify(visual, null, 2));
        } catch (_) {}

        const rolling = await ensureDir(rootHandle, 'rolling');
        const bucketDir = await ensureDir(rolling, bucket);
        const safe = String(reason || 'auto').replace(/[^a-z0-9_-]+/gi, '-').slice(0, 32);
        await writeFile(bucketDir, `${stamp}-${safe || 'auto'}.json`, text);
        await pruneDir(bucketDir, keep);

        // themes folder always present
        await ensureDir(rootHandle, 'themes');
    }

    async function linkUserBackupFolder() {
        if (!global.showDirectoryPicker) throw new Error('Folder picker not supported');
        const handle = await showDirectoryPicker({ id: 'fafo-backup-vault', mode: 'readwrite' });
        // Prefer creating FAFO-Backups subfolder inside chosen location
        let root = handle;
        try {
            root = await handle.getDirectoryHandle('FAFO-Backups', { create: true });
        } catch {
            root = handle;
        }
        const db = await FAFOLibrary.openDB();
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').put({
            id: 'backup-vault',
            name: root.name || 'FAFO-Backups',
            handle: root,
            kind: 'backup-vault',
            addedAt: Date.now(),
        });
        await new Promise((res, rej) => {
            tx.oncomplete = () => res();
            tx.onerror = () => rej(tx.error);
        });
        // Seed readme + empty structure
        await writeBundleToDirectoryHandle(root, {
            kind: KIND,
            version: VERSION,
            reason: 'manual',
            savedAt: Date.now(),
            data: {},
            note: 'Vault initialized',
        }, 'manual');
        return { name: root.name, pathHint: 'FAFO-Backups' };
    }

    async function getUserBackupFolderInfo() {
        try {
            if (!global.FAFOLibrary?.listFolders) return null;
            const db = await FAFOLibrary.openDB();
            const folders = await FAFOLibrary.listFolders(db);
            const vault = folders.find((f) => f.id === 'backup-vault' || f.kind === 'backup-vault');
            if (!vault) return null;
            const perm = await FAFOLibrary.queryPermissionOnly?.(vault.handle);
            return { name: vault.name, permission: perm || 'unknown' };
        } catch {
            return null;
        }
    }

    async function vaultStatusFromServer() {
        try {
            const r = await fetch(`${TOOLBOX_API}/fafo/backup/status`, {
                signal: AbortSignal.timeout(2500),
            });
            if (!r.ok) return null;
            return await r.json();
        } catch {
            return null;
        }
    }

    async function saveThemeToDisk(theme) {
        try {
            await fetch(`${TOOLBOX_API}/fafo/theme`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ theme, name: theme?.name || 'custom' }),
                signal: AbortSignal.timeout(4000),
            });
        } catch (_) {}
        try {
            if (global.FAFOLibrary?.openDB) {
                const db = await FAFOLibrary.openDB();
                const folders = await FAFOLibrary.listFolders(db);
                const vault = folders.find((f) => f.id === 'backup-vault' || f.kind === 'backup-vault');
                if (vault?.handle && await FAFOLibrary.ensurePermission(vault.handle, 'readwrite')) {
                    const themes = await vault.handle.getDirectoryHandle('themes', { create: true });
                    const safe = String(theme?.name || 'theme').replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 48);
                    await writeFile(themes, `${safe || 'theme'}.json`, JSON.stringify(theme, null, 2));
                    await pruneDir(themes, KEEP_BY_BUCKET.themes || 20);
                }
            }
        } catch (_) {}
    }

    /**
     * After a successful live save — refresh snapshot + maybe history + disk JSON.
     * Pass optional partial live override (from in-memory meta module).
     * Always mirrors options (mediaConfig), playlists, and library file index.
     */
    async function afterLiveSave(partial, reason) {
        try {
            // Never accept secret-mode lists into the public backup stream
            const safePartial = stripPrivateKeys(partial || {});
            let live = { ...(await readLive()), ...safePartial };
            live = stripPrivateKeys(live);
            // Pull IDB playlists/files unless caller wiped / skipped
            if (reason !== 'wipe' && partial?.skipIdbEnrich !== true) {
                live = await enrichLiveFromIdb(live);
                live = stripPrivateKeys(live);
            }
            delete live.skipIdbEnrich;
            const bundle = buildBundle(live, reason || 'auto');
            if (bundle?.data) bundle.data = stripPrivateKeys(bundle.data);
            await chrome.storage.local.set({ [SNAPSHOT_KEY]: bundle });

            const now = Date.now();
            const forceHistory = reason === 'manual' || reason === 'export' || reason === 'pre-restore'
                || reason === 'post-restore' || reason === 'options-save' || reason === 'playlist-edit'
                || reason === 'playlist-create' || reason === 'playlist-rename' || reason === 'playlist-delete';
            if (now - lastHistoryWrite >= HISTORY_MIN_MS || forceHistory) {
                lastHistoryWrite = now;
                const res = await chrome.storage.local.get([HISTORY_KEY]);
                let history = Array.isArray(res[HISTORY_KEY]) ? res[HISTORY_KEY] : [];
                const entry = {
                    id: 'bak_' + now.toString(36),
                    ...bundle,
                };
                // History slots: keep playlists; drop bulky catalog + full mediaConfig to save quota
                if (entry.data) {
                    delete entry.data.mediaConfig;
                    delete entry.data.libraryCatalog;
                    delete entry.data.fafoUserSettingsText;
                }
                history = [entry, ...history.filter((h) => h && h.id !== entry.id)].slice(0, HISTORY_MAX);
                await chrome.storage.local.set({ [HISTORY_KEY]: history });
            }

            // Disk JSON every save (throttled) — full bundle including options + files + playlists
            writeDiskBackup(bundle, forceHistory).catch(() => {});
            return bundle;
        } catch (e) {
            console.warn('FAFO backup afterLiveSave failed', e);
            return null;
        }
    }

    /**
     * Secret-mode only: snapshot private keys to a separate store (not exported by default).
     * Public recovery / Options export never reads this key.
     */
    async function afterPrivateLiveSave(partial, reason) {
        try {
            const priv = {};
            const src = partial && typeof partial === 'object' ? partial : {};
            PRIVATE_LIVE_KEYS.forEach((k) => {
                if (src[k] !== undefined) priv[k] = src[k];
            });
            // Also pull latest private keys from chrome.storage for completeness
            const disk = await chrome.storage.local.get(PRIVATE_LIVE_KEYS);
            PRIVATE_LIVE_KEYS.forEach((k) => {
                if (priv[k] === undefined && disk[k] !== undefined) priv[k] = disk[k];
            });
            const bundle = {
                kind: 'fafo-private-tags-backup',
                version: VERSION,
                savedAt: new Date().toISOString(),
                reason: reason || 'private-auto',
                data: priv,
            };
            await chrome.storage.local.set({ [SNAPSHOT_PRIVATE_KEY]: bundle });
            return bundle;
        } catch (e) {
            console.warn('FAFO private backup failed', e);
            return null;
        }
    }

    async function getSnapshot() {
        const res = await chrome.storage.local.get([SNAPSHOT_KEY]);
        return res[SNAPSHOT_KEY] || null;
    }

    async function listHistory() {
        const res = await chrome.storage.local.get([HISTORY_KEY]);
        return Array.isArray(res[HISTORY_KEY]) ? res[HISTORY_KEY] : [];
    }

    function applyBundleToStoragePayload(bundle, opts = {}) {
        const d = bundle?.data || bundle;
        if (!d || typeof d !== 'object') throw new Error('Invalid backup data');
        const out = {};
        // Full-system restore: copy every known live key present in the bundle
        if (opts.fullSystem || bundle?.kind === FULL_CONFIG_KIND) {
            LIVE_KEYS.forEach((k) => {
                if (k === NAMED_CONFIGS_KEY) return; // don't clobber catalog from inside a config
                if (d[k] !== undefined) out[k] = d[k];
            });
            // aliases
            if (Array.isArray(d.playlists)) out.fafoPlaylistsBackup = d.playlists;
            if (d.libraryCatalog != null) out.fafoLibraryCatalog = d.libraryCatalog;
            return out;
        }
        if (d.fafoMediaMeta != null) out.fafoMediaMeta = d.fafoMediaMeta;
        if (d.fafoTagLibrary != null) out.fafoTagLibrary = d.fafoTagLibrary;
        if (d.fafoTagLastUsed != null) out.fafoTagLastUsed = d.fafoTagLastUsed;
        if (d.fafoTagHotkeys != null) out.fafoTagHotkeys = d.fafoTagHotkeys;
        if (d.fafoTagApplyCounts != null) out.fafoTagApplyCounts = d.fafoTagApplyCounts;
        if (d.fafoTagCountMode != null) out.fafoTagCountMode = d.fafoTagCountMode;
        if (d.fafoSkipTaggedMode != null) out.fafoSkipTaggedMode = !!d.fafoSkipTaggedMode;
        if (d.fafoApplyAndNext != null) out.fafoApplyAndNext = !!d.fafoApplyAndNext;
        if (d.fafoTagsPanelStartOpen != null) out.fafoTagsPanelStartOpen = !!d.fafoTagsPanelStartOpen;
        if (d.fafoHudDock != null) out.fafoHudDock = d.fafoHudDock;
        if (d.fafoHudPinned != null) out.fafoHudPinned = !!d.fafoHudPinned;
        if (d.fafoHudClean != null) out.fafoHudClean = !!d.fafoHudClean;
        if (d.fafoHudQuickTags != null) out.fafoHudQuickTags = !!d.fafoHudQuickTags;
        if (d.fafoManualRepeat != null) out.fafoManualRepeat = !!d.fafoManualRepeat;
        if (d.fafoTagLibraryHeight != null) out.fafoTagLibraryHeight = d.fafoTagLibraryHeight;
        if (d.fafoMetaPanelWidth != null) out.fafoMetaPanelWidth = d.fafoMetaPanelWidth;
        if (d.fafoTagExcluded != null) out.fafoTagExcluded = d.fafoTagExcluded;
        if (d.fafoExtraTagBanks != null) out.fafoExtraTagBanks = d.fafoExtraTagBanks;
        if (d.fafoPairs != null) out.fafoPairs = d.fafoPairs;
        // Always restore options + playlist/file mirrors unless explicitly skipped
        if (opts.includeConfig !== false && d.mediaConfig) out.mediaConfig = d.mediaConfig;
        if (Array.isArray(d.playlists)) out.fafoPlaylistsBackup = d.playlists;
        if (d.libraryCatalog != null) out.fafoLibraryCatalog = d.libraryCatalog;
        if (d.fafoUserSettingsText != null) out.fafoUserSettingsText = d.fafoUserSettingsText;
        if (d.fafoChromeArt != null) out.fafoChromeArt = d.fafoChromeArt;
        if (Array.isArray(d.fafoLayoutPresets)) out.fafoLayoutPresets = d.fafoLayoutPresets;
        if (d.fafoLayoutPresetActive != null) out.fafoLayoutPresetActive = d.fafoLayoutPresetActive;
        if (d.fafoAutoDiskSync != null) out.fafoAutoDiskSync = !!d.fafoAutoDiskSync;
        if (d.fafoVisual != null) out.fafoVisual = d.fafoVisual;
        if (Array.isArray(d.fafoCustomThemes)) out.fafoCustomThemes = d.fafoCustomThemes;
        if (d.fafoActiveCustomThemeId != null) out.fafoActiveCustomThemeId = d.fafoActiveCustomThemeId;
        // Color / theme extras when present
        [
            'fafoTagColors', 'fafoTagColorPresets', 'fafoTagColorSlots', 'fafoTagColorSlotsByTheme',
            'fafoTagChosenStyle', 'fafoTagTypeStyle',
            'fafoTagTheme', 'fafoTagThemeCustom', 'fafoTagThemeUserPacks',
            'fafoVideoStage', 'fafoChromeScale', 'fafoMetaUiScale', 'fafoMetaLayoutMemory',
        ].forEach((k) => {
            if (d[k] !== undefined) out[k] = d[k];
        });
        return out;
    }

    function safeConfigFileName(name) {
        const base = String(name || 'FAFO-Config')
            .trim()
            .replace(/[<>:"/\\|?*\x00-\x1f]+/g, '-')
            .replace(/\s+/g, '-')
            .replace(/-+/g, '-')
            .replace(/^\.+|\.+$/g, '')
            .slice(0, 80) || 'FAFO-Config';
        const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
        return `${base}_${stamp}.json`;
    }

    async function getConfigsFolderPath() {
        try {
            const res = await chrome.storage.local.get(CONFIGS_PATH_KEY);
            if (typeof res[CONFIGS_PATH_KEY] === 'string' && res[CONFIGS_PATH_KEY].trim()) {
                return res[CONFIGS_PATH_KEY].trim();
            }
        } catch (_) {}
        return DEFAULT_CONFIGS_PATH;
    }

    async function setConfigsFolderPath(path) {
        const p = String(path || '').trim() || DEFAULT_CONFIGS_PATH;
        await chrome.storage.local.set({ [CONFIGS_PATH_KEY]: p });
        return p;
    }

    async function listNamedConfigs() {
        try {
            const res = await chrome.storage.local.get(NAMED_CONFIGS_KEY);
            return Array.isArray(res[NAMED_CONFIGS_KEY]) ? res[NAMED_CONFIGS_KEY] : [];
        } catch (_) {
            return [];
        }
    }

    async function rememberNamedConfig(entry) {
        const list = await listNamedConfigs();
        const next = [entry, ...list.filter((e) => e && e.id !== entry.id)].slice(0, 80);
        await chrome.storage.local.set({ [NAMED_CONFIGS_KEY]: next });
        return next;
    }

    /**
     * Build a full-system config bundle (everything we know about FAFO options + tags + colors).
     */
    async function buildFullSystemConfig(name) {
        let live = await readLive();
        live = await enrichLiveFromIdb(live);
        const stamp = Date.now();
        return {
            kind: FULL_CONFIG_KIND,
            version: VERSION,
            name: String(name || 'FAFO config').trim() || 'FAFO config',
            savedAt: stamp,
            savedAtIso: new Date(stamp).toISOString(),
            source: 'options-save-as',
            defaultPathHint: await getConfigsFolderPath(),
            data: live,
        };
    }

    /**
     * Save As full system config JSON.
     * Always prompts for a filename (Save As). Prefers File System Access API so
     * the user can pick the repo configs folder (or any folder) and we remember the path hint.
     *
     * @param {string} name  Human label for this config
     * @param {object} [opts]
     * @param {string} [opts.suggestedPath]  Path hint shown / stored (not auto-written without picker)
     * @returns {Promise<{ ok:boolean, filename:string, pathHint:string, entry:object, method:string }>}
     */
    async function saveFullConfigAs(name, opts = {}) {
        const label = String(name || '').trim();
        if (!label) throw new Error('Config name is required (Save As)');
        const pathHint = (opts.suggestedPath || (await getConfigsFolderPath())).trim() || DEFAULT_CONFIGS_PATH;
        await setConfigsFolderPath(pathHint);

        const bundle = await buildFullSystemConfig(label);
        const filename = safeConfigFileName(label);
        const json = JSON.stringify(bundle, null, 2);
        let method = 'download';
        let savedPath = pathHint + '\\' + filename;

        // Prefer Save As picker (user can navigate to repo configs folder)
        if (typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function') {
            try {
                const handle = await window.showSaveFilePicker({
                    suggestedName: filename,
                    types: [{
                        description: 'FAFO full system config',
                        accept: { 'application/json': ['.json'] },
                    }],
                });
                const writable = await handle.createWritable();
                await writable.write(json);
                await writable.close();
                method = 'file-picker';
                savedPath = pathHint + '\\' + (handle.name || filename);
            } catch (e) {
                if (e && (e.name === 'AbortError' || e.name === 'NotAllowedError')) {
                    throw new Error('Save cancelled');
                }
                // fall through to download
                method = 'download-fallback';
            }
        }

        if (method !== 'file-picker') {
            const blob = new Blob([json], { type: 'application/json' });
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = filename;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 2500);
            method = method === 'download-fallback' ? 'download-fallback' : 'download';
            savedPath = '(browser Downloads)/' + filename + ' — copy into: ' + pathHint;
        }

        const entry = {
            id: 'cfg_' + Date.now().toString(36),
            name: label,
            filename,
            pathHint,
            savedPath,
            method,
            savedAt: bundle.savedAt,
            savedAtIso: bundle.savedAtIso,
            stats: {
                mediaEntries: metaEntryCount(bundle.data?.fafoMediaMeta),
                tags: (bundle.data?.fafoTagLibrary || []).length,
                hasColors: !!(bundle.data?.fafoTagColors || bundle.data?.fafoTagColorSlots),
                hasMediaConfig: !!bundle.data?.mediaConfig,
            },
        };
        await rememberNamedConfig(entry);
        return { ok: true, filename, pathHint, entry, method, bundle };
    }

    async function importFullConfigFromFile(file) {
        const text = await file.text();
        const obj = JSON.parse(text);
        if (obj?.kind === FULL_CONFIG_KIND || obj?.kind === KIND || obj?.data) {
            return restoreBundle(obj, { fullSystem: obj?.kind === FULL_CONFIG_KIND });
        }
        return importFromObject(obj, { fullSystem: true });
    }

    async function restoreBundle(bundle, opts = {}) {
        const payload = applyBundleToStoragePayload(bundle, opts);
        if (!Object.keys(payload).length) throw new Error('Backup has no tag data');
        // Safety snapshot of current state first
        await afterLiveSave(null, 'pre-restore');
        await chrome.storage.local.set(payload);
        // Restore playlists into IDB when present
        try {
            const lists = payload.fafoPlaylistsBackup || bundle?.data?.playlists;
            if (Array.isArray(lists) && lists.length && global.FAFOLibrary?.importPlaylistsFromBackup) {
                const db = await FAFOLibrary.openDB();
                await FAFOLibrary.importPlaylistsFromBackup(db, lists, { merge: opts.mergePlaylists !== false });
            }
        } catch (e) {
            console.warn('FAFO playlist restore from backup', e);
        }
        await afterLiveSave(payload, 'post-restore');
        return {
            mediaEntries: metaEntryCount(payload.fafoMediaMeta),
            tags: (payload.fafoTagLibrary || []).length,
            pairs: (payload.fafoPairs || []).length,
            playlists: (payload.fafoPlaylistsBackup || []).length,
        };
    }

    async function restoreLatestSnapshot() {
        const snap = await getSnapshot();
        if (!snap?.data) throw new Error('No snapshot available yet — tag something first');
        return restoreBundle(snap);
    }

    async function restoreHistoryId(id) {
        const history = await listHistory();
        const hit = history.find((h) => h.id === id);
        if (!hit) throw new Error('Backup not found');
        return restoreBundle(hit);
    }

    /**
     * If live media meta is empty but a snapshot has data, recover automatically.
     * Returns recovered bundle data or null.
     */
    async function tryRecoverEmptyLive() {
        try {
            const live = await readLive();
            if (metaEntryCount(live.fafoMediaMeta) > 0) return null;
            const snap = await getSnapshot();
            if (!snap?.data || metaEntryCount(snap.data.fafoMediaMeta) === 0) {
                // try history
                const history = await listHistory();
                const hit = history.find((h) => metaEntryCount(h?.data?.fafoMediaMeta) > 0);
                if (!hit) return null;
                await chrome.storage.local.set(applyBundleToStoragePayload(hit));
                console.info('FAFO recovered tags from backup history', hit.id);
                return hit;
            }
            await chrome.storage.local.set(applyBundleToStoragePayload(snap));
            console.info('FAFO recovered tags from latest snapshot');
            return snap;
        } catch (e) {
            console.warn('FAFO tryRecoverEmptyLive', e);
            return null;
        }
    }

    async function exportToDownload(opts = {}) {
        // Public export only — secret-mode libraries are never written to Downloads
        let live = await readLive();
        live = await enrichLiveFromIdb(live);
        live = stripPrivateKeys(live);
        const bundle = buildBundle(live, opts.reason || 'export');
        if (bundle?.data) bundle.data = stripPrivateKeys(bundle.data);
        // Default: full backup (options + playlists + file catalog). Opt-out with includeConfig:false
        if (opts.includeConfig === false) {
            delete bundle.data.mediaConfig;
        }
        if (opts.includeCatalog === false) {
            delete bundle.data.libraryCatalog;
        }
        // Prefer structured vault (user folder and/or companion) — then optional browser download
        await writeDiskBackup(bundle, true);
        tryWriteUserBackupFolder(bundle, 'export').catch(() => {});

        if (opts.download !== false) {
            // Download into Downloads as FAFO-Backups_export_<stamp>.json
            // (browser cannot create folders without a linked vault; vault is preferred)
            const blob = new Blob([JSON.stringify(bundle, null, 2)], { type: 'application/json' });
            const a = document.createElement('a');
            const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
            a.href = URL.createObjectURL(blob);
            a.download = opts.filename || `FAFO-Backups_export_${stamp}.json`;
            a.click();
            setTimeout(() => URL.revokeObjectURL(a.href), 2000);
        }
        await afterLiveSave(live, 'export');
        return bundle;
    }

    async function importFromObject(obj, opts = {}) {
        // Accept full bundle or raw { fafoMediaMeta, ... } or legacy mediaConfig-only
        if (!obj || typeof obj !== 'object') throw new Error('Invalid JSON');

        if (obj.kind === KIND || obj.data?.fafoMediaMeta || obj.fafoMediaMeta) {
            const bundle = obj.data ? obj : { data: obj, kind: KIND, version: VERSION, savedAt: Date.now() };
            return restoreBundle(bundle, opts);
        }

        // Legacy: pure mediaConfig export
        if (obj.layout || obj.useLocal != null || obj.fxSnow != null) {
            await chrome.storage.local.set({ mediaConfig: obj });
            return { mediaEntries: 0, tags: 0, pairs: 0, configOnly: true };
        }

        throw new Error('Unrecognized backup format');
    }

    async function importFromFile(file, opts = {}) {
        const text = await file.text();
        const obj = JSON.parse(text);
        return importFromObject(obj, opts);
    }

    /** Strip pair/role system tags the same way the Tags UI does. */
    function userTagsOnly(tags) {
        if (global.FAFOId?.userTagsOnly) return FAFOId.userTagsOnly(tags);
        if (!Array.isArray(tags)) return [];
        return tags
            .map((t) => String(t || '').trim())
            .filter((t) => {
                if (!t) return false;
                if (/^pair_ID_\d{1,6}$/i.test(t) || /^UP-\d{1,6}$/i.test(t)) return false;
                const low = t.toLowerCase();
                return !['source', 'before', 'after', 'pair', 'vsr', 'upscaled', 'image', 'original'].includes(low);
            });
    }

    /**
     * Coverage stats for fafoMediaMeta + tag vocabulary.
     * @param {object} meta
     * @param {string[]} tagLib
     * @param {object} [opts]
     * @param {number} [opts.libraryTotal]  Visual library item count (when known)
     * @param {string[]} [opts.libraryKeys] Meta keys for each library item (accurate tagged/untagged)
     * @param {string[]} [opts.libraryNames] File names in the visual library (fast name match)
     */
    function analyzeTagCoverage(meta, tagLib, opts = {}) {
        const entries = Object.entries(meta && typeof meta === 'object' ? meta : {});
        let filesWithTags = 0;
        let filesWithoutTags = 0;
        let filesWithRating = 0;
        let filesRatingOnly = 0;
        let totalTagApplications = 0;
        const uniqueOnFiles = new Set();
        /** lower(name) -> true if any meta entry with that name has tags */
        const taggedNames = new Set();
        const allMetaNames = new Set();

        entries.forEach(([, m]) => {
            const tags = userTagsOnly(m?.tags);
            tags.forEach((t) => uniqueOnFiles.add(String(t).toLowerCase()));
            totalTagApplications += tags.length;
            if (tags.length > 0) filesWithTags++;
            else filesWithoutTags++;
            const rating = Number(m?.rating) || 0;
            if (rating > 0) {
                filesWithRating++;
                if (tags.length === 0) filesRatingOnly++;
            }
            if (m?.name) {
                const low = String(m.name).toLowerCase();
                allMetaNames.add(low);
                if (tags.length > 0) taggedNames.add(low);
            }
        });

        const vocab = Array.isArray(tagLib) ? tagLib : [];
        const uniqueTagsRecorded = vocab.length || uniqueOnFiles.size;

        // Library-level coverage (visual library may be larger than meta)
        let libraryTotal = null;
        let libraryTagged = null;
        let libraryUntagged = null;
        if (typeof opts.libraryTotal === 'number' && opts.libraryTotal >= 0) {
            libraryTotal = opts.libraryTotal | 0;
            if (Array.isArray(opts.libraryNames) && opts.libraryNames.length) {
                libraryTagged = 0;
                opts.libraryNames.forEach((name) => {
                    const low = String(name || '').toLowerCase();
                    if (low && taggedNames.has(low)) libraryTagged++;
                });
                // Names shorter than total → rest untagged
                const named = opts.libraryNames.filter(Boolean).length;
                if (named < libraryTotal) {
                    libraryUntagged = (libraryTotal - named) + (named - libraryTagged);
                } else {
                    libraryUntagged = Math.max(0, libraryTotal - libraryTagged);
                }
            } else if (Array.isArray(opts.libraryKeys) && opts.libraryKeys.length) {
                libraryTagged = 0;
                const byName = new Map();
                Object.values(meta || {}).forEach((m) => {
                    if (!m?.name) return;
                    const low = String(m.name).toLowerCase();
                    if (!byName.has(low)) byName.set(low, []);
                    byName.get(low).push(m);
                });
                opts.libraryKeys.forEach((key) => {
                    if (!key) return;
                    let m = meta?.[key];
                    if (!m && String(key).startsWith('name:')) {
                        const hits = byName.get(String(key).slice(5)) || [];
                        m = hits.length === 1 ? hits[0] : null;
                    }
                    if (!m && global.FAFOId?.findStoredMeta) {
                        const parts = String(key).split('|');
                        const namePart = parts[0]?.replace(/^file:/, '') || '';
                        const sizePart = parts[1] != null ? Number(parts[1]) : null;
                        m = FAFOId.findStoredMeta(meta, {
                            key,
                            name: namePart,
                            size: Number.isFinite(sizePart) ? sizePart : undefined,
                        })?.meta || null;
                    }
                    if (userTagsOnly(m?.tags).length > 0) libraryTagged++;
                });
                const keyed = opts.libraryKeys.filter(Boolean).length;
                if (keyed < libraryTotal) {
                    libraryUntagged = (libraryTotal - keyed) + (keyed - libraryTagged);
                } else {
                    libraryUntagged = Math.max(0, libraryTotal - libraryTagged);
                }
            } else {
                // Approximate: meta files-with-tags vs full library size
                libraryTagged = filesWithTags;
                libraryUntagged = Math.max(0, libraryTotal - libraryTagged);
            }
        }

        const pct = (n, d) => (d > 0 ? Math.round((n / d) * 1000) / 10 : 0);

        return {
            /** Unique tag names in vocabulary (fafoTagLibrary) */
            totalTagsRecorded: uniqueTagsRecorded,
            /** Distinct user tags found on at least one file */
            uniqueTagsOnFiles: uniqueOnFiles.size,
            /** Sum of tag chips across all media (one file with 3 tags → +3) */
            totalTagApplications,
            /** Meta rows that exist (ever tagged/rated/touched) */
            mediaMetaEntries: entries.length,
            /** Meta rows with ≥1 user tag */
            filesWithTags,
            /** Meta rows with 0 user tags (may still have rating/pair) */
            filesWithoutTagsInMeta: filesWithoutTags,
            filesWithRating,
            filesRatingOnly,
            /** Visual library size when provided */
            libraryTotal,
            libraryTagged,
            libraryUntagged,
            /** Percentages (null when no denominator) */
            pctTaggedInMeta: pct(filesWithTags, entries.length),
            pctTaggedInLibrary: libraryTotal != null ? pct(libraryTagged, libraryTotal) : null,
            pctUntaggedInLibrary: libraryTotal != null ? pct(libraryUntagged, libraryTotal) : null,
        };
    }

    /**
     * @param {object} [opts]
     * @param {number} [opts.libraryTotal]
     * @param {string[]} [opts.libraryKeys]
     */
    async function statusSummary(opts = {}) {
        const live = await readLive();
        const snap = await getSnapshot();
        const history = await listHistory();
        const coverage = analyzeTagCoverage(live.fafoMediaMeta, live.fafoTagLibrary, {
            libraryTotal: opts.libraryTotal,
            libraryKeys: opts.libraryKeys,
            libraryNames: opts.libraryNames,
        });
        const snapCoverage = snap?.data
            ? analyzeTagCoverage(snap.data.fafoMediaMeta, snap.data.fafoTagLibrary)
            : null;

        return {
            // Back-compat fields
            liveMedia: coverage.mediaMetaEntries,
            liveTags: coverage.totalTagsRecorded,
            livePairs: (live.fafoPairs || []).length,
            snapshotAt: snap?.savedAt || null,
            snapshotMedia: metaEntryCount(snap?.data?.fafoMediaMeta),
            historyCount: history.length,
            history: history.map((h) => {
                const c = h.data
                    ? analyzeTagCoverage(h.data.fafoMediaMeta, h.data.fafoTagLibrary)
                    : null;
                return {
                    id: h.id,
                    savedAt: h.savedAt,
                    reason: h.reason,
                    mediaEntries: h.stats?.mediaEntries ?? c?.mediaMetaEntries ?? metaEntryCount(h.data?.fafoMediaMeta),
                    tagCount: h.stats?.tagCount ?? c?.totalTagsRecorded ?? (h.data?.fafoTagLibrary || []).length,
                    pairCount: h.stats?.pairCount ?? (h.data?.fafoPairs || []).length,
                    filesWithTags: c?.filesWithTags ?? null,
                    filesWithoutTags: c?.filesWithoutTagsInMeta ?? null,
                    uniqueTagsOnFiles: c?.uniqueTagsOnFiles ?? null,
                };
            }),
            // Detailed coverage
            coverage,
            snapshotCoverage: snapCoverage,
        };
    }

    /** One-line / multi-line text for compact UIs. */
    function formatCoverageLines(s) {
        const c = s?.coverage || s;
        if (!c) return ['No tag data yet'];
        const lines = [];
        lines.push(
            `Tags recorded: ${c.totalTagsRecorded} vocabulary · ${c.uniqueTagsOnFiles} used on files · ${c.totalTagApplications} total applies`
        );
        lines.push(
            `Meta records: ${c.mediaMetaEntries} · ${c.filesWithTags} tagged · ${c.filesWithoutTagsInMeta} untagged in meta` +
            (c.filesWithRating ? ` · ${c.filesWithRating} rated` : '')
        );
        if (c.libraryTotal != null) {
            lines.push(
                `Library: ${c.libraryTotal} total · ${c.libraryTagged} tagged · ${c.libraryUntagged} untagged` +
                (c.pctTaggedInLibrary != null ? ` (${c.pctTaggedInLibrary}% tagged)` : '')
            );
        }
        return lines;
    }

    global.FAFOBackup = {
        KIND,
        VERSION,
        FULL_CONFIG_KIND,
        DEFAULT_CONFIGS_PATH,
        LIVE_KEYS,
        PRIVATE_LIVE_KEYS,
        readLive,
        enrichLiveFromIdb,
        afterLiveSave,
        afterPrivateLiveSave,
        stripPrivateKeys,
        writeDiskBackup,
        linkUserBackupFolder,
        getUserBackupFolderInfo,
        vaultStatusFromServer,
        saveThemeToDisk,
        bucketForReason,
        KEEP_BY_BUCKET,
        getSnapshot,
        listHistory,
        restoreBundle,
        restoreLatestSnapshot,
        restoreHistoryId,
        tryRecoverEmptyLive,
        exportToDownload,
        importFromObject,
        importFromFile,
        importFullConfigFromFile,
        buildFullSystemConfig,
        saveFullConfigAs,
        getConfigsFolderPath,
        setConfigsFolderPath,
        listNamedConfigs,
        rememberNamedConfig,
        statusSummary,
        analyzeTagCoverage,
        formatCoverageLines,
        buildBundle,
    };
})(typeof window !== 'undefined' ? window : globalThis);
