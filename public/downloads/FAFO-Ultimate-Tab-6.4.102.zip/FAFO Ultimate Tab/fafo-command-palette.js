/**
 * FAFO Command Palette — Ctrl+K or / (when not typing in inputs).
 */
(function (global) {
  'use strict';

  let root = null;
  let input = null;
  let list = null;
  let open = false;
  let filter = '';
  let selected = 0;
  /** @type {{ id:string, title:string, hint?:string, keywords?:string, run:()=>void|Promise<void>, group?:string }[]} */
  let commands = [];

  function isTypingTarget(el) {
    if (!el) return false;
    const t = el.tagName;
    if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return true;
    if (el.isContentEditable) return true;
    return !!el.closest?.('input, textarea, select, [contenteditable="true"]');
  }

  function ensureDom() {
    if (root && document.contains(root)) return root;
    root = document.createElement('div');
    root.id = 'fafo-cmd-palette';
    root.className = 'fafo-cmd-palette hidden';
    root.innerHTML = `
      <div class="fafo-cmd-backdrop" data-close="1"></div>
      <div class="fafo-cmd-panel" role="dialog" aria-label="Command palette">
        <div class="fafo-cmd-head">
          <input type="search" class="fafo-cmd-input" placeholder="Search commands, tags, clips…" autocomplete="off" spellcheck="false" />
          <kbd class="fafo-cmd-kbd">Esc</kbd>
        </div>
        <div class="fafo-cmd-list" role="listbox"></div>
        <div class="fafo-cmd-foot">
          <span>↑↓ navigate · Enter run · Ctrl+K toggle</span>
          <span class="fafo-cmd-count"></span>
        </div>
      </div>`;
    document.body.appendChild(root);
    input = root.querySelector('.fafo-cmd-input');
    list = root.querySelector('.fafo-cmd-list');
    root.querySelector('.fafo-cmd-backdrop')?.addEventListener('click', () => close());
    input?.addEventListener('input', () => {
      filter = input.value || '';
      selected = 0;
      render();
    });
    input?.addEventListener('keydown', (e) => {
      const items = filtered();
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        selected = Math.min(items.length - 1, selected + 1);
        render();
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        selected = Math.max(0, selected - 1);
        render();
      } else if (e.key === 'Enter') {
        e.preventDefault();
        runSelected();
      } else if (e.key === 'Escape') {
        e.preventDefault();
        close();
      }
    });
    return root;
  }

  function buildCommands() {
    const cmds = [];
    const add = (c) => cmds.push(c);

    add({
      id: 'play-pause',
      group: 'Player',
      title: 'Play / Pause',
      keywords: 'space toggle',
      run: () => global.FAFOPlayer?.togglePause?.(),
    });
    add({
      id: 'next',
      group: 'Player',
      title: 'Next clip',
      keywords: 'skip forward d',
      run: () => global.FAFOPlayer?.skipTrack?.(1),
    });
    add({
      id: 'prev',
      group: 'Player',
      title: 'Previous clip',
      keywords: 'back a',
      run: () => global.FAFOPlayer?.skipTrack?.(-1),
    });
    add({
      id: 'fullscreen',
      group: 'Player',
      title: 'Toggle fullscreen',
      keywords: 'f screen',
      run: () => {
        if (document.fullscreenElement) document.exitFullscreen?.();
        else document.documentElement.requestFullscreen?.();
      },
    });
    add({
      id: 'tags-toggle',
      group: 'Tags',
      title: 'Toggle tags panel',
      keywords: 't meta rate',
      run: () => {
        const btn = document.getElementById('meta-toggle');
        btn?.click();
      },
    });
    add({
      id: 'undo',
      group: 'Tags',
      title: global.FAFOUndo?.canUndo?.()
        ? `Undo: ${global.FAFOUndo.peek()?.label || 'last edit'}`
        : 'Undo (nothing yet)',
      keywords: 'ctrl z reverse',
      run: () => global.FAFOUndo?.undo?.(),
    });
    add({
      id: 'sprint',
      group: 'Tags',
      title: 'Toggle Sprint Tag',
      keywords: 'rapid bulk',
      run: () => document.getElementById('meta-sprint-toggle')?.click(),
    });
    add({
      id: 'fast-tag',
      group: 'Tags',
      title: 'Open Graffiti Speed Tagging',
      keywords: 'fast tag graffiti thumbnail bulk click apply library hover',
      run: () => { window.location.href = 'fast-tag.html'; },
    });
    add({
      id: 'skip-tagged',
      group: 'Tags',
      title: 'Toggle Skip tagged',
      run: () => document.getElementById('meta-skip-tagged')?.click(),
    });
    add({
      id: 'apply-next',
      group: 'Tags',
      title: 'Toggle Apply+Next',
      run: () => document.getElementById('meta-apply-next')?.click(),
    });
    add({
      id: 'export-backup',
      group: 'Tags',
      title: 'Export tags backup',
      run: () => document.getElementById('meta-export-backup')?.click(),
    });
    add({
      id: 'layout-reset',
      group: 'Layout',
      title: 'Reset panel layout',
      run: () => document.getElementById('meta-layout-reset')?.click(),
    });
    add({
      id: 'undock',
      group: 'Layout',
      title: 'Undock panels for move',
      run: () => document.getElementById('meta-undock-move')?.click(),
    });
    add({
      id: 'stick',
      group: 'Layout',
      title: 'Toggle Stick layout',
      run: () => document.getElementById('meta-stick-layout')?.click(),
    });
    add({
      id: 'ui-scale-100',
      group: 'Scale',
      title: 'UI / tags scale → 100%',
      run: () => global.FAFOMeta?.setUiScale?.(1, { toast: true }),
    });
    add({
      id: 'video-100',
      group: 'Scale',
      title: 'Video zoom → 100%',
      run: () => global.FAFOPlayer?.setVideoZoom?.(1, { toast: true }),
    });
    add({
      id: 'options',
      group: 'App',
      title: 'Open Options',
      keywords: 'settings preferences',
      run: () => {
        const a = document.getElementById('options-link');
        if (a?.href) window.location.href = a.href;
      },
    });
    add({
      id: 'help',
      group: 'App',
      title: 'Keyboard shortcuts help',
      keywords: '? help',
      run: () => document.getElementById('shortcut-help')?.classList.toggle('hidden'),
    });
    add({
      id: 'guide',
      group: 'App',
      title: 'Help for this screen (F1)',
      keywords: 'docs tips tooltips help manual context f1',
      run: () => global.FAFOHelp?.summon?.() || global.FAFOKnowledge?.openGuide?.(),
    });
    add({
      id: 'guide-all',
      group: 'App',
      title: 'Full knowledge guide (all topics)',
      keywords: 'docs archive manual',
      run: () => global.FAFOHelp?.summon?.({ all: true }) || global.FAFOKnowledge?.openGuide?.(),
    });
    add({
      id: 'resume',
      group: 'Session',
      title: 'Resume last session clip',
      keywords: 'restore continue',
      run: () => global.FAFOSession?.resumeNow?.(),
    });
    add({
      id: 'doctor',
      group: 'Library',
      title: 'Library doctor (fix broken folders)',
      keywords: 'repair restore access permission',
      run: () => global.FAFOLibraryDoctor?.open?.(),
    });
    add({
      id: 'next-up-show',
      group: 'Layout',
      title: 'Show Up next strip',
      keywords: 'upcoming previews queue restore unhide next strip',
      run: () => {
        global.FAFOLibraryDoctor?.showNextUp?.();
        global.FAFOUndo?.showToast?.('Up next strip shown');
      },
    });
    add({
      id: 'next-up-hide',
      group: 'Layout',
      title: 'Hide Up next strip',
      keywords: 'upcoming previews hide strip',
      run: () => {
        global.FAFOLibraryDoctor?.hideNextUp?.();
        global.FAFOUndo?.showToast?.('Up next hidden · Ctrl+K → Show Up next');
      },
    });
    add({
      id: 'next-up-pos',
      group: 'Layout',
      title: 'Cycle Up next position',
      keywords: 'dock bottom top left right free strip',
      run: () => {
        global.FAFOLibraryDoctor?.cycleNextUpPos?.();
        const p = global.FAFOLibraryDoctor?.getNextUpLayout?.()?.pos || '';
        global.FAFOUndo?.showToast?.(`Up next · ${p}`);
      },
    });
    add({
      id: 'next-up-count-8',
      group: 'Layout',
      title: 'Up next · 8 cards',
      keywords: 'count upcoming',
      run: () => {
        global.FAFOLibraryDoctor?.setNextUpCount?.(8);
        global.FAFOUndo?.showToast?.('Up next · 8 cards');
      },
    });
    add({
      id: 'next-up-count-12',
      group: 'Layout',
      title: 'Up next · 12 cards',
      keywords: 'count upcoming more',
      run: () => {
        global.FAFOLibraryDoctor?.setNextUpCount?.(12);
        global.FAFOUndo?.showToast?.('Up next · 12 cards');
      },
    });
    add({
      id: 'tag-theme',
      group: 'Look',
      title: 'Cycle tag theme pack',
      run: () => global.FAFOTagThemes?.cycle?.(),
    });

    // Recent / library tags as quick apply / edit
    try {
      const recent = global.FAFOMeta?.getRecentTags?.() || [];
      recent.slice(0, 12).forEach((t) => {
        add({
          id: 'tag-recent-' + t,
          group: 'Apply tag',
          title: `Apply tag: ${t}`,
          keywords: 'tag ' + t,
          run: () => global.FAFOMeta?.toggleLibraryTag?.(t),
        });
        add({
          id: 'tag-edit-' + t,
          group: 'Edit tag',
          title: `Rename: ${t}`,
          keywords: 'edit rename ' + t,
          run: () => global.FAFOMeta?.renameTagEverywhere?.(t),
        });
        add({
          id: 'tag-del-file-' + t,
          group: 'Edit tag',
          title: `Remove from this file: ${t}`,
          keywords: 'delete remove file ' + t,
          run: () => global.FAFOMeta?.removeTagFromCurrentFile?.(t),
        });
        add({
          id: 'tag-purge-' + t,
          group: 'Edit tag',
          title: `Delete everywhere: ${t}`,
          keywords: 'purge wipe ' + t,
          run: () => global.FAFOMeta?.purgeTagEverywhere?.(t),
        });
      });
    } catch (_) {}

    // Playlist jump (sample)
    try {
      const pl = global.FAFOPlayer?.getPlaylist?.() || [];
      const cur = global.FAFOPlayer?.getCurrentIndex?.() ?? 0;
      const slice = pl.slice(Math.max(0, cur - 5), cur + 20);
      slice.forEach((item, i) => {
        const abs = Math.max(0, cur - 5) + i;
        const name = item?.handle?.name || item?.name || item?.url || `Clip ${abs + 1}`;
        add({
          id: 'jump-' + abs,
          group: 'Jump to clip',
          title: name,
          hint: `#${abs + 1}`,
          keywords: 'play open ' + name,
          run: () => global.FAFOPlayer?.playIndex?.(abs),
        });
      });
    } catch (_) {}

    commands = cmds;
    return cmds;
  }

  function filtered() {
    const q = (filter || '').trim().toLowerCase();
    if (!q) return commands;
    return commands.filter((c) => {
      const hay = [c.title, c.hint, c.keywords, c.group].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(q) || q.split(/\s+/).every((p) => hay.includes(p));
    });
  }

  function render() {
    if (!list) return;
    const items = filtered();
    if (selected >= items.length) selected = Math.max(0, items.length - 1);
    const count = root?.querySelector('.fafo-cmd-count');
    if (count) count.textContent = items.length + ' commands';
    if (!items.length) {
      list.innerHTML = '<div class="fafo-cmd-empty">No matches</div>';
      return;
    }
    let lastGroup = '';
    list.innerHTML = items
      .map((c, i) => {
        let g = '';
        if (c.group && c.group !== lastGroup) {
          lastGroup = c.group;
          g = `<div class="fafo-cmd-group">${escapeHtml(c.group)}</div>`;
        }
        return (
          g +
          `<button type="button" class="fafo-cmd-item${i === selected ? ' selected' : ''}" data-i="${i}" role="option" aria-selected="${i === selected}">
            <span class="fafo-cmd-title">${escapeHtml(c.title)}</span>
            ${c.hint ? `<span class="fafo-cmd-hint">${escapeHtml(c.hint)}</span>` : ''}
          </button>`
        );
      })
      .join('');
    list.querySelectorAll('.fafo-cmd-item').forEach((btn) => {
      btn.addEventListener('click', () => {
        selected = parseInt(btn.getAttribute('data-i'), 10) || 0;
        runSelected();
      });
      btn.addEventListener('mouseenter', () => {
        selected = parseInt(btn.getAttribute('data-i'), 10) || 0;
        list.querySelectorAll('.fafo-cmd-item').forEach((b, i) => b.classList.toggle('selected', i === selected));
      });
    });
    list.querySelector('.fafo-cmd-item.selected')?.scrollIntoView({ block: 'nearest' });
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  async function runSelected() {
    const items = filtered();
    const c = items[selected];
    if (!c) return;
    close();
    try {
      await c.run();
    } catch (e) {
      console.warn('command failed', c.id, e);
    }
  }

  function openPalette() {
    ensureDom();
    buildCommands();
    filter = '';
    selected = 0;
    if (input) input.value = '';
    open = true;
    root.classList.remove('hidden');
    document.body.classList.add('fafo-cmd-open');
    render();
    setTimeout(() => input?.focus(), 20);
  }

  function close() {
    open = false;
    root?.classList.add('hidden');
    document.body.classList.remove('fafo-cmd-open');
  }

  function toggle() {
    if (open) close();
    else openPalette();
  }

  function onKey(e) {
    const mod = e.ctrlKey || e.metaKey;
    if (mod && (e.key === 'k' || e.key === 'K')) {
      e.preventDefault();
      toggle();
      return;
    }
    if (mod && (e.key === 'z' || e.key === 'Z') && !e.shiftKey) {
      if (isTypingTarget(e.target)) return;
      e.preventDefault();
      global.FAFOUndo?.undo?.();
      return;
    }
    if (open) return;
    // Slash opens palette when not typing
    if (e.key === '/' && !mod && !e.altKey && !isTypingTarget(e.target)) {
      e.preventDefault();
      openPalette();
    }
  }

  function init() {
    ensureDom();
    document.addEventListener('keydown', onKey, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.FAFOCommandPalette = {
    open: openPalette,
    close,
    toggle,
    rebuild: buildCommands,
  };
})(typeof window !== 'undefined' ? window : globalThis);
