# FAFO Ultimate Tab — Tags, Ratings & Windows Explorer

This package lets you **rate and tag videos while they play**, and write that data into the **real files** so it shows up in:

- Windows File Explorer (**Tags** and **Rating** columns)
- Windows Search (`tag:keyword`, `rating:4 stars`)
- Other apps that read Windows file properties

Without the small companion server below, ratings/tags stay only inside the browser extension.

### Library persistence (v6.2+)

Chrome **revokes folder permission** when the browser restarts — that is normal, not a wipe.

| Action | Where |
|--------|--------|
| **Link Video/Photo Folder** | Options → Visual Library (directory handle is **saved**) |
| **🔓 Restore Access** | Options or red banner on new-tab — one click, **no re-pick** |
| **↻ Resync All** / per-folder Resync | Re-scan saved folders for new/removed files |
| **Smart playlists** | Options → Playlists — filter by ★ rating, tags, untagged |

You should **not** need to delete the library and re-select folders after a restart — Restore Access is enough. Legacy libraries (file handles only) still work; re-link once so folders appear under **Persistent folders**.

### Pairing & Compare (v6.3+)

Full section in **Options → 🔗 Pairing & Compare** (same style as Visual Library):

| Tab | What it does |
|-----|----------------|
| **Pairs** | Pick Before + After from library, create `UP-####` pairs, optional FAFO tags |
| **Compare** | Slider / side-by-side / blend (video + images), play/pause/sync, swap |
| **Duplicates** | Scan library by exact size and/or similar names; set as Before/After or remove from index |
| **Thumbnails** | Set **seconds into the video** for library/pair thumbnails; regenerate pair slot thumbs |

Pairs are stored in Chrome storage (`fafoPairs`). Thumb seek time is `mediaConfig.thumbSeekSec`.

### Tag persistence & restore (v6.3.2+)

| Layer | What |
|-------|------|
| **Live** | `chrome.storage.local` — tags/ratings per file, tag library, hotkeys, pairs (saved on every change) |
| **Latest snapshot** | `fafoTagsSnapshot` — rewritten after each save |
| **History** | Last **12** auto/manual snapshots (`fafoTagsBackupHistory`) |
| **File export** | Options → **Backup / Restore** → **Export tags backup** (JSON you can keep offline) |

**Restore:** Options → Backup → Restore latest snapshot, restore a history row, or **Import tags backup**.  
If live meta is ever empty, FAFO **auto-recovers** from the latest snapshot/history on load.

Also ensure `fafo-backup.js` is loaded on new-tab and options (bundled with the extension).

---

## What’s included

| Path | Purpose |
|------|---------|
| Extension files (`manifest.json`, `newtab.html`, `script.js`, …) | FAFO new-tab video player + on-play ★ Tags UI |
| `Videos\` | Optional bundled library |
| **`explorer-meta\`** | **Required for Explorer sync** — local metadata server |
| `explorer-meta\file_metadata.py` | Writes `System.Keywords` + `System.Rating` (pywin32) |
| `explorer-meta\server.py` | Local API on `http://127.0.0.1:8765` |
| `explorer-meta\requirements.txt` | Python packages (fastapi, uvicorn, **pywin32**, mutagen, …) |
| `explorer-meta\INSTALL_DEPS.bat` | One-click install of those packages |
| `explorer-meta\START_META_SERVER.bat` | Start the metadata server |
| `explorer-meta\ADD_VIDEO_FOLDER.bat` | Register a video folder so files can be found by name/size |

---

## Requirements (for people you distribute this to)

1. **Windows 10 or 11**
2. **Google Chrome or Microsoft Edge**
3. **Python 3.10+** (3.11–3.14 fine)  
   - Download: https://www.python.org/downloads/  
   - During setup, enable **“Add python.exe to PATH”**
4. Internet once (to `pip install` packages)

No need for the full AI HTML TOOLBOX app. The `explorer-meta` folder is a **standalone** companion.

---

## Setup (recipients)

### 1. Install the browser extension

1. Open `chrome://extensions` (or `edge://extensions`)
2. Turn **Developer mode** ON
3. Click **Load unpacked**
4. Select **this** FAFO folder (the one that contains `manifest.json`)

### 2. Install metadata dependencies (once)

1. Open the `explorer-meta` folder
2. Double-click **`INSTALL_DEPS.bat`**
3. Wait until you see `pywin32 OK` and `file_metadata OK`

This installs:

- `fastapi` + `uvicorn` — local server  
- **`pywin32`** — writes Windows Explorer Tags / Rating  
- `mutagen` — extra MP4 embedded tags for other players  

### 3. Start the metadata server (every session you want Explorer sync)

1. Double-click **`START_META_SERVER.bat`**
2. Leave that window open  
3. You should see: `http://127.0.0.1:8765`

> Only one app should use port **8765**. If you already run **AI HTML TOOLBOX** server, you do **not** need this companion (toolbox already provides the same API). In the toolbox, start it with **▶ Start Server** inside Media Library / Launcher / VSR / File Organizer (or `START SERVER.bat`).

### 4. Register video folders (important)

The browser cannot hand the server a full disk path for privacy reasons. The server must **index** folders so it can match a playing video by **filename + size**.

**Bundled `Videos\` folder** is indexed automatically when the server starts.

For **your own** libraries:

1. Keep the metadata server running  
2. Run **`ADD_VIDEO_FOLDER.bat`** and paste the full path, e.g.  
   `D:\MyClips`  
   **or** edit `explorer-meta\config.json`:

```json
{
  "version": 1,
  "watched_dirs": [
    "D:\\MyClips",
    "C:\\Users\\You\\Videos"
  ]
}
```

3. Then either restart the server or open a browser to rescan:  
   `http://127.0.0.1:8765/api/library/rescan` (POST via the bat is easier)

### 5. Use tags & ratings in FAFO

1. Open a **new tab** (FAFO player)
2. Click **★ Tags** (bottom-right) or press **`T`**
3. Click stars (1–5) or type/click tags  
4. Status line should say something like **Saved to file (Explorer)**

### 6. Confirm in File Explorer

1. Open the video’s folder in Explorer  
2. Details view → right-click column headers → enable **Tags** and **Rating**  
3. Search box examples:

```text
tag:vacation
rating:5 stars
rating:>=3 stars
```

---

## Keyboard shortcuts (player)

| Key | Action |
|-----|--------|
| `T` | Open / close tags panel |
| `1`–`5` | Set rating (panel open) |
| `0` | Clear rating |

---

## Format support (honest)

| Format | Explorer Tags / Rating |
|--------|-------------------------|
| **MP4 / M4V / MOV** | Usually excellent |
| **JPEG / many photos** | Excellent (if you use the same tools on images) |
| **MKV / WebM / AVI** | Often limited in Explorer; we still write what Windows allows |

---

## Troubleshooting

| Symptom | Fix |
|---------|-----|
| Status: *start AI HTML TOOLBOX server…* / can’t reach server | Run **`START_META_SERVER.bat`** and leave it open |
| *File not in library* / not found | Run **`ADD_VIDEO_FOLDER.bat`** on the folder that contains those videos |
| `pywin32` import error | Re-run **`INSTALL_DEPS.bat`**, or: `python -m pip install --force-reinstall pywin32` |
| Port already in use | Another server (e.g. AI Toolbox) is on 8765 — that’s fine, use that one instead |
| Tags only in FAFO, not Explorer | Server wasn’t running when you tagged, or folder wasn’t registered |
| Python not found | Install Python with **Add to PATH**, open a **new** Command Prompt |

Health check in a browser:

```text
http://127.0.0.1:8765/api/health
```

---

## For distributors (you)

When you zip / ship FAFO to others, include the **entire** folder structure, especially:

```text
FAFO_Ultimate_Tab/   (or your release name)
  manifest.json
  newtab.html
  script.js
  styles.css
  options.html
  options.js
  library.json
  readme.txt
  TAGS_AND_RATINGS.md      ← this guide
  explorer-meta/
    server.py
    file_metadata.py
    requirements.txt
    INSTALL_DEPS.bat
    START_META_SERVER.bat
    ADD_VIDEO_FOLDER.bat
    config.json
    README.md
  Videos/                  ← optional bundled clips
```

You do **not** need to pre-install pywin32 on their PCs; **`INSTALL_DEPS.bat`** does that.

Optional: mention in your product notes:

> For Windows Explorer tags & star ratings, run `explorer-meta\INSTALL_DEPS.bat` once, then `START_META_SERVER.bat` whenever you use FAFO.

---

## Privacy / network

- Server binds to **127.0.0.1 only** (this PC, not the internet)
- No cloud upload
- Metadata is written into the files you rate/tag

---

## Related: full AI HTML TOOLBOX

If someone also uses **AI HTML TOOLBOX** (Media Library / File Organizer), that app’s server on the same port already writes Explorer metadata. They should run **either** the toolbox server **or** this FAFO companion, not two copies fighting for port 8765.

For **before/after pairs**, moving files between folders, dual-tagging partners, and long-term storage (ZIP vs re-encode vs USB), see the toolbox doc:

`AI HTML TOOLBOX\MEDIA_LIBRARY_AND_PAIRS.md`

### Can I ZIP videos to save space and still play them in FAFO?

**Not practically.** Zip archives are not playable video streams. Better options:

1. Re-encode to a smaller **MP4** (e.g. HEVC/AV1) and keep playing normally  
2. Keep cold projects on a **USB drive** and point FAFO / the toolbox at that folder when plugged in  
3. Leave “hot” clips on the internal disk uncompressed-as-video (already codec-compressed)

See the toolbox Q&A for the full table.
