FAFO ULTIMATE TAB v6.4.0 - INSTALLATION & USER GUIDE
====================================================

Extension version: **6.4.0** (manifest).
Last public store build many users saw: **2.9**. This jumps straight to 6.4.0 on purpose —
intermediate numbers were never all public store releases. Dirty versioning; full feature catch-up.

Full FAFO new-tab media center:
cinema / grid / carousel, visual library in Options, smart playlists, pairing,
particle FX, audio-reactive neon border, player HUD, on-play ★ Tags (T),
Skip tagged / Apply+Next bulk tagging, hotkey banks, backups.

Also see:
  TAGS_AND_RATINGS.md
  explorer-meta\README.md
  STORE_LISTING.md          ← Chrome Web Store copy + feature inventory
  DISTRIBUTOR_STORE_AND_WEBSITE_GUIDE.md

[ IMPORTANT LINKS ]
-------------------------------------------------
• Chrome Web Store Version (Official):
  https://chromewebstore.google.com/search/FAFO%20Local%20Media

• Sample Video Library (Download to test):
  https://drive.google.com/open?id=1_srvtfS2_7cwmIn3jXdRIDOLOgB43B-c&usp=drive_fs


[ PART 1: INSTALLATION ]
-------------------------------------------------
Since this is the "Unpacked" developer version, please follow these steps:

OPTION A — LOAD FROM THIS FOLDER (RECOMMENDED FOR DEVELOPMENT)
1. Open Google Chrome.
2. Navigate to: chrome://extensions
3. ENABLE "Developer Mode" (toggle in the top right corner).
4. Click "Load Unpacked" (top left).
5. Select this folder: FAFO Local Media
6. Open a New Tab to see the player.

OPTION B — INSTALLER BUILD
1. Run "FAFO_Local_Media_Installer_v3.0.exe" (when available).
2. By default, files extract to: Documents\FAFO_Local_Media_V3.0
3. Load that folder via chrome://extensions → Load Unpacked.


[ PART 2: LIBRARY SETUP ]
-------------------------------------------------
You must link your media files for them to play.

STEP A: GENERATE BUNDLED LIBRARY (OPTIONAL)
1. Place videos in the extension's Videos\ folder.
2. Double-click generate_library.bat.
   *Scans Videos\ and Photos\ and writes library.json for bundled playback.*

STEP B: LINK YOUR LOCAL FOLDERS
1. Open a New Tab and click the gear icon (⚙️), or go to Options.
2. Visual Library → "+ Link Video Folder" / "+ Link Photo Folder".
3. Select the folders on your computer that contain your media.
4. Click "SAVE SYSTEM" at the bottom of the Options sidebar.

Settings apply live on the new tab after Save — no manual refresh needed.


[ PART 3: PLAYER HUD & CONTROLS (v3.1) ]
-------------------------------------------------
A control bar appears at the bottom in Cinema mode. It auto-hides after a few
seconds of idle mouse movement and reappears when you move the mouse or hover
the bar.

ON-SCREEN CONTROLS:
  ⏮  Previous track
  ⏸/▶  Play / Pause
  ⏭  Next track
  🔀  Shuffle on/off
  1×  Playback speed (click to cycle)
  🔇/🔊  Mute / Unmute
  ───  Volume slider
  ⊡  Picture-in-Picture
  ⛶  Fullscreen

The HUD shows the current file name, track position (e.g. 3 / 47), elapsed
and total time, and a seekable progress bar during video playback (click or
drag to jump).

EMPTY LIBRARY:
If no folders, bundled files, or URLs are linked, a prompt appears with a
link to Options. A sample clip may play in the background until you add media.

KEYBOARD SHORTCUTS:
  [SPACEBAR]  Play / Pause
  [←] [→]     Previous / Next track
  [M]         Mute / Unmute
  [S]         Toggle shuffle
  [<] [>]     Slower / faster playback
  [P]         Picture-in-Picture
  [F]         Fullscreen
  [?]         Show / hide shortcut help


[ PART 4: AUDIO-REACTIVE NEON TRIM ]
-------------------------------------------------
Options → Cinema & Ambience → Audio-Reactive Neon Trim

Enable perimeter neon lights that react to playback audio.

SETTINGS:
  • Enable Neon Border       — turn edge lights on/off
  • Sync to Audio (Bass)     — lights respond to low-frequency audio
  • Use Theme Accent Color   — match your theme, or pick a custom color

PATTERNS:
  • Chase        — running light around the frame
  • Dual Chase   — two opposing lights racing around the border
  • Strobe       — beat-detected flash with corner pulse nodes
  • Pulse        — breathe in sync with smoothed audio
  • Wave         — ripple around the border
  • Spectrum     — frequency bands mapped to each segment
  • Segment Stack — sequential fill (activation sequence style)
  • Flicker      — organic spark flicker driven by audio

TIPS:
  • Raise Master Volume in Playback settings for stronger audio reaction.
  • Spectrum and Dual Chase are great for music videos.
  • Click Save — changes apply immediately on the new tab.


[ PART 5: PARTICLE FX (v3.2 OVERHAUL) ]
-------------------------------------------------
Options → Particle FX — enable any combination; settings apply live.

EFFECTS:
  • Heavy Snow    — 3 depth layers, wind gusts, crystalline flakes
  • Digital Rain  — angled streaks, splashes, accent-tinted highlights
  • Rising Embers — heat trails, flickering cores, warm gradients
  • Volumetric Smoke — soft screen-blended plumes with persistence
  • Rising Sparks — gravity arcs with bright trails
  • Neon Pulse    — accent-synced bokeh orbs with pulse rings

When any FX are active, a subtle vignette frames the scene for depth.


[ VERSION v3.2 HIGHLIGHTS ]
-------------------------------------------------
• PARTICLE FX ENGINE v2:
  Dedicated renderer with layered depth, trails, splashes, and live rebuild.

• NEON BORDER v2:
  Beat detection, corner nodes, gradient tubes, Spectrum & Dual Chase patterns.

• KEN BURNS:
  Smoother multi-point pan/zoom for photo slideshows.


[ VERSION v3.1 HIGHLIGHTS ]
-------------------------------------------------
• SEEKABLE PROGRESS BAR:
  Click or drag to jump within the current video.

• VOLUME SLIDER + TIME DISPLAY:
  On-screen volume control with elapsed / total time codes.

• SHUFFLE, SPEED, PiP:
  Toggle shuffle, cycle playback speed, and pop out Picture-in-Picture.

• AUTO-HIDE HUD:
  Cinema mode bar fades away when idle; move the mouse to bring it back.

• EMPTY LIBRARY PROMPT:
  Clear call-to-action when no media is linked yet.

[ VERSION v3.0 HIGHLIGHTS ]
-------------------------------------------------
• LIVE CONFIG SYNC, PLAYER HUD, AUDIO-REACTIVE NEON TRIM, BUG FIXES


[ CARRIED OVER FROM v2.9 ]
-------------------------------------------------
• THEME ENGINE — customize accent color across the UI
• PLAYLIST MANAGER — collections, filtering, pagination
• CINEMA & AMBIENCE PRO — dynamic blur or solid color background
• LAYOUT MODES — Cinema, Grid, Carousel, Collage
• PARTICLE FX — overhauled embers, smoke, snow, rain, sparks, neon bokeh
• PER-FILE OVERRIDES — custom volume and scaling per asset
• BACKUP / RESTORE — export and import settings JSON


[ TROUBLESHOOTING ]
-------------------------------------------------
• "Database Blocked"?
  Close all other New Tab pages and refresh the Options page.

• "Permissions Lost"?
  Click the red warning on the new tab or re-link your media folder
  in Options → Visual Library.

• Videos not showing up?
  Run generate_library.bat after adding files to Videos\, or re-link
  your folder in Options.

• Neon lights not reacting to audio?
  Enable Neon Border + Sync to Audio, raise Master Volume, and use a
  video with audible sound (not muted).

• Settings not applying?
  Click "SAVE SYSTEM" in Options. v3.0 applies changes live — if stuck,
  reload the extension at chrome://extensions.


[ VERSION HISTORY ]
-------------------------------------------------
v3.2  Overhauled particle FX engine, neon border v2, Ken Burns polish
v3.1  Seekable HUD, volume slider, shuffle/speed/PiP, auto-hide, empty state
v3.0  Player HUD, audio-reactive neon trim, live config sync, bug fixes
v2.9  Playlist manager, theme engine, cinema & ambience pro
v2.7  Individual particle FX controls
v2.5  Particle engine expansion
v2.3  Visual library and layout engine
v2.1  Initial cyber-HUD overhaul