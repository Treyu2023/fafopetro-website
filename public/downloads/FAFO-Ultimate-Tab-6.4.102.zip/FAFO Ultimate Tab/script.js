document.addEventListener('DOMContentLoaded', async () => {
    // --- DOM ELEMENTS ---
    const scene = document.getElementById('scene-root');
    const overlay = document.getElementById('overlay');
    const bokehCanvas = document.getElementById('bokeh-canvas');
    const ui = {
        clock: document.getElementById('clock'),
        date: document.getElementById('date'),
        box: document.getElementById('ui-container')
    };
    const hud = {
        box: document.getElementById('player-hud'),
        title: document.getElementById('hud-title'),
        index: document.getElementById('hud-index'),
        play: document.getElementById('hud-play'),
        prev: document.getElementById('hud-prev'),
        next: document.getElementById('hud-next'),
        shuffle: document.getElementById('hud-shuffle'),
        speedDown: document.getElementById('hud-speed-down'),
        speed: document.getElementById('hud-speed'),
        speedUp: document.getElementById('hud-speed-up'),
        mute: document.getElementById('hud-mute'),
        volume: document.getElementById('hud-volume'),
        pip: document.getElementById('hud-pip'),
        fs: document.getElementById('hud-fs'),
        progressWrap: document.getElementById('hud-progress-wrap'),
        progressTrack: document.getElementById('hud-progress-track'),
        progress: document.getElementById('hud-progress'),
        progressThumb: document.getElementById('hud-progress-thumb'),
        timeCurrent: document.getElementById('hud-time-current'),
        timeTotal: document.getElementById('hud-time-total')
    };
    const emptyState = document.getElementById('empty-state');
    const neonFrame = document.getElementById('neon-frame');
    const shortcutHelp = document.getElementById('shortcut-help');

    // --- 1. CONFIGURATION DEFAULTS ---
    let cfg = {
        // Library Settings
        useLocal: true, 
        usePhotos: true, 
        urls: [],
        activePlaylistId: 'all', 
        
        // Layout Settings
        layout: 'cinema', 
        // Fit stage, upscale/downscale as needed (best on-screen quality; decode stays native)
        scaling: 'scale-contain',
        gridCols: 4, 
        gridRows: 1, 
        carouselCount: 8, 
        carouselRadius: 650, 
        carouselTilt: 0,
        carouselSpeed: 40,
        reflectOpacity: 30, 
        reflectOffset: 0,
        
        // Playback Settings
        loops: 1, 
        shuffle: true, 
        volume: 0.7,
        playbackSpeed: 1,
        photoDuration: 3, 
        kenburns: true,
        
        // Visual Settings
        accentColor: '#00e5ff', 
        brightness: 100, 
        contrast: 100, 
        saturate: 100, 
        sepia: 0, 
        grayscale: 0,

        // Dark UI chrome (tags panel / player HUD) — no light themes
        uiThemePreset: 'cyan',
        uiPanelOpacity: 0.92,
        uiHudOpacity: 0.82,
        uiPanelBorderOpacity: 0.14,
        uiRadius: 14,
        uiPanelBorderColor: '', // empty = derive from accent
        
        // Ambilight & Borders (video/media frame)
        borderSize: 0, 
        borderColor: '#44858d', 
        borderGlow: 15,
        // Full-window screen frame — independent of video border / neon
        screenFrameEnabled: false,
        screenFrameSize: 3,
        screenFrameColor: '#00e5ff',
        screenFrameGlow: 12,
        screenFrameOpacity: 0.9,
        screenFrameStyle: 'solid', // solid | double | dashed | glow | corners
        screenFrameRadius: 0,
        ambiScale: 1.0, 
        ambiOpacity: 0.25, 
        ambiBlur: 5,
        ambiMode: 'blur',

        // Audio-reactive neon border
        neonBorder: false,
        neonPattern: 'chase',
        neonSegments: 24,
        neonSpeed: 1,
        neonAudio: true,
        neonStrobe: 0.8,
        neonSensitivity: 1.2,
        neonWidth: 4,
        neonUseAccent: true,
        neonColor: '#00e5ff',
        
        // Detailed Particle Configs (Updated with all controls)
        fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
        fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
        fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
        fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
        fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
        fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,
        
        // UI Settings
        showDate: true, 
        format12h: true, 
        showSeconds: false,
        showClock: true,
        clockColor: '#ffffff',
        clockOpacity: 1,
        hudAlwaysShow: false,
        hudIdleMs: 5000,
        clockSize: 25, 
        font: "'Arial Black', sans-serif", 
        pos: 'pos-bottom-left',
        
        // Per-File Overrides
        overrides: {},

        // Performance
        performanceMode: false,
        // 0 = native/unlimited — best available quality (GPU scales to fit, no artificial 1080p cap)
        maxDisplayHeight: 0,
        disableAmbience: false,
        disableParticles: false,
        disableCssFilters: false,
        disableNeonAudio: false,
    };

    // --- STATE VARIABLES ---
    let playlist = [];
    let currentIdx = 0;
    let loopCount = 0;
    let db = null;
    let mainVideo = null;
    let ambienceVideo = null;
    let photoTimeout = null;
    let collageInterval = null; 
    let isPaused = false;
    let permissionWarned = false;
    let healthCheckInterval = null;
    let consecutiveErrors = 0;
    let currentBlobUrl = null;
    /** Monotonic token so only the latest playNext owns the video element. */
    let playToken = 0;
    let playFailTimer = null;
    let userUnlockedAudio = false;
    /** Player HUD layout: mr (mid-right default) | br | bl | free — always-on-top in this tab. */
    let hudDock = 'mr';
    /**
     * Workspace layout cycled from Layout (not the corner Dock button).
     * dock = floating tags + full video. left/right = tags column. under = player bar under the picture.
     */
    let stageLayoutMode = 'dock';
    /** Video column width used by Left, Right, and Under. */
    let stageVideoWidth = 'wide';
    /** True after a Left/Right/Under frame has been painted, so Dock can restore chrome once. */
    let stageFrameApplied = false;
    let hudPinned = true;
    let hudX = 18;
    let hudY = 18;
    let hudDragging = false;
    /** Layout width/height (px, unscaled). null = CSS default. */
    let hudW = null;
    let hudH = null;
    let hudResizing = false;
    /** Chips before wrap on player Tags row (2–12). */
    let hudTagsPerRow = 5;
    /** Manual repeat (Q) — loop current clip until toggled off or user skips. */
    let manualRepeat = false;
    /** True while loadAndPlayVideo / playNext is swapping sources — ignore pause/ended side-effects. */
    let mediaLoading = false;
    let clockInterval = null;
    let neonEngine = null;
    let particleEngine = null;
    let progressInterval = null;
    let libraryEmpty = false;
    let isSeeking = false;
    let hudIdleTimer = null;
    let playerChromeTimer = null;
    let gridResizeTimer = null;
    let volumeSaveTimer = null;
    /**
     * Wall mode: multi-video grid (2 / 6 / 8) — full frames, no crop, stays on screen.
     * Session toggle from Player HUD; Options layout is restored on exit.
     * Prefs (count, gap, reflow, pin) shared with Options → Layout → The Wall.
     */
    let wallModeActive = false;
    let wallModeRestore = null; // { layout, gridCols, gridRows, scaling }
    /** How many videos in the wall: 2 | 6 | 8 */
    let wallCount = 8;
    const WALL_COUNTS = [2, 6, 8];
    /** Scalability prefs — mirrored from Options / fafoWallPrefs */
    let wallPrefs = {
        count: 8,
        gapScale: 1,
        fullFrame: true,
        liveReflow: true,
        stayOnScreen: true,
        muteHoverScale: true,
    };
    /**
     * Wall audio: tiles start muted (autoplay). After user unmute / volume drag,
     * only the primary tile has sound (avoids 8× cacophony). Click a tile to make it primary.
     */
    let wallAudioMuted = true;
    /** Suppress spurious onended after seek-to-end / scrub. */
    let suppressEndedUntil = 0;
    /** Stack of prior playlist indices so Prev returns to the last played clip. */
    let playHistory = [];
    const PLAY_HISTORY_MAX = 200;
    const HUD_IDLE_MS = 5000;
    const SPEED_STEPS = [0.25, 0.33, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
    /** Keys that require rebuilding the playlist when mediaConfig changes. */
    const PLAYLIST_AFFECTING_KEYS = [
        'activePlaylistId', 'shuffle', 'useLocal', 'usePhotos', 'urls',
    ];
    /** Keys that only need live apply — never rebuild / re-layout. */
    const SOFT_CONFIG_KEYS = [
        'volume', 'playbackSpeed', 'brightness', 'contrast', 'saturate',
        'uiThemePreset', 'uiPanelOpacity', 'uiHudOpacity', 'uiPanelBorderOpacity', 'uiRadius', 'uiPanelBorderColor',
        'sepia', 'grayscale', 'showDate', 'format12h', 'showSeconds',
        'showClock', 'clockColor', 'clockOpacity', 'hudAlwaysShow', 'hudIdleMs',
        'clockSize', 'font', 'pos',
        'scaling', 'maxDisplayHeight',
    ];

    // --- CORE FUNCTIONS (boot sequence runs at bottom so FAFOPlayer exists first) ---

    async function loadConfig() {
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        cfg = {...cfg, ...mediaConfig};
        // Coerce display cap: missing/invalid → native (best quality). 0 is valid.
        const mdh = parseInt(cfg.maxDisplayHeight, 10);
        cfg.maxDisplayHeight = Number.isFinite(mdh) && mdh > 0 ? mdh : 0;
        // Default scaling to fit-screen if unset
        if (!cfg.scaling) cfg.scaling = 'scale-contain';
    }

    function listenForConfigChanges() {
        chrome.storage.onChanged.addListener(async (changes, area) => {
            if (area !== 'local' || !changes.mediaConfig) return;
            const oldVal = changes.mediaConfig.oldValue || {};
            const newVal = changes.mediaConfig.newValue || {};
            if (!newVal || typeof newVal !== 'object') return;

            // Diff only keys that actually changed (volume slider writes many times)
            const changedKeys = Object.keys(newVal).filter((k) => {
                try {
                    return JSON.stringify(oldVal[k]) !== JSON.stringify(newVal[k]);
                } catch {
                    return oldVal[k] !== newVal[k];
                }
            });
            if (!changedKeys.length) return;

            const prevLayout = cfg.layout;
            const prevPlaylistId = cfg.activePlaylistId;
            cfg = { ...cfg, ...newVal };

            // Soft-only updates (volume/speed/etc.) — never rebuild playlist or restart video
            const needsPlaylist = changedKeys.some((k) => PLAYLIST_AFFECTING_KEYS.includes(k));
            const needsLayout = changedKeys.includes('layout')
                || (newVal.activePlaylistId !== undefined && newVal.activePlaylistId !== prevPlaylistId);
            const softOnly = !needsPlaylist && !needsLayout
                && changedKeys.every((k) => SOFT_CONFIG_KEYS.includes(k));

            if (softOnly) {
                if (changedKeys.includes('volume')) {
                    const vol = Math.max(0, Math.min(1, cfg.volume ?? 0.7));
                    if (wallModeActive || cfg.layout === 'grid') {
                        applyWallAudio({ volume: vol });
                    } else if (mainVideo) {
                        mainVideo.volume = vol;
                        if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
                    }
                    if (hud.volume) hud.volume.value = Math.round(vol * 100);
                    updateHudMuteIcon();
                }
                if (changedKeys.includes('playbackSpeed')) {
                    applyPlaybackSpeed();
                }
                if (changedKeys.some((k) => ['showDate', 'format12h', 'showSeconds', 'showClock', 'clockColor', 'clockOpacity', 'clockSize', 'font', 'pos', 'hudAlwaysShow', 'hudIdleMs'].includes(k))) {
                    applyHUD();
                    if (changedKeys.includes('hudAlwaysShow') || changedKeys.includes('hudIdleMs')) revealHud();
                }
                if (changedKeys.some((k) => ['brightness', 'contrast', 'saturate', 'sepia', 'grayscale'].includes(k))) {
                    applyGlobalStyles();
                }
                if (changedKeys.includes('scaling') || changedKeys.includes('maxDisplayHeight')) {
                    const fit = objectFitFromConfig();
                    // "Fit whole frame" means show the entire picture — leftover wheel zoom
                    // would still clip edges even with the new contain layout.
                    if (changedKeys.includes('scaling') && fit !== 'cover') {
                        videoZoom = DEFAULT_VIDEO_ZOOM;
                    }
                    try { applyCinemaObjectFit(cinemaMediaEl() || mainVideo, fit); } catch (_) {}
                    if (wallModeActive) {
                        try { applyWallVideoZoom(); } catch (_) {}
                    }
                    try { scheduleVideoStageSave(); } catch (_) {}
                }
                return;
            }

            applyGlobalStyles();
            applyHUD();
            initNeonEngine();
            refreshParticles();
            if (changedKeys.includes('scaling') || changedKeys.includes('maxDisplayHeight')) {
                const fit = objectFitFromConfig();
                if (changedKeys.includes('scaling') && fit !== 'cover') {
                    videoZoom = DEFAULT_VIDEO_ZOOM;
                }
                try { applyCinemaObjectFit(cinemaMediaEl() || mainVideo, fit); } catch (_) {}
            }

            if (needsPlaylist) {
                // Keep current clip if it still exists after rebuild
                const prevItem = playlist[currentIdx];
                const prevKey = prevItem
                    ? (prevItem.name || prevItem.handle?.name || prevItem.url || '')
                    : '';
                await buildPlaylist();
                if (prevKey && playlist.length) {
                    const found = playlist.findIndex((it) =>
                        (it.name || it.handle?.name || it.url || '') === prevKey
                    );
                    if (found >= 0) currentIdx = found;
                    else currentIdx = Math.min(currentIdx, playlist.length - 1);
                }
                // Playlist order changed — history indices are stale
                playHistory = [];
            }

            if (needsLayout || cfg.layout !== prevLayout) {
                initLayout();
            } else {
                updateHUD();
            }
        });
    }

    function initNeonEngine() {
        if (!neonEngine) neonEngine = new NeonBorderEngine(neonFrame, () => cfg);
        neonEngine.rebuild();
        neonEngine.start();
    }

    function refreshParticles() {
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        document.body.classList.toggle('fx-active', anyFx);
        if (!particleEngine) particleEngine = new ParticleFXEngine(bokehCanvas, () => cfg);
        if (anyFx) {
            particleEngine.rebuild();
            if (!particleEngine.rafId) particleEngine.start();
            syncParticlePerformance();
        } else {
            particleEngine.destroy();
        }
    }

    function syncParticlePerformance() {
        if (!particleEngine) return;
        const videoBusy = cfg.layout === 'cinema' && mainVideo && !mainVideo.paused && !isPaused;
        const forceOff = cfg.disableParticles || cfg.performanceMode;
        if (forceOff && videoBusy) {
            particleEngine.setPerformanceMode(true);
            // Fully pause particle loop while media plays in perf mode
            if (particleEngine.rafId) particleEngine.destroy();
            document.body.classList.remove('fx-active');
            return;
        }
        particleEngine.setPerformanceMode(videoBusy || !!cfg.performanceMode);
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        if (anyFx && !particleEngine.rafId && !(forceOff && videoBusy)) {
            document.body.classList.add('fx-active');
            particleEngine.rebuild();
            particleEngine.start();
        }
    }

    function computeOptimalGrid(cellCount) {
        if (cellCount <= 1) return { cols: 1, rows: 1 };
        const aspect = innerWidth / innerHeight;
        let best = { cols: 1, rows: cellCount, score: -Infinity };
        for (let cols = 1; cols <= cellCount; cols++) {
            const rows = Math.ceil(cellCount / cols);
            const waste = cols * rows - cellCount;
            const cellAspect = (cols / rows) * aspect;
            const target = 16 / 9;
            const score = -Math.abs(Math.log(cellAspect / target)) - waste * 0.45;
            if (score > best.score) best = { cols, rows, score };
        }
        return { cols: best.cols, rows: best.rows };
    }

    /** Best cols×rows for wall count so every cell fits in the viewport (contain, no crop). */
    function wallGridForCount(count, vw, vh) {
        const n = WALL_COUNTS.includes(count) ? count : 8;
        const w = Math.max(320, vw || window.innerWidth || 1280);
        const h = Math.max(240, vh || window.innerHeight || 720);
        const tall = h > w * 1.08;
        // Prefer landscape-friendly matrices; flip when window is portrait
        const presets = {
            2: tall ? [1, 2] : [2, 1],
            6: tall ? [2, 3] : [3, 2],
            8: tall ? [2, 4] : [4, 2],
        };
        let [cols, rows] = presets[n] || [4, 2];
        // If cells would be extremely thin/tall, flip once for better 16:9 contain
        const gap = 8;
        const cellW = (w - gap * (cols + 1)) / cols;
        const cellH = (h - gap * (rows + 1)) / rows;
        if (cellW > 0 && cellH > 0) {
            const cellAr = cellW / cellH;
            // For landscape video (~1.78), prefer cells not much taller than wide when we can flip
            if (!tall && cellAr < 1.05 && cols > rows) {
                // almost square/tall cells in landscape window — try transpose if product matches
                if (rows * cols === n) {
                    const t = cols; cols = rows; rows = t;
                }
            }
        }
        return { cols, rows, cellCount: n };
    }

    function applyGridDimensions() {
        let cellCount = Math.max(1, (cfg.gridCols || 4) * (cfg.gridRows || 1));
        if (wallModeActive) {
            const box = wallContentBox();
            const grid = wallGridForCount(wallCount, box.w, box.h);
            cellCount = grid.cellCount;
            cfg.gridCols = grid.cols;
            cfg.gridRows = grid.rows;
            document.documentElement.style.setProperty('--grid-cols', String(grid.cols));
            document.documentElement.style.setProperty('--grid-rows', String(grid.rows));
            document.documentElement.style.setProperty('--wall-cols', String(grid.cols));
            document.documentElement.style.setProperty('--wall-rows', String(grid.rows));
            reflowWallLayout({ skipRebuild: true, cols: grid.cols, rows: grid.rows, cellCount });
            return { cols: grid.cols, rows: grid.rows, cellCount };
        }
        const grid = computeOptimalGrid(cellCount);
        document.documentElement.style.setProperty('--grid-cols', grid.cols);
        document.documentElement.style.setProperty('--grid-rows', grid.rows);
        return { ...grid, cellCount };
    }

    /** Available content box for the wall (real viewport, zoom-safe). */
    function wallViewportBox() {
        try {
            const vp = window.FAFOViewport?.viewportBox?.();
            if (vp && vp.width > 80 && vp.height > 80) {
                return { w: Math.round(vp.width), h: Math.round(vp.height), x: vp.x || 0, y: vp.y || 0 };
            }
        } catch (_) {}
        const vv = window.visualViewport;
        if (vv && vv.width > 80 && vv.height > 80) {
            return {
                w: Math.round(vv.width),
                h: Math.round(vv.height),
                x: Math.round(vv.offsetLeft || 0),
                y: Math.round(vv.offsetTop || 0),
            };
        }
        return {
            w: Math.round(window.innerWidth || document.documentElement.clientWidth || 1280),
            h: Math.round(window.innerHeight || document.documentElement.clientHeight || 720),
            x: 0,
            y: 0,
        };
    }

    const STAGE_LAYOUTS = ['dock', 'left', 'right', 'under'];
    const STAGE_WIDTHS = ['wide', 'med', 'narrow'];
    const STAGE_LAYOUT_LABEL = { dock: 'Dock', left: 'Left', right: 'Right', under: 'Under' };
    const STAGE_WIDTH_LABEL = { wide: 'Wide', med: 'Med', narrow: 'Narrow' };

    function stageWidthFraction() {
        if (stageVideoWidth === 'narrow') return 0.42;
        if (stageVideoWidth === 'med') return 0.58;
        return 0.74;
    }

    /**
     * Left / Right / Under frames. Dock returns null (full window, floating chrome).
     * Video rect is the picture only. HUD sits beneath that picture, same width.
     */
    function stageLayoutFrames() {
        if (!STAGE_LAYOUTS.includes(stageLayoutMode) || stageLayoutMode === 'dock') return null;
        const ww = Math.round(window.innerWidth || document.documentElement.clientWidth || 1280);
        const wh = Math.round(window.innerHeight || document.documentElement.clientHeight || 720);
        const gap = 10;
        const edge = 8;
        const hudH = 156;
        const fr = stageWidthFraction();
        if (stageLayoutMode === 'under') {
            const videoW = Math.max(320, Math.round((ww - edge * 2) * fr));
            const videoX = Math.max(edge, Math.round((ww - videoW) / 2));
            const videoH = Math.max(160, wh - hudH - edge * 2 - gap);
            return {
                panel: null,
                video: { x: videoX, y: edge, w: videoW, h: videoH },
                hud: { x: videoX, y: edge + videoH + gap, w: videoW, h: Math.max(120, wh - (edge + videoH + gap) - edge) },
            };
        }
        const inner = Math.max(420, ww - edge * 2 - gap);
        let videoW = Math.round(inner * fr);
        let panelW = inner - videoW;
        if (panelW < 240) {
            panelW = Math.min(240, Math.round(inner * 0.42));
            videoW = Math.max(200, inner - panelW);
        }
        if (videoW < 200) {
            videoW = 200;
            panelW = Math.max(180, inner - videoW);
        }
        const videoH = Math.max(160, wh - hudH - edge * 2 - gap);
        const hudTop = edge + videoH + gap;
        if (stageLayoutMode === 'left') {
            const videoX = edge + panelW + gap;
            return {
                panel: { x: edge, y: edge, w: panelW, h: wh - edge * 2 },
                video: { x: videoX, y: edge, w: videoW, h: videoH },
                hud: { x: videoX, y: hudTop, w: videoW, h: Math.max(120, wh - hudTop - edge) },
            };
        }
        return {
            panel: { x: ww - edge - panelW, y: edge, w: panelW, h: wh - edge * 2 },
            video: { x: edge, y: edge, w: videoW, h: videoH },
            hud: { x: edge, y: hudTop, w: videoW, h: Math.max(120, wh - hudTop - edge) },
        };
    }

    /** Layout slot plus the live drag offset, kept on screen. */
    function nudgedVideoRect(rect) {
        if (!rect) return rect;
        const ww = Math.round(window.innerWidth || 1280);
        const wh = Math.round(window.innerHeight || 720);
        const w = rect.w;
        const h = rect.h;
        let x = Math.round(rect.x + (stageNudgeX || 0));
        let y = Math.round(rect.y + (stageNudgeY || 0));
        x = Math.max(0, Math.min(Math.max(0, ww - Math.min(w, ww)), x));
        y = Math.max(0, Math.min(Math.max(0, wh - Math.min(h, wh)), y));
        return { ...rect, x, y };
    }

    function framesWithNudge(frames) {
        if (!frames?.video) return frames;
        const video = nudgedVideoRect(frames.video);
        const dx = video.x - frames.video.x;
        const dy = video.y - frames.video.y;
        return {
            ...frames,
            video,
            hud: frames.hud
                ? { ...frames.hud, x: frames.hud.x + dx, y: frames.hud.y + dy }
                : null,
        };
    }

    function updateStageLayoutButtons() {
        const layoutLabel = `Layout · ${STAGE_LAYOUT_LABEL[stageLayoutMode] || 'Dock'}`;
        const widthLabel = `Video · ${STAGE_WIDTH_LABEL[stageVideoWidth] || 'Wide'}`;
        const layoutTitle = 'Cycle layout: Dock (float) → Left panel → Right panel → Player under the video';
        const widthTitle = 'Video area width for Left, Right, and Under: Wide → Medium → Narrow';
        ['hud-stage-layout', 'meta-stage-layout'].forEach((id) => {
            const btn = document.getElementById(id);
            if (!btn) return;
            btn.textContent = layoutLabel;
            btn.title = layoutTitle;
            btn.classList.toggle('active', stageLayoutMode !== 'dock');
        });
        ['hud-stage-width', 'meta-stage-width'].forEach((id) => {
            const btn = document.getElementById(id);
            if (!btn) return;
            btn.textContent = widthLabel;
            btn.title = widthTitle;
            btn.classList.toggle('active', stageVideoWidth !== 'wide');
        });
    }

    function saveStageLayout() {
        try {
            chrome.storage.local.set({
                fafoStageLayout: {
                    mode: stageLayoutMode,
                    width: stageVideoWidth,
                    nudgeX: Math.round(stageNudgeX || 0),
                    nudgeY: Math.round(stageNudgeY || 0),
                },
            }).catch(() => {});
        } catch (_) {}
    }

    async function loadStageLayoutPrefs() {
        try {
            const data = await chrome.storage.local.get('fafoStageLayout');
            const s = data.fafoStageLayout || {};
            if (STAGE_LAYOUTS.includes(s.mode)) stageLayoutMode = s.mode;
            if (STAGE_WIDTHS.includes(s.width)) stageVideoWidth = s.width;
            if (typeof s.nudgeX === 'number') stageNudgeX = s.nudgeX;
            if (typeof s.nudgeY === 'number') stageNudgeY = s.nudgeY;
        } catch (_) {}
        document.body.dataset.stageLayout = stageLayoutMode;
        document.body.dataset.stageWidth = stageVideoWidth;
        document.body.classList.toggle('fafo-stage-framed', stageLayoutMode !== 'dock');
        updateStageLayoutButtons();
    }

    function applyStageHud(frames) {
        const el = hud.box;
        if (!el || !frames?.hud) return;
        const h = frames.hud;
        const s = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));
        const layoutW = Math.max(220, Math.round(h.w / s));
        const layoutH = Math.max(110, Math.round(h.h / s));
        el.classList.add('hud-stage-slot', 'hud-pinned', 'hud-visible');
        el.classList.remove('hud-idle');
        el.style.setProperty('--fafo-chrome-scale', String(s));
        el.style.setProperty('transform', `scale(${s})`, 'important');
        el.style.setProperty('transform-origin', 'top left', 'important');
        el.style.setProperty('left', `${h.x}px`, 'important');
        el.style.setProperty('top', `${h.y}px`, 'important');
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');
        el.style.setProperty('width', `${layoutW}px`, 'important');
        el.style.setProperty('height', `${layoutH}px`, 'important');
        el.style.setProperty('max-width', `${layoutW}px`, 'important');
        el.style.setProperty('max-height', `${layoutH}px`, 'important');
        hudX = h.x;
        hudY = h.y;
        hudPinned = true;
    }

    function clearStageHudStyles() {
        const el = hud.box;
        if (!el) return;
        el.classList.remove('hud-stage-slot');
        ['width', 'height', 'max-width', 'max-height'].forEach((prop) => {
            el.style.removeProperty(prop);
        });
    }

    /** Re-apply Left / Right / Under (or return to floating Dock). */
    function applyStageLayoutNow() {
        document.body.dataset.stageLayout = stageLayoutMode;
        document.body.dataset.stageWidth = stageVideoWidth;
        document.body.classList.toggle('fafo-stage-framed', stageLayoutMode !== 'dock');
        try { applyVideoStageLayout(); } catch (_) {}
        if (wallModeActive) {
            try { reflowWallLayout({ skipRebuild: true }); } catch (_) {}
        }
        updateStageLayoutButtons();
    }

    function cycleStageLayout() {
        const i = Math.max(0, STAGE_LAYOUTS.indexOf(stageLayoutMode));
        stageLayoutMode = STAGE_LAYOUTS[(i + 1) % STAGE_LAYOUTS.length];
        stageNudgeX = 0;
        stageNudgeY = 0;
        applyStageLayoutNow();
        saveStageLayout();
        showScaleToast(`Layout · ${STAGE_LAYOUT_LABEL[stageLayoutMode] || 'Dock'}`);
    }

    function cycleStageWidth() {
        const i = Math.max(0, STAGE_WIDTHS.indexOf(stageVideoWidth));
        stageVideoWidth = STAGE_WIDTHS[(i + 1) % STAGE_WIDTHS.length];
        applyStageLayoutNow();
        saveStageLayout();
        const where = stageLayoutMode === 'dock'
            ? 'saved for Left, Right, and Under'
            : (STAGE_LAYOUT_LABEL[stageLayoutMode] || 'layout');
        showScaleToast(`Video · ${STAGE_WIDTH_LABEL[stageVideoWidth] || 'Wide'} · ${where}`);
    }

    /**
     * Wall content box = viewport minus open Tags/Library panels + breathing pad.
     * Left / Right / Under use the video frame so tiles stay in the picture area.
     * Prevents the wall from painting under HUD/config chrome (overlapping tiles).
     */
    function wallContentBox() {
        const framed = stageLayoutFrames();
        if (framed?.video && framed.video.w > 80 && framed.video.h > 80) {
            const v = nudgedVideoRect(framed.video);
            return {
                x: v.x, y: v.y, w: v.w, h: v.h,
                left: v.x, right: 0, top: v.y, bottom: 0,
            };
        }
        const box = wallViewportBox();
        const parseCssPx = (name) => {
            try {
                const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
                const n = parseFloat(raw);
                return Number.isFinite(n) ? n : 0;
            } catch (_) {
                return 0;
            }
        };
        let left = Math.max(0, parseCssPx('--safe-left'));
        let right = Math.max(0, parseCssPx('--safe-right'));
        let top = Math.max(0, parseCssPx('--safe-top'));
        let bottom = Math.max(0, parseCssPx('--safe-bottom'));

        // Live measure open panels (scale-fix may lag or stage-early-return)
        try {
            const ww = box.w || window.innerWidth || 1280;
            const panels = [
                document.getElementById('meta-panel'),
                document.getElementById('meta-library-panel'),
            ];
            for (const el of panels) {
                if (!el) continue;
                if (el.classList.contains('collapsed') || el.classList.contains('hidden')) continue;
                if (el.getAttribute('aria-hidden') === 'true') continue;
                const r = el.getBoundingClientRect();
                if (r.width < 60 || r.height < 60) continue;
                if (r.left > ww * 0.28) {
                    right = Math.max(right, Math.round(ww - r.left) + 10);
                } else if (r.right < ww * 0.72) {
                    left = Math.max(left, Math.round(r.right) + 10);
                } else {
                    if (r.left < ww * 0.22) left = Math.max(left, Math.round(r.right) + 10);
                    if (r.right > ww * 0.78) right = Math.max(right, Math.round(ww - r.left) + 10);
                }
            }
            // Player HUD when visible/pinned — leave a strip so wall config chips aren't on top of tiles
            const hudEl = document.getElementById('player-hud');
            if (hudEl && !hudEl.classList.contains('hud-idle')) {
                const hr = hudEl.getBoundingClientRect();
                if (hr.width > 80 && hr.height > 40) {
                    const margin = 8;
                    // If HUD sits on a side, carve that side; if bottom/top band, carve that edge
                    if (hr.bottom < box.h * 0.42) {
                        top = Math.max(top, Math.round(hr.bottom - box.y) + margin);
                    } else if (hr.top > box.h * 0.58) {
                        bottom = Math.max(bottom, Math.round(box.y + box.h - hr.top) + margin);
                    } else if (hr.left > box.w * 0.45) {
                        right = Math.max(right, Math.round(box.x + box.w - hr.left) + margin);
                    } else if (hr.right < box.w * 0.55) {
                        left = Math.max(left, Math.round(hr.right - box.x) + margin);
                    }
                }
            }
        } catch (_) { /* ignore measure failures */ }

        // Keep a usable stage
        const maxInsetX = Math.max(0, box.w - 280);
        const maxInsetY = Math.max(0, box.h - 200);
        left = Math.min(left, maxInsetX * 0.7);
        right = Math.min(right, maxInsetX - left);
        top = Math.min(top, maxInsetY * 0.55);
        bottom = Math.min(bottom, maxInsetY - top);

        const w = Math.max(200, Math.round(box.w - left - right));
        const h = Math.max(160, Math.round(box.h - top - bottom));
        return {
            x: Math.round(box.x + left),
            y: Math.round(box.y + top),
            w,
            h,
            left: Math.round(left),
            right: Math.round(right),
            top: Math.round(top),
            bottom: Math.round(bottom),
        };
    }

    function normalizeWallPrefs(raw) {
        const src = raw && typeof raw === 'object' ? raw : {};
        const count = WALL_COUNTS.includes(parseInt(src.count, 10))
            ? parseInt(src.count, 10)
            : 8;
        const gapScale = Math.max(0.4, Math.min(1.8, Number(src.gapScale) || 1));
        return {
            count,
            gapScale: Math.round(gapScale * 100) / 100,
            fullFrame: src.fullFrame !== false,
            liveReflow: src.liveReflow !== false,
            stayOnScreen: src.stayOnScreen !== false,
            muteHoverScale: src.muteHoverScale !== false,
        };
    }

    function getWallVideos() {
        const sceneEl = scene || document.getElementById('scene-root');
        if (!sceneEl) return [];
        return Array.from(sceneEl.querySelectorAll('.grid-cell video'));
    }

    function getWallPrimaryVideo() {
        const vids = getWallVideos();
        if (!vids.length) return null;
        return vids.find((v) => v.dataset.wallPrimary === '1') || vids[0];
    }

    /** Mark one wall tile as the audio focus; others stay muted. */
    function setWallPrimaryVideo(videoEl) {
        const vids = getWallVideos();
        if (!vids.length) return null;
        const target = videoEl && vids.includes(videoEl) ? videoEl : vids[0];
        vids.forEach((v) => {
            if (v === target) v.dataset.wallPrimary = '1';
            else delete v.dataset.wallPrimary;
            try { v.classList.toggle('wall-audio-primary', v === target); } catch (_) {}
        });
        mainVideo = target;
        return target;
    }

    /**
     * Apply cfg.volume + wallAudioMuted to wall tiles.
     * Only the primary tile unmutes when sound is wanted (user gesture unlock).
     */
    function applyWallAudio(opts = {}) {
        if (!wallModeActive && cfg.layout !== 'grid') return;
        const vids = getWallVideos();
        if (!vids.length) return;
        const vol = Math.max(0, Math.min(1,
            opts.volume !== undefined ? opts.volume : (cfg.volume ?? 0.7)));
        if (opts.muted === true) wallAudioMuted = true;
        if (opts.muted === false) wallAudioMuted = false;
        // volume 0 forces mute UX; dragging above 0 with gesture unlocks
        if (opts.fromVolumeSlider && vol > 0) {
            wallAudioMuted = false;
            userUnlockedAudio = true;
        }
        let primary = getWallPrimaryVideo() || setWallPrimaryVideo(vids[0]);
        if (!primary || !vids.includes(primary)) primary = setWallPrimaryVideo(vids[0]);

        const wantSound = !wallAudioMuted && vol > 0 && userUnlockedAudio;
        vids.forEach((v) => {
            try {
                v.volume = vol;
                if (v === primary && wantSound) {
                    v.muted = false;
                    v.removeAttribute('muted');
                } else {
                    v.muted = true;
                    v.setAttribute('muted', '');
                }
            } catch (_) { /* ignore */ }
        });
        mainVideo = primary;
        try { updateHudMuteIcon(); } catch (_) {}
    }

    /**
     * Cell size for a wall tile. Grid rows used to collapse to 0 (minmax(0,1fr)
     * plus absolute videos), so clientHeight was 0 while audio still played.
     */
    function wallCellBox(cell) {
        let w = cell?.clientWidth || 0;
        let h = cell?.clientHeight || 0;
        if (w >= 8 && h >= 8) return { w, h };
        const sceneEl = cell?.parentElement || scene || document.getElementById('scene-root');
        const sw = sceneEl?.clientWidth || 0;
        const sh = sceneEl?.clientHeight || 0;
        let cols = 1;
        let rows = 1;
        try {
            const cs = getComputedStyle(sceneEl);
            const cc = (cs.gridTemplateColumns || '').split(' ').filter(Boolean).length;
            const rr = (cs.gridTemplateRows || '').split(' ').filter(Boolean).length;
            if (cc > 0) cols = cc;
            if (rr > 0) rows = rr;
        } catch (_) {}
        const gap = 8;
        const pad = 8;
        if (sw > 40) w = Math.max(w, (sw - pad * 2 - gap * Math.max(0, cols - 1)) / cols);
        if (sh > 40) h = Math.max(h, (sh - pad * 2 - gap * Math.max(0, rows - 1)) / rows);
        if (h < 8 || w < 8) {
            const box = wallContentBox();
            w = Math.max(w, (box.w - pad * 2) / cols);
            h = Math.max(h, (box.h - pad * 2) / rows);
        }
        return {
            w: Math.max(48, Math.round(w) || 48),
            h: Math.max(48, Math.round(h) || 48),
        };
    }

    /** Apply current videoZoom to every wall tile. Fit whole frame, then zoom that frame. */
    function applyWallVideoZoom() {
        if (!wallModeActive) return;
        const sceneEl = scene || document.getElementById('scene-root');
        if (!sceneEl) return;
        const z = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, Number(videoZoom) || DEFAULT_VIDEO_ZOOM));
        videoZoom = Math.round(z * 1000) / 1000;
        document.documentElement.style.setProperty('--video-zoom', String(videoZoom));
        sceneEl.style.setProperty('--video-zoom', String(videoZoom));
        const fit = wallPrefs.fullFrame ? 'contain' : (objectFitFromConfig() === 'cover' ? 'cover' : 'contain');
        sceneEl.querySelectorAll('.grid-cell').forEach((cell) => {
            cell.style.overflow = 'hidden';
            cell.style.position = 'relative';
            const v = cell.querySelector('video, img');
            if (!v) return;
            v.style.removeProperty('inset');
            v.style.removeProperty('margin');
            const box = wallCellBox(cell);
            layoutMediaIntoBox(v, box.w, box.h, videoZoom, fit, 0, 0);
            v.style.setProperty('--video-zoom', String(videoZoom), 'important');
            v.style.setProperty('background', '#000');
        });
        try {
            const s = document.getElementById('meta-slider-video');
            const lab = document.getElementById('meta-slider-video-val');
            const pctLabel = Math.round(videoZoom * 100) + '%';
            const sliderActive = s && (document.activeElement === s || s.matches?.(':active'));
            if (s && !sliderActive) s.value = String(Math.round(videoZoom * 100));
            if (lab) lab.textContent = pctLabel;
        } catch (_) {}
    }

    /**
     * Fit the wall grid fully on-screen with contain videos (no crop / no overflow).
     * Call on resize, chrome scale, and count changes (when live reflow is on).
     * Uses wallContentBox() so Tags/HUD chrome do not sit on top of tiles.
     */
    function reflowWallLayout(opts = {}) {
        if (!wallModeActive) return;
        const sceneEl = scene || document.getElementById('scene-root');
        if (!sceneEl) return;

        const box = wallContentBox();
        const grid = opts.cols
            ? { cols: opts.cols, rows: opts.rows, cellCount: opts.cellCount || wallCount }
            : wallGridForCount(wallCount, box.w, box.h);

        // Pad/gap scale gently with viewport so 8 tiles still fit; Options gap density multiplies
        const shortSide = Math.min(box.w, box.h);
        const gapMul = wallPrefs.gapScale || 1;
        const gap = Math.max(2, Math.min(14, Math.round(shortSide * 0.008 * gapMul)));
        const pad = Math.max(3, Math.min(16, Math.round(shortSide * 0.01 * gapMul)));

        document.documentElement.style.setProperty('--grid-cols', String(grid.cols));
        document.documentElement.style.setProperty('--grid-rows', String(grid.rows));
        document.documentElement.style.setProperty('--wall-cols', String(grid.cols));
        document.documentElement.style.setProperty('--wall-rows', String(grid.rows));
        document.documentElement.style.setProperty('--wall-gap', `${gap}px`);
        document.documentElement.style.setProperty('--wall-pad', `${pad}px`);
        document.documentElement.style.setProperty('--video-zoom', String(videoZoom || 1));

        sceneEl.classList.add('layout-grid', 'layout-wall');
        document.body.classList.toggle('fafo-wall-mute-hover', !!wallPrefs.muteHoverScale);

        if (wallPrefs.stayOnScreen) {
            // Pin scene to the free content box (not under Tags/HUD)
            sceneEl.style.cssText = [
                'position:fixed',
                `left:${box.x}px`,
                `top:${box.y}px`,
                `width:${box.w}px`,
                `height:${box.h}px`,
                'max-width:100%',
                'max-height:100%',
                'margin:0',
                'box-sizing:border-box',
                'overflow:hidden',
                'display:grid',
                `grid-template-columns:repeat(${grid.cols}, minmax(0, 1fr))`,
                `grid-template-rows:repeat(${grid.rows}, minmax(48px, 1fr))`,
                `gap:${gap}px`,
                `padding:${pad}px`,
                'place-content:stretch',
                'align-content:stretch',
                'z-index:6',
                `--video-zoom:${videoZoom || 1}`,
            ].join(';');
        } else {
            sceneEl.style.cssText = [
                'display:grid',
                `grid-template-columns:repeat(${grid.cols}, minmax(0, 1fr))`,
                `grid-template-rows:repeat(${grid.rows}, minmax(48px, 1fr))`,
                `gap:${gap}px`,
                `padding:${pad}px`,
                'box-sizing:border-box',
                'overflow:hidden',
                'width:100%',
                'height:100%',
                `--video-zoom:${videoZoom || 1}`,
            ].join(';');
        }

        // Ensure cell count matches (count change needs rebuild)
        if (!opts.skipRebuild) {
            const cells = sceneEl.querySelectorAll('.grid-cell');
            if (cells.length !== grid.cellCount) {
                cfg.layout = 'grid';
                cfg.gridCols = grid.cols;
                cfg.gridRows = grid.rows;
                if (wallPrefs.fullFrame) cfg.scaling = 'scale-contain';
                try { initLayout(); } catch (_) {}
                return;
            }
        }

        // Tile geometry + live video zoom on every cell
        applyWallVideoZoom();
        // Keep primary audio target wired after reflow
        try {
            setWallPrimaryVideo(getWallPrimaryVideo());
            applyWallAudio();
        } catch (_) {}

        document.body.classList.add('fafo-wall-mode');
        document.body.dataset.wallCount = String(grid.cellCount);
        updateWallModeHudBtn();
    }

    function updateWallModeHudBtn() {
        const btn = document.getElementById('hud-wall-mode');
        if (btn) {
            btn.classList.toggle('active', !!wallModeActive);
            btn.setAttribute('aria-pressed', wallModeActive ? 'true' : 'false');
            const flags = [
                wallPrefs.fullFrame ? 'full frames' : 'may crop',
                wallPrefs.liveReflow ? 'live reflow' : 'static',
            ].join(' · ');
            btn.title = wallModeActive
                ? `Wall on · ${wallCount} videos · ${flags} · click to return · chips for count / gap`
                : 'Wall · multi-video grid (2 / 6 / 8) · full frames · click again to restore';
            btn.textContent = wallModeActive ? `Wall · ${wallCount}` : 'Wall';
        }
        document.body.classList.toggle('fafo-wall-mode', !!wallModeActive);
        document.body.classList.toggle('fafo-wall-mute-hover', !!(wallModeActive && wallPrefs.muteHoverScale));
        const cfgRow = document.getElementById('hud-wall-config');
        if (cfgRow) {
            cfgRow.classList.toggle('hidden', !wallModeActive);
            cfgRow.hidden = !wallModeActive;
            cfgRow.querySelectorAll('[data-wall-count]').forEach((chip) => {
                const n = parseInt(chip.getAttribute('data-wall-count'), 10);
                chip.classList.toggle('active', wallModeActive && n === wallCount);
            });
            // Gap density chips (optional HUD scalability controls)
            cfgRow.querySelectorAll('[data-wall-gap]').forEach((chip) => {
                const g = parseFloat(chip.getAttribute('data-wall-gap'));
                const cur = Math.round((wallPrefs.gapScale || 1) * 100) / 100;
                chip.classList.toggle('active', wallModeActive && Math.abs(g - cur) < 0.05);
            });
            // Feature toggles in HUD wall config
            cfgRow.querySelectorAll('[data-wall-flag]').forEach((chip) => {
                const key = chip.getAttribute('data-wall-flag');
                const on = !!(wallPrefs[key]);
                chip.classList.toggle('active', wallModeActive && on);
                chip.setAttribute('aria-pressed', on ? 'true' : 'false');
            });
        }
    }

    async function loadWallPrefs() {
        try {
            const data = await chrome.storage.local.get(['fafoWallPrefs', 'fafoWallCount']);
            let prefs = data.fafoWallPrefs;
            if (!prefs || typeof prefs !== 'object') {
                const n = parseInt(data.fafoWallCount, 10);
                prefs = { count: WALL_COUNTS.includes(n) ? n : 8 };
            }
            wallPrefs = normalizeWallPrefs(prefs);
            wallCount = wallPrefs.count;
        } catch (_) {}
    }

    function saveWallPrefs() {
        try {
            wallPrefs = normalizeWallPrefs({ ...wallPrefs, count: wallCount });
            chrome.storage.local.set({
                fafoWallPrefs: wallPrefs,
                fafoWallCount: wallCount,
            }).catch(() => {});
        } catch (_) {}
    }

    function setWallGapScale(scale) {
        const n = Math.max(0.4, Math.min(1.8, Number(scale) || 1));
        wallPrefs.gapScale = Math.round(n * 100) / 100;
        saveWallPrefs();
        if (wallModeActive) reflowWallLayout({ skipRebuild: true });
        updateWallModeHudBtn();
        return wallPrefs.gapScale;
    }

    function setWallFlag(key, value) {
        if (!['fullFrame', 'liveReflow', 'stayOnScreen', 'muteHoverScale'].includes(key)) return wallPrefs;
        wallPrefs[key] = !!value;
        saveWallPrefs();
        if (wallModeActive) reflowWallLayout({ skipRebuild: true });
        updateWallModeHudBtn();
        return wallPrefs;
    }

    /**
     * Set wall tile count (2 / 6 / 8). If wall is on, reflow immediately.
     */
    function setWallCount(n) {
        const count = WALL_COUNTS.includes(n) ? n : 8;
        if (count === wallCount && wallModeActive) {
            reflowWallLayout();
            return wallCount;
        }
        wallCount = count;
        wallPrefs.count = count;
        saveWallPrefs();
        if (wallModeActive) {
            const box = wallContentBox();
            const grid = wallGridForCount(wallCount, box.w, box.h);
            cfg.layout = 'grid';
            cfg.gridCols = grid.cols;
            cfg.gridRows = grid.rows;
            if (wallPrefs.fullFrame) cfg.scaling = 'scale-contain';
            try { initLayout(); } catch (e) { console.warn('wall count', e); }
            reflowWallLayout();
        }
        updateWallModeHudBtn();
        return wallCount;
    }

    /**
     * Toggle wall grid ↔ previous layout (usually cinema).
     * Session-only — does not change Options permanently.
     */
    function toggleWallMode() {
        if (wallModeActive) {
            const snap = wallModeRestore || { layout: 'cinema', gridCols: 4, gridRows: 1, scaling: 'scale-contain' };
            wallModeActive = false;
            wallModeRestore = null;
            cfg.layout = snap.layout || 'cinema';
            if (snap.gridCols != null) cfg.gridCols = snap.gridCols;
            if (snap.gridRows != null) cfg.gridRows = snap.gridRows;
            if (snap.scaling) cfg.scaling = snap.scaling;
            // Clear wall-only inline styles on scene
            try {
                if (scene) {
                    scene.classList.remove('layout-wall');
                    scene.removeAttribute('style');
                }
            } catch (_) {}
            document.body.classList.remove('fafo-wall-mode', 'fafo-wall-mute-hover');
            delete document.body.dataset.wallCount;
            wallAudioMuted = true;
            try { initLayout(); } catch (e) { console.warn('wall restore', e); }
            updateWallModeHudBtn();
            return wallModeActive;
        }

        wallModeRestore = {
            layout: cfg.layout || 'cinema',
            gridCols: cfg.gridCols || 4,
            gridRows: cfg.gridRows || 1,
            scaling: cfg.scaling || 'scale-contain',
        };
        wallModeActive = true;
        // Start muted for autoplay; volume/mute controls unlock primary tile audio
        wallAudioMuted = true;
        const box = wallContentBox();
        const grid = wallGridForCount(wallCount, box.w, box.h);
        cfg.layout = 'grid';
        cfg.gridCols = grid.cols;
        cfg.gridRows = grid.rows;
        if (wallPrefs.fullFrame) cfg.scaling = 'scale-contain';
        try { initLayout(); } catch (e) { console.warn('wall enter', e); }
        reflowWallLayout();
        try { applyVideoZoom(); } catch (_) {}
        try { applyWallAudio(); } catch (_) {}
        updateWallModeHudBtn();
        return wallModeActive;
    }

    function initGridResizeListener() {
        const schedule = () => {
            if (cfg.layout !== 'grid' && !wallModeActive) return;
            clearTimeout(gridResizeTimer);
            gridResizeTimer = setTimeout(() => {
                if (stageLayoutMode !== 'dock') {
                    try { applyStageLayoutNow(); } catch (_) {}
                }
                if (wallModeActive) {
                    if (wallPrefs.liveReflow) reflowWallLayout({ skipRebuild: true });
                } else {
                    applyGridDimensions();
                }
            }, 80);
        };
        window.addEventListener('resize', schedule);
        try {
            window.visualViewport?.addEventListener('resize', schedule);
            window.visualViewport?.addEventListener('scroll', schedule);
        } catch (_) {}
        // Options / other tab updates wall prefs live
        try {
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local' || !changes.fafoWallPrefs) return;
                const next = normalizeWallPrefs(changes.fafoWallPrefs.newValue);
                wallPrefs = next;
                wallCount = next.count;
                if (wallModeActive) {
                    try {
                        const box = wallContentBox();
                        const grid = wallGridForCount(wallCount, box.w, box.h);
                        const cells = (scene || document.getElementById('scene-root'))?.querySelectorAll('.grid-cell');
                        if (cells && cells.length !== grid.cellCount) {
                            cfg.gridCols = grid.cols;
                            cfg.gridRows = grid.rows;
                            try { initLayout(); } catch (_) {}
                        }
                        reflowWallLayout({ skipRebuild: true });
                    } catch (_) {}
                }
                updateWallModeHudBtn();
            });
        } catch (_) {}
    }

    function revokeCurrentBlob() {
        if (currentBlobUrl) {
            const old = currentBlobUrl;
            currentBlobUrl = null;
            // Defer revoke — immediate revoke mid-load kills play() and cascades "stalled"
            setTimeout(() => {
                try { URL.revokeObjectURL(old); } catch (_) {}
            }, 2500);
        }
    }

    // NEW: Helper for Theme Engine
    function hexToRgb(hex) {
        const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    function isPerfMode() {
        return !!(cfg.performanceMode || cfg.disableCssFilters);
    }

    /** Dark-only UI chrome presets (tags panel / player HUD). */
    const DARK_UI_PRESETS = {
        cyan:   { accent: '#00e5ff', panelRgb: '12,12,18', hudRgb: '0,0,0', borderRgb: '0,229,255' },
        violet: { accent: '#b388ff', panelRgb: '14,10,20', hudRgb: '6,0,12', borderRgb: '179,136,255' },
        amber:  { accent: '#ffc107', panelRgb: '18,14,8',  hudRgb: '10,8,0', borderRgb: '255,193,7' },
        green:  { accent: '#69f0ae', panelRgb: '8,16,12',  hudRgb: '0,8,4',  borderRgb: '105,240,174' },
        rose:   { accent: '#ff80ab', panelRgb: '18,10,14', hudRgb: '12,0,6', borderRgb: '255,128,171' },
        steel:  { accent: '#90a4ae', panelRgb: '10,12,14', hudRgb: '4,6,8',  borderRgb: '144,164,174' },
        crimson:{ accent: '#ff5252', panelRgb: '16,8,8',   hudRgb: '10,0,0', borderRgb: '255,82,82' },
        ice:    { accent: '#e0f7fa', panelRgb: '8,12,16',  hudRgb: '0,4,8',  borderRgb: '128,222,234' },
    };

    function applyUiChromeStyles(root) {
        const presetName = cfg.uiThemePreset || 'cyan';
        const preset = DARK_UI_PRESETS[presetName] || DARK_UI_PRESETS.cyan;
        // Preset can drive accent unless user customized after; still apply panel colors from preset+opacity
        const panelA = Math.max(0.25, Math.min(0.98, Number(cfg.uiPanelOpacity ?? 0.92)));
        const hudA = Math.max(0.25, Math.min(0.98, Number(cfg.uiHudOpacity ?? 0.82)));
        const borderA = Math.max(0.05, Math.min(0.9, Number(cfg.uiPanelBorderOpacity ?? 0.14)));
        const radius = Math.max(4, Math.min(28, parseInt(cfg.uiRadius, 10) || 14));
        const panelRgb = preset.panelRgb;
        const hudRgb = preset.hudRgb;
        let borderRgb = preset.borderRgb;
        if (cfg.uiPanelBorderColor) {
            const br = hexToRgb(cfg.uiPanelBorderColor);
            if (br) borderRgb = `${br.r},${br.g},${br.b}`;
        }
        root.style.setProperty('--ui-panel-bg', `rgba(${panelRgb},${panelA})`);
        root.style.setProperty('--ui-hud-bg', `rgba(${hudRgb},${hudA})`);
        root.style.setProperty('--ui-panel-border', `rgba(${borderRgb},${borderA})`);
        root.style.setProperty('--ui-radius', `${radius}px`);
        root.style.setProperty('--ui-panel-rgb', panelRgb);
        root.dataset.uiTheme = presetName;
    }

    function applyGlobalStyles() {
        const root = document.documentElement;
        const body = document.body;

        // Dark UI chrome (transparency, radius, themed borders)
        applyUiChromeStyles(root);
        
        // Apply Accent Color Logic (may be overridden by theme preset if no custom accent saved)
        let accent = cfg.accentColor || '#00e5ff';
        const preset = DARK_UI_PRESETS[cfg.uiThemePreset || 'cyan'];
        if (preset && (!cfg.accentColor || cfg._accentFromPreset)) {
            // keep user's accent if set
        }
        const rgb = hexToRgb(accent);
        if (rgb) {
            root.style.setProperty('--accent', accent);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }
        // Full visual customizer (gradients / tag colors / anim) — may override accent further
        try {
            if (window.FAFOVisual && cfg.visual) {
                FAFOVisual.apply(cfg.visual);
            }
        } catch (_) {}

        // Color grading on #scene-root is expensive (re-filters the whole video layer).
        // Skip when identity, perf mode, or explicitly disabled so GPU can composite cleanly.
        const b = Number(cfg.brightness ?? 100);
        const c = Number(cfg.contrast ?? 100);
        const sat = Number(cfg.saturate ?? 100);
        const se = Number(cfg.sepia ?? 0);
        const g = Number(cfg.grayscale ?? 0);
        const identityFilters = b === 100 && c === 100 && sat === 100 && se === 0 && g === 0;
        const noFilters = cfg.disableCssFilters || cfg.performanceMode || identityFilters;
        if (noFilters) {
            root.style.setProperty('--brightness', '100%');
            root.style.setProperty('--contrast', '100%');
            root.style.setProperty('--saturate', '100%');
            root.style.setProperty('--sepia', '0%');
            root.style.setProperty('--grayscale', '0%');
            scene?.classList.add('no-scene-filter');
        } else {
            root.style.setProperty('--brightness', `${b}%`);
            root.style.setProperty('--contrast', `${c}%`);
            root.style.setProperty('--saturate', `${sat}%`);
            root.style.setProperty('--sepia', `${se}%`);
            root.style.setProperty('--grayscale', `${g}%`);
            scene?.classList.remove('no-scene-filter');
        }

        // Display cap only affects free-placed stage max size; locked = always full screen
        const maxH = parseInt(cfg.maxDisplayHeight, 10) || 0;
        if (maxH > 0) {
            root.style.setProperty('--video-max-h', `${maxH}px`);
            root.style.setProperty('--video-max-w', `${Math.round(maxH * 21 / 9)}px`);
        } else {
            root.style.setProperty('--video-max-h', '100%');
            root.style.setProperty('--video-max-w', '100%');
        }
        // Video stays locked inside the stage; re-apply fit + stage geometry
        if (cfg.layout === 'cinema') {
            try { applyCinemaObjectFit(cinemaMediaEl() || mainVideo, objectFitFromConfig()); } catch (_) {}
        }
        try { applyVideoStageLayout(); } catch (_) {}
        body.classList.toggle('perf-mode', !!cfg.performanceMode);
        
        // Borders & Layout (video/media)
        root.style.setProperty('--border-size', `${cfg.borderSize}px`);
        root.style.setProperty('--border-color', cfg.borderColor);
        root.style.setProperty('--border-glow', `${cfg.borderGlow}px`);
        // Independent full-window screen frame
        applyScreenFrame();
        if (cfg.layout === 'grid') applyGridDimensions();
        else {
            root.style.setProperty('--grid-cols', cfg.gridCols);
            root.style.setProperty('--grid-rows', cfg.gridRows);
        }
        
        // Reflections (Convert 0-100 to 0.0-1.0)
        root.style.setProperty('--reflect-op', `${cfg.reflectOpacity / 100}`);
        root.style.setProperty('--reflect-off', `${cfg.reflectOffset}px`);
    }

    /** Full-window frame around the browser content — not the video media border. */
    function applyScreenFrame() {
        const el = document.getElementById('fafo-screen-frame');
        const root = document.documentElement;
        const on = !!cfg.screenFrameEnabled && (Number(cfg.screenFrameSize) || 0) > 0;
        const size = Math.max(0, Math.min(48, Number(cfg.screenFrameSize) || 0));
        const glow = Math.max(0, Math.min(80, Number(cfg.screenFrameGlow) || 0));
        const opacity = Math.max(0, Math.min(1, Number(cfg.screenFrameOpacity) ?? 0.9));
        const radius = Math.max(0, Math.min(40, Number(cfg.screenFrameRadius) || 0));
        const color = cfg.screenFrameColor || '#00e5ff';
        const style = ['solid', 'double', 'dashed', 'glow', 'corners'].includes(cfg.screenFrameStyle)
            ? cfg.screenFrameStyle
            : 'solid';
        root.style.setProperty('--screen-frame-size', on ? `${size}px` : '0px');
        root.style.setProperty('--screen-frame-color', color);
        root.style.setProperty('--screen-frame-glow', `${glow}px`);
        root.style.setProperty('--screen-frame-opacity', String(opacity));
        root.style.setProperty('--screen-frame-radius', `${radius}px`);
        root.style.setProperty('--screen-frame-corner', `${Math.max(24, size * 12)}px`);
        if (!el) return;
        el.classList.toggle('is-off', !on);
        el.dataset.off = on ? '0' : '1';
        el.classList.remove('style-solid', 'style-double', 'style-dashed', 'style-glow', 'style-corners');
        el.classList.add(`style-${style}`);
    }

    function applyVideoGpuHints(videoEl) {
        if (!videoEl) return;
        try { videoEl.disablePictureInPicture = false; } catch (_) {}
        try { videoEl.disableRemotePlayback = true; } catch (_) {}
        videoEl.setAttribute('playsinline', '');
        videoEl.setAttribute('webkit-playsinline', '');
        videoEl.playsInline = true;
        // Decode the file at native quality; layout (below) picks the on-screen size.
        try { videoEl.preload = 'auto'; } catch (_) {}
        videoEl.style.backfaceVisibility = 'hidden';
        // Permanent will-change keeps an extra compositor layer — only while zooming.
        videoEl.style.removeProperty('will-change');
    }

    // --- VIDEO STAGE: locked to screen OR free-placeable window ---
    // Fit-to-screen sizes the MEDIA (whole frame, correct aspect) into the stage.
    // Wheel zoom then scales that full frame — never a pre-cropped window.
    let videoStageLocked = true;
    let videoStageX = 40;
    let videoStageY = 40;
    /** Where the picture sits in its frame. 0.5, 0.5 is center. Drag the video to move it. */
    let videoSpawnX = 0.5;
    let videoSpawnY = 0.5;
    /** Pixel nudge of the Left / Right / Under video frame after you drag it. */
    let stageNudgeX = 0;
    let stageNudgeY = 0;
    let suppressPauseClick = false;
    let videoStageW = 0;
    let videoStageH = 0;
    let videoStageDragging = false;
    let videoStageResizing = false;
    let videoStageSaveTimer = null;
    let videoStageInteractBound = false;
    /**
     * Video content zoom relative to the fitted whole-frame size.
     * 1 = entire image/video visible (contain). >1 zooms into that full frame.
     */
    const DEFAULT_VIDEO_ZOOM = 1;
    let videoZoom = DEFAULT_VIDEO_ZOOM;
    const VIDEO_ZOOM_MIN = 0.25;
    const VIDEO_ZOOM_MAX = 4;
    const VIDEO_ZOOM_STEP = 0.1;
    /** Independent chrome scale (HUD + clock + tags). Default 100% under non-100% browser zoom. */
    const DEFAULT_CHROME_SCALE = 1;
    let chromeScale = DEFAULT_CHROME_SCALE;
    const CHROME_SCALE_MIN = 0.25;
    const CHROME_SCALE_MAX = 4;
    const CHROME_SCALE_STEP = 0.05;
    let pointerOverVideo = false;
    let scaleToastTimer = null;
    let cinemaResizeObs = null;

    function objectFitFromConfig() {
        const scaleMode = currentScaleMode();
        if (scaleMode === 'scale-cover' || scaleMode === 'cover') return 'cover';
        if (scaleMode === 'scale-center') return 'none';
        if (scaleMode === 'scale-capped') return 'capped';
        return 'contain';
    }

    function currentScaleMode() {
        try {
            const fileName = playlist[currentIdx]?.handle?.name
                || (playlist[currentIdx]?.url ? playlist[currentIdx].url.split('/').pop() : '');
            const overrides = (fileName && cfg.overrides?.[fileName]) || {};
            return overrides.scaling || cfg.scaling || 'scale-contain';
        } catch {
            return cfg.scaling || 'scale-contain';
        }
    }

    function mediaIntrinsicSize(el) {
        if (!el) return { w: 0, h: 0 };
        if (el.tagName === 'VIDEO') {
            return { w: el.videoWidth || 0, h: el.videoHeight || 0 };
        }
        return { w: el.naturalWidth || 0, h: el.naturalHeight || 0 };
    }

    function containSize(srcW, srcH, boxW, boxH) {
        if (!(srcW > 0 && srcH > 0 && boxW > 0 && boxH > 0)) return { w: boxW, h: boxH };
        const s = Math.min(boxW / srcW, boxH / srcH);
        return { w: srcW * s, h: srcH * s };
    }

    function coverSize(srcW, srcH, boxW, boxH) {
        if (!(srcW > 0 && srcH > 0 && boxW > 0 && boxH > 0)) return { w: boxW, h: boxH };
        const s = Math.max(boxW / srcW, boxH / srcH);
        return { w: srcW * s, h: srcH * s };
    }

    function readPadPx(host, name, fallback) {
        try {
            const raw = getComputedStyle(host).getPropertyValue(name).trim();
            const n = parseFloat(raw);
            if (Number.isFinite(n)) return n;
        } catch (_) {}
        return fallback;
    }

    function stageContentBox(stage) {
        const sw = Math.max(1, stage?.clientWidth || window.innerWidth || 800);
        const sh = Math.max(1, stage?.clientHeight || window.innerHeight || 600);
        const free = !!stage?.classList?.contains('stage-free');
        const host = stage || document.documentElement;
        const padT = readPadPx(host, '--video-pad-top', free ? 12 : 28);
        const padX = readPadPx(host, '--video-pad-x', free ? 10 : 18);
        const padB = readPadPx(host, '--video-pad-bottom', free ? 12 : 20);
        return {
            padT, padX, padB,
            boxW: Math.max(1, sw - padX * 2),
            boxH: Math.max(1, sh - padT - padB),
        };
    }

    /**
     * Size the media element to the WHOLE frame (correct aspect), then apply zoom.
     * At zoom=1 + contain: every pixel of the source is visible (letterbox if needed).
     * Wheel zoom scales that full frame; the stage clips only when zoomed in.
     * Never stretch the element to the window and object-fit-crop first — that was the bug.
     */
    function layoutMediaIntoBox(el, boxW, boxH, zoom, fitMode, originX, originY) {
        if (!el) return;
        const z = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, Number(zoom) || 1));
        const { w: iw, h: ih } = mediaIntrinsicSize(el);
        const maxH = parseInt(cfg.maxDisplayHeight, 10) || 0;

        let baseW;
        let baseH;
        const mode = fitMode || 'contain';

        if (!(iw > 0 && ih > 0)) {
            // No intrinsic size yet. height:auto on an absolute video is 0px
            // (audio can already be playing). Fill the box until dimensions arrive.
            const w = Math.max(1, Math.round(boxW));
            const h = Math.max(1, Math.round(boxH));
            el.style.setProperty('position', 'absolute', 'important');
            el.style.setProperty('width', w + 'px', 'important');
            el.style.setProperty('height', h + 'px', 'important');
            el.style.setProperty('max-width', 'none', 'important');
            el.style.setProperty('max-height', 'none', 'important');
            el.style.setProperty('left', originX + 'px', 'important');
            el.style.setProperty('top', originY + 'px', 'important');
            el.style.setProperty('right', 'auto', 'important');
            el.style.setProperty('bottom', 'auto', 'important');
            el.style.setProperty('object-fit', 'contain', 'important');
            el.style.setProperty('object-position', 'center center', 'important');
            el.style.setProperty('transform', 'none', 'important');
            el.style.setProperty('transform-origin', 'center center', 'important');
            el.style.setProperty('margin', '0', 'important');
            return;
        }

        if (mode === 'cover') {
            const c = coverSize(iw, ih, boxW, boxH);
            baseW = c.w;
            baseH = c.h;
        } else if (mode === 'none') {
            baseW = iw;
            baseH = ih;
        } else if (mode === 'capped') {
            const c = containSize(iw, ih, boxW, boxH);
            // Never upscale past native pixels (and honor optional display cap).
            const capW = maxH > 0 ? Math.min(iw, Math.round(maxH * (iw / ih))) : iw;
            const capH = maxH > 0 ? Math.min(ih, maxH) : ih;
            const s = Math.min(1, c.w / iw, capW / iw, capH / ih);
            baseW = iw * s;
            baseH = ih * s;
        } else {
            // contain = fit WHOLE frame to the stage. Pixel-cap belongs to scale-capped
            // only — applying it here letterboxed 4K on a 4K TV and looked like a crop.
            const c = containSize(iw, ih, boxW, boxH);
            baseW = c.w;
            baseH = c.h;
        }

        const w = Math.max(1, Math.round(baseW * z));
        const h = Math.max(1, Math.round(w * (ih / iw)));
        const ax = Math.max(0, Math.min(1, Number(videoSpawnX)));
        const ay = Math.max(0, Math.min(1, Number(videoSpawnY)));
        const left = originX + (boxW - w) * (Number.isFinite(ax) ? ax : 0.5);
        const top = originY + (boxH - h) * (Number.isFinite(ay) ? ay : 0.5);

        el.style.setProperty('position', 'absolute', 'important');
        el.style.setProperty('width', w + 'px', 'important');
        el.style.setProperty('height', h + 'px', 'important');
        el.style.setProperty('max-width', 'none', 'important');
        el.style.setProperty('max-height', 'none', 'important');
        el.style.setProperty('left', left + 'px', 'important');
        el.style.setProperty('top', top + 'px', 'important');
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');
        el.style.setProperty('margin', '0', 'important');
        // Element already matches the media aspect — fill it, don't recrop.
        el.style.setProperty('object-fit', 'fill', 'important');
        el.style.setProperty('object-position', 'center center', 'important');
        el.style.setProperty('transform-origin', 'center center', 'important');
        // Ken Burns (photos at 100% zoom) animates transform; don't kill it.
        if (el.classList.contains('ken-burns') && Math.abs(z - 1) < 0.02) {
            el.style.removeProperty('transform');
        } else {
            el.style.setProperty('transform', 'none', 'important');
        }
        el.style.setProperty('box-sizing', 'border-box', 'important');
        el.style.removeProperty('will-change');
    }

    function ensureCinemaPhotoEl(stage) {
        if (!stage) return null;
        let img = stage.querySelector('#bg-photo');
        if (!img) {
            img = document.createElement('img');
            img.id = 'bg-photo';
            img.className = 'is-photo';
            img.alt = '';
            img.decoding = 'async';
            img.setAttribute('decoding', 'async');
            try { img.fetchPriority = 'high'; } catch (_) {}
            img.draggable = false;
            stage.appendChild(img);
            img.addEventListener('load', () => {
                try { applyVideoZoom(); } catch (_) {}
            });
        }
        return img;
    }

    function cinemaMediaEl() {
        const stage = scene?.querySelector('.cinema-stage') || document.querySelector('.cinema-stage');
        const photo = stage?.querySelector('#bg-photo');
        if (photo && photo.style.display !== 'none' && (photo.currentSrc || photo.src)) return photo;
        return mainVideo
            || stage?.querySelector?.('#bg-video')
            || document.getElementById('bg-video')
            || stage?.querySelector?.('video, img.is-photo, img');
    }

    function watchCinemaStageSize(stage) {
        if (!stage || typeof ResizeObserver === 'undefined') return;
        if (cinemaResizeObs && cinemaResizeObs._stage === stage) return;
        if (cinemaResizeObs) {
            try { cinemaResizeObs.disconnect(); } catch (_) {}
        }
        let raf = 0;
        cinemaResizeObs = new ResizeObserver(() => {
            if (raf) return;
            raf = requestAnimationFrame(() => {
                raf = 0;
                try { applyVideoZoom(); } catch (_) {}
            });
        });
        cinemaResizeObs._stage = stage;
        cinemaResizeObs.observe(stage);
    }

    /**
     * Video fills the stage by laying out the whole frame (contain) unless cover/1:1.
     * Zoom is a scale of that full frame — slider / wheel never crop-then-scale.
     */
    function applyCinemaObjectFit(videoEl, objectFit) {
        if (!videoEl) return;
        const fit = objectFit || objectFitFromConfig() || 'contain';
        videoEl.classList.remove('fit-cover', 'fit-none', 'is-capped');
        scene?.classList.remove('fit-cover', 'fit-none');

        try {
            videoEl.style.removeProperty('--vw-display');
            videoEl.style.removeProperty('--vh-display');
        } catch (_) {}

        if (fit === 'cover') {
            videoEl.classList.add('fit-cover');
            scene?.classList.add('fit-cover');
        } else if (fit === 'none') {
            videoEl.classList.add('fit-none');
            scene?.classList.add('fit-none');
        } else if (fit === 'capped') {
            videoEl.classList.add('is-capped');
        }
        try { applyVideoZoom(); } catch (_) {}
    }

    function scheduleVideoStageSave() {
        clearTimeout(videoStageSaveTimer);
        videoStageSaveTimer = setTimeout(() => {
            chrome.storage.local.set({
                fafoVideoStage: {
                    locked: videoStageLocked,
                    x: videoStageX,
                    y: videoStageY,
                    w: videoStageW,
                    h: videoStageH,
                    zoom: videoZoom,
                    spawnX: videoSpawnX,
                    spawnY: videoSpawnY,
                },
                fafoChromeScale: chromeScale,
            }).catch(() => {});
        }, 200);
    }

    function showScaleToast(msg) {
        let el = document.getElementById('fafo-scale-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'fafo-scale-toast';
            el.className = 'fafo-scale-toast';
            document.body.appendChild(el);
        }
        el.textContent = msg;
        el.classList.add('show');
        clearTimeout(scaleToastTimer);
        scaleToastTimer = setTimeout(() => el.classList.remove('show'), 900);
    }

    /**
     * Store zoom CSS var for wall tiles / badges. Cinema layout uses pixel size, not transform.
     */
    function applyVideoContentZoomVars(host, zoom) {
        if (!host) return;
        const z = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, zoom || 1));
        host.style.setProperty('--video-zoom', String(z));
        try { document.documentElement.style.setProperty('--video-zoom', String(z)); } catch (_) {}
    }

    /**
     * Live zoom on the currently playing video/photo.
     * Fit-to-screen: whole frame visible. Wheel/slider then scale that full frame.
     */
    function applyVideoZoom() {
        const z = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, Number(videoZoom) || DEFAULT_VIDEO_ZOOM));
        videoZoom = Math.round(z * 1000) / 1000;
        const pctLabel = Math.round(videoZoom * 100) + '%';
        document.documentElement.style.setProperty('--video-zoom', String(videoZoom));

        if (wallModeActive) {
            applyWallVideoZoom();
            return;
        }

        const stage = scene?.querySelector('.cinema-stage') || document.querySelector('.cinema-stage');
        const v = cinemaMediaEl();

        if (stage) {
            stage.dataset.videoZoom = String(videoZoom);
            stage.dataset.videoZoomLabel = 'VIDEO ' + pctLabel;
            stage.style.setProperty('overflow', 'hidden', 'important');
            applyVideoContentZoomVars(stage, videoZoom);
            stage.classList.toggle('video-zoomed', Math.abs(videoZoom - 1) > 0.005);
            watchCinemaStageSize(stage);
        }

        if (v && stage) {
            const { padT, padX, padB, boxW, boxH } = stageContentBox(stage);
            v.style.setProperty('--video-pad-top', padT + 'px');
            v.style.setProperty('--video-pad-x', padX + 'px');
            v.style.setProperty('--video-pad-bottom', padB + 'px');
            const fit = objectFitFromConfig() || 'contain';
            layoutMediaIntoBox(v, boxW, boxH, videoZoom, fit, padX, padT);
            applyVideoContentZoomVars(v, videoZoom);
            // Ken Burns fights zoom transforms — only at a true fit.
            if (Math.abs(videoZoom - 1) > 0.02) v.classList.remove('ken-burns');
        }

        const zoomBadge = stage?.querySelector?.('.cinema-stage-zoom');
        if (zoomBadge) zoomBadge.textContent = pctLabel;

        try {
            const s = document.getElementById('meta-slider-video');
            const lab = document.getElementById('meta-slider-video-val');
            const sliderActive = s && (document.activeElement === s || s.matches?.(':active'));
            if (s && !sliderActive) s.value = String(Math.round(videoZoom * 100));
            if (lab) lab.textContent = pctLabel;
        } catch (_) {}
    }

    function setVideoZoom(z, opts = {}) {
        const fallback = DEFAULT_VIDEO_ZOOM;
        const next = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX,
            Number.isFinite(Number(z)) ? Number(z) : fallback));
        videoZoom = next;
        // Apply immediately to the CURRENT frame — do not wait for layout rebuild
        applyVideoZoom();
        // Free window: optional grow/shrink of the floating stage only when asked
        if (!videoStageLocked && opts.resizeFree === true) {
            const prev = Math.max(0.01, Number(opts.prevZoom) || fallback);
            if (!videoStageW || !videoStageH) {
                videoStageW = Math.round((window.innerWidth || 800) * DEFAULT_VIDEO_ZOOM);
                videoStageH = Math.round((window.innerHeight || 600) * DEFAULT_VIDEO_ZOOM);
                videoStageX = Math.round(((window.innerWidth || 800) - videoStageW) / 2);
                videoStageY = Math.round(((window.innerHeight || 600) - videoStageH) / 2);
            }
            const ratio = next / prev;
            const cx = videoStageX + videoStageW / 2;
            const cy = videoStageY + videoStageH / 2;
            const nw = Math.round(videoStageW * ratio);
            const nh = Math.round(videoStageH * ratio);
            const r = clampVideoStageRect(cx - nw / 2, cy - nh / 2, nw, nh);
            videoStageX = r.x;
            videoStageY = r.y;
            videoStageW = r.w;
            videoStageH = r.h;
            try { applyVideoStageLayout(); } catch (_) {}
            // Re-apply zoom after layout (layout may touch the video node)
            applyVideoZoom();
        }
        // Re-assert after layout/fit handlers that may run in the same turn
        requestAnimationFrame(() => {
            try { applyVideoZoom(); } catch (_) {}
        });
        scheduleVideoStageSave();
        // Slider: toast only when explicitly true (release). Wheel/UI: toast unless toast:false.
        const showToast = opts.fromSlider ? opts.toast === true : opts.toast !== false;
        if (showToast) showScaleToast(`Video · ${Math.round(videoZoom * 100)}%`);
        try { revealPlayerChrome(); } catch (_) {}
    }

    /** Top chips, Disk pip, and the video-size bubble leave after the HUD idle delay. */
    function revealPlayerChrome() {
        document.body.classList.remove('fafo-chrome-idle');
        clearTimeout(playerChromeTimer);
        const idleMs = Math.max(1500, Math.min(20000, Number(cfg.hudIdleMs) || HUD_IDLE_MS));
        playerChromeTimer = setTimeout(() => {
            const busy = document.querySelector(
                '.cinema-stage.stage-dragging, .cinema-stage.stage-resizing, #fafo-status-chips:hover, #fafo-corner:hover, #fafo-corner-menu:not([hidden]), .cinema-stage-chrome:hover'
            );
            if (busy) {
                revealPlayerChrome();
                return;
            }
            document.body.classList.add('fafo-chrome-idle');
        }, idleMs);
    }

    function nudgeVideoZoom(dir) {
        const factor = dir < 0 ? (1 - VIDEO_ZOOM_STEP) : (1 + VIDEO_ZOOM_STEP);
        setVideoZoom((videoZoom || DEFAULT_VIDEO_ZOOM) * factor);
    }

    /** UI/chrome scale only — never touches the video stage. Default 80%. */
    function applyChromeScale() {
        const s = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));
        chromeScale = Math.round(s * 100) / 100;
        document.documentElement.style.setProperty('--fafo-chrome-scale', String(chromeScale));
        document.body?.style.setProperty('--fafo-chrome-scale', String(chromeScale));
        document.documentElement.style.setProperty('--meta-ui-scale', String(chromeScale));
        document.body?.style.setProperty('--meta-ui-scale', String(chromeScale));
        document.getElementById('meta-library-panel')?.style.setProperty('--meta-ui-scale', String(chromeScale));
        try {
            // Meta panels reclamp inside setUiScale — prevents scale from pushing off-screen
            window.FAFOMeta?.setUiScale?.(chromeScale, { fromChrome: true });
        } catch (_) {}
        const dockEl = document.getElementById('meta-dock');
        if (dockEl) dockEl.style.setProperty('--meta-ui-scale', String(chromeScale));
        const hudEl = document.getElementById('player-hud');
        if (hudEl) {
            hudEl.style.setProperty('--fafo-chrome-scale', String(chromeScale));
            hudEl.style.setProperty('transform', `scale(${chromeScale})`, 'important');
            hudEl.style.setProperty('transform-origin', 'top left', 'important');
        }
        const clock = document.getElementById('ui-container');
        if (clock) {
            clock.style.setProperty('--fafo-chrome-scale', String(chromeScale));
            // Keep clock fully on-screen: bottom-left origin, clamp via max size if needed
            clock.style.setProperty('transform', `scale(${chromeScale})`, 'important');
            clock.style.setProperty('transform-origin', 'bottom left', 'important');
            clock.style.maxWidth = 'min(96vw, 100%)';
            clock.style.maxHeight = 'min(40vh, 100%)';
        }
        // Always reclamp player chrome after scale (HUD + free video)
        try { reclampAllPlayerChromeAfterScale(); } catch (_) {
            try { if (hud?.box) placeHudAt(hudX, hudY); } catch (_) {}
            try { if (!videoStageLocked) applyVideoStageLayout(); } catch (_) {}
        }
        // Wall grid must reflow live when UI/window scale changes (if enabled)
        if (wallModeActive && wallPrefs.liveReflow) {
            try { reflowWallLayout({ skipRebuild: true }); } catch (_) {}
        }
    }

    function setChromeScale(s, opts = {}) {
        const n = Number(s);
        chromeScale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX,
            Number.isFinite(n) ? n : DEFAULT_CHROME_SCALE));
        applyChromeScale();
        scheduleVideoStageSave();
        if (opts.toast !== false) showScaleToast(`UI · ${Math.round(chromeScale * 100)}%`);
    }

    function nudgeChromeScale(dir) {
        const factor = dir < 0 ? (1 - CHROME_SCALE_STEP) : (1 + CHROME_SCALE_STEP);
        setChromeScale((chromeScale || DEFAULT_CHROME_SCALE) * factor);
    }

    /** True if element (or ancestor) is a scrollable field the user can wheel-scroll. */
    function isScrollableField(el) {
        let n = el;
        for (let i = 0; n && i < 12; i++, n = n.parentElement) {
            if (!n || n === document.body || n === document.documentElement) break;
            if (n.classList?.contains('fafo-scrollable')) return true;
            if (n.classList?.contains('meta-ctx-menu') || n.classList?.contains('meta-ctx-menu-wide')) return true;
            if (n.classList?.contains('meta-ctx-slot-tiles') || n.classList?.contains('meta-ctx-slot-editor')) return true;
            if (n.id === 'meta-tag-library' || n.id === 'meta-dock' || n.id === 'meta-panel') return true;
            if (n.classList?.contains('meta-library') || n.classList?.contains('meta-panel-body')) return true;
            if (n.tagName === 'TEXTAREA' || n.tagName === 'SELECT' || (n.tagName === 'INPUT' && n.type === 'text')) return true;
            try {
                const st = getComputedStyle(n);
                const oy = st.overflowY;
                const ox = st.overflowX;
                const canY = (oy === 'auto' || oy === 'scroll' || oy === 'overlay') && n.scrollHeight > n.clientHeight + 1;
                const canX = (ox === 'auto' || ox === 'scroll' || ox === 'overlay') && n.scrollWidth > n.clientWidth + 1;
                if (canY || canX) return true;
            } catch (_) {}
        }
        return false;
    }

    /** True if pointer is over the cinema video stage (not HUD/tags). Uses geometry, not only event.target. */
    function isPointOverVideoStage(clientX, clientY) {
        if (clientX == null || clientY == null) return !!pointerOverVideo;
        // Exclude chrome overlays first
        const stack = document.elementsFromPoint?.(clientX, clientY) || [];
        for (const el of stack) {
            if (!el || !el.closest) continue;
            if (el.closest('#meta-dock') || el.closest('.player-hud') || el.closest('#ui-container')) return false;
            if (el.closest('#playlist-pick') || el.closest('#shortcut-help') || el.closest('#empty-state')) return false;
            if (el.closest('.meta-ctx-menu') || el.closest('.fafo-cmd-palette') || el.closest('.fafo-knowledge-guide')) return false;
            if (el.closest('.cinema-stage') || el.id === 'bg-video' || el.id === 'bg-photo' || el.closest('#bg-video') || el.closest('#bg-photo')) return true;
        }
        const stage = scene?.querySelector?.('.cinema-stage') || document.querySelector('.cinema-stage');
        const video = mainVideo || document.getElementById('bg-video');
        const hit = (el) => {
            if (!el) return false;
            const r = el.getBoundingClientRect();
            return clientX >= r.left && clientX <= r.right && clientY >= r.top && clientY <= r.bottom;
        };
        return hit(stage) || hit(video);
    }

    function isEventOverVideo(e) {
        // Never treat scrollable UI as "video" for wheel purposes
        if (e?.target && isScrollableField(e.target)) return false;
        if (e && (e.clientX != null || e.clientY != null)) {
            return isPointOverVideoStage(e.clientX, e.clientY);
        }
        const t = e?.target;
        if (!t || !t.closest) return pointerOverVideo;
        if (t.closest('#meta-dock') || t.closest('.player-hud') || t.closest('#ui-container')) return false;
        if (t.closest('.meta-ctx-menu') || t.closest('.fafo-cmd-palette')) return false;
        if (t.closest('.cinema-stage') || t.closest('#bg-video') || t.closest('#bg-photo') || t.id === 'bg-video' || t.id === 'bg-photo') return true;
        return false;
    }

    function initIndependentScaleControls() {
        // Track hover over video stage (geometry-based)
        document.addEventListener('pointermove', (e) => {
            pointerOverVideo = isPointOverVideoStage(e.clientX, e.clientY);
            document.body.classList.toggle('fafo-over-video', pointerOverVideo);
            revealPlayerChrome();
        }, { passive: true, capture: true });
        document.addEventListener('keydown', () => revealPlayerChrome(), { passive: true });
        revealPlayerChrome();

        // Wheel over video → video zoom only (always when pointer is on stage).
        // Hovering a scrollable field → native scroll (do not steal the wheel).
        // Ctrl/Cmd+wheel elsewhere → UI chrome scale only (never browser page zoom).
        // Also: plain wheel anywhere with Alt = video zoom (fallback if hit-test fails).
        document.addEventListener('wheel', (e) => {
            // Priority: scrollable UI panels / color tiles / tag lists
            if (e.target && isScrollableField(e.target) && !e.altKey) {
                // Let the browser scroll this field; still block ctrl-zoom on page
                if (e.ctrlKey || e.metaKey) {
                    e.preventDefault();
                    e.stopPropagation();
                    nudgeChromeScale(e.deltaY > 0 ? -1 : 1);
                }
                return;
            }
            const overVideo = isEventOverVideo(e) || e.altKey;
            if (overVideo) {
                e.preventDefault();
                e.stopPropagation();
                nudgeVideoZoom(e.deltaY > 0 ? -1 : 1);
                return;
            }
            if (e.ctrlKey || e.metaKey) {
                e.preventDefault();
                e.stopPropagation();
                nudgeChromeScale(e.deltaY > 0 ? -1 : 1);
            }
        }, { passive: false, capture: true });

        // Ctrl + / - / 0 — video if pointer over it, else UI
        document.addEventListener('keydown', (e) => {
            if (e.target?.tagName === 'INPUT' || e.target?.tagName === 'TEXTAREA' || e.target?.isContentEditable) return;
            if (!(e.ctrlKey || e.metaKey)) return;
            const key = e.key;
            const isPlus = key === '+' || key === '=' || e.code === 'Equal' || e.code === 'NumpadAdd';
            const isMinus = key === '-' || key === '_' || e.code === 'Minus' || e.code === 'NumpadSubtract';
            const isZero = key === '0' || e.code === 'Digit0' || e.code === 'Numpad0';
            if (!isPlus && !isMinus && !isZero) return;
            e.preventDefault();
            e.stopPropagation();
            const overVideo = pointerOverVideo || isEventOverVideo(e) || e.altKey;
            if (isZero) {
                // Reset to 100% (whole frame)
                if (overVideo) setVideoZoom(DEFAULT_VIDEO_ZOOM);
                else setChromeScale(DEFAULT_CHROME_SCALE);
                return;
            }
            if (overVideo) nudgeVideoZoom(isPlus ? 1 : -1);
            else nudgeChromeScale(isPlus ? 1 : -1);
        }, true);

        // Options page sliders write fafoChromeScale / fafoVideoStage.zoom — apply live
        chrome.storage.onChanged.addListener((changes, area) => {
            if (area !== 'local') return;
            if (changes.fafoChromeScale && typeof changes.fafoChromeScale.newValue === 'number') {
                const n = changes.fafoChromeScale.newValue;
                if (n > 0 && Math.abs(n - chromeScale) > 0.001) {
                    chromeScale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, n));
                    applyChromeScale();
                }
            } else if (changes.fafoMetaUiScale && typeof changes.fafoMetaUiScale.newValue === 'number') {
                const n = changes.fafoMetaUiScale.newValue;
                if (n > 0 && Math.abs(n - chromeScale) > 0.001) {
                    chromeScale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, n));
                    applyChromeScale();
                }
            }
            if (changes.fafoVideoStage?.newValue && typeof changes.fafoVideoStage.newValue === 'object') {
                const st = changes.fafoVideoStage.newValue;
                // Ignore echo while user is dragging the video slider
                const vSlider = document.getElementById('meta-slider-video');
                const sliderActive = vSlider
                    && (document.activeElement === vSlider || vSlider.matches?.(':active'));
                if (!sliderActive && typeof st.zoom === 'number' && st.zoom > 0
                    && Math.abs(st.zoom - videoZoom) > 0.001) {
                    videoZoom = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, st.zoom));
                    applyVideoZoom();
                }
                if (typeof st.locked === 'boolean' && st.locked !== videoStageLocked) {
                    videoStageLocked = st.locked;
                    applyVideoStageLayout();
                }
                if (typeof st.x === 'number') videoStageX = st.x;
                if (typeof st.y === 'number') videoStageY = st.y;
                if (typeof st.w === 'number' && st.w > 0) videoStageW = st.w;
                if (typeof st.h === 'number' && st.h > 0) videoStageH = st.h;
                if (!videoStageLocked && !sliderActive) applyVideoStageLayout();
            }
        });
    }

    /** Keep free video stage fully inside the window (uses FAFOViewport when available). */
    function clampVideoStageRect(x, y, w, h) {
        const vp = window.FAFOViewport?.viewportBox?.() || {
            width: window.innerWidth || 800,
            height: window.innerHeight || 600,
        };
        const margin = 4;
        const minW = Math.min(240, vp.width - margin * 2);
        const minH = Math.min(160, vp.height - margin * 2);
        const maxW = Math.max(minW, vp.width - margin * 2);
        const maxH = Math.max(minH, vp.height - margin * 2);
        w = Math.max(minW, Math.min(maxW, Math.round(w || vp.width * DEFAULT_VIDEO_ZOOM)));
        h = Math.max(minH, Math.min(maxH, Math.round(h || vp.height * DEFAULT_VIDEO_ZOOM)));
        if (window.FAFOViewport?.clampPoint) {
            const c = window.FAFOViewport.clampPoint(x, y, w, h, 1, margin);
            return { x: c.x, y: c.y, w, h };
        }
        const maxX = Math.max(margin, vp.width - w - margin);
        const maxY = Math.max(margin, vp.height - h - margin);
        x = Math.round(Math.max(margin, Math.min(maxX, Number(x) || 0)));
        y = Math.round(Math.max(margin, Math.min(maxY, Number(y) || 0)));
        return { x, y, w, h };
    }

    /** Apply free-stage coords then lock painted box to the real window. */
    function lockVideoStageToWindow() {
        const stage = scene?.querySelector('.cinema-stage');
        if (!stage || videoStageLocked) return;
        stage.style.left = videoStageX + 'px';
        stage.style.top = videoStageY + 'px';
        stage.style.width = videoStageW + 'px';
        stage.style.height = videoStageH + 'px';
        const locked = window.FAFOViewport?.lock?.(stage, {
            margin: 4, canResize: true, minW: 240, minH: 160,
        });
        if (locked) {
            videoStageX = locked.x;
            videoStageY = locked.y;
            videoStageW = locked.w;
            videoStageH = locked.h;
        }
    }

    /**
     * Pin locked stage to the browser content area at any page zoom (TV 50–80% included).
     * Scene = position:fixed; inset:0 (no transform — transform would trap fixed kids).
     * Stage = absolute; inset:0 inside scene (safe when scene has CSS filters).
     * Video = whole frame laid out inside the stage, then zoomed.
     * Truly centered. Do not stretch to 100%×100% and object-fit-crop.
     */
    function pinStageToRect(stage, rect) {
        if (!stage || !rect) return;
        if (scene) {
            scene.classList.add('layout-cinema');
            [
                ['position', 'fixed'], ['inset', '0'], ['left', '0'], ['top', '0'],
                ['right', '0'], ['bottom', '0'], ['width', 'auto'], ['height', 'auto'],
                ['max-width', 'none'], ['max-height', 'none'], ['margin', '0'],
                ['transform', 'none'], ['perspective', 'none'],
            ].forEach(([k, v]) => scene.style.setProperty(k, v, 'important'));
        }
        stage.classList.add('stage-locked');
        stage.classList.remove('stage-free');
        [
            ['position', 'fixed'], ['inset', 'auto'],
            ['left', rect.x + 'px'], ['top', rect.y + 'px'],
            ['width', rect.w + 'px'], ['height', rect.h + 'px'],
            ['right', 'auto'], ['bottom', 'auto'],
            ['max-width', 'none'], ['max-height', 'none'], ['margin', '0'],
            ['transform', 'none'],
        ].forEach(([k, v]) => stage.style.setProperty(k, v, 'important'));
        applyVideoContentZoomVars(stage, videoZoom || 1);
    }

    function pinLockedStageToBrowserViewport(stage) {
        if (!stage) return;
        const frames = stageLayoutFrames();
        if (frames?.video) {
            pinStageToRect(stage, frames.video);
            return;
        }
        if (scene) {
            scene.classList.add('layout-cinema');
            [
                ['position', 'fixed'], ['inset', '0'], ['left', '0'], ['top', '0'],
                ['right', '0'], ['bottom', '0'], ['width', 'auto'], ['height', 'auto'],
                ['max-width', 'none'], ['max-height', 'none'], ['margin', '0'],
                // Critical: no transform on scene — would break viewport binding under zoom
                ['transform', 'none'], ['perspective', 'none'],
            ].forEach(([k, v]) => scene.style.setProperty(k, v, 'important'));
        }
        stage.classList.add('stage-locked');
        stage.classList.remove('stage-free');
        [
            // absolute fills fixed scene (= browser content box at any Ctrl+/- zoom)
            ['position', 'absolute'], ['inset', '0'], ['left', '0'], ['top', '0'],
            ['right', '0'], ['bottom', '0'], ['width', 'auto'], ['height', 'auto'],
            ['max-width', 'none'], ['max-height', 'none'], ['margin', '0'],
            ['transform', 'none'], ['border', 'none'], ['border-radius', '0'],
        ].forEach(([k, v]) => stage.style.setProperty(k, v, 'important'));
        applyVideoContentZoomVars(stage, videoZoom || 1);
    }

    function applyVideoStageLayout() {
        const frames = stageLayoutFrames();
        if (frames) {
            stageFrameApplied = true;
            const placed = framesWithNudge(frames);
            const stage = scene?.querySelector('.cinema-stage');
            if (stage) {
                pinStageToRect(stage, placed.video);
                const lockBtn = stage.querySelector('.cinema-stage-lock');
                const label = stage.querySelector('.cinema-stage-label');
                if (lockBtn) {
                    lockBtn.textContent = 'Place';
                    lockBtn.title = 'Drag this bar to move the video frame. Drag the picture to set where it spawns.';
                }
                if (label) {
                    const name = STAGE_LAYOUT_LABEL[stageLayoutMode] || 'Layout';
                    const wide = STAGE_WIDTH_LABEL[stageVideoWidth] || 'Wide';
                    label.textContent = `Video · ${name} · ${wide}`;
                }
                try { applyVideoZoom(); } catch (_) {}
            }
            applyStageHud(placed);
            try { window.FAFOMeta?.pinDockForStage?.(placed.panel || null); } catch (_) {}
            updateStageLayoutButtons();
            return;
        }
        if (stageFrameApplied) {
            stageFrameApplied = false;
            try { window.FAFOMeta?.pinDockForStage?.(null); } catch (_) {}
            clearStageHudStyles();
            try { applyHudLayout(); } catch (_) {}
        }
        const stage = scene?.querySelector('.cinema-stage');
        if (!stage) return;
        const lockBtn = stage.querySelector('.cinema-stage-lock');
        const label = stage.querySelector('.cinema-stage-label');
        const zoomBadge = stage.querySelector('.cinema-stage-zoom');

        if (videoStageLocked) {
            pinLockedStageToBrowserViewport(stage);
            // Do NOT clear video transform here — applyVideoZoom owns live scale
            if (lockBtn) {
                lockBtn.textContent = 'Place';
                lockBtn.title = 'Drag the picture to move its spawn point. Drag this bar to place the window.';
            }
            if (label) {
                label.textContent = Math.abs(videoZoom - 1) < 0.01
                    ? 'Video · full window (browser zoom OK)'
                    : `Video · ${Math.round(videoZoom * 100)}% (live zoom)`;
            }
        } else {
            // Free/placed: stage is a window; video fills it. Wheel resizes the window.
            const vp = window.FAFOViewport?.viewportBox?.() || {
                width: document.documentElement.clientWidth || window.innerWidth || 800,
                height: document.documentElement.clientHeight || window.innerHeight || 600,
            };
            const r = clampVideoStageRect(
                videoStageX,
                videoStageY,
                videoStageW || Math.round(vp.width * 0.8),
                videoStageH || Math.round(vp.height * 0.8),
            );
            videoStageX = r.x;
            videoStageY = r.y;
            videoStageW = r.w;
            videoStageH = r.h;
            stage.classList.remove('stage-locked');
            stage.classList.add('stage-free');
            stage.style.setProperty('position', 'fixed', 'important');
            stage.style.setProperty('inset', 'auto', 'important');
            stage.style.setProperty('left', r.x + 'px', 'important');
            stage.style.setProperty('top', r.y + 'px', 'important');
            stage.style.setProperty('width', r.w + 'px', 'important');
            stage.style.setProperty('height', r.h + 'px', 'important');
            stage.style.setProperty('right', 'auto', 'important');
            stage.style.setProperty('bottom', 'auto', 'important');
            stage.style.setProperty('transform', 'none', 'important');
            // Stage frame only — video content zoom is re-applied below
            if (lockBtn) {
                lockBtn.textContent = 'Lock';
                lockBtn.title = 'Lock video to full browser window again';
            }
            if (label) {
                label.textContent = Math.abs(videoZoom - 1) < 0.01
                    ? 'Video · free · drag · wheel to scale'
                    : `Video · free · ${Math.round(videoZoom * 100)}% live`;
            }
            lockVideoStageToWindow();
        }
        // CRITICAL: never leave layout without re-applying live content zoom
        // (previously free-mode forced transform:none and killed the slider)
        try { applyVideoZoom(); } catch (_) {}
        if (zoomBadge) zoomBadge.textContent = Math.round((videoZoom || 1) * 100) + '%';
        updateVideoPlaceHudBtn();
    }

    function updateVideoPlaceHudBtn() {
        const btn = document.getElementById('hud-video-place');
        if (!btn) return;
        if (videoStageLocked) {
            btn.textContent = 'Place';
            btn.title = 'Free-place video window (drag · resize). Video stays locked inside the frame.';
            btn.classList.remove('active');
        } else {
            btn.textContent = 'Lock';
            btn.title = 'Lock video full-screen again';
            btn.classList.add('active');
        }
    }

    function setVideoStageLocked(locked) {
        const wasLocked = videoStageLocked;
        videoStageLocked = !!locked;
        if (!videoStageLocked) {
            // Free/placed: ~80% screen window; track zoom from default for wheel scaling
            videoZoom = DEFAULT_VIDEO_ZOOM;
            if (!videoStageW || !videoStageH) {
                videoStageW = Math.round((window.innerWidth || 800) * DEFAULT_VIDEO_ZOOM);
                videoStageH = Math.round((window.innerHeight || 600) * DEFAULT_VIDEO_ZOOM);
                videoStageX = Math.round(((window.innerWidth || 800) - videoStageW) / 2);
                videoStageY = Math.round(((window.innerHeight || 600) - videoStageH) / 2);
            }
        } else if (!wasLocked) {
            // Re-docked: restore default 100% content zoom (whole frame)
            videoZoom = DEFAULT_VIDEO_ZOOM;
        }
        applyVideoZoom();
        applyVideoStageLayout();
        scheduleVideoStageSave();
    }

    function toggleVideoStageLock() {
        setVideoStageLocked(!videoStageLocked);
    }

    function bindVideoStageInteractions(stage) {
        if (!stage || videoStageInteractBound || stage.dataset.stageBound === '1') return;
        videoStageInteractBound = true;
        stage.dataset.stageBound = '1';
        const chrome = stage.querySelector('.cinema-stage-chrome');
        const lockBtn = stage.querySelector('.cinema-stage-lock');
        const resize = stage.querySelector('.cinema-stage-resize');

        lockBtn?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleVideoStageLock();
        });

        // Double-click chrome = toggle lock
        chrome?.addEventListener('dblclick', (e) => {
            if (e.target.closest('button')) return;
            e.preventDefault();
            toggleVideoStageLock();
        });

        // Drag chrome to place (auto-unlocks)
        let dragOffX = 0;
        let dragOffY = 0;
        const onDragMove = (e) => {
            if (!videoStageDragging) return;
            const r = clampVideoStageRect(
                e.clientX - dragOffX,
                e.clientY - dragOffY,
                videoStageW || stage.offsetWidth,
                videoStageH || stage.offsetHeight,
            );
            videoStageX = r.x;
            videoStageY = r.y;
            videoStageW = r.w;
            videoStageH = r.h;
            applyVideoStageLayout();
        };
        const onDragEnd = () => {
            if (!videoStageDragging) return;
            videoStageDragging = false;
            stage.classList.remove('stage-dragging');
            document.removeEventListener('pointermove', onDragMove, true);
            document.removeEventListener('pointerup', onDragEnd, true);
            scheduleVideoStageSave();
        };
        chrome?.addEventListener('pointerdown', (e) => {
            if (e.button !== 0) return;
            if (e.target.closest('button')) return;
            e.preventDefault();
            e.stopPropagation();
            // Left / Right / Under: drag the bar to move the video frame live.
            if (stageLayoutFrames()) {
                const startX = e.clientX;
                const startY = e.clientY;
                const startNX = stageNudgeX;
                const startNY = stageNudgeY;
                const moveFrame = (ev) => {
                    stageNudgeX = startNX + (ev.clientX - startX);
                    stageNudgeY = startNY + (ev.clientY - startY);
                    applyStageLayoutNow();
                };
                const endFrame = () => {
                    document.removeEventListener('pointermove', moveFrame, true);
                    document.removeEventListener('pointerup', endFrame, true);
                    saveStageLayout();
                    showScaleToast('Video frame moved');
                };
                document.addEventListener('pointermove', moveFrame, true);
                document.addEventListener('pointerup', endFrame, true);
                return;
            }
            // Start free-place if locked (window size = scale; content zoom independent only when docked)
            if (videoStageLocked) {
                const rect = stage.getBoundingClientRect();
                videoStageW = Math.round(rect.width * DEFAULT_VIDEO_ZOOM);
                videoStageH = Math.round(rect.height * DEFAULT_VIDEO_ZOOM);
                videoStageX = Math.round(rect.left + (rect.width - videoStageW) / 2);
                videoStageY = Math.round(rect.top + 40);
                videoStageLocked = false;
                videoZoom = DEFAULT_VIDEO_ZOOM;
                applyVideoZoom();
                applyVideoStageLayout();
            }
            const rect = stage.getBoundingClientRect();
            dragOffX = e.clientX - rect.left;
            dragOffY = e.clientY - rect.top;
            videoStageDragging = true;
            stage.classList.add('stage-dragging');
            document.addEventListener('pointermove', onDragMove, true);
            document.addEventListener('pointerup', onDragEnd, true);
            try { chrome.setPointerCapture?.(e.pointerId); } catch (_) {}
        });

        // Resize from SE corner
        let resizeStart = null;
        const onResizeMove = (e) => {
            if (!videoStageResizing || !resizeStart) return;
            const r = clampVideoStageRect(
                videoStageX,
                videoStageY,
                resizeStart.w + (e.clientX - resizeStart.cx),
                resizeStart.h + (e.clientY - resizeStart.cy),
            );
            videoStageW = r.w;
            videoStageH = r.h;
            applyVideoStageLayout();
        };
        const onResizeEnd = () => {
            if (!videoStageResizing) return;
            videoStageResizing = false;
            resizeStart = null;
            stage.classList.remove('stage-resizing');
            document.removeEventListener('pointermove', onResizeMove, true);
            document.removeEventListener('pointerup', onResizeEnd, true);
            scheduleVideoStageSave();
        };
        resize?.addEventListener('pointerdown', (e) => {
            if (e.button !== 0) return;
            e.preventDefault();
            e.stopPropagation();
            if (videoStageLocked) {
                const rect = stage.getBoundingClientRect();
                videoStageW = Math.round(rect.width);
                videoStageH = Math.round(rect.height);
                videoStageX = Math.round(rect.left);
                videoStageY = Math.round(rect.top);
                videoStageLocked = false;
                videoZoom = DEFAULT_VIDEO_ZOOM;
                applyVideoZoom();
                applyVideoStageLayout();
            }
            resizeStart = {
                cx: e.clientX,
                cy: e.clientY,
                w: videoStageW || stage.offsetWidth,
                h: videoStageH || stage.offsetHeight,
            };
            videoStageResizing = true;
            stage.classList.add('stage-resizing');
            document.addEventListener('pointermove', onResizeMove, true);
            document.addEventListener('pointerup', onResizeEnd, true);
        });

        window.addEventListener('resize', () => {
            if (cfg.layout === 'cinema') {
                // Keep free video stage fully inside new viewport
                if (!videoStageLocked) {
                    const r = clampVideoStageRect(videoStageX, videoStageY, videoStageW, videoStageH);
                    videoStageX = r.x;
                    videoStageY = r.y;
                    videoStageW = r.w;
                    videoStageH = r.h;
                }
                applyVideoStageLayout();
            }
            try { if (hud.box) placeHudAt(hudX, hudY); } catch (_) {}
        });
    }

    async function loadVideoStageLayout() {
        try {
            const res = await chrome.storage.local.get([
                'fafoVideoStage', 'fafoChromeScale', 'fafoScaleDefaultsV2',
                'fafoBrowserZoomFixV1', 'fafoWholeFrameFitV1',
            ]);
            const fafoVideoStage = res.fafoVideoStage;
            if (fafoVideoStage && typeof fafoVideoStage === 'object') {
                videoStageLocked = fafoVideoStage.locked !== false;
                if (typeof fafoVideoStage.x === 'number') videoStageX = fafoVideoStage.x;
                if (typeof fafoVideoStage.y === 'number') videoStageY = fafoVideoStage.y;
                if (typeof fafoVideoStage.w === 'number' && fafoVideoStage.w > 0) videoStageW = fafoVideoStage.w;
                if (typeof fafoVideoStage.h === 'number' && fafoVideoStage.h > 0) videoStageH = fafoVideoStage.h;
                if (typeof fafoVideoStage.zoom === 'number' && fafoVideoStage.zoom > 0) {
                    videoZoom = Math.max(VIDEO_ZOOM_MIN, Math.min(VIDEO_ZOOM_MAX, fafoVideoStage.zoom));
                } else {
                    videoZoom = DEFAULT_VIDEO_ZOOM;
                }
                if (typeof fafoVideoStage.spawnX === 'number') {
                    videoSpawnX = Math.max(0, Math.min(1, fafoVideoStage.spawnX));
                }
                if (typeof fafoVideoStage.spawnY === 'number') {
                    videoSpawnY = Math.max(0, Math.min(1, fafoVideoStage.spawnY));
                }
            } else {
                videoZoom = DEFAULT_VIDEO_ZOOM;
            }
            if (typeof res.fafoChromeScale === 'number' && res.fafoChromeScale > 0) {
                chromeScale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, res.fafoChromeScale));
            } else {
                chromeScale = DEFAULT_CHROME_SCALE;
            }

            // One-time: old stacks assumed 100% browser zoom + extra 80% video scale.
            // On TVs people use 50–80% page zoom — stacking 80% video made it look unbound/off-center.
            if (!res.fafoBrowserZoomFixV1) {
                videoZoom = 1;
                videoStageLocked = true;
                // Keep chrome scale if user set it; only reset the broken 0.8 default
                if (res.fafoChromeScale == null || res.fafoChromeScale === 0.8) {
                    chromeScale = DEFAULT_CHROME_SCALE;
                }
                chrome.storage.local.set({
                    fafoBrowserZoomFixV1: true,
                    fafoScaleDefaultsV2: true,
                    fafoChromeScale: chromeScale,
                    fafoVideoStage: {
                        locked: true,
                        x: videoStageX,
                        y: videoStageY,
                        w: videoStageW,
                        h: videoStageH,
                        zoom: 1,
                    },
                }).catch(() => {});
            }
            // 6.4.87: old zoom was applied to a pre-cropped 100%×100% box, so saved
            // values don't match "zoom the whole frame". Reset once to a true fit.
            if (!res.fafoWholeFrameFitV1) {
                videoZoom = DEFAULT_VIDEO_ZOOM;
                chrome.storage.local.set({
                    fafoWholeFrameFitV1: true,
                    fafoVideoStage: {
                        locked: videoStageLocked,
                        x: videoStageX,
                        y: videoStageY,
                        w: videoStageW,
                        h: videoStageH,
                        zoom: DEFAULT_VIDEO_ZOOM,
                    },
                }).catch(() => {});
            }
        } catch (_) {
            videoZoom = DEFAULT_VIDEO_ZOOM;
            chromeScale = DEFAULT_CHROME_SCALE;
        }
        applyChromeScale();
        applyVideoZoom();
        applyVideoStageLayout();
    }

    /** Stage host: video is locked inside; stage can be locked full-screen or free-placed. */
    function ensureCinemaStage() {
        if (!scene) return null;
        let stage = scene.querySelector('.cinema-stage');
        if (!stage) {
            stage = document.createElement('div');
            stage.className = 'cinema-stage stage-locked';
            stage.innerHTML = `
                <div class="cinema-stage-chrome" title="Drag bar to move the window · drag the picture to set spawn · double-click picture centers it">
                    <span class="cinema-stage-grip" aria-hidden="true">⋮⋮</span>
                    <span class="cinema-stage-label">Video · full window (browser zoom OK)</span>
                    <button type="button" class="cinema-stage-zoom-btn" data-zoom-dir="-1" title="Video zoom out">−</button>
                    <span class="cinema-stage-zoom" title="App video zoom (on top of browser zoom)">100%</span>
                    <button type="button" class="cinema-stage-zoom-btn" data-zoom-dir="1" title="Video zoom in">+</button>
                    <button type="button" class="cinema-stage-lock" title="Free-place or lock full screen">Place</button>
                </div>
                <div class="cinema-stage-resize" title="Resize video window" aria-hidden="true"></div>
            `;
            scene.appendChild(stage);
            videoStageInteractBound = false;
        }
        if (!stage.dataset.stageBound) {
            videoStageInteractBound = false;
            bindVideoStageInteractions(stage);
            stage.dataset.stageBound = '1';
        }
        // Direct wheel + zoom buttons on stage (reliable hit target)
        if (!stage.dataset.wheelBound) {
            stage.dataset.wheelBound = '1';
            stage.addEventListener('wheel', (e) => {
                e.preventDefault();
                e.stopPropagation();
                nudgeVideoZoom(e.deltaY > 0 ? -1 : 1);
            }, { passive: false });
            stage.querySelectorAll('.cinema-stage-zoom-btn').forEach((btn) => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    const dir = parseInt(btn.dataset.zoomDir, 10) || 1;
                    nudgeVideoZoom(dir);
                });
            });
        }
        applyVideoStageLayout();
        return stage;
    }

    function applyHUD() {
        if (!ui.clock || !ui.box) return;
        ui.clock.style.fontSize = `${cfg.clockSize}px`;
        ui.clock.style.color = cfg.clockColor || '';
        ui.box.style.fontFamily = cfg.font;
        ui.box.className = cfg.pos;
        ui.box.style.display = cfg.showClock === false ? 'none' : '';
        ui.box.style.opacity = cfg.clockOpacity != null ? String(cfg.clockOpacity) : '';
        ui.date.style.display = cfg.showDate ? 'block' : 'none';
    }

    function unlockAudioFromGesture() {
        userUnlockedAudio = true;
        if (mainVideo && mainVideo.muted && cfg.volume > 0) {
            // Only unmute if HUD mute wasn't intentionally left on at zero volume
            // Keep muted if user last set mute via button (video.muted && volume>0 after explicit mute)
            // Heuristic: if volume slider > 0 and we're paused/playing after gesture, allow sound
            try {
                mainVideo.muted = false;
                mainVideo.volume = cfg.volume;
                updateHudMuteIcon();
            } catch (_) {}
        }
    }

    function installVideoSpawnDrag() {
        if (document.body.dataset.fafoSpawnDrag === '1') return;
        document.body.dataset.fafoSpawnDrag = '1';
        let drag = null;
        const applySpawn = () => {
            try {
                if (wallModeActive) applyWallVideoZoom();
                else applyVideoZoom();
            } catch (_) {}
        };
        const onMove = (e) => {
            if (!drag) return;
            const dx = e.clientX - drag.x;
            const dy = e.clientY - drag.y;
            if (!drag.moved && Math.hypot(dx, dy) < 5) return;
            drag.moved = true;
            suppressPauseClick = true;
            document.body.classList.add('fafo-spawn-dragging');
            const bw = Math.max(80, drag.bw);
            const bh = Math.max(80, drag.bh);
            videoSpawnX = Math.max(0, Math.min(1, drag.sx + dx / bw));
            videoSpawnY = Math.max(0, Math.min(1, drag.sy + dy / bh));
            applySpawn();
        };
        const onUp = () => {
            if (!drag) return;
            const moved = drag.moved;
            drag = null;
            document.removeEventListener('pointermove', onMove, true);
            document.removeEventListener('pointerup', onUp, true);
            document.body.classList.remove('fafo-spawn-dragging');
            if (!moved) return;
            scheduleVideoStageSave();
            showScaleToast(`Video spawn · ${Math.round(videoSpawnX * 100)}% across · ${Math.round(videoSpawnY * 100)}% down`);
        };
        document.addEventListener('pointerdown', (e) => {
            if (e.button !== 0) return;
            const media = e.target?.closest?.(
                '#bg-video, #bg-photo, .cinema-stage > video, .cinema-stage > img, .grid-cell video, .grid-cell img'
            );
            if (!media) return;
            if (e.target.closest('button, a, input, .cinema-stage-chrome, .player-hud, #meta-dock')) return;
            if (e.detail >= 2) {
                videoSpawnX = 0.5;
                videoSpawnY = 0.5;
                suppressPauseClick = true;
                applySpawn();
                scheduleVideoStageSave();
                showScaleToast('Video spawn · centered');
                e.preventDefault();
                return;
            }
            const box = media.parentElement?.getBoundingClientRect?.() || media.getBoundingClientRect();
            drag = {
                x: e.clientX,
                y: e.clientY,
                sx: videoSpawnX,
                sy: videoSpawnY,
                bw: box.width || 1,
                bh: box.height || 1,
                moved: false,
            };
            document.addEventListener('pointermove', onMove, true);
            document.addEventListener('pointerup', onUp, true);
        }, true);
    }

    function initInputListeners() {
        // Any gesture unlocks sound for future clips (Chrome new-tab autoplay policy)
        document.addEventListener('pointerdown', () => unlockAudioFromGesture(), { capture: true, passive: true });
        document.addEventListener('keydown', () => unlockAudioFromGesture(), { capture: true, passive: true });

        let lastSpaceTapAt = 0;
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
            // Don't steal keys while typing in tag panel inputs
            if (e.target.closest?.('#meta-dock input, #meta-dock textarea')) return;

            if (e.code === 'Space') {
                e.preventDefault();
                const now = Date.now();
                // Double-tap Space → focus Add-tag field (live filter all lists)
                if (now - lastSpaceTapAt < 420) {
                    lastSpaceTapAt = 0;
                    try { window.FAFOMeta?.focusTagInput?.(); } catch (_) {}
                    return;
                }
                lastSpaceTapAt = now;
                togglePause();
            }
            if (e.code === 'ArrowRight') skipTrack(1);
            if (e.code === 'ArrowLeft') skipTrack(-1);
            // A/D transport · W/S speed · Q repeat · E E-set (modifiers = banks)
            if (e.code === 'KeyA' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                skipTrack(-1);
            }
            if (e.code === 'KeyD' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                skipTrack(1);
            }
            if (e.code === 'KeyW' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                changeSpeed(1);
            }
            if (e.code === 'KeyS' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                changeSpeed(-1);
            }
            if (e.code === 'KeyQ' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                toggleManualRepeat();
            }
            if (e.code === 'KeyE') {
                // E + modifiers select bank (same matrix as hotkeys)
                // Skip when focus is inside E-set custom assign inputs (already guarded above)
                e.preventDefault();
                const bank = bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
                window.FAFOMeta?.setExtraLiveBank?.(bank);
                window.FAFOMeta?.applyExtraTagBank?.(bank);
                revealHud();
            }
            if (e.code === 'KeyH') toggleShuffle(); // was S
            if (e.code === 'KeyG' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                // Wall grid (8-up) ↔ previous view
                e.preventDefault();
                toggleWallMode();
            }
            if (e.code === 'KeyM') toggleMute();
            if (e.code === 'KeyP') togglePiP();
            if (e.code === 'KeyF') toggleFullscreen();
            if (e.code === 'KeyL') { e.preventDefault(); openPlaylistPicker(); }
            if (e.code === 'Comma') changeSpeed(-1);
            if (e.code === 'Period') changeSpeed(1);
            if (e.key === '?') shortcutHelp?.classList.toggle('hidden');
            // Live-update E-set bank chips when modifiers held
            if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) {
                window.FAFOMeta?.syncExtraBankFromEvent?.(e);
            }
            revealHud();
        });
        document.addEventListener('keyup', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            window.FAFOMeta?.syncExtraBankFromEvent?.(e);
        });
        // Independent video vs UI scaling (wheel / Ctrl±) — blocks browser page zoom
        initIndependentScaleControls();
        // Lock all floating UI to the real window (windowed + fullscreen)
        initViewportLockWatch();
        document.addEventListener('click', (e) => {
            if (suppressPauseClick) {
                suppressPauseClick = false;
                return;
            }
            if (e.target.closest('a') || e.target.closest('button') || e.target.closest('.modal') || e.target.closest('.player-hud') || e.target.closest('#meta-dock') || e.target.closest('#playlist-pick') || e.target.closest('.cinema-stage-chrome')) return;
            togglePause();
        });
        installVideoSpawnDrag();
        document.addEventListener('mousemove', revealHud, { passive: true });
        
        // Creative 3D Tilt for Carousel
        document.addEventListener('mousemove', (e) => {
            if (cfg.layout === 'carousel') {
                const x = (e.clientX / window.innerWidth - 0.5) * 2; // -1 to 1
                const y = (e.clientY / window.innerHeight - 0.5) * 2;
                
                const pivot = document.querySelector('.carousel-pivot');
                if(pivot) {
                    pivot.style.transformOrigin = 'center center';
                    scene.style.transform = `rotateX(${cfg.carouselTilt + (y * 10)}deg) rotateY(${x * 10}deg)`;
                }
            }
        });
    }

    function pushPlayHistory(idx) {
        if (idx == null || idx < 0 || !playlist.length) return;
        // Avoid duplicate consecutive entries
        if (playHistory.length && playHistory[playHistory.length - 1] === idx) return;
        playHistory.push(idx);
        if (playHistory.length > PLAY_HISTORY_MAX) playHistory.shift();
    }

    /**
     * Advance (or go back) in the playlist.
     * dir < 0 uses play history so Prev returns the last played clip (not just index-1).
     * When skip-tagged mode is on, forward skips already-tagged / heavily-tagged clips.
     */
    function shuffleInPlace(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
        return arr;
    }

    function skipTrack(dir) {
        if (!playlist.length) return;
        clearTimeout(photoTimeout);
        clearTimeout(playFailTimer);
        loopCount = 0;
        isPaused = false;
        consecutiveErrors = 0; // user intent always restarts the fail streak
        userUnlockedAudio = true;
        ui.clock.style.opacity = 1;
        if (hud.play) hud.play.textContent = '⏸';
        clearPlayOverlay();
        try { window.FAFOMeta?.clearUntaggedPrompt?.(); } catch (_) {}

        if (dir < 0) {
            // Prefer real history of what was played
            while (playHistory.length) {
                const prev = playHistory.pop();
                if (prev !== currentIdx && prev >= 0 && prev < playlist.length) {
                    currentIdx = prev;
                    playNext({ fromHistory: true, instant: true, force: true });
                    return;
                }
            }
            // Fallback: previous index in current order
            currentIdx = (currentIdx - 1 + playlist.length) % playlist.length;
            playNext({ fromHistory: true, instant: true, force: true });
            return;
        }

        // Forward: remember where we were, then find next eligible index
        pushPlayHistory(currentIdx);
        const next = findNextEligibleIndex(currentIdx, 1);
        currentIdx = next;
        playNext({ instant: true, force: true });
    }

    /**
     * Find next playlist index respecting FAFOMeta skip-tagged mode when active.
     * Falls back to simple wrap if every item is filtered.
     */
    function findNextEligibleIndex(fromIdx, dir) {
        const n = playlist.length;
        if (!n) return 0;
        const step = dir < 0 ? -1 : 1;

        // Sprint Tag mode: order by 0 tags → 1 → 2… and prefer clips missing sprint focus tags
        if (window.FAFOMeta?.isSprintMode?.()) {
            let bestIdx = -1;
            let bestScore = Infinity;
            // Prefer scanning forward (or back) but pick lowest score among all items
            // so the runway always works untagged-first regardless of current position.
            for (let i = 1; i <= n; i++) {
                const idx = (fromIdx + step * i + n * 20) % n;
                if (idx === fromIdx) continue;
                const item = playlist[idx];
                let score = 0;
                try {
                    score = window.FAFOMeta.sprintScoreForItem?.(item);
                    if (score == null || !Number.isFinite(score)) {
                        score = window.FAFOMeta.tagCountForItem?.(item) ?? 0;
                    }
                } catch {
                    score = 0;
                }
                // Tie-break: closer in step direction first among equal scores
                const dist = i;
                const ranked = score * 100000 + dist;
                if (ranked < bestScore) {
                    bestScore = ranked;
                    bestIdx = idx;
                }
            }
            if (bestIdx >= 0) return bestIdx;
            return (fromIdx + step + n) % n;
        }

        // Private/public isolation — never mix sections in playback
        const spaceFilter = typeof window.FAFOMeta?.isMediaInCurrentSpace === 'function'
            ? (item) => {
                try {
                    return !!window.FAFOMeta.isMediaInCurrentSpace(item);
                } catch {
                    return true;
                }
            }
            : () => true;

        const skipMode = !!window.FAFOMeta?.isSkipTaggedMode?.();
        if (!skipMode) {
            for (let i = 1; i <= n; i++) {
                const idx = (fromIdx + step * i + n * 10) % n;
                const item = playlist[idx];
                if (spaceFilter(item)) return idx;
            }
            return (fromIdx + step + n) % n;
        }
        // Prefer untagged; if none left in a full scan, prefer < 5 tags
        let foundLight = -1;
        let foundAnySpace = -1;
        for (let i = 1; i <= n; i++) {
            const idx = (fromIdx + step * i + n * 10) % n;
            const item = playlist[idx];
            if (!spaceFilter(item)) continue;
            if (foundAnySpace < 0) foundAnySpace = idx;
            const count = window.FAFOMeta?.tagCountForItem?.(item) ?? 0;
            if (count === 0) return idx;
            if (foundLight < 0 && count < 5) foundLight = idx;
        }
        // All tagged: skip ones with 5+ tags when possible
        if (foundLight >= 0) return foundLight;
        if (foundAnySpace >= 0) return foundAnySpace;
        return (fromIdx + step + n) % n;
    }

    /**
     * Loop current clip until user presses Next when:
     * - clip is untagged (replaces old pause-at-end), or
     * - Skip tagged mode is on
     * Tagging does NOT auto-advance.
     */
    /** Same rules as FAFOMeta: Alt→3, Ctrl→2, Shift→1, none→0 */
    function bankFromMods(shift, ctrl, alt) {
        if (alt) return 3;
        if (ctrl) return 2;
        if (shift) return 1;
        return 0;
    }

    function isClipLoopMode() {
        if (manualRepeat) return true;
        try {
            if (window.FAFOMeta?.isSkipTaggedMode?.()) return true;
            if (window.FAFOMeta?.isUntagged?.()) return true;
        } catch (_) {}
        return false;
    }

    function toggleManualRepeat() {
        manualRepeat = !manualRepeat;
        chrome.storage.local.set({ fafoManualRepeat: manualRepeat }).catch(() => {});
        refreshLoopMode();
        updateRepeatButton();
        revealHud();
        if (hud.title) {
            const prev = hud.title.textContent;
            hud.title.textContent = manualRepeat ? '🔁 Repeat ON' : 'Repeat off';
            setTimeout(() => {
                if (hud.title && (hud.title.textContent === '🔁 Repeat ON' || hud.title.textContent === 'Repeat off')) {
                    updateHUD();
                }
            }, 900);
        }
    }

    function updateRepeatButton() {
        const btn = document.getElementById('hud-repeat');
        if (!btn) return;
        btn.classList.toggle('active', !!manualRepeat);
        btn.title = manualRepeat
            ? 'Repeat ON (Q) — click or Q to turn off'
            : 'Repeat this clip (Q)';
        btn.setAttribute('aria-pressed', manualRepeat ? 'true' : 'false');
    }

    function restartClipFromStart(reason) {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        // Never fight a mid-load source swap (this was killing Chrome playback)
        if (mediaLoading) return;
        if (isPaused && reason !== 'setClipLoop') return;
        try {
            mainVideo.loop = true;
            if (ambienceVideo) ambienceVideo.loop = true;
            try {
                mainVideo.currentTime = 0;
            } catch (_) {}
            applyPlaybackSpeed();
            isPaused = false;
            ui.clock.style.opacity = 1;
            if (hud.play) hud.play.textContent = '⏸';
            const p = mainVideo.play();
            if (p && typeof p.catch === 'function') {
                p.catch(() => {
                    if (mediaLoading) return;
                    setTimeout(() => {
                        if (mediaLoading || !mainVideo) return;
                        try {
                            mainVideo.currentTime = 0;
                            mainVideo.loop = true;
                            mainVideo.muted = mainVideo.muted || !userUnlockedAudio;
                            mainVideo.play().catch(() => {});
                        } catch (_) {}
                    }, 50);
                });
            }
            if (ambienceVideo) {
                try {
                    ambienceVideo.currentTime = 0;
                    ambienceVideo.play().catch(() => {});
                } catch (_) {}
            }
        } catch (e) {
            console.warn('restartClipFromStart', reason, e);
        }
    }

    function setClipLoop(on) {
        if (mainVideo && mainVideo.tagName === 'VIDEO') {
            // Keep the native loop flag on continuously when looping is desired
            mainVideo.loop = !!on;
            if (ambienceVideo) ambienceVideo.loop = !!on;
            updateLoopHudChip();
            // Only restart if truly stuck at end — not during load
            if (
                on &&
                !mediaLoading &&
                !isPaused &&
                mainVideo.readyState >= 2 &&
                Number.isFinite(mainVideo.duration) &&
                mainVideo.duration > 0 &&
                (mainVideo.ended || mainVideo.currentTime >= mainVideo.duration - 0.05)
            ) {
                restartClipFromStart('setClipLoop');
            }
        }
    }

    function refreshLoopMode() {
        const on = isClipLoopMode();
        setClipLoop(on);
        // Photos: restart timer path is handled in playNext via isClipLoopMode
        updateLoopHudChip();
    }

    function updateLoopHudChip() {
        const chip = document.getElementById('hud-mode-chip');
        if (!chip) return;
        const skip = !!window.FAFOMeta?.isSkipTaggedMode?.();
        const untagged = !!window.FAFOMeta?.isUntagged?.();
        const looping = isClipLoopMode();
        const parts = [];
        if (manualRepeat) parts.push('REPEAT · Q');
        if (skip) parts.push('SKIP TAGGED');
        if (untagged) parts.push('UNTAGGED · LOOP');
        else if (looping && skip && !manualRepeat) parts.push('LOOP');
        if (!parts.length) {
            chip.hidden = true;
            chip.textContent = '';
            updateRepeatButton();
            return;
        }
        chip.hidden = false;
        chip.textContent = parts.join(' · ');
        updateRepeatButton();
        chip.title = skip
            ? 'Skip tagged on Next · looping until you press Next'
            : 'Untagged clip loops until you press Next (tagging does not advance)';
    }

    async function playIndex(idx, opts = {}) {
        if (!playlist.length) return;
        const n = Math.max(0, Math.min(playlist.length - 1, Number(idx) || 0));
        currentIdx = n;
        await playNext({ instant: true, force: true, seek: opts.seek });
        try { window.FAFOLibraryDoctor?.scheduleNextUp?.(); } catch (_) {}
        try { window.FAFOSession?.scheduleSave?.(); } catch (_) {}
    }

    // Bridge for fafo-meta.js (tags / ratings / meta prev-next)
    window.FAFOPlayer = {
        skipTrack,
        playIndex,
        getCurrentItem: () => playlist[currentIdx] || null,
        getCurrentIndex: () => currentIdx,
        getPlaylistLength: () => playlist.length,
        getPlaylist: () => playlist.slice(),
        /** Rebuild playlist for current public/private library (no Explorer). */
        reloadLibrary: async () => {
            try {
                await buildPlaylist();
                currentIdx = 0;
                if (typeof historyStack !== 'undefined' && Array.isArray(historyStack)) {
                    historyStack.length = 0;
                }
                if (typeof playNext === 'function') playNext({ instant: true, force: true });
                else if (typeof initLayout === 'function') initLayout();
                if (typeof updateEmptyState === 'function') updateEmptyState();
            } catch (e) {
                console.warn('FAFOPlayer.reloadLibrary', e);
            }
        },
        togglePause: () => { if (typeof togglePause === 'function') togglePause(); },
        openPlaylistPicker: () => openPlaylistPicker(),
        findNextEligibleIndex,
        setClipLoop,
        refreshLoopMode,
        applyPlaybackSpeed: () => applyPlaybackSpeed(),
        updateLoopHudChip,
        undockHudForMove,
        resetHudLayout,
        lockVideoToScreen: () => setVideoStageLocked(true),
        placeVideoStage: () => setVideoStageLocked(false),
        toggleVideoStageLock,
        setVideoZoom,
        nudgeVideoZoom,
        getVideoZoom: () => videoZoom,
        fitWholeFrame: () => {
            videoZoom = DEFAULT_VIDEO_ZOOM;
            try { cfg.scaling = 'scale-contain'; } catch (_) {}
            try { cinemaMediaEl()?.classList.remove('ken-burns'); } catch (_) {}
            applyCinemaObjectFit(cinemaMediaEl() || mainVideo, 'contain');
            showScaleToast('Video · fit whole frame');
            scheduleVideoStageSave();
            try {
                chrome.storage.local.get('mediaConfig').then((res) => {
                    const mc = { ...(res.mediaConfig || {}), scaling: 'scale-contain' };
                    chrome.storage.local.set({ mediaConfig: mc });
                }).catch(() => {});
            } catch (_) {}
        },
        setChromeScale,
        nudgeChromeScale,
        getChromeScale: () => chromeScale,
        isVideoStageLocked: () => videoStageLocked,
        toggleWallMode,
        isWallMode: () => !!wallModeActive,
        setWallCount,
        getWallCount: () => wallCount,
        setWallGapScale,
        setWallFlag,
        getWallPrefs: () => ({ ...wallPrefs }),
        reflowWallLayout,
        reclampToWindow: () => reclampAllPlayerChromeAfterScale(),
        cycleStageLayout,
        cycleStageWidth,
        applyStageLayoutNow,
        isStageFramed: () => stageLayoutMode !== 'dock',
        getStageLayout: () => ({ mode: stageLayoutMode, width: stageVideoWidth }),
    };

    // --- PLAYLIST QUICK-ADD (during playback) ---
    async function listDbPlaylists() {
        if (!db) return [];
        try {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            return await new Promise(res => {
                const req = store.getAll();
                req.onsuccess = () => res(req.result || []);
                req.onerror = () => res([]);
            });
        } catch { return []; }
    }

    async function openPlaylistPicker() {
        const panel = document.getElementById('playlist-pick');
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        if (!panel || !select) return;
        const item = playlist[currentIdx];
        if (!item || !item.handle) {
            // Bundled URL items can't join handle playlists easily
            console.warn('Current item has no file handle for playlist storage');
        }
        const lists = (await listDbPlaylists()).filter(p => p.type !== 'smart');
        select.innerHTML = '<option value="">— select playlist —</option>' +
            lists.map(p => `<option value="${p.id}">${p.name} (${(p.items || []).length})</option>`).join('');
        if (newName) newName.value = '';
        panel.classList.remove('hidden');
        revealHud();
    }

    function closePlaylistPicker() {
        document.getElementById('playlist-pick')?.classList.add('hidden');
    }

    async function addCurrentToPlaylist() {
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        const item = playlist[currentIdx];
        if (!item?.handle) {
            alert('This clip has no local file handle (bundled/URL). Link a folder in Options to use playlists.');
            return;
        }
        if (!db) await initDB();

        let playlistId = select?.value || '';
        let pl = null;

        if (newName?.value?.trim()) {
            const name = newName.value.trim();
            pl = {
                id: 'pl_' + Date.now().toString(36),
                name,
                items: [],
                created: Date.now(),
            };
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
            playlistId = pl.id;
        } else if (playlistId) {
            const tx = db.transaction('playlists', 'readonly');
            pl = await new Promise(res => {
                const r = tx.objectStore('playlists').get(playlistId);
                r.onsuccess = () => res(r.result);
                r.onerror = () => res(null);
            });
        }
        if (!pl) {
            alert('Pick an existing playlist or type a new name.');
            return;
        }

        const storeName = item.type === 'photo' ? 'photos' : 'videos';
        let handleKey = null;
        try {
            const tx = db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const vals = await new Promise((res, rej) => {
                const r = store.getAll();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const keys = await new Promise((res, rej) => {
                const tx2 = db.transaction(storeName, 'readonly');
                const r = tx2.objectStore(storeName).getAllKeys();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const targetName = item.handle?.name || item.name;
            for (let i = 0; i < vals.length; i++) {
                const entry = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(vals[i]) : null;
                const h = entry?.handle || vals[i];
                const n = entry?.name || vals[i]?.name || h?.name;
                if (h === item.handle || (targetName && n === targetName)) {
                    handleKey = keys[i];
                    break;
                }
            }
        } catch (e) {
            console.warn(e);
        }

        if (handleKey == null) {
            try {
                const tx = db.transaction(storeName, 'readwrite');
                handleKey = await new Promise((res, rej) => {
                    const payload = {
                        handle: item.handle,
                        name: item.handle?.name || item.name,
                        addedAt: Date.now(),
                    };
                    const r = tx.objectStore(storeName).add(payload);
                    r.onsuccess = () => res(r.result);
                    r.onerror = () => rej(r.error);
                });
            } catch (e) {
                alert('Could not resolve file in library: ' + e.message);
                return;
            }
        }

        pl.items = pl.items || [];
        const exists = pl.items.some(i => i.store === storeName && String(i.key) === String(handleKey));
        if (!exists) {
            pl.items.push({ store: storeName, key: handleKey });
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
        }
        closePlaylistPicker();
        if (hud.title) {
            const prev = hud.title.textContent;
            hud.title.textContent = `✓ Added to ${pl.name}`;
            setTimeout(() => { if (hud.title) hud.title.textContent = prev; }, 1600);
        }
    }

    document.getElementById('playlist-pick-cancel')?.addEventListener('click', closePlaylistPicker);
    document.getElementById('playlist-pick-ok')?.addEventListener('click', () => addCurrentToPlaylist());
    document.getElementById('playlist-pick')?.addEventListener('click', (e) => {
        if (e.target.id === 'playlist-pick') closePlaylistPicker();
    });

    function toggleMute() {
        userUnlockedAudio = true;
        // Wall / grid: mute state is wallAudioMuted; only primary tile has sound
        if (wallModeActive || (cfg.layout === 'grid' && getWallVideos().length)) {
            wallAudioMuted = !wallAudioMuted;
            if (!wallAudioMuted) {
                const vol = Math.max(0, Math.min(1, cfg.volume ?? 0.7));
                if (vol === 0 && hud.volume) {
                    const restored = Math.max(0.05, (parseInt(hud.volume.value, 10) || 70) / 100);
                    cfg.volume = restored;
                }
            }
            applyWallAudio({ muted: wallAudioMuted });
            // Retry play unmuted after gesture (autoplay policies)
            if (!wallAudioMuted) {
                const p = getWallPrimaryVideo();
                if (p) {
                    p.muted = false;
                    p.play().catch(() => {
                        // If unmuted play fails, stay soft-muted flag false but keep element muted
                        try { p.muted = false; } catch (_) {}
                    });
                }
            }
            updateHudMuteIcon();
            return;
        }
        if (!mainVideo) return;
        mainVideo.muted = !mainVideo.muted;
        if (!mainVideo.muted && mainVideo.volume === 0 && hud.volume) {
            mainVideo.volume = hud.volume.value / 100;
            cfg.volume = mainVideo.volume;
        }
        updateHudMuteIcon();
    }

    function toggleShuffle() {
        cfg.shuffle = !cfg.shuffle;
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, shuffle: cfg.shuffle}});
        });
        if (cfg.shuffle && playlist.length > 1) {
            const current = playlist[currentIdx];
            const rest = playlist.filter((_, i) => i !== currentIdx);
            shuffleInPlace(rest);
            playlist = [current, ...rest];
            currentIdx = 0;
            playHistory = []; // indices invalidated by reorder
            updateHUD();
        }
    }

    function formatSpeedLabel(speed) {
        if (speed === 1) return '1×';
        if (speed === 0.33) return '0.33×';
        if (speed === 0.25) return '0.25×';
        return `${speed}×`;
    }

    function changeSpeed(dir) {
        const idx = SPEED_STEPS.indexOf(cfg.playbackSpeed);
        const base = idx < 0 ? SPEED_STEPS.indexOf(1) : idx;
        const next = SPEED_STEPS[Math.max(0, Math.min(SPEED_STEPS.length - 1, base + dir))];
        setPlaybackSpeed(next);
        revealHud();
    }

    /** Apply cfg.playbackSpeed to active media. Must re-run after src changes (browsers reset rate). */
    function applyPlaybackSpeed() {
        const speed = cfg.playbackSpeed || 1;
        if (mainVideo && mainVideo.tagName === 'VIDEO') {
            try { mainVideo.playbackRate = speed; } catch (_) {}
        }
        if (ambienceVideo) {
            try { ambienceVideo.playbackRate = speed; } catch (_) {}
        }
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(speed);
    }

    function setPlaybackSpeed(speed) {
        cfg.playbackSpeed = speed;
        applyPlaybackSpeed();
        chrome.storage.local.get('mediaConfig', ({ mediaConfig = {} }) => {
            if (mediaConfig.playbackSpeed === speed) return;
            chrome.storage.local.set({ mediaConfig: { ...mediaConfig, playbackSpeed: speed } });
        });
    }

    async function togglePiP() {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        try {
            if (document.pictureInPictureElement) {
                await document.exitPictureInPicture();
            } else if (document.pictureInPictureEnabled) {
                await mainVideo.requestPictureInPicture();
            }
        } catch (e) { console.warn('PiP unavailable', e); }
    }

    function formatTime(sec) {
        if (!isFinite(sec) || sec < 0) return '0:00';
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    }

    function updateProgressUI() {
        if (!mainVideo || !mainVideo.duration) return;
        const ratio = mainVideo.currentTime / mainVideo.duration;
        const pct = `${ratio * 100}%`;
        if (hud.progress) hud.progress.style.width = pct;
        if (hud.progressThumb) hud.progressThumb.style.left = pct;
        if (hud.timeCurrent) hud.timeCurrent.textContent = formatTime(mainVideo.currentTime);
        if (hud.timeTotal) hud.timeTotal.textContent = formatTime(mainVideo.duration);
    }

    function seekFromEvent(e) {
        if (!mainVideo || !mainVideo.duration || !hud.progressTrack) return;
        const rect = hud.progressTrack.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        // Seeking near/past end can fire `ended` — suppress spurious skip
        suppressEndedUntil = Date.now() + 450;
        mainVideo.currentTime = ratio * mainVideo.duration;
        if (ambienceVideo && ambienceVideo.duration) ambienceVideo.currentTime = mainVideo.currentTime;
        updateProgressUI();
    }

    function initProgressSeek() {
        if (!hud.progressTrack) return;
        const onDown = (e) => {
            if (!mainVideo?.duration) return;
            isSeeking = true;
            suppressEndedUntil = Date.now() + 800;
            hud.progressTrack.classList.add('seeking');
            seekFromEvent(e);
            e.preventDefault();
        };
        const onMove = (e) => { if (isSeeking) seekFromEvent(e); };
        const onUp = () => {
            isSeeking = false;
            suppressEndedUntil = Date.now() + 400;
            hud.progressTrack?.classList.remove('seeking');
        };
        hud.progressTrack.addEventListener('mousedown', onDown);
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    function setVolume(level) {
        const vol = Math.max(0, Math.min(1, level));
        cfg.volume = vol;
        // Volume slider is a user gesture — unlock audio for wall + cinema
        if (vol > 0) userUnlockedAudio = true;

        if (wallModeActive || (cfg.layout === 'grid' && getWallVideos().length)) {
            applyWallAudio({ volume: vol, fromVolumeSlider: true });
            if (vol > 0 && !wallAudioMuted) {
                const p = getWallPrimaryVideo();
                if (p) {
                    try {
                        p.muted = false;
                        p.volume = vol;
                        p.play().catch(() => {});
                    } catch (_) {}
                }
            }
        } else if (mainVideo) {
            mainVideo.volume = vol;
            if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
        }
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        updateHudMuteIcon();
        // Debounce storage writes so sliding the volume doesn't thrash storage
        // (and so even a mis-fired rebuild can't spam-reshuffle mid-drag)
        clearTimeout(volumeSaveTimer);
        volumeSaveTimer = setTimeout(() => {
            chrome.storage.local.get('mediaConfig', ({ mediaConfig = {} }) => {
                // Only write if volume actually differs (avoids echo loops)
                if (mediaConfig.volume === vol) return;
                chrome.storage.local.set({ mediaConfig: { ...mediaConfig, volume: vol } });
            });
        }, 180);
    }

    function saveHudLayout() {
        chrome.storage.local.set({
            fafoHudDock: hudDock,
            fafoHudPinned: hudPinned,
            fafoHudX: hudX,
            fafoHudY: hudY,
            fafoHudW: hudW,
            fafoHudH: hudH,
            fafoHudTagsPerRow: hudTagsPerRow,
        }).catch(() => {});
    }

    function applyHudTagsPerRow(n) {
        const v = Math.max(2, Math.min(12, Math.round(Number(n) || 5)));
        hudTagsPerRow = v;
        const row = document.getElementById('hud-current-tags');
        if (row) row.style.setProperty('--hud-tags-per-row', String(v));
        const input = document.getElementById('hud-tags-per-row');
        if (input && String(input.value) !== String(v)) input.value = String(v);
        const lab = document.getElementById('hud-tags-per-row-val');
        if (lab) lab.textContent = String(v);
    }

    function applyHudSize() {
        const el = hud.box;
        if (!el) return;
        const maxW = Math.min(920, Math.max(280, (window.innerWidth || 800) - 16));
        const maxH = Math.min(860, Math.max(120, (window.innerHeight || 600) - 16));
        if (hudW && hudW > 0) {
            el.style.width = Math.round(Math.min(maxW, Math.max(280, hudW))) + 'px';
        } else {
            el.style.width = '';
        }
        if (hudH && hudH > 0) {
            el.style.height = Math.round(Math.min(maxH, Math.max(120, hudH))) + 'px';
        } else {
            el.style.height = '';
        }
    }

    /** Pre-clamp HUD coords (scale-aware); final truth is FAFOViewport.lock painted rect. */
    function clampHudXY(x, y) {
        const el = hud.box;
        const scale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));
        const layoutW = el?.offsetWidth || 340;
        const layoutH = el?.offsetHeight || 140;
        if (window.FAFOViewport?.clampPoint) {
            const c = window.FAFOViewport.clampPoint(x, y, layoutW, layoutH, scale, 4);
            return { x: c.x, y: c.y };
        }
        return { x: Math.round(Number(x) || 0), y: Math.round(Number(y) || 0) };
    }

    /** Pin HUD with left/top, then lock painted box to the real window. */
    function placeHudAt(x, y) {
        const el = hud.box;
        if (!el) return;
        const s = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));
        el.style.setProperty('--fafo-chrome-scale', String(s));
        el.style.setProperty('transform', `scale(${s})`, 'important');
        el.style.setProperty('transform-origin', 'top left', 'important');
        applyHudSize();
        applyHudTagsPerRow(hudTagsPerRow);
        const c = clampHudXY(x, y);
        hudX = c.x;
        hudY = c.y;
        el.style.setProperty('left', `${hudX}px`, 'important');
        el.style.setProperty('top', `${hudY}px`, 'important');
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');
        // Final lock: uses getBoundingClientRect (scale-correct, windowed or fullscreen)
        // Allow resize to keep user width/height; only clamp position by default
        const locked = window.FAFOViewport?.lock?.(el, {
            margin: 4,
            canResize: false,
            minW: 200,
            minH: 80,
        });
        if (locked) {
            hudX = locked.x;
            hudY = locked.y;
        }
    }

    /** After GUI/video scale or window/fullscreen change — lock everything to the window. */
    function reclampAllPlayerChromeAfterScale() {
        if (stageLayoutMode !== 'dock') {
            try { applyStageLayoutNow(); } catch (_) {}
            return;
        }
        try {
            if (hud.box) {
                if (hudDock === 'free') placeHudAt(hudX, hudY);
                else {
                    const snap = coordsForHudSnap(hudDock);
                    placeHudAt(snap.x, snap.y);
                }
            }
        } catch (_) {}
        try {
            if (!videoStageLocked) {
                applyVideoStageLayout();
                lockVideoStageToWindow();
            } else {
                applyVideoZoom();
            }
        } catch (_) {}
        try {
            window.FAFOMeta?.reclampAllChromeAfterScale?.();
        } catch (_) {}
    }

    function initViewportLockWatch() {
        if (!window.FAFOViewport) return;
        window.FAFOViewport.watch();
        window.FAFOViewport.onLock(() => {
            reclampAllPlayerChromeAfterScale();
        });
    }

    function coordsForHudSnap(pos) {
        const el = hud.box;
        const m = 8;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const scale = Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));
        const w = Math.max(200, (el?.offsetWidth || 340) * scale);
        const h = Math.max(80, (el?.offsetHeight || 160) * scale);
        switch (pos) {
            case 'bl':
                return { x: m, y: Math.max(m, wh - h - m) };
            case 'br':
                return { x: Math.max(m, ww - w - m), y: Math.max(m, wh - h - m) };
            case 'mr':
                return { x: Math.max(m, ww - w - m), y: Math.max(m, Math.round((wh - h) / 2)) };
            case 'free':
            default:
                return { x: hudX, y: hudY };
        }
    }

    function setHudFreeStyles(el, x, y) {
        if (!el) return;
        el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr');
        el.classList.add('hud-dock-free');
        el.dataset.hudDock = 'free';
        placeHudAt(x, y);
    }

    function applyHudLayout() {
        if (!hud.box) return;
        const frames = stageLayoutFrames();
        if (frames?.hud) {
            applyStageHud(frames);
            updateStageLayoutButtons();
            return;
        }
        clearStageHudStyles();
        const el = hud.box;
        el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr', 'hud-dock-free', 'hud-pinned');
        const dock = ['mr', 'br', 'bl', 'free'].includes(hudDock) ? hudDock : 'mr';
        hudDock = dock;
        el.classList.add(`hud-dock-${dock}`);
        el.dataset.hudDock = dock;
        if (hudPinned) el.classList.add('hud-pinned');

        // Always left/top pixels — dock mode only picks the target coords
        const place = () => {
            if (dock === 'free') {
                placeHudAt(hudX, hudY);
            } else {
                const c = coordsForHudSnap(dock);
                placeHudAt(c.x, c.y);
            }
        };
        place();
        requestAnimationFrame(place);

        const dockBtn = document.getElementById('hud-dock-cycle');
        if (dockBtn) {
            const label = { mr: 'MR', bl: 'BL', br: 'BR', free: 'Free' }[dock] || 'MR';
            dockBtn.textContent = `Dock · ${label}`;
            dockBtn.classList.toggle('active', dock === 'free');
            dockBtn.title = 'Cycle: mid-right → bottom-right → bottom-left → free. Or drag the Player bar anytime.';
        }
        const pinBtn = document.getElementById('hud-pin');
        if (pinBtn) {
            pinBtn.classList.toggle('active', !!hudPinned);
            pinBtn.textContent = hudPinned ? 'Pinned' : 'Pin';
            pinBtn.title = hudPinned
                ? 'Always visible · click to allow auto-hide'
                : 'Keep controls always visible (no auto-hide)';
        }
    }

    function cycleHudDock() {
        if (stageLayoutMode !== 'dock') {
            stageLayoutMode = 'dock';
            applyStageLayoutNow();
            saveStageLayout();
            showScaleToast('Layout · Dock');
            return;
        }
        const order = ['mr', 'br', 'bl', 'free'];
        const i = order.indexOf(hudDock);
        hudDock = order[(i + 1) % order.length];
        if (hudDock === 'free' && hud.box) {
            const r = hud.box.getBoundingClientRect();
            const c = clampHudXY(r.left, r.top);
            hudX = c.x;
            hudY = c.y;
        }
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    /** Force free-float HUD into a grab-able on-screen spot. */
    function undockHudForMove() {
        if (!hud.box) return;
        const r = hud.box.getBoundingClientRect();
        hudDock = 'free';
        hudPinned = true;
        if (r.width > 0) {
            const c = clampHudXY(r.left, r.top);
            hudX = c.x;
            hudY = c.y;
        } else {
            hudX = Math.max(18, Math.round((window.innerWidth || 800) * 0.55));
            hudY = Math.max(18, Math.round((window.innerHeight || 600) * 0.35));
        }
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    function resetHudLayout() {
        hudDock = 'mr';
        hudPinned = true;
        hudX = 18;
        hudY = 18;
        hudW = null;
        hudH = null;
        hudTagsPerRow = 5;
        applyHudTagsPerRow(5);
        applyHudSize();
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    /** Edge/corner resize for player HUD (scale-aware layout px). */
    function initHudResize() {
        const el = hud.box;
        if (!el) return;
        const handles = el.querySelectorAll('.hud-rh[data-edge]');
        if (!handles.length) return;

        const minW = 280;
        const minH = 120;
        const getScale = () =>
            Math.max(CHROME_SCALE_MIN, Math.min(CHROME_SCALE_MAX, chromeScale || DEFAULT_CHROME_SCALE));

        handles.forEach((handle) => {
            const edge = handle.dataset.edge || '';
            handle.addEventListener('pointerdown', (e) => {
                if (e.button != null && e.button !== 0) return;
                e.preventDefault();
                e.stopPropagation();
                const scale = getScale() || 1;
                const rect = el.getBoundingClientRect();
                // Layout size under transform scale (origin top-left)
                const layoutW = Math.round(el.offsetWidth || rect.width / scale);
                const layoutH = Math.round(el.offsetHeight || rect.height / scale);
                const startX = e.clientX;
                const startY = e.clientY;
                const startLeft = rect.left;
                const startTop = rect.top;
                const startW = layoutW;
                const startH = layoutH;
                hudResizing = true;
                document.body.style.userSelect = 'none';
                const cursors = {
                    n: 'ns-resize', s: 'ns-resize', e: 'ew-resize', w: 'ew-resize',
                    ne: 'nesw-resize', sw: 'nesw-resize', nw: 'nwse-resize', se: 'nwse-resize',
                };
                document.body.style.cursor = cursors[edge] || 'nwse-resize';

                const onMove = (ev) => {
                    if (!hudResizing) return;
                    const dx = (ev.clientX - startX) / scale;
                    const dy = (ev.clientY - startY) / scale;
                    let nextW = startW;
                    let nextH = startH;
                    let nextLeft = startLeft;
                    let nextTop = startTop;
                    if (edge.includes('e')) nextW = startW + dx;
                    if (edge.includes('s')) nextH = startH + dy;
                    if (edge.includes('w')) {
                        nextW = startW - dx;
                        nextLeft = startLeft + (ev.clientX - startX);
                    }
                    if (edge.includes('n')) {
                        nextH = startH - dy;
                        nextTop = startTop + (ev.clientY - startY);
                    }
                    const maxW = Math.min(920, (window.innerWidth || 800) - 16);
                    const maxH = Math.min(860, (window.innerHeight || 600) - 16);
                    nextW = Math.round(Math.min(maxW, Math.max(minW, nextW)));
                    nextH = Math.round(Math.min(maxH, Math.max(minH, nextH)));
                    // If west/north hit min size, don't keep sliding the opposite edge
                    if (edge.includes('w')) {
                        const paintedW = nextW * scale;
                        nextLeft = startLeft + (startW * scale - paintedW);
                    }
                    if (edge.includes('n')) {
                        const paintedH = nextH * scale;
                        nextTop = startTop + (startH * scale - paintedH);
                    }
                    hudW = nextW;
                    hudH = nextH;
                    applyHudSize();
                    // Moving from any dock during resize → free float
                    hudDock = 'free';
                    hudPinned = true;
                    el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr');
                    el.classList.add('hud-dock-free', 'hud-pinned');
                    el.dataset.hudDock = 'free';
                    placeHudAt(nextLeft, nextTop);
                    revealHud();
                    ev.preventDefault();
                };
                const onUp = () => {
                    hudResizing = false;
                    document.body.style.userSelect = '';
                    document.body.style.cursor = '';
                    window.removeEventListener('pointermove', onMove, true);
                    window.removeEventListener('pointerup', onUp, true);
                    window.removeEventListener('pointercancel', onUp, true);
                    saveHudLayout();
                    applyHudLayout();
                };
                window.addEventListener('pointermove', onMove, true);
                window.addEventListener('pointerup', onUp, true);
                window.addEventListener('pointercancel', onUp, true);
                try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            });
        });
    }

    function initHudTagsPerRowControl() {
        const input = document.getElementById('hud-tags-per-row');
        if (!input || input.dataset.bound) return;
        input.dataset.bound = '1';
        applyHudTagsPerRow(hudTagsPerRow);
        const onChange = () => {
            applyHudTagsPerRow(input.value);
            saveHudLayout();
            revealHud();
        };
        input.addEventListener('input', onChange);
        input.addEventListener('change', onChange);
    }

    function toggleHudPin() {
        hudPinned = !hudPinned;
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    function initHudDrag() {
        const el = hud.box;
        if (!el) return;
        const handle = document.getElementById('hud-drag-handle') || el;
        let offX = 0;
        let offY = 0;
        let activePointerId = null;

        // Make the whole chrome bar an obvious drag target
        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.userSelect = 'none';

        const isBlockedTarget = (target) =>
            !!target?.closest?.(
                '.hud-chrome-actions button, .hud-controls button, .hud-controls input, .hud-rh, .hud-resize-handles, .hud-tags-row-ctrl, input, a, select, textarea, #hud-progress-track'
            );

        const paintFree = (x, y) => {
            hudDock = 'free';
            hudX = x;
            hudY = y;
            el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr');
            el.classList.add('hud-dock-free', 'hud-pinned');
            el.dataset.hudDock = 'free';
            hudPinned = true; // keep visible while free-dragging
            placeHudAt(x, y);
            const dockBtn = document.getElementById('hud-dock-cycle');
            if (dockBtn) {
                dockBtn.textContent = 'Dock · Free';
                dockBtn.classList.add('active');
            }
            const pinBtn = document.getElementById('hud-pin');
            if (pinBtn) {
                pinBtn.classList.add('active');
                pinBtn.textContent = 'Pinned';
            }
        };

        const onMove = (cx, cy) => {
            if (!hudDragging) return;
            const c = clampHudXY(cx - offX, cy - offY);
            paintFree(c.x, c.y);
        };

        const end = (e) => {
            if (!hudDragging) return;
            hudDragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            el.classList.remove('dragging');
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            window.removeEventListener('pointermove', onPointerMove, true);
            window.removeEventListener('pointerup', onPointerUp, true);
            window.removeEventListener('pointercancel', onPointerUp, true);
            window.removeEventListener('mousemove', onMouseMove, true);
            window.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
                try { el.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            saveHudLayout();
        };

        const onPointerMove = (e) => {
            if (!hudDragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            end(e);
        };
        const onMouseMove = (e) => { if (hudDragging) onMove(e.clientX, e.clientY); };
        const onMouseUp = () => end();

        const start = (cx, cy, target) => {
            if (isBlockedTarget(target)) return false;
            const r = el.getBoundingClientRect();
            hudDragging = true;
            offX = cx - r.left;
            offY = cy - r.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            el.classList.add('dragging');
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Convert current on-screen rect → free coords immediately
            paintFree(Math.round(r.left), Math.round(r.top));
            return true;
        };

        // Drag from the Player chrome bar (⋮⋮ / label / empty space)
        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (!start(e.clientX, e.clientY, e.target)) return;
            activePointerId = e.pointerId;
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            window.addEventListener('pointermove', onPointerMove, true);
            window.addEventListener('pointerup', onPointerUp, true);
            window.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });

        // Also allow dragging from the title row (bigger hit target)
        const track = el.querySelector('.hud-track');
        if (track) {
            track.style.cursor = 'grab';
            track.style.touchAction = 'none';
            track.addEventListener('pointerdown', (e) => {
                if (e.button != null && e.button !== 0) return;
                if (!start(e.clientX, e.clientY, e.target)) return;
                activePointerId = e.pointerId;
                try { track.setPointerCapture(e.pointerId); } catch (_) {}
                window.addEventListener('pointermove', onPointerMove, true);
                window.addEventListener('pointerup', onPointerUp, true);
                window.addEventListener('pointercancel', onPointerUp, true);
                e.preventDefault();
                e.stopPropagation();
            });
        }

        window.addEventListener('resize', () => {
            if (!hudDragging) applyHudLayout();
        });
    }

    async function loadHudLayout() {
        try {
            const res = await chrome.storage.local.get([
                'fafoHudDock', 'fafoHudPinned', 'fafoHudX', 'fafoHudY',
                'fafoHudW', 'fafoHudH', 'fafoHudTagsPerRow',
            ]);
            // First run / no saved dock → mid-right (default)
            if (['mr', 'bl', 'br', 'free'].includes(res.fafoHudDock)) hudDock = res.fafoHudDock;
            else hudDock = 'mr';
            // Default pinned ON so controls stay available
            if (typeof res.fafoHudPinned === 'boolean') hudPinned = res.fafoHudPinned;
            else hudPinned = true;
            if (typeof res.fafoHudX === 'number') hudX = res.fafoHudX;
            if (typeof res.fafoHudY === 'number') hudY = res.fafoHudY;
            if (typeof res.fafoHudW === 'number' && res.fafoHudW >= 200) hudW = Math.round(res.fafoHudW);
            if (typeof res.fafoHudH === 'number' && res.fafoHudH >= 100) hudH = Math.round(res.fafoHudH);
            if (typeof res.fafoHudTagsPerRow === 'number') {
                hudTagsPerRow = Math.max(2, Math.min(12, Math.round(res.fafoHudTagsPerRow)));
            }
        } catch (_) {
            hudDock = 'mr';
            hudPinned = true;
        }
        applyHudTagsPerRow(hudTagsPerRow);
        applyHudSize();
        applyHudLayout();
        try {
            chrome.storage.onChanged.addListener((changes, area) => {
                if (area !== 'local' || hudDragging) return;
                let dirty = false;
                if (changes.fafoHudDock && ['mr', 'bl', 'br', 'free'].includes(changes.fafoHudDock.newValue)) {
                    hudDock = changes.fafoHudDock.newValue;
                    dirty = true;
                }
                if (changes.fafoHudPinned && typeof changes.fafoHudPinned.newValue === 'boolean') {
                    hudPinned = changes.fafoHudPinned.newValue;
                    dirty = true;
                }
                if (changes.fafoManualRepeat) {
                    manualRepeat = !!changes.fafoManualRepeat.newValue;
                    updateRepeatButton();
                    refreshLoopMode();
                }
                if (dirty) {
                    applyHudLayout();
                    revealHud();
                }
            });
        } catch (_) {}
    }

    function revealHud() {
        if (!hud.box || cfg.layout !== 'cinema') return;
        hud.box.classList.add('hud-visible');
        hud.box.classList.remove('hud-idle');
        clearTimeout(hudIdleTimer);
        // Pinned, free-float, or Options "always show HUD": stay visible
        if (hudPinned || hudDock === 'free' || cfg.hudAlwaysShow) return;
        const idleMs = Math.max(1500, Math.min(20000, Number(cfg.hudIdleMs) || HUD_IDLE_MS));
        hudIdleTimer = setTimeout(() => {
            if (!hud.box.matches(':hover') && !hudPinned && hudDock !== 'free') {
                hud.box.classList.add('hud-idle');
            }
            hud.box.classList.remove('hud-visible');
        }, idleMs);
    }

    function initHudAutoHide() {
        if (cfg.layout === 'cinema') revealHud();
        else if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
    }

    function updateEmptyState() {
        if (!emptyState) return;
        emptyState.classList.toggle('hidden', !libraryEmpty || cfg.layout !== 'cinema');
    }

    function toggleFullscreen() {
        document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    }

    function togglePause() {
        if (cfg.layout === 'collage') {
            isPaused = !isPaused;
            ui.clock.style.opacity = isPaused ? 0.5 : 1;
            if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
            return;
        }

        // Wall / grid: pause or resume every tile
        if (wallModeActive || (cfg.layout === 'grid' && getWallVideos().length)) {
            isPaused = !isPaused;
            ui.clock.style.opacity = isPaused ? 0.5 : 1;
            if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
            const vids = getWallVideos();
            if (!mainVideo) setWallPrimaryVideo(vids[0]);
            vids.forEach((v) => {
                try {
                    if (isPaused) v.pause();
                    else v.play().catch(() => {});
                } catch (_) {}
            });
            if (!isPaused) applyWallAudio();
            revealHud();
            return;
        }

        if (!mainVideo) return;

        // At end while looping (untagged / skip-tagged): restart — never auto-advance on Space
        if (mainVideo.ended && (isPaused || mainVideo.paused)) {
            if (isClipLoopMode()) {
                try {
                    mainVideo.currentTime = 0;
                    applyPlaybackSpeed();
                    isPaused = false;
                    ui.clock.style.opacity = 1;
                    if (hud.play) hud.play.textContent = '⏸';
                    mainVideo.play().catch(() => {});
                    if (ambienceVideo) {
                        ambienceVideo.currentTime = 0;
                        ambienceVideo.play().catch(() => {});
                    }
                    window.FAFOMeta?.notifyEndNeedsTag?.();
                } catch (_) {}
                revealHud();
                return;
            }
            // Tagged & not looping — go to next clip
            loopCount = 0;
            if (playlist.length) {
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            isPaused = false;
            ui.clock.style.opacity = 1;
            if (hud.play) hud.play.textContent = '⏸';
            playNext({ instant: true });
            revealHud();
            return;
        }

        isPaused = !isPaused;
        ui.clock.style.opacity = isPaused ? 0.5 : 1;
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';

        if (isPaused) {
            mainVideo.pause();
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.pause();
        } else {
            consecutiveErrors = 0;
            clearPlayOverlay();
            // If we stalled mid-load, restart the current item cleanly
            if (!mainVideo.src || mainVideo.error || mainVideo.readyState < 2) {
                playNext({ instant: true, force: true });
            } else {
                mainVideo.play().catch((e) => {
                    console.warn('Resume play failed, reloading clip', e);
                    playNext({ instant: true, force: true });
                });
                if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.play().catch(() => {});
            }
        }
        syncParticlePerformance();
        revealHud();
    }

    function getTrackName(item) {
        if (!item) return '—';
        if (item.name) return item.name;
        if (item.handle?.name) return item.handle.name;
        if (item.url) return item.url.split('/').pop().split('?')[0] || 'Stream';
        return 'Unknown';
    }

    function updateHUD() {
        if (!hud.box) return;
        const item = playlist[currentIdx];
        if (hud.title) hud.title.textContent = getTrackName(item);
        if (hud.index) hud.index.textContent = playlist.length ? `${currentIdx + 1} / ${playlist.length}` : '0 / 0';
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(cfg.playbackSpeed || 1);
        updateHudMuteIcon();
        const isVideo = item?.type === 'video' && cfg.layout === 'cinema';
        if (hud.progressWrap) hud.progressWrap.classList.toggle('hidden', !isVideo);
        if (!isVideo && hud.timeCurrent) hud.timeCurrent.textContent = '0:00';
        if (!isVideo && hud.timeTotal) hud.timeTotal.textContent = '0:00';
        updateLoopHudChip();
        updateEmptyState();
    }

    function updateHudMuteIcon() {
        if (!hud.mute) return;
        let muted;
        if (wallModeActive || (cfg.layout === 'grid' && getWallVideos().length)) {
            const vol = cfg.volume ?? 0.7;
            muted = wallAudioMuted || vol === 0 || !userUnlockedAudio;
        } else {
            muted = !mainVideo || mainVideo.muted || mainVideo.volume === 0;
        }
        hud.mute.textContent = muted ? '🔇' : '🔊';
    }

    function startProgressBar() {
        if (progressInterval) clearInterval(progressInterval);
        if (!mainVideo) return;
        mainVideo.removeEventListener('timeupdate', updateProgressUI);
        mainVideo.addEventListener('timeupdate', updateProgressUI);
        updateProgressUI();
    }

    function bindHudReveal(el, fn) {
        if (!el) return;
        el.addEventListener('click', () => { revealHud(); fn(); });
    }

    function initHudControls() {
        bindHudReveal(hud.prev, () => skipTrack(-1));
        bindHudReveal(hud.next, () => skipTrack(1));
        bindHudReveal(hud.play, () => togglePause());
        bindHudReveal(hud.shuffle, () => toggleShuffle());
        bindHudReveal(hud.speedDown, () => changeSpeed(-1));
        bindHudReveal(hud.speedUp, () => changeSpeed(1));
        if (hud.speed) hud.speed.onclick = () => { revealHud(); setPlaybackSpeed(1); };
        bindHudReveal(document.getElementById('hud-repeat'), () => toggleManualRepeat());
        bindHudReveal(document.getElementById('hud-extra-apply'), () => {
            const bank = window.FAFOMeta?.getExtraLiveBank?.() ?? 0;
            window.FAFOMeta?.applyExtraTagBank?.(bank);
        });
        bindHudReveal(hud.mute, () => toggleMute());
        bindHudReveal(hud.pip, () => togglePiP());
        bindHudReveal(hud.fs, () => toggleFullscreen());
        bindHudReveal(document.getElementById('hud-wall-mode'), () => toggleWallMode());
        // Wall config: count (2/6/8), gap density, scalability flags
        const wallCfg = document.getElementById('hud-wall-config');
        wallCfg?.querySelectorAll('[data-wall-count]')?.forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                revealHud();
                const n = parseInt(chip.getAttribute('data-wall-count'), 10);
                if (!WALL_COUNTS.includes(n)) return;
                if (!wallModeActive) {
                    wallCount = n;
                    wallPrefs.count = n;
                    saveWallPrefs();
                    toggleWallMode();
                } else {
                    setWallCount(n);
                }
            });
        });
        wallCfg?.querySelectorAll('[data-wall-gap]')?.forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                revealHud();
                const g = parseFloat(chip.getAttribute('data-wall-gap'));
                if (!Number.isFinite(g)) return;
                if (!wallModeActive) {
                    wallPrefs.gapScale = Math.max(0.4, Math.min(1.8, g));
                    saveWallPrefs();
                    toggleWallMode();
                } else {
                    setWallGapScale(g);
                }
            });
        });
        wallCfg?.querySelectorAll('[data-wall-flag]')?.forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                revealHud();
                const key = chip.getAttribute('data-wall-flag');
                if (!key) return;
                const next = !wallPrefs[key];
                if (!wallModeActive) {
                    wallPrefs[key] = next;
                    saveWallPrefs();
                    updateWallModeHudBtn();
                } else {
                    setWallFlag(key, next);
                }
            });
        });
        bindHudReveal(document.getElementById('hud-video-place'), () => {
            toggleVideoStageLock();
            updateVideoPlaceHudBtn();
        });
        bindHudReveal(document.getElementById('hud-vid-zoom-out'), () => nudgeVideoZoom(-1));
        bindHudReveal(document.getElementById('hud-vid-zoom-in'), () => nudgeVideoZoom(1));
        bindHudReveal(document.getElementById('hud-gui-zoom-out'), () => nudgeChromeScale(-1));
        bindHudReveal(document.getElementById('hud-gui-zoom-in'), () => nudgeChromeScale(1));
        bindHudReveal(document.getElementById('hud-playlist'), () => openPlaylistPicker());
        if (hud.volume) {
            hud.volume.value = Math.round((cfg.volume ?? 0.7) * 100);
            hud.volume.addEventListener('input', () => {
                revealHud();
                setVolume(hud.volume.value / 100);
            });
        }
        initProgressSeek();
        const helpClose = document.getElementById('help-close');
        if (helpClose) helpClose.onclick = () => shortcutHelp?.classList.add('hidden');
        if (hud.box) {
            hud.box.addEventListener('mouseenter', revealHud);
            hud.box.addEventListener('mousemove', revealHud);
        }
        if (hud.progressTrack) {
            hud.progressTrack.addEventListener('mousedown', revealHud);
        }
        // Undock / pin / always-on-top
        document.getElementById('hud-dock-cycle')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cycleHudDock();
        });
        document.getElementById('hud-stage-layout')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cycleStageLayout();
            revealHud();
        });
        document.getElementById('hud-stage-width')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cycleStageWidth();
            revealHud();
        });
        document.getElementById('hud-pin')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleHudPin();
        });
        initHudDrag();
        initHudResize();
        initHudTagsPerRowControl();
        loadHudLayout().then(() => revealHud());
        chrome.storage.local.get(['fafoManualRepeat'], (res) => {
            manualRepeat = !!res.fafoManualRepeat;
            updateRepeatButton();
            refreshLoopMode();
        });
        // E-set UI lives in FAFOMeta but render after a tick so module is ready
        setTimeout(() => window.FAFOMeta?.renderExtraTagHud?.(), 200);
        updateHUD();
    }

    // --- 4. LIBRARY MANAGEMENT ---

    function toPlaylistItem(entry, typeHint) {
        if (!entry) return null;
        const unwrapped = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(entry) : null;
        if (unwrapped?.handle) {
            return {
                type: typeHint || (unwrapped.storeName === 'photos' ? 'photo' : 'video'),
                handle: unwrapped.handle,
                name: unwrapped.name,
            };
        }
        if (entry.handle) {
            return { type: typeHint || 'video', handle: entry.handle, name: entry.name };
        }
        if (typeof entry.getFile === 'function' || entry.kind === 'file') {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        if (entry instanceof File) {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        return null;
    }

    async function buildPlaylist() {
        playlist = [];
        libraryEmpty = false;
        
        // 1. PLAYLIST MODE: manual or smart
        if (cfg.activePlaylistId && cfg.activePlaylistId !== 'all' && db) {
            try {
                const tx = db.transaction('playlists', 'readonly');
                const store = tx.objectStore('playlists');
                const pl = await new Promise(res => {
                    const req = store.get(cfg.activePlaylistId);
                    req.onsuccess = () => res(req.result);
                    req.onerror = () => res(null);
                });

                if (pl && window.FAFOLibrary?.resolvePlaylist) {
                    const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
                    const resolved = await FAFOLibrary.resolvePlaylist(db, pl, fafoMediaMeta);
                    for (const item of resolved) {
                        playlist.push({
                            type: item.type,
                            handle: item.handle,
                            name: item.name,
                        });
                    }
                } else if (pl?.items?.length) {
                    for (const itemRef of pl.items) {
                        const raw = await getHandleByKey(itemRef.store || itemRef.storeName, itemRef.key);
                        const item = toPlaylistItem(raw, (itemRef.store || itemRef.storeName) === 'photos' ? 'photo' : 'video');
                        if (item) playlist.push(item);
                    }
                }
            } catch (e) { console.warn('Failed to load playlist', e); }
        } 
        
        // 2. FALLBACK TO ALL IF EMPTY OR 'ALL' MODE
        if (playlist.length === 0) {
            if (cfg.useLocal) {
                const videos = await getHandles('videos');
                for (const h of videos) {
                    const item = toPlaylistItem(h, 'video');
                    if (item) playlist.push(item);
                }
            }
            if (cfg.usePhotos) {
                const photos = await getHandles('photos');
                for (const h of photos) {
                    const item = toPlaylistItem(h, 'photo');
                    if (item) playlist.push(item);
                }
            }
            // Bundled demo library is public-only — never leak into private section
            const privateMode = !!window.FAFOMeta?.isPrivateSpaceActive?.();
            if (!privateMode) {
                const bundled = await loadBundledLibrary();
                if (bundled.length > 0) playlist.push(...bundled);
            }
        }
        
        // 3. FINAL FALLBACK
        if (playlist.length === 0) {
            const privateMode = !!window.FAFOMeta?.isPrivateSpaceActive?.();
            if (privateMode) {
                // Empty private vault — no demo / no public fallback
                libraryEmpty = true;
                playlist = [];
            } else if (cfg.urls && cfg.urls.length > 0) {
                playlist = cfg.urls.map(u => ({type: 'video', url: u}));
            } else {
                libraryEmpty = true;
                playlist = [{type: 'video', url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm', isDemo: true}];
            }
        }
        
        if (cfg.shuffle) shuffleInPlace(playlist);
        updateEmptyState();
        maybeShowRestoreBanner();
    }

    // Helper to get specific item for playlist
    async function getHandleByKey(storeName, key) {
        return new Promise(res => {
            try {
                const tx = db.transaction(storeName, 'readonly');
                const req = tx.objectStore(storeName).get(key);
                req.onsuccess = () => res(req.result);
                req.onerror = () => res(null);
            } catch(e) { res(null); }
        });
    }

    async function loadBundledLibrary() {
        try {
            const resp = await fetch('library.json');
            if (!resp.ok) return [];
            const files = await resp.json();
            return files.map(f => {
                const path = f.replace(/^videos\//i, 'Videos/').replace(/^photos\//i, 'Photos/');
                return {
                    type: path.match(/\.(jpg|jpeg|png|webp|gif)$/i) ? 'photo' : 'video',
                    url: path,
                    isBundled: true
                };
            });
        } catch (e) {
            return [];
        }
    }

    let restoreBannerEl = null;

    function removeRestoreBanner() {
        const modal = document.getElementById('fafo-perm-modal');
        if (modal) modal.classList.add('hidden');
        restoreBannerEl = null;
        permissionWarned = false;
    }

    function isPermissionFailure(reason) {
        const msg = String(reason && (reason.message || reason.name || reason) || '').toLowerCase();
        return msg.includes('permission') || msg.includes('no source');
    }

    function haltForPermissionRestore() {
        clearTimeout(playFailTimer);
        playToken++;
        consecutiveErrors = 0;
        mediaLoading = false;
        isPaused = true;
        clearPlayOverlay();
        if (hud.play) hud.play.textContent = '▶';
        if (hud.title) hud.title.textContent = 'Folders need permission';
        revealHud();
        showRestoreBanner();
    }

    function ensurePermModal() {
        let modal = document.getElementById('fafo-perm-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'fafo-perm-modal';
            modal.className = 'fafo-perm-modal hidden';
            modal.setAttribute('role', 'dialog');
            modal.setAttribute('aria-labelledby', 'fafo-perm-title');
            modal.innerHTML = `
            <div class="fafo-perm-card">
                <h2 id="fafo-perm-title">Folder access needed</h2>
                <p id="fafo-perm-copy">Saved media folders need a refresh. Click Restore Access. If Chrome shows Allow, use it. If no prompt appears, setup already allowed this site and playback continues.</p>
                <div class="fafo-perm-actions">
                    <button type="button" id="fafo-perm-restore">Restore Access</button>
                    <button type="button" id="fafo-perm-later">Not now</button>
                </div>
                <p class="fafo-perm-hint">If Chrome asks, click Allow. If it does not ask, your folders were already allowed at setup — Restore still continues.</p>
            </div>`;
            document.body.appendChild(modal);
        }
        if (modal.dataset.bound === '1') return modal;
        modal.dataset.bound = '1';
        modal.querySelector('#fafo-perm-restore')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            restoreLibraryAccessFromBanner();
        });
        modal.querySelector('#fafo-perm-later')?.addEventListener('click', (e) => {
            e.preventDefault();
            modal.classList.add('hidden');
        });
        modal.addEventListener('click', (e) => {
            if (e.target === modal) modal.classList.add('hidden');
        });
        return modal;
    }

    async function resumeAfterRestore() {
        removeRestoreBanner();
        await buildPlaylist();
        clearTimeout(playFailTimer);
        playToken++;
        consecutiveErrors = 0;
        isPaused = false;
        if (hud.play) hud.play.textContent = '⏸';
        if (typeof initLayout === 'function') initLayout();
        else if (typeof playNext === 'function') playNext({ instant: true, force: true });
    }

    async function restoreLibraryAccessFromBanner() {
        if (!db || !window.FAFOLibrary) {
            window.location.href = 'options.html';
            return;
        }
        const restoreBtn = document.getElementById('fafo-perm-restore');
        const copy = document.getElementById('fafo-perm-copy');
        try {
            clearTimeout(playFailTimer);
            playToken++;
            consecutiveErrors = 0;
            userUnlockedAudio = true;
            if (restoreBtn) {
                restoreBtn.textContent = 'Checking folders…';
                restoreBtn.disabled = true;
            }
            if (copy) {
                copy.textContent = 'Checking saved folders. If Chrome asks, click Allow. If no prompt appears, your setup already allowed this site — we will continue.';
            }

            const st = await FAFOLibrary.libraryAccessStatus(db).catch(() => null);
            const alreadyOk = st && st.folderGranted > 0 && st.folderPrompt === 0 && st.folderDenied === 0 && st.sampleBad === 0;
            if (alreadyOk) {
                if (copy) copy.textContent = 'Folders already allowed — no Chrome prompt needed.';
                await resumeAfterRestore();
                console.info('Library access already granted', st);
                return;
            }

            const r = await FAFOLibrary.restoreAccess(db);
            const readable = (r.grantedFolders || 0) + (r.grantedFiles || 0);
            if (copy) {
                copy.textContent = readable
                    ? 'Access granted — starting playback.'
                    : 'No extra Chrome prompt. Using existing folder access — starting playback.';
            }
            const folders = await FAFOLibrary.listFolders(db);
            if (folders.length) {
                try {
                    await FAFOLibrary.resyncAllFolders(db, { skipPermission: true });
                } catch (e) {
                    console.warn('resync after restore', e);
                }
            }
            await resumeAfterRestore();
            console.info('Library access restored', r);
        } catch (e) {
            console.warn(e);
            // Don't hang the tab: if we can still build a playlist, play it
            try {
                await resumeAfterRestore();
                return;
            } catch (_) { /* fall through */ }
            if (restoreBtn) {
                restoreBtn.disabled = false;
                restoreBtn.textContent = 'Try Restore Access again';
            }
            if (copy) copy.textContent = 'Could not finish restore. Click Restore Access again. If Chrome never asks, your folders may already be allowed — try Not now and play.';
        }
    }

    function showRestoreBanner(msg) {
        permissionWarned = true;
        const modal = ensurePermModal();
        const copy = document.getElementById('fafo-perm-copy');
        if (copy && msg) copy.textContent = msg;
        const restoreBtn = document.getElementById('fafo-perm-restore');
        if (restoreBtn) {
            restoreBtn.disabled = false;
            restoreBtn.textContent = 'Restore Access';
        }
        modal.classList.remove('hidden');
        restoreBannerEl = modal;
    }

    async function maybeShowRestoreBanner() {
        if (!db || !window.FAFOLibrary || permissionWarned) return;
        try {
            const st = await FAFOLibrary.libraryAccessStatus(db);
            if (st.needsRestore && (st.folders > 0 || st.sampleBad > 0)) {
                showRestoreBanner('Chrome needs Allow on your saved media folders. Click Restore Access — you do not have to re-pick folders in Options.');
            }
        } catch (_) {}
    }

    async function getSrc(item) {
        if (item.url) return item.url;
        if (item.handle) {
            if (item.handle instanceof File) {
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(item.handle);
                return currentBlobUrl;
            }
            try {
                if (window.FAFOLibrary) {
                    const ok = await FAFOLibrary.ensurePermission(item.handle, 'read');
                    if (!ok) throw new Error('permission denied');
                }
                const file = await item.handle.getFile();
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(file);
                removeRestoreBanner();
                return currentBlobUrl;
            } catch (e) {
                const err = new Error('permission denied');
                err.code = 'PERMISSION';
                haltForPermissionRestore();
                throw err;
            }
        }
        return null;
    }

    async function getHandles(store) {
        if (!db) return [];
        try {
            // Isolated libraries: public vs private vault never mix
            const space = window.FAFOMeta?.isPrivateSpaceActive?.() ? 'private' : 'public';
            const vaultId = space === 'private'
                ? (window.FAFOMeta?.getActiveVaultId?.() || 'default')
                : undefined;
            if (window.FAFOLibrary?.getMediaForSpace) {
                const entries = await FAFOLibrary.getMediaForSpace(db, store, space, { vaultId });
                return entries.map((e) => ({
                    handle: e.handle,
                    name: e.name,
                    size: e.size,
                    lastModified: e.lastModified,
                    parentFolderId: e.parentFolderId,
                    space: e.space,
                    vaultId: e.vaultId,
                    storeName: store,
                }));
            }
            const tx = db.transaction(store, 'readonly');
            const req = tx.objectStore(store).getAll();
            return new Promise(res => req.onsuccess = () => res(req.result || []));
        } catch(e) { return []; }
    }
    
    function getObjectFitFromConfig() {
        switch(cfg.scaling) {
            case 'scale-cover': return 'cover';
            case 'scale-contain': return 'contain';
            case 'scale-capped': return 'capped'; 
            case 'scale-center': return 'none';
            default: return 'contain';
        }
    }

    // --- 5. LAYOUT ENGINES ---

    function initLayout() {
        scene.innerHTML = '';
        if (collageInterval) clearInterval(collageInterval);
        if (photoTimeout) clearTimeout(photoTimeout);
        if (progressInterval) clearInterval(progressInterval);
        if (neonEngine) neonEngine.disconnectAudio();
        revokeCurrentBlob();

        if (cfg.layout !== 'cinema') {
            overlay.style.opacity = '0';
            if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
        } else {
            initHudAutoHide();
        }

        scene.className = `layout-${cfg.layout}`;
        scene.removeAttribute('style'); 
        
        if (cfg.layout === 'grid') initGrid();
        else if (cfg.layout === 'carousel') initCarousel();
        else if (cfg.layout === 'collage') initCollage(); 
        else initCinema();
        try { updateWallModeHudBtn(); } catch (_) {}
    }

    function initCinema() {
        // Dual-video ambilight (2× decode + huge CSS blur) is the #1 lag source on 4K.
        const useAmbiVideo = cfg.ambiMode === 'blur'
            && !cfg.disableAmbience
            && !cfg.performanceMode;

        if (useAmbiVideo) {
            ambienceVideo = document.createElement('video');
            ambienceVideo.className = 'ambience';
            ambienceVideo.muted = true;
            ambienceVideo.loop = true;
            ambienceVideo.playsInline = true;
            // Prefer cheaper blur in normal mode; still expensive — keep scale modest
            const blurPx = Math.min(cfg.ambiBlur || 5, 12);
            ambienceVideo.style.filter = `blur(${blurPx}px) brightness(${cfg.ambiOpacity}) saturate(1.1)`;
            ambienceVideo.style.transform = `translate(-50%, -50%) scale(${cfg.ambiScale}) translateZ(0)`;
            scene.appendChild(ambienceVideo);
        } else {
            scene.style.backgroundColor = cfg.accentColor || '#000';
            ambienceVideo = null;
        }

        const stage = ensureCinemaStage();
        mainVideo = document.createElement('video');
        mainVideo.id = 'bg-video';
        mainVideo.playsInline = true;
        mainVideo.autoplay = true;
        // Prefer hardware decode paths; avoid software filter on the video element itself
        try { mainVideo.disableRemotePlayback = true; } catch (_) {}
        applyVideoGpuHints(mainVideo);
        // Video is locked inside the stage; stage is full-screen or free-placed
        applyCinemaObjectFit(mainVideo, objectFitFromConfig());
        (stage || scene).appendChild(mainVideo);
        loadVideoStageLayout();

        playNext();
        updateHUD();
        
        mainVideo.addEventListener('play', syncParticlePerformance);
        mainVideo.addEventListener('pause', syncParticlePerformance);
        mainVideo.addEventListener('play', () => applyPlaybackSpeed());
        const reassertFit = () => {
            applyPlaybackSpeed();
            try {
                applyCinemaObjectFit(cinemaMediaEl() || mainVideo, objectFitFromConfig());
            } catch (_) {}
        };
        mainVideo.addEventListener('loadeddata', reassertFit);
        mainVideo.addEventListener('loadedmetadata', reassertFit);
        mainVideo.addEventListener('resize', reassertFit);

        mainVideo.onended = () => {
            if (mediaLoading || isSeeking || Date.now() < suppressEndedUntil) return;

            // Continuous loop fallback when native loop doesn't fire or was briefly false
            if (isClipLoopMode() || manualRepeat) {
                mainVideo.loop = true;
                if (ambienceVideo) ambienceVideo.loop = true;
                restartClipFromStart('onended');
                if (window.FAFOMeta?.isUntagged?.()) {
                    window.FAFOMeta.notifyEndNeedsTag?.();
                }
                updateLoopHudChip();
                return;
            }

            if (++loopCount >= cfg.loops) {
                loopCount = 0;
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            playNext();
        };

        // NOTE: Do NOT restart on every pause — loadAndPlayVideo intentionally pauses
        // while swapping sources; that was racing Chrome and killing playback.

        const sync = () => {
            if(ambienceVideo && Math.abs(mainVideo.currentTime - ambienceVideo.currentTime) > 0.5) 
                ambienceVideo.currentTime = mainVideo.currentTime;
        };
        
        if(ambienceVideo) {
            mainVideo.addEventListener('play', () => {
                if (mediaLoading) return;
                ambienceVideo.play().catch(()=>{});
            });
            mainVideo.addEventListener('pause', () => {
                if (mediaLoading) return;
                ambienceVideo.pause();
            });
            mainVideo.addEventListener('timeupdate', sync);
        }
    }

    function clearPlayOverlay() {
        if (overlay) overlay.style.opacity = '0';
    }

    function resetPlaybackErrors() {
        consecutiveErrors = 0;
    }

    function showRetryPlaybackBanner(msg) {
        // Do not steal the permission Restore popup
        const permModal = document.getElementById('fafo-perm-modal');
        if (permModal && !permModal.classList.contains('hidden')) return;
        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:96vw;';
        const retry = document.createElement('button');
        retry.textContent = msg || '⚠️ Playback stuck — click to retry';
        retry.style.cssText = 'background:#1565c0;color:white;padding:12px 18px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.5);';
        retry.onclick = () => {
            userUnlockedAudio = true;
            consecutiveErrors = 0;
            playToken++; // cancel in-flight
            clearTimeout(playFailTimer);
            try { wrap.remove(); } catch (_) {}
            restoreBannerEl = null;
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
            playNext({ instant: true, force: true });
        };
        const restore = document.createElement('button');
        restore.textContent = 'Restore library access';
        restore.style.cssText = 'background:#d32f2f;color:white;padding:12px 14px;border:none;border-radius:8px;cursor:pointer;font-weight:bold;';
        restore.onclick = () => restoreLibraryAccessFromBanner();
        const opt = document.createElement('button');
        opt.textContent = 'Options';
        opt.style.cssText = 'background:#222;color:#fff;padding:12px 14px;border:1px solid #555;border-radius:8px;cursor:pointer;';
        opt.onclick = () => { window.location.href = 'options.html'; };
        wrap.appendChild(retry);
        wrap.appendChild(restore);
        wrap.appendChild(opt);
        document.body.appendChild(wrap);
        restoreBannerEl = retry;
        restoreBannerEl._wrap = wrap;
        restoreBannerEl.remove = () => { wrap.remove(); };
    }

    /** Advance after a hard failure so we never freeze on one bad clip / autoplay reject. */
    function advanceAfterPlayFailure(reason, token) {
        // Ignore failures from superseded playNext calls (the main cascade bug)
        if (token != null && token !== playToken) return;
        if (isPermissionFailure(reason)) {
            haltForPermissionRestore();
            return;
        }

        consecutiveErrors++;
        const msg = reason && (reason.message || reason.name || reason);
        console.warn('Playback failure:', msg || reason, `(streak ${consecutiveErrors})`);
        clearPlayOverlay();
        if (!playlist.length) return;

        pushPlayHistory(currentIdx);
        currentIdx = findNextEligibleIndex(currentIdx, 1);

        clearTimeout(playFailTimer);
        if (consecutiveErrors > 6) {
            consecutiveErrors = 0;
            isPaused = true;
            if (hud.play) hud.play.textContent = '▶';
            if (hud.title) hud.title.textContent = 'Playback stuck — click Retry';
            revealHud();
            showRetryPlaybackBanner('⚠️ Playback stuck — click to retry current library');
            return;
        }
        playFailTimer = setTimeout(() => {
            if (token != null && token !== playToken) return;
            playNext({ instant: true });
        }, 80);
    }

    /**
     * Load a blob/url into the video and start playback.
     * Starts muted for reliable Chrome new-tab autoplay; unmutes after a user gesture.
     */
    async function loadAndPlayVideo(video, src, token) {
        if (!video) throw new Error('no video element');
        if (token !== playToken) return;

        mediaLoading = true;
        suppressEndedUntil = Date.now() + 800;

        try {
            try { video.pause(); } catch (_) {}

            // Full reset avoids sticky error state from a previous failed blob
            try {
                video.removeAttribute('src');
                video.load();
            } catch (_) {}

            if (token !== playToken) return;

            video.src = src;
            video.style.background = '';
            try { video.preload = 'auto'; } catch (_) {}
            // Apply loop BEFORE play so Chrome native loop works from the first frame
            const shouldLoop = isClipLoopMode();
            video.loop = shouldLoop;
            // New-tab pages: muted autoplay is allowed; sound after click/key
            if (!userUnlockedAudio) {
                video.muted = true;
            }
            applyPlaybackSpeed();

            // Kick the network/fetch; play() will wait for enough data
            try { video.load(); } catch (_) {}

            if (token !== playToken) return;

            // Prefer canplay, but don't hard-fail slow 4K disks — try play either way
            await new Promise((resolve) => {
                let done = false;
                const finish = () => {
                    if (done) return;
                    done = true;
                    video.removeEventListener('canplay', finish);
                    video.removeEventListener('loadeddata', finish);
                    video.removeEventListener('error', finish);
                    clearTimeout(timer);
                    // Session resume seek
                    try {
                        const sk = video.__fafoResumeSeek;
                        if (sk != null && sk > 0.5 && Number.isFinite(video.duration) && sk < video.duration - 0.25) {
                            video.currentTime = sk;
                        }
                        delete video.__fafoResumeSeek;
                    } catch (_) {}
                    resolve();
                };
                const timer = setTimeout(finish, 4000); // allow slower local disks
                video.addEventListener('canplay', finish);
                video.addEventListener('loadeddata', finish);
                video.addEventListener('error', finish);
                if (video.readyState >= 2) finish();
            });

            if (token !== playToken) return;

            if (video.error) {
                const code = video.error.code;
                throw new Error(`media error code ${code}`);
            }

            // Re-assert loop right before play (src change can clear it in some cases)
            video.loop = isClipLoopMode();

            try {
                await video.play();
            } catch (e) {
                if (e && e.name === 'AbortError') throw e;
                // Last resort: force muted and try once more (Chrome new-tab autoplay)
                video.muted = true;
                updateHudMuteIcon();
                await video.play();
            }

            if (token !== playToken) return;

            // Restore volume if user already interacted
            if (userUnlockedAudio && video.muted && cfg.volume > 0 && !video.paused) {
                // Leave muted state alone if user had muted via HUD; only unmute after gesture unlock
                // when volume > 0 — optional soft unmute:
                // video.muted = false;
            }
        } finally {
            // Only clear loading if this token still owns the player
            if (token === playToken) {
                mediaLoading = false;
                suppressEndedUntil = Date.now() + 300;
            }
        }
    }

    async function playNext(opts = {}) {
        if (!mainVideo && cfg.layout === 'cinema') {
            // Layout not ready yet
            return;
        }

        // Cancel any pending fail-advance from a previous streak
        clearTimeout(playFailTimer);
        const token = ++playToken;
        mediaLoading = true;
        suppressEndedUntil = Date.now() + 800;

        if (photoTimeout) clearTimeout(photoTimeout);
        if (overlay) overlay.style.opacity = '1';

        // Manual skip: no 250ms fade delay
        if (!opts.instant) {
            await new Promise(r => setTimeout(r, 250));
        }
        if (token !== playToken) {
            if (token === playToken) mediaLoading = false;
            return;
        }

        const item = playlist[currentIdx];
        if (!item) {
            mediaLoading = false;
            clearPlayOverlay();
            return;
        }

        // Show title immediately so UI feels alive even while file opens
        updateHUD();

        // Bind tags/sync identity BEFORE file open — so Sync/tags work even if
        // Chrome blocks getFile() (permissions). Previously bind ran only after src.
        try {
            if (window.FAFOMeta?.bindToItem) {
                await window.FAFOMeta.bindToItem(item, currentIdx);
            }
        } catch (e) { console.warn('FAFOMeta bind', e); }
        if (token !== playToken) return;
        // Optional resume seek (session restore)
        if (opts.seek != null && Number(opts.seek) > 0.5) {
            mainVideo.__fafoResumeSeek = Number(opts.seek);
        } else {
            try { delete mainVideo.__fafoResumeSeek; } catch (_) {}
        }
        try { window.FAFOLibraryDoctor?.scheduleNextUp?.(); } catch (_) {}
        try { window.FAFOSession?.scheduleSave?.(); } catch (_) {}

        let src = null;
        try {
            src = await getSrc(item);
        } catch (e) {
            if (token !== playToken) return;
            mediaLoading = false;
            if (isPermissionFailure(e)) haltForPermissionRestore();
            else advanceAfterPlayFailure(e, token);
            return;
        }
        if (token !== playToken) return;

        if (!src) {
            mediaLoading = false;
            haltForPermissionRestore();
            return;
        }

        const fileName = item.handle?.name || (item.url ? item.url.split('/').pop() : 'unknown');
        const overrides = cfg.overrides?.[fileName] || {};

        if (!mainVideo) {
            mediaLoading = false;
            clearPlayOverlay();
            return;
        }

        const vol = overrides.volume !== undefined ? overrides.volume : cfg.volume;
        mainVideo.volume = vol;
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        // Keep loop attribute live for continuous repeat (Q / untagged / skip-tagged)
        const shouldLoop = isClipLoopMode();
        mainVideo.loop = shouldLoop;
        if (ambienceVideo) ambienceVideo.loop = shouldLoop;

        const objectFit = objectFitFromConfig();

        // Keep video locked inside the placeable stage
        const stage = ensureCinemaStage();
        if (stage && mainVideo.parentElement !== stage) {
            stage.appendChild(mainVideo);
        }
        applyVideoStageLayout();

        applyCinemaObjectFit(mainVideo, objectFit);
        mainVideo.classList.remove('ken-burns', 'is-photo');

        if (item.type === 'photo') {
            consecutiveErrors = 0;
            const photoEl = ensureCinemaPhotoEl(stage);
            if (photoEl) {
                photoEl.style.display = '';
                photoEl.src = src;
                photoEl.classList.toggle('ken-burns', !!cfg.kenburns && Math.abs(videoZoom - 1) < 0.02);
            }
            // Pause/hide the video element so it doesn't sit on top of the photo.
            try {
                mainVideo.pause();
                mainVideo.removeAttribute('src');
                mainVideo.load();
                mainVideo.style.display = 'none';
                mainVideo.style.backgroundImage = '';
            } catch (_) {}

            if (ambienceVideo) ambienceVideo.poster = src;
            applyCinemaObjectFit(photoEl || mainVideo, objectFit);

            mediaLoading = false;
            clearPlayOverlay();
            const restartPhoto = () => {
                if (isPaused) return;
                if (token !== playToken) return;
                if (isClipLoopMode()) {
                    updateLoopHudChip();
                    photoTimeout = setTimeout(restartPhoto, cfg.photoDuration * 1000);
                    return;
                }
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
                playNext();
            };
            photoTimeout = setTimeout(restartPhoto, cfg.photoDuration * 1000);
            updateLoopHudChip();
            return;
        }

        // Restore video element; hide photo overlay
        mainVideo.classList.remove('is-photo');
        mainVideo.style.display = '';
        mainVideo.style.backgroundImage = '';
        mainVideo.style.backgroundSize = '';
        mainVideo.style.backgroundPosition = '';
        mainVideo.style.backgroundRepeat = '';
        try {
            const photoEl = stage?.querySelector('#bg-photo');
            if (photoEl) {
                photoEl.style.display = 'none';
                photoEl.removeAttribute('src');
                photoEl.classList.remove('ken-burns');
            }
        } catch (_) {}

        // Ambience uses same src only after main is set (and only if still current)
        try {
            await loadAndPlayVideo(mainVideo, src, token);
            if (token !== playToken) return;

            consecutiveErrors = 0;
            applyPlaybackSpeed();
            // Re-center after decode (intrinsic size now known)
            applyCinemaObjectFit(mainVideo, objectFit);
            // Keep loop on after successful start
            mainVideo.loop = isClipLoopMode();
            if (ambienceVideo) {
                try {
                    ambienceVideo.src = src;
                    ambienceVideo.muted = true;
                    ambienceVideo.loop = isClipLoopMode();
                    await ambienceVideo.play().catch(() => {});
                } catch (_) {}
            }
            clearPlayOverlay();
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
            applyVideoGpuHints(mainVideo);
            if (neonEngine) {
                if (cfg.disableNeonAudio || cfg.performanceMode) {
                    try { neonEngine.disconnectAudio(); } catch (_) {}
                } else {
                    try { neonEngine.connectAudio(mainVideo); } catch (_) {}
                }
            }
            startProgressBar();
            updateHudMuteIcon();
            syncParticlePerformance();
            updateLoopHudChip();
            revealHud();
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
        } catch (err) {
            if (token === playToken) mediaLoading = false;
            if (token !== playToken) return;
            const name = err && (err.name || '');
            if (name === 'AbortError') {
                // Superseded by a newer playNext — ignore
                return;
            }
            console.warn('Play failed', err);
            advanceAfterPlayFailure(err, token);
        }
    }

    function initGrid() {
        const { cellCount } = applyGridDimensions();
        // Wall: full frame when pref on. Normal grid: follow scaling config.
        const fit = wallModeActive
            ? (wallPrefs.fullFrame ? 'contain' : (objectFitFromConfig() === 'cover' ? 'cover' : 'contain'))
            : (objectFitFromConfig() === 'cover' ? 'cover' : 'contain');

        for (let i = 0; i < cellCount; i++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            cell.style.minWidth = '0';
            cell.style.minHeight = '0';
            cell.style.overflow = 'hidden';
            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;
            v.setAttribute('playsinline', '');
            v.setAttribute('muted', '');
            applyVideoGpuHints(v);
            try { v.preload = (wallModeActive && i !== 0) ? 'metadata' : 'auto'; } catch (_) {}
            v.style.background = '#000';
            if (!wallModeActive) {
                v.style.width = '100%';
                v.style.height = '100%';
                v.style.maxWidth = '100%';
                v.style.maxHeight = '100%';
                v.style.objectFit = fit;
                v.style.objectPosition = 'center center';
            }
            if (i === 0) {
                v.dataset.wallPrimary = '1';
                v.classList.add('wall-audio-primary');
                mainVideo = v;
            }

            // Click tile → make it the audio focus (volume applies here)
            cell.addEventListener('click', (e) => {
                if (suppressPauseClick) return;
                if (!wallModeActive && cfg.layout !== 'grid') return;
                e.stopPropagation();
                userUnlockedAudio = true;
                setWallPrimaryVideo(v);
                // Optional: unmute primary on tile click if volume > 0
                if ((cfg.volume ?? 0.7) > 0 && !wallAudioMuted) {
                    applyWallAudio({ muted: false });
                } else {
                    applyWallAudio();
                }
            });
            cell.title = wallModeActive
                ? 'Click to focus audio on this tile · mute/volume on play panel'
                : '';

            v.onerror = () => loadRandomVideo(v);
            const relayoutWallTile = () => {
                try { if (wallModeActive) applyWallVideoZoom(); } catch (_) {}
            };
            // resize fires when width/height become real after a 0-size metadata event
            v.addEventListener('loadedmetadata', relayoutWallTile);
            v.addEventListener('loadeddata', relayoutWallTile);
            v.addEventListener('resize', relayoutWallTile);
            cell.appendChild(v);
            scene.appendChild(cell);
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
        if (wallModeActive) {
            // Second pass after DOM paint — lock geometry to viewport + audio
            requestAnimationFrame(() => {
                try { reflowWallLayout({ skipRebuild: true }); } catch (_) {}
                try { applyWallAudio(); } catch (_) {}
            });
        } else {
            try {
                setWallPrimaryVideo(getWallPrimaryVideo());
                applyWallAudio();
            } catch (_) {}
        }
        updateWallModeHudBtn();
    }

    function initCarousel() {
        const pivot = document.createElement('div');
        pivot.className = 'carousel-pivot';
        scene.appendChild(pivot);
        
        scene.style.transform = `rotateX(${cfg.carouselTilt}deg)`;

        const count = cfg.carouselCount;
        const radius = cfg.carouselRadius;
        const fit = getObjectFitFromConfig();

        for (let i = 0; i < count; i++) {
            const card = document.createElement('div');
            card.className = 'carousel-card';
            
            // FIX: Inner wrapper for breathing animation
            const inner = document.createElement('div');
            inner.className = 'carousel-inner';
            inner.style.animationDelay = `${i * 0.2}s`;

            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;
            applyVideoGpuHints(v);
            try { v.preload = 'metadata'; } catch (_) {}
            v.style.width = '100%';
            v.style.height = '100%';
            v.style.objectFit = (fit === 'cover') ? 'cover' : 'contain';
            
            v.onerror = () => loadRandomVideo(v);
            
            inner.appendChild(v);
            card.appendChild(inner);
            pivot.appendChild(card);
            
            const angle = (i / count) * 360;
            // 3D Transform is now safe on the outer card
            card.style.transform = `rotateY(${angle}deg) translateZ(${radius}px)`;
            
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
        // Pivot spin is handled in CSS via class
        pivot.style.animationDuration = `${cfg.carouselSpeed}s`;
    }

    function initCollage() {
        const photoPlaylist = playlist.filter(item => item.type === 'photo');
        
        if (!photoPlaylist.length) {
            const msg = document.createElement('div');
            msg.textContent = "Add photos to library for Collage Mode";
            msg.style.color = "#555";
            scene.appendChild(msg);
            return;
        }

        isPaused = false;

        const spawnPhoto = async () => {
            if (isPaused) return;

            const item = photoPlaylist[Math.floor(Math.random() * photoPlaylist.length)];
            const src = await getSrc(item);
            if (!src) return;

            const img = document.createElement('img');
            img.src = src;
            img.className = 'collage-card';
            
            const top = Math.random() * 80;
            const left = Math.random() * 80;
            const rot = (Math.random() - 0.5) * 40;
            
            img.style.top = `${top}%`;
            img.style.left = `${left}%`;
            img.style.transform = `rotate(${rot}deg) scale(0.8)`;
            
            img.style.zIndex = Date.now() % 10000; 

            scene.appendChild(img);

            requestAnimationFrame(() => {
                img.classList.add('visible');
                img.style.transform = `rotate(${rot}deg) scale(1)`;
            });

            setTimeout(() => {
                img.style.opacity = 0;
                setTimeout(() => img.remove(), 2000);
            }, 60000);
        };

        spawnPhoto();
        spawnPhoto();
        spawnPhoto();
        
        collageInterval = setInterval(spawnPhoto, 3000); 
    }

    async function loadRandomVideo(v) {
        if (!playlist.length) return;
        const item = playlist[Math.floor(Math.random() * playlist.length)];
        const src = await getSrc(item);
        if (!src) return;

        if (item.type === 'photo') {
             v.src = "";
             v.poster = src;
        } else {
            v.src = src;
            // Start muted for autoplay reliability; re-apply wall audio after play
            v.muted = true;
            v.playsInline = true;
            try {
                const vol = Math.max(0, Math.min(1, cfg.volume ?? 0.7));
                v.volume = vol;
            } catch (_) {}
            try {
                await v.play();
            } catch(e) {
                // console.warn("Grid autoplay blocked, retrying muted...", e);
                v.muted = true;
                try {
                    await v.play();
                } catch(err) {
                    // console.error("Grid video failed completely", err);
                }
            }
            // Restore primary-tile audio after source change (volume control target)
            if (wallModeActive || cfg.layout === 'grid') {
                try { applyWallAudio(); } catch (_) {}
            }
        }
    }

    // --- 6. UTILITIES ---

    function startClock() {
        if (clockInterval) clearInterval(clockInterval);
        const tick = () => {
            try {
                const n = new Date();
                let h = n.getHours();
                if (cfg.format12h) h = h % 12 || 12;
                const m = n.getMinutes().toString().padStart(2, '0');
                const s = n.getSeconds().toString().padStart(2, '0');
                if (ui.clock) {
                    ui.clock.textContent = cfg.showSeconds ? `${h}:${m}:${s}` : `${h}:${m}`;
                }
                if (ui.date) {
                    if (cfg.showDate === false) {
                        ui.date.style.display = 'none';
                    } else {
                        ui.date.style.display = '';
                        ui.date.textContent = n.toLocaleDateString(undefined, {
                            weekday: 'long', month: 'long', day: 'numeric',
                        });
                    }
                }
            } catch (err) {
                console.warn('clock tick', err);
            }
        };
        tick();
        clockInterval = setInterval(tick, 1000);
    }

    async function initDB() {
        try {
            if (window.FAFOLibrary?.openDB) {
                db = await FAFOLibrary.openDB();
                return;
            }
        } catch (e) {
            console.warn('FAFOLibrary.openDB failed', e);
        }
        db = await new Promise(res => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            req.onblocked = () => console.warn('Database Upgrade Pending — close other FAFO tabs');
            req.onupgradeneeded = e => {
                const d = e.target.result;
                ['videos', 'photos'].forEach(s => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', { keyPath: 'id' });
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }

    function startHealthCheck() {
        if (healthCheckInterval) clearInterval(healthCheckInterval);
        healthCheckInterval = setInterval(() => {
            if (isPaused) return;
            const videos = document.querySelectorAll('#scene-root video');
            videos.forEach(v => {
                if (v.src && !v.paused && v.readyState < 3 && !v.ended) {
                    v.play().catch(() => {
                         if(!v.muted) { v.muted = true; v.play().catch(()=>{}); }
                    });
                }
            });
        }, 5000);
    }

    // --- BOOT (after all functions + FAFOPlayer bridge are defined) ---
    // Cinematic title splash + one random folder-linked intro promo (preloaded ASAP).
    let bootSplash = null;
    let introPlan = { play: true, quietSplash: false, reason: 'default' };
    try {
        try { window.FAFOIntroPromos?.beginPreload?.(); } catch (_) {}
        const ver = (typeof chrome !== 'undefined' && chrome.runtime?.getManifest)
            ? chrome.runtime.getManifest().version
            : '6.4';
        if (window.FAFOSession?.shouldPlayIntro) {
            introPlan = await FAFOSession.shouldPlayIntro(ver);
        }
        if (introPlan.play && window.FafoIntroSplash?.mount) {
            bootSplash = FafoIntroSplash.mount(document, {
                version: ver,
                minDurationMs: introPlan.quietSplash ? 500 : 1600,
                timeScale: introPlan.quietSplash ? 3.2 : 2.4,
            });
            bootSplash.setStatus?.(
                introPlan.quietSplash ? 'Quick start…' : 'Booting cinema…',
                0.08
            );
        } else {
            document.body.classList.add('fafo-ready');
            try { window.FAFOIntroPromos?.cancelPreload?.(); } catch (_) {}
        }
        // Changelog toast on version bump
        try {
            const prev = (await chrome.storage.local.get('fafoChangelogSeen')).fafoChangelogSeen;
            if (prev && prev !== ver) {
                window.FAFOUndo?.showToast?.(`Updated to v${ver} · Ctrl+K commands · Undo Z`);
            }
            await chrome.storage.local.set({ fafoChangelogSeen: ver });
        } catch (_) {}
    } catch (e) {
        console.warn('FAFO intro splash', e);
    }

    // Clock first so the date never sticks on HTML "Loading..." while DB/playlist await
    try {
        await loadConfig();
        try { await loadWallPrefs(); } catch (_) {}
        try { await loadStageLayoutPrefs(); } catch (_) {}
        applyGlobalStyles();
        try {
            if (window.FAFOVisual) {
                const vis = cfg.visual
                    ? FAFOVisual.normalize(cfg.visual)
                    : await FAFOVisual.loadFromStorage();
                FAFOVisual.apply(vis);
            }
        } catch (_) {}
        applyHUD();
        startClock();
        initInputListeners();
        initHudControls();
        initHudAutoHide();
        bootSplash?.setStatus?.('UI ready', 0.25);
    } catch (e) {
        console.error('FAFO early UI init failed', e);
        try { startClock(); } catch (_) {}
    }

    try {
        await initDB();
        bootSplash?.setStatus?.('Library online', 0.4);
        await buildPlaylist();
        bootSplash?.setStatus?.('Playlist built', 0.55);
        initNeonEngine();
        refreshParticles();
        initLayout();
        initGridResizeListener();
        startHealthCheck();
        listenForConfigChanges();
        // Re-bind tags once player + playlist are ready
        try {
            const item = playlist[currentIdx];
            if (item) {
                await window.FAFOMeta?.bindToItem?.(item, currentIdx);
            }
        } catch (_) {}
        // If still no video after a moment, surface restore UI
        setTimeout(() => {
            try {
                if (mainVideo && !mainVideo.src && playlist.length) {
                    maybeShowRestoreBanner();
                    showRetryPlaybackBanner('⚠️ Video not loading — click Retry or Restore Access');
                }
            } catch (_) {}
        }, 2500);
    } catch (e) {
        console.error('FAFO library/layout init failed', e);
        libraryEmpty = true;
        updateEmptyState();
        showRestoreBanner('⚠️ Library failed to open — click to Restore Access or open Options');
        try {
            if (!mainVideo && cfg.layout === 'cinema') initLayout();
        } catch (_) {}
    }

    // Intro promo: one random clip (preloaded during splash). Esc / click skips immediately.
    try {
        if (introPlan.play) {
            bootSplash?.setStatus?.('Intro promo…', 0.7);
            if (window.FAFOIntroPromos?.playBootSequence) {
                if (bootSplash?.finish) {
                    await bootSplash.finish(introPlan.quietSplash ? 0 : 40);
                }
                const skipPromos = !!bootSplash?.skipped;
                bootSplash = null;
                if (skipPromos) {
                    try { window.FAFOIntroPromos?.cancelPreload?.(); } catch (_) {}
                } else {
                    await FAFOIntroPromos.playBootSequence({
                        onStatus: (msg) => {
                            try { console.info('[FAFO intro]', msg); } catch (_) {}
                        },
                    });
                }
            } else if (bootSplash?.finish) {
                await bootSplash.finish(300);
                bootSplash = null;
            }
        } else if (bootSplash?.finish) {
            await bootSplash.finish(80);
            bootSplash = null;
        }
        // Offer resume if we have a session and didn't just start mid-playlist randomly
        try {
            const introPrefs = await window.FAFOSession?.readIntroPrefs?.();
            if (introPrefs?.autoResume) {
                const r = await window.FAFOSession?.resumeNow?.();
                if (r?.ok) {
                    window.FAFOUndo?.showToast?.('Resumed last clip');
                }
            } else {
                const sess = await window.FAFOSession?.readSession?.();
                if (sess?.name && playlist.length > 1) {
                    setTimeout(() => {
                        window.FAFOUndo?.showToast?.('Session saved · Ctrl+K → Resume last clip');
                    }, 1200);
                }
            }
        } catch (_) {}
    } catch (e) {
        console.warn('FAFO intro promos', e);
        try { await bootSplash?.finish?.(100); } catch (_) {}
        bootSplash = null;
    } finally {
        document.body.classList.add('fafo-ready');
        document.body.classList.remove('fafo-intro-active', 'fafo-intro-promo-active');
        try {
            if (mainVideo && mainVideo.paused && !isPaused && mainVideo.src) {
                mainVideo.play().catch(() => {});
            }
        } catch (_) {}
        try { window.FAFOLibraryDoctor?.scheduleNextUp?.(); } catch (_) {}
    }
});