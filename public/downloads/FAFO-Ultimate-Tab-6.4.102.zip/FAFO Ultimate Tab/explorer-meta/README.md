# FAFO Explorer Metadata Server

Companion for **FAFO Ultimate Tab**. Writes **Tags** and **star Ratings** into real video files so Windows Explorer and other apps can see them.

## Quick start (auto)

You should **not** have to keep a server window open.

1. Double-click **`INSTALL_DEPS.bat`** once per PC (Python packages + auto-launch)
2. Reload FAFO Ultimate Tab
3. Open a new tab — the file-tag server starts in the background if it is down
4. Tag as usual. **Disk · ON** means Explorer writes are live. **Add folder…** if a clip is not in the index.

The launcher copies itself to `%LOCALAPPDATA%\FAFO\ExplorerMeta` (no spaces), registers `fafo-companion://`, and keeps a supervisor running. Same idea as Imagine Vault.

Optional: **`START_META_SERVER.bat`** only if you want the console visible. **`Launch-ExplorerMeta.bat`** is the silent start.

`APPLY_PENDING_LEDGER.bat` starts the server itself. `LAUNCH_FAFO_STACK.bat` now delegates to the silent launcher.

Full guide (parent folder): **[TAGS_AND_RATINGS.md](../TAGS_AND_RATINGS.md)**

## Dependencies (`requirements.txt`)

| Package | Why |
|---------|-----|
| **pywin32** | Windows `System.Keywords` + `System.Rating` (what Explorer shows) |
| fastapi + uvicorn | Local HTTP API on `127.0.0.1:8765` |
| mutagen | MP4 embedded tags for other players |
| pydantic | Request models |
| Pillow | Optional image test / helpers |

Install manually:

```bat
python -m pip install -r requirements.txt
```

## API (for tools / debugging)

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/health` | Server up? |
| POST | `/api/fs/write-metadata` | Body: `{name,size,mtime,tags,rating}` or `{path,tags,rating}` |
| GET | `/api/fs/read-metadata?path=` | Read tags/rating from a file |
| POST | `/api/library/add-folder` | Body: `{path}` — index a folder **and all subfolders** |
| POST | `/api/library/pick-folder` | Mini Explorer window; picked folder is rolled up (subdirs included) |
| POST | `/api/library/remove-folder` | Body: `{path}` — stop watching a folder |
| POST | `/api/library/rescan` | Rebuild index |
| GET | `/api/library` | Index stats |

## Port

Default: **8765** (same as AI HTML TOOLBOX). Run only one server on that port.
