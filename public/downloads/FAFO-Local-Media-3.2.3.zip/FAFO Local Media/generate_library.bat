@echo off
echo Scanning media folders and generating library.json...

powershell -NoProfile -Command ^
  "$videos = @(); $photos = @(); " ^
  "if (Test-Path 'Videos') { $videos = Get-ChildItem -Path 'Videos' -Include *.mp4,*.webm,*.mkv,*.mov,*.avi,*.m4v,*.ts -Recurse -File }; " ^
  "if (Test-Path 'videos') { $videos += Get-ChildItem -Path 'videos' -Include *.mp4,*.webm,*.mkv,*.mov,*.avi,*.m4v,*.ts -Recurse -File }; " ^
  "if (Test-Path 'Photos') { $photos = Get-ChildItem -Path 'Photos' -Include *.jpg,*.jpeg,*.png,*.webp,*.gif -Recurse -File }; " ^
  "if (Test-Path 'photos') { $photos += Get-ChildItem -Path 'photos' -Include *.jpg,*.jpeg,*.png,*.webp,*.gif -Recurse -File }; " ^
  "$list = @(); " ^
  "foreach ($f in $videos) { $list += 'Videos/' + $f.Name }; " ^
  "foreach ($f in $photos) { $list += 'Photos/' + $f.Name }; " ^
  "$list | ConvertTo-Json -Depth 2 | Out-File 'library.json' -Encoding UTF8"

echo.
echo -------------------------------------------------------
echo SUCCESS! library.json has been updated.
echo Videos: Videos/  |  Photos: Photos/
echo -------------------------------------------------------
pause