document.addEventListener('DOMContentLoaded', async () => {
    // --- DOM ELEMENTS ---
    const scene = document.getElementById('scene-root');
    const overlay = document.getElementById('overlay');
    const bokehCanvas = document.getElementById('bokeh-canvas');
    const ui = {
        clock: document.getElementById('clock'),
        date: document.getElementById('date'),
        box: document.getElementById('ui-container')
    };
    const hud = {
        box: document.getElementById('player-hud'),
        title: document.getElementById('hud-title'),
        index: document.getElementById('hud-index'),
        play: document.getElementById('hud-play'),
        prev: document.getElementById('hud-prev'),
        next: document.getElementById('hud-next'),
        shuffle: document.getElementById('hud-shuffle'),
        speedDown: document.getElementById('hud-speed-down'),
        speed: document.getElementById('hud-speed'),
        speedUp: document.getElementById('hud-speed-up'),
        mute: document.getElementById('hud-mute'),
        volume: document.getElementById('hud-volume'),
        pip: document.getElementById('hud-pip'),
        fs: document.getElementById('hud-fs'),
        progressWrap: document.getElementById('hud-progress-wrap'),
        progressTrack: document.getElementById('hud-progress-track'),
        progress: document.getElementById('hud-progress'),
        progressThumb: document.getElementById('hud-progress-thumb'),
        timeCurrent: document.getElementById('hud-time-current'),
        timeTotal: document.getElementById('hud-time-total')
    };
    const emptyState = document.getElementById('empty-state');
    const neonFrame = document.getElementById('neon-frame');
    const shortcutHelp = document.getElementById('shortcut-help');

    // --- 1. CONFIGURATION DEFAULTS ---
    let cfg = {
        // Library Settings
        useLocal: true, 
        usePhotos: true, 
        urls: [],
        activePlaylistId: 'all', 
        
        // Layout Settings
        layout: 'cinema', 
        scaling: 'scale-capped',
        gridCols: 4, 
        gridRows: 1, 
        carouselCount: 8, 
        carouselRadius: 650, 
        carouselTilt: 0,
        carouselSpeed: 40,
        reflectOpacity: 30, 
        reflectOffset: 0,
        
        // Playback Settings
        loops: 1, 
        shuffle: true, 
        volume: 0.7,
        playbackSpeed: 1,
        photoDuration: 3, 
        kenburns: true,
        
        // Visual Settings
        accentColor: '#00e5ff', 
        brightness: 100, 
        contrast: 100, 
        saturate: 100, 
        sepia: 0, 
        grayscale: 0,

        // Dark UI chrome (tags panel / player HUD) — no light themes
        uiThemePreset: 'cyan',
        uiPanelOpacity: 0.92,
        uiHudOpacity: 0.82,
        uiPanelBorderOpacity: 0.14,
        uiRadius: 14,
        uiPanelBorderColor: '', // empty = derive from accent
        
        // Ambilight & Borders
        borderSize: 0, 
        borderColor: '#44858d', 
        borderGlow: 15,
        ambiScale: 1.0, 
        ambiOpacity: 0.25, 
        ambiBlur: 5,
        ambiMode: 'blur',

        // Audio-reactive neon border
        neonBorder: false,
        neonPattern: 'chase',
        neonSegments: 24,
        neonSpeed: 1,
        neonAudio: true,
        neonStrobe: 0.8,
        neonSensitivity: 1.2,
        neonWidth: 4,
        neonUseAccent: true,
        neonColor: '#00e5ff',
        
        // Detailed Particle Configs (Updated with all controls)
        fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
        fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
        fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
        fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
        fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
        fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,
        
        // UI Settings
        showDate: true, 
        format12h: true, 
        showSeconds: false,
        clockSize: 25, 
        font: "'Arial Black', sans-serif", 
        pos: 'pos-bottom-left',
        
        // Per-File Overrides
        overrides: {},

        // Performance
        performanceMode: false,
        maxDisplayHeight: 1080,
        cinemaScalePercent: 88,
        disableAmbience: false,
        disableParticles: false,
        disableCssFilters: false,
        disableNeonAudio: false,
    };

    // --- STATE VARIABLES ---
    let playlist = [];
    let currentIdx = 0;
    let loopCount = 0;
    let db = null;
    let mainVideo = null;
    let ambienceVideo = null;
    let photoTimeout = null;
    let collageInterval = null; 
    let isPaused = false;
    let permissionWarned = false;
    let healthCheckInterval = null;
    let consecutiveErrors = 0;
    let currentBlobUrl = null;
    /** Monotonic token so only the latest playNext owns the video element. */
    let playToken = 0;
    let playFailTimer = null;
    let userUnlockedAudio = false;
    /** Player HUD layout: mr (mid-right default) | br | bl | free — always-on-top in this tab. */
    let hudDock = 'mr';
    let hudPinned = true;
    let hudX = 18;
    let hudY = 18;
    let hudDragging = false;
    /** Manual repeat (Q) — loop current clip until toggled off or user skips. */
    let manualRepeat = false;
    /** True while loadAndPlayVideo / playNext is swapping sources — ignore pause/ended side-effects. */
    let mediaLoading = false;
    let clockInterval = null;
    let neonEngine = null;
    let particleEngine = null;
    let progressInterval = null;
    let libraryEmpty = false;
    let isSeeking = false;
    let hudIdleTimer = null;
    let gridResizeTimer = null;
    let volumeSaveTimer = null;
    /** Suppress spurious onended after seek-to-end / scrub. */
    let suppressEndedUntil = 0;
    /** Stack of prior playlist indices so Prev returns to the last played clip. */
    let playHistory = [];
    const PLAY_HISTORY_MAX = 200;
    const HUD_IDLE_MS = 5000;
    const SPEED_STEPS = [0.25, 0.33, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];
    /** Keys that require rebuilding the playlist when mediaConfig changes. */
    const PLAYLIST_AFFECTING_KEYS = [
        'activePlaylistId', 'shuffle', 'useLocal', 'usePhotos', 'urls',
    ];
    /** Keys that only need live apply — never rebuild / re-layout. */
    const SOFT_CONFIG_KEYS = [
        'volume', 'playbackSpeed', 'brightness', 'contrast', 'saturate',
        'uiThemePreset', 'uiPanelOpacity', 'uiHudOpacity', 'uiPanelBorderOpacity', 'uiRadius', 'uiPanelBorderColor',
        'sepia', 'grayscale', 'showDate', 'format12h', 'showSeconds',
        'clockSize', 'font', 'pos',
    ];

    // --- CORE FUNCTIONS (boot sequence runs at bottom so FAFOPlayer exists first) ---

    async function loadConfig() {
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        cfg = {...cfg, ...mediaConfig};
    }

    function listenForConfigChanges() {
        chrome.storage.onChanged.addListener(async (changes, area) => {
            if (area !== 'local' || !changes.mediaConfig) return;
            const oldVal = changes.mediaConfig.oldValue || {};
            const newVal = changes.mediaConfig.newValue || {};
            if (!newVal || typeof newVal !== 'object') return;

            // Diff only keys that actually changed (volume slider writes many times)
            const changedKeys = Object.keys(newVal).filter((k) => {
                try {
                    return JSON.stringify(oldVal[k]) !== JSON.stringify(newVal[k]);
                } catch {
                    return oldVal[k] !== newVal[k];
                }
            });
            if (!changedKeys.length) return;

            const prevLayout = cfg.layout;
            const prevPlaylistId = cfg.activePlaylistId;
            cfg = { ...cfg, ...newVal };

            // Soft-only updates (volume/speed/etc.) — never rebuild playlist or restart video
            const needsPlaylist = changedKeys.some((k) => PLAYLIST_AFFECTING_KEYS.includes(k));
            const needsLayout = changedKeys.includes('layout')
                || (newVal.activePlaylistId !== undefined && newVal.activePlaylistId !== prevPlaylistId);
            const softOnly = !needsPlaylist && !needsLayout
                && changedKeys.every((k) => SOFT_CONFIG_KEYS.includes(k));

            if (softOnly) {
                if (changedKeys.includes('volume') && mainVideo) {
                    const vol = Math.max(0, Math.min(1, cfg.volume ?? 0.7));
                    mainVideo.volume = vol;
                    if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
                    if (hud.volume) hud.volume.value = Math.round(vol * 100);
                    updateHudMuteIcon();
                }
                if (changedKeys.includes('playbackSpeed')) {
                    applyPlaybackSpeed();
                }
                if (changedKeys.some((k) => ['showDate', 'format12h', 'showSeconds', 'clockSize', 'font', 'pos'].includes(k))) {
                    applyHUD();
                }
                if (changedKeys.some((k) => ['brightness', 'contrast', 'saturate', 'sepia', 'grayscale'].includes(k))) {
                    applyGlobalStyles();
                }
                return;
            }

            applyGlobalStyles();
            applyHUD();
            initNeonEngine();
            refreshParticles();

            if (needsPlaylist) {
                // Keep current clip if it still exists after rebuild
                const prevItem = playlist[currentIdx];
                const prevKey = prevItem
                    ? (prevItem.name || prevItem.handle?.name || prevItem.url || '')
                    : '';
                await buildPlaylist();
                if (prevKey && playlist.length) {
                    const found = playlist.findIndex((it) =>
                        (it.name || it.handle?.name || it.url || '') === prevKey
                    );
                    if (found >= 0) currentIdx = found;
                    else currentIdx = Math.min(currentIdx, playlist.length - 1);
                }
                // Playlist order changed — history indices are stale
                playHistory = [];
            }

            if (needsLayout || cfg.layout !== prevLayout) {
                initLayout();
            } else {
                updateHUD();
            }
        });
    }

    function initNeonEngine() {
        if (!neonEngine) neonEngine = new NeonBorderEngine(neonFrame, () => cfg);
        neonEngine.rebuild();
        neonEngine.start();
    }

    function refreshParticles() {
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        document.body.classList.toggle('fx-active', anyFx);
        if (!particleEngine) particleEngine = new ParticleFXEngine(bokehCanvas, () => cfg);
        if (anyFx) {
            particleEngine.rebuild();
            if (!particleEngine.rafId) particleEngine.start();
            syncParticlePerformance();
        } else {
            particleEngine.destroy();
        }
    }

    function syncParticlePerformance() {
        if (!particleEngine) return;
        const videoBusy = cfg.layout === 'cinema' && mainVideo && !mainVideo.paused && !isPaused;
        const forceOff = cfg.disableParticles || cfg.performanceMode;
        if (forceOff && videoBusy) {
            particleEngine.setPerformanceMode(true);
            // Fully pause particle loop while media plays in perf mode
            if (particleEngine.rafId) particleEngine.destroy();
            document.body.classList.remove('fx-active');
            return;
        }
        particleEngine.setPerformanceMode(videoBusy || !!cfg.performanceMode);
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        if (anyFx && !particleEngine.rafId && !(forceOff && videoBusy)) {
            document.body.classList.add('fx-active');
            particleEngine.rebuild();
            particleEngine.start();
        }
    }

    function computeOptimalGrid(cellCount) {
        if (cellCount <= 1) return { cols: 1, rows: 1 };
        const aspect = innerWidth / innerHeight;
        let best = { cols: 1, rows: cellCount, score: -Infinity };
        for (let cols = 1; cols <= cellCount; cols++) {
            const rows = Math.ceil(cellCount / cols);
            const waste = cols * rows - cellCount;
            const cellAspect = (cols / rows) * aspect;
            const target = 16 / 9;
            const score = -Math.abs(Math.log(cellAspect / target)) - waste * 0.45;
            if (score > best.score) best = { cols, rows, score };
        }
        return { cols: best.cols, rows: best.rows };
    }

    function applyGridDimensions() {
        const cellCount = Math.max(1, (cfg.gridCols || 4) * (cfg.gridRows || 1));
        const grid = computeOptimalGrid(cellCount);
        document.documentElement.style.setProperty('--grid-cols', grid.cols);
        document.documentElement.style.setProperty('--grid-rows', grid.rows);
        return { ...grid, cellCount };
    }

    function initGridResizeListener() {
        window.addEventListener('resize', () => {
            if (cfg.layout !== 'grid') return;
            clearTimeout(gridResizeTimer);
            gridResizeTimer = setTimeout(applyGridDimensions, 120);
        });
    }

    function revokeCurrentBlob() {
        if (currentBlobUrl) {
            const old = currentBlobUrl;
            currentBlobUrl = null;
            // Defer revoke — immediate revoke mid-load kills play() and cascades "stalled"
            setTimeout(() => {
                try { URL.revokeObjectURL(old); } catch (_) {}
            }, 2500);
        }
    }

    // NEW: Helper for Theme Engine
    function hexToRgb(hex) {
        const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    function isPerfMode() {
        return !!(cfg.performanceMode || cfg.disableCssFilters);
    }

    /** Dark-only UI chrome presets (tags panel / player HUD). */
    const DARK_UI_PRESETS = {
        cyan:   { accent: '#00e5ff', panelRgb: '12,12,18', hudRgb: '0,0,0', borderRgb: '0,229,255' },
        violet: { accent: '#b388ff', panelRgb: '14,10,20', hudRgb: '6,0,12', borderRgb: '179,136,255' },
        amber:  { accent: '#ffc107', panelRgb: '18,14,8',  hudRgb: '10,8,0', borderRgb: '255,193,7' },
        green:  { accent: '#69f0ae', panelRgb: '8,16,12',  hudRgb: '0,8,4',  borderRgb: '105,240,174' },
        rose:   { accent: '#ff80ab', panelRgb: '18,10,14', hudRgb: '12,0,6', borderRgb: '255,128,171' },
        steel:  { accent: '#90a4ae', panelRgb: '10,12,14', hudRgb: '4,6,8',  borderRgb: '144,164,174' },
        crimson:{ accent: '#ff5252', panelRgb: '16,8,8',   hudRgb: '10,0,0', borderRgb: '255,82,82' },
        ice:    { accent: '#e0f7fa', panelRgb: '8,12,16',  hudRgb: '0,4,8',  borderRgb: '128,222,234' },
    };

    function applyUiChromeStyles(root) {
        const presetName = cfg.uiThemePreset || 'cyan';
        const preset = DARK_UI_PRESETS[presetName] || DARK_UI_PRESETS.cyan;
        // Preset can drive accent unless user customized after; still apply panel colors from preset+opacity
        const panelA = Math.max(0.25, Math.min(0.98, Number(cfg.uiPanelOpacity ?? 0.92)));
        const hudA = Math.max(0.25, Math.min(0.98, Number(cfg.uiHudOpacity ?? 0.82)));
        const borderA = Math.max(0.05, Math.min(0.9, Number(cfg.uiPanelBorderOpacity ?? 0.14)));
        const radius = Math.max(4, Math.min(28, parseInt(cfg.uiRadius, 10) || 14));
        const panelRgb = preset.panelRgb;
        const hudRgb = preset.hudRgb;
        let borderRgb = preset.borderRgb;
        if (cfg.uiPanelBorderColor) {
            const br = hexToRgb(cfg.uiPanelBorderColor);
            if (br) borderRgb = `${br.r},${br.g},${br.b}`;
        }
        root.style.setProperty('--ui-panel-bg', `rgba(${panelRgb},${panelA})`);
        root.style.setProperty('--ui-hud-bg', `rgba(${hudRgb},${hudA})`);
        root.style.setProperty('--ui-panel-border', `rgba(${borderRgb},${borderA})`);
        root.style.setProperty('--ui-radius', `${radius}px`);
        root.style.setProperty('--ui-panel-rgb', panelRgb);
        root.dataset.uiTheme = presetName;
    }

    function applyGlobalStyles() {
        const root = document.documentElement;
        const body = document.body;

        // Dark UI chrome (transparency, radius, themed borders)
        applyUiChromeStyles(root);
        
        // Apply Accent Color Logic (may be overridden by theme preset if no custom accent saved)
        let accent = cfg.accentColor || '#00e5ff';
        const preset = DARK_UI_PRESETS[cfg.uiThemePreset || 'cyan'];
        if (preset && (!cfg.accentColor || cfg._accentFromPreset)) {
            // keep user's accent if set
        }
        const rgb = hexToRgb(accent);
        if (rgb) {
            root.style.setProperty('--accent', accent);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }

        // Color grading on #scene-root is expensive (re-filters the whole video layer).
        // In perf mode or when disabled, force identity filters so GPU can composite cleanly.
        const noFilters = cfg.disableCssFilters || cfg.performanceMode;
        if (noFilters) {
            root.style.setProperty('--brightness', '100%');
            root.style.setProperty('--contrast', '100%');
            root.style.setProperty('--saturate', '100%');
            root.style.setProperty('--sepia', '0%');
            root.style.setProperty('--grayscale', '0%');
            scene?.classList.add('no-scene-filter');
        } else {
            root.style.setProperty('--brightness', `${cfg.brightness}%`);
            root.style.setProperty('--contrast', `${cfg.contrast}%`);
            root.style.setProperty('--saturate', `${cfg.saturate}%`);
            root.style.setProperty('--sepia', `${cfg.sepia}%`);
            root.style.setProperty('--grayscale', `${cfg.grayscale}%`);
            scene?.classList.remove('no-scene-filter');
        }

        // Cap display size for perf (CSS inset:0 + margin:auto centers the smaller box)
        const maxH = parseInt(cfg.maxDisplayHeight, 10) || 0;
        if (maxH > 0) {
            root.style.setProperty('--video-max-h', `min(100%, ${maxH}px)`);
            root.style.setProperty('--video-max-w', `min(100%, ${Math.round(maxH * 16 / 9)}px)`);
        } else {
            root.style.setProperty('--video-max-h', '100%');
            root.style.setProperty('--video-max-w', '100%');
        }
        body.classList.toggle('perf-mode', !!cfg.performanceMode);
        
        // Borders & Layout
        root.style.setProperty('--border-size', `${cfg.borderSize}px`);
        root.style.setProperty('--border-color', cfg.borderColor);
        root.style.setProperty('--border-glow', `${cfg.borderGlow}px`);
        if (cfg.layout === 'grid') applyGridDimensions();
        else {
            root.style.setProperty('--grid-cols', cfg.gridCols);
            root.style.setProperty('--grid-rows', cfg.gridRows);
        }
        
        // Reflections (Convert 0-100 to 0.0-1.0)
        root.style.setProperty('--reflect-op', `${cfg.reflectOpacity / 100}`);
        root.style.setProperty('--reflect-off', `${cfg.reflectOffset}px`);
    }

    function applyVideoGpuHints(videoEl) {
        if (!videoEl) return;
        // Do NOT set inline transform here — CSS owns layout/centering.
        // Overwriting transform previously broke cinema scale (only top-left visible).
        try { videoEl.disablePictureInPicture = false; } catch (_) {}
        videoEl.setAttribute('playsinline', '');
        videoEl.style.backfaceVisibility = 'hidden';
        // Optional display cap via CSS variables (keeps object-fit + full-frame layout)
        // Inline max size only when not using cover (cover needs full viewport box)
    }

    function applyCinemaObjectFit(videoEl, objectFit) {
        if (!videoEl) return;
        const scaleMode = cfg.scaling || 'scale-capped';
        const fillPct = Math.max(50, Math.min(100, parseInt(cfg.cinemaScalePercent, 10) || 88)) / 100;
        const maxCfg = parseInt(cfg.maxDisplayHeight, 10) || 0;
        const capped = scaleMode === 'scale-capped' || objectFit === 'capped';
        const fitWindow = scaleMode === 'scale-fit-window';

        if (capped || fitWindow) {
            const place = () => {
                const vw = videoEl.videoWidth || videoEl.naturalWidth || 0;
                const vh = videoEl.videoHeight || videoEl.naturalHeight || 0;
                let maxW = (window.innerWidth || 1920) * fillPct;
                let maxH = (window.innerHeight || 1080) * fillPct;
                if (maxCfg > 0) {
                    maxH = Math.min(maxH, maxCfg);
                    maxW = Math.min(maxW, Math.round(maxCfg * 16 / 9));
                }
                if (capped && vw > 0 && vh > 0) {
                    maxW = Math.min(maxW, vw);
                    maxH = Math.min(maxH, vh);
                }
                let drawW = vw || maxW;
                let drawH = vh || maxH;
                if (!vw || !vh) {
                    drawW = maxW;
                    drawH = maxH;
                } else if (drawW > maxW || drawH > maxH) {
                    const s = Math.min(maxW / drawW, maxH / drawH);
                    drawW = Math.round(drawW * s);
                    drawH = Math.round(drawH * s);
                } else if (fitWindow) {
                    const s = Math.min(maxW / drawW, maxH / drawH);
                    drawW = Math.round(drawW * s);
                    drawH = Math.round(drawH * s);
                }
                videoEl.style.objectFit = 'contain';
                videoEl.style.width = drawW + 'px';
                videoEl.style.height = drawH + 'px';
                videoEl.style.maxWidth = '100%';
                videoEl.style.maxHeight = '100%';
                videoEl.style.left = '50%';
                videoEl.style.top = '50%';
                videoEl.style.right = 'auto';
                videoEl.style.bottom = 'auto';
                videoEl.style.inset = 'auto';
                videoEl.style.margin = '0';
                videoEl.style.position = 'absolute';
                videoEl.style.transform = 'translate(-50%, -50%) translateZ(0)';
            };
            place();
            if (!videoEl._fafoCappedBound) {
                videoEl._fafoCappedBound = true;
                videoEl.addEventListener('loadedmetadata', place);
                window.addEventListener('resize', place);
            }
            videoEl._fafoPlaceCapped = place;
            return;
        }

        videoEl.style.objectFit = objectFit || 'contain';
        if (objectFit === 'none') {
            videoEl.style.width = 'auto';
            videoEl.style.height = 'auto';
            videoEl.style.maxWidth = '100%';
            videoEl.style.maxHeight = '100%';
            videoEl.style.left = '50%';
            videoEl.style.top = '50%';
            videoEl.style.right = 'auto';
            videoEl.style.bottom = 'auto';
            videoEl.style.inset = 'auto';
            videoEl.style.position = 'absolute';
            videoEl.style.transform = 'translate(-50%, -50%) translateZ(0)';
        } else {
            videoEl.style.width = '100%';
            videoEl.style.height = '100%';
            videoEl.style.left = '';
            videoEl.style.top = '';
            videoEl.style.right = '';
            videoEl.style.bottom = '';
            videoEl.style.inset = '0';
            videoEl.style.margin = 'auto';
            videoEl.style.position = 'absolute';
            videoEl.style.transform = 'translateZ(0)';
        }
    }

    function applyHUD() {
        ui.clock.style.fontSize = `${cfg.clockSize}px`;
        ui.box.style.fontFamily = cfg.font;
        ui.box.className = cfg.pos;
        ui.date.style.display = cfg.showDate ? 'block' : 'none';
    }

    function unlockAudioFromGesture() {
        userUnlockedAudio = true;
        if (mainVideo && mainVideo.muted && cfg.volume > 0) {
            // Only unmute if HUD mute wasn't intentionally left on at zero volume
            // Keep muted if user last set mute via button (video.muted && volume>0 after explicit mute)
            // Heuristic: if volume slider > 0 and we're paused/playing after gesture, allow sound
            try {
                mainVideo.muted = false;
                mainVideo.volume = cfg.volume;
                updateHudMuteIcon();
            } catch (_) {}
        }
    }

    function initInputListeners() {
        // Any gesture unlocks sound for future clips (Chrome new-tab autoplay policy)
        document.addEventListener('pointerdown', () => unlockAudioFromGesture(), { capture: true, passive: true });
        document.addEventListener('keydown', () => unlockAudioFromGesture(), { capture: true, passive: true });

        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
            // Don't steal keys while typing in tag panel inputs
            if (e.target.closest?.('#meta-dock input, #meta-dock textarea')) return;

            if (e.code === 'Space') { e.preventDefault(); togglePause(); }
            if (e.code === 'ArrowRight') skipTrack(1);
            if (e.code === 'ArrowLeft') skipTrack(-1);
            // A/D transport · W/S speed · Q repeat · E E-set (modifiers = banks)
            if (e.code === 'KeyA' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                skipTrack(-1);
            }
            if (e.code === 'KeyD' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                skipTrack(1);
            }
            if (e.code === 'KeyW' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                changeSpeed(1);
            }
            if (e.code === 'KeyS' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                changeSpeed(-1);
            }
            if (e.code === 'KeyQ' && !e.ctrlKey && !e.metaKey && !e.altKey) {
                e.preventDefault();
                toggleManualRepeat();
            }
            if (e.code === 'KeyE') {
                // E + modifiers select bank (same matrix as hotkeys)
                // Skip when focus is inside E-set custom assign inputs (already guarded above)
                e.preventDefault();
                const bank = bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
                window.FAFOMeta?.setExtraLiveBank?.(bank);
                window.FAFOMeta?.applyExtraTagBank?.(bank);
                revealHud();
            }
            if (e.code === 'KeyH') toggleShuffle(); // was S
            if (e.code === 'KeyM') toggleMute();
            if (e.code === 'KeyP') togglePiP();
            if (e.code === 'KeyF') toggleFullscreen();
            if (e.code === 'KeyL') { e.preventDefault(); openPlaylistPicker(); }
            if (e.code === 'Comma') changeSpeed(-1);
            if (e.code === 'Period') changeSpeed(1);
            if (e.key === '?') shortcutHelp?.classList.toggle('hidden');
            // Live-update E-set bank chips when modifiers held
            if (e.shiftKey || e.ctrlKey || e.metaKey || e.altKey) {
                window.FAFOMeta?.syncExtraBankFromEvent?.(e);
            }
            revealHud();
        });
        document.addEventListener('keyup', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            window.FAFOMeta?.syncExtraBankFromEvent?.(e);
        });
        document.addEventListener('click', (e) => {
            if (e.target.closest('a') || e.target.closest('button') || e.target.closest('.modal') || e.target.closest('.player-hud') || e.target.closest('#meta-dock') || e.target.closest('#playlist-pick')) return;
            togglePause();
        });
        document.addEventListener('mousemove', revealHud, { passive: true });
        
        // Creative 3D Tilt for Carousel
        document.addEventListener('mousemove', (e) => {
            if (cfg.layout === 'carousel') {
                const x = (e.clientX / window.innerWidth - 0.5) * 2; // -1 to 1
                const y = (e.clientY / window.innerHeight - 0.5) * 2;
                
                const pivot = document.querySelector('.carousel-pivot');
                if(pivot) {
                    pivot.style.transformOrigin = 'center center';
                    scene.style.transform = `rotateX(${cfg.carouselTilt + (y * 10)}deg) rotateY(${x * 10}deg)`;
                }
            }
        });
    }

    function pushPlayHistory(idx) {
        if (idx == null || idx < 0 || !playlist.length) return;
        // Avoid duplicate consecutive entries
        if (playHistory.length && playHistory[playHistory.length - 1] === idx) return;
        playHistory.push(idx);
        if (playHistory.length > PLAY_HISTORY_MAX) playHistory.shift();
    }

    /**
     * Advance (or go back) in the playlist.
     * dir < 0 uses play history so Prev returns the last played clip (not just index-1).
     * When skip-tagged mode is on, forward skips already-tagged / heavily-tagged clips.
     */
    function shuffleInPlace(arr) {
        for (let i = arr.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            const tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
        return arr;
    }

    function skipTrack(dir) {
        if (!playlist.length) return;
        clearTimeout(photoTimeout);
        clearTimeout(playFailTimer);
        loopCount = 0;
        isPaused = false;
        consecutiveErrors = 0; // user intent always restarts the fail streak
        userUnlockedAudio = true;
        ui.clock.style.opacity = 1;
        if (hud.play) hud.play.textContent = '⏸';
        clearPlayOverlay();
        try { window.FAFOMeta?.clearUntaggedPrompt?.(); } catch (_) {}

        if (dir < 0) {
            // Prefer real history of what was played
            while (playHistory.length) {
                const prev = playHistory.pop();
                if (prev !== currentIdx && prev >= 0 && prev < playlist.length) {
                    currentIdx = prev;
                    playNext({ fromHistory: true, instant: true, force: true });
                    return;
                }
            }
            // Fallback: previous index in current order
            currentIdx = (currentIdx - 1 + playlist.length) % playlist.length;
            playNext({ fromHistory: true, instant: true, force: true });
            return;
        }

        // Forward: remember where we were, then find next eligible index
        pushPlayHistory(currentIdx);
        const next = findNextEligibleIndex(currentIdx, 1);
        currentIdx = next;
        playNext({ instant: true, force: true });
    }

    /**
     * Find next playlist index respecting FAFOMeta skip-tagged mode when active.
     * Falls back to simple wrap if every item is filtered.
     */
    function findNextEligibleIndex(fromIdx, dir) {
        const n = playlist.length;
        if (!n) return 0;
        const step = dir < 0 ? -1 : 1;
        const skipMode = !!window.FAFOMeta?.isSkipTaggedMode?.();
        if (!skipMode) {
            return (fromIdx + step + n) % n;
        }
        // Prefer untagged; if none left in a full scan, prefer < 5 tags
        let foundLight = -1;
        for (let i = 1; i <= n; i++) {
            const idx = (fromIdx + step * i + n * 10) % n;
            const item = playlist[idx];
            const count = window.FAFOMeta?.tagCountForItem?.(item) ?? 0;
            if (count === 0) return idx;
            if (foundLight < 0 && count < 5) foundLight = idx;
        }
        // All tagged: skip ones with 5+ tags when possible
        if (foundLight >= 0) return foundLight;
        return (fromIdx + step + n) % n;
    }

    /**
     * Loop current clip until user presses Next when:
     * - clip is untagged (replaces old pause-at-end), or
     * - Skip tagged mode is on
     * Tagging does NOT auto-advance.
     */
    /** Same rules as FAFOMeta: Alt→3, Ctrl→2, Shift→1, none→0 */
    function bankFromMods(shift, ctrl, alt) {
        if (alt) return 3;
        if (ctrl) return 2;
        if (shift) return 1;
        return 0;
    }

    function isClipLoopMode() {
        if (manualRepeat) return true;
        try {
            if (window.FAFOMeta?.isSkipTaggedMode?.()) return true;
            if (window.FAFOMeta?.isUntagged?.()) return true;
        } catch (_) {}
        return false;
    }

    function toggleManualRepeat() {
        manualRepeat = !manualRepeat;
        chrome.storage.local.set({ fafoManualRepeat: manualRepeat }).catch(() => {});
        refreshLoopMode();
        updateRepeatButton();
        revealHud();
        if (hud.title) {
            const prev = hud.title.textContent;
            hud.title.textContent = manualRepeat ? '🔁 Repeat ON' : 'Repeat off';
            setTimeout(() => {
                if (hud.title && (hud.title.textContent === '🔁 Repeat ON' || hud.title.textContent === 'Repeat off')) {
                    updateHUD();
                }
            }, 900);
        }
    }

    function updateRepeatButton() {
        const btn = document.getElementById('hud-repeat');
        if (!btn) return;
        btn.classList.toggle('active', !!manualRepeat);
        btn.title = manualRepeat
            ? 'Repeat ON (Q) — click or Q to turn off'
            : 'Repeat this clip (Q)';
        btn.setAttribute('aria-pressed', manualRepeat ? 'true' : 'false');
    }

    function restartClipFromStart(reason) {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        // Never fight a mid-load source swap (this was killing Chrome playback)
        if (mediaLoading) return;
        if (isPaused && reason !== 'setClipLoop') return;
        try {
            mainVideo.loop = true;
            if (ambienceVideo) ambienceVideo.loop = true;
            try {
                mainVideo.currentTime = 0;
            } catch (_) {}
            applyPlaybackSpeed();
            isPaused = false;
            ui.clock.style.opacity = 1;
            if (hud.play) hud.play.textContent = '⏸';
            const p = mainVideo.play();
            if (p && typeof p.catch === 'function') {
                p.catch(() => {
                    if (mediaLoading) return;
                    setTimeout(() => {
                        if (mediaLoading || !mainVideo) return;
                        try {
                            mainVideo.currentTime = 0;
                            mainVideo.loop = true;
                            mainVideo.muted = mainVideo.muted || !userUnlockedAudio;
                            mainVideo.play().catch(() => {});
                        } catch (_) {}
                    }, 50);
                });
            }
            if (ambienceVideo) {
                try {
                    ambienceVideo.currentTime = 0;
                    ambienceVideo.play().catch(() => {});
                } catch (_) {}
            }
        } catch (e) {
            console.warn('restartClipFromStart', reason, e);
        }
    }

    function setClipLoop(on) {
        if (mainVideo && mainVideo.tagName === 'VIDEO') {
            // Keep the native loop flag on continuously when looping is desired
            mainVideo.loop = !!on;
            if (ambienceVideo) ambienceVideo.loop = !!on;
            updateLoopHudChip();
            // Only restart if truly stuck at end — not during load
            if (
                on &&
                !mediaLoading &&
                !isPaused &&
                mainVideo.readyState >= 2 &&
                Number.isFinite(mainVideo.duration) &&
                mainVideo.duration > 0 &&
                (mainVideo.ended || mainVideo.currentTime >= mainVideo.duration - 0.05)
            ) {
                restartClipFromStart('setClipLoop');
            }
        }
    }

    function refreshLoopMode() {
        const on = isClipLoopMode();
        setClipLoop(on);
        // Photos: restart timer path is handled in playNext via isClipLoopMode
        updateLoopHudChip();
    }

    function updateLoopHudChip() {
        const chip = document.getElementById('hud-mode-chip');
        if (!chip) return;
        const skip = !!window.FAFOMeta?.isSkipTaggedMode?.();
        const untagged = !!window.FAFOMeta?.isUntagged?.();
        const looping = isClipLoopMode();
        const parts = [];
        if (manualRepeat) parts.push('REPEAT · Q');
        if (skip) parts.push('SKIP TAGGED');
        if (untagged) parts.push('UNTAGGED · LOOP');
        else if (looping && skip && !manualRepeat) parts.push('LOOP');
        if (!parts.length) {
            chip.hidden = true;
            chip.textContent = '';
            updateRepeatButton();
            return;
        }
        chip.hidden = false;
        chip.textContent = parts.join(' · ');
        updateRepeatButton();
        chip.title = skip
            ? 'Skip tagged on Next · looping until you press Next'
            : 'Untagged clip loops until you press Next (tagging does not advance)';
    }

    // Bridge for fafo-meta.js (tags / ratings / meta prev-next)
    window.FAFOPlayer = {
        skipTrack,
        getCurrentItem: () => playlist[currentIdx] || null,
        getCurrentIndex: () => currentIdx,
        getPlaylistLength: () => playlist.length,
        getPlaylist: () => playlist.slice(),
        togglePause: () => { if (typeof togglePause === 'function') togglePause(); },
        openPlaylistPicker: () => openPlaylistPicker(),
        findNextEligibleIndex,
        setClipLoop,
        refreshLoopMode,
        applyPlaybackSpeed: () => applyPlaybackSpeed(),
        updateLoopHudChip,
        undockHudForMove,
        resetHudLayout,
    };

    // --- PLAYLIST QUICK-ADD (during playback) ---
    async function listDbPlaylists() {
        if (!db) return [];
        try {
            const tx = db.transaction('playlists', 'readonly');
            const store = tx.objectStore('playlists');
            return await new Promise(res => {
                const req = store.getAll();
                req.onsuccess = () => res(req.result || []);
                req.onerror = () => res([]);
            });
        } catch { return []; }
    }

    async function openPlaylistPicker() {
        const panel = document.getElementById('playlist-pick');
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        if (!panel || !select) return;
        const item = playlist[currentIdx];
        if (!item || !item.handle) {
            // Bundled URL items can't join handle playlists easily
            console.warn('Current item has no file handle for playlist storage');
        }
        const lists = (await listDbPlaylists()).filter(p => p.type !== 'smart');
        select.innerHTML = '<option value="">— select playlist —</option>' +
            lists.map(p => `<option value="${p.id}">${p.name} (${(p.items || []).length})</option>`).join('');
        if (newName) newName.value = '';
        panel.classList.remove('hidden');
        revealHud();
    }

    function closePlaylistPicker() {
        document.getElementById('playlist-pick')?.classList.add('hidden');
    }

    async function addCurrentToPlaylist() {
        const select = document.getElementById('playlist-pick-select');
        const newName = document.getElementById('playlist-pick-new');
        const item = playlist[currentIdx];
        if (!item?.handle) {
            alert('This clip has no local file handle (bundled/URL). Link a folder in Options to use playlists.');
            return;
        }
        if (!db) await initDB();

        let playlistId = select?.value || '';
        let pl = null;

        if (newName?.value?.trim()) {
            const name = newName.value.trim();
            pl = {
                id: 'pl_' + Date.now().toString(36),
                name,
                items: [],
                created: Date.now(),
            };
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
            playlistId = pl.id;
        } else if (playlistId) {
            const tx = db.transaction('playlists', 'readonly');
            pl = await new Promise(res => {
                const r = tx.objectStore('playlists').get(playlistId);
                r.onsuccess = () => res(r.result);
                r.onerror = () => res(null);
            });
        }
        if (!pl) {
            alert('Pick an existing playlist or type a new name.');
            return;
        }

        const storeName = item.type === 'photo' ? 'photos' : 'videos';
        let handleKey = null;
        try {
            const tx = db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const vals = await new Promise((res, rej) => {
                const r = store.getAll();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const keys = await new Promise((res, rej) => {
                const tx2 = db.transaction(storeName, 'readonly');
                const r = tx2.objectStore(storeName).getAllKeys();
                r.onsuccess = () => res(r.result || []);
                r.onerror = () => rej(r.error);
            });
            const targetName = item.handle?.name || item.name;
            for (let i = 0; i < vals.length; i++) {
                const entry = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(vals[i]) : null;
                const h = entry?.handle || vals[i];
                const n = entry?.name || vals[i]?.name || h?.name;
                if (h === item.handle || (targetName && n === targetName)) {
                    handleKey = keys[i];
                    break;
                }
            }
        } catch (e) {
            console.warn(e);
        }

        if (handleKey == null) {
            try {
                const tx = db.transaction(storeName, 'readwrite');
                handleKey = await new Promise((res, rej) => {
                    const payload = {
                        handle: item.handle,
                        name: item.handle?.name || item.name,
                        addedAt: Date.now(),
                    };
                    const r = tx.objectStore(storeName).add(payload);
                    r.onsuccess = () => res(r.result);
                    r.onerror = () => rej(r.error);
                });
            } catch (e) {
                alert('Could not resolve file in library: ' + e.message);
                return;
            }
        }

        pl.items = pl.items || [];
        const exists = pl.items.some(i => i.store === storeName && String(i.key) === String(handleKey));
        if (!exists) {
            pl.items.push({ store: storeName, key: handleKey });
            const tx = db.transaction('playlists', 'readwrite');
            await new Promise((res, rej) => {
                const r = tx.objectStore('playlists').put(pl);
                r.onsuccess = () => res();
                r.onerror = () => rej(r.error);
            });
        }
        closePlaylistPicker();
        if (hud.title) {
            const prev = hud.title.textContent;
            hud.title.textContent = `✓ Added to ${pl.name}`;
            setTimeout(() => { if (hud.title) hud.title.textContent = prev; }, 1600);
        }
    }

    document.getElementById('playlist-pick-cancel')?.addEventListener('click', closePlaylistPicker);
    document.getElementById('playlist-pick-ok')?.addEventListener('click', () => addCurrentToPlaylist());
    document.getElementById('playlist-pick')?.addEventListener('click', (e) => {
        if (e.target.id === 'playlist-pick') closePlaylistPicker();
    });

    function toggleMute() {
        if (!mainVideo) return;
        mainVideo.muted = !mainVideo.muted;
        if (!mainVideo.muted && mainVideo.volume === 0 && hud.volume) {
            mainVideo.volume = hud.volume.value / 100;
        }
        updateHudMuteIcon();
    }

    function toggleShuffle() {
        cfg.shuffle = !cfg.shuffle;
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, shuffle: cfg.shuffle}});
        });
        if (cfg.shuffle && playlist.length > 1) {
            const current = playlist[currentIdx];
            const rest = playlist.filter((_, i) => i !== currentIdx);
            shuffleInPlace(rest);
            playlist = [current, ...rest];
            currentIdx = 0;
            playHistory = []; // indices invalidated by reorder
            updateHUD();
        }
    }

    function formatSpeedLabel(speed) {
        if (speed === 1) return '1×';
        if (speed === 0.33) return '0.33×';
        if (speed === 0.25) return '0.25×';
        return `${speed}×`;
    }

    function changeSpeed(dir) {
        const idx = SPEED_STEPS.indexOf(cfg.playbackSpeed);
        const base = idx < 0 ? SPEED_STEPS.indexOf(1) : idx;
        const next = SPEED_STEPS[Math.max(0, Math.min(SPEED_STEPS.length - 1, base + dir))];
        setPlaybackSpeed(next);
        revealHud();
    }

    /** Apply cfg.playbackSpeed to active media. Must re-run after src changes (browsers reset rate). */
    function applyPlaybackSpeed() {
        const speed = cfg.playbackSpeed || 1;
        if (mainVideo && mainVideo.tagName === 'VIDEO') {
            try { mainVideo.playbackRate = speed; } catch (_) {}
        }
        if (ambienceVideo) {
            try { ambienceVideo.playbackRate = speed; } catch (_) {}
        }
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(speed);
    }

    function setPlaybackSpeed(speed) {
        cfg.playbackSpeed = speed;
        applyPlaybackSpeed();
        chrome.storage.local.get('mediaConfig', ({ mediaConfig = {} }) => {
            if (mediaConfig.playbackSpeed === speed) return;
            chrome.storage.local.set({ mediaConfig: { ...mediaConfig, playbackSpeed: speed } });
        });
    }

    async function togglePiP() {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        try {
            if (document.pictureInPictureElement) {
                await document.exitPictureInPicture();
            } else if (document.pictureInPictureEnabled) {
                await mainVideo.requestPictureInPicture();
            }
        } catch (e) { console.warn('PiP unavailable', e); }
    }

    function formatTime(sec) {
        if (!isFinite(sec) || sec < 0) return '0:00';
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    }

    function updateProgressUI() {
        if (!mainVideo || !mainVideo.duration) return;
        const ratio = mainVideo.currentTime / mainVideo.duration;
        const pct = `${ratio * 100}%`;
        if (hud.progress) hud.progress.style.width = pct;
        if (hud.progressThumb) hud.progressThumb.style.left = pct;
        if (hud.timeCurrent) hud.timeCurrent.textContent = formatTime(mainVideo.currentTime);
        if (hud.timeTotal) hud.timeTotal.textContent = formatTime(mainVideo.duration);
    }

    function seekFromEvent(e) {
        if (!mainVideo || !mainVideo.duration || !hud.progressTrack) return;
        const rect = hud.progressTrack.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        // Seeking near/past end can fire `ended` — suppress spurious skip
        suppressEndedUntil = Date.now() + 450;
        mainVideo.currentTime = ratio * mainVideo.duration;
        if (ambienceVideo && ambienceVideo.duration) ambienceVideo.currentTime = mainVideo.currentTime;
        updateProgressUI();
    }

    function initProgressSeek() {
        if (!hud.progressTrack) return;
        const onDown = (e) => {
            if (!mainVideo?.duration) return;
            isSeeking = true;
            suppressEndedUntil = Date.now() + 800;
            hud.progressTrack.classList.add('seeking');
            seekFromEvent(e);
            e.preventDefault();
        };
        const onMove = (e) => { if (isSeeking) seekFromEvent(e); };
        const onUp = () => {
            isSeeking = false;
            suppressEndedUntil = Date.now() + 400;
            hud.progressTrack?.classList.remove('seeking');
        };
        hud.progressTrack.addEventListener('mousedown', onDown);
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    function setVolume(level) {
        const vol = Math.max(0, Math.min(1, level));
        cfg.volume = vol;
        if (mainVideo) {
            mainVideo.volume = vol;
            if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
        }
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        updateHudMuteIcon();
        // Debounce storage writes so sliding the volume doesn't thrash storage
        // (and so even a mis-fired rebuild can't spam-reshuffle mid-drag)
        clearTimeout(volumeSaveTimer);
        volumeSaveTimer = setTimeout(() => {
            chrome.storage.local.get('mediaConfig', ({ mediaConfig = {} }) => {
                // Only write if volume actually differs (avoids echo loops)
                if (mediaConfig.volume === vol) return;
                chrome.storage.local.set({ mediaConfig: { ...mediaConfig, volume: vol } });
            });
        }, 180);
    }

    function saveHudLayout() {
        chrome.storage.local.set({
            fafoHudDock: hudDock,
            fafoHudPinned: hudPinned,
            fafoHudX: hudX,
            fafoHudY: hudY,
        }).catch(() => {});
    }

    function clampHudXY(x, y) {
        const el = hud.box;
        const w = el?.offsetWidth || 340;
        const h = el?.offsetHeight || 140;
        const minVis = 64;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const loX = -(Math.max(0, w - minVis));
        const hiX = Math.max(0, ww - minVis);
        const loY = 0;
        const hiY = Math.max(0, wh - minVis);
        return {
            x: Math.round(Math.max(loX, Math.min(hiX, Number(x) || 0))),
            y: Math.round(Math.max(loY, Math.min(hiY, Number(y) || 0))),
        };
    }

    /** Always pin HUD with left/top (never right/bottom — CSS forces auto there). */
    function placeHudAt(x, y) {
        const el = hud.box;
        if (!el) return;
        const c = clampHudXY(x, y);
        hudX = c.x;
        hudY = c.y;
        el.style.setProperty('left', `${hudX}px`, 'important');
        el.style.setProperty('top', `${hudY}px`, 'important');
        el.style.setProperty('right', 'auto', 'important');
        el.style.setProperty('bottom', 'auto', 'important');
        el.style.setProperty('transform', 'none', 'important');
    }

    function coordsForHudSnap(pos) {
        const el = hud.box;
        const m = 18;
        const ww = window.innerWidth || 800;
        const wh = window.innerHeight || 600;
        const w = Math.max(200, el?.offsetWidth || 340);
        const h = Math.max(80, el?.offsetHeight || 160);
        switch (pos) {
            case 'bl':
                return { x: m, y: Math.max(m, wh - h - m) };
            case 'br':
                return { x: Math.max(m, ww - w - m), y: Math.max(m, wh - h - m) };
            case 'mr':
                return { x: Math.max(m, ww - w - m), y: Math.max(m, Math.round((wh - h) / 2)) };
            case 'free':
            default:
                return { x: hudX, y: hudY };
        }
    }

    function setHudFreeStyles(el, x, y) {
        if (!el) return;
        el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr');
        el.classList.add('hud-dock-free');
        el.dataset.hudDock = 'free';
        placeHudAt(x, y);
    }

    function applyHudLayout() {
        if (!hud.box) return;
        const el = hud.box;
        el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr', 'hud-dock-free', 'hud-pinned');
        const dock = ['mr', 'br', 'bl', 'free'].includes(hudDock) ? hudDock : 'mr';
        hudDock = dock;
        el.classList.add(`hud-dock-${dock}`);
        el.dataset.hudDock = dock;
        if (hudPinned) el.classList.add('hud-pinned');

        // Always left/top pixels — dock mode only picks the target coords
        const place = () => {
            if (dock === 'free') {
                placeHudAt(hudX, hudY);
            } else {
                const c = coordsForHudSnap(dock);
                placeHudAt(c.x, c.y);
            }
        };
        place();
        requestAnimationFrame(place);

        const dockBtn = document.getElementById('hud-dock-cycle');
        if (dockBtn) {
            const label = { mr: 'MR', bl: 'BL', br: 'BR', free: 'Free' }[dock] || 'MR';
            dockBtn.textContent = `Dock · ${label}`;
            dockBtn.classList.toggle('active', dock === 'free');
            dockBtn.title = 'Cycle: mid-right → bottom-right → bottom-left → free. Or drag the Player bar anytime.';
        }
        const pinBtn = document.getElementById('hud-pin');
        if (pinBtn) {
            pinBtn.classList.toggle('active', !!hudPinned);
            pinBtn.textContent = hudPinned ? 'Pinned' : 'Pin';
            pinBtn.title = hudPinned
                ? 'Always visible · click to allow auto-hide'
                : 'Keep controls always visible (no auto-hide)';
        }
    }

    function cycleHudDock() {
        const order = ['mr', 'br', 'bl', 'free'];
        const i = order.indexOf(hudDock);
        hudDock = order[(i + 1) % order.length];
        if (hudDock === 'free' && hud.box) {
            const r = hud.box.getBoundingClientRect();
            const c = clampHudXY(r.left, r.top);
            hudX = c.x;
            hudY = c.y;
        }
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    /** Force free-float HUD into a grab-able on-screen spot. */
    function undockHudForMove() {
        if (!hud.box) return;
        const r = hud.box.getBoundingClientRect();
        hudDock = 'free';
        hudPinned = true;
        if (r.width > 0) {
            const c = clampHudXY(r.left, r.top);
            hudX = c.x;
            hudY = c.y;
        } else {
            hudX = Math.max(18, Math.round((window.innerWidth || 800) * 0.55));
            hudY = Math.max(18, Math.round((window.innerHeight || 600) * 0.35));
        }
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    function resetHudLayout() {
        hudDock = 'mr';
        hudPinned = true;
        hudX = 18;
        hudY = 18;
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    function toggleHudPin() {
        hudPinned = !hudPinned;
        applyHudLayout();
        saveHudLayout();
        revealHud();
    }

    function initHudDrag() {
        const el = hud.box;
        if (!el) return;
        const handle = document.getElementById('hud-drag-handle') || el;
        let offX = 0;
        let offY = 0;
        let activePointerId = null;

        // Make the whole chrome bar an obvious drag target
        handle.style.pointerEvents = 'auto';
        handle.style.cursor = 'grab';
        handle.style.touchAction = 'none';
        handle.style.userSelect = 'none';

        const isBlockedTarget = (target) =>
            !!target?.closest?.('.hud-chrome-actions button, .hud-controls button, .hud-controls input, input, a, select, textarea, #hud-progress-track');

        const paintFree = (x, y) => {
            hudDock = 'free';
            hudX = x;
            hudY = y;
            el.classList.remove('hud-dock-bl', 'hud-dock-br', 'hud-dock-mr');
            el.classList.add('hud-dock-free', 'hud-pinned');
            el.dataset.hudDock = 'free';
            hudPinned = true; // keep visible while free-dragging
            placeHudAt(x, y);
            const dockBtn = document.getElementById('hud-dock-cycle');
            if (dockBtn) {
                dockBtn.textContent = 'Dock · Free';
                dockBtn.classList.add('active');
            }
            const pinBtn = document.getElementById('hud-pin');
            if (pinBtn) {
                pinBtn.classList.add('active');
                pinBtn.textContent = 'Pinned';
            }
        };

        const onMove = (cx, cy) => {
            if (!hudDragging) return;
            const c = clampHudXY(cx - offX, cy - offY);
            paintFree(c.x, c.y);
        };

        const end = (e) => {
            if (!hudDragging) return;
            hudDragging = false;
            activePointerId = null;
            handle.classList.remove('dragging');
            handle.style.cursor = 'grab';
            el.classList.remove('dragging');
            document.body.style.userSelect = '';
            document.body.style.cursor = '';
            window.removeEventListener('pointermove', onPointerMove, true);
            window.removeEventListener('pointerup', onPointerUp, true);
            window.removeEventListener('pointercancel', onPointerUp, true);
            window.removeEventListener('mousemove', onMouseMove, true);
            window.removeEventListener('mouseup', onMouseUp, true);
            if (e && e.pointerId != null) {
                try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
                try { el.releasePointerCapture(e.pointerId); } catch (_) {}
            }
            saveHudLayout();
        };

        const onPointerMove = (e) => {
            if (!hudDragging) return;
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            onMove(e.clientX, e.clientY);
            e.preventDefault();
        };
        const onPointerUp = (e) => {
            if (activePointerId != null && e.pointerId !== activePointerId) return;
            end(e);
        };
        const onMouseMove = (e) => { if (hudDragging) onMove(e.clientX, e.clientY); };
        const onMouseUp = () => end();

        const start = (cx, cy, target) => {
            if (isBlockedTarget(target)) return false;
            const r = el.getBoundingClientRect();
            hudDragging = true;
            offX = cx - r.left;
            offY = cy - r.top;
            handle.classList.add('dragging');
            handle.style.cursor = 'grabbing';
            el.classList.add('dragging');
            document.body.style.userSelect = 'none';
            document.body.style.cursor = 'grabbing';
            // Convert current on-screen rect → free coords immediately
            paintFree(Math.round(r.left), Math.round(r.top));
            return true;
        };

        // Drag from the Player chrome bar (⋮⋮ / label / empty space)
        handle.addEventListener('pointerdown', (e) => {
            if (e.button != null && e.button !== 0) return;
            if (!start(e.clientX, e.clientY, e.target)) return;
            activePointerId = e.pointerId;
            try { handle.setPointerCapture(e.pointerId); } catch (_) {}
            window.addEventListener('pointermove', onPointerMove, true);
            window.addEventListener('pointerup', onPointerUp, true);
            window.addEventListener('pointercancel', onPointerUp, true);
            e.preventDefault();
            e.stopPropagation();
        });

        // Also allow dragging from the title row (bigger hit target)
        const track = el.querySelector('.hud-track');
        if (track) {
            track.style.cursor = 'grab';
            track.style.touchAction = 'none';
            track.addEventListener('pointerdown', (e) => {
                if (e.button != null && e.button !== 0) return;
                if (!start(e.clientX, e.clientY, e.target)) return;
                activePointerId = e.pointerId;
                try { track.setPointerCapture(e.pointerId); } catch (_) {}
                window.addEventListener('pointermove', onPointerMove, true);
                window.addEventListener('pointerup', onPointerUp, true);
                window.addEventListener('pointercancel', onPointerUp, true);
                e.preventDefault();
                e.stopPropagation();
            });
        }

        window.addEventListener('resize', () => {
            if (!hudDragging) applyHudLayout();
        });
    }

    async function loadHudLayout() {
        try {
            const res = await chrome.storage.local.get([
                'fafoHudDock', 'fafoHudPinned', 'fafoHudX', 'fafoHudY',
            ]);
            // First run / no saved dock → mid-right (default)
            if (['mr', 'bl', 'br', 'free'].includes(res.fafoHudDock)) hudDock = res.fafoHudDock;
            else hudDock = 'mr';
            // Default pinned ON so controls stay available
            if (typeof res.fafoHudPinned === 'boolean') hudPinned = res.fafoHudPinned;
            else hudPinned = true;
            if (typeof res.fafoHudX === 'number') hudX = res.fafoHudX;
            if (typeof res.fafoHudY === 'number') hudY = res.fafoHudY;
        } catch (_) {
            hudDock = 'mr';
            hudPinned = true;
        }
        applyHudLayout();
    }

    function revealHud() {
        if (!hud.box || cfg.layout !== 'cinema') return;
        hud.box.classList.add('hud-visible');
        hud.box.classList.remove('hud-idle');
        clearTimeout(hudIdleTimer);
        // Pinned or free-float: stay visible, never auto-hide
        if (hudPinned || hudDock === 'free') return;
        hudIdleTimer = setTimeout(() => {
            if (!hud.box.matches(':hover') && !hudPinned && hudDock !== 'free') {
                hud.box.classList.add('hud-idle');
            }
            hud.box.classList.remove('hud-visible');
        }, HUD_IDLE_MS);
    }

    function initHudAutoHide() {
        if (cfg.layout === 'cinema') revealHud();
        else if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
    }

    function updateEmptyState() {
        if (!emptyState) return;
        emptyState.classList.toggle('hidden', !libraryEmpty || cfg.layout !== 'cinema');
    }

    function toggleFullscreen() {
        document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    }

    function togglePause() {
        if (cfg.layout === 'collage') {
            isPaused = !isPaused;
            ui.clock.style.opacity = isPaused ? 0.5 : 1;
            if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
            return;
        }

        if (!mainVideo) return;

        // At end while looping (untagged / skip-tagged): restart — never auto-advance on Space
        if (mainVideo.ended && (isPaused || mainVideo.paused)) {
            if (isClipLoopMode()) {
                try {
                    mainVideo.currentTime = 0;
                    applyPlaybackSpeed();
                    isPaused = false;
                    ui.clock.style.opacity = 1;
                    if (hud.play) hud.play.textContent = '⏸';
                    mainVideo.play().catch(() => {});
                    if (ambienceVideo) {
                        ambienceVideo.currentTime = 0;
                        ambienceVideo.play().catch(() => {});
                    }
                    window.FAFOMeta?.notifyEndNeedsTag?.();
                } catch (_) {}
                revealHud();
                return;
            }
            // Tagged & not looping — go to next clip
            loopCount = 0;
            if (playlist.length) {
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            isPaused = false;
            ui.clock.style.opacity = 1;
            if (hud.play) hud.play.textContent = '⏸';
            playNext({ instant: true });
            revealHud();
            return;
        }

        isPaused = !isPaused;
        ui.clock.style.opacity = isPaused ? 0.5 : 1;
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';

        if (isPaused) {
            mainVideo.pause();
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.pause();
        } else {
            consecutiveErrors = 0;
            clearPlayOverlay();
            // If we stalled mid-load, restart the current item cleanly
            if (!mainVideo.src || mainVideo.error || mainVideo.readyState < 2) {
                playNext({ instant: true, force: true });
            } else {
                mainVideo.play().catch((e) => {
                    console.warn('Resume play failed, reloading clip', e);
                    playNext({ instant: true, force: true });
                });
                if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.play().catch(() => {});
            }
        }
        syncParticlePerformance();
        revealHud();
    }

    function getTrackName(item) {
        if (!item) return '—';
        if (item.name) return item.name;
        if (item.handle?.name) return item.handle.name;
        if (item.url) return item.url.split('/').pop().split('?')[0] || 'Stream';
        return 'Unknown';
    }

    function updateHUD() {
        if (!hud.box) return;
        const item = playlist[currentIdx];
        if (hud.title) hud.title.textContent = getTrackName(item);
        if (hud.index) hud.index.textContent = playlist.length ? `${currentIdx + 1} / ${playlist.length}` : '0 / 0';
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(cfg.playbackSpeed || 1);
        updateHudMuteIcon();
        const isVideo = item?.type === 'video' && cfg.layout === 'cinema';
        if (hud.progressWrap) hud.progressWrap.classList.toggle('hidden', !isVideo);
        if (!isVideo && hud.timeCurrent) hud.timeCurrent.textContent = '0:00';
        if (!isVideo && hud.timeTotal) hud.timeTotal.textContent = '0:00';
        updateLoopHudChip();
        updateEmptyState();
    }

    function updateHudMuteIcon() {
        if (!hud.mute) return;
        const muted = !mainVideo || mainVideo.muted || mainVideo.volume === 0;
        hud.mute.textContent = muted ? '🔇' : '🔊';
    }

    function startProgressBar() {
        if (progressInterval) clearInterval(progressInterval);
        if (!mainVideo) return;
        mainVideo.removeEventListener('timeupdate', updateProgressUI);
        mainVideo.addEventListener('timeupdate', updateProgressUI);
        updateProgressUI();
    }

    function bindHudReveal(el, fn) {
        if (!el) return;
        el.addEventListener('click', () => { revealHud(); fn(); });
    }

    function initHudControls() {
        bindHudReveal(hud.prev, () => skipTrack(-1));
        bindHudReveal(hud.next, () => skipTrack(1));
        bindHudReveal(hud.play, () => togglePause());
        bindHudReveal(hud.shuffle, () => toggleShuffle());
        bindHudReveal(hud.speedDown, () => changeSpeed(-1));
        bindHudReveal(hud.speedUp, () => changeSpeed(1));
        if (hud.speed) hud.speed.onclick = () => { revealHud(); setPlaybackSpeed(1); };
        bindHudReveal(document.getElementById('hud-repeat'), () => toggleManualRepeat());
        bindHudReveal(document.getElementById('hud-extra-apply'), () => {
            const bank = window.FAFOMeta?.getExtraLiveBank?.() ?? 0;
            window.FAFOMeta?.applyExtraTagBank?.(bank);
        });
        bindHudReveal(hud.mute, () => toggleMute());
        bindHudReveal(hud.pip, () => togglePiP());
        bindHudReveal(hud.fs, () => toggleFullscreen());
        bindHudReveal(document.getElementById('hud-playlist'), () => openPlaylistPicker());
        if (hud.volume) {
            hud.volume.value = Math.round((cfg.volume ?? 0.7) * 100);
            hud.volume.addEventListener('input', () => {
                revealHud();
                setVolume(hud.volume.value / 100);
            });
        }
        initProgressSeek();
        const helpClose = document.getElementById('help-close');
        if (helpClose) helpClose.onclick = () => shortcutHelp?.classList.add('hidden');
        if (hud.box) {
            hud.box.addEventListener('mouseenter', revealHud);
            hud.box.addEventListener('mousemove', revealHud);
        }
        if (hud.progressTrack) {
            hud.progressTrack.addEventListener('mousedown', revealHud);
        }
        // Undock / pin / always-on-top
        document.getElementById('hud-dock-cycle')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            cycleHudDock();
        });
        document.getElementById('hud-pin')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleHudPin();
        });
        initHudDrag();
        loadHudLayout().then(() => revealHud());
        chrome.storage.local.get(['fafoManualRepeat'], (res) => {
            manualRepeat = !!res.fafoManualRepeat;
            updateRepeatButton();
            refreshLoopMode();
        });
        // E-set UI lives in FAFOMeta but render after a tick so module is ready
        setTimeout(() => window.FAFOMeta?.renderExtraTagHud?.(), 200);
        updateHUD();
    }

    // --- 4. LIBRARY MANAGEMENT ---

    function toPlaylistItem(entry, typeHint) {
        if (!entry) return null;
        const unwrapped = window.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(entry) : null;
        if (unwrapped?.handle) {
            return {
                type: typeHint || (unwrapped.storeName === 'photos' ? 'photo' : 'video'),
                handle: unwrapped.handle,
                name: unwrapped.name,
            };
        }
        if (entry.handle) {
            return { type: typeHint || 'video', handle: entry.handle, name: entry.name };
        }
        if (typeof entry.getFile === 'function' || entry.kind === 'file') {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        if (entry instanceof File) {
            return { type: typeHint || 'video', handle: entry, name: entry.name };
        }
        return null;
    }

    async function buildPlaylist() {
        playlist = [];
        libraryEmpty = false;
        
        // 1. PLAYLIST MODE: manual or smart
        if (cfg.activePlaylistId && cfg.activePlaylistId !== 'all' && db) {
            try {
                const tx = db.transaction('playlists', 'readonly');
                const store = tx.objectStore('playlists');
                const pl = await new Promise(res => {
                    const req = store.get(cfg.activePlaylistId);
                    req.onsuccess = () => res(req.result);
                    req.onerror = () => res(null);
                });

                if (pl && window.FAFOLibrary?.resolvePlaylist) {
                    const { fafoMediaMeta = {} } = await chrome.storage.local.get('fafoMediaMeta');
                    const resolved = await FAFOLibrary.resolvePlaylist(db, pl, fafoMediaMeta);
                    for (const item of resolved) {
                        playlist.push({
                            type: item.type,
                            handle: item.handle,
                            name: item.name,
                        });
                    }
                } else if (pl?.items?.length) {
                    for (const itemRef of pl.items) {
                        const raw = await getHandleByKey(itemRef.store || itemRef.storeName, itemRef.key);
                        const item = toPlaylistItem(raw, (itemRef.store || itemRef.storeName) === 'photos' ? 'photo' : 'video');
                        if (item) playlist.push(item);
                    }
                }
            } catch (e) { console.warn('Failed to load playlist', e); }
        } 
        
        // 2. FALLBACK TO ALL IF EMPTY OR 'ALL' MODE
        if (playlist.length === 0) {
            if (cfg.useLocal) {
                const videos = await getHandles('videos');
                for (const h of videos) {
                    const item = toPlaylistItem(h, 'video');
                    if (item) playlist.push(item);
                }
            }
            if (cfg.usePhotos) {
                const photos = await getHandles('photos');
                for (const h of photos) {
                    const item = toPlaylistItem(h, 'photo');
                    if (item) playlist.push(item);
                }
            }
            // Bundled/default Videos are disabled — only folders the user added
            // (and optional cfg.urls) are used. No flower.webm / sample pack.
        }
        
        // 3. Empty state (no remote demo clip)
        if (playlist.length === 0) {
            if (cfg.urls && cfg.urls.length > 0) {
                playlist = cfg.urls.map(u => ({type: 'video', url: u}));
            } else {
                libraryEmpty = true;
                playlist = [];
            }
        }
        
        if (cfg.shuffle) shuffleInPlace(playlist);
        updateEmptyState();
        maybeShowRestoreBanner();
    }

    // Helper to get specific item for playlist
    async function getHandleByKey(storeName, key) {
        return new Promise(res => {
            try {
                const tx = db.transaction(storeName, 'readonly');
                const req = tx.objectStore(storeName).get(key);
                req.onsuccess = () => res(req.result);
                req.onerror = () => res(null);
            } catch(e) { res(null); }
        });
    }

    /** Bundled sample library is no longer shipped (was redundant). Kept as empty stub. */
    async function loadBundledLibrary() {
        return [];
    }

    let restoreBannerEl = null;

    function removeRestoreBanner() {
        if (restoreBannerEl) {
            if (restoreBannerEl._wrap) restoreBannerEl._wrap.remove();
            else restoreBannerEl.remove();
            restoreBannerEl = null;
        }
        permissionWarned = false;
    }

    async function restoreLibraryAccessFromBanner() {
        if (!db || !window.FAFOLibrary) {
            window.location.href = 'options.html';
            return;
        }
        try {
            // Stop failure cascade while we re-auth
            clearTimeout(playFailTimer);
            playToken++;
            consecutiveErrors = 0;
            userUnlockedAudio = true;
            if (restoreBannerEl) {
                restoreBannerEl.textContent = '🔓 Restoring access… allow if Chrome asks';
                restoreBannerEl.disabled = true;
            }
            const r = await FAFOLibrary.restoreAccess(db);
            // Optional light resync when folders exist
            const folders = await FAFOLibrary.listFolders(db);
            if (folders.length) {
                await FAFOLibrary.resyncAllFolders(db);
            }
            removeRestoreBanner();
            await buildPlaylist();
            // Full layout rebuild can race; cancel again then rebuild once
            clearTimeout(playFailTimer);
            playToken++;
            consecutiveErrors = 0;
            if (typeof initLayout === 'function') initLayout();
            else if (typeof playNext === 'function') playNext({ instant: true, force: true });
            console.info('Library access restored', r);
        } catch (e) {
            console.warn(e);
            if (restoreBannerEl) {
                restoreBannerEl.disabled = false;
                restoreBannerEl.textContent = '⚠️ Restore failed — click for Options';
                restoreBannerEl.onclick = () => { window.location.href = 'options.html'; };
            }
        }
    }

    function showRestoreBanner(msg) {
        if (restoreBannerEl) return;
        permissionWarned = true;
        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:96vw;';
        const warn = document.createElement('button');
        warn.textContent = msg || '⚠️ Library access lost — click to Restore (no re-link)';
        warn.style.cssText = 'background:#d32f2f;color:white;padding:12px 18px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.5);';
        warn.onclick = () => restoreLibraryAccessFromBanner();
        const opt = document.createElement('button');
        opt.textContent = 'Options';
        opt.style.cssText = 'background:#222;color:#fff;padding:12px 14px;border:1px solid #555;border-radius:8px;cursor:pointer;';
        opt.onclick = () => { window.location.href = 'options.html'; };
        wrap.appendChild(warn);
        wrap.appendChild(opt);
        document.body.appendChild(wrap);
        restoreBannerEl = warn;
        // Keep wrap as parent for remove
        restoreBannerEl._wrap = wrap;
        const origRemove = restoreBannerEl.remove.bind(restoreBannerEl);
        restoreBannerEl.remove = () => { wrap.remove(); };
    }

    async function maybeShowRestoreBanner() {
        if (!db || !window.FAFOLibrary || permissionWarned) return;
        try {
            const st = await FAFOLibrary.libraryAccessStatus(db);
            if (st.needsRestore && (st.folders > 0 || st.sampleBad > 0)) {
                showRestoreBanner('⚠️ Library access needs restore — click here (saved folders, no re-pick)');
            }
        } catch (_) {}
    }

    async function getSrc(item) {
        if (item.url) return item.url;
        if (item.handle) {
            if (item.handle instanceof File) {
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(item.handle);
                return currentBlobUrl;
            }
            try {
                if (window.FAFOLibrary) {
                    const ok = await FAFOLibrary.ensurePermission(item.handle, 'read');
                    if (!ok) throw new Error('permission denied');
                }
                const file = await item.handle.getFile();
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(file);
                removeRestoreBanner();
                return currentBlobUrl;
            } catch (e) {
                showRestoreBanner('⚠️ Permissions lost — click to Restore Access (keeps your folders)');
                return null;
            }
        }
        return null;
    }

    async function getHandles(store) {
        if (!db) return [];
        try {
            const tx = db.transaction(store, 'readonly');
            const req = tx.objectStore(store).getAll();
            return new Promise(res => req.onsuccess = () => res(req.result || []));
        } catch(e) { return []; }
    }
    
    function getObjectFitFromConfig() {
        switch(cfg.scaling) {
            case 'scale-cover': return 'cover';
            case 'scale-contain': return 'contain';
            case 'scale-capped': return 'capped';
            case 'scale-fit-window': return 'capped'; 
            case 'scale-center': return 'none';
            default: return 'contain';
        }
    }

    // --- 5. LAYOUT ENGINES ---

    function initLayout() {
        scene.innerHTML = '';
        if (collageInterval) clearInterval(collageInterval);
        if (photoTimeout) clearTimeout(photoTimeout);
        if (progressInterval) clearInterval(progressInterval);
        if (neonEngine) neonEngine.disconnectAudio();
        revokeCurrentBlob();

        if (cfg.layout !== 'cinema') {
            overlay.style.opacity = '0';
            if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
        } else {
            initHudAutoHide();
        }

        scene.className = `layout-${cfg.layout}`;
        scene.removeAttribute('style'); 
        
        if (cfg.layout === 'grid') initGrid();
        else if (cfg.layout === 'carousel') initCarousel();
        else if (cfg.layout === 'collage') initCollage(); 
        else initCinema();
    }

    function initCinema() {
        // Dual-video ambilight (2× decode + huge CSS blur) is the #1 lag source on 4K.
        const useAmbiVideo = cfg.ambiMode === 'blur'
            && !cfg.disableAmbience
            && !cfg.performanceMode;

        if (useAmbiVideo) {
            ambienceVideo = document.createElement('video');
            ambienceVideo.className = 'ambience';
            ambienceVideo.muted = true;
            ambienceVideo.loop = true;
            ambienceVideo.playsInline = true;
            // Prefer cheaper blur in normal mode; still expensive — keep scale modest
            const blurPx = Math.min(cfg.ambiBlur || 5, 12);
            ambienceVideo.style.filter = `blur(${blurPx}px) brightness(${cfg.ambiOpacity}) saturate(1.1)`;
            ambienceVideo.style.transform = `translate(-50%, -50%) scale(${cfg.ambiScale}) translateZ(0)`;
            ambienceVideo.style.willChange = 'transform';
            scene.appendChild(ambienceVideo);
        } else {
            scene.style.backgroundColor = cfg.accentColor || '#000';
            ambienceVideo = null;
        }

        mainVideo = document.createElement('video');
        mainVideo.id = 'bg-video';
        mainVideo.playsInline = true;
        mainVideo.autoplay = true;
        // Prefer hardware decode paths; avoid software filter on the video element itself
        try { mainVideo.disableRemotePlayback = true; } catch (_) {}
        applyVideoGpuHints(mainVideo);
        scene.appendChild(mainVideo);

        playNext();
        updateHUD();
        
        mainVideo.addEventListener('play', syncParticlePerformance);
        mainVideo.addEventListener('pause', syncParticlePerformance);
        // Browsers often reset playbackRate on new media — re-apply on play/load only
        // (do not force on ratechange — fights intentional / browser edge cases)
        mainVideo.addEventListener('play', () => applyPlaybackSpeed());
        mainVideo.addEventListener('loadeddata', () => applyPlaybackSpeed());
        mainVideo.addEventListener('loadedmetadata', () => applyPlaybackSpeed());

        mainVideo.onended = () => {
            if (mediaLoading || isSeeking || Date.now() < suppressEndedUntil) return;

            // Continuous loop fallback when native loop doesn't fire or was briefly false
            if (isClipLoopMode() || manualRepeat) {
                mainVideo.loop = true;
                if (ambienceVideo) ambienceVideo.loop = true;
                restartClipFromStart('onended');
                if (window.FAFOMeta?.isUntagged?.()) {
                    window.FAFOMeta.notifyEndNeedsTag?.();
                }
                updateLoopHudChip();
                return;
            }

            if (++loopCount >= cfg.loops) {
                loopCount = 0;
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
            }
            playNext();
        };

        // NOTE: Do NOT restart on every pause — loadAndPlayVideo intentionally pauses
        // while swapping sources; that was racing Chrome and killing playback.

        const sync = () => {
            if(ambienceVideo && Math.abs(mainVideo.currentTime - ambienceVideo.currentTime) > 0.5) 
                ambienceVideo.currentTime = mainVideo.currentTime;
        };
        
        if(ambienceVideo) {
            mainVideo.addEventListener('play', () => {
                if (mediaLoading) return;
                ambienceVideo.play().catch(()=>{});
            });
            mainVideo.addEventListener('pause', () => {
                if (mediaLoading) return;
                ambienceVideo.pause();
            });
            mainVideo.addEventListener('timeupdate', sync);
        }
    }

    function clearPlayOverlay() {
        if (overlay) overlay.style.opacity = '0';
    }

    function resetPlaybackErrors() {
        consecutiveErrors = 0;
    }

    function showRetryPlaybackBanner(msg) {
        // Prefer a non-destructive retry (restoreAccess rebuilds the whole library and races playNext)
        if (restoreBannerEl) {
            try { restoreBannerEl.remove(); } catch (_) {}
            restoreBannerEl = null;
        }
        const wrap = document.createElement('div');
        wrap.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:9999;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;max-width:96vw;';
        const retry = document.createElement('button');
        retry.textContent = msg || '⚠️ Playback stuck — click to retry';
        retry.style.cssText = 'background:#1565c0;color:white;padding:12px 18px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.5);';
        retry.onclick = () => {
            userUnlockedAudio = true;
            consecutiveErrors = 0;
            playToken++; // cancel in-flight
            clearTimeout(playFailTimer);
            try { wrap.remove(); } catch (_) {}
            restoreBannerEl = null;
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
            playNext({ instant: true, force: true });
        };
        const restore = document.createElement('button');
        restore.textContent = 'Restore library access';
        restore.style.cssText = 'background:#d32f2f;color:white;padding:12px 14px;border:none;border-radius:8px;cursor:pointer;font-weight:bold;';
        restore.onclick = () => restoreLibraryAccessFromBanner();
        const opt = document.createElement('button');
        opt.textContent = 'Options';
        opt.style.cssText = 'background:#222;color:#fff;padding:12px 14px;border:1px solid #555;border-radius:8px;cursor:pointer;';
        opt.onclick = () => { window.location.href = 'options.html'; };
        wrap.appendChild(retry);
        wrap.appendChild(restore);
        wrap.appendChild(opt);
        document.body.appendChild(wrap);
        restoreBannerEl = retry;
        restoreBannerEl._wrap = wrap;
        restoreBannerEl.remove = () => { wrap.remove(); };
    }

    /** Advance after a hard failure so we never freeze on one bad clip / autoplay reject. */
    function advanceAfterPlayFailure(reason, token) {
        // Ignore failures from superseded playNext calls (the main cascade bug)
        if (token != null && token !== playToken) return;

        consecutiveErrors++;
        const msg = reason && (reason.message || reason.name || reason);
        console.warn('Playback failure:', msg || reason, `(streak ${consecutiveErrors})`);
        clearPlayOverlay();
        if (!playlist.length) return;

        pushPlayHistory(currentIdx);
        currentIdx = findNextEligibleIndex(currentIdx, 1);

        clearTimeout(playFailTimer);
        if (consecutiveErrors > 6) {
            consecutiveErrors = 0;
            isPaused = true;
            if (hud.play) hud.play.textContent = '▶';
            if (hud.title) hud.title.textContent = 'Playback stuck — click Retry';
            revealHud();
            showRetryPlaybackBanner('⚠️ Playback stuck — click to retry current library');
            return;
        }
        playFailTimer = setTimeout(() => {
            if (token != null && token !== playToken) return;
            playNext({ instant: true });
        }, 80);
    }

    /**
     * Load a blob/url into the video and start playback.
     * Starts muted for reliable Chrome new-tab autoplay; unmutes after a user gesture.
     */
    async function loadAndPlayVideo(video, src, token) {
        if (!video) throw new Error('no video element');
        if (token !== playToken) return;

        mediaLoading = true;
        suppressEndedUntil = Date.now() + 800;

        try {
            try { video.pause(); } catch (_) {}

            // Full reset avoids sticky error state from a previous failed blob
            try {
                video.removeAttribute('src');
                video.load();
            } catch (_) {}

            if (token !== playToken) return;

            video.src = src;
            video.style.background = '';
            // Apply loop BEFORE play so Chrome native loop works from the first frame
            const shouldLoop = isClipLoopMode();
            video.loop = shouldLoop;
            // New-tab pages: muted autoplay is allowed; sound after click/key
            if (!userUnlockedAudio) {
                video.muted = true;
            }
            applyPlaybackSpeed();

            // Kick the network/fetch; play() will wait for enough data
            try { video.load(); } catch (_) {}

            if (token !== playToken) return;

            // Prefer canplay, but don't hard-fail slow 4K disks — try play either way
            await new Promise((resolve) => {
                let done = false;
                const finish = () => {
                    if (done) return;
                    done = true;
                    video.removeEventListener('canplay', finish);
                    video.removeEventListener('loadeddata', finish);
                    video.removeEventListener('error', finish);
                    clearTimeout(timer);
                    resolve();
                };
                const timer = setTimeout(finish, 4000); // allow slower local disks
                video.addEventListener('canplay', finish);
                video.addEventListener('loadeddata', finish);
                video.addEventListener('error', finish);
                if (video.readyState >= 2) finish();
            });

            if (token !== playToken) return;

            if (video.error) {
                const code = video.error.code;
                throw new Error(`media error code ${code}`);
            }

            // Re-assert loop right before play (src change can clear it in some cases)
            video.loop = isClipLoopMode();

            try {
                await video.play();
            } catch (e) {
                if (e && e.name === 'AbortError') throw e;
                // Last resort: force muted and try once more (Chrome new-tab autoplay)
                video.muted = true;
                updateHudMuteIcon();
                await video.play();
            }

            if (token !== playToken) return;

            // Restore volume if user already interacted
            if (userUnlockedAudio && video.muted && cfg.volume > 0 && !video.paused) {
                // Leave muted state alone if user had muted via HUD; only unmute after gesture unlock
                // when volume > 0 — optional soft unmute:
                // video.muted = false;
            }
        } finally {
            // Only clear loading if this token still owns the player
            if (token === playToken) {
                mediaLoading = false;
                suppressEndedUntil = Date.now() + 300;
            }
        }
    }

    async function playNext(opts = {}) {
        if (!mainVideo && cfg.layout === 'cinema') {
            // Layout not ready yet
            return;
        }

        // Cancel any pending fail-advance from a previous streak
        clearTimeout(playFailTimer);
        const token = ++playToken;
        mediaLoading = true;
        suppressEndedUntil = Date.now() + 800;

        if (photoTimeout) clearTimeout(photoTimeout);
        if (overlay) overlay.style.opacity = '1';

        // Manual skip: no 250ms fade delay
        if (!opts.instant) {
            await new Promise(r => setTimeout(r, 250));
        }
        if (token !== playToken) {
            if (token === playToken) mediaLoading = false;
            return;
        }

        const item = playlist[currentIdx];
        if (!item) {
            mediaLoading = false;
            clearPlayOverlay();
            return;
        }

        // Show title immediately so UI feels alive even while file opens
        updateHUD();

        // Bind tags/sync identity BEFORE file open — so Sync/tags work even if
        // Chrome blocks getFile() (permissions). Previously bind ran only after src.
        try {
            if (window.FAFOMeta?.bindToItem) {
                await window.FAFOMeta.bindToItem(item, currentIdx);
            }
        } catch (e) { console.warn('FAFOMeta bind', e); }
        if (token !== playToken) return;

        let src = null;
        try {
            src = await getSrc(item);
        } catch (e) {
            if (token !== playToken) return;
            mediaLoading = false;
            advanceAfterPlayFailure(e, token);
            return;
        }
        if (token !== playToken) return;

        if (!src) {
            mediaLoading = false;
            advanceAfterPlayFailure(new Error('no source / permission'), token);
            return;
        }

        const fileName = item.handle?.name || (item.url ? item.url.split('/').pop() : 'unknown');
        const overrides = cfg.overrides?.[fileName] || {};

        if (!mainVideo) {
            mediaLoading = false;
            clearPlayOverlay();
            return;
        }

        const vol = overrides.volume !== undefined ? overrides.volume : cfg.volume;
        mainVideo.volume = vol;
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        // Keep loop attribute live for continuous repeat (Q / untagged / skip-tagged)
        const shouldLoop = isClipLoopMode();
        mainVideo.loop = shouldLoop;
        if (ambienceVideo) ambienceVideo.loop = shouldLoop;

        let scaleMode = overrides.scaling || cfg.scaling;
        let objectFit = 'contain';
        if (scaleMode === 'scale-cover' || scaleMode === 'cover') objectFit = 'cover';
        else if (scaleMode === 'scale-center') objectFit = 'none';
        else if (scaleMode === 'scale-capped' || scaleMode === 'scale-fit-window') objectFit = 'capped';
        applyCinemaObjectFit(mainVideo, objectFit);
        mainVideo.classList.remove('ken-burns');

        if (item.type === 'photo') {
            consecutiveErrors = 0;
            mainVideo.style.background = `url("${src}") center/${objectFit === 'cover' ? 'cover' : 'contain'} no-repeat`;
            try {
                mainVideo.removeAttribute('src');
                mainVideo.load();
            } catch (_) {}

            if (ambienceVideo) ambienceVideo.poster = src;
            if (cfg.kenburns) mainVideo.classList.add('ken-burns');

            mediaLoading = false;
            clearPlayOverlay();
            const restartPhoto = () => {
                if (isPaused) return;
                if (token !== playToken) return;
                if (isClipLoopMode()) {
                    updateLoopHudChip();
                    photoTimeout = setTimeout(restartPhoto, cfg.photoDuration * 1000);
                    return;
                }
                pushPlayHistory(currentIdx);
                currentIdx = findNextEligibleIndex(currentIdx, 1);
                playNext();
            };
            photoTimeout = setTimeout(restartPhoto, cfg.photoDuration * 1000);
            updateLoopHudChip();
            return;
        }

        // Ambience uses same src only after main is set (and only if still current)
        try {
            await loadAndPlayVideo(mainVideo, src, token);
            if (token !== playToken) return;

            consecutiveErrors = 0;
            applyPlaybackSpeed();
            // Keep loop on after successful start
            mainVideo.loop = isClipLoopMode();
            if (ambienceVideo) {
                try {
                    ambienceVideo.src = src;
                    ambienceVideo.muted = true;
                    ambienceVideo.loop = isClipLoopMode();
                    await ambienceVideo.play().catch(() => {});
                } catch (_) {}
            }
            clearPlayOverlay();
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
            applyVideoGpuHints(mainVideo);
            if (neonEngine) {
                if (cfg.disableNeonAudio || cfg.performanceMode) {
                    try { neonEngine.disconnectAudio(); } catch (_) {}
                } else {
                    try { neonEngine.connectAudio(mainVideo); } catch (_) {}
                }
            }
            startProgressBar();
            updateHudMuteIcon();
            syncParticlePerformance();
            updateLoopHudChip();
            revealHud();
            isPaused = false;
            if (hud.play) hud.play.textContent = '⏸';
        } catch (err) {
            if (token === playToken) mediaLoading = false;
            if (token !== playToken) return;
            const name = err && (err.name || '');
            if (name === 'AbortError') {
                // Superseded by a newer playNext — ignore
                return;
            }
            console.warn('Play failed', err);
            advanceAfterPlayFailure(err, token);
        }
    }

    function initGrid() {
        const { cellCount } = applyGridDimensions();

        for (let i = 0; i < cellCount; i++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;

            v.onerror = () => loadRandomVideo(v);
            cell.appendChild(v);
            scene.appendChild(cell);
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
    }

    function initCarousel() {
        const pivot = document.createElement('div');
        pivot.className = 'carousel-pivot';
        scene.appendChild(pivot);
        
        scene.style.transform = `rotateX(${cfg.carouselTilt}deg)`;

        const count = cfg.carouselCount;
        const radius = cfg.carouselRadius;
        const fit = getObjectFitFromConfig();

        for (let i = 0; i < count; i++) {
            const card = document.createElement('div');
            card.className = 'carousel-card';
            
            // FIX: Inner wrapper for breathing animation
            const inner = document.createElement('div');
            inner.className = 'carousel-inner';
            inner.style.animationDelay = `${i * 0.2}s`;

            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;
            v.style.width = '100%';
            v.style.height = '100%';
            v.style.objectFit = fit;
            
            v.onerror = () => loadRandomVideo(v);
            
            inner.appendChild(v);
            card.appendChild(inner);
            pivot.appendChild(card);
            
            const angle = (i / count) * 360;
            // 3D Transform is now safe on the outer card
            card.style.transform = `rotateY(${angle}deg) translateZ(${radius}px)`;
            
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
        // Pivot spin is handled in CSS via class
        pivot.style.animationDuration = `${cfg.carouselSpeed}s`;
    }

    function initCollage() {
        const photoPlaylist = playlist.filter(item => item.type === 'photo');
        
        if (!photoPlaylist.length) {
            const msg = document.createElement('div');
            msg.textContent = "Add photos to library for Collage Mode";
            msg.style.color = "#555";
            scene.appendChild(msg);
            return;
        }

        isPaused = false;

        const spawnPhoto = async () => {
            if (isPaused) return;

            const item = photoPlaylist[Math.floor(Math.random() * photoPlaylist.length)];
            const src = await getSrc(item);
            if (!src) return;

            const img = document.createElement('img');
            img.src = src;
            img.className = 'collage-card';
            
            const top = Math.random() * 80;
            const left = Math.random() * 80;
            const rot = (Math.random() - 0.5) * 40;
            
            img.style.top = `${top}%`;
            img.style.left = `${left}%`;
            img.style.transform = `rotate(${rot}deg) scale(0.8)`;
            
            img.style.zIndex = Date.now() % 10000; 

            scene.appendChild(img);

            requestAnimationFrame(() => {
                img.classList.add('visible');
                img.style.transform = `rotate(${rot}deg) scale(1)`;
            });

            setTimeout(() => {
                img.style.opacity = 0;
                setTimeout(() => img.remove(), 2000);
            }, 60000);
        };

        spawnPhoto();
        spawnPhoto();
        spawnPhoto();
        
        collageInterval = setInterval(spawnPhoto, 3000); 
    }

    async function loadRandomVideo(v) {
        if (!playlist.length) return;
        const item = playlist[Math.floor(Math.random() * playlist.length)];
        const src = await getSrc(item);
        if (!src) return;

        if (item.type === 'photo') {
             v.src = "";
             v.poster = src;
        } else {
            v.src = src;
            v.muted = true;
            v.playsInline = true;
            try {
                await v.play();
            } catch(e) {
                // console.warn("Grid autoplay blocked, retrying muted...", e);
                v.muted = true;
                try {
                    await v.play();
                } catch(err) {
                    // console.error("Grid video failed completely", err);
                }
            }
        }
    }

    // --- 6. UTILITIES ---

    function startClock() {
        if (clockInterval) clearInterval(clockInterval);
        const tick = () => {
            try {
                const n = new Date();
                let h = n.getHours();
                if (cfg.format12h) h = h % 12 || 12;
                const m = n.getMinutes().toString().padStart(2, '0');
                const s = n.getSeconds().toString().padStart(2, '0');
                if (ui.clock) {
                    ui.clock.textContent = cfg.showSeconds ? `${h}:${m}:${s}` : `${h}:${m}`;
                }
                if (ui.date) {
                    if (cfg.showDate === false) {
                        ui.date.style.display = 'none';
                    } else {
                        ui.date.style.display = '';
                        ui.date.textContent = n.toLocaleDateString(undefined, {
                            weekday: 'long', month: 'long', day: 'numeric',
                        });
                    }
                }
            } catch (err) {
                console.warn('clock tick', err);
            }
        };
        tick();
        clockInterval = setInterval(tick, 1000);
    }

    async function initDB() {
        try {
            if (window.FAFOLibrary?.openDB) {
                db = await FAFOLibrary.openDB();
                return;
            }
        } catch (e) {
            console.warn('FAFOLibrary.openDB failed', e);
        }
        db = await new Promise(res => {
            const req = indexedDB.open('NewTabMediaDB', 4);
            req.onblocked = () => console.warn('Database Upgrade Pending — close other FAFO tabs');
            req.onupgradeneeded = e => {
                const d = e.target.result;
                ['videos', 'photos'].forEach(s => {
                    if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { autoIncrement: true });
                });
                if (!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', { keyPath: 'id' });
                if (!d.objectStoreNames.contains('folders')) d.createObjectStore('folders', { keyPath: 'id' });
            };
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }

    function startHealthCheck() {
        if (healthCheckInterval) clearInterval(healthCheckInterval);
        healthCheckInterval = setInterval(() => {
            if (isPaused) return;
            const videos = document.querySelectorAll('#scene-root video');
            videos.forEach(v => {
                if (v.src && !v.paused && v.readyState < 3 && !v.ended) {
                    v.play().catch(() => {
                         if(!v.muted) { v.muted = true; v.play().catch(()=>{}); }
                    });
                }
            });
        }, 5000);
    }

    // --- BOOT (after all functions + FAFOPlayer bridge are defined) ---
    // Full-viewport capability intro (skip with Esc); then full 6.4.x feature stack
    const intro = (typeof FafoIntroSplash !== 'undefined')
        ? FafoIntroSplash.mount(document, {
            accent: cfg.accentColor || '#00e5ff',
            version: '7.2.0',
            minDurationMs: 7200,
        })
        : null;
    intro?.setStatus('Loading configuration…', 0.12);

    // Clock first so the date never sticks on HTML "Loading..." while DB/playlist await
    try {
        await loadConfig();
        intro?.setAccent(cfg.accentColor || '#00e5ff');
        intro?.setStatus('Preparing workspace…', 0.28);
        applyGlobalStyles();
        applyHUD();
        startClock();
        initInputListeners();
        initHudControls();
        initHudAutoHide();
    } catch (e) {
        console.error('FAFO early UI init failed', e);
        try { startClock(); } catch (_) {}
    }

    try {
        intro?.setStatus('Opening media library…', 0.45);
        await initDB();
        intro?.setStatus('Building playlist…', 0.6);
        await buildPlaylist();
        intro?.setStatus('Lighting neon systems…', 0.75);
        initNeonEngine();
        intro?.setStatus('Starting atmosphere…', 0.88);
        refreshParticles();
        initLayout();
        initGridResizeListener();
        startHealthCheck();
        listenForConfigChanges();
        // Re-bind tags once player + playlist are ready
        try {
            const item = playlist[currentIdx];
            if (item) {
                await window.FAFOMeta?.bindToItem?.(item, currentIdx);
            }
        } catch (_) {}
        intro?.setStatus(libraryEmpty ? 'Ready — link folders in Options' : 'Ready', 1);
        // If still no video after a moment, surface restore UI
        setTimeout(() => {
            try {
                if (mainVideo && !mainVideo.src && playlist.length) {
                    maybeShowRestoreBanner();
                    showRetryPlaybackBanner('⚠️ Video not loading — click Retry or Restore Access');
                }
            } catch (_) {}
        }, 2500);
    } catch (e) {
        console.error('FAFO library/layout init failed', e);
        libraryEmpty = true;
        updateEmptyState();
        showRestoreBanner('⚠️ Library failed to open — click to Restore Access or open Options');
        intro?.setStatus('Started with warnings — check Options', 1);
        try {
            if (!mainVideo && cfg.layout === 'cinema') initLayout();
        } catch (_) {}
    }
    await intro?.finish?.(450);
});