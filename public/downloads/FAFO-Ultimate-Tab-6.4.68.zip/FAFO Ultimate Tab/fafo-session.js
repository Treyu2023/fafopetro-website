/**
 * FAFO Session — resume last clip + quiet / daily intro.
 */
(function (global) {
  'use strict';

  const SESSION_KEY = 'fafoLastSession';
  const INTRO_PREF_KEY = 'fafoIntroPrefs';
  const DAY_KEY = 'fafoIntroLastDay';

  const DEFAULT_INTRO = {
    mode: 'daily', // always | daily | never | after-update
    quietSplash: true,
  };

  async function readIntroPrefs() {
    try {
      const res = await chrome.storage.local.get(INTRO_PREF_KEY);
      return { ...DEFAULT_INTRO, ...(res[INTRO_PREF_KEY] || {}) };
    } catch {
      return { ...DEFAULT_INTRO };
    }
  }

  async function writeIntroPrefs(partial) {
    const cur = await readIntroPrefs();
    const next = { ...cur, ...partial };
    await chrome.storage.local.set({ [INTRO_PREF_KEY]: next });
    return next;
  }

  function todayStr() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  /**
   * Should cinematic splash + promo videos run this open?
   */
  async function shouldPlayIntro(manifestVersion) {
    const prefs = await readIntroPrefs();
    if (prefs.mode === 'never') return { play: false, reason: 'never' };
    if (prefs.mode === 'always') return { play: true, reason: 'always', quietSplash: !!prefs.quietSplash };

    try {
      const res = await chrome.storage.local.get([DAY_KEY, 'fafoLastSeenVersion']);
      const lastDay = res[DAY_KEY];
      const lastVer = res.fafoLastSeenVersion;
      const today = todayStr();

      if (prefs.mode === 'after-update') {
        if (manifestVersion && lastVer && lastVer !== manifestVersion) {
          await chrome.storage.local.set({ fafoLastSeenVersion: manifestVersion, [DAY_KEY]: today });
          return { play: true, reason: 'update', quietSplash: false };
        }
        await chrome.storage.local.set({ fafoLastSeenVersion: manifestVersion || lastVer });
        return { play: false, reason: 'no-update', quietSplash: true };
      }

      // daily (default)
      if (lastDay === today) {
        return { play: false, reason: 'already-today', quietSplash: true };
      }
      await chrome.storage.local.set({
        [DAY_KEY]: today,
        fafoLastSeenVersion: manifestVersion || lastVer,
      });
      return { play: true, reason: 'daily', quietSplash: !!prefs.quietSplash };
    } catch {
      return { play: true, reason: 'fallback', quietSplash: true };
    }
  }

  async function saveSession(partial) {
    try {
      const res = await chrome.storage.local.get(SESSION_KEY);
      const cur = res[SESSION_KEY] && typeof res[SESSION_KEY] === 'object' ? res[SESSION_KEY] : {};
      const next = {
        ...cur,
        ...partial,
        savedAt: Date.now(),
      };
      await chrome.storage.local.set({ [SESSION_KEY]: next });
      return next;
    } catch {
      return null;
    }
  }

  async function readSession() {
    try {
      const res = await chrome.storage.local.get(SESSION_KEY);
      return res[SESSION_KEY] || null;
    } catch {
      return null;
    }
  }

  /**
   * Capture current player state for resume.
   */
  function captureFromPlayer() {
    const item = global.FAFOPlayer?.getCurrentItem?.();
    const idx = global.FAFOPlayer?.getCurrentIndex?.() ?? 0;
    const name = item?.handle?.name || item?.name || item?.url || '';
    const key = item?.mediaKey || '';
    let t = 0;
    try {
      const v = document.getElementById('bg-video');
      if (v && Number.isFinite(v.currentTime)) t = v.currentTime;
    } catch (_) {}
    return {
      index: idx,
      name,
      mediaKey: key,
      time: t,
      layout: document.body?.dataset?.layout || '',
    };
  }

  let saveTimer = null;
  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      saveSession(captureFromPlayer()).catch(() => {});
    }, 800);
  }

  async function resumeNow() {
    const s = await readSession();
    if (!s) {
      global.FAFOUndo?.showToast?.('No saved session');
      return { ok: false };
    }
    const pl = global.FAFOPlayer?.getPlaylist?.() || [];
    let idx = typeof s.index === 'number' ? s.index : -1;
    if (s.mediaKey) {
      const byKey = pl.findIndex((it) => it?.mediaKey === s.mediaKey);
      if (byKey >= 0) idx = byKey;
    }
    if (s.name && (idx < 0 || !pl[idx])) {
      const byName = pl.findIndex(
        (it) => (it?.handle?.name || it?.name || '') === s.name
      );
      if (byName >= 0) idx = byName;
    }
    if (idx < 0 || idx >= pl.length) {
      global.FAFOUndo?.showToast?.('Session clip not in playlist');
      return { ok: false };
    }
    if (global.FAFOPlayer?.playIndex) {
      await global.FAFOPlayer.playIndex(idx, { seek: s.time || 0 });
    } else {
      global.FAFOPlayer?.skipTrack?.(idx - (global.FAFOPlayer.getCurrentIndex?.() || 0));
    }
    global.FAFOUndo?.showToast?.('Resumed: ' + (s.name || 'clip'));
    return { ok: true, index: idx };
  }

  function wireAutosave() {
    document.addEventListener(
      'visibilitychange',
      () => {
        if (document.visibilityState === 'hidden') {
          saveSession(captureFromPlayer()).catch(() => {});
        }
      },
      true
    );
    window.addEventListener('beforeunload', () => {
      try {
        // best-effort sync path
        const payload = captureFromPlayer();
        chrome.storage.local.set({ [SESSION_KEY]: { ...payload, savedAt: Date.now() } });
      } catch (_) {}
    });
    // periodic
    setInterval(() => scheduleSave(), 15000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', wireAutosave);
  } else {
    wireAutosave();
  }

  global.FAFOSession = {
    readIntroPrefs,
    writeIntroPrefs,
    shouldPlayIntro,
    saveSession,
    readSession,
    captureFromPlayer,
    scheduleSave,
    resumeNow,
    todayStr,
  };
})(typeof window !== 'undefined' ? window : globalThis);
