/**
 * FAFO Library Doctor — re-grant broken folders + next-up preview strip
 * (dockable / free-drag / scalable).
 */
(function (global) {
  'use strict';

  let doctorRoot = null;
  let nextUpRoot = null;
  let nextUpTimer = null;

  /** @type {{ pos:string, x:number, y:number, scale:number, count:number, hidden:boolean }} */
  let nextUpLayout = {
    pos: 'bottom', // bottom | top | left | right | free
    x: 24,
    y: 24,
    scale: 1,
    count: 8,
    hidden: false,
  };
  let nextUpDragging = false;
  let nextUpSaveTimer = null;

  function ensureDoctor() {
    if (doctorRoot && document.contains(doctorRoot)) return doctorRoot;
    doctorRoot = document.createElement('div');
    doctorRoot.id = 'fafo-library-doctor';
    doctorRoot.className = 'fafo-library-doctor hidden';
    doctorRoot.innerHTML = `
      <div class="fld-backdrop" data-close="1"></div>
      <div class="fld-panel" role="dialog" aria-label="Library doctor">
        <div class="fld-head">
          <h3>Library doctor</h3>
          <button type="button" class="fld-close" data-close="1" title="Close">×</button>
        </div>
        <p class="fld-sub">Re-grant Chrome access for folders that lost permission. Links stay saved — no full re-pick required when grants work.</p>
        <div class="fld-list"></div>
        <div class="fld-actions">
          <button type="button" class="fld-btn primary" id="fld-restore-all">Restore all needed</button>
          <button type="button" class="fld-btn" id="fld-refresh">Rescan status</button>
          <button type="button" class="fld-btn ghost" data-close="1">Close</button>
        </div>
        <p class="fld-status"></p>
      </div>`;
    document.body.appendChild(doctorRoot);
    doctorRoot.querySelectorAll('[data-close]').forEach((el) => {
      el.addEventListener('click', () => close());
    });
    doctorRoot.querySelector('#fld-refresh')?.addEventListener('click', () => refresh());
    doctorRoot.querySelector('#fld-restore-all')?.addEventListener('click', () => restoreAll());
    return doctorRoot;
  }

  async function listFolderStatus() {
    if (!global.FAFOLibrary?.openDB) return [];
    const db = await FAFOLibrary.openDB();
    const folders = await FAFOLibrary.listFolders(db);
    const out = [];
    for (const f of folders) {
      if (f.introPromo || String(f.kind || '').startsWith('intro-promo')) continue;
      let ok = false;
      let err = '';
      try {
        if (f.handle) {
          ok = await FAFOLibrary.ensurePermission(f.handle, 'read');
          if (!ok) {
            try {
              const q = await f.handle.queryPermission?.({ mode: 'read' });
              ok = q === 'granted';
              if (!ok) err = q || 'prompt';
            } catch (_) {
              err = 'no-permission';
            }
          }
        } else {
          err = 'missing-handle';
        }
      } catch (e) {
        err = e.message || 'error';
      }
      out.push({
        id: f.id,
        name: f.name || f.id,
        kind: f.kind || f.storeName || '',
        ok,
        err,
        handle: f.handle,
      });
    }
    return out;
  }

  async function refresh() {
    ensureDoctor();
    const list = doctorRoot.querySelector('.fld-list');
    const status = doctorRoot.querySelector('.fld-status');
    if (status) status.textContent = 'Checking…';
    const rows = await listFolderStatus();
    if (!list) return rows;
    if (!rows.length) {
      list.innerHTML = '<div class="fld-empty">No linked folders.</div>';
      if (status) status.textContent = 'Nothing linked — open Options → Visual Library.';
      return rows;
    }
    list.innerHTML = rows
      .map(
        (r) => `
      <div class="fld-row ${r.ok ? 'ok' : 'bad'}" data-id="${escapeAttr(r.id)}">
        <div class="fld-row-main">
          <span class="fld-dot"></span>
          <div>
            <div class="fld-name">${escapeHtml(r.name)}</div>
            <div class="fld-meta">${escapeHtml(r.kind || '')} · ${r.ok ? 'access OK' : 'needs restore'}</div>
          </div>
        </div>
        ${r.ok ? '' : `<button type="button" class="fld-btn small" data-fix="${escapeAttr(r.id)}">Restore</button>`}
      </div>`
      )
      .join('');
    list.querySelectorAll('[data-fix]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await restoreOne(btn.getAttribute('data-fix'));
        await refresh();
      });
    });
    const bad = rows.filter((r) => !r.ok).length;
    if (status) {
      status.textContent = bad
        ? `${bad} folder(s) need attention`
        : `All ${rows.length} folder(s) granted`;
    }
    return rows;
  }

  async function restoreOne(id) {
    if (!global.FAFOLibrary?.openDB) return false;
    const db = await FAFOLibrary.openDB();
    const folders = await FAFOLibrary.listFolders(db);
    const f = folders.find((x) => x.id === id);
    if (!f?.handle) return false;
    try {
      const ok = await FAFOLibrary.ensurePermission(f.handle, 'read');
      if (!ok && f.handle.requestPermission) {
        const r = await f.handle.requestPermission({ mode: 'read' });
        return r === 'granted';
      }
      return ok;
    } catch {
      return false;
    }
  }

  async function restoreAll() {
    const rows = await listFolderStatus();
    for (const r of rows.filter((x) => !x.ok)) {
      await restoreOne(r.id);
    }
    await refresh();
  }

  function open() {
    ensureDoctor();
    doctorRoot.classList.remove('hidden');
    refresh();
  }

  function close() {
    doctorRoot?.classList.add('hidden');
  }

  function escapeHtml(s) {
    return String(s ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, '&#39;');
  }

  // ── Next-up strip ──────────────────────────────────────────────
  function scheduleNextUpSave() {
    clearTimeout(nextUpSaveTimer);
    nextUpSaveTimer = setTimeout(() => {
      try {
        chrome.storage.local.set({ fafoNextUp: { ...nextUpLayout } }).catch(() => {});
      } catch (_) {}
    }, 200);
  }

  async function loadNextUpLayout() {
    try {
      const res = await chrome.storage.local.get(['fafoNextUp']);
      if (res.fafoNextUp && typeof res.fafoNextUp === 'object') {
        nextUpLayout = {
          pos: ['bottom', 'top', 'left', 'right', 'free'].includes(res.fafoNextUp.pos)
            ? res.fafoNextUp.pos
            : 'bottom',
          x: typeof res.fafoNextUp.x === 'number' ? res.fafoNextUp.x : 24,
          y: typeof res.fafoNextUp.y === 'number' ? res.fafoNextUp.y : 24,
          scale: Math.max(0.6, Math.min(1.8, Number(res.fafoNextUp.scale) || 1)),
          count: Math.max(3, Math.min(16, Math.round(Number(res.fafoNextUp.count) || 8))),
          hidden: !!res.fafoNextUp.hidden,
        };
      }
    } catch (_) {}
  }

  function applyNextUpLayout() {
    if (!nextUpRoot) return;
    const L = nextUpLayout;
    nextUpRoot.classList.remove('pos-bottom', 'pos-top', 'pos-left', 'pos-right', 'pos-free', 'collapsed', 'hidden');
    nextUpRoot.classList.add(`pos-${L.pos}`);
    nextUpRoot.style.setProperty('--fnu-scale', String(L.scale));
    nextUpRoot.style.setProperty('--fnu-x', `${Math.round(L.x)}px`);
    nextUpRoot.style.setProperty('--fnu-y', `${Math.round(L.y)}px`);
    if (L.hidden) nextUpRoot.classList.add('collapsed');
    const posBtn = nextUpRoot.querySelector('[data-fnu-pos]');
    if (posBtn) {
      const labels = { bottom: 'Bot', top: 'Top', left: 'L', right: 'R', free: 'Free' };
      posBtn.textContent = labels[L.pos] || 'Bot';
      posBtn.title = `Position: ${L.pos} · click to cycle · drag header to free-place`;
    }
    const scaleLab = nextUpRoot.querySelector('[data-fnu-scale-lab]');
    if (scaleLab) scaleLab.textContent = Math.round(L.scale * 100) + '%';
    const scaleIn = nextUpRoot.querySelector('[data-fnu-scale]');
    if (scaleIn && document.activeElement !== scaleIn) {
      scaleIn.value = String(Math.round(L.scale * 100));
    }
    const countLab = nextUpRoot.querySelector('[data-fnu-count-lab]');
    if (countLab) countLab.textContent = String(L.count);
    const countIn = nextUpRoot.querySelector('[data-fnu-count]');
    if (countIn && document.activeElement !== countIn) {
      countIn.value = String(L.count);
    }
  }

  function cycleNextUpPos() {
    const order = ['bottom', 'top', 'left', 'right', 'free'];
    const i = order.indexOf(nextUpLayout.pos);
    nextUpLayout.pos = order[(i + 1) % order.length];
    if (nextUpLayout.pos === 'free' && nextUpRoot) {
      const r = nextUpRoot.getBoundingClientRect();
      nextUpLayout.x = Math.max(8, Math.round(r.left));
      nextUpLayout.y = Math.max(8, Math.round(r.top));
    }
    applyNextUpLayout();
    scheduleNextUpSave();
  }

  function setNextUpCount(n) {
    const c = Math.max(3, Math.min(16, Math.round(Number(n) || 8)));
    nextUpLayout.count = c;
    applyNextUpLayout();
    scheduleNextUpSave();
    scheduleNextUp();
    return c;
  }

  function setNextUpScale(s) {
    nextUpLayout.scale = Math.max(0.6, Math.min(1.8, Number(s) || 1));
    applyNextUpLayout();
    scheduleNextUpSave();
    return nextUpLayout.scale;
  }

  function setNextUpPos(pos) {
    if (['bottom', 'top', 'left', 'right', 'free'].includes(pos)) {
      nextUpLayout.pos = pos;
      applyNextUpLayout();
      scheduleNextUpSave();
    }
    return nextUpLayout.pos;
  }

  function hideNextUp() {
    nextUpLayout.hidden = true;
    applyNextUpLayout();
    scheduleNextUpSave();
  }

  function bindNextUpChrome() {
    if (!nextUpRoot || nextUpRoot.dataset.bound) return;
    nextUpRoot.dataset.bound = '1';
    const head = nextUpRoot.querySelector('.fnu-head');

    nextUpRoot.querySelector('[data-fnu-pos]')?.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      cycleNextUpPos();
    });
    nextUpRoot.querySelector('[data-fnu-scale]')?.addEventListener('input', (e) => {
      const pct = parseInt(e.target.value, 10);
      if (!Number.isFinite(pct)) return;
      nextUpLayout.scale = Math.max(0.6, Math.min(1.8, pct / 100));
      applyNextUpLayout();
      scheduleNextUpSave();
    });
    nextUpRoot.querySelector('[data-fnu-count]')?.addEventListener('input', (e) => {
      setNextUpCount(e.target.value);
    });
    nextUpRoot.querySelector('.fnu-hide')?.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      hideNextUp();
    });
    nextUpRoot.querySelector('[data-fnu-show]')?.addEventListener('click', (e) => {
      e.preventDefault();
      showNextUp();
    });

    // Drag header → free position
    if (head) {
      let offX = 0;
      let offY = 0;
      head.addEventListener('pointerdown', (e) => {
        if (e.button != null && e.button !== 0) return;
        if (e.target.closest('button, input, select, label')) return;
        e.preventDefault();
        const r = nextUpRoot.getBoundingClientRect();
        nextUpDragging = true;
        offX = e.clientX - r.left;
        offY = e.clientY - r.top;
        nextUpLayout.pos = 'free';
        head.classList.add('dragging');
        try { head.setPointerCapture(e.pointerId); } catch (_) {}
        const onMove = (ev) => {
          if (!nextUpDragging) return;
          nextUpLayout.x = Math.max(4, Math.min((window.innerWidth || 800) - 80, ev.clientX - offX));
          nextUpLayout.y = Math.max(4, Math.min((window.innerHeight || 600) - 40, ev.clientY - offY));
          applyNextUpLayout();
        };
        const onUp = () => {
          nextUpDragging = false;
          head.classList.remove('dragging');
          window.removeEventListener('pointermove', onMove, true);
          window.removeEventListener('pointerup', onUp, true);
          scheduleNextUpSave();
        };
        window.addEventListener('pointermove', onMove, true);
        window.addEventListener('pointerup', onUp, true);
      });
    }
  }

  function ensureNextUp() {
    if (nextUpRoot && document.contains(nextUpRoot)) return nextUpRoot;
    nextUpRoot = document.createElement('div');
    nextUpRoot.id = 'fafo-next-up';
    nextUpRoot.className = 'fafo-next-up pos-bottom';
    nextUpRoot.innerHTML = `
      <div class="fnu-head" title="Drag to free-place · Pos docks · # cards · scale">
        <span class="fnu-title">Up next</span>
        <div class="fnu-head-actions">
          <button type="button" class="fnu-btn" data-fnu-pos title="Cycle position: bottom · top · left · right · free">Bot</button>
          <label class="fnu-btn" title="How many upcoming clips" style="display:inline-flex;align-items:center;gap:4px;cursor:default;">
            <span style="opacity:0.7">#</span>
            <input type="range" data-fnu-count min="3" max="16" value="8" style="width:56px;accent-color:#00e5ff;" />
            <span data-fnu-count-lab>8</span>
          </label>
          <label class="fnu-btn" title="Strip scale" style="display:inline-flex;align-items:center;gap:4px;cursor:default;">
            <input type="range" data-fnu-scale min="60" max="180" value="100" style="width:56px;accent-color:#00e5ff;" />
            <span data-fnu-scale-lab>100%</span>
          </label>
          <button type="button" class="fnu-hide" title="Hide strip · restore via Ctrl+K → Show Up next">×</button>
        </div>
      </div>
      <div class="fnu-track"></div>`;
    document.body.appendChild(nextUpRoot);
    bindNextUpChrome();
    applyNextUpLayout();
    return nextUpRoot;
  }

  /** Show strip again if user hid it (e.g. from command palette later). */
  function showNextUp() {
    nextUpLayout.hidden = false;
    ensureNextUp();
    applyNextUpLayout();
    scheduleNextUpSave();
    scheduleNextUp();
  }

  async function renderNextUp() {
    const pl = global.FAFOPlayer?.getPlaylist?.() || [];
    const cur = global.FAFOPlayer?.getCurrentIndex?.() ?? 0;
    if (!pl.length) {
      nextUpRoot?.classList.add('hidden');
      return;
    }
    ensureNextUp();
    if (nextUpLayout.hidden) {
      nextUpRoot.classList.add('collapsed');
      return;
    }
    nextUpRoot.classList.remove('hidden', 'collapsed');
    applyNextUpLayout();
    const track = nextUpRoot.querySelector('.fnu-track');
    if (!track) return;

    const maxN = nextUpLayout.count || 8;
    const upcoming = [];
    for (let i = 1; i <= maxN; i++) {
      const idx = (cur + i) % pl.length;
      if (idx === cur && pl.length === 1) break;
      upcoming.push({ idx, item: pl[idx] });
      if (upcoming.length >= maxN) break;
      if (pl.length <= i) break;
    }

    track.innerHTML = upcoming
      .map(({ idx, item }) => {
        const name = item?.handle?.name || item?.name || `Clip ${idx + 1}`;
        return `<button type="button" class="fnu-card" data-idx="${idx}" title="${escapeAttr(name)}">
          <div class="fnu-thumb" data-idx="${idx}"><span class="fnu-num">${idx + 1}</span></div>
          <div class="fnu-label">${escapeHtml(truncate(name, 28))}</div>
        </button>`;
      })
      .join('');

    track.querySelectorAll('.fnu-card').forEach((btn) => {
      btn.addEventListener('click', () => {
        const idx = parseInt(btn.getAttribute('data-idx'), 10);
        global.FAFOPlayer?.playIndex?.(idx);
      });
    });

    upcoming.forEach(async ({ idx, item }) => {
      const el = track.querySelector(`.fnu-thumb[data-idx="${idx}"]`);
      if (!el || !item?.handle?.getFile) return;
      try {
        const file = await item.handle.getFile();
        if (!file.type.startsWith('video/') && !/\.(mp4|webm|mov|mkv)$/i.test(file.name)) {
          if (file.type.startsWith('image/')) {
            const url = URL.createObjectURL(file);
            el.style.backgroundImage = `url("${url}")`;
            el.dataset.blob = url;
          }
          return;
        }
        const url = URL.createObjectURL(file);
        const video = document.createElement('video');
        video.muted = true;
        video.preload = 'metadata';
        video.src = url;
        await new Promise((res, rej) => {
          video.onloadeddata = () => res();
          video.onerror = () => rej();
          setTimeout(res, 2000);
        });
        try {
          video.currentTime = Math.min(1.2, (video.duration || 2) * 0.1);
        } catch (_) {}
        await new Promise((r) => setTimeout(r, 200));
        const canvas = document.createElement('canvas');
        canvas.width = 160;
        canvas.height = 90;
        const ctx = canvas.getContext('2d');
        if (ctx && video.videoWidth) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          el.style.backgroundImage = `url("${canvas.toDataURL('image/jpeg', 0.7)}")`;
        }
        URL.revokeObjectURL(url);
        video.src = '';
      } catch (_) {
        /* ignore thumb errors */
      }
    });
  }

  function truncate(s, n) {
    const t = String(s || '');
    return t.length > n ? t.slice(0, n - 1) + '…' : t;
  }

  function scheduleNextUp() {
    clearTimeout(nextUpTimer);
    nextUpTimer = setTimeout(() => renderNextUp().catch(() => {}), 400);
  }

  async function initNextUp() {
    await loadNextUpLayout();
    ensureNextUp();
    scheduleNextUp();
    setInterval(() => {
      if (document.hidden) return;
      scheduleNextUp();
    }, 8000);
    // Options page (or another tab) can change count/pos/scale/hidden live
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area !== 'local' || !changes.fafoNextUp?.newValue) return;
        const L = changes.fafoNextUp.newValue;
        if (!L || typeof L !== 'object') return;
        nextUpLayout = {
          pos: ['bottom', 'top', 'left', 'right', 'free'].includes(L.pos) ? L.pos : nextUpLayout.pos,
          x: typeof L.x === 'number' ? L.x : nextUpLayout.x,
          y: typeof L.y === 'number' ? L.y : nextUpLayout.y,
          scale: Math.max(0.6, Math.min(1.8, Number(L.scale) || nextUpLayout.scale)),
          count: Math.max(3, Math.min(16, Math.round(Number(L.count) || nextUpLayout.count))),
          hidden: !!L.hidden,
        };
        ensureNextUp();
        applyNextUpLayout();
        scheduleNextUp();
      });
    } catch (_) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(initNextUp, 1500));
  } else {
    setTimeout(initNextUp, 1500);
  }

  global.FAFOLibraryDoctor = {
    open,
    close,
    refresh,
    restoreAll,
    restoreOne,
    renderNextUp,
    scheduleNextUp,
    showNextUp,
    hideNextUp,
    cycleNextUpPos,
    setNextUpCount,
    setNextUpScale,
    setNextUpPos,
    getNextUpLayout: () => ({ ...nextUpLayout }),
  };
})(typeof window !== 'undefined' ? window : globalThis);
