/**
 * FAFO Intro Promos — up to 4 boot video folders.
 *
 * Default: play ONE random clip from enabled slots (residual shuffle so the
 * same file is not reused until the deck is empty). Optional legacy mode
 * plays every enabled slot in order.
 *
 * Preload starts as soon as the new tab parses this file. Playback is sized
 * to 1920×1080 (or 1080×1920 portrait) so the compositor is not pushing 4K.
 * Slot 4 is sponsored by BOFA Deez Teas.
 */
(function (global) {
  'use strict';

  const VIDEO_RE = /\.(mp4|webm|mkv|mov|m4v|avi)$/i;
  const STORAGE_KEY = 'fafoIntroPromos';
  const QUEUE_KEY = 'fafoIntroPromoQueues';

  const BOFA = {
    name: 'BOFA Deez Teas',
    tagline: 'Suck one down today at a retailer near you!',
    short: 'Sponsored · BOFA Deez Teas',
  };

  const DEFAULT_SLOTS = [
    { id: 1, key: 'intro-promo-1', label: 'Intro 1', enabled: true, sponsored: false },
    { id: 2, key: 'intro-promo-2', label: 'Intro 2', enabled: true, sponsored: false },
    { id: 3, key: 'intro-promo-3', label: 'Intro 3', enabled: true, sponsored: false },
    {
      id: 4,
      key: 'intro-promo-4',
      label: 'BOFA Deez Teas',
      enabled: true,
      sponsored: true,
      sponsor: { ...BOFA },
    },
  ];

  const DEFAULTS = {
    enabled: true,
    shuffle: true,
    playToEnd: true,
    playAllSlots: false,
    showSplashAfter: false,
    slots: DEFAULT_SLOTS.map((s) => ({ ...s, sponsor: s.sponsor ? { ...s.sponsor } : undefined })),
  };

  const BOOT_QUEUE_KEY = 'boot-one';
  const MAX_LANDSCAPE = { w: 1920, h: 1080 };
  const MAX_PORTRAIT = { w: 1080, h: 1920 };

  const preloadState = { promise: null, pack: null, aborted: false };

  function deepDefaults() {
    return JSON.parse(JSON.stringify(DEFAULTS));
  }

  async function readConfig() {
    try {
      const res = await chrome.storage.local.get(STORAGE_KEY);
      const raw = res[STORAGE_KEY];
      if (!raw || typeof raw !== 'object') return deepDefaults();
      const base = deepDefaults();
      const slots = DEFAULT_SLOTS.map((def, i) => {
        const got = Array.isArray(raw.slots) ? raw.slots.find((s) => s.id === def.id) || raw.slots[i] : null;
        return {
          ...def,
          enabled: got && typeof got.enabled === 'boolean' ? got.enabled : def.enabled,
          label: (got && got.label) || def.label,
          sponsor: def.sponsored ? { ...BOFA, ...(got?.sponsor || {}) } : undefined,
        };
      });
      return {
        enabled: raw.enabled !== false,
        shuffle: raw.shuffle !== false,
        playToEnd: raw.playToEnd !== false,
        playAllSlots: !!raw.playAllSlots,
        showSplashAfter: !!raw.showSplashAfter,
        slots,
      };
    } catch {
      return deepDefaults();
    }
  }

  async function writeConfig(partial) {
    const cur = await readConfig();
    const next = {
      ...cur,
      ...partial,
      slots: partial.slots
        ? DEFAULT_SLOTS.map((def) => {
            const g = partial.slots.find((s) => s.id === def.id) || {};
            return {
              ...def,
              enabled: typeof g.enabled === 'boolean' ? g.enabled : def.enabled,
              label: g.label || def.label,
              sponsor: def.sponsored ? { ...BOFA, ...(g.sponsor || {}) } : undefined,
            };
          })
        : cur.slots,
    };
    await chrome.storage.local.set({ [STORAGE_KEY]: next });
    return next;
  }

  async function readQueues() {
    try {
      const res = await chrome.storage.local.get(QUEUE_KEY);
      return res[QUEUE_KEY] && typeof res[QUEUE_KEY] === 'object' ? res[QUEUE_KEY] : {};
    } catch {
      return {};
    }
  }

  async function writeQueues(q) {
    await chrome.storage.local.set({ [QUEUE_KEY]: q || {} });
  }

  function shuffleInPlace(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const t = arr[i];
      arr[i] = arr[j];
      arr[j] = t;
    }
    return arr;
  }

  async function getFolderByKey(key) {
    if (!global.FAFOLibrary?.openDB || !global.FAFOLibrary?.listFolders) return null;
    try {
      const db = await FAFOLibrary.openDB();
      const folders = await FAFOLibrary.listFolders(db);
      return folders.find((f) => f.id === key || f.kind === key || f.promoKey === key) || null;
    } catch {
      return null;
    }
  }

  async function listVideos(folder) {
    if (!folder?.handle) return [];
    const ok = await FAFOLibrary.ensurePermission(folder.handle, 'read');
    if (!ok) return [];
    const out = [];
    try {
      for await (const entry of folder.handle.values()) {
        if (entry.kind === 'file' && VIDEO_RE.test(entry.name)) out.push(entry);
      }
    } catch (e) {
      console.warn('FAFO intro promos list', e);
    }
    out.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
    return out;
  }

  /**
   * Residual shuffle deck: pick next file name, rebuild when empty.
   * Persists so reopening the tab does not restart the same first clips.
   */
  async function pickNextVideo(slotKey, handles, shuffle) {
    if (!handles.length) return null;
    const names = handles.map((h) => h.name);
    const nameSet = new Set(names);
    const queues = await readQueues();
    let deck = Array.isArray(queues[slotKey]) ? queues[slotKey].filter((n) => nameSet.has(n)) : [];

    if (!deck.length) {
      deck = names.slice();
      if (shuffle) shuffleInPlace(deck);
    }

    const nextName = deck.shift();
    queues[slotKey] = deck;
    await writeQueues(queues);

    return handles.find((h) => h.name === nextName) || handles[0];
  }

  async function linkSlotFolder(slotId) {
    if (!global.showDirectoryPicker) throw new Error('Folder picker not supported in this browser');
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) throw new Error('Unknown intro slot');

    const handle = await showDirectoryPicker({
      id: 'fafo-' + slot.key,
      mode: 'read',
    });
    const db = await FAFOLibrary.openDB();
    // Replace previous folder with same key
    try {
      if (db.objectStoreNames.contains('folders')) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').put({
          id: slot.key,
          kind: slot.key,
          promoKey: slot.key,
          storeName: 'videos',
          name: handle.name || slot.label,
          handle,
          addedAt: Date.now(),
          lastSyncedAt: Date.now(),
          fileCount: 0,
          introPromo: true,
          slotId,
        });
        await new Promise((res, rej) => {
          tx.oncomplete = () => res();
          tx.onerror = () => rej(tx.error);
        });
      }
    } catch (e) {
      console.warn('intro promo folder save', e);
      throw e;
    }

    // Reset residual queue for this slot so new library builds a fresh deck
    const q = await readQueues();
    delete q[slot.key];
    await writeQueues(q);

    const vids = await listVideos({ handle });
    return { folderName: handle.name, count: vids.length, slot };
  }

  async function clearSlotFolder(slotId) {
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) return;
    try {
      const db = await FAFOLibrary.openDB();
      if (db.objectStoreNames.contains('folders')) {
        const tx = db.transaction('folders', 'readwrite');
        tx.objectStore('folders').delete(slot.key);
        await new Promise((res) => {
          tx.oncomplete = () => res();
          tx.onerror = () => res();
        });
      }
    } catch (_) {}
    const q = await readQueues();
    delete q[slot.key];
    await writeQueues(q);
  }

  async function slotStatus(slotId) {
    const cfg = await readConfig();
    const slot = cfg.slots.find((s) => s.id === slotId);
    if (!slot) return null;
    const folder = await getFolderByKey(slot.key);
    let count = 0;
    if (folder) {
      try {
        count = (await listVideos(folder)).length;
      } catch (_) {}
    }
    const q = await readQueues();
    const remaining = Array.isArray(q[slot.key]) ? q[slot.key].length : null;
    return {
      slot,
      folderName: folder?.name || null,
      linked: !!folder?.handle,
      count,
      queueRemaining: remaining,
    };
  }

  function apply1080Fit(video) {
    if (!video) return;
    const vw = video.videoWidth || 0;
    const vh = video.videoHeight || 0;
    const portrait = vh > vw;
    video.classList.toggle('is-portrait', portrait);
    const cap = portrait ? MAX_PORTRAIT : MAX_LANDSCAPE;
    const maxW = Math.min(cap.w, window.innerWidth || cap.w);
    const maxH = Math.min(cap.h, window.innerHeight || cap.h);
    if (vw < 2 || vh < 2) {
      video.style.maxWidth = maxW + 'px';
      video.style.maxHeight = maxH + 'px';
      return;
    }
    const s = Math.min(maxW / vw, maxH / vh, 1);
    const dw = Math.max(2, Math.round(vw * s));
    const dh = Math.max(2, Math.round(vh * s));
    video.width = dw;
    video.height = dh;
    video.style.width = dw + 'px';
    video.style.height = dh + 'px';
  }

  async function collectSlotVideos(cfg) {
    const out = [];
    for (const slot of cfg.slots) {
      if (!slot.enabled) continue;
      const folder = await getFolderByKey(slot.key);
      if (!folder?.handle) continue;
      const handles = await listVideos(folder);
      handles.forEach((handle) => {
        out.push({
          slot,
          handle,
          key: slot.key + '|' + handle.name,
        });
      });
    }
    return out;
  }

  async function pickOneBootClip(cfg) {
    const pool = await collectSlotVideos(cfg);
    if (!pool.length) return null;
    const nameSet = new Set(pool.map((p) => p.key));
    const queues = await readQueues();
    let deck = Array.isArray(queues[BOOT_QUEUE_KEY])
      ? queues[BOOT_QUEUE_KEY].filter((n) => nameSet.has(n))
      : [];
    if (!deck.length) {
      deck = pool.map((p) => p.key);
      if (cfg.shuffle) shuffleInPlace(deck);
    }
    const nextKey = deck.shift();
    queues[BOOT_QUEUE_KEY] = deck;
    await writeQueues(queues);
    return pool.find((p) => p.key === nextKey) || pool[0];
  }

  function waitMedia(video, eventName, ms) {
    return new Promise((resolve) => {
      let done = false;
      const finish = () => {
        if (done) return;
        done = true;
        video.removeEventListener(eventName, finish);
        video.removeEventListener('error', finish);
        resolve();
      };
      video.addEventListener(eventName, finish, { once: true });
      video.addEventListener('error', finish, { once: true });
      setTimeout(finish, ms);
    });
  }

  function primeVideoEl(video) {
    video.preload = 'auto';
    video.playsInline = true;
    video.disablePictureInPicture = true;
    video.controls = false;
    video.muted = true;
  }

  async function beginPreload() {
    if (preloadState.aborted) return null;
    if (preloadState.promise) return preloadState.promise;
    preloadState.promise = (async () => {
      const cfg = await readConfig();
      if (!cfg.enabled || preloadState.aborted) return null;
      const pick = cfg.playAllSlots
        ? await (async () => {
            for (const slot of cfg.slots) {
              if (!slot.enabled) continue;
              const folder = await getFolderByKey(slot.key);
              if (!folder?.handle) continue;
              const handles = await listVideos(folder);
              if (!handles.length) continue;
              const handle = await pickNextVideo(slot.key, handles, cfg.shuffle);
              if (handle) return { slot, handle, key: slot.key + '|' + handle.name };
            }
            return null;
          })()
        : await pickOneBootClip(cfg);
      if (!pick?.handle) return null;
      let file;
      try {
        file = await pick.handle.getFile();
      } catch (e) {
        console.warn('intro promo preload getFile', e);
        return null;
      }
      const url = URL.createObjectURL(file);
      const root = ensureOverlay();
      root.classList.add('is-preloading');
      root.classList.remove('hidden');
      const video = root.querySelector('.fip-video');
      primeVideoEl(video);
      video.addEventListener('loadedmetadata', () => apply1080Fit(video));
      video.src = url;
      try { video.load(); } catch (_) {}
      await waitMedia(video, 'canplaythrough', 4500);
      apply1080Fit(video);
      if (preloadState.aborted) {
        try { URL.revokeObjectURL(url); } catch (_) {}
        return null;
      }
      const pack = { ...pick, file, url, video, root };
      preloadState.pack = pack;
      return pack;
    })().catch((e) => {
      console.warn('intro promo preload', e);
      return null;
    });
    return preloadState.promise;
  }

  function cancelPreload() {
    preloadState.aborted = true;
    const pack = preloadState.pack;
    preloadState.pack = null;
    const root = document.getElementById('fafo-intro-promo');
    if (root) {
      root.classList.add('hidden');
      root.classList.remove('is-preloading');
    }
    const video = root?.querySelector('.fip-video');
    try {
      video?.pause();
      video?.removeAttribute('src');
      video?.load();
    } catch (_) {}
    if (pack?.url) {
      try { URL.revokeObjectURL(pack.url); } catch (_) {}
    }
  }

  function ensureOverlay() {
    let el = document.getElementById('fafo-intro-promo');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'fafo-intro-promo';
    el.className = 'fafo-intro-promo hidden';
    el.setAttribute('role', 'dialog');
    el.setAttribute('aria-label', 'Intro promo');
    el.innerHTML = `
      <div class="fip-bg-pattern" aria-hidden="true"></div>
      <div class="fip-frame" aria-hidden="true">
        <span class="fip-corner tl"></span><span class="fip-corner tr"></span>
        <span class="fip-corner bl"></span><span class="fip-corner br"></span>
      </div>
      <video class="fip-video" playsinline></video>
      <div class="fip-chrome">
        <div class="fip-top">
          <div class="fip-slot-label"></div>
          <div class="fip-sponsor hidden"></div>
        </div>
        <div class="fip-bottom">
          <div class="fip-progress"><div class="fip-progress-fill"></div></div>
          <div class="fip-actions">
            <button type="button" class="fip-skip" title="Skip this intro (Esc)">Skip intro · Esc</button>
            <button type="button" class="fip-skip-all" title="Skip remaining intros" hidden>Skip all</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(el);
    return el;
  }

  function playFile(videoEl, file, existingUrl, abortRef) {
    return new Promise((resolve, reject) => {
      const url = existingUrl || URL.createObjectURL(file);
      const ownsUrl = !existingUrl;
      let settled = false;
      let watchdog = null;
      const done = (err) => {
        if (settled) return;
        settled = true;
        if (abortRef) abortRef.fn = null;
        if (watchdog) clearTimeout(watchdog);
        try {
          videoEl.onended = null;
          videoEl.onerror = null;
        } catch (_) {}
        try { videoEl.pause(); } catch (_) {}
        if (ownsUrl) {
          try { URL.revokeObjectURL(url); } catch (_) {}
          try {
            videoEl.removeAttribute('src');
            videoEl.load();
          } catch (_) {}
        }
        if (err) reject(err);
        else resolve();
      };
      if (abortRef) abortRef.fn = () => done();
      videoEl.onended = () => done();
      videoEl.onerror = () => done(new Error('video error'));
      watchdog = setTimeout(() => done(), 180000);
      videoEl.addEventListener('loadedmetadata', () => {
        const d = Number(videoEl.duration);
        if (Number.isFinite(d) && d > 0) {
          clearTimeout(watchdog);
          watchdog = setTimeout(() => done(), Math.min(180000, (d + 2.5) * 1000));
        }
      }, { once: true });
      primeVideoEl(videoEl);
      if (videoEl.src !== url) videoEl.src = url;
      try { videoEl.currentTime = 0; } catch (_) {}
      const tryPlay = () => {
        if (settled) return;
        const p = videoEl.play();
        if (p && p.catch) {
          p.catch(() => {
            if (settled) return;
            videoEl.muted = true;
            videoEl.play().catch(() => done(new Error('play blocked')));
          });
        }
      };
      if (videoEl.readyState >= 3) {
        videoEl.muted = false;
        tryPlay();
      } else {
        videoEl.addEventListener('canplay', () => {
          if (settled) return;
          videoEl.muted = false;
          tryPlay();
        }, { once: true });
        try { videoEl.load(); } catch (_) { tryPlay(); }
      }
    });
  }

  function paintSlotChrome(root, slot, name, opts) {
    const slotLabel = root.querySelector('.fip-slot-label');
    const sponsorEl = root.querySelector('.fip-sponsor');
    if (slotLabel) {
      slotLabel.textContent = slot.sponsored
        ? `Intro ${slot.id} · Sponsored`
        : `Intro ${slot.id} · ${slot.label}`;
    }
    if (sponsorEl) {
      if (slot.sponsored) {
        const sp = slot.sponsor || BOFA;
        sponsorEl.classList.remove('hidden');
        sponsorEl.innerHTML =
          `<strong>${escapeHtml(sp.name || BOFA.name)}</strong>` +
          `<span>${escapeHtml(sp.tagline || BOFA.tagline)}</span>`;
        root.classList.add('fip-sponsored');
      } else {
        sponsorEl.classList.add('hidden');
        sponsorEl.innerHTML = '';
        root.classList.remove('fip-sponsored');
      }
    }
    opts.onStatus?.(
      slot.sponsored
        ? `Sponsored by ${BOFA.name}…`
        : `Playing ${slot.label}: ${name || ''}`
    );
  }

  /**
   * Default: one random clip from enabled folders.
   * playAllSlots: legacy 1→4 sequence.
   */
  async function playBootSequence(opts = {}) {
    const cfg = await readConfig();
    if (!cfg.enabled) return { played: 0, skipped: true };

    const pack = await beginPreload();
    const root = ensureOverlay();
    const videoEl = root.querySelector('.fip-video');
    const fill = root.querySelector('.fip-progress-fill');
    const btnSkip = root.querySelector('.fip-skip');
    const btnSkipAll = root.querySelector('.fip-skip-all');
    if (btnSkipAll) btnSkipAll.hidden = !cfg.playAllSlots;

    let skipOne = false;
    let skipAll = false;
    let progressTimer = null;
    const abortRef = { fn: null };

    const requestSkip = (all) => {
      if (all) skipAll = true;
      skipOne = true;
      try { videoEl.pause(); } catch (_) {}
      try { abortRef.fn?.(); } catch (_) {}
    };

    const onKey = (e) => {
      if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        e.stopPropagation();
        requestSkip(e.key === 'Escape' || e.shiftKey);
      }
    };

    btnSkip.onclick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      requestSkip(false);
    };
    if (btnSkipAll) {
      btnSkipAll.onclick = (e) => {
        e.preventDefault();
        e.stopPropagation();
        requestSkip(true);
      };
    }
    const onOverlayClick = (e) => {
      if (e.target.closest('button')) return;
      requestSkip(true);
    };

    document.addEventListener('keydown', onKey, true);
    root.addEventListener('click', onOverlayClick);
    root.classList.remove('hidden', 'is-preloading');
    document.body.classList.add('fafo-intro-promo-active');
    const onResize = () => apply1080Fit(videoEl);
    window.addEventListener('resize', onResize);

    const runOne = async (slot, file, url, name) => {
      if (skipAll) return;
      skipOne = false;
      paintSlotChrome(root, slot, name, opts);
      clearInterval(progressTimer);
      progressTimer = setInterval(() => {
        if (!videoEl.duration || !fill) return;
        const p = Math.min(100, (videoEl.currentTime / videoEl.duration) * 100);
        fill.style.width = p + '%';
      }, 120);
      apply1080Fit(videoEl);
      try {
        await playFile(videoEl, file, url, abortRef);
      } catch (e) {
        console.warn('intro promo play', e);
      }
      clearInterval(progressTimer);
      if (fill) fill.style.width = '100%';
    };

    let played = 0;
    try {
      if (!cfg.playAllSlots) {
        if (pack?.file && pack.slot) {
          await runOne(pack.slot, pack.file, pack.url, pack.handle?.name);
          played = 1;
        }
      } else {
        let first = true;
        for (const slot of cfg.slots) {
          if (skipAll) break;
          if (!slot.enabled) continue;

          if (first && pack?.file && pack.slot?.id === slot.id) {
            first = false;
            await runOne(slot, pack.file, pack.url, pack.handle?.name);
            played += 1;
            continue;
          }
          first = false;

          const folder = await getFolderByKey(slot.key);
          if (!folder?.handle) {
            opts.onStatus?.(`${slot.label}: no folder linked`);
            continue;
          }
          const handles = await listVideos(folder);
          if (!handles.length) {
            opts.onStatus?.(`${slot.label}: empty folder`);
            continue;
          }
          const pick = await pickNextVideo(slot.key, handles, cfg.shuffle);
          if (!pick) continue;
          let file;
          try {
            file = await pick.getFile();
          } catch (e) {
            console.warn('intro promo getFile', e);
            continue;
          }
          await runOne(slot, file, null, pick.name);
          played += 1;
        }
      }
    } finally {
      clearInterval(progressTimer);
      try { abortRef.fn?.(); } catch (_) {}
      document.removeEventListener('keydown', onKey, true);
      root.removeEventListener('click', onOverlayClick);
      window.removeEventListener('resize', onResize);
      root.classList.add('hidden');
      root.classList.remove('is-preloading', 'fip-sponsored');
      document.body.classList.remove('fafo-intro-promo-active');
      try {
        videoEl.pause();
        if (preloadState.pack?.url) {
          try { URL.revokeObjectURL(preloadState.pack.url); } catch (_) {}
        }
        videoEl.removeAttribute('src');
        videoEl.load();
      } catch (_) {}
      preloadState.pack = null;
      preloadState.promise = null;
    }

    return { played, skipped: skipAll };
  }

  function escapeHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  global.FAFOIntroPromos = {
    BOFA,
    DEFAULT_SLOTS,
    readConfig,
    writeConfig,
    linkSlotFolder,
    clearSlotFolder,
    slotStatus,
    listVideos,
    getFolderByKey,
    playBootSequence,
    beginPreload,
    cancelPreload,
    readQueues,
  };
})(typeof window !== 'undefined' ? window : globalThis);
