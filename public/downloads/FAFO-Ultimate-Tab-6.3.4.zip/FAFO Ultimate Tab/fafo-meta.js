/**
 * FAFO on-play tags & star ratings (+ optional Explorer write via localhost:8765)
 * Tag list order: library frequency seed → after first apply this session, session counts win.
 * Loaded after script.js core; hooks into window.FAFOPlayer hooks when available.
 */
(function () {
    'use strict';

    const TOOLBOX_API = 'http://127.0.0.1:8765/api';

    let mediaMeta = {};
    let tagLibrary = [];       // display names; ordered by count (see sortTagLibrary)
    let tagLastUsed = {};      // kept for compat / secondary tie-break only
    let libraryTagCount = {};  // lower(tag) -> how many library files have this tag (seed)
    let sessionTagCount = {};  // lower(tag) -> times applied this browser session
    let sessionHasPicks = false; // once true, session counts drive order (not library seed)
    /** 'session' | 'total' — sort + primary ranking; session badges always visible on tiles */
    let countDisplayMode = 'session';
    /**
     * Hotkey matrix: 10 always-visible slots (keys 1–9, 0) × 4 modifier banks.
     * Banks: 0=base, 1=Shift, 2=Shift+Ctrl, 3=Shift+Ctrl+Alt  → 40 assignable tags.
     * Holding modifiers swaps the 10 on-screen buttons in real time.
     */
    const HOTKEY_SLOTS = 10;
    const HOTKEY_BANKS = 4;
    const BANK_LABELS = ['Base', 'Shift', 'Shift+Ctrl', 'Shift+Ctrl+Alt'];
    const BANK_SHORT = ['', '⇧', '⌃⇧', '⌥⌃⇧'];
    let tagHotkeys = emptyHotkeyBanks(); // [bank][slot] string
    let liveBank = 0; // currently displayed bank (from held modifiers)
    let activeKey = null;
    let activeName = '';
    let activeTags = [];
    let activeRating = 0;
    let suggestIndex = -1;
    let metaPanelOpen = false;
    let bracketChord = false;
    let bracketTimer = null;
    let ctxMenu = null;
    let els = {};
    /** When true, player skips clips that already have tags (then 5+ tags). */
    let skipTaggedMode = false;
    let tagLibraryHeight = 160;
    let panelWidth = 0;
    let resizeDragging = false;

    function emptyHotkeyBanks() {
        return Array.from({ length: HOTKEY_BANKS }, () => Array(HOTKEY_SLOTS).fill(''));
    }

    /** Migrate old 5-slot arrays into the new bank matrix. */
    function normalizeHotkeyBanks(raw) {
        const banks = emptyHotkeyBanks();
        if (!raw) return banks;
        // Nested banks: [4][10] or [4][5+]
        if (Array.isArray(raw) && raw.length > 0 && Array.isArray(raw[0])) {
            for (let b = 0; b < HOTKEY_BANKS; b++) {
                const row = raw[b];
                if (!Array.isArray(row)) continue;
                for (let s = 0; s < HOTKEY_SLOTS; s++) {
                    banks[b][s] = normalizeTag(row[s] || '');
                }
            }
            return banks;
        }
        // Flat list of strings (legacy 5, or 10, or 40)
        if (Array.isArray(raw) && (raw.length === 0 || typeof raw[0] === 'string')) {
            if (raw.length >= HOTKEY_BANKS * HOTKEY_SLOTS) {
                for (let b = 0; b < HOTKEY_BANKS; b++) {
                    for (let s = 0; s < HOTKEY_SLOTS; s++) {
                        banks[b][s] = normalizeTag(raw[b * HOTKEY_SLOTS + s] || '');
                    }
                }
            } else {
                // Legacy base bank only (first 5 or 10)
                for (let s = 0; s < Math.min(HOTKEY_SLOTS, raw.length); s++) {
                    banks[0][s] = normalizeTag(raw[s] || '');
                }
            }
            return banks;
        }
        return banks;
    }

    function bankFromMods(shift, ctrl, alt) {
        if (shift && ctrl && alt) return 3;
        if (shift && ctrl) return 2;
        if (shift) return 1;
        return 0;
    }

    function bankFromEvent(e) {
        return bankFromMods(!!e.shiftKey, !!(e.ctrlKey || e.metaKey), !!e.altKey);
    }

    function digitToSlot(key) {
        if (key === '0') return 9;
        if (key >= '1' && key <= '9') return parseInt(key, 10) - 1;
        return -1;
    }

    function slotToDigit(slot) {
        return slot === 9 ? '0' : String(slot + 1);
    }

    function formatHotkeyLabel(bank, slot) {
        return `${BANK_SHORT[bank] || ''}${slotToDigit(slot)}`;
    }

    function getHotkey(bank, slot) {
        return tagHotkeys[bank]?.[slot] || '';
    }

    function setHotkey(bank, slot, tag) {
        if (!tagHotkeys[bank]) tagHotkeys[bank] = Array(HOTKEY_SLOTS).fill('');
        tagHotkeys[bank][slot] = normalizeTag(tag || '');
    }

    function clearTagFromAllHotkeys(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return;
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    tagHotkeys[b][s] = '';
                }
            }
        }
    }

    function anyHotkeyAssigned() {
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s]) return true;
            }
        }
        return false;
    }

    function syncLiveBank(e) {
        const bank = e ? bankFromEvent(e) : 0;
        if (bank === liveBank) return;
        liveBank = bank;
        renderHotkeyBar();
        updateBankIndicator();
    }

    function $(id) { return document.getElementById(id); }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
    function escapeAttr(s) { return escapeHtml(s).replace(/'/g, '&#39;'); }
    /** Hard caps — corrupted metadata and AI prompt dumps used to blow past these. */
    const TAG_MAX_LEN = 100;
    const TAGS_PER_MEDIA_MAX = 40;
    const TAG_LIBRARY_MAX = 500;

    function looksLikeMetadataDump(s) {
        if (!s) return true;
        if (/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\uFFFD]/.test(s)) return true;
        if (/^[{[]/.test(s) || /"\w+"\s*:/.test(s)) return true;
        if ((s.match(/[\\\/|]/g) || []).length >= 3) return true;
        if (/^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(s) && s.length > 36) return true;
        if (/\b(codec|bitrate|fps|resolution|duration|encoder|muxer|handler_name|major_brand)\b/i.test(s)) return true;
        // AI image/video prompt dumps (common in ©cmt / Keywords from generators)
        if (/\b(cinematic|photorealistic|masterpiece|negative prompt|best quality|ultra detailed|highly detailed|volumetric|octane render|unreal engine|trending on artstation|shot on|bokeh|8k|4k uhd)\b/i.test(s)) return true;
        if (/\b(prompt|seed|cfg scale|steps:|lora|checkpoint|sampler)\b/i.test(s)) return true;
        const seps = (s.match(/[,;|]/g) || []).length;
        // Multi-clause prompt blobs before they are split into fake "tags"
        if (s.length > 80 && seps >= 3) return true;
        if (s.length > 50 && seps >= 5) return true;
        const alnum = (s.match(/[a-zA-Z0-9]/g) || []).length;
        if (s.length > 8 && alnum / s.length < 0.4) return true;
        // Long prose / prompt paragraphs are not tags
        if (s.length > 60 && (s.match(/\s/g) || []).length >= 8) return true;
        // Hard reject anything already over the display cap that is multi-word soup
        if (s.length > 100) return true;
        return false;
    }

    /** True when a raw source string is an AI/metadata blob, not a real tag list. */
    function looksLikePromptBlob(raw) {
        const s = String(raw == null ? '' : raw).trim();
        if (!s) return true;
        if (looksLikeMetadataDump(s)) return true;
        const pieces = s.split(/[,;|]+/).map((p) => p.trim()).filter(Boolean);
        // One long string exploding into many short "tags" = generator prompt
        if (pieces.length >= 6 && s.length > 60) return true;
        if (pieces.length >= 4 && s.length > 120) return true;
        return false;
    }

    /**
     * Normalize a single tag: trim, collapse whitespace, cap at 100 chars,
     * drop control/metadata garbage. Returns '' if unusable.
     */
    function normalizeTag(t) {
        let s = String(t == null ? '' : t)
            .replace(/[\u0000-\u001F\u007F]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
        if (!s) return '';
        if (s.length > TAG_MAX_LEN) {
            s = s.slice(0, TAG_MAX_LEN);
            // prefer breaking on word boundary when possible
            const cut = s.lastIndexOf(' ');
            if (cut >= 40) s = s.slice(0, cut);
            s = s.trim();
        }
        if (looksLikeMetadataDump(s)) return '';
        return s;
    }

    /** Deduped, sanitized list capped per media item. */
    function sanitizeTagList(tags) {
        const out = [];
        const seen = new Set();
        const list = Array.isArray(tags) ? tags : (tags ? [tags] : []);
        for (const raw of list) {
            const rawStr = String(raw == null ? '' : raw);
            // Drop whole AI prompt / metadata blobs before splitting them into fake chips
            if (looksLikePromptBlob(rawStr)) continue;
            const pieces = rawStr.split(/[,;|]+/);
            if (pieces.length >= 6 && rawStr.length > 60) continue;
            for (const piece of pieces) {
                const t = normalizeTag(piece);
                if (!t) continue;
                // Real tags are short keywords — reject multi-sentence leftovers
                if (t.split(/\s+/).length > 6) continue;
                const low = t.toLowerCase();
                if (seen.has(low)) continue;
                seen.add(low);
                out.push(t);
                if (out.length >= TAGS_PER_MEDIA_MAX) return out;
            }
        }
        return out;
    }

    /** Scrub live storage after upgrades / corruption. */
    function scrubAllStoredMeta() {
        let changed = false;
        const next = {};
        for (const [k, v] of Object.entries(mediaMeta || {})) {
            if (!v || typeof v !== 'object') continue;
            const tags = sanitizeTagList(v.tags || []);
            const rating = Math.max(0, Math.min(5, parseInt(v.rating, 10) || 0));
            if (JSON.stringify(tags) !== JSON.stringify(v.tags || []) || rating !== (v.rating || 0)) changed = true;
            next[k] = { ...v, tags, rating };
        }
        mediaMeta = next;
        const cleanedLib = sanitizeTagList(tagLibrary).slice(0, TAG_LIBRARY_MAX);
        if (cleanedLib.length !== tagLibrary.length || cleanedLib.some((t, i) => t !== tagLibrary[i])) {
            tagLibrary = cleanedLib;
            changed = true;
        } else {
            tagLibrary = cleanedLib;
        }
        return changed;
    }


    /** Count tags across saved media (library frequency seed). */
    function rebuildLibraryTagCounts() {
        libraryTagCount = {};
        Object.values(mediaMeta || {}).forEach((m) => {
            (m.tags || []).forEach((raw) => {
                const t = normalizeTag(raw);
                if (!t) return;
                const low = t.toLowerCase();
                libraryTagCount[low] = (libraryTagCount[low] || 0) + 1;
            });
        });
    }

    function sessionCountFor(tag) {
        return sessionTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function libraryCountFor(tag) {
        return libraryTagCount[normalizeTag(tag).toLowerCase()] || 0;
    }
    function isTagOnVideo(tag) {
        const low = normalizeTag(tag).toLowerCase();
        return activeTags.some((x) => x.toLowerCase() === low);
    }

    /** Primary sort key from toggle: session (after first pick) or library total. */
    function displayCountFor(tag) {
        if (countDisplayMode === 'total') return libraryCountFor(tag);
        if (sessionHasPicks) return sessionCountFor(tag);
        return libraryCountFor(tag); // seed until first session pick
    }

    /**
     * Sort tag list by Session or Total mode (toggle).
     * Session mode: after first pick this session, session counts lead; else library seed.
     * Total mode: library frequency always.
     */
    function sortTagLibrary() {
        tagLibrary.sort((a, b) => {
            const la = a.toLowerCase();
            const lb = b.toLowerCase();
            if (countDisplayMode === 'session' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ca = libraryTagCount[la] || 0;
            const cb = libraryTagCount[lb] || 0;
            if (cb !== ca) return cb - ca;
            if (countDisplayMode === 'total' && sessionHasPicks) {
                const sa = sessionTagCount[la] || 0;
                const sb = sessionTagCount[lb] || 0;
                if (sb !== sa) return sb - sa;
            }
            const ta = tagLastUsed[la] || 0;
            const tb = tagLastUsed[lb] || 0;
            if (tb !== ta) return tb - ta;
            return a.localeCompare(b, undefined, { sensitivity: 'base' });
        });
    }

    function syncCountModeToggle() {
        const btn = $('meta-count-mode');
        if (!btn) return;
        const isTotal = countDisplayMode === 'total';
        btn.classList.toggle('active', isTotal);
        btn.dataset.mode = countDisplayMode;
        btn.textContent = isTotal ? 'Σ Totals' : 'Session #';
        btn.title = isTotal
            ? 'Showing library totals for sort · click for session counts'
            : 'Showing session counts for sort · click for library totals';
    }

    function setCountDisplayMode(mode) {
        countDisplayMode = mode === 'total' ? 'total' : 'session';
        syncCountModeToggle();
        sortTagLibrary();
        renderTagLibrary();
        renderHotkeyBar();
    }

    /** Apply tags this session — bumps session counter (and light last-used stamp). */
    function touchTags(tags, when = Date.now()) {
        const list = Array.isArray(tags) ? tags : [tags];
        let any = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            sessionHasPicks = true;
            sessionTagCount[low] = (sessionTagCount[low] || 0) + 1;
            tagLastUsed[low] = when;
            const existing = tagLibrary.find((x) => x.toLowerCase() === low);
            if (!existing) tagLibrary.push(t);
            any = true;
        });
        if (any) sortTagLibrary();
    }

    /**
     * Add tags into the known vocabulary WITHOUT bumping session counters.
     * Use when discovering tags from file metadata or catalog on load/play.
     */
    function ensureTagsKnown(tags) {
        const list = Array.isArray(tags) ? tags : [tags];
        let added = false;
        list.forEach((raw) => {
            const t = normalizeTag(raw);
            if (!t) return;
            const low = t.toLowerCase();
            if (tagLibrary.some((x) => x.toLowerCase() === low)) return;
            tagLibrary.push(t);
            added = true;
        });
        if (added) sortTagLibrary();
        return added;
    }

    /** Returns display label for a tag's assigned hotkey, or ''. */
    function hotkeySlotForTag(tag) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low) return '';
        for (let b = 0; b < HOTKEY_BANKS; b++) {
            for (let s = 0; s < HOTKEY_SLOTS; s++) {
                if (tagHotkeys[b][s] && tagHotkeys[b][s].toLowerCase() === low) {
                    return formatHotkeyLabel(b, s);
                }
            }
        }
        return '';
    }

    async function loadStore() {
        try {
            // Auto-recover if live meta was wiped but a snapshot/history exists
            if (globalThis.FAFOBackup?.tryRecoverEmptyLive) {
                await FAFOBackup.tryRecoverEmptyLive();
            }
            const res = await chrome.storage.local.get([
                'fafoMediaMeta', 'fafoTagLibrary', 'fafoTagLastUsed', 'fafoTagHotkeys',
                'fafoSkipTaggedMode', 'fafoTagLibraryHeight', 'fafoMetaPanelWidth',
            ]);
            mediaMeta = res.fafoMediaMeta || {};
            tagLastUsed = res.fafoTagLastUsed && typeof res.fafoTagLastUsed === 'object' ? res.fafoTagLastUsed : {};
            tagLibrary = Array.isArray(res.fafoTagLibrary) ? res.fafoTagLibrary.slice() : [];
            tagHotkeys = normalizeHotkeyBanks(res.fafoTagHotkeys);
            skipTaggedMode = !!res.fafoSkipTaggedMode;
            if (typeof res.fafoTagLibraryHeight === 'number' && res.fafoTagLibraryHeight >= 80) {
                tagLibraryHeight = Math.min(res.fafoTagLibraryHeight, 480);
            }
            if (typeof res.fafoMetaPanelWidth === 'number' && res.fafoMetaPanelWidth >= 280) {
                panelWidth = Math.min(res.fafoMetaPanelWidth, 520);
            }
            // Scrub corrupted / oversized metadata tags (cap 100, drop dumps)
            if (scrubAllStoredMeta()) {
                try { await chrome.storage.local.set({ fafoMediaMeta: mediaMeta, fafoTagLibrary: tagLibrary }); } catch { /* ignore */ }
            }
            // Always re-harvest known tags from saved media (no session bump)
            Object.values(mediaMeta).forEach(m => ensureTagsKnown(m.tags || []));
            if (!tagLibrary.length) {
                const set = new Set();
                Object.values(mediaMeta).forEach(m => (m.tags || []).forEach(t => {
                    const n = normalizeTag(t);
                    if (n) set.add(n);
                }));
                tagLibrary = [...set].slice(0, TAG_LIBRARY_MAX);
            } else {
                tagLibrary = sanitizeTagList(tagLibrary).slice(0, TAG_LIBRARY_MAX);
            }
            rebuildLibraryTagCounts();
            sessionTagCount = {};
            sessionHasPicks = false;
            sortTagLibrary();
        } catch {
            mediaMeta = {};
            tagLibrary = [];
            tagLastUsed = {};
            libraryTagCount = {};
            sessionTagCount = {};
            sessionHasPicks = false;
            tagHotkeys = emptyHotkeyBanks();
            skipTaggedMode = false;
        }
    }

    async function saveStore() {
        try {
            const payload = {
                fafoMediaMeta: mediaMeta,
                fafoTagLibrary: tagLibrary,
                fafoTagLastUsed: tagLastUsed,
                fafoTagHotkeys: tagHotkeys,
                fafoSkipTaggedMode: skipTaggedMode,
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: panelWidth || undefined,
            };
            await chrome.storage.local.set(payload);
            // Durable rolling backups (snapshot + history)
            if (globalThis.FAFOBackup?.afterLiveSave) {
                FAFOBackup.afterLiveSave(payload, 'tag-save').catch((e) =>
                    console.warn('FAFO backup failed', e)
                );
            }
        } catch (e) {
            console.warn('FAFO meta save failed', e);
            if (els.status) {
                els.status.textContent = 'Save failed — check storage / try Backup → Export tags';
            }
        }
    }

    function applyTagLibraryHeight() {
        if (els.library) {
            els.library.style.height = tagLibraryHeight + 'px';
        }
        if (els.panel && panelWidth > 0) {
            els.panel.style.width = panelWidth + 'px';
        }
    }

    function updateSkipTaggedBtn() {
        if (!els.skipTagged) return;
        els.skipTagged.classList.toggle('active', skipTaggedMode);
        els.skipTagged.setAttribute('aria-pressed', skipTaggedMode ? 'true' : 'false');
        els.skipTagged.title = skipTaggedMode
            ? 'ON: skipping already-tagged clips (then 5+ tags). Click to turn off.'
            : 'Skip videos that already have tags; once all are tagged, skip ones with 5+ tags';
        els.skipTagged.textContent = skipTaggedMode ? 'Skip tagged · ON' : 'Skip tagged';
    }

    async function setSkipTaggedMode(on) {
        skipTaggedMode = !!on;
        updateSkipTaggedBtn();
        try {
            await chrome.storage.local.set({ fafoSkipTaggedMode: skipTaggedMode });
        } catch { /* ignore */ }
        if (els.status) {
            els.status.textContent = skipTaggedMode
                ? 'Skip tagged ON — jumps past tagged clips (then 5+ tags)'
                : 'Skip tagged off';
        }
        // If we just turned it on and the current clip is already tagged, advance
        if (skipTaggedMode && activeTags.length > 0) {
            window.FAFOPlayer?.skipTrack?.(1);
        }
    }

    /**
     * Look up tag count for a playlist item (for skip-tagged mode).
     * Matches storage keys by handle identity or filename.
     */
    function tagCountForItem(item) {
        if (!item) return 0;
        const name = itemDisplayName(item);
        // Prefer live state for the clip currently bound in the panel
        if (activeName && name && activeName.toLowerCase() === String(name).toLowerCase()) {
            return activeTags.length;
        }
        const byName = findStoredByName(name);
        if (byName?.meta?.tags) return byName.meta.tags.length;
        // Also scan raw keys like file:Name|size|mtime
        if (name) {
            const low = String(name).toLowerCase();
            for (const [k, v] of Object.entries(mediaMeta || {})) {
                if (!v?.tags?.length) continue;
                if (k.toLowerCase().includes(low)) return v.tags.length;
            }
        }
        return 0;
    }

    function isSkipTaggedMode() {
        return skipTaggedMode;
    }

    /** Pull tag vocabulary from toolbox/server without MRU bump. */
    async function harvestTagsFromServer() {
        if (!(await toolboxOnline())) return;
        try {
            const r = await fetch(`${TOOLBOX_API}/tags`, { signal: AbortSignal.timeout(3000) });
            if (!r.ok) return;
            const tags = await r.json();
            if (Array.isArray(tags) && tags.length) {
                ensureTagsKnown(tags);
                await saveStore();
                renderTagLibrary();
            }
        } catch { /* optional */ }
    }

    async function fetchTagsForIdentity(id) {
        if (!id?.name || !(await toolboxOnline())) return null;
        try {
            // Match catalog by name/size via write-metadata path — use media query if available
            const q = new URLSearchParams({ search: id.name, limit: '5' });
            const r = await fetch(`${TOOLBOX_API}/media?${q}`, { signal: AbortSignal.timeout(3000) });
            if (!r.ok) return null;
            const data = await r.json();
            const items = data.items || data || [];
            if (!Array.isArray(items)) return null;
            let hit = items.find(m => m.name === id.name && (id.size == null || m.size === id.size));
            if (!hit) hit = items.find(m => m.name === id.name);
            if (!hit) return null;
            return {
                tags: hit.tags || [],
                rating: hit.rank != null ? Number(hit.rank) : 0,
            };
        } catch {
            return null;
        }
    }

    /**
     * Match stored meta by exact filename only (re-export / size-key change).
     * Never use substring key matching — that reused one video's tags on many others.
     */
    function findStoredByName(name) {
        if (!name) return null;
        const low = name.toLowerCase();
        let best = null;
        for (const [k, v] of Object.entries(mediaMeta)) {
            if (!v) continue;
            const vName = v.name ? String(v.name).toLowerCase() : '';
            const keyName = (() => {
                // keys look like file:Name.ext|size|mtime
                const m = /^file:(.+?)\|/.exec(k);
                return m ? m[1].toLowerCase() : '';
            })();
            if (vName === low || keyName === low) {
                // Prefer most recently updated
                if (!best || (v.updated || 0) >= (best.meta.updated || 0)) {
                    best = { key: k, meta: v };
                }
            }
        }
        return best;
    }

    function itemDisplayName(item) {
        if (!item) return 'Unknown';
        if (item.handle?.name) return item.handle.name;
        if (typeof item === 'object' && item.name) return item.name;
        if (item.url) {
            try {
                return decodeURIComponent(item.url.split('?')[0].split('/').pop() || item.url);
            } catch { return item.url; }
        }
        if (typeof item === 'string') {
            try { return decodeURIComponent(item.split('/').pop() || item); }
            catch { return item; }
        }
        return 'Unknown';
    }

    async function mediaKeyFor(item) {
        if (!item) return null;
        if (item.handle) {
            try {
                const f = await item.handle.getFile();
                return `file:${f.name}|${f.size}|${f.lastModified}`;
            } catch {
                return 'handle:' + (item.handle.name || 'unknown');
            }
        }
        if (typeof item === 'object' && item.getFile) {
            try {
                const f = await item.getFile();
                return `file:${f.name}|${f.size}|${f.lastModified}`;
            } catch {
                return 'handle:' + (item.name || 'unknown');
            }
        }
        if (item.url) return 'url:' + item.url;
        if (typeof item === 'string') return 'url:' + item;
        return 'unknown:' + itemDisplayName(item);
    }

    async function identityForItem(item) {
        const name = itemDisplayName(item);
        if (item?.handle?.getFile) {
            try {
                const f = await item.handle.getFile();
                return { name: f.name || name, size: f.size, mtime: f.lastModified };
            } catch { /* fall through */ }
        }
        if (typeof item === 'object' && item.getFile) {
            try {
                const f = await item.getFile();
                return { name: f.name || name, size: f.size, mtime: f.lastModified };
            } catch { /* fall through */ }
        }
        return { name, size: null, mtime: null };
    }

    async function toolboxOnline() {
        try {
            const r = await fetch(`${TOOLBOX_API}/health`, { signal: AbortSignal.timeout(1200) });
            return r.ok;
        } catch {
            return false;
        }
    }

    async function syncFileMetadataToDisk() {
        if (!activeKey) return;
        if (!(await toolboxOnline())) {
            if (els.status) {
                els.status.textContent = 'Saved in FAFO · run explorer-meta\\START_META_SERVER.bat for Explorer tags';
            }
            return;
        }
        const item = window.FAFOPlayer?.getCurrentItem?.() || null;
        const id = await identityForItem(item);
        if (!id?.name) return;
        try {
            const r = await fetch(`${TOOLBOX_API}/fs/write-metadata`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: id.name,
                    size: id.size,
                    mtime: id.mtime,
                    tags: activeTags,
                    rating: activeRating,
                    update_catalog: true,
                }),
            });
            const data = await r.json().catch(() => ({}));
            if (!r.ok) {
                const detail = data.detail || r.statusText;
                if (els.status) {
                    const d = typeof detail === 'string' ? detail : JSON.stringify(detail);
                    els.status.textContent = /not found|library/i.test(d)
                        ? 'Saved in FAFO · run ADD_VIDEO_FOLDER.bat for this library'
                        : `Saved in FAFO · file write: ${d}`;
                }
                return;
            }
            const methods = data.methods || data.file_write?.methods || [];
            if (els.status) {
                els.status.textContent = data.ok === false
                    ? 'Saved · file write failed'
                    : `Saved to file (Explorer) · ${(methods.join(', ') || 'ok')}`;
            }
        } catch {
            if (els.status) els.status.textContent = 'Saved in FAFO · could not reach toolbox server';
        }
    }

    async function persistActiveMeta(opts = {}) {
        if (!activeKey) return;
        const now = Date.now();
        activeTags = sanitizeTagList(activeTags);
        mediaMeta[activeKey] = {
            rating: activeRating,
            tags: [...activeTags],
            name: activeName,
            updated: now,
        };
        // Session counters only for tags the user just applied (not full resaves / rating-only)
        const touched = opts.touchedTags != null ? opts.touchedTags : [];
        if (touched && touched.length) touchTags(touched, now);
        // Ensure every active tag is in the vocabulary without session bumps
        ensureTagsKnown(activeTags);
        // Keep library seed fresh as tags land on files this session
        rebuildLibraryTagCounts();
        sortTagLibrary();
        await saveStore();
        renderMetaPanel();
        if (activeTags.length) clearUntaggedPrompt();
        syncFileMetadataToDisk().catch(() => {});
    }

    function setMetaPanelOpen(open) {
        metaPanelOpen = open;
        if (els.panel) {
            els.panel.classList.toggle('collapsed', !open);
            els.panel.setAttribute('aria-hidden', open ? 'false' : 'true');
        }
        if (els.toggle) els.toggle.classList.toggle('open', open);
        if (open) {
            renderTagLibrary();
            renderTagSuggestions(els.tagInput?.value || '');
        } else hideSuggestions();
    }

    function setRating(r) {
        if (r === activeRating) activeRating = 0;
        else activeRating = Math.max(0, Math.min(5, r));
        persistActiveMeta();
    }

    async function addTagsFromInput() {
        if (!els.tagInput) return;
        const parts = els.tagInput.value.split(/[,;]+/).map(normalizeTag).filter(Boolean);
        if (!parts.length) return;
        const newly = [];
        parts.forEach(t => {
            if (!activeTags.some(x => x.toLowerCase() === t.toLowerCase())) {
                activeTags.push(t);
                newly.push(t);
            } else {
                newly.push(t); // still counts as "used" for MRU order
            }
        });
        els.tagInput.value = '';
        hideSuggestions();
        await persistActiveMeta({ touchedTags: newly });
    }

    async function toggleLibraryTag(tag) {
        const idx = activeTags.findIndex(x => x.toLowerCase() === tag.toLowerCase());
        if (idx >= 0) {
            activeTags.splice(idx, 1);
            // Removing does not reorder; only applying bumps last-used
            await persistActiveMeta({ touchedTags: [] });
        } else {
            activeTags.push(tag);
            await persistActiveMeta({ touchedTags: [tag] });
        }
    }

    function hideCtxMenu() {
        if (ctxMenu) {
            ctxMenu.remove();
            ctxMenu = null;
        }
    }

    function showTagContextMenu(e, tag) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const t = normalizeTag(tag);
        const bank = liveBank;
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu meta-ctx-menu-wide';
        const slotBtns = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
            const cur = getHotkey(bank, s);
            const active = cur && cur.toLowerCase() === t.toLowerCase();
            const label = formatHotkeyLabel(bank, s);
            return `<button type="button" data-bank="${bank}" data-slot="${s}" class="${active ? 'on' : ''}">
                <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
            </button>`;
        }).join('');
        // Quick bank switch inside menu
        const bankTabs = BANK_LABELS.map((name, b) =>
            `<button type="button" data-pick-bank="${b}" class="meta-ctx-bank ${b === bank ? 'on' : ''}">${escapeHtml(name)}</button>`
        ).join('');
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">${escapeHtml(t)}</div>
            <div class="meta-ctx-hint">Assign to slot (hold modifiers to change bank, or pick below)</div>
            <div class="meta-ctx-bank-row">${bankTabs}</div>
            <div class="meta-ctx-slot-list" data-for-bank="${bank}">${slotBtns}</div>
            <button type="button" data-clear="1" class="meta-ctx-clear">Clear this tag's hotkey</button>
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 260);
        const y = Math.min(e.clientY, window.innerHeight - 360);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        const refillSlots = (b) => {
            const list = ctxMenu.querySelector('.meta-ctx-slot-list');
            if (!list) return;
            list.dataset.forBank = String(b);
            list.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, s) => {
                const cur = getHotkey(b, s);
                const active = cur && cur.toLowerCase() === t.toLowerCase();
                const label = formatHotkeyLabel(b, s);
                return `<button type="button" data-bank="${b}" data-slot="${s}" class="${active ? 'on' : ''}">
                    <kbd>${escapeHtml(label)}</kbd> ${active ? '✓ ' + escapeHtml(cur) : (cur ? escapeHtml(cur) : 'empty')}
                </button>`;
            }).join('');
            wireSlotAssign(list);
        };

        const wireSlotAssign = (root) => {
            root.querySelectorAll('[data-slot]').forEach((btn) => {
                btn.addEventListener('click', async () => {
                    const b = parseInt(btn.dataset.bank, 10);
                    const s = parseInt(btn.dataset.slot, 10);
                    clearTagFromAllHotkeys(t);
                    setHotkey(b, s, t);
                    await saveStore();
                    hideCtxMenu();
                    renderTagLibrary();
                    renderHotkeyBar();
                    if (els.status) els.status.textContent = `Hotkey ${formatHotkeyLabel(b, s)} → ${t}`;
                });
            });
        };

        ctxMenu.querySelectorAll('[data-pick-bank]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const b = parseInt(btn.dataset.pickBank, 10);
                ctxMenu.querySelectorAll('[data-pick-bank]').forEach((x) => {
                    x.classList.toggle('on', parseInt(x.dataset.pickBank, 10) === b);
                });
                refillSlots(b);
            });
        });
        wireSlotAssign(ctxMenu.querySelector('.meta-ctx-slot-list'));

        ctxMenu.querySelector('[data-clear]')?.addEventListener('click', async () => {
            clearTagFromAllHotkeys(t);
            await saveStore();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
    }

    /** Right-click an empty or filled hotkey slot to pick / reassign a tag. */
    function showHotkeySlotAssignMenu(e, bank, slot) {
        e.preventDefault();
        e.stopPropagation();
        hideCtxMenu();
        const current = getHotkey(bank, slot);
        const label = formatHotkeyLabel(bank, slot);
        const candidates = tagLibrary.slice(0, 24);
        ctxMenu = document.createElement('div');
        ctxMenu.className = 'meta-ctx-menu';
        ctxMenu.innerHTML = `
            <div class="meta-ctx-title">Hotkey ${escapeHtml(label)}</div>
            <div class="meta-ctx-hint">${BANK_LABELS[bank]} · ${current ? 'Currently: ' + escapeHtml(current) : 'Empty — pick a tag'}</div>
            ${candidates.length
                ? candidates.map((t) => {
                    const on = current && current.toLowerCase() === t.toLowerCase();
                    return `<button type="button" data-assign="${escapeAttr(t)}" class="${on ? 'on' : ''}">${escapeHtml(t)}</button>`;
                }).join('')
                : '<div class="meta-ctx-hint">No tags yet — add some first</div>'}
            ${current ? '<button type="button" data-clear-slot="1" class="meta-ctx-clear">Clear this slot</button>' : ''}
        `;
        document.body.appendChild(ctxMenu);
        const x = Math.min(e.clientX, window.innerWidth - 220);
        const y = Math.min(e.clientY, window.innerHeight - 320);
        ctxMenu.style.left = x + 'px';
        ctxMenu.style.top = y + 'px';

        ctxMenu.querySelectorAll('[data-assign]').forEach((btn) => {
            btn.addEventListener('click', async () => {
                const t = normalizeTag(btn.dataset.assign);
                clearTagFromAllHotkeys(t);
                setHotkey(bank, slot, t);
                await saveStore();
                hideCtxMenu();
                renderTagLibrary();
                renderHotkeyBar();
                if (els.status) els.status.textContent = `Hotkey ${label} → ${t}`;
            });
        });
        ctxMenu.querySelector('[data-clear-slot]')?.addEventListener('click', async () => {
            setHotkey(bank, slot, '');
            await saveStore();
            hideCtxMenu();
            renderTagLibrary();
            renderHotkeyBar();
        });
    }

    function updateBankIndicator() {
        const el = $('meta-hotkey-bank');
        if (!el) return;
        el.innerHTML = BANK_LABELS.map((name, b) =>
            `<span class="meta-bank-chip ${b === liveBank ? 'active' : ''}" data-bank="${b}">${escapeHtml(name)}</span>`
        ).join('');
        el.querySelectorAll('.meta-bank-chip').forEach((chip) => {
            chip.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                // Manual bank pin until modifiers change
                liveBank = parseInt(chip.dataset.bank, 10);
                renderHotkeyBar();
                updateBankIndicator();
            });
        });
    }

    function renderHotkeyBar() {
        const bar = $('meta-hotkey-bar');
        if (!bar) return;
        const bank = liveBank;
        bar.dataset.bank = String(bank);
        bar.className = `meta-hotkey-bar bank-${bank}`;
        bar.innerHTML = Array.from({ length: HOTKEY_SLOTS }, (_, i) => {
            const t = getHotkey(bank, i);
            const label = formatHotkeyLabel(bank, i);
            const on = t ? isTagOnVideo(t) : false;
            const sc = t ? sessionCountFor(t) : 0;
            const lc = t ? libraryCountFor(t) : 0;
            let statusClass = 'empty';
            if (t && on) statusClass = 'on-video';
            else if (t) statusClass = 'set';
            const countsHtml = t
                ? `<span class="meta-hk-counts">
                    <span class="meta-count-badge session" title="Session applies">${sc}</span>
                    ${on ? `<span class="meta-count-badge total" title="Library total (on this video)">${lc}</span>` : ''}
                   </span>`
                : '';
            const title = t
                ? `${on ? '● On this video · ' : ''}Session ${sc} · Library ${lc} · Left-click apply · Right-click reassign · ${BANK_LABELS[bank]}`
                : `Empty · Right-click to assign · ${BANK_LABELS[bank]}`;
            return `<button type="button" class="meta-hotkey-slot ${statusClass}" data-bank="${bank}" data-slot="${i}" title="${escapeAttr(title)}">
                <span class="meta-hk-top"><kbd>${escapeHtml(label)}</kbd>${countsHtml}</span>
                <span class="meta-hk-name">${t ? escapeHtml(t) : '—'}</span>
            </button>`;
        }).join('');
        bar.querySelectorAll('.meta-hotkey-slot').forEach((btn) => {
            const b = parseInt(btn.dataset.bank, 10);
            const slot = parseInt(btn.dataset.slot, 10);
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                applyHotkeyTag(b, slot);
            });
            btn.addEventListener('contextmenu', (e) => showHotkeySlotAssignMenu(e, b, slot));
        });
        updateBankIndicator();
    }

    async function applyHotkeyTag(bank, slot) {
        // Back-compat: applyHotkeyTag(1..10) treated as base bank
        if (slot == null && typeof bank === 'number' && bank >= 1 && bank <= HOTKEY_SLOTS) {
            slot = bank - 1;
            bank = 0;
        }
        bank = Math.max(0, Math.min(HOTKEY_BANKS - 1, bank | 0));
        slot = Math.max(0, Math.min(HOTKEY_SLOTS - 1, slot | 0));
        const tag = getHotkey(bank, slot);
        const label = formatHotkeyLabel(bank, slot);
        if (!tag) {
            if (els.status) els.status.textContent = `Hotkey ${label} empty — right-click to assign`;
            setMetaPanelOpen(true);
            return;
        }
        if (!activeKey) {
            if (els.status) els.status.textContent = 'No media active to tag';
            return;
        }
        if (!activeTags.some(x => x.toLowerCase() === tag.toLowerCase())) {
            activeTags.push(tag);
        }
        await persistActiveMeta({ touchedTags: [tag] });
        if (els.status) els.status.textContent = `Applied ${label} ${tag}`;
    }

    function renderTagLibrary() {
        if (!els.library) return;
        sortTagLibrary();
        syncCountModeToggle();
        const q = (els.tagFilter?.value || '').trim().toLowerCase();
        const list = tagLibrary.filter(t => !q || t.toLowerCase().includes(q));
        const modeLabel = countDisplayMode === 'total' ? 'totals' : 'session';
        if (els.tagCount) {
            els.tagCount.textContent = tagLibrary.length
                ? `(${tagLibrary.length} · sort: ${modeLabel})`
                : '';
        }
        if (!list.length) {
            els.library.innerHTML = tagLibrary.length
                ? '<div class="meta-lib-empty">No tags match filter</div>'
                : '<div class="meta-lib-empty">Tags from files &amp; typing appear here (highest count first)</div>';
            renderHotkeyBar();
            return;
        }
        els.library.innerHTML = list.map(t => {
            const on = isTagOnVideo(t);
            const hk = hotkeySlotForTag(t);
            const sc = sessionCountFor(t);
            const lc = libraryCountFor(t);
            // Always show session count; library total only when selected on this video
            const sessionBadge = `<span class="meta-count-badge session" title="Session applies">${sc}</span>`;
            const totalBadge = on
                ? `<span class="meta-count-badge total" title="Library total (shown because selected on this video)">${lc}</span>`
                : '';
            const classes = [
                'meta-lib-tag',
                on ? 'on-video' : '',
                sc > 0 ? 'has-session' : '',
                hk ? 'has-hotkey' : '',
            ].filter(Boolean).join(' ');
            return `<button type="button" class="${classes}" data-tag="${escapeAttr(t)}">${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span> ` : ''}<span class="meta-lib-name">${escapeHtml(t)}</span>${sessionBadge}${totalBadge}</button>`;
        }).join('');
        els.library.querySelectorAll('.meta-lib-tag').forEach(btn => {
            btn.addEventListener('click', () => toggleLibraryTag(btn.dataset.tag));
            btn.addEventListener('contextmenu', (e) => showTagContextMenu(e, btn.dataset.tag));
        });
        renderHotkeyBar();
    }

    function matchingSuggestions(query) {
        const q = normalizeTag(query).toLowerCase();
        const onVideo = new Set(activeTags.map(t => t.toLowerCase()));
        // tagLibrary is already count-sorted; when typing, prefer prefix then count
        let list = tagLibrary.filter(t => !onVideo.has(t.toLowerCase()));
        if (q) {
            list = list.filter(t => t.toLowerCase().includes(q));
            list.sort((a, b) => {
                const ap = a.toLowerCase().startsWith(q) ? 0 : 1;
                const bp = b.toLowerCase().startsWith(q) ? 0 : 1;
                if (ap !== bp) return ap - bp;
                const ca = displayCountFor(a);
                const cb = displayCountFor(b);
                if (cb !== ca) return cb - ca;
                return a.localeCompare(b, undefined, { sensitivity: 'base' });
            });
        }
        return list.slice(0, 12);
    }

    function hideSuggestions() {
        if (!els.suggest) return;
        els.suggest.hidden = true;
        els.suggest.innerHTML = '';
        suggestIndex = -1;
    }

    function renderTagSuggestions(query) {
        if (!els.suggest) return;
        const matches = matchingSuggestions(query);
        const q = normalizeTag(query);
        if (!matches.length) {
            if (q) {
                els.suggest.innerHTML = `<div class="hint">Press Enter to create “${escapeHtml(q)}”</div>`;
                els.suggest.hidden = false;
            } else {
                const top = tagLibrary.filter(t => !activeTags.some(x => x.toLowerCase() === t.toLowerCase())).slice(0, 10);
                if (!top.length) { hideSuggestions(); return; }
                els.suggest.innerHTML = top.map((t, i) =>
                    `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}">${escapeHtml(t)}</div>`
                ).join('');
                wireSuggest();
                els.suggest.hidden = false;
            }
            return;
        }
        els.suggest.innerHTML = matches.map((t, i) =>
            `<div data-tag="${escapeAttr(t)}" class="${i === suggestIndex ? 'active' : ''}">${escapeHtml(t)}</div>`
        ).join('');
        wireSuggest();
        els.suggest.hidden = false;
    }

    function wireSuggest() {
        els.suggest.querySelectorAll('[data-tag]').forEach(div => {
            div.addEventListener('mousedown', (e) => {
                e.preventDefault();
                pickSuggestion(div.dataset.tag);
            });
        });
    }

    async function pickSuggestion(tag) {
        if (els.tagInput) els.tagInput.value = '';
        hideSuggestions();
        if (!activeTags.some(x => x.toLowerCase() === tag.toLowerCase())) {
            activeTags.push(tag);
        }
        await persistActiveMeta({ touchedTags: [tag] });
        els.tagInput?.focus();
    }

    function renderMetaPanel() {
        if (!els.filename) return;
        const n = window.FAFOPlayer?.getPlaylistLength?.() ?? 0;
        const idx = window.FAFOPlayer?.getCurrentIndex?.() ?? 0;
        els.filename.textContent = activeName || 'No media';
        els.filename.title = activeName || '';
        if (els.status) {
            if (!activeKey) {
                els.status.textContent = n ? 'Loading…' : 'No media — link folders in Options';
            } else {
                const hkHint = anyHotkeyAssigned()
                    ? ' · hold Shift/Ctrl/Alt for banks · click or `+1–0'
                    : ' · right-click tag → hotkey';
                els.status.textContent = `Item ${idx + 1} of ${n} · T panel · 1–5 stars${hkHint}`;
            }
        }

        if (els.stars) {
            let html = '';
            for (let i = 1; i <= 5; i++) {
                html += `<span class="meta-star ${i <= activeRating ? 'on' : ''}" data-r="${i}">${i <= activeRating ? '★' : '☆'}</span>`;
            }
            els.stars.innerHTML = html;
            els.stars.querySelectorAll('.meta-star').forEach(st => {
                st.addEventListener('click', () => setRating(parseInt(st.dataset.r, 10)));
                st.addEventListener('contextmenu', (e) => { e.preventDefault(); setRating(0); });
            });
        }

        if (els.currentTags) {
            if (!activeTags.length) {
                els.currentTags.innerHTML = '<span class="meta-chip-empty">No tags — type, click list, or hotkey slots</span>';
            } else {
                els.currentTags.innerHTML = activeTags.map((t, i) => {
                    const hk = hotkeySlotForTag(t);
                    return `<span class="meta-chip" data-tag="${escapeAttr(t)}">${hk ? `<span class="meta-hk-badge">${escapeHtml(hk)}</span>` : ''}${escapeHtml(t)} <button type="button" data-i="${i}">×</button></span>`;
                }).join('');
                els.currentTags.querySelectorAll('button').forEach(btn => {
                    btn.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        activeTags.splice(parseInt(btn.dataset.i, 10), 1);
                        await persistActiveMeta({ touchedTags: [] });
                    });
                });
                els.currentTags.querySelectorAll('.meta-chip').forEach(chip => {
                    chip.addEventListener('contextmenu', (e) => showTagContextMenu(e, chip.dataset.tag));
                });
            }
        }
        renderTagLibrary();
    }

    async function bindToItem(item, index) {
        clearUntaggedPrompt();
        activeName = itemDisplayName(item);
        activeKey = await mediaKeyFor(item);
        let stored = (activeKey && mediaMeta[activeKey]) || null;
        // Fallback: same filename under a different size/key after re-export
        if (!stored || !(stored.tags && stored.tags.length)) {
            const byName = findStoredByName(activeName);
            if (byName?.meta) stored = byName.meta;
        }
        activeRating = Math.max(0, Math.min(5, parseInt(stored?.rating, 10) || 0));
        activeTags = sanitizeTagList(stored?.tags || []);

        // Harvest remote vocabulary only — never auto-apply file/catalog tags.
        // Auto-apply previously copied the same ©cmt AI prompt onto almost every clip.
        const id = await identityForItem(item);
        const remote = await fetchTagsForIdentity(id);
        if (remote) {
            const remoteTags = sanitizeTagList(remote.tags || []);
            ensureTagsKnown(remoteTags);
            // Rating-only import is safe (stars, not dump text)
            if (!activeRating && remote.rating) {
                activeRating = Math.max(0, Math.min(5, parseInt(remote.rating, 10) || 0));
            }
            await saveStore();
        }
        ensureTagsKnown(activeTags);
        // Re-persist scrubbed tags if sanitizer dropped corrupt entries
        if (activeKey && stored && JSON.stringify(activeTags) !== JSON.stringify(stored.tags || [])) {
            mediaMeta[activeKey] = {
                ...(mediaMeta[activeKey] || {}),
                rating: activeRating,
                tags: [...activeTags],
                name: activeName,
                updated: Date.now(),
            };
            await saveStore();
        }

        renderMetaPanel();
    }

    function onTagInputKeydown(e) {
        const visible = els.suggest && !els.suggest.hidden;
        const items = visible ? [...els.suggest.querySelectorAll('[data-tag]')] : [];
        if (e.key === 'ArrowDown' && items.length) {
            e.preventDefault();
            suggestIndex = (suggestIndex + 1) % items.length;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'ArrowUp' && items.length) {
            e.preventDefault();
            suggestIndex = suggestIndex <= 0 ? items.length - 1 : suggestIndex - 1;
            renderTagSuggestions(els.tagInput.value);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (suggestIndex >= 0 && items[suggestIndex]) pickSuggestion(items[suggestIndex].dataset.tag);
            else addTagsFromInput();
            return;
        }
        if (e.key === 'Escape') {
            hideSuggestions();
            els.tagInput?.blur();
            return;
        }
        if (e.key === 'Tab' && suggestIndex >= 0 && items[suggestIndex]) {
            e.preventDefault();
            pickSuggestion(items[suggestIndex].dataset.tag);
        }
    }

    function initTagLibraryResize() {
        const handle = $('meta-tag-resize');
        if (!handle || !els.library) return;

        applyTagLibraryHeight();

        const onMove = (clientY) => {
            if (!resizeDragging) return;
            const rect = els.library.getBoundingClientRect();
            const next = Math.round(clientY - rect.top);
            tagLibraryHeight = Math.max(80, Math.min(Math.round(window.innerHeight * 0.55), next));
            els.library.style.height = tagLibraryHeight + 'px';
        };

        const endDrag = () => {
            if (!resizeDragging) return;
            resizeDragging = false;
            handle.classList.remove('dragging');
            document.body.style.cursor = '';
            document.body.style.userSelect = '';
            // Persist height (and panel width if user used CSS resize)
            if (els.panel) {
                const w = els.panel.getBoundingClientRect().width;
                if (w >= 280) panelWidth = Math.round(w);
            }
            chrome.storage.local.set({
                fafoTagLibraryHeight: tagLibraryHeight,
                fafoMetaPanelWidth: panelWidth || undefined,
            }).catch(() => {});
        };

        handle.addEventListener('mousedown', (e) => {
            e.preventDefault();
            e.stopPropagation();
            resizeDragging = true;
            handle.classList.add('dragging');
            document.body.style.cursor = 'ns-resize';
            document.body.style.userSelect = 'none';
        });
        document.addEventListener('mousemove', (e) => {
            if (resizeDragging) onMove(e.clientY);
        });
        document.addEventListener('mouseup', endDrag);

        handle.addEventListener('touchstart', (e) => {
            if (!e.touches?.[0]) return;
            e.preventDefault();
            resizeDragging = true;
            handle.classList.add('dragging');
        }, { passive: false });
        document.addEventListener('touchmove', (e) => {
            if (resizeDragging && e.touches?.[0]) onMove(e.touches[0].clientY);
        }, { passive: true });
        document.addEventListener('touchend', endDrag);
    }

    function wireUI() {
        els = {
            toggle: $('meta-toggle'),
            panel: $('meta-panel'),
            filename: $('meta-filename'),
            status: $('meta-status'),
            stars: $('meta-stars'),
            currentTags: $('meta-current-tags'),
            tagInput: $('meta-tag-input'),
            tagAdd: $('meta-tag-add'),
            suggest: $('meta-tag-suggest'),
            library: $('meta-tag-library'),
            tagFilter: $('meta-tag-filter'),
            tagCount: $('meta-tag-count'),
            prev: $('meta-prev'),
            next: $('meta-next'),
            collapse: $('meta-collapse'),
            skipTagged: $('meta-skip-tagged'),
        };
        if (!els.toggle) return;

        els.toggle.addEventListener('click', () => setMetaPanelOpen(!metaPanelOpen));
        els.collapse?.addEventListener('click', () => setMetaPanelOpen(false));
        els.prev?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(-1));
        els.next?.addEventListener('click', () => window.FAFOPlayer?.skipTrack?.(1));
        els.tagAdd?.addEventListener('click', () => addTagsFromInput());
        els.tagInput?.addEventListener('keydown', onTagInputKeydown);
        els.tagInput?.addEventListener('input', () => {
            suggestIndex = -1;
            renderTagSuggestions(els.tagInput.value);
        });
        els.tagInput?.addEventListener('focus', () => renderTagSuggestions(els.tagInput.value));
        els.tagFilter?.addEventListener('input', () => renderTagLibrary());
        els.skipTagged?.addEventListener('click', () => setSkipTaggedMode(!skipTaggedMode));
        $('meta-count-mode')?.addEventListener('click', () => {
            setCountDisplayMode(countDisplayMode === 'total' ? 'session' : 'total');
        });

        initTagLibraryResize();
        updateSkipTaggedBtn();
        syncCountModeToggle();

        document.addEventListener('click', (e) => {
            if (els.suggest && !els.suggest.contains(e.target) && e.target !== els.tagInput) {
                hideSuggestions();
            }
            if (ctxMenu && !ctxMenu.contains(e.target)) hideCtxMenu();
        });

        // Live bank switching: hold Shift / Shift+Ctrl / Shift+Ctrl+Alt
        // to swap the 10 on-screen hotkey buttons in real time
        const onModKeys = (e) => {
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return;
            syncLiveBank(e);
        };
        document.addEventListener('keydown', onModKeys, true);
        document.addEventListener('keyup', onModKeys, true);
        window.addEventListener('blur', () => {
            liveBank = 0;
            renderHotkeyBar();
            updateBankIndicator();
        });

        document.addEventListener('keydown', (e) => {
            const t = e.target;
            const typing = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
            if (typing) return;

            // Keep live bank in sync even when we handle the key
            syncLiveBank(e);

            // Chord: ` / ~ then 1–9 / 0 applies hotkey (modifiers select bank)
            if (e.key === '`' || e.key === '~' || e.code === 'Backquote') {
                e.preventDefault();
                bracketChord = true;
                clearTimeout(bracketTimer);
                bracketTimer = setTimeout(() => { bracketChord = false; }, 2000);
                const bName = BANK_LABELS[liveBank] || 'Base';
                if (els.status) els.status.textContent = `Hotkey (${bName}): press 1–9 or 0…`;
                return;
            }

            const slot = digitToSlot(e.key);
            if (slot >= 0) {
                const bank = bankFromEvent(e);

                // ` chord + digit → apply that bank/slot
                if (bracketChord) {
                    e.preventDefault();
                    bracketChord = false;
                    clearTimeout(bracketTimer);
                    applyHotkeyTag(bank, slot);
                    return;
                }

                // Modifier banks: hold Shift (etc.) + digit to apply without backtick
                if (bank > 0) {
                    e.preventDefault();
                    applyHotkeyTag(bank, slot);
                    return;
                }

                // Base bank without chord: 1–5 rate when panel open; 0 clears rating
                if (metaPanelOpen && !bracketChord) {
                    if (slot <= 4) {
                        setRating(slot + 1);
                        return;
                    }
                    if (e.key === '0') {
                        setRating(0);
                        return;
                    }
                }
            }

            if (e.key === 't' || e.key === 'T') {
                e.preventDefault();
                setMetaPanelOpen(!metaPanelOpen);
                if (metaPanelOpen) setTimeout(() => els.tagInput?.focus(), 40);
            }
        });

        renderMetaPanel();
        renderHotkeyBar();
        updateBankIndicator();
    }

    async function init() {
        await loadStore();
        wireUI();
        harvestTagsFromServer().catch(() => {});
        const item = window.FAFOPlayer?.getCurrentItem?.();
        if (item) await bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
    }

    /** True when the current clip has no tags yet (rating alone does not count). */
    function isUntagged() {
        return !activeTags || activeTags.length === 0;
    }

    function notifyEndNeedsTag() {
        const dock = $('meta-dock');
        dock?.classList.add('untagged-prompt');
        setMetaPanelOpen(true);
        if (els.status) {
            els.status.textContent = 'End of clip — add at least one tag, then press Space / ▶ to continue';
        }
        if (els.toggle) els.toggle.title = 'Tag this media to continue (T)';
    }

    function clearUntaggedPrompt() {
        $('meta-dock')?.classList.remove('untagged-prompt');
        if (els.toggle) els.toggle.title = 'Rate & tag this media (T)';
    }

    window.FAFOMeta = {
        init,
        bindToItem,
        setMetaPanelOpen,
        open: () => setMetaPanelOpen(true),
        ensureTagsKnown,
        normalizeTag,
        sanitizeTagList,
        scrubAllStoredMeta,
        TAG_MAX_LEN,
        getTagLibrary: () => tagLibrary.slice(),
        getSessionTagCounts: () => ({ ...sessionTagCount }),
        getLibraryTagCounts: () => ({ ...libraryTagCount }),
        isSessionCountMode: () => countDisplayMode === 'session',
        getCountDisplayMode: () => countDisplayMode,
        setCountDisplayMode,
        isUntagged,
        /** @deprecated alias */
        needsTagging: isUntagged,
        notifyEndNeedsTag,
        clearUntaggedPrompt,
        getActiveTags: () => activeTags.slice(),
        getActiveRating: () => activeRating,
        isSkipTaggedMode,
        setSkipTaggedMode,
        tagCountForItem,
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => init());
    } else {
        // Player may still be initializing — retry bind shortly
        init().then(() => {
            setTimeout(() => {
                const item = window.FAFOPlayer?.getCurrentItem?.();
                if (item) bindToItem(item, window.FAFOPlayer.getCurrentIndex?.() || 0);
            }, 800);
        });
    }
})();
