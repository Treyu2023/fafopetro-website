/**
 * FAFO polish — status chips + small UX glue (stand-out pass E / PET-TAB-1).
 */
(function (global) {
  'use strict';

  function ensureChips() {
    let el = document.getElementById('fafo-status-chips');
    if (el) return el;
    el = document.createElement('div');
    el.id = 'fafo-status-chips';
    el.setAttribute('role', 'toolbar');
    el.setAttribute('aria-label', 'FAFO quick actions');
    el.innerHTML = `
      <button type="button" class="fafo-chip btn" data-act="cmd" data-fafo-tip="cmd.palette" title="Command palette (Ctrl+K or /)">Ctrl+K</button>
      <button type="button" class="fafo-chip btn" data-act="undo" data-fafo-tip="tag.undo" title="Undo last tag/rating (up to 50)">Back</button>
      <button type="button" class="fafo-chip btn" data-act="resume" data-fafo-tip="session.resume" title="Resume last session">Resume</button>
      <button type="button" class="fafo-chip btn" data-act="doctor" data-fafo-tip="lib.doctor" title="Library doctor">Doctor</button>
      <button type="button" class="fafo-chip btn" data-act="theme" id="fafo-chip-theme" data-fafo-tip="tag.themes" title="Cycle tag theme">Theme</button>
      <button type="button" class="fafo-chip btn" data-act="guide" title="F1 help for this screen. Shift+click for full guide.">Help</button>
    `;
    document.body.appendChild(el);
    el.querySelectorAll('[data-act]').forEach((btn) => {
      btn.addEventListener('click', (ev) => {
        const a = btn.getAttribute('data-act');
        if (a === 'cmd') global.FAFOCommandPalette?.open?.();
        if (a === 'undo') global.FAFOUndo?.undo?.();
        if (a === 'resume') global.FAFOSession?.resumeNow?.();
        if (a === 'doctor') global.FAFOLibraryDoctor?.open?.();
        if (a === 'guide') {
          if (ev.shiftKey) {
            global.FAFOHelp?.summon?.({ all: true }) || global.FAFOKnowledge?.openGuide?.();
          } else {
            global.FAFOHelp?.summon?.() || global.FAFOKnowledge?.openGuide?.();
          }
        }
        if (a === 'theme') {
          const p = global.FAFOTagThemes?.cycle?.();
          refreshThemeChip();
          if (p?.name) {
            try { global.FAFOUndo?.showToast?.('Theme: ' + p.name); } catch (_) {}
          }
        }
      });
    });
    try { global.FAFOKnowledge?.applyTooltips?.(el); } catch (_) {}
    return el;
  }

  function refreshThemeChip() {
    const t = document.getElementById('fafo-chip-theme');
    const p = global.FAFOTagThemes?.current?.();
    if (t && p) t.textContent = p.name || 'Theme';
  }

  function patchHelp() {
    const panel = document.querySelector('#shortcut-help .shortcut-panel');
    if (!panel || panel.dataset.polishHelp) return;
    panel.dataset.polishHelp = '1';
    const extra = document.createElement('div');
    extra.className = 'fafo-polish-help-extra';
    extra.innerHTML = `
      <p style="margin-top:10px;border-top:1px solid color-mix(in srgb, var(--border, #333) 80%, transparent);padding-top:8px;"><kbd>Ctrl</kbd>+<kbd>K</kbd> or <kbd>/</kbd> Command palette</p>
      <p><kbd>Ctrl</kbd>+<kbd>Z</kbd> or <strong>Back</strong> — undo last 50 tag/rating changes</p>
      <p><strong>Select</strong> / <kbd>Ctrl</kbd>+click tags — multi-edit · <strong>All</strong> = visible</p>
      <p><kbd>Ctrl</kbd>+<kbd>K</kbd> → <strong>Show Up next strip</strong> if you hid the previews</p>
      <p>Top chips: Resume · Doctor · Theme · Help (Shift+Help = full guide)</p>
      <p>Corner <strong>Disk</strong> LED — file-tag server · Bottom: <strong>Up next</strong> strip</p>
    `;
    panel.insertBefore(extra, panel.querySelector('#help-close'));
  }

  function closeCornerMenu() {
    const menu = document.getElementById('fafo-corner-menu');
    const btn = document.getElementById('fafo-menu-btn');
    if (menu) menu.hidden = true;
    if (btn) btn.setAttribute('aria-expanded', 'false');
  }

  function runMenuAct(act, ev) {
    if (act === 'cmd') global.FAFOCommandPalette?.open?.();
    if (act === 'undo') global.FAFOUndo?.undo?.();
    if (act === 'resume') global.FAFOSession?.resumeNow?.();
    if (act === 'doctor') global.FAFOLibraryDoctor?.open?.();
    if (act === 'help') document.getElementById('shortcut-help')?.classList.toggle('hidden');
    if (act === 'guide') global.FAFOHelp?.summon?.() || global.FAFOKnowledge?.openGuide?.();
    if (act === 'guide-all') global.FAFOHelp?.summon?.({ all: true }) || global.FAFOKnowledge?.openGuide?.();
    if (act === 'theme') {
      const p = global.FAFOTagThemes?.cycle?.();
      refreshThemeChip();
      if (p?.name) {
        try { global.FAFOUndo?.showToast?.('Theme: ' + p.name); } catch (_) {}
      }
    }
    closeCornerMenu();
    if (ev && act !== 'options') ev.preventDefault();
  }

  function bindCornerMenu() {
    const btn = document.getElementById('fafo-menu-btn');
    const menu = document.getElementById('fafo-corner-menu');
    if (!btn || !menu || btn.dataset.bound) return;
    btn.dataset.bound = '1';
    btn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const open = menu.hidden;
      menu.hidden = !open;
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) menu.querySelector('[role="menuitem"]')?.focus?.();
    });
    menu.querySelectorAll('[data-menu]').forEach((item) => {
      item.addEventListener('click', (ev) => runMenuAct(item.getAttribute('data-menu'), ev));
    });
    document.addEventListener('click', (ev) => {
      if (!menu.hidden && !ev.target.closest?.('#fafo-corner')) closeCornerMenu();
    });
    document.addEventListener('keydown', (ev) => {
      if (ev.key === 'Escape') closeCornerMenu();
    });
  }

  function init() {
    ensureChips();
    bindCornerMenu();
    refreshThemeChip();
    setTimeout(patchHelp, 800);
    document.addEventListener('fafo:tag-theme', refreshThemeChip);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  global.FAFOPolish = { refreshThemeChip, refreshS2: function () { /* Disk LED owns S2 status */ } };
})(typeof window !== 'undefined' ? window : globalThis);
