/**
 * FAFO multi private-vault registry + PIN security.
 *
 * Security model:
 * - Each vault has its own PIN (hashed + salted). Forgot vault PIN ⇒ locked forever
 *   unless the admin Master PIN can override THAT vault.
 * - Changing a vault PIN always requires the current vault PIN (or master, if eligible).
 * - Master PIN is optional admin override, set in Options.
 * - Master establishedAt is IMMUTABLE (first set only). Rotating the master PIN
 *   never moves establishedAt.
 * - Master may unlock / change PIN only for vaults with createdAt >= master.establishedAt.
 *   Vaults created before the master was set cannot be back-doored by adding/changing master later.
 *
 * Storage key: fafoPrivateVaults (v2). Migrates legacy fafoPrivateVault → default vault.
 */
(function (global) {
    'use strict';

    const REGISTRY_KEY = 'fafoPrivateVaults';
    const LEGACY_KEY = 'fafoPrivateVault';
    const MIN_PIN = 4;
    const DEFAULT_VAULT_ID = 'default';

    /** Fixed public storage keys (unchanged). */
    const PUBLIC_KEYS = {
        mediaMeta: 'fafoMediaMeta',
        tagLibrary: 'fafoTagLibrary',
        tagLastUsed: 'fafoTagLastUsed',
        tagHotkeys: 'fafoTagHotkeys',
        tagExcluded: 'fafoTagExcluded',
        tagMenuScope: 'fafoTagMenuScope',
        recentTags: 'fafoRecentTags',
        applyCounts: 'fafoTagApplyCounts',
        extraBanks: 'fafoExtraTagBanks',
        sprintTags: 'fafoSprintTags',
        pairs: 'fafoPairs',
        tagColors: 'fafoTagColors',
        /** Opaque encrypted tag vocabulary (FAFOTagDb) */
        tagDb: 'fafoTagDb',
    };

    /** Legacy single private vault keys (id === default). */
    const LEGACY_PRIVATE_KEYS = {
        mediaMeta: 'fafoMediaMetaPrivate',
        tagLibrary: 'fafoTagLibraryPrivate',
        tagLastUsed: 'fafoTagLastUsedPrivate',
        tagHotkeys: 'fafoTagHotkeysPrivate',
        tagExcluded: 'fafoTagExcludedPrivate',
        tagMenuScope: 'fafoTagMenuScopePrivate',
        recentTags: 'fafoRecentTagsPrivate',
        applyCounts: 'fafoTagApplyCountsPrivate',
        extraBanks: 'fafoExtraTagBanksPrivate',
        sprintTags: 'fafoSprintTagsPrivate',
        pairs: 'fafoPairsPrivate',
        tagColors: 'fafoTagColorsPrivate',
        tagDb: 'fafoTagDbPrivate',
    };

    function emptyMaster() {
        return {
            pinHash: '',
            pinSalt: '',
            establishedAt: null,
            updatedAt: null,
        };
    }

    function emptyRegistry() {
        return {
            v: 2,
            master: emptyMaster(),
            vaults: [],
        };
    }

    function safeVaultId(id) {
        return String(id || '')
            .replace(/[^a-zA-Z0-9_-]/g, '')
            .slice(0, 40);
    }

    function newVaultId() {
        return 'v_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 8);
    }

    function randomSalt() {
        const a = new Uint8Array(16);
        crypto.getRandomValues(a);
        return Array.from(a)
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
    }

    async function sha256Hex(str) {
        const data = new TextEncoder().encode(str);
        const buf = await crypto.subtle.digest('SHA-256', data);
        return Array.from(new Uint8Array(buf))
            .map((b) => b.toString(16).padStart(2, '0'))
            .join('');
    }

    async function hashPin(pin, salt) {
        return sha256Hex(`${salt}::${String(pin || '')}`);
    }

    function validatePin(pin) {
        const p = String(pin || '').trim();
        if (p.length < MIN_PIN) {
            return { ok: false, error: `PIN must be at least ${MIN_PIN} characters` };
        }
        return { ok: true, pin: p };
    }

    /** Storage key map for a private vault id. Default keeps legacy unsuffixed Private keys. */
    function privateStorageKeys(vaultId) {
        const id = safeVaultId(vaultId) || DEFAULT_VAULT_ID;
        if (id === DEFAULT_VAULT_ID) {
            return { ...LEGACY_PRIVATE_KEYS };
        }
        const suf = `Private_${id}`;
        return {
            mediaMeta: `fafoMediaMeta${suf}`,
            tagLibrary: `fafoTagLibrary${suf}`,
            tagLastUsed: `fafoTagLastUsed${suf}`,
            tagHotkeys: `fafoTagHotkeys${suf}`,
            tagExcluded: `fafoTagExcluded${suf}`,
            tagMenuScope: `fafoTagMenuScope${suf}`,
            recentTags: `fafoRecentTags${suf}`,
            applyCounts: `fafoTagApplyCounts${suf}`,
            extraBanks: `fafoExtraTagBanks${suf}`,
            sprintTags: `fafoSprintTags${suf}`,
            pairs: `fafoPairs${suf}`,
            tagColors: `fafoTagColors${suf}`,
            tagDb: `fafoTagDb${suf}`,
        };
    }

    function publicStorageKeys() {
        return { ...PUBLIC_KEYS };
    }

    function spaceStorageKeys(privateActive, vaultId) {
        if (!privateActive) return publicStorageKeys();
        return privateStorageKeys(vaultId || DEFAULT_VAULT_ID);
    }

    /** True if key belongs to any private vault storage. */
    function isPrivateStorageKey(key) {
        const k = String(key || '');
        if (!k) return false;
        if (Object.values(LEGACY_PRIVATE_KEYS).includes(k)) return true;
        return /Private(_|$)/i.test(k) || /Private_/i.test(k);
    }

    function listPrivateKeyNames(registry) {
        const set = new Set(Object.values(LEGACY_PRIVATE_KEYS));
        (registry?.vaults || []).forEach((v) => {
            Object.values(privateStorageKeys(v.id)).forEach((k) => set.add(k));
        });
        return [...set];
    }

    function sanitizeVault(raw) {
        if (!raw || typeof raw !== 'object') return null;
        const id = safeVaultId(raw.id) || newVaultId();
        const name = String(raw.name || 'Private').trim().slice(0, 48) || 'Private';
        const createdAt = Number(raw.createdAt);
        return {
            id,
            name,
            pinHash: String(raw.pinHash || ''),
            pinSalt: String(raw.pinSalt || ''),
            createdAt: Number.isFinite(createdAt) && createdAt > 0 ? createdAt : Date.now(),
        };
    }

    function sanitizeMaster(raw) {
        const m = emptyMaster();
        if (!raw || typeof raw !== 'object') return m;
        m.pinHash = String(raw.pinHash || '');
        m.pinSalt = String(raw.pinSalt || '');
        const est = Number(raw.establishedAt);
        m.establishedAt = Number.isFinite(est) && est > 0 ? est : null;
        const upd = Number(raw.updatedAt);
        m.updatedAt = Number.isFinite(upd) && upd > 0 ? upd : null;
        // Integrity: hash without establishedAt → treat as not set
        if (!m.pinHash || !m.pinSalt) {
            m.pinHash = '';
            m.pinSalt = '';
            m.establishedAt = null;
        }
        return m;
    }

    function sanitizeRegistry(raw) {
        const reg = emptyRegistry();
        if (!raw || typeof raw !== 'object') return reg;
        reg.v = 2;
        reg.master = sanitizeMaster(raw.master);
        reg.vaults = Array.isArray(raw.vaults)
            ? raw.vaults.map(sanitizeVault).filter(Boolean)
            : [];
        return reg;
    }

    async function loadRegistry() {
        const bag = await chrome.storage.local.get([REGISTRY_KEY, LEGACY_KEY]);
        let reg = sanitizeRegistry(bag[REGISTRY_KEY]);

        // Migrate legacy single vault → default vault (createdAt in past so master can't backdoor it)
        const legacy = bag[LEGACY_KEY];
        if ((!reg.vaults || !reg.vaults.length) && legacy && typeof legacy === 'object') {
            const pinHash = String(legacy.pinHash || '');
            const pinSalt = String(legacy.salt || legacy.pinSalt || '');
            if (pinHash && pinSalt) {
                reg.vaults = [
                    {
                        id: DEFAULT_VAULT_ID,
                        name: 'Private',
                        pinHash,
                        pinSalt,
                        // Pre-date any future master so override cannot apply retroactively
                        createdAt: 1,
                    },
                ];
                await saveRegistry(reg);
            }
        }
        return reg;
    }

    async function saveRegistry(reg) {
        const clean = sanitizeRegistry(reg);
        await chrome.storage.local.set({ [REGISTRY_KEY]: clean });
        return clean;
    }

    function findVault(reg, vaultId) {
        const id = safeVaultId(vaultId) || DEFAULT_VAULT_ID;
        return (reg.vaults || []).find((v) => v.id === id) || null;
    }

    function hasMaster(reg) {
        return !!(reg?.master?.pinHash && reg?.master?.pinSalt && reg?.master?.establishedAt);
    }

    function hasVaultPin(vault) {
        return !!(vault?.pinHash && vault?.pinSalt);
    }

    /**
     * Master may override this vault only if vault was created at or after master was first established.
     * Vaults that predate master.establishedAt are permanent non-override (no backdoor).
     */
    function masterCanOverrideVault(reg, vault) {
        if (!hasMaster(reg) || !vault) return false;
        const est = Number(reg.master.establishedAt);
        const created = Number(vault.createdAt);
        if (!Number.isFinite(est) || !Number.isFinite(created)) return false;
        return created >= est;
    }

    async function verifyVaultPin(vault, pin) {
        if (!hasVaultPin(vault)) return false;
        const h = await hashPin(String(pin || '').trim(), vault.pinSalt);
        return h === vault.pinHash;
    }

    async function verifyMasterPin(reg, pin) {
        if (!hasMaster(reg)) return false;
        const h = await hashPin(String(pin || '').trim(), reg.master.pinSalt);
        return h === reg.master.pinHash;
    }

    /** Public-safe vault list for UI (no hashes). */
    function vaultSummaries(reg) {
        return (reg.vaults || []).map((v) => ({
            id: v.id,
            name: v.name,
            createdAt: v.createdAt,
            hasPin: hasVaultPin(v),
            masterEligible: masterCanOverrideVault(reg, v),
        }));
    }

    function masterSummary(reg) {
        return {
            hasMaster: hasMaster(reg),
            establishedAt: reg.master?.establishedAt || null,
            updatedAt: reg.master?.updatedAt || null,
        };
    }

    /**
     * Create a new private vault with PIN.
     * createdAt = now ⇒ master (if already established) can override this vault.
     * If master is set later, this vault remains eligible only if createdAt >= that establishedAt
     * (so create after master → eligible; create before master → not eligible).
     */
    async function createVault({ name, pin }) {
        const check = validatePin(pin);
        if (!check.ok) return { ok: false, error: check.error };
        const reg = await loadRegistry();
        const label = String(name || '').trim().slice(0, 48) || `Private ${(reg.vaults.length || 0) + 1}`;
        // Prefer default id for first vault so legacy storage keys are reused
        let id = reg.vaults.length === 0 ? DEFAULT_VAULT_ID : newVaultId();
        if (findVault(reg, id)) id = newVaultId();
        const salt = randomSalt();
        const pinHash = await hashPin(check.pin, salt);
        const vault = {
            id,
            name: label,
            pinHash,
            pinSalt: salt,
            createdAt: Date.now(),
        };
        reg.vaults.push(vault);
        await saveRegistry(reg);
        return { ok: true, vault: { id: vault.id, name: vault.name, createdAt: vault.createdAt } };
    }

    /**
     * Change vault PIN.
     * auth: { vaultPin } OR { masterPin } (master only if eligible).
     * Cannot use master on pre-master vaults.
     */
    async function changeVaultPin(vaultId, { newPin, vaultPin, masterPin }) {
        const check = validatePin(newPin);
        if (!check.ok) return { ok: false, error: check.error };
        const reg = await loadRegistry();
        const vault = findVault(reg, vaultId);
        if (!vault) return { ok: false, error: 'Vault not found' };

        let authorized = false;
        let via = '';
        if (vaultPin != null && String(vaultPin).length) {
            if (await verifyVaultPin(vault, vaultPin)) {
                authorized = true;
                via = 'vault';
            } else {
                return { ok: false, error: 'Current vault PIN is wrong' };
            }
        } else if (masterPin != null && String(masterPin).length) {
            if (!(await verifyMasterPin(reg, masterPin))) {
                return { ok: false, error: 'Master PIN is wrong' };
            }
            if (!masterCanOverrideVault(reg, vault)) {
                return {
                    ok: false,
                    error:
                        'Master cannot change this vault — it was created before the master PIN was established (no backdoor)',
                };
            }
            authorized = true;
            via = 'master';
        } else {
            return { ok: false, error: 'Enter the current vault PIN (or eligible master PIN)' };
        }
        if (!authorized) return { ok: false, error: 'Not authorized' };

        const salt = randomSalt();
        vault.pinHash = await hashPin(check.pin, salt);
        vault.pinSalt = salt;
        // createdAt stays forever — never rewrite eligibility clock
        await saveRegistry(reg);
        return { ok: true, via };
    }

    /**
     * Set master PIN the first time. Sets establishedAt once (immutable thereafter).
     */
    async function setMasterPin(pin) {
        const check = validatePin(pin);
        if (!check.ok) return { ok: false, error: check.error };
        const reg = await loadRegistry();
        if (hasMaster(reg)) {
            return { ok: false, error: 'Master PIN already set — use changeMasterPin with current master' };
        }
        const salt = randomSalt();
        const now = Date.now();
        reg.master = {
            pinHash: await hashPin(check.pin, salt),
            pinSalt: salt,
            establishedAt: now,
            updatedAt: now,
        };
        await saveRegistry(reg);
        return {
            ok: true,
            establishedAt: now,
            note:
                'Master only overrides vaults created from this moment on. Older vaults stay vault-PIN-only forever.',
        };
    }

    /**
     * Rotate master PIN. Requires current master. Does NOT change establishedAt
     * (cannot expand override to older vaults by rotating master).
     */
    async function changeMasterPin({ currentPin, newPin }) {
        const check = validatePin(newPin);
        if (!check.ok) return { ok: false, error: check.error };
        const reg = await loadRegistry();
        if (!hasMaster(reg)) {
            return { ok: false, error: 'No master PIN yet — use setMasterPin first' };
        }
        if (!(await verifyMasterPin(reg, currentPin))) {
            return { ok: false, error: 'Current master PIN is wrong' };
        }
        const salt = randomSalt();
        const now = Date.now();
        reg.master.pinHash = await hashPin(check.pin, salt);
        reg.master.pinSalt = salt;
        reg.master.updatedAt = now;
        // establishedAt intentionally unchanged
        await saveRegistry(reg);
        return { ok: true, establishedAt: reg.master.establishedAt, updatedAt: now };
    }

    /**
     * Unlock authorization for a vault.
     * Returns { ok, via: 'vault'|'master', vaultId } or error.
     * Master path only if vault is master-eligible.
     */
    async function authorizeVaultAccess(vaultId, { pin, useMaster }) {
        const reg = await loadRegistry();
        const vault = findVault(reg, vaultId);
        if (!vault) return { ok: false, error: 'Vault not found' };
        if (!hasVaultPin(vault) && !useMaster) {
            return { ok: false, error: 'Vault has no PIN — set one in Options' };
        }
        const p = String(pin || '').trim();
        if (!p) return { ok: false, error: 'Enter PIN' };

        if (useMaster) {
            if (!(await verifyMasterPin(reg, p))) {
                return { ok: false, error: 'Master PIN is wrong' };
            }
            if (!masterCanOverrideVault(reg, vault)) {
                return {
                    ok: false,
                    error:
                        'Master cannot open this vault — it was created before the master PIN (no backdoor)',
                };
            }
            return { ok: true, via: 'master', vaultId: vault.id, vaultName: vault.name };
        }

        if (await verifyVaultPin(vault, p)) {
            return { ok: true, via: 'vault', vaultId: vault.id, vaultName: vault.name };
        }
        return { ok: false, error: 'Wrong PIN' };
    }

    /** Rename vault (no PIN required — name is not secret). */
    async function renameVault(vaultId, name) {
        const reg = await loadRegistry();
        const vault = findVault(reg, vaultId);
        if (!vault) return { ok: false, error: 'Vault not found' };
        vault.name = String(name || '').trim().slice(0, 48) || vault.name;
        await saveRegistry(reg);
        return { ok: true, name: vault.name };
    }

    /**
     * Ensure at least one vault exists when user wants private mode with no registry yet.
     * Does not set a PIN — setup flow still required.
     */
    async function ensureDefaultVaultShell(name) {
        const reg = await loadRegistry();
        if (reg.vaults.length) return { ok: true, vault: reg.vaults[0], created: false };
        const id = DEFAULT_VAULT_ID;
        const vault = {
            id,
            name: String(name || 'Private').trim().slice(0, 48) || 'Private',
            pinHash: '',
            pinSalt: '',
            createdAt: Date.now(),
        };
        reg.vaults.push(vault);
        await saveRegistry(reg);
        return { ok: true, vault, created: true };
    }

    /**
     * First-time set PIN on a vault that has none (setup).
     * Uses createdAt already on the vault (do not move it).
     */
    async function setVaultPinInitial(vaultId, pin) {
        const check = validatePin(pin);
        if (!check.ok) return { ok: false, error: check.error };
        const reg = await loadRegistry();
        const vault = findVault(reg, vaultId);
        if (!vault) return { ok: false, error: 'Vault not found' };
        if (hasVaultPin(vault)) {
            return { ok: false, error: 'Vault already has a PIN — use changeVaultPin' };
        }
        const salt = randomSalt();
        vault.pinHash = await hashPin(check.pin, salt);
        vault.pinSalt = salt;
        await saveRegistry(reg);
        return { ok: true, vaultId: vault.id };
    }

    global.FAFOPrivateVaults = {
        REGISTRY_KEY,
        LEGACY_KEY,
        DEFAULT_VAULT_ID,
        MIN_PIN,
        publicStorageKeys,
        privateStorageKeys,
        spaceStorageKeys,
        isPrivateStorageKey,
        listPrivateKeyNames,
        loadRegistry,
        saveRegistry,
        findVault,
        hasMaster,
        hasVaultPin,
        masterCanOverrideVault,
        vaultSummaries,
        masterSummary,
        createVault,
        changeVaultPin,
        setMasterPin,
        changeMasterPin,
        authorizeVaultAccess,
        renameVault,
        ensureDefaultVaultShell,
        setVaultPinInitial,
        verifyVaultPin,
        verifyMasterPin,
        validatePin,
        hashPin,
        randomSalt,
    };
})(typeof window !== 'undefined' ? window : globalThis);
