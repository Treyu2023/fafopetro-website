/**
 * FAFO Particle FX Engine v2 — layered depth, trails, splashes, accent-synced bokeh.
 */
class ParticleFXEngine {
    constructor(canvas, getConfig) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d', { alpha: true, desynchronized: true });
        this.getConfig = getConfig;
        this.particles = [];
        this.splashes = [];
        this.wind = 0;
        this.windTarget = 0;
        this.rafId = null;
        this.lastTime = 0;
        this.frameCounter = 0;
        this.performanceMode = false;
        this.renderScale = 1;
        this.accentRgb = { r: 0, g: 229, b: 255 };
        this._resize = () => {
            this.applyCanvasSize();
            this.rebuild();
        };
    }

    setPerformanceMode(active) {
        this.performanceMode = !!active;
        this.applyCanvasSize();
    }

    applyCanvasSize() {
        if (!this.canvas) return;
        const scale = this.performanceMode ? 0.55 : Math.min(1, 0.85);
        this.renderScale = scale;
        this.canvas.width = Math.floor(innerWidth * scale);
        this.canvas.height = Math.floor(innerHeight * scale);
        this.canvas.style.width = '100%';
        this.canvas.style.height = '100%';
        if (this.ctx) this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    }

    capDensity(requested, totalRequested) {
        const maxTotal = this.performanceMode ? 70 : 130;
        if (totalRequested <= maxTotal) return requested;
        return Math.max(3, Math.floor(requested * maxTotal / totalRequested));
    }

    rand(min, max) { return min + Math.random() * (max - min); }

    parseAccent(hex) {
        const s = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex || '#00e5ff');
        if (!s) return { r: 0, g: 229, b: 255 };
        return { r: parseInt(s[1], 16), g: parseInt(s[2], 16), b: parseInt(s[3], 16) };
    }

    cfgVal(prefix, attr, fallback) {
        const cfg = this.getConfig();
        const key = `${prefix}${attr.charAt(0).toUpperCase()}${attr.slice(1)}`;
        return cfg[key] ?? fallback;
    }

    isActive() {
        const c = this.getConfig();
        return c.fxSnow || c.fxRain || c.fxEmbers || c.fxSmoke || c.fxSparks || c.fxNeon;
    }

    start() {
        this.stop();
        if (!this.canvas) return;
        this._resize();
        window.addEventListener('resize', this._resize);
        this.rebuild();
        const loop = (t) => {
            this.frameCounter++;
            if (this.performanceMode && this.frameCounter % 2 !== 0) {
                this.rafId = requestAnimationFrame(loop);
                return;
            }
            const dt = Math.min(0.05, (t - this.lastTime) / 1000 || 0.016);
            this.lastTime = t;
            this.tick(dt, t * 0.001);
            this.rafId = requestAnimationFrame(loop);
        };
        this.rafId = requestAnimationFrame(loop);
    }

    stop() {
        if (this.rafId) cancelAnimationFrame(this.rafId);
        this.rafId = null;
        window.removeEventListener('resize', this._resize);
    }

    destroy() {
        this.stop();
        this.particles = [];
        this.splashes = [];
        if (this.ctx) this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }

    rebuild() {
        const cfg = this.getConfig();
        this.accentRgb = this.parseAccent(cfg.accentColor);
        this.particles = [];
        this.splashes = [];
        const w = innerWidth;
        const h = innerHeight;
        const totals = [];
        if (cfg.fxSnow) totals.push(cfg.fxSnowDensity || 50);
        if (cfg.fxRain) totals.push(cfg.fxRainDensity || 100);
        if (cfg.fxEmbers) totals.push(cfg.fxEmbersDensity || 60);
        if (cfg.fxSmoke) totals.push(cfg.fxSmokeDensity || 30);
        if (cfg.fxSparks) totals.push(cfg.fxSparksDensity || 40);
        if (cfg.fxNeon) totals.push(cfg.fxNeonDensity || 20);
        const totalRequested = totals.reduce((a, b) => a + b, 0) || 1;
        const push = (n, factory) => {
            const count = this.capDensity(n, totalRequested);
            for (let i = 0; i < count; i++) this.particles.push(factory(i, count, w, h));
        };

        if (cfg.fxSnow) {
            const d = cfg.fxSnowDensity || 50;
            push(d, (i, c, W, H) => this.spawnSnow(W, H, i / c));
        }
        if (cfg.fxRain) {
            const d = cfg.fxRainDensity || 100;
            push(d, (i, c, W, H) => this.spawnRain(W, H, i / c));
        }
        if (cfg.fxEmbers) {
            const d = cfg.fxEmbersDensity || 60;
            push(d, (i, c, W, H) => this.spawnEmber(W, H));
        }
        if (cfg.fxSmoke) {
            const d = cfg.fxSmokeDensity || 30;
            push(d, (i, c, W, H) => this.spawnSmoke(W, H));
        }
        if (cfg.fxSparks) {
            const d = cfg.fxSparksDensity || 40;
            push(d, (i, c, W, H) => this.spawnSpark(W, H));
        }
        if (cfg.fxNeon) {
            const d = cfg.fxNeonDensity || 20;
            push(d, (i, c, W, H) => this.spawnNeon(W, H, i));
        }
        this.particles.sort((a, b) => (a.layer ?? 0) - (b.layer ?? 0));
    }

    spawnSnow(W, H, depth) {
        const sizeBase = this.cfgVal('fxSnow', 'size', 3);
        const speedBase = this.cfgVal('fxSnow', 'speed', 1);
        const layer = depth < 0.33 ? 0 : depth < 0.66 ? 1 : 2;
        const scale = [0.5, 1, 1.6][layer];
        return {
            type: 'snow', layer,
            x: Math.random() * W,
            y: Math.random() * H,
            size: this.rand(sizeBase * 0.4, sizeBase * 0.9) * scale,
            speed: this.rand(speedBase * 0.4, speedBase) * scale * 0.6,
            drift: this.rand(-0.8, 0.8),
            rot: Math.random() * Math.PI,
            spin: this.rand(-0.02, 0.02),
            alpha: this.rand(0.35, 0.95) * (layer === 2 ? 1 : 0.7),
            wobble: Math.random() * 100
        };
    }

    spawnRain(W, H, depth) {
        const lenBase = this.cfgVal('fxRain', 'size', 20);
        const speedBase = this.cfgVal('fxRain', 'speed', 15);
        const layer = depth < 0.4 ? 0 : depth < 0.7 ? 1 : 2;
        const scale = [0.6, 1, 1.3][layer];
        return {
            type: 'rain', layer,
            x: Math.random() * W,
            y: Math.random() * H - H * 0.2,
            len: this.rand(lenBase * 0.5, lenBase) * scale,
            speed: this.rand(speedBase * 0.6, speedBase + 10) * scale,
            width: layer === 2 ? 2.2 : layer === 1 ? 1.5 : 0.8,
            alpha: [0.25, 0.45, 0.7][layer]
        };
    }

    spawnEmber(W, H) {
        const sizeBase = this.cfgVal('fxEmbers', 'size', 3);
        const speedBase = this.cfgVal('fxEmbers', 'speed', 2);
        return {
            type: 'ember',
            x: Math.random() * W,
            y: H + this.rand(0, 80),
            size: this.rand(sizeBase * 0.5, sizeBase + 2),
            speed: this.rand(speedBase * 0.5, speedBase + 1.5),
            drift: this.rand(-1.2, 1.2),
            life: this.rand(0.6, 1),
            maxLife: 1,
            heat: this.rand(0.7, 1),
            trail: [],
            offset: Math.random() * 100,
            flicker: Math.random()
        };
    }

    spawnSmoke(W, H) {
        const sizeBase = this.cfgVal('fxSmoke', 'size', 10);
        const speedBase = this.cfgVal('fxSmoke', 'speed', 1);
        return {
            type: 'smoke',
            x: Math.random() * W,
            y: H + this.rand(0, 60),
            size: this.rand(sizeBase * 0.6, sizeBase + 12),
            speed: this.rand(speedBase * 0.3, speedBase + 0.4),
            drift: this.rand(-0.6, 0.6),
            life: this.rand(0.7, 1),
            maxLife: 1,
            offset: Math.random() * 200,
            hue: this.rand(0, 30)
        };
    }

    spawnSpark(W, H) {
        const sizeBase = this.cfgVal('fxSparks', 'size', 2);
        const speedBase = this.cfgVal('fxSparks', 'speed', 3);
        const angle = this.rand(-Math.PI * 0.85, -Math.PI * 0.15);
        const vel = this.rand(speedBase * 2, speedBase * 6);
        return {
            type: 'spark',
            x: Math.random() * W,
            y: H + this.rand(0, 20),
            vx: Math.cos(angle) * vel * 0.4,
            vy: Math.sin(angle) * vel,
            size: this.rand(sizeBase * 0.5, sizeBase + 1),
            life: this.rand(0.5, 1),
            maxLife: 1,
            trail: []
        };
    }

    spawnNeon(W, H, i) {
        const sizeBase = this.cfgVal('fxNeon', 'size', 5);
        const speedBase = this.cfgVal('fxNeon', 'speed', 1);
        const { r, g, b } = this.accentRgb;
        const hueShift = this.rand(-25, 25);
        return {
            type: 'neon',
            x: Math.random() * W,
            y: Math.random() * H,
            size: this.rand(sizeBase * 0.5, sizeBase + 4),
            speed: this.rand(speedBase * 0.2, speedBase + 0.5),
            angle: Math.random() * Math.PI * 2,
            pulse: Math.random() * Math.PI * 2,
            r, g, b, hueShift,
            ring: i % 4 === 0
        };
    }

    resetSnow(p, W, H) {
        Object.assign(p, this.spawnSnow(W, H, Math.random()));
        p.y = -10;
    }

    resetRain(p, W, H) {
        Object.assign(p, this.spawnRain(W, H, Math.random()));
        p.y = -p.len - 10;
    }

    tick(dt, time) {
        const cfg = this.getConfig();
        if (!this.isActive()) {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
            return;
        }

        this.accentRgb = this.parseAccent(cfg.accentColor);
        const scale = this.renderScale;
        const W = innerWidth;
        const H = innerHeight;
        const cW = this.canvas.width;
        const cH = this.canvas.height;
        const ctx = this.ctx;

        this.windTarget = Math.sin(time * 0.3) * 1.8 + Math.sin(time * 0.07) * 0.8;
        this.wind += (this.windTarget - this.wind) * dt * 2;

        ctx.setTransform(scale, 0, 0, scale, 0, 0);
        if (cfg.fxSmoke) {
            ctx.fillStyle = this.performanceMode ? 'rgba(5, 5, 8, 0.18)' : 'rgba(5, 5, 8, 0.12)';
            ctx.fillRect(0, 0, W, H);
        } else {
            ctx.clearRect(0, 0, cW, cH);
        }

        this.updateSplashes(dt);

        for (const p of this.particles) {
            this.updateParticle(p, dt, time, W, H, cfg);
        }

        const skipBlur = this.performanceMode;
        const typeOrder = ['smoke', 'snow', 'rain', 'ember', 'spark', 'neon'];
        for (const type of typeOrder) {
            for (const p of this.particles) {
                if (p.type === type) this.drawParticle(p, cfg, skipBlur);
            }
        }

        this.drawSplashes(cfg);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
    }

    updateSplashes(dt) {
        for (let i = this.splashes.length - 1; i >= 0; i--) {
            const s = this.splashes[i];
            s.life -= dt * 3;
            s.r += dt * 18;
            if (s.life <= 0) this.splashes.splice(i, 1);
        }
    }

    addSplash(x, cfg) {
        if (this.splashes.length > 40) this.splashes.shift();
        const { r, g, b } = this.accentRgb;
        this.splashes.push({ x, y: innerHeight - 2, r: 2, life: 1, cr: r, cg: g, cb: b });
    }

    updateParticle(p, dt, time, W, H, cfg) {
        const wind = this.wind;

        switch (p.type) {
            case 'snow': {
                p.y += p.speed * 60 * dt;
                p.x += (p.drift + wind * (p.layer === 2 ? 1.2 : p.layer === 1 ? 0.7 : 0.35)) * 40 * dt;
                p.x += Math.sin(time * 1.2 + p.wobble) * 0.4;
                p.rot += p.spin;
                if (p.y > H + 10) this.resetSnow(p, W, H);
                break;
            }
            case 'rain': {
                const angle = 0.12 + wind * 0.04;
                p.y += p.speed * 80 * dt;
                p.x += (wind * 30 + Math.sin(time + p.x) * 0.2) * dt * 60;
                p._angle = angle;
                if (p.y > H + 20) {
                    if (!this.performanceMode && p.layer === 2 && Math.random() < 0.08) this.addSplash(p.x, cfg);
                    this.resetRain(p, W, H);
                }
                break;
            }
            case 'ember': {
                p.y -= p.speed * 45 * dt;
                p.x += Math.sin(time * 2 + p.offset) * 1.2 + p.drift * 20 * dt;
                p.x += wind * 8 * dt;
                p.life -= dt * 0.42;
                p.flicker += dt * 12;
                if (!this.performanceMode) {
                    p.trail.push({ x: p.x, y: p.y, life: p.life });
                    if (p.trail.length > 6) p.trail.shift();
                }
                if (p.life <= 0 || p.y < -30) Object.assign(p, this.spawnEmber(W, H));
                break;
            }
            case 'smoke': {
                p.y -= p.speed * 25 * dt;
                p.x += Math.sin(time * 0.4 + p.offset) * 1.8 + p.drift * 15 * dt + wind * 5 * dt;
                p.size += dt * 6;
                p.life -= dt * 0.12;
                if (p.life <= 0 || p.y < -p.size) Object.assign(p, this.spawnSmoke(W, H));
                break;
            }
            case 'spark': {
                p.vy += 28 * dt;
                p.x += p.vx * dt * 60;
                p.y += p.vy * dt * 60;
                p.life -= dt * 0.9;
                if (!this.performanceMode) {
                    p.trail.push({ x: p.x, y: p.y });
                    if (p.trail.length > 4) p.trail.shift();
                }
                if (p.life <= 0 || p.y < -20) Object.assign(p, this.spawnSpark(W, H));
                break;
            }
            case 'neon': {
                p.angle += dt * p.speed * 0.4;
                p.x += Math.cos(p.angle) * p.speed * 25 * dt;
                p.y += Math.sin(p.angle * 0.7) * p.speed * 18 * dt;
                p.pulse += dt * 2;
                if (p.x < -20 || p.x > W + 20 || p.y < -20 || p.y > H + 20) {
                    Object.assign(p, this.spawnNeon(W, H, 0));
                }
                break;
            }
        }
    }

    drawParticle(p, cfg, skipBlur = false) {
        const ctx = this.ctx;
        let blur = 0;
        if (!skipBlur) {
            if (p.type === 'ember') blur = this.cfgVal('fxEmbers', 'blur', 0);
            else if (p.type === 'smoke') blur = this.cfgVal('fxSmoke', 'blur', 5);
            else if (p.type === 'snow') blur = this.cfgVal('fxSnow', 'blur', 0);
            else if (p.type === 'rain') blur = this.cfgVal('fxRain', 'blur', 0);
            else if (p.type === 'spark') blur = this.cfgVal('fxSparks', 'blur', 0);
            else if (p.type === 'neon') blur = this.cfgVal('fxNeon', 'blur', 2);
        }

        if (blur > 0) ctx.filter = `blur(${blur}px)`;
        else ctx.filter = 'none';

        switch (p.type) {
            case 'snow': this.drawSnow(ctx, p); break;
            case 'rain': this.drawRain(ctx, p); break;
            case 'ember': this.drawEmber(ctx, p); break;
            case 'smoke': this.drawSmoke(ctx, p); break;
            case 'spark': this.drawSpark(ctx, p); break;
            case 'neon': this.drawNeon(ctx, p); break;
        }
        ctx.filter = 'none';
    }

    drawSnow(ctx, p) {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.rot);
        ctx.globalAlpha = p.alpha;
        const r = p.size;
        const g = ctx.createRadialGradient(0, 0, 0, 0, 0, r);
        g.addColorStop(0, 'rgba(255,255,255,0.95)');
        g.addColorStop(0.5, 'rgba(220,235,255,0.6)');
        g.addColorStop(1, 'rgba(200,220,255,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        if (p.layer === 2) {
            for (let i = 0; i < 6; i++) {
                const a = (i / 6) * Math.PI * 2;
                ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r);
            }
            ctx.closePath();
        } else {
            ctx.arc(0, 0, r, 0, Math.PI * 2);
        }
        ctx.fill();
        ctx.restore();
    }

    drawRain(ctx, p) {
        const angle = p._angle || 0.1;
        const dx = Math.sin(angle) * p.len;
        const dy = p.len;
        const x2 = p.x + dx;
        const y2 = p.y + dy;
        const grad = ctx.createLinearGradient(p.x, p.y, x2, y2);
        const { r, g, b } = this.accentRgb;
        grad.addColorStop(0, `rgba(${r},${g},${b},0)`);
        grad.addColorStop(0.4, `rgba(180,200,230,${p.alpha * 0.5})`);
        grad.addColorStop(1, `rgba(220,235,255,${p.alpha})`);
        ctx.strokeStyle = grad;
        ctx.lineWidth = p.width;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    }

    drawEmber(ctx, p) {
        const heat = p.heat * p.life;
        for (let i = 0; i < p.trail.length - 1; i++) {
            const t = p.trail[i];
            const a = (i / p.trail.length) * t.life * 0.35;
            ctx.strokeStyle = `rgba(255, ${80 + heat * 100}, 20, ${a})`;
            ctx.lineWidth = p.size * 0.4 * (i / p.trail.length);
            ctx.beginPath();
            ctx.moveTo(p.trail[i].x, p.trail[i].y);
            ctx.lineTo(p.trail[i + 1].x, p.trail[i + 1].y);
            ctx.stroke();
        }
        const flick = 0.75 + Math.sin(p.flicker) * 0.25;
        const alpha = p.life * flick;
        const rad = p.size * (0.8 + heat * 0.5);
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rad * 3);
        g.addColorStop(0, `rgba(255,${200 + heat * 55},${80 + heat * 40},${alpha})`);
        g.addColorStop(0.35, `rgba(255,${60 + heat * 80},0,${alpha * 0.7})`);
        g.addColorStop(1, 'rgba(80,20,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, rad * 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = `rgba(255,255,${200 + heat * 55},${alpha})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, rad * 0.35, 0, Math.PI * 2);
        ctx.fill();
    }

    drawSmoke(ctx, p) {
        const a = p.life * 0.22;
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size);
        g.addColorStop(0, `rgba(${90 + p.hue},${88 + p.hue},${95 + p.hue},${a * 0.5})`);
        g.addColorStop(0.45, `rgba(60,60,68,${a * 0.35})`);
        g.addColorStop(1, 'rgba(40,40,48,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
    }

    drawSpark(ctx, p) {
        if (p.trail.length > 1) {
            ctx.strokeStyle = `rgba(255, 220, 100, ${p.life * 0.5})`;
            ctx.lineWidth = p.size * 0.6;
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(p.trail[0].x, p.trail[0].y);
            for (let i = 1; i < p.trail.length; i++) ctx.lineTo(p.trail[i].x, p.trail[i].y);
            ctx.stroke();
        }
        const g = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 4);
        g.addColorStop(0, `rgba(255,255,255,${p.life})`);
        g.addColorStop(0.2, `rgba(255,230,80,${p.life * 0.8})`);
        g.addColorStop(1, 'rgba(255,120,0,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * 3, 0, Math.PI * 2);
        ctx.fill();
    }

    drawNeon(ctx, p) {
        const pulse = 0.55 + Math.sin(p.pulse) * 0.45;
        const { r, g, b } = p;
        const rad = p.size * (1 + pulse * 0.3);
        const gRad = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, rad * 2.5);
        gRad.addColorStop(0, `rgba(${r},${g},${b},${0.5 * pulse})`);
        gRad.addColorStop(0.5, `rgba(${r},${g},${b},${0.15 * pulse})`);
        gRad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.globalCompositeOperation = 'screen';
        ctx.fillStyle = gRad;
        ctx.beginPath();
        ctx.arc(p.x, p.y, rad * 2.5, 0, Math.PI * 2);
        ctx.fill();
        if (p.ring) {
            ctx.strokeStyle = `rgba(${r},${g},${b},${0.25 * pulse})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.arc(p.x, p.y, rad * (1.8 + pulse), 0, Math.PI * 2);
            ctx.stroke();
        }
        ctx.globalCompositeOperation = 'source-over';
    }

    drawSplashes(cfg) {
        if (!cfg.fxRain) return;
        const ctx = this.ctx;
        for (const s of this.splashes) {
            ctx.strokeStyle = `rgba(${s.cr},${s.cg},${s.cb},${s.life * 0.35})`;
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.ellipse(s.x, s.y, s.r, s.r * 0.35, 0, 0, Math.PI * 2);
            ctx.stroke();
        }
    }
}