/**
 * FAFO Tag Theme Packs — chips, borders, glows, fonts, animations.
 * Built-in packs + live custom overrides + user-saved themes.
 */
(function (global) {
  'use strict';

  const STORAGE_KEY = 'fafoTagTheme';
  const CUSTOM_KEY = 'fafoTagThemeCustom';
  const USER_PACKS_KEY = 'fafoTagThemeUserPacks';

  const DEFAULT_VARS = {
    '--tag-font': "'Segoe UI', system-ui, sans-serif",
    '--tag-weight': '700',
    '--tag-radius': '999px',
    '--tag-border-w': '1px',
    '--tag-pad-y': '4px',
    '--tag-pad-x': '10px',
    '--tag-bg': 'rgba(0, 20, 28, 0.75)',
    '--tag-border': 'rgba(0, 229, 255, 0.35)',
    '--tag-fg': '#b8f7ff',
    '--tag-selected-bg': 'linear-gradient(135deg, rgba(0,255,168,0.25), rgba(0,229,255,0.2))',
    '--tag-selected-border': '#00ffa8',
    '--tag-selected-fg': '#e8fff6',
    '--tag-selected-glow': '0 0 12px rgba(0,255,168,0.45)',
    '--tag-last-border': '#ffc107',
    '--tag-last-glow': '0 0 10px rgba(255,193,7,0.4)',
    '--tag-hover-scale': '1.04',
    '--tag-panel-border': 'rgba(0, 229, 255, 0.28)',
    '--tag-panel-glow': '0 0 18px rgba(0, 229, 255, 0.12)',
    '--tag-letter-spacing': '0.02em',
    '--tag-shadow': 'none',
  };

  const ANIM_OPTIONS = [
    { id: 'neon', label: 'Neon glow' },
    { id: 'breathe', label: 'Breathe' },
    { id: 'pulse', label: 'Pulse' },
    { id: 'shimmer', label: 'Shimmer' },
    { id: 'flash', label: 'Flash' },
    { id: 'bounce', label: 'Bounce' },
    { id: 'flicker', label: 'Flicker' },
    { id: 'static', label: 'Static (no anim)' },
  ];

  const LAST_ANIM_OPTIONS = [
    { id: 'breathe-gold', label: 'Gold breathe' },
    { id: 'pulse', label: 'Pulse' },
    { id: 'flash', label: 'Flash' },
    { id: 'static', label: 'Static' },
  ];

  const BORDER_STYLES = [
    { id: 'glow', label: 'Soft glow' },
    { id: 'solid', label: 'Solid' },
    { id: 'double', label: 'Double' },
    { id: 'dashed', label: 'Dashed' },
    { id: 'neon-run', label: 'Neon run' },
    { id: 'gradient-spin', label: 'Gradient spin' },
    { id: 'pulse-edge', label: 'Pulse edge' },
    { id: 'corners', label: 'Corners only' },
    { id: 'none', label: 'None' },
  ];

  function pack(id, name, vars, extras = {}) {
    return {
      id,
      name,
      description: extras.description || '',
      anim: extras.anim || 'neon',
      lastAnim: extras.lastAnim || 'breathe-gold',
      borderStyle: extras.borderStyle || 'glow',
      vars: { ...DEFAULT_VARS, ...vars },
    };
  }

  const BUILTIN = [
    pack('cyan-ops', 'Cyan Ops', {
      '--tag-bg': 'rgba(0, 20, 28, 0.75)',
      '--tag-border': 'rgba(0, 229, 255, 0.35)',
      '--tag-fg': '#b8f7ff',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(0,255,168,0.25), rgba(0,229,255,0.2))',
      '--tag-selected-border': '#00ffa8',
      '--tag-selected-glow': '0 0 12px rgba(0,255,168,0.45)',
    }, { description: 'Classic FAFO cyan pills', anim: 'neon', borderStyle: 'glow' }),

    pack('amber-field', 'Amber Field', {
      '--tag-font': "Georgia, 'Times New Roman', serif",
      '--tag-weight': '600',
      '--tag-radius': '8px',
      '--tag-border-w': '1.5px',
      '--tag-bg': 'rgba(28, 18, 0, 0.8)',
      '--tag-border': 'rgba(255, 193, 7, 0.4)',
      '--tag-fg': '#ffe8a8',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(255,152,0,0.35), rgba(255,193,7,0.2))',
      '--tag-selected-border': '#ff9800',
      '--tag-selected-fg': '#fff8e7',
      '--tag-selected-glow': '0 0 14px rgba(255,152,0,0.5)',
      '--tag-last-border': '#00e5ff',
      '--tag-panel-border': 'rgba(255, 193, 7, 0.3)',
    }, { description: 'Warm field report', anim: 'breathe', lastAnim: 'flash', borderStyle: 'solid' }),

    pack('violet-night', 'Violet Night', {
      '--tag-radius': '10px',
      '--tag-bg': 'rgba(18, 10, 32, 0.85)',
      '--tag-border': 'rgba(167, 139, 250, 0.4)',
      '--tag-fg': '#e9e0ff',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(167,139,250,0.35), rgba(236,72,153,0.2))',
      '--tag-selected-border': '#a78bfa',
      '--tag-selected-glow': '0 0 16px rgba(167,139,250,0.55)',
      '--tag-last-border': '#f472b6',
      '--tag-panel-border': 'rgba(167, 139, 250, 0.35)',
      '--tag-panel-glow': '0 0 22px rgba(167, 139, 250, 0.18)',
    }, { description: 'Purple neon club', anim: 'pulse', borderStyle: 'neon-run' }),

    pack('hard-edge', 'Hard Edge', {
      '--tag-font': 'ui-monospace, Consolas, monospace',
      '--tag-radius': '2px',
      '--tag-border-w': '2px',
      '--tag-pad-y': '3px',
      '--tag-pad-x': '8px',
      '--tag-bg': 'rgba(0,0,0,0.7)',
      '--tag-border': 'rgba(255,255,255,0.35)',
      '--tag-fg': '#eee',
      '--tag-selected-bg': '#00e5ff',
      '--tag-selected-border': '#fff',
      '--tag-selected-fg': '#001018',
      '--tag-selected-glow': 'none',
      '--tag-last-border': '#ff4466',
      '--tag-last-glow': 'none',
      '--tag-hover-scale': '1.0',
      '--tag-letter-spacing': '0.04em',
    }, { description: 'Brutalist monospace', anim: 'static', lastAnim: 'static', borderStyle: 'solid' }),

    pack('soft-glass', 'Soft Glass', {
      '--tag-radius': '14px',
      '--tag-bg': 'rgba(255,255,255,0.08)',
      '--tag-border': 'rgba(255,255,255,0.18)',
      '--tag-fg': 'rgba(255,255,255,0.88)',
      '--tag-selected-bg': 'rgba(0,229,255,0.22)',
      '--tag-selected-border': 'rgba(0,229,255,0.65)',
      '--tag-selected-glow': '0 4px 18px rgba(0,229,255,0.25)',
      '--tag-shadow': '0 2px 8px rgba(0,0,0,0.25)',
    }, { description: 'Frosted glass chips', anim: 'shimmer', borderStyle: 'glow' }),

    pack('blood-moon', 'Blood Moon', {
      '--tag-radius': '6px',
      '--tag-bg': 'rgba(40, 4, 10, 0.88)',
      '--tag-border': 'rgba(255, 68, 102, 0.45)',
      '--tag-fg': '#ffc0cb',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(255,68,102,0.4), rgba(180,0,40,0.35))',
      '--tag-selected-border': '#ff4466',
      '--tag-selected-fg': '#fff',
      '--tag-selected-glow': '0 0 18px rgba(255,68,102,0.55)',
      '--tag-last-border': '#ffc107',
      '--tag-panel-border': 'rgba(255, 68, 102, 0.35)',
      '--tag-panel-glow': '0 0 20px rgba(255, 40, 80, 0.2)',
    }, { description: 'Crimson heat', anim: 'flash', lastAnim: 'pulse', borderStyle: 'pulse-edge' }),

    pack('matrix-green', 'Matrix Green', {
      '--tag-font': 'ui-monospace, Consolas, monospace',
      '--tag-radius': '0px',
      '--tag-border-w': '1px',
      '--tag-bg': 'rgba(0, 12, 0, 0.9)',
      '--tag-border': 'rgba(0, 255, 100, 0.4)',
      '--tag-fg': '#7CFF9A',
      '--tag-selected-bg': 'rgba(0,255,100,0.2)',
      '--tag-selected-border': '#00ff66',
      '--tag-selected-fg': '#d0ffd8',
      '--tag-selected-glow': '0 0 12px rgba(0,255,100,0.5)',
      '--tag-last-border': '#00e5ff',
      '--tag-letter-spacing': '0.06em',
    }, { description: 'Terminal rain aesthetic', anim: 'flicker', borderStyle: 'dashed' }),

    pack('ice-crystal', 'Ice Crystal', {
      '--tag-radius': '4px',
      '--tag-border-w': '1.5px',
      '--tag-bg': 'rgba(200, 230, 255, 0.08)',
      '--tag-border': 'rgba(160, 210, 255, 0.5)',
      '--tag-fg': '#e0f2ff',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(160,210,255,0.35), rgba(100,180,255,0.15))',
      '--tag-selected-border': '#9ad0ff',
      '--tag-selected-glow': '0 0 16px rgba(140, 200, 255, 0.5)',
      '--tag-last-border': '#f0abfc',
    }, { description: 'Cold sharp ice', anim: 'shimmer', borderStyle: 'double' }),

    pack('hot-pink', 'Hot Pink Pop', {
      '--tag-radius': '999px',
      '--tag-bg': 'rgba(40, 0, 30, 0.85)',
      '--tag-border': 'rgba(244, 114, 182, 0.5)',
      '--tag-fg': '#fce7f3',
      '--tag-selected-bg': 'linear-gradient(135deg, #f472b6, #c026d3)',
      '--tag-selected-border': '#fff',
      '--tag-selected-fg': '#fff',
      '--tag-selected-glow': '0 0 20px rgba(244, 114, 182, 0.65)',
      '--tag-hover-scale': '1.08',
    }, { description: 'Party pink pills', anim: 'bounce', borderStyle: 'gradient-spin' }),

    pack('gold-luxury', 'Gold Luxury', {
      '--tag-font': "Georgia, 'Palatino Linotype', serif",
      '--tag-weight': '600',
      '--tag-radius': '6px',
      '--tag-border-w': '1.5px',
      '--tag-bg': 'rgba(24, 18, 4, 0.9)',
      '--tag-border': 'rgba(251, 191, 36, 0.55)',
      '--tag-fg': '#fde68a',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(251,191,36,0.4), rgba(180,120,20,0.3))',
      '--tag-selected-border': '#fbbf24',
      '--tag-selected-fg': '#fffbeb',
      '--tag-selected-glow': '0 0 16px rgba(251, 191, 36, 0.5)',
    }, { description: 'VIP gold chips', anim: 'breathe', lastAnim: 'flash', borderStyle: 'corners' }),

    pack('noir-film', 'Noir Film', {
      '--tag-radius': '3px',
      '--tag-border-w': '1px',
      '--tag-bg': 'rgba(12, 12, 12, 0.92)',
      '--tag-border': 'rgba(180, 180, 180, 0.35)',
      '--tag-fg': '#d4d4d4',
      '--tag-selected-bg': 'rgba(255,255,255,0.12)',
      '--tag-selected-border': '#f5f5f5',
      '--tag-selected-fg': '#fff',
      '--tag-selected-glow': 'none',
      '--tag-last-border': '#a3a3a3',
      '--tag-last-glow': 'none',
      '--tag-hover-scale': '1.02',
    }, { description: 'B&W cinema', anim: 'static', lastAnim: 'static', borderStyle: 'solid' }),

    pack('toxic-slime', 'Toxic Slime', {
      '--tag-radius': '12px',
      '--tag-bg': 'rgba(10, 30, 0, 0.88)',
      '--tag-border': 'rgba(163, 230, 53, 0.5)',
      '--tag-fg': '#ecfccb',
      '--tag-selected-bg': 'linear-gradient(135deg, rgba(163,230,53,0.35), rgba(34,197,94,0.25))',
      '--tag-selected-border': '#a3e635',
      '--tag-selected-glow': '0 0 18px rgba(163, 230, 53, 0.55)',
      '--tag-last-border': '#facc15',
    }, { description: 'Acid green ooze', anim: 'pulse', borderStyle: 'glow' }),

    pack('ocean-depth', 'Ocean Depth', {
      '--tag-radius': '20px',
      '--tag-bg': 'rgba(0, 20, 40, 0.85)',
      '--tag-border': 'rgba(56, 189, 248, 0.4)',
      '--tag-fg': '#bae6fd',
      '--tag-selected-bg': 'linear-gradient(160deg, rgba(14,165,233,0.4), rgba(3,105,161,0.35))',
      '--tag-selected-border': '#38bdf8',
      '--tag-selected-glow': '0 0 16px rgba(56, 189, 248, 0.5)',
      '--tag-panel-glow': '0 0 24px rgba(14, 165, 233, 0.15)',
    }, { description: 'Deep sea blues', anim: 'breathe', borderStyle: 'neon-run' }),

    pack('ember-forge', 'Ember Forge', {
      '--tag-radius': '4px',
      '--tag-border-w': '2px',
      '--tag-bg': 'rgba(30, 10, 0, 0.9)',
      '--tag-border': 'rgba(249, 115, 22, 0.55)',
      '--tag-fg': '#ffedd5',
      '--tag-selected-bg': 'linear-gradient(135deg, #ea580c, #b91c1c)',
      '--tag-selected-border': '#fdba74',
      '--tag-selected-fg': '#fff',
      '--tag-selected-glow': '0 0 20px rgba(249, 115, 22, 0.6)',
    }, { description: 'Molten orange forge', anim: 'flash', lastAnim: 'pulse', borderStyle: 'pulse-edge' }),

    pack('minimal-ink', 'Minimal Ink', {
      '--tag-weight': '500',
      '--tag-radius': '6px',
      '--tag-border-w': '1px',
      '--tag-bg': 'transparent',
      '--tag-border': 'rgba(255,255,255,0.2)',
      '--tag-fg': 'rgba(255,255,255,0.75)',
      '--tag-selected-bg': 'transparent',
      '--tag-selected-border': 'rgba(255,255,255,0.85)',
      '--tag-selected-fg': '#fff',
      '--tag-selected-glow': 'none',
      '--tag-last-glow': 'none',
      '--tag-hover-scale': '1.02',
    }, { description: 'Quiet outline only', anim: 'static', lastAnim: 'static', borderStyle: 'none' }),

    pack('retro-arcade', 'Retro Arcade', {
      '--tag-font': 'ui-monospace, Consolas, monospace',
      '--tag-radius': '0',
      '--tag-border-w': '3px',
      '--tag-pad-y': '4px',
      '--tag-pad-x': '8px',
      '--tag-bg': '#000',
      '--tag-border': '#ff00ff',
      '--tag-fg': '#00ffff',
      '--tag-selected-bg': '#ff00ff',
      '--tag-selected-border': '#ffff00',
      '--tag-selected-fg': '#000',
      '--tag-selected-glow': '4px 4px 0 #00ffff',
      '--tag-last-border': '#ffff00',
      '--tag-letter-spacing': '0.08em',
    }, { description: '80s cabinet vibes', anim: 'bounce', borderStyle: 'double' }),
  ];

  /** @type {Array} user-saved packs */
  let userPacks = [];
  let currentId = 'cyan-ops';
  /** Live custom overrides layered on top of the active pack */
  let customOverrides = {
    vars: {},
    anim: null,
    lastAnim: null,
    borderStyle: null,
  };

  function allPacks() {
    return BUILTIN.concat(userPacks);
  }

  function list() {
    return allPacks().map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description || '',
      anim: p.anim,
      borderStyle: p.borderStyle,
      user: !!p.user,
    }));
  }

  function get(id) {
    return allPacks().find((p) => p.id === id) || BUILTIN[0];
  }

  function stripThemeClasses(body) {
    // Remove previous theme id classes
    [...body.classList].forEach((c) => {
      if (c.startsWith('fafo-tag-theme-')) body.classList.remove(c);
    });
    // Tag anim classes we own
    [
      'fafo-tag-neon', 'fafo-tag-breathe', 'fafo-tag-pulse', 'fafo-tag-shimmer',
      'fafo-tag-flash', 'fafo-tag-bounce', 'fafo-tag-flicker', 'fafo-tag-static',
      'fafo-last-breathe-gold', 'fafo-last-pulse', 'fafo-last-flash', 'fafo-last-static',
      'fafo-tag-border-glow', 'fafo-tag-border-solid', 'fafo-tag-border-double',
      'fafo-tag-border-dashed', 'fafo-tag-border-neon-run', 'fafo-tag-border-gradient-spin',
      'fafo-tag-border-pulse-edge', 'fafo-tag-border-corners', 'fafo-tag-border-none',
    ].forEach((c) => body.classList.remove(c));
  }

  function resolveAnim(pack) {
    return customOverrides.anim || pack.anim || 'neon';
  }

  function resolveLastAnim(pack) {
    return customOverrides.lastAnim || pack.lastAnim || 'breathe-gold';
  }

  function resolveBorder(pack) {
    return customOverrides.borderStyle || pack.borderStyle || 'glow';
  }

  function apply(id, opts = {}) {
    const pack = get(id || currentId);
    currentId = pack.id;
    const root = document.documentElement;
    const body = document.body;

    // CSS vars from pack + custom overrides
    const merged = { ...pack.vars, ...(customOverrides.vars || {}) };
    Object.entries(DEFAULT_VARS).forEach(([k, v]) => {
      root.style.setProperty(k, merged[k] != null ? merged[k] : v);
    });
    Object.entries(merged).forEach(([k, v]) => root.style.setProperty(k, v));

    stripThemeClasses(body);
    body.classList.add('fafo-tag-theme-' + pack.id);
    body.dataset.tagTheme = pack.id;

    const anim = resolveAnim(pack);
    const lastAnim = resolveLastAnim(pack);
    const border = resolveBorder(pack);

    body.classList.add('fafo-tag-' + anim);
    if (lastAnim === 'breathe-gold') body.classList.add('fafo-last-breathe-gold');
    else if (lastAnim === 'pulse') body.classList.add('fafo-last-pulse');
    else if (lastAnim === 'flash') body.classList.add('fafo-last-flash');
    else body.classList.add('fafo-last-static');

    body.classList.add('fafo-tag-border-' + border);
    body.dataset.tagAnim = anim;
    body.dataset.tagBorder = border;

    if (!opts.skipSave) {
      try {
        chrome.storage.local.set({
          [STORAGE_KEY]: pack.id,
          [CUSTOM_KEY]: customOverrides,
        });
      } catch (_) {}
    }

    try {
      global.dispatchEvent(new CustomEvent('fafo:tag-theme', {
        detail: {
          id: pack.id,
          name: pack.name,
          anim,
          lastAnim,
          borderStyle: border,
          vars: merged,
        },
      }));
    } catch (_) {}

    return {
      ...pack,
      anim,
      lastAnim,
      borderStyle: border,
      vars: merged,
    };
  }

  function setOverride(partial) {
    if (!partial || typeof partial !== 'object') return current();
    if (partial.vars && typeof partial.vars === 'object') {
      customOverrides.vars = { ...customOverrides.vars, ...partial.vars };
    }
    if (partial.anim != null) customOverrides.anim = partial.anim || null;
    if (partial.lastAnim != null) customOverrides.lastAnim = partial.lastAnim || null;
    if (partial.borderStyle != null) customOverrides.borderStyle = partial.borderStyle || null;
    return apply(currentId);
  }

  function clearOverrides() {
    customOverrides = { vars: {}, anim: null, lastAnim: null, borderStyle: null };
    return apply(currentId);
  }

  function getOverrides() {
    return JSON.parse(JSON.stringify(customOverrides));
  }

  async function saveUserPack(name) {
    const base = get(currentId);
    const merged = { ...base.vars, ...(customOverrides.vars || {}) };
    const id = 'user-' + Date.now().toString(36);
    const packObj = {
      id,
      name: String(name || 'My theme').trim() || 'My theme',
      description: 'Saved custom theme',
      user: true,
      anim: resolveAnim(base),
      lastAnim: resolveLastAnim(base),
      borderStyle: resolveBorder(base),
      vars: merged,
    };
    userPacks.push(packObj);
    await persistUserPacks();
    apply(id);
    return packObj;
  }

  async function deleteUserPack(id) {
    userPacks = userPacks.filter((p) => p.id !== id);
    await persistUserPacks();
    if (currentId === id) apply(BUILTIN[0].id);
    return list();
  }

  async function persistUserPacks() {
    try {
      await chrome.storage.local.set({ [USER_PACKS_KEY]: userPacks });
    } catch (e) {
      console.warn('tag theme user packs save', e);
    }
  }

  async function load() {
    try {
      const res = await chrome.storage.local.get([STORAGE_KEY, CUSTOM_KEY, USER_PACKS_KEY]);
      if (Array.isArray(res[USER_PACKS_KEY])) {
        userPacks = res[USER_PACKS_KEY].filter((p) => p && p.id && p.vars);
      }
      if (res[CUSTOM_KEY] && typeof res[CUSTOM_KEY] === 'object') {
        customOverrides = {
          vars: res[CUSTOM_KEY].vars && typeof res[CUSTOM_KEY].vars === 'object' ? res[CUSTOM_KEY].vars : {},
          anim: res[CUSTOM_KEY].anim || null,
          lastAnim: res[CUSTOM_KEY].lastAnim || null,
          borderStyle: res[CUSTOM_KEY].borderStyle || null,
        };
      }
      const id = res[STORAGE_KEY] || 'cyan-ops';
      return apply(id, { skipSave: true });
    } catch {
      return apply('cyan-ops', { skipSave: true });
    }
  }

  function cycle() {
    const packs = allPacks();
    const i = packs.findIndex((p) => p.id === currentId);
    const next = packs[(i + 1 + packs.length) % packs.length];
    // clear overrides when cycling presets so pack identity is clear
    customOverrides = { vars: {}, anim: null, lastAnim: null, borderStyle: null };
    apply(next.id);
    try {
      global.FAFOUndo?.showToast?.('Tag theme: ' + next.name);
    } catch (_) {}
    return next;
  }

  function current() {
    const pack = get(currentId);
    return {
      ...pack,
      anim: resolveAnim(pack),
      lastAnim: resolveLastAnim(pack),
      borderStyle: resolveBorder(pack),
      vars: { ...pack.vars, ...(customOverrides.vars || {}) },
      overrides: getOverrides(),
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => load());
  } else {
    load();
  }

  global.FAFOTagThemes = {
    list,
    get,
    apply,
    load,
    cycle,
    current,
    PACKS: BUILTIN,
    DEFAULT_VARS,
    ANIM_OPTIONS,
    LAST_ANIM_OPTIONS,
    BORDER_STYLES,
    setOverride,
    clearOverrides,
    getOverrides,
    saveUserPack,
    deleteUserPack,
    getUserPacks: () => userPacks.slice(),
  };
})(typeof window !== 'undefined' ? window : globalThis);
