/**
 * FAFO per-tag colors + named color slots (chrome.storage.local).
 *
 * Slots are meaningful named palettes (Subject, Descriptor, Weapons…) — not hex labels.
 * Each slot supports:
 *   - fill + border (independent)
 *   - solid or gradient (linear / radial / conic)
 *   - transparency per stop
 *   - gradient direction + midpoint stop (slide colors closer/further)
 *
 * Tags map to a slot index, a legacy #hex, or a full style object.
 */
(function (global) {
  'use strict';

  const KEY_PUBLIC = 'fafoTagColors';
  const KEY_PRIVATE = 'fafoTagColorsPrivate';
  const PRESETS_KEY = 'fafoTagColorPresets';
  const SLOTS_KEY = 'fafoTagColorSlots';
  /** Per-theme slot overrides: { [themeId]: { [slotIndex]: partialSlot } } */
  const THEME_SLOTS_KEY = 'fafoTagColorSlotsByTheme';
  /** Global look for tags currently on the active clip (chosen / selected) */
  const CHOSEN_KEY = 'fafoTagChosenStyle';
  /** Global typeface + default text color for every tag tile (slot/tag can still override) */
  const TYPE_KEY = 'fafoTagTypeStyle';
  const RECENT_KEY = 'fafoTagRecentColors';
  const RECENT_MAX = 18;
  const MIN_SLOTS = 25;
  /** @type {Array<{hex?: string, g?: boolean, a?: string, b?: string, c?: string, pattern?: string, dir?: string}>} */
  let recent = [];

  const FONT_CHOICES = [
    { id: '', label: 'Theme default' },
    { id: "'Segoe UI', system-ui, sans-serif", label: 'Segoe UI' },
    { id: 'system-ui, -apple-system, sans-serif', label: 'System UI' },
    { id: "'Inter', 'Segoe UI', sans-serif", label: 'Inter-like (system)' },
    { id: "'Trebuchet MS', 'Segoe UI', sans-serif", label: 'Trebuchet' },
    { id: 'Arial, Helvetica, sans-serif', label: 'Arial' },
    { id: 'Verdana, Geneva, sans-serif', label: 'Verdana' },
    { id: "'Lucida Sans Unicode', 'Lucida Grande', sans-serif", label: 'Lucida Sans' },
    { id: "Georgia, 'Times New Roman', serif", label: 'Georgia serif' },
    { id: "'Palatino Linotype', Palatino, serif", label: 'Palatino' },
    { id: "'Times New Roman', Times, serif", label: 'Times New Roman' },
    { id: "ui-monospace, Consolas, 'Courier New', monospace", label: 'Consolas / Mono' },
    { id: "'Courier New', Courier, monospace", label: 'Courier New' },
    { id: "'Comic Sans MS', 'Segoe Print', cursive", label: 'Comic Sans' },
    { id: 'Impact, Haettenschweiler, sans-serif', label: 'Impact' },
    { id: "'Segoe Print', 'Bradley Hand', cursive", label: 'Segoe Print' },
  ];

  /** Active map key — secret mode never shares tag→color vocabulary with public. */
  function colorsStorageKey() {
    try {
      if (global.FAFOMeta?.isPrivateSpaceActive?.()) {
        const sk = global.FAFOMeta?.getSpaceStorageKeys?.();
        if (sk?.tagColors) return sk.tagColors;
        return KEY_PRIVATE;
      }
    } catch (_) { /* ignore */ }
    return KEY_PUBLIC;
  }

  /** @type {Record<string, any>} lowercase tag → #hex | { slot } | style */
  let map = {};
  let loaded = false;
  /** @type {ReturnType<typeof defaultChosen>} */
  let chosen = null;
  /** @type {ReturnType<typeof defaultTypeStyle>} */
  let typeStyle = null;

  const DEFAULT_SLOT_NAMES = [
    'Subject',
    'Descriptor',
    'Things',
    'Weapons',
    'Location',
    'Action',
    'Mood',
    'Quality',
    'People',
    'Animals',
    'Vehicles',
    'Environment',
    'Weather',
    'Time',
    'Style',
    'Genre',
    'Camera',
    'Lighting',
    'Outfit',
    'Props',
    'Effects',
    'Rating',
    'Series',
    'WIP',
    'Custom',
    'Extra A',
    'Extra B',
    'Extra C',
    'Extra D',
    'Extra E',
  ];

  const DEFAULT_HEXES = [
    '#00e5ff', '#00ffa8', '#ffc107', '#ff9800', '#ff4466',
    '#f472b6', '#a78bfa', '#60a5fa', '#34d399', '#fbbf24',
    '#e8e8ec', '#94a3b8', '#22d3ee', '#a3e635', '#fb7185',
    '#c084fc', '#38bdf8', '#4ade80', '#facc15', '#f97316',
    '#e879f9', '#2dd4bf', '#f43f5e', '#818cf8', '#14b8a6',
    '#84cc16', '#d946ef', '#0ea5e9', '#ef4444', '#10b981',
  ];

  const GRADIENT_DIRS = [
    { id: 'to right', label: '→ Right' },
    { id: 'to left', label: '← Left' },
    { id: 'to bottom', label: '↓ Down' },
    { id: 'to top', label: '↑ Up' },
    { id: 'to bottom right', label: '↘ Diagonal' },
    { id: 'to bottom left', label: '↙ Diagonal' },
    { id: 'to top right', label: '↗ Diagonal' },
    { id: 'to top left', label: '↖ Diagonal' },
    { id: '135deg', label: '135°' },
    { id: '45deg', label: '45°' },
    { id: '90deg', label: '90°' },
    { id: '0deg', label: '0°' },
  ];

  /** Gradient shape (how colors blend) */
  const GRADIENT_PATTERNS = [
    { id: 'linear', label: 'Linear blend' },
    { id: 'radial', label: 'Radial blend' },
    { id: 'conic', label: 'Conic / sweep' },
  ];

  /**
   * Chosen-tag (on-clip) fill modes — includes 3D sphere / orb lighting.
   * Applied to every tag currently on the active media, all UI fields.
   */
  const CHOSEN_FILL_MODES = [
    { id: 'solid', label: 'Solid' },
    { id: 'linear', label: 'Linear blend' },
    { id: 'radial', label: 'Radial soft' },
    { id: 'conic', label: 'Conic sweep' },
    { id: 'sphere', label: '3D sphere (shaded)' },
    { id: 'sphere-soft', label: '3D sphere soft' },
    { id: 'sphere-chrome', label: '3D chrome orb' },
    { id: 'sphere-deep', label: '3D deep orb' },
    { id: 'pill-3d', label: '3D pill bevel' },
  ];

  function defaultTypeStyle() {
    return {
      font: '',
      // auto = contrast against fill (old default for painted chips)
      // custom = textColor on every tile
      // theme = CSS --tag-fg from the tag theme pack
      textMode: 'auto',
      textColor: '#ffffff',
    };
  }

  function sanitizeTypeStyle(raw) {
    const base = defaultTypeStyle();
    if (!raw || typeof raw !== 'object') return base;
    const t = { ...base, ...raw };
    const fonts = FONT_CHOICES.map((f) => f.id);
    t.font = fonts.includes(t.font) ? t.font : (typeof t.font === 'string' ? t.font : '');
    t.textMode = ['auto', 'custom', 'theme'].includes(t.textMode) ? t.textMode : 'auto';
    t.textColor = isHex(t.textColor) ? expandHex(t.textColor) : base.textColor;
    return t;
  }

  function getTypeStyle() {
    return sanitizeTypeStyle(typeStyle || defaultTypeStyle());
  }

  function themeFgFallback() {
    try {
      if (typeof document === 'undefined') return '#ffffff';
      const css = getComputedStyle(document.documentElement).getPropertyValue('--tag-fg').trim();
      return css || '#ffffff';
    } catch {
      return '#ffffff';
    }
  }

  /**
   * Resolve chip text color.
   * Priority: slot/tag custom → slot auto → global custom → global theme → auto contrast.
   */
  function resolveFg(slotLike, primary, alpha) {
    const localMode = slotLike && slotLike.textMode;
    if (localMode === 'custom' && isHex(slotLike.textColor)) return expandHex(slotLike.textColor);
    if (localMode === 'auto') return contrastFg(primary, alpha);
    if (localMode === 'theme') return themeFgFallback();
    const g = getTypeStyle();
    if (g.textMode === 'custom') return g.textColor;
    if (g.textMode === 'theme') return themeFgFallback();
    return contrastFg(primary, alpha);
  }

  async function setTypeStyle(partial, opts = {}) {
    typeStyle = sanitizeTypeStyle({ ...(typeStyle || defaultTypeStyle()), ...(partial || {}) });
    if (opts.persist !== false) {
      try {
        await chrome.storage.local.set({ [TYPE_KEY]: typeStyle });
      } catch (e) {
        console.warn('FAFO tag type style save', e);
      }
    }
    applyTypeCssVars();
    if (opts.paint !== false) {
      try {
        if (typeof document !== 'undefined') paintAll(document);
      } catch (_) {}
    }
    try {
      global.dispatchEvent(new CustomEvent('fafo:tag-type-style', { detail: { ...typeStyle } }));
    } catch (_) {}
    return getTypeStyle();
  }

  function applyTypeCssVars() {
    if (typeof document === 'undefined') return;
    const t = getTypeStyle();
    const root = document.documentElement;
    if (t.font) root.style.setProperty('--tag-font', t.font);
    if (t.textMode === 'custom' && t.textColor) {
      root.style.setProperty('--tag-fg', t.textColor);
    }
    root.style.setProperty('--tag-type-font', t.font || 'inherit');
    root.style.setProperty('--tag-type-fg', t.textMode === 'custom' ? t.textColor : 'inherit');
  }

  function defaultChosen() {
    return {
      enabled: true,
      // solid | linear | radial | conic | sphere | sphere-soft | sphere-chrome | sphere-deep | pill-3d
      fillMode: 'sphere',
      fillA: '#7ef7ff', // highlight / primary
      fillB: '#00e5ff', // mid
      fillC: '#0066aa', // shadow
      fillAlpha: 0.98,
      fillAlphaB: 0.95,
      fillAlphaC: 0.92,
      // Text: 'auto' uses contrast against primary, or a hex
      textMode: 'custom', // auto | custom
      textColor: '#041018',
      borderMode: 'solid', // solid | match-fill | glow
      borderA: '#00ffa8',
      borderAlpha: 1,
      glow: 0.55, // 0–1 intensity of outer glow
      lightX: 32, // sphere light position %
      lightY: 28,
      blendSoftness: 70, // smooth sphere falloff
    };
  }

  function sanitizeChosen(raw) {
    const base = defaultChosen();
    if (!raw || typeof raw !== 'object') return base;
    const c = { ...base, ...raw };
    c.enabled = c.enabled !== false;
    const modes = CHOSEN_FILL_MODES.map((m) => m.id);
    c.fillMode = modes.includes(c.fillMode) ? c.fillMode : 'sphere';
    c.fillA = isHex(c.fillA) ? expandHex(c.fillA) : base.fillA;
    c.fillB = isHex(c.fillB) ? expandHex(c.fillB) : base.fillB;
    c.fillC = isHex(c.fillC) ? expandHex(c.fillC) : base.fillC;
    c.fillAlpha = clamp(c.fillAlpha, 0, 1);
    c.fillAlphaB = clamp(c.fillAlphaB, 0, 1);
    c.fillAlphaC = clamp(c.fillAlphaC, 0, 1);
    c.textMode = c.textMode === 'auto' ? 'auto' : 'custom';
    c.textColor = isHex(c.textColor) ? expandHex(c.textColor) : base.textColor;
    c.borderMode = ['solid', 'match-fill', 'glow'].includes(c.borderMode) ? c.borderMode : 'solid';
    c.borderA = isHex(c.borderA) ? expandHex(c.borderA) : base.borderA;
    c.borderAlpha = clamp(c.borderAlpha, 0, 1);
    c.glow = clamp(c.glow, 0, 1);
    c.lightX = clamp(c.lightX ?? 32, 5, 95);
    c.lightY = clamp(c.lightY ?? 28, 5, 95);
    c.blendSoftness = clamp(c.blendSoftness ?? 70, 0, 100);
    return c;
  }

  function mixHex(hexA, hexB, t) {
    try {
      const a = hexToRgb(hexA);
      const b = hexToRgb(hexB);
      const u = clamp(t, 0, 1);
      const r = Math.round(a.r + (b.r - a.r) * u);
      const g = Math.round(a.g + (b.g - a.g) * u);
      const bl = Math.round(a.b + (b.b - a.b) * u);
      return '#' + [r, g, bl].map((x) => x.toString(16).padStart(2, '0')).join('');
    } catch {
      return hexA;
    }
  }

  /**
   * Smooth 3D sphere / orb fills (shaded ball lighting).
   * Uses highlight → mid → deep shadow with soft falloff controlled by blendSoftness.
   */
  function buildSphereFill(c, mode) {
    const soft = clamp(c.blendSoftness, 0, 100) / 100;
    const hi = rgba(c.fillA, c.fillAlpha);
    const mid = rgba(c.fillB, c.fillAlphaB);
    const sh = rgba(c.fillC, c.fillAlphaC);
    const deep = rgba(mixHex(c.fillC, '#000000', 0.45), Math.min(1, c.fillAlphaC + 0.05));
    const lx = clamp(c.lightX, 5, 95);
    const ly = clamp(c.lightY, 5, 95);
    // Softness spreads the mid band (smooth blends like a shaded sphere)
    const p1 = Math.round(8 + soft * 10);   // highlight core
    const p2 = Math.round(28 + soft * 18);  // mid start
    const p3 = Math.round(55 + soft * 15);  // mid end
    const p4 = Math.round(78 + soft * 10);  // shadow
    if (mode === 'sphere-soft') {
      return `radial-gradient(circle at ${lx}% ${ly}%, ${hi} 0%, ${mid} ${p2}%, ${sh} ${p4}%, ${deep} 100%)`;
    }
    if (mode === 'sphere-chrome') {
      const glint = rgba('#ffffff', 0.92);
      return `radial-gradient(circle at ${lx}% ${ly}%, ${glint} 0%, ${hi} 12%, ${mid} 38%, ${sh} 72%, ${deep} 100%)`;
    }
    if (mode === 'sphere-deep') {
      return `radial-gradient(circle at ${lx}% ${ly}%, ${hi} 0%, ${mid} ${p1 + 12}%, ${sh} ${p3}%, ${deep} 92%, #000 100%)`;
    }
    // default sphere
    return `radial-gradient(circle at ${lx}% ${ly}%, ${hi} 0%, ${mid} ${p2}%, ${sh} ${p3}%, ${deep} 100%)`;
  }

  function buildPill3dFill(c) {
    const hi = rgba(c.fillA, c.fillAlpha);
    const mid = rgba(c.fillB, c.fillAlphaB);
    const sh = rgba(c.fillC, c.fillAlphaC);
    return `linear-gradient(180deg, ${hi} 0%, ${mid} 48%, ${sh} 100%)`;
  }

  /** Resolve chosen-style into a paint style object (same shape as styleFromSlot). */
  function styleFromChosen(raw) {
    const c = sanitizeChosen(raw || chosen || defaultChosen());
    let fill;
    let fillSpec = null;
    const mode = c.fillMode;
    if (mode === 'solid') {
      fill = rgba(c.fillA, c.fillAlpha);
    } else if (mode === 'linear') {
      fill = buildSoftGradient(
        'linear',
        'to bottom right',
        [
          { color: rgba(c.fillA, c.fillAlpha), pos: 0 },
          { color: rgba(c.fillB, c.fillAlphaB), pos: 50 },
          { color: rgba(c.fillC, c.fillAlphaC), pos: 100 },
        ],
        c.blendSoftness
      );
    } else if (mode === 'radial') {
      fill = buildSoftGradient(
        'radial',
        'circle at 35% 30%',
        [
          { color: rgba(c.fillA, c.fillAlpha), pos: 0 },
          { color: rgba(c.fillB, c.fillAlphaB), pos: 55 },
          { color: rgba(c.fillC, c.fillAlphaC), pos: 100 },
        ],
        c.blendSoftness
      );
    } else if (mode === 'conic') {
      fill = buildSoftGradient(
        'conic',
        'from 0deg',
        [
          { color: rgba(c.fillA, c.fillAlpha), pos: 0 },
          { color: rgba(c.fillB, c.fillAlphaB), pos: 50 },
          { color: rgba(c.fillC, c.fillAlphaC), pos: 100 },
        ],
        c.blendSoftness
      );
    } else if (mode === 'pill-3d') {
      fill = buildPill3dFill(c);
    } else {
      // sphere family
      fill = buildSphereFill(c, mode);
    }

    let border;
    if (c.borderMode === 'match-fill') {
      border = rgba(c.fillA, c.borderAlpha);
    } else if (c.borderMode === 'glow') {
      border = rgba(c.borderA, c.borderAlpha);
    } else {
      border = rgba(c.borderA, c.borderAlpha);
    }

    const primary = c.fillA;
    const fg = c.textMode === 'auto' ? contrastFg(primary, c.fillAlpha) : c.textColor;
    const glowPx = Math.round(6 + c.glow * 18);
    const glowCol = rgba(c.borderA || primary, 0.25 + c.glow * 0.55);
    const is3d = mode.startsWith('sphere') || mode === 'pill-3d';
    const boxShadow = is3d
      ? `inset 2px 2px 6px ${rgba('#ffffff', 0.22)}, inset -2px -3px 8px ${rgba('#000000', 0.35)}, 0 0 ${glowPx}px ${glowCol}`
      : `0 0 ${glowPx}px ${glowCol}`;

    return {
      fill,
      fillSpec,
      border,
      borderSpec: null,
      primary,
      fg,
      boxShadow,
      chosen: true,
      slot: null,
    };
  }

  function getChosen() {
    return sanitizeChosen(chosen || defaultChosen());
  }

  async function setChosen(partial, opts = {}) {
    chosen = sanitizeChosen({ ...(chosen || defaultChosen()), ...(partial || {}) });
    if (opts.persist !== false) {
      try {
        await chrome.storage.local.set({ [CHOSEN_KEY]: chosen });
      } catch (e) {
        console.warn('FAFO chosen style save', e);
      }
    }
    applyChosenCssVars();
    if (opts.paint !== false) {
      try {
        if (typeof document !== 'undefined') paintAll(document);
      } catch (_) {}
    }
    try {
      global.dispatchEvent(new CustomEvent('fafo:tag-chosen-style', { detail: { ...chosen } }));
    } catch (_) {}
    return getChosen();
  }

  /** Publish CSS variables so theme fallbacks match chosen style too. */
  function applyChosenCssVars() {
    const c = getChosen();
    if (typeof document === 'undefined') return;
    const root = document.documentElement;
    if (!c.enabled) {
      // leave theme pack vars alone
      root.style.removeProperty('--fafo-chosen-enabled');
      return;
    }
    const st = styleFromChosen(c);
    root.style.setProperty('--fafo-chosen-enabled', '1');
    root.style.setProperty('--tag-selected-bg', st.fill);
    root.style.setProperty('--tag-selected-border', typeof st.border === 'string' ? st.border : c.borderA);
    root.style.setProperty('--tag-selected-fg', st.fg);
    root.style.setProperty('--tag-selected-glow', st.boxShadow);
    root.style.setProperty('--tag-selected', c.fillA);
  }

  /**
   * Tiling fill patterns (paint-program style).
   * All are scalable via tileScale (px cell size) and use up to 3 colors + per-color opacity.
   */
  const TILE_PATTERNS = (global.FAFOTilePatterns && Array.isArray(global.FAFOTilePatterns.CATALOG)
    && global.FAFOTilePatterns.CATALOG.length)
    ? global.FAFOTilePatterns.CATALOG.slice()
    : [
    { id: 'stripes-h', label: 'Stripes H', group: 'stripes' },
    { id: 'stripes-v', label: 'Stripes V', group: 'stripes' },
    { id: 'stripes-diag', label: 'Stripes ╱', group: 'stripes' },
    { id: 'stripes-diag2', label: 'Stripes ╲', group: 'stripes' },
    { id: 'stripes-thick', label: 'Stripes thick', group: 'stripes' },
    { id: 'stripes-thin', label: 'Stripes thin', group: 'stripes' },
    { id: 'bars-3', label: 'Triple bars', group: 'stripes' },
    { id: 'checker', label: 'Checker', group: 'blocks' },
    { id: 'checker-sm', label: 'Checker fine', group: 'blocks' },
    { id: 'pixel', label: 'Pixel blocks', group: 'blocks' },
    { id: 'bricks', label: 'Bricks', group: 'blocks' },
    { id: 'grid', label: 'Grid', group: 'lines' },
    { id: 'grid-bold', label: 'Grid bold', group: 'lines' },
    { id: 'crosshatch', label: 'Crosshatch', group: 'lines' },
    { id: 'crosshatch-dense', label: 'Hatch dense', group: 'lines' },
    { id: 'dots', label: 'Dots', group: 'dots' },
    { id: 'dots-loose', label: 'Dots loose', group: 'dots' },
    { id: 'dots-dense', label: 'Dots dense', group: 'dots' },
    { id: 'rings', label: 'Rings', group: 'dots' },
    { id: 'diamonds', label: 'Diamonds', group: 'geo' },
    { id: 'diamonds-outline', label: 'Diamond outline', group: 'geo' },
    { id: 'triangles', label: 'Triangles', group: 'geo' },
    { id: 'triangles-flip', label: 'Triangles flip', group: 'geo' },
    { id: 'chevron', label: 'Chevron', group: 'geo' },
    { id: 'chevron-v', label: 'Chevron V', group: 'geo' },
    { id: 'zigzag', label: 'Zigzag', group: 'geo' },
    { id: 'plaid', label: 'Plaid', group: 'weave' },
    { id: 'plaid-fine', label: 'Plaid fine', group: 'weave' },
    { id: 'weave', label: 'Basket weave', group: 'weave' },
    { id: 'honey', label: 'Honeycomb', group: 'organic' },
    { id: 'waves', label: 'Waves', group: 'organic' },
    { id: 'scales', label: 'Scales', group: 'organic' },
    { id: 'confetti', label: 'Confetti', group: 'organic' },
    { id: 'noise', label: 'Noise grit', group: 'organic' },
    { id: 'hex', label: 'Hex lattice', group: 'fafo' },
    { id: 'hex-outline', label: 'Hex outline', group: 'fafo' },
    { id: 'circuit', label: 'Circuit board', group: 'fafo' },
    { id: 'circuit-nodes', label: 'Circuit nodes', group: 'fafo' },
    { id: 'star-8', label: 'Star lattice', group: 'fafo' },
    { id: 'plus-grid', label: 'Plus grid', group: 'fafo' },
    { id: 'plus', label: 'Plus marks', group: 'fafo' },
    { id: 'scanlines', label: 'Scanlines', group: 'fafo' },
    { id: 'carbon', label: 'Carbon fiber', group: 'fafo' },
    { id: 'herringbone', label: 'Herringbone', group: 'fafo' },
    { id: 'argyle', label: 'Argyle', group: 'fafo' },
    { id: 'micro-grid', label: 'Micro grid', group: 'fafo' },
  ];

  function clamp(n, a, b) {
    const x = Number(n);
    if (!Number.isFinite(x)) return a;
    return Math.min(b, Math.max(a, x));
  }

  function normKey(tag) {
    return String(tag || '').trim().toLowerCase();
  }

  function isHex(c) {
    return typeof c === 'string' && /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.test(c.trim());
  }

  function expandHex(c) {
    const h = String(c || '').trim();
    if (/^#[0-9a-f]{3}$/i.test(h)) {
      return '#' + h[1] + h[1] + h[2] + h[2] + h[3] + h[3];
    }
    if (/^#[0-9a-f]{8}$/i.test(h)) return h.toLowerCase().slice(0, 7); // drop alpha channel in hex storage
    return h.toLowerCase();
  }

  function hexToRgb(hex) {
    const h = expandHex(hex).slice(1);
    return {
      r: parseInt(h.slice(0, 2), 16),
      g: parseInt(h.slice(2, 4), 16),
      b: parseInt(h.slice(4, 6), 16),
    };
  }

  function rgba(hex, alpha) {
    try {
      const { r, g, b } = hexToRgb(hex);
      const a = clamp(alpha == null ? 1 : alpha, 0, 1);
      return `rgba(${r},${g},${b},${a})`;
    } catch {
      return hex || '#00e5ff';
    }
  }

  function parseCssRgba(color) {
    const m = String(color || '').match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+))?\s*\)/i);
    if (!m) return null;
    return { r: +m[1], g: +m[2], b: +m[3], a: m[4] != null ? +m[4] : 1 };
  }

  /** Interpolate two rgba() (or hex) colors in sRGB — actual mix, not a hard slice. */
  function mixCssColor(c1, c2, t) {
    const u = clamp(t, 0, 1);
    const a = parseCssRgba(c1);
    const b = parseCssRgba(c2);
    if (a && b) {
      return `rgba(${Math.round(a.r + (b.r - a.r) * u)},${Math.round(a.g + (b.g - a.g) * u)},${Math.round(a.b + (b.b - a.b) * u)},${(a.a + (b.a - a.a) * u).toFixed(3)})`;
    }
    return `color-mix(in srgb, ${c1} ${Math.round((1 - u) * 100)}%, ${c2})`;
  }

  function contrastFg(hex, alpha) {
    try {
      const { r, g, b } = hexToRgb(hex);
      const a = alpha == null ? 1 : clamp(alpha, 0, 1);
      // blend on dark background for readability
      const br = r * a;
      const bg = g * a;
      const bb = b * a;
      const y = (0.299 * br + 0.587 * bg + 0.114 * bb) / 255;
      return y > 0.45 ? '#0a0a10' : '#ffffff';
    } catch {
      return '#ffffff';
    }
  }

  function defaultSlot(i, hex, name) {
    const c = expandHex(hex || DEFAULT_HEXES[i % DEFAULT_HEXES.length]);
    const c2 = DEFAULT_HEXES[(i + 3) % DEFAULT_HEXES.length];
    const c3 = DEFAULT_HEXES[(i + 7) % DEFAULT_HEXES.length];
    const n = name || DEFAULT_SLOT_NAMES[i] || `Slot ${i + 1}`;
    return {
      id: `slot-${i + 1}`,
      name: n,
      // global = one look for all themes; per-theme = overrides live under each theme id
      scope: 'global',
      // solid | gradient | pattern
      fillMode: 'solid',
      // Color stops (paint-style: each color has its own opacity 0–1)
      fillA: c,
      fillB: c2,
      fillC: c3,
      fillAlpha: 0.95,   // opacity of color 1
      fillAlphaB: 0.85,  // opacity of color 2
      fillAlphaC: 0.7,   // opacity of color 3
      // How many colors are active in gradient/pattern (1–3)
      fillColorCount: 2,
      borderMode: 'solid', // solid | gradient | pattern | match-fill
      borderA: c,
      borderB: '#ffffff',
      borderC: c2,
      borderAlpha: 1,
      borderAlphaB: 0.85,
      borderAlphaC: 0.7,
      borderColorCount: 1,
      // Gradient blend
      gradientDir: 'to bottom right',
      gradientPattern: 'linear', // linear | radial | conic
      // Softness of blend between stops (0 = hard edge, 100 = very soft)
      blendSoftness: 55,
      // Legacy mid stop (still used as position of color 2 in multi-stop)
      gradientStop: 50,
      // Position of color 3 when using 3 stops (0–100)
      gradientStopC: 80,
      // Tile text: inherit global type · auto contrast · custom · theme · gradient
      textMode: 'inherit',
      textColor: '#ffffff',
      // On-clip / selected text (empty = use chosen-style or idle text)
      textOnMode: 'inherit',
      textColorOn: '#041018',
      // Optional pill behind the letters (library chips already default to a dark bubble)
      textBubble: 'auto', // auto | off | solid | gradient
      textBubbleA: '#000000',
      textBubbleB: '#1a1a24',
      textBubbleAlpha: 0.62,
      // Tiling pattern
      tilePattern: 'stripes-h',
      // Pattern cell size in px (scalable tile)
      tileScale: 16,
      // Second tiling factor: zoom multiplier (0.25–4) and rotation (deg)
      tileZoom: 1,
      tileRotate: 0,
    };
  }

  function sanitizeSlot(raw, i) {
    const base = defaultSlot(i);
    if (!raw || typeof raw !== 'object') {
      if (isHex(raw)) return defaultSlot(i, raw);
      return base;
    }
    const s = { ...base, ...raw };
    s.id = String(s.id || base.id);
    s.name = String(s.name || base.name).trim() || base.name;
    s.scope = s.scope === 'per-theme' ? 'per-theme' : 'global';
    s.fillMode = ['solid', 'gradient', 'pattern'].includes(s.fillMode) ? s.fillMode : 'solid';
    s.borderMode = ['solid', 'gradient', 'pattern', 'match-fill'].includes(s.borderMode)
      ? s.borderMode
      : 'solid';
    s.fillA = isHex(s.fillA) ? expandHex(s.fillA) : base.fillA;
    s.fillB = isHex(s.fillB) ? expandHex(s.fillB) : base.fillB;
    s.fillC = isHex(s.fillC) ? expandHex(s.fillC) : base.fillC;
    s.borderA = isHex(s.borderA) ? expandHex(s.borderA) : base.borderA;
    s.borderB = isHex(s.borderB) ? expandHex(s.borderB) : base.borderB;
    s.borderC = isHex(s.borderC) ? expandHex(s.borderC) : base.borderC;
    s.fillAlpha = clamp(s.fillAlpha, 0, 1);
    s.fillAlphaB = clamp(s.fillAlphaB, 0, 1);
    s.fillAlphaC = clamp(s.fillAlphaC, 0, 1);
    s.borderAlpha = clamp(s.borderAlpha, 0, 1);
    s.borderAlphaB = clamp(s.borderAlphaB, 0, 1);
    s.borderAlphaC = clamp(s.borderAlphaC, 0, 1);
    s.fillColorCount = Math.round(clamp(s.fillColorCount ?? 2, 1, 3));
    s.borderColorCount = Math.round(clamp(s.borderColorCount ?? 1, 1, 3));
    s.gradientDir = String(s.gradientDir || base.gradientDir);
    s.gradientPattern = ['linear', 'radial', 'conic'].includes(s.gradientPattern)
      ? s.gradientPattern
      : 'linear';
    s.blendSoftness = clamp(s.blendSoftness ?? s.gradientStop ?? 55, 0, 100);
    s.gradientStop = clamp(s.gradientStop, 0, 100);
    s.gradientStopC = clamp(s.gradientStopC ?? 80, 0, 100);
    const tileIds = TILE_PATTERNS.map((p) => p.id);
    s.tilePattern = tileIds.includes(s.tilePattern) ? s.tilePattern : 'stripes-h';
    s.tileScale = Math.round(clamp(s.tileScale ?? 16, 2, 192));
    s.tileZoom = clamp(s.tileZoom ?? 1, 0.25, 4);
    s.tileRotate = Math.round(clamp(s.tileRotate ?? 0, 0, 359));
    s.textMode = ['inherit', 'auto', 'custom', 'theme', 'gradient'].includes(s.textMode) ? s.textMode : 'inherit';
    s.textColor = isHex(s.textColor) ? expandHex(s.textColor) : base.textColor;
    s.textOnMode = ['inherit', 'auto', 'custom', 'theme', 'gradient'].includes(s.textOnMode) ? s.textOnMode : 'inherit';
    s.textColorOn = isHex(s.textColorOn) ? expandHex(s.textColorOn) : base.textColorOn;
    s.textBubble = ['auto', 'off', 'solid', 'gradient'].includes(s.textBubble) ? s.textBubble : 'auto';
    s.textBubbleA = isHex(s.textBubbleA) ? expandHex(s.textBubbleA) : base.textBubbleA;
    s.textBubbleB = isHex(s.textBubbleB) ? expandHex(s.textBubbleB) : base.textBubbleB;
    s.textBubbleAlpha = clamp(s.textBubbleAlpha ?? 0.62, 0, 1);
    return s;
  }

  function ensureMinSlots(list) {
    const out = (Array.isArray(list) ? list : []).map((s, i) => sanitizeSlot(s, i));
    while (out.length < MIN_SLOTS) {
      out.push(defaultSlot(out.length));
    }
    return out;
  }

  function migrateLegacyPresets(list) {
    // Old format: string[] of hex
    if (!Array.isArray(list) || !list.length) return ensureMinSlots([]);
    if (typeof list[0] === 'string' && isHex(list[0])) {
      return ensureMinSlots(
        list.map((hex, i) => defaultSlot(i, hex, DEFAULT_SLOT_NAMES[i]))
      );
    }
    return ensureMinSlots(list);
  }

  /** @type {ReturnType<typeof defaultSlot>[]} baseline (global) slots */
  let slots = ensureMinSlots([]);
  /** @type {Record<string, Record<string, object>>} themeId → slotIndex → partial overrides */
  let themeOverlays = {};

  function currentThemeId() {
    try {
      if (global.FAFOTagThemes?.current) {
        const c = global.FAFOTagThemes.current();
        if (c?.id) return String(c.id);
      }
      if (typeof document !== 'undefined' && document.body?.dataset?.tagTheme) {
        return document.body.dataset.tagTheme;
      }
    } catch (_) {}
    return 'cyan-ops';
  }

  /**
   * True interpolating gradient (paint blend), not hard color slices.
   * Each stop is a peak of that color; CSS + extra mix samples melt into neighbors.
   * softness 0 = knife edge at midpoints; 100 = full melt across each span.
   * stops: [{ color, pos }] pos 0–100
   */
  function buildSoftGradient(shape, dir, stops, softness) {
    const soft = clamp(softness, 0, 100) / 100;
    const sorted = (stops || [])
      .filter((t) => t && t.color)
      .map((t) => ({ color: t.color, pos: clamp(t.pos, 0, 100) }))
      .sort((a, b) => a.pos - b.pos);
    if (!sorted.length) return 'transparent';
    if (sorted.length === 1) return sorted[0].color;

    // First at 0%, last at 100% — the chip is a melt, not leftover solid bars.
    const first = { color: sorted[0].color, pos: 0 };
    const last = { color: sorted[sorted.length - 1].color, pos: 100 };
    const mids = sorted.slice(1, -1).map((t) => ({ color: t.color, pos: t.pos }));
    const pts = mids.length ? [first, ...mids, last] : [first, last];
    for (let i = 1; i < pts.length; i += 1) {
      if (pts[i].pos <= pts[i - 1].pos) pts[i].pos = Math.min(100, pts[i - 1].pos + 2);
    }
    pts[pts.length - 1].pos = 100;
    // 2-color: Color 2 peak slider is the 50/50 mix point across the full tile.
    const mixBias = !mids.length && sorted.length >= 2 ? clamp(sorted[sorted.length - 1].pos, 5, 95) : null;

    const parts = [];
    const emitSpan = (a, b, from, to) => {
      const samples = soft < 0.03 ? 0 : 1 + Math.round(soft * 5);
      parts.push(`${a} ${from.toFixed(1)}%`);
      for (let s = 1; s <= samples; s += 1) {
        const u = s / (samples + 1);
        const pos = from + (to - from) * u;
        parts.push(`${mixCssColor(a, b, u)} ${pos.toFixed(1)}%`);
      }
    };

    if (soft < 0.03) {
      pts.forEach((t, i) => {
        if (i === 0) {
          parts.push(`${t.color} 0%`);
          return;
        }
        const cut = mixBias != null && i === 1 ? mixBias : (pts[i - 1].pos + t.pos) / 2;
        parts.push(`${pts[i - 1].color} ${cut.toFixed(1)}%`);
        parts.push(`${t.color} ${cut.toFixed(1)}%`);
      });
      parts.push(`${pts[pts.length - 1].color} 100%`);
    } else if (mixBias != null) {
      const mid = mixCssColor(first.color, last.color, 0.5);
      const rebuilt = [`${first.color} 0%`];
      const samples = 1 + Math.round(soft * 5);
      for (let s = 1; s <= samples; s += 1) {
        const u = s / (samples + 1);
        rebuilt.push(`${mixCssColor(first.color, mid, u)} ${(mixBias * u).toFixed(1)}%`);
      }
      rebuilt.push(`${mid} ${mixBias.toFixed(1)}%`);
      for (let s = 1; s <= samples; s += 1) {
        const u = s / (samples + 1);
        rebuilt.push(`${mixCssColor(mid, last.color, u)} ${(mixBias + (100 - mixBias) * u).toFixed(1)}%`);
      }
      rebuilt.push(`${last.color} 100%`);
      parts.length = 0;
      parts.push(...rebuilt);
    } else {
      pts.forEach((t, i) => {
        if (i >= pts.length - 1) {
          parts.push(`${t.color} 100%`);
          return;
        }
        emitSpan(t.color, pts[i + 1].color, t.pos, pts[i + 1].pos);
      });
    }

    const toConic = (list) => list.map((p) => p.replace(/([\d.]+)%\s*$/, (_, n) => `${((+n / 100) * 360).toFixed(1)}deg`));

    if (shape === 'radial') {
      return `radial-gradient(circle at center, ${parts.join(', ')})`;
    }
    if (shape === 'conic') {
      return `conic-gradient(from 0deg, ${toConic(parts).join(', ')})`;
    }
    return `linear-gradient(${dir || 'to right'}, ${parts.join(', ')})`;
  }

  function stopsFromSlot(s, which) {
    // which: 'fill' | 'border'
    const count = which === 'border' ? s.borderColorCount : s.fillColorCount;
    const n = Math.round(clamp(count, 1, 3));
    if (which === 'border') {
      const list = [
        { color: rgba(s.borderA, s.borderAlpha), pos: 0 },
        { color: rgba(s.borderB, s.borderAlphaB), pos: s.gradientStop },
        { color: rgba(s.borderC, s.borderAlphaC), pos: s.gradientStopC },
      ];
      return list.slice(0, n);
    }
    const list = [
      { color: rgba(s.fillA, s.fillAlpha), pos: 0 },
      { color: rgba(s.fillB, s.fillAlphaB), pos: s.gradientStop },
      { color: rgba(s.fillC, s.fillAlphaC), pos: s.gradientStopC },
    ];
    return list.slice(0, n);
  }

  /**
   * Scalable tiling pattern using up to 3 colors (each with its own opacity).
   * Returns { image, size, repeat, position, color } for applyStyleToEl.
   * CRITICAL: background-image may only contain gradients/urls — never raw rgba()
   * base colors (those go in `color` → background-color). Never embed size/pos
   * inside the image string when using separate size/position properties.
   */
  function buildTilePattern(s) {
    if (global.FAFOTilePatterns && typeof global.FAFOTilePatterns.build === 'function') {
      return global.FAFOTilePatterns.build(s);
    }
    const zoom = clamp(s.tileZoom ?? 1, 0.25, 4);
    const scale = Math.round(clamp((s.tileScale ?? 16) * zoom, 2, 256));
    const c1 = rgba(s.fillA, s.fillAlpha);
    const c2 = rgba(s.fillB, s.fillAlphaB);
    const c3 = rgba(s.fillC, s.fillAlphaC);
    const n = Math.round(clamp(s.fillColorCount, 1, 3));
    const a = c1;
    const b = n >= 2 ? c2 : c1;
    const c = n >= 3 ? c3 : b;
    const id = s.tilePattern || 'stripes-h';
    const sz = `${scale}px ${scale}px`;
    const sz2 = `${scale * 2}px ${scale * 2}px`;
    const half = Math.max(1, Math.round(scale / 2));
    const third = Math.max(1, Math.round(scale / 3));
    const line = Math.max(1, Math.round(scale * 0.12));
    const lineThin = Math.max(1, Math.round(scale * 0.06));

    /** @param {string|string[]} image @param {string} [size] @param {string} [color] @param {string} [position] */
    const pack = (image, size = sz, color = a, position = '0 0', repeat = 'repeat') => {
      const img = Array.isArray(image) ? image.filter(Boolean).join(', ') : String(image || '');
      const layers = img ? img.split(',').length : 0;
      let sizeOut = size;
      // Expand single size to N layers so multi-background always tiles
      if (layers > 1 && size && !String(size).includes(',')) {
        sizeOut = Array(layers).fill(size).join(', ');
      }
      let posOut = position;
      if (layers > 1 && position && !String(position).includes(',')) {
        posOut = Array(layers).fill(position).join(', ');
      }
      return {
        image: img,
        size: sizeOut,
        repeat: repeat || 'repeat',
        position: posOut,
        color: color || a,
        css: img,
      };
    };

    const stripe = (angle, band) => {
      const w = Math.max(1, Math.round(scale * band));
      if (n < 3) {
        return pack(
          `repeating-linear-gradient(${angle}, ${a} 0 ${w}px, ${b} ${w}px ${scale}px)`,
          sz,
          a
        );
      }
      return pack(
        `repeating-linear-gradient(${angle}, ${a} 0 ${third}px, ${b} ${third}px ${third * 2}px, ${c} ${third * 2}px ${scale}px)`,
        sz,
        a
      );
    };

    switch (id) {
      case 'stripes-h': return stripe('0deg', 0.5);
      case 'stripes-v': return stripe('90deg', 0.5);
      case 'stripes-diag': return stripe('45deg', 0.5);
      case 'stripes-diag2': return stripe('-45deg', 0.5);
      case 'stripes-thick': return stripe('90deg', 0.72);
      case 'stripes-thin': return stripe('90deg', 0.22);
      case 'bars-3': return stripe('0deg', 0.33);
      case 'checker':
      case 'checker-sm': {
        const cell = id === 'checker-sm' ? Math.max(4, half) : scale;
        const cellSz = `${cell * 2}px ${cell * 2}px`;
        if (n >= 3) {
          return pack(
            [
              `repeating-conic-gradient(${a} 0% 25%, ${b} 0% 50%)`,
              `repeating-linear-gradient(45deg, ${c} 0 ${Math.max(1, Math.round(cell / 6))}px, transparent ${Math.max(1, Math.round(cell / 6))}px ${cell}px)`,
            ],
            cellSz,
            a
          );
        }
        return pack(`repeating-conic-gradient(${a} 0% 25%, ${b} 0% 50%)`, cellSz, a);
      }
      case 'pixel':
        return pack(
          `repeating-conic-gradient(${a} 0% 25%, ${b} 0% 50%, ${c} 0% 75%, ${a} 0% 100%)`,
          `${half}px ${half}px`,
          a
        );
      case 'bricks': {
        const bh = half;
        const bw = scale;
        return pack(
          [
            `linear-gradient(${a} 50%, ${b} 50%)`,
            `linear-gradient(${c} 50%, ${a} 50%)`,
          ],
          `${bw}px ${bh * 2}px, ${bw}px ${bh * 2}px`,
          a,
          `0 0, ${Math.round(bw / 2)}px ${bh}px`
        );
      }
      case 'grid':
        return pack(
          [
            `linear-gradient(to right, ${b} ${lineThin}px, transparent ${lineThin}px)`,
            `linear-gradient(to bottom, ${b} ${lineThin}px, transparent ${lineThin}px)`,
          ],
          sz,
          a
        );
      case 'grid-bold':
        return pack(
          [
            `linear-gradient(to right, ${b} ${line}px, transparent ${line}px)`,
            `linear-gradient(to bottom, ${c} ${line}px, transparent ${line}px)`,
          ],
          sz,
          a
        );
      case 'crosshatch':
        return pack(
          [
            `repeating-linear-gradient(45deg, ${b} 0 ${lineThin}px, transparent ${lineThin}px ${scale}px)`,
            `repeating-linear-gradient(-45deg, ${c} 0 ${lineThin}px, transparent ${lineThin}px ${scale}px)`,
          ],
          sz,
          a
        );
      case 'crosshatch-dense':
        return pack(
          [
            `repeating-linear-gradient(45deg, ${b} 0 ${lineThin}px, transparent ${lineThin}px ${half}px)`,
            `repeating-linear-gradient(-45deg, ${c} 0 ${lineThin}px, transparent ${lineThin}px ${half}px)`,
          ],
          `${half}px ${half}px`,
          a
        );
      case 'dots':
      case 'dots-loose':
      case 'dots-dense': {
        const r =
          id === 'dots-loose' ? Math.max(1, scale * 0.16)
            : id === 'dots-dense' ? Math.max(1, scale * 0.32)
              : Math.max(1, scale * 0.24);
        const step =
          id === 'dots-loose' ? scale * 1.5
            : id === 'dots-dense' ? scale * 0.75
              : scale;
        return pack(
          `radial-gradient(circle ${r.toFixed(1)}px at 50% 50%, ${b} 96%, transparent 100%)`,
          `${Math.round(step)}px ${Math.round(step)}px`,
          a
        );
      }
      case 'rings': {
        const r1 = Math.max(2, scale * 0.2);
        const r2 = Math.max(3, scale * 0.32);
        return pack(
          `radial-gradient(circle, transparent ${r1}px, ${b} ${r1}px, ${b} ${r2}px, transparent ${r2}px)`,
          sz,
          a
        );
      }
      case 'diamonds':
        return pack(
          [
            `repeating-linear-gradient(45deg, ${a} 0 ${half}px, ${b} ${half}px ${scale}px)`,
            `repeating-linear-gradient(-45deg, transparent 0 ${half}px, ${c} ${half}px ${scale}px)`,
          ],
          sz,
          a
        );
      case 'diamonds-outline':
        return pack(
          [
            `linear-gradient(45deg, ${b} ${lineThin}px, transparent ${lineThin}px)`,
            `linear-gradient(-45deg, ${b} ${lineThin}px, transparent ${lineThin}px)`,
          ],
          sz,
          a
        );
      case 'triangles':
        return pack(
          [
            `linear-gradient(45deg, ${b} 50%, transparent 50%)`,
            `linear-gradient(-45deg, ${c} 50%, transparent 50%)`,
          ],
          sz,
          a
        );
      case 'triangles-flip':
        return pack(
          [
            `linear-gradient(135deg, ${b} 50%, transparent 50%)`,
            `linear-gradient(225deg, ${c} 50%, transparent 50%)`,
          ],
          sz,
          a
        );
      case 'chevron':
        return pack(
          [
            `repeating-linear-gradient(135deg, ${a} 0 ${half}px, ${b} ${half}px ${scale}px)`,
            `repeating-linear-gradient(45deg, ${a} 0 ${half}px, ${c} ${half}px ${scale}px)`,
          ],
          sz,
          a
        );
      case 'chevron-v':
        return pack(
          [
            `repeating-linear-gradient(45deg, ${a} 0 ${half}px, ${b} ${half}px ${scale}px)`,
            `repeating-linear-gradient(135deg, ${a} 0 ${half}px, ${c} ${half}px ${scale}px)`,
          ],
          sz,
          a
        );
      case 'zigzag':
        return pack(
          [
            `linear-gradient(135deg, ${b} 25%, transparent 25%)`,
            `linear-gradient(225deg, ${b} 25%, transparent 25%)`,
            `linear-gradient(315deg, ${b} 25%, transparent 25%)`,
            `linear-gradient(45deg, ${b} 25%, transparent 25%)`,
          ],
          `${sz2}, ${sz2}, ${sz2}, ${sz2}`,
          a,
          `-${half}px 0, -${half}px 0, 0 0, 0 0`
        );
      case 'plaid':
      case 'plaid-fine': {
        const t = id === 'plaid-fine' ? Math.max(1, Math.round(scale / 6)) : Math.max(1, Math.round(scale / 4));
        const cell = id === 'plaid-fine' ? half : scale;
        return pack(
          [
            `repeating-linear-gradient(90deg, ${b} 0 ${t}px, transparent ${t}px ${cell}px)`,
            `repeating-linear-gradient(0deg, ${c} 0 ${t}px, transparent ${t}px ${cell}px)`,
          ],
          `${cell}px ${cell}px`,
          a
        );
      }
      case 'weave':
        return pack(
          [
            `linear-gradient(90deg, ${a} 50%, ${b} 50%)`,
            `linear-gradient(0deg, ${c} 50%, transparent 50%)`,
          ],
          `${sz}, ${half}px ${half}px`,
          a
        );
      case 'honey':
        return pack(
          [
            `radial-gradient(circle closest-side at 50% 50%, ${b} 96%, transparent 100%)`,
            `radial-gradient(circle closest-side at 50% 50%, ${c} 96%, transparent 100%)`,
          ],
          `${sz}, ${sz}`,
          a,
          `0 0, ${half}px ${half}px`
        );
      case 'waves':
        return pack(
          `repeating-radial-gradient(circle at 0 50%, transparent 0, transparent ${scale * 0.3}px, ${b} ${scale * 0.3}px, ${b} ${scale * 0.42}px, transparent ${scale * 0.42}px, transparent ${scale}px)`,
          `${scale * 2}px ${scale}px`,
          a
        );
      case 'scales':
        return pack(
          [
            `radial-gradient(circle at 50% 0, ${b} 40%, transparent 41%)`,
            `radial-gradient(circle at 0 50%, ${c} 40%, transparent 41%)`,
            `radial-gradient(circle at 100% 50%, ${c} 40%, transparent 41%)`,
          ],
          sz,
          a
        );
      case 'confetti':
        return pack(
          [
            `radial-gradient(circle at 20% 30%, ${b} 0 12%, transparent 13%)`,
            `radial-gradient(circle at 70% 60%, ${c} 0 10%, transparent 11%)`,
            `radial-gradient(circle at 40% 80%, ${b} 0 8%, transparent 9%)`,
            `radial-gradient(circle at 85% 25%, ${c} 0 9%, transparent 10%)`,
          ],
          sz2,
          a
        );
      case 'noise':
        return pack(
          `repeating-conic-gradient(${a} 0% 12%, ${b} 0% 18%, ${a} 0% 30%, ${c} 0% 36%, ${a} 0% 50%)`,
          `${Math.max(3, Math.round(scale / 3))}px ${Math.max(3, Math.round(scale / 3))}px`,
          a
        );
      default:
        return stripe('0deg', 0.5);
    }
  }

  function styleFromSlot(slot) {
    const s = sanitizeSlot(slot, 0);
    let fill;
    let fillSpec = null; // { image, size, repeat, position }
    if (s.fillMode === 'pattern') {
      fillSpec = buildTilePattern(s);
      fill = fillSpec.image;
    } else if (s.fillMode === 'gradient') {
      fill = buildSoftGradient(
        s.gradientPattern,
        s.gradientDir,
        stopsFromSlot(s, 'fill'),
        s.blendSoftness
      );
    } else {
      fill = rgba(s.fillA, s.fillAlpha);
    }

    let border;
    let borderSpec = null;
    if (s.borderMode === 'match-fill') {
      if (s.fillMode === 'pattern') {
        border = rgba(s.fillA, s.borderAlpha);
      } else if (s.fillMode === 'gradient') {
        border = buildSoftGradient(
          s.gradientPattern,
          s.gradientDir,
          stopsFromSlot(s, 'fill').map((t, i) => ({
            color: i === 0
              ? rgba(s.fillA, s.borderAlpha)
              : i === 1
                ? rgba(s.fillB, s.borderAlphaB)
                : rgba(s.fillC, s.borderAlphaC),
            pos: t.pos,
          })),
          s.blendSoftness
        );
      } else {
        border = rgba(s.fillA, s.borderAlpha);
      }
    } else if (s.borderMode === 'pattern') {
      borderSpec = buildTilePattern({
        ...s,
        fillA: s.borderA,
        fillB: s.borderB,
        fillC: s.borderC,
        fillAlpha: s.borderAlpha,
        fillAlphaB: s.borderAlphaB,
        fillAlphaC: s.borderAlphaC,
        fillColorCount: s.borderColorCount,
      });
      border = borderSpec.image;
    } else if (s.borderMode === 'gradient') {
      border = buildSoftGradient(
        s.gradientPattern,
        s.gradientDir,
        stopsFromSlot(s, 'border'),
        s.blendSoftness
      );
    } else {
      border = rgba(s.borderA, s.borderAlpha);
    }

    const primary = s.fillA;
    const fg = resolveFg(s, primary, s.fillAlpha);
    let fgGradient = null;
    if (s.textMode === 'gradient') {
      fgGradient = buildSoftGradient(
        s.gradientPattern || 'linear',
        s.gradientDir || 'to right',
        [
          { color: rgba(s.textColor || s.fillA, 1), pos: 0 },
          { color: rgba(s.fillB || s.textColorOn || '#ffffff', 1), pos: 100 },
        ],
        s.blendSoftness ?? 55
      );
    }
    let bubble = null;
    if (s.textBubble === 'off') {
      bubble = 'transparent';
    } else if (s.textBubble === 'solid') {
      bubble = rgba(s.textBubbleA, s.textBubbleAlpha);
    } else if (s.textBubble === 'gradient') {
      bubble = buildSoftGradient(
        'linear',
        'to right',
        [
          { color: rgba(s.textBubbleA, s.textBubbleAlpha), pos: 0 },
          { color: rgba(s.textBubbleB, s.textBubbleAlpha), pos: 100 },
        ],
        50
      );
    }
    return {
      fill,
      fillSpec,
      border,
      borderSpec,
      primary,
      fg,
      fgGradient,
      bubble,
      bubbleMode: s.textBubble || 'auto',
      boxShadow: `0 0 10px ${rgba(primary, 0.35)}`,
      slot: s,
    };
  }

  /** Apply a style object (from styleFromSlot) onto an element — handles pattern size/repeat. */
  function applyStyleToEl(el, st, opts = {}) {
    if (!el || !st) return;
    el.classList.add('has-custom-color');
    const typeFont = (getTypeStyle().font || '').trim();
    if (typeFont) el.style.setProperty('font-family', typeFont, 'important');
    else el.style.removeProperty('font-family');
    el.style.setProperty(
      'box-shadow',
      opts.onVideo ? st.boxShadow : `inset 0 0 0 1px ${rgba(st.primary, 0.4)}`,
      'important'
    );

    el.style.setProperty('color', st.fg, 'important');
    const nameEl = el.querySelector?.('.meta-lib-name');
    if (nameEl && st.fgGradient) {
      nameEl.style.backgroundImage = st.fgGradient;
      nameEl.style.webkitBackgroundClip = 'text';
      nameEl.style.backgroundClip = 'text';
      nameEl.style.color = 'transparent';
      nameEl.style.webkitTextFillColor = 'transparent';
    } else if (nameEl) {
      nameEl.style.backgroundImage = '';
      nameEl.style.webkitBackgroundClip = '';
      nameEl.style.backgroundClip = '';
      nameEl.style.webkitTextFillColor = '';
      nameEl.style.color = '';
    }

    const rot = Number(st.fillSpec?.rotate || st.slot?.tileRotate || 0) || 0;
    const useRotate = Math.abs(rot) >= 1;
    el.classList.toggle('has-tile-rotate', useRotate);
    if (useRotate) {
      el.style.setProperty('--fafo-tile-rot', rot + 'deg');
    } else {
      el.style.removeProperty('--fafo-tile-rot');
    }

    if (st.bubbleMode === 'off') {
      el.classList.add('tag-bubble-off');
      el.classList.remove('tag-bubble-on');
      el.style.setProperty('--tag-label-bg', 'transparent');
    } else if (st.bubble) {
      el.classList.add('tag-bubble-on');
      el.classList.remove('tag-bubble-off');
      el.style.setProperty('--tag-label-bg', st.bubble);
    } else {
      el.classList.remove('tag-bubble-on', 'tag-bubble-off');
      el.style.removeProperty('--tag-label-bg');
    }

    const applyFill = (target) => {
      if (st.fillSpec && st.fillSpec.image) {
        const base = st.fillSpec.color || st.primary || 'transparent';
        target.style.removeProperty('background');
        target.style.setProperty('background-color', base, 'important');
        target.style.setProperty('background-image', st.fillSpec.image, 'important');
        target.style.setProperty('background-size', st.fillSpec.size || '16px 16px', 'important');
        target.style.setProperty('background-repeat', st.fillSpec.repeat || 'repeat', 'important');
        target.style.setProperty('background-position', st.fillSpec.position || '0 0', 'important');
      } else if (typeof st.fill === 'string' && st.fill.includes('gradient')) {
        target.style.removeProperty('background');
        target.style.setProperty('background-color', 'transparent', 'important');
        target.style.setProperty('background-image', st.fill, 'important');
        target.style.setProperty('background-size', '100% 100%', 'important');
        target.style.setProperty('background-repeat', 'no-repeat', 'important');
        target.style.setProperty('background-position', '0 0', 'important');
      } else {
        target.style.setProperty('background', st.fill, 'important');
        target.style.setProperty('background-image', 'none', 'important');
        target.style.removeProperty('background-size');
        target.style.removeProperty('background-repeat');
        target.style.removeProperty('background-position');
      }
    };

    if (useRotate && st.fillSpec && st.fillSpec.image) {
      el.style.setProperty('--fafo-tile-img', st.fillSpec.image);
      el.style.setProperty('--fafo-tile-size', st.fillSpec.size || '16px 16px');
      el.style.setProperty('--fafo-tile-pos', st.fillSpec.position || '0 0');
      el.style.setProperty('background-color', st.fillSpec.color || st.primary || 'transparent', 'important');
      el.style.setProperty('background-image', 'none', 'important');
    } else {
      el.style.removeProperty('--fafo-tile-img');
      el.style.removeProperty('--fafo-tile-size');
      el.style.removeProperty('--fafo-tile-pos');
      applyFill(el);
    }

    const isGradBorder = typeof st.border === 'string' && st.border.includes('gradient');
    if (st.borderSpec && st.borderSpec.image) {
      // Pattern borders: approximate with solid primary of pattern
      el.style.setProperty('border-image', 'none', 'important');
      el.style.setProperty('border-color', st.primary, 'important');
      el.style.setProperty('border-style', 'solid', 'important');
    } else if (isGradBorder) {
      el.style.setProperty('border-color', 'transparent', 'important');
      el.style.setProperty('border-image', `${st.border} 1`, 'important');
    } else {
      el.style.setProperty('border-image', 'none', 'important');
      el.style.setProperty('border-color', st.border, 'important');
      el.style.setProperty('border-style', 'solid', 'important');
    }
  }

  function mergeTagOverSlot(slot, entry) {
    if (!entry || typeof entry !== 'object') return slot;
    const o = { ...slot };
    ['textMode', 'textColor', 'textOnMode', 'textColorOn', 'textBubble', 'textBubbleA', 'textBubbleB', 'textBubbleAlpha']
      .forEach((k) => {
        if (entry[k] != null && entry[k] !== '') o[k] = entry[k];
      });
    return o;
  }

  function resolveStyle(entry) {
    if (!entry) return null;
    if (typeof entry === 'string' && isHex(entry)) {
      const hex = expandHex(entry);
      return styleFromSlot({
        fillMode: 'solid',
        fillA: hex,
        fillAlpha: 0.9,
        borderMode: 'solid',
        borderA: hex,
        borderAlpha: 1,
      });
    }
    if (typeof entry === 'object') {
      if (Number.isFinite(entry.slot) || Number.isFinite(entry.slotIndex)) {
        const i = Number(entry.slot != null ? entry.slot : entry.slotIndex);
        const eff = getSlots()[i];
        if (eff) return styleFromSlot(mergeTagOverSlot(eff, entry));
      }
      if (entry.slotId) {
        const list = getSlots();
        const hit = list.find((s) => s.id === entry.slotId);
        if (hit) return styleFromSlot(mergeTagOverSlot(hit, entry));
      }
      // inline style / partial slot
      if (entry.fillA || entry.fillMode || entry.name || entry.textMode || entry.textColor) {
        return styleFromSlot(entry);
      }
    }
    return null;
  }

  async function load() {
    try {
      const KEY = colorsStorageKey();
      const res = await chrome.storage.local.get([
        KEY, PRESETS_KEY, SLOTS_KEY, THEME_SLOTS_KEY, CHOSEN_KEY, TYPE_KEY, RECENT_KEY,
      ]);
      const raw = res[KEY];
      map = raw && typeof raw === 'object' && !Array.isArray(raw) ? { ...raw } : {};

      if (Array.isArray(res[SLOTS_KEY]) && res[SLOTS_KEY].length) {
        slots = migrateLegacyPresets(res[SLOTS_KEY]);
      } else if (Array.isArray(res[PRESETS_KEY]) && res[PRESETS_KEY].length) {
        slots = migrateLegacyPresets(res[PRESETS_KEY]);
        // Persist migration to new key
        try {
          await chrome.storage.local.set({ [SLOTS_KEY]: slots });
        } catch (_) {}
      } else {
        slots = ensureMinSlots([]);
      }
      themeOverlays =
        res[THEME_SLOTS_KEY] && typeof res[THEME_SLOTS_KEY] === 'object' && !Array.isArray(res[THEME_SLOTS_KEY])
          ? res[THEME_SLOTS_KEY]
          : {};
      chosen = sanitizeChosen(res[CHOSEN_KEY]);
      typeStyle = sanitizeTypeStyle(res[TYPE_KEY]);
      recent = Array.isArray(res[RECENT_KEY]) ? res[RECENT_KEY].filter(Boolean).slice(0, RECENT_MAX) : [];
      loaded = true;
    } catch {
      map = {};
      slots = ensureMinSlots([]);
      themeOverlays = {};
      chosen = defaultChosen();
      typeStyle = defaultTypeStyle();
      recent = [];
      loaded = true;
    }
    syncPresetsExport();
    try { applyChosenCssVars(); } catch (_) {}
    try { applyTypeCssVars(); } catch (_) {}
    return map;
  }

  function syncPresetsExport() {
    // Back-compat: PRESETS as primary fill hex list
    if (Array.isArray(global.FAFOTagColors?.PRESETS)) {
      global.FAFOTagColors.PRESETS.length = 0;
      slots.forEach((s) => global.FAFOTagColors.PRESETS.push(s.fillA));
    }
  }

  async function save() {
    try {
      await chrome.storage.local.set({ [colorsStorageKey()]: map });
    } catch (e) {
      console.warn('FAFO tag colors save', e);
    }
  }

  /** Reload map when public ↔ private switches (slots stay global UI chrome). */
  async function reloadForSpace() {
    loaded = false;
    await load();
    try {
      // Force chips / library to pick up the other space's colors
      document.querySelectorAll('.meta-lib-tag, .meta-chip, .meta-hotkey-slot, .meta-recent-tag')
        .forEach((el) => {
          // leave styling to next render; clear inline color cache if any
          el.classList.remove('has-custom-color', 'has-chosen-style');
        });
    } catch (_) { /* ignore */ }
    return map;
  }

  // Swap color maps when FAFOMeta flips public/private
  try {
    window.addEventListener('fafo-space-changed', () => {
      reloadForSpace().catch(() => {});
    });
  } catch (_) { /* ignore */ }

  async function saveSlots() {
    try {
      await chrome.storage.local.set({
        [SLOTS_KEY]: slots.map((s, i) => sanitizeSlot(s, i)),
        [THEME_SLOTS_KEY]: themeOverlays,
        // Keep a hex list for any old readers
        [PRESETS_KEY]: slots.map((s) => s.fillA),
      });
      syncPresetsExport();
    } catch (e) {
      console.warn('FAFO tag color slots save', e);
    }
  }

  /**
   * Effective slots for a theme (merges global baseline + per-theme overlays).
   * @param {string} [themeId]
   */
  function getSlots(themeId) {
    const tid = themeId || currentThemeId();
    const ovRoot = themeOverlays[tid] || {};
    return slots.map((base, i) => {
      const b = sanitizeSlot(base, i);
      if (b.scope !== 'per-theme') {
        return { ...b, effectiveTheme: null, hasThemeOverride: false };
      }
      const ov = ovRoot[String(i)] || ovRoot[i];
      if (ov && typeof ov === 'object') {
        return {
          ...sanitizeSlot({ ...b, ...ov, scope: 'per-theme' }, i),
          effectiveTheme: tid,
          hasThemeOverride: true,
        };
      }
      // Per-theme slot with no override yet — show global baseline as starting point
      return { ...b, effectiveTheme: tid, hasThemeOverride: false };
    });
  }

  async function setSlots(list) {
    slots = ensureMinSlots(list);
    await saveSlots();
    return getSlots();
  }

  /**
   * Update a slot. Respects scope:
   *  - global → writes baseline for all themes
   *  - per-theme → writes overlay for the active theme only
   * Pass patch.scope to switch mode.
   */
  async function updateSlot(index, patch, opts = {}) {
    const i = Number(index);
    if (!Number.isFinite(i) || i < 0 || i >= slots.length) return getSlots();
    const tid = opts.themeId || currentThemeId();
    const nextScope =
      patch && patch.scope != null
        ? (patch.scope === 'per-theme' ? 'per-theme' : 'global')
        : slots[i].scope;

    if (nextScope === 'per-theme') {
      // Keep baseline (name can update on baseline for discoverability)
      const basePatch = {};
      if (patch?.name) basePatch.name = patch.name;
      basePatch.scope = 'per-theme';
      slots[i] = sanitizeSlot({ ...slots[i], ...basePatch }, i);

      if (!themeOverlays[tid] || typeof themeOverlays[tid] !== 'object') {
        themeOverlays[tid] = {};
      }
      const prevOv = themeOverlays[tid][String(i)] || {};
      // Store visual fields on the theme overlay (not scope flag)
      const { scope: _s, id: _id, ...visual } = patch || {};
      themeOverlays[tid][String(i)] = sanitizeSlot(
        { ...slots[i], ...prevOv, ...visual, scope: 'per-theme' },
        i
      );
    } else {
      // Global: write baseline; optional clear of this slot's theme overlays
      slots[i] = sanitizeSlot({ ...slots[i], ...(patch || {}), scope: 'global' }, i);
      if (opts.clearThemeOverlays !== false && patch?.scope === 'global') {
        Object.keys(themeOverlays).forEach((theme) => {
          if (themeOverlays[theme] && themeOverlays[theme][String(i)] != null) {
            delete themeOverlays[theme][String(i)];
          }
        });
      }
    }
    await saveSlots();
    return getSlots(tid);
  }

  async function setSlotScope(index, scope, opts = {}) {
    return updateSlot(index, { scope: scope === 'per-theme' ? 'per-theme' : 'global' }, opts);
  }

  function getThemeId() {
    return currentThemeId();
  }

  async function renameSlot(index, name) {
    return updateSlot(index, { name: String(name || '').trim() || slots[index]?.name });
  }

  async function addSlot(partial) {
    const i = slots.length;
    slots.push(sanitizeSlot(partial || defaultSlot(i), i));
    await saveSlots();
    return getSlots();
  }

  async function removeSlot(index) {
    const i = Number(index);
    if (!Number.isFinite(i) || i < 0 || i >= slots.length) return getSlots();
    if (slots.length <= MIN_SLOTS) return getSlots(); // keep minimum
    slots.splice(i, 1);
    // re-id for stability of display only
    slots = ensureMinSlots(slots);
    await saveSlots();
    return getSlots();
  }

  async function resetSlots() {
    slots = ensureMinSlots([]);
    await saveSlots();
    return getSlots();
  }

  // ─── Legacy preset API (hex list) ─────────────────────────────────────────

  function getPresets() {
    return slots.map((s) => s.fillA);
  }

  async function setPresets(list) {
    if (Array.isArray(list) && list.length && isHex(list[0])) {
      slots = migrateLegacyPresets(list);
    }
    await saveSlots();
    return getPresets();
  }

  async function addPreset(color) {
    if (!isHex(color)) return getPresets();
    await addSlot(defaultSlot(slots.length, color, `Slot ${slots.length + 1}`));
    return getPresets();
  }

  async function updatePreset(index, color) {
    if (!isHex(color)) return getPresets();
    await updateSlot(index, { fillA: expandHex(color), borderA: expandHex(color) });
    return getPresets();
  }

  async function removePreset(index) {
    await removeSlot(index);
    return getPresets();
  }

  async function resetPresets() {
    return resetSlots();
  }

  // ─── Tag → color mapping ──────────────────────────────────────────────────

  function get(tag) {
    const k = normKey(tag);
    if (!k) return null;
    const entry = map[k];
    if (!entry) return null;
    if (typeof entry === 'string' && isHex(entry)) return expandHex(entry);
    const st = resolveStyle(entry);
    return st ? st.primary : null;
  }

  function getStyle(tag) {
    const k = normKey(tag);
    if (!k) return null;
    return resolveStyle(map[k]);
  }

  function getEntry(tag) {
    const k = normKey(tag);
    return k ? map[k] ?? null : null;
  }

  async function set(tag, colorOrStyle) {
    const k = normKey(tag);
    if (!k) return null;
    if (colorOrStyle == null || colorOrStyle === '') {
      delete map[k];
      await save();
      return null;
    }
    if (typeof colorOrStyle === 'number' && Number.isFinite(colorOrStyle)) {
      map[k] = { slot: Math.floor(colorOrStyle) };
      await save();
      return get(tag);
    }
    if (typeof colorOrStyle === 'string' && isHex(colorOrStyle)) {
      map[k] = expandHex(colorOrStyle);
      await save();
      return map[k];
    }
    if (typeof colorOrStyle === 'object') {
      map[k] = colorOrStyle;
      await save();
      return get(tag);
    }
    return get(tag);
  }

  async function setSlotOnTag(tag, slotIndex) {
    const k = normKey(tag);
    const cur = k ? map[k] : null;
    const next = { slot: Number(slotIndex) };
    if (cur && typeof cur === 'object') {
      ['textMode', 'textColor', 'textOnMode', 'textColorOn', 'textBubble', 'textBubbleA', 'textBubbleB', 'textBubbleAlpha']
        .forEach((key) => {
          if (cur[key] != null && cur[key] !== '') next[key] = cur[key];
        });
    }
    return set(tag, next);
  }

  async function setTagTextOverride(tag, patch) {
    const k = normKey(tag);
    if (!k) return null;
    const cur = map[k];
    const base = (cur && typeof cur === 'object')
      ? { ...cur }
      : (typeof cur === 'number' ? { slot: cur } : (typeof cur === 'string' && isHex(cur) ? { fillA: cur, fillMode: 'solid' } : {}));
    Object.assign(base, patch || {});
    map[k] = base;
    await save();
    try { if (typeof document !== 'undefined') paintAll(document); } catch (_) {}
    return getEntry(tag);
  }

  async function clear(tag) {
    return set(tag, null);
  }

  /**
   * Clear every tag→color assignment (slots palette is kept).
   * Options-only UI should call this after user confirmation.
   * @returns {{ cleared: number }}
   */
  async function clearAllTagAssignments() {
    const n = Object.keys(map).length;
    map = {};
    await save();
    try {
      if (typeof document !== 'undefined') paintAll(document);
    } catch (_) {}
    return { cleared: n };
  }

  async function rename(fromTag, toTag) {
    const from = normKey(fromTag);
    const to = normKey(toTag);
    if (!from || !to || from === to) return;
    if (map[from]) {
      if (!map[to]) map[to] = map[from];
      delete map[from];
      await save();
    }
  }

  async function remove(tag) {
    return clear(tag);
  }

  async function setMany(tags, colorOrStyle) {
    const list = Array.isArray(tags) ? tags : [];
    let n = 0;
    for (const tag of list) {
      const k = normKey(tag);
      if (!k) continue;
      if (typeof colorOrStyle === 'number') {
        map[k] = { slot: Math.floor(colorOrStyle) };
      } else if (typeof colorOrStyle === 'string' && isHex(colorOrStyle)) {
        map[k] = expandHex(colorOrStyle);
      } else if (colorOrStyle && typeof colorOrStyle === 'object') {
        map[k] = colorOrStyle;
      } else continue;
      n++;
    }
    if (n) await save();
    return n;
  }

  function clearPaint(el) {
    if (!el) return;
    el.style.removeProperty('--tag-custom');
    el.style.removeProperty('--tag-custom-fg');
    el.style.removeProperty('--tag-custom-border');
    el.style.removeProperty('border-color');
    el.style.removeProperty('border-image');
    el.style.removeProperty('background');
    el.style.removeProperty('background-image');
    el.style.removeProperty('background-size');
    el.style.removeProperty('background-repeat');
    el.style.removeProperty('background-position');
    el.style.removeProperty('background-color');
    el.style.removeProperty('color');
    el.style.removeProperty('font-family');
    el.style.removeProperty('box-shadow');
    el.classList.remove('has-custom-color', 'has-chosen-style');
  }

  /**
   * Apply inline styles for a tag chip element.
   * When onVideo/chosen and global chosen style is enabled, that look wins
   * (so every on-clip tag reads clearly across library / hotkeys / HUD / chips).
   * @param {HTMLElement} el
   * @param {string} tag
   * @param {{ onVideo?: boolean, forceChosen?: boolean }} [opts]
   */
  function paint(el, tag, opts = {}) {
    if (!el) return;
    const on =
      opts.onVideo ||
      opts.forceChosen ||
      el.classList.contains('on-video') ||
      el.classList.contains('state-on-current');
    const ch = getChosen();
    const slotSt = getStyle(tag);

    // Chosen (on-clip) style — user-configurable, realtime, all fields
    if (on && ch.enabled) {
      const st = styleFromChosen(ch);
      const entry = getEntry(tag);
      const slot = slotSt?.slot;
      if (entry && entry.textOnMode === 'custom' && isHex(entry.textColorOn)) {
        st.fg = expandHex(entry.textColorOn);
      } else if (slot && slot.textOnMode === 'custom' && isHex(slot.textColorOn)) {
        st.fg = expandHex(slot.textColorOn);
      }
      if (slotSt && slotSt.bubbleMode && slotSt.bubbleMode !== 'auto') {
        st.bubble = slotSt.bubble;
        st.bubbleMode = slotSt.bubbleMode;
      }
      el.classList.add('has-custom-color', 'has-chosen-style');
      el.style.setProperty('--tag-custom', st.primary);
      el.style.setProperty('--tag-custom-fg', st.fg);
      el.style.setProperty(
        '--tag-custom-border',
        typeof st.border === 'string' ? st.border : st.primary
      );
      applyStyleToEl(el, st, { onVideo: true });
      // Optional: tiny slot-color accent bar so palette identity still peeks through
      if (slotSt?.primary) {
        el.style.setProperty(
          'box-shadow',
          `${st.boxShadow}, inset 3px 0 0 ${rgba(slotSt.primary, 0.9)}`,
          'important'
        );
      }
      return;
    }

    if (!slotSt) {
      clearPaint(el);
      return;
    }
    el.classList.remove('has-chosen-style');
    el.style.setProperty('--tag-custom', slotSt.primary);
    el.style.setProperty('--tag-custom-fg', slotSt.fg);
    el.style.setProperty(
      '--tag-custom-border',
      typeof slotSt.border === 'string' ? slotSt.border : slotSt.primary
    );
    applyStyleToEl(el, slotSt, opts);
  }

  /** Paint a preview chip from a slot object (options / editor / pattern gallery). */
  function paintFromSlot(el, slot, opts = {}) {
    if (!el) return;
    const st = styleFromSlot(slot);
    applyStyleToEl(el, st, opts);
  }

  /** CSS background string for small swatches (includes size when pattern). */
  function slotPreviewBackground(slot) {
    const st = styleFromSlot(slot);
    if (st.fillSpec && st.fillSpec.image) {
      // For inline style= on tiny swatches, use the full image + size via element paint instead
      return st.fillSpec.image;
    }
    return st.fill;
  }

  function applyPreviewBackground(el, slot) {
    if (!el) return;
    paintFromSlot(el, slot);
  }

  function paintAll(root) {
    const scope = root || document;
    applyChosenCssVars();
    scope.querySelectorAll('[data-tag]').forEach((el) => {
      const tag = el.getAttribute('data-tag') || el.dataset.tag;
      if (!tag) return;
      const on =
        el.classList.contains('on-video') ||
        el.classList.contains('state-on-current') ||
        (el.classList.contains('meta-chip') && !el.classList.contains('meta-chip-pair'));
      paint(el, tag, { onVideo: on });
    });
  }

  /** Paint a demo chip with the current chosen style (options preview). */
  function paintChosenPreview(el) {
    if (!el) return;
    const st = styleFromChosen(getChosen());
    el.classList.add('has-custom-color', 'has-chosen-style');
    applyStyleToEl(el, st, { onVideo: true });
    el.style.setProperty('color', st.fg, 'important');
  }

  function slotPreviewBorder(slot) {
    const st = styleFromSlot(slot);
    return st.border;
  }

  /** Build preview style for a specific pattern id using current slot colors/scale. */
  function previewPatternStyle(slot, patternId) {
    return styleFromSlot({
      ...sanitizeSlot(slot, 0),
      fillMode: 'pattern',
      tilePattern: patternId || slot.tilePattern || 'stripes-h',
    });
  }

  function recentKey(item) {
    if (!item) return '';
    if (item.g) return `g:${item.a}:${item.b}:${item.c}:${item.pattern || ''}`;
    return String(item.hex || '').toLowerCase();
  }

  function getRecentColors() {
    return recent.slice();
  }

  async function rememberColor(hex, extra) {
    const item = extra && extra.g
      ? {
          g: true,
          a: isHex(extra.a) ? expandHex(extra.a) : '#00e5ff',
          b: isHex(extra.b) ? expandHex(extra.b) : '#00ffa8',
          c: isHex(extra.c) ? expandHex(extra.c) : '#a78bfa',
          pattern: extra.pattern || 'linear',
          dir: extra.dir || 'to right',
        }
      : (isHex(hex) ? { hex: expandHex(hex) } : null);
    if (!item) return getRecentColors();
    const k = recentKey(item);
    recent = [item, ...recent.filter((r) => recentKey(r) !== k)].slice(0, RECENT_MAX);
    try { await chrome.storage.local.set({ [RECENT_KEY]: recent }); } catch (_) {}
    try { global.dispatchEvent(new CustomEvent('fafo:tag-recent-colors', { detail: recent.slice() })); } catch (_) {}
    return getRecentColors();
  }

  async function rememberGradient(a, b, c, pattern, dir) {
    return rememberColor(a, { g: true, a, b, c, pattern, dir });
  }

  function renderRecentBar(host, onPick) {
    if (!host) return;
    const list = getRecentColors();
    if (!list.length) {
      host.innerHTML = '<span class="tcs-recent-empty">No recent colors yet — pick any color below</span>';
      return;
    }
    host.innerHTML = list.map((item, i) => {
      if (item.g) {
        const bg = `linear-gradient(90deg, ${item.a}, ${item.b}, ${item.c})`;
        return `<button type="button" class="tcs-recent-swatch grad" data-ri="${i}" title="Gradient ${item.pattern || ''}" style="background:${bg}"></button>`;
      }
      return `<button type="button" class="tcs-recent-swatch" data-ri="${i}" title="${item.hex}" style="background:${item.hex}"></button>`;
    }).join('');
    host.querySelectorAll('[data-ri]').forEach((btn) => {
      btn.addEventListener('click', (ev) => {
        ev.preventDefault();
        ev.stopPropagation();
        const item = list[Number(btn.getAttribute('data-ri'))];
        if (item && typeof onPick === 'function') onPick(item);
      });
    });
  }

  // Export shell first so PRESETS array is shared
  const PRESETS_EXPORT = DEFAULT_HEXES.slice(0, MIN_SLOTS);

  // Live reload chosen style when Options changes storage
  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local') return;
      let paint = false;
      if (changes[CHOSEN_KEY]) {
        chosen = sanitizeChosen(changes[CHOSEN_KEY].newValue);
        applyChosenCssVars();
        paint = true;
      }
      if (changes[TYPE_KEY]) {
        typeStyle = sanitizeTypeStyle(changes[TYPE_KEY].newValue);
        applyTypeCssVars();
        paint = true;
      }
      if (paint) {
        try {
          if (typeof document !== 'undefined') paintAll(document);
        } catch (_) {}
      }
    });
  } catch (_) {}

  global.FAFOTagColors = {
    PRESETS: PRESETS_EXPORT,
    DEFAULT_PRESETS: DEFAULT_HEXES.slice(0, MIN_SLOTS),
    DEFAULT_SLOT_NAMES: DEFAULT_SLOT_NAMES.slice(),
    MIN_SLOTS,
    GRADIENT_DIRS,
    GRADIENT_PATTERNS,
    TILE_PATTERNS,
    CHOSEN_FILL_MODES,
    CHOSEN_KEY,
    TYPE_KEY,
    RECENT_KEY,
    FONT_CHOICES,
    load,
    reloadForSpace,
    get,
    getStyle,
    getEntry,
    set,
    setSlotOnTag,
    setTagTextOverride,
    getRecentColors,
    rememberColor,
    rememberGradient,
    renderRecentBar,
    setMany,
    clear,
    clearAllTagAssignments,
    rename,
    remove,
    paint,
    paintFromSlot,
    paintAll,
    paintChosenPreview,
    applyStyleToEl,
    applyPreviewBackground,
    contrastFg,
    rgba,
    styleFromSlot,
    styleFromChosen,
    buildTilePattern,
    slotPreviewBackground,
    slotPreviewBorder,
    previewPatternStyle,
    getChosen,
    setChosen,
    applyChosenCssVars,
    defaultChosen,
    getTypeStyle,
    setTypeStyle,
    applyTypeCssVars,
    defaultTypeStyle,
    all: () => ({ ...map }),
    // slots API
    getSlots,
    setSlots,
    updateSlot,
    setSlotScope,
    getThemeId,
    renameSlot,
    addSlot,
    removeSlot,
    resetSlots,
    // legacy
    getPresets,
    setPresets,
    addPreset,
    updatePreset,
    removePreset,
    resetPresets,
  };

  load();
})(typeof window !== 'undefined' ? window : globalThis);
