/**
 * FAFO Pairing & Compare — pairs, slider/blend comparator, duplicates, thumb seek time.
 * Loaded on options.html after fafo-library.js / with options.js.
 */
(function (global) {
    'use strict';

    const $ = (id) => document.getElementById(id);
    const STORAGE_PAIRS = 'fafoPairs';
    const STORAGE_CFG = 'mediaConfig';

    let db = null;
    let pairs = [];
    let draft = { before: null, after: null }; // { store, key, name, type, handle, file, thumbUrl }
    let pickTarget = null; // 'before' | 'after'
    let cmp = {
        before: null,
        after: null,
        mediaB: null,
        mediaA: null,
        urls: [],
        sliderPct: 50,
        dragging: false,
        zoom: 1,
        panX: 0,
        panY: 0,
        sweepRaf: null,
        sweepDir: 1,
        loopHandlers: null,
    };
    let thumbSeekSec = 1;
    let showToast = (msg) => console.log(msg);
    let genThumb = null; // (file, seekSec) => Promise<dataUrl>
    let dupeScanToken = 0; // cancel stale scans
    let pickerGen = 0;

    /** Limit concurrent async jobs (thumbs / getFile). */
    function createPool(limit) {
        let active = 0;
        const q = [];
        const runNext = () => {
            while (active < limit && q.length) {
                active++;
                const { fn, resolve, reject } = q.shift();
                Promise.resolve()
                    .then(fn)
                    .then(resolve, reject)
                    .finally(() => {
                        active--;
                        runNext();
                    });
            }
        };
        return (fn) =>
            new Promise((resolve, reject) => {
                q.push({ fn, resolve, reject });
                runNext();
            });
    }

    const thumbPool = createPool(3);
    const filePool = createPool(4);

    function yieldUI() {
        return new Promise((r) => setTimeout(r, 0));
    }

    function fmtTime(s) {
        if (!isFinite(s) || s < 0) return '0:00';
        const m = Math.floor(s / 60);
        const sec = Math.floor(s % 60);
        return `${m}:${String(sec).padStart(2, '0')}`;
    }

    /**
     * Unique pair tag: pair_ID_01234 (5 digits).
     * Also accepts legacy UP-#### when computing next number.
     */
    function nextPairCode() {
        let max = 0;
        const take = (s) => {
            const a = String(s || '').match(/pair_ID_(\d{1,5})/i);
            if (a) max = Math.max(max, parseInt(a[1], 10));
            const b = String(s || '').match(/UP-(\d+)/i);
            if (b) max = Math.max(max, parseInt(b[1], 10));
        };
        pairs.forEach((p) => {
            take(p.code);
            take(p.pairId);
        });
        const n = Math.min(99999, max + 1);
        return 'pair_ID_' + String(n).padStart(5, '0');
    }

    async function loadPairs() {
        try {
            const res = await chrome.storage.local.get([STORAGE_PAIRS]);
            pairs = Array.isArray(res[STORAGE_PAIRS]) ? res[STORAGE_PAIRS] : [];
        } catch {
            pairs = [];
        }
        return pairs;
    }

    async function savePairs() {
        await chrome.storage.local.set({ [STORAGE_PAIRS]: pairs });
        if (global.FAFOBackup?.afterLiveSave) {
            FAFOBackup.afterLiveSave({ fafoPairs: pairs }, 'pairs-save').catch(() => {});
        }
    }

    async function loadThumbSeek() {
        try {
            const { mediaConfig = {} } = await chrome.storage.local.get(STORAGE_CFG);
            const v = Number(mediaConfig.thumbSeekSec);
            thumbSeekSec = Number.isFinite(v) && v >= 0 ? v : 1;
        } catch {
            thumbSeekSec = 1;
        }
        syncThumbSeekUI();
        return thumbSeekSec;
    }

    async function saveThumbSeek(sec) {
        thumbSeekSec = Math.max(0, Number(sec) || 0);
        const { mediaConfig = {} } = await chrome.storage.local.get(STORAGE_CFG);
        mediaConfig.thumbSeekSec = thumbSeekSec;
        await chrome.storage.local.set({ mediaConfig });
        syncThumbSeekUI();
        if ($('thumb-seek-status')) {
            $('thumb-seek-status').textContent =
                `Saved: thumbnails capture at ${thumbSeekSec}s into each video (capped to duration).`;
        }
        showToast(`Thumbnail time: ${thumbSeekSec}s`);
    }

    function syncThumbSeekUI() {
        if ($('thumb-seek-sec')) $('thumb-seek-sec').value = String(thumbSeekSec);
        if ($('thumb-seek-sec-num')) $('thumb-seek-sec-num').value = String(thumbSeekSec);
        if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = String(thumbSeekSec);
    }

    async function generateThumbnail(file, seekOverride) {
        const seek = seekOverride != null ? seekOverride : thumbSeekSec;
        try {
            if (genThumb) {
                const out = await Promise.race([
                    genThumb(file, seek),
                    new Promise((r) => setTimeout(() => r(null), 5000)),
                ]);
                if (out) return out;
            }
        } catch (e) {
            console.warn('genThumb failed', e);
        }
        // Built-in fallback (always resolves)
        if (!file) return null;
        const name = file.name || '';
        if (String(file.type || '').startsWith('image') || /\.(jpg|jpeg|png|webp|gif|bmp)$/i.test(name)) {
            try { return URL.createObjectURL(file); } catch { return null; }
        }
        const isVideo =
            String(file.type || '').startsWith('video') ||
            /\.(mp4|webm|mkv|mov|m4v|avi)$/i.test(name);
        if (!isVideo) return null;

        return new Promise((resolve) => {
            let settled = false;
            const video = document.createElement('video');
            video.preload = 'auto';
            video.muted = true;
            video.playsInline = true;
            let url;
            try { url = URL.createObjectURL(file); } catch { resolve(null); return; }
            video.src = url;
            const done = (v) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                try { URL.revokeObjectURL(url); } catch (_) {}
                try { video.removeAttribute('src'); video.load(); video.remove(); } catch (_) {}
                resolve(v || null);
            };
            const capture = () => {
                try {
                    const w = video.videoWidth || 0;
                    const h = video.videoHeight || 0;
                    if (w < 2 || h < 2) return done(null);
                    const canvas = document.createElement('canvas');
                    canvas.width = Math.max(1, Math.floor(w / 4));
                    canvas.height = Math.max(1, Math.floor(h / 4));
                    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                    done(canvas.toDataURL('image/jpeg', 0.72));
                } catch {
                    done(null);
                }
            };
            const timer = setTimeout(() => {
                if (video.readyState >= 2) capture();
                else done(null);
            }, 4500);
            video.addEventListener('seeked', capture, { once: true });
            video.addEventListener('error', () => done(null), { once: true });
            const doSeek = () => {
                try {
                    const dur = Number(video.duration);
                    const cap = Number.isFinite(dur) && dur > 0 ? Math.max(0, dur - 0.08) : 0;
                    const t = Math.min(Math.max(0, Number(seek) || 0), cap || 0);
                    if (Math.abs((video.currentTime || 0) - t) < 0.001) {
                        if (video.readyState >= 2) capture();
                        else video.currentTime = Math.min(0.15, cap || 0.15);
                    } else {
                        video.currentTime = t;
                    }
                } catch {
                    if (video.readyState >= 2) capture();
                    else done(null);
                }
            };
            video.addEventListener('loadeddata', doSeek, { once: true });
            video.addEventListener('loadedmetadata', () => {
                if (video.readyState >= 2) doSeek();
            }, { once: true });
        });
    }

    async function resolveEntry(ref, opts = {}) {
        if (!db || !ref) return null;
        const storeName = ref.store || ref.storeName || 'videos';
        try {
            // Prefer live handle from picker when present (avoids stale IDB lookup)
            let handle = ref.handle || null;
            let entryName = ref.name || null;
            if (!handle) {
                const tx = db.transaction(storeName, 'readonly');
                const raw = await new Promise((res, rej) => {
                    const r = tx.objectStore(storeName).get(ref.key);
                    r.onsuccess = () => res(r.result);
                    r.onerror = () => rej(r.error);
                });
                const entry = global.FAFOLibrary ? FAFOLibrary.unwrapFileEntry(raw) : null;
                if (!entry?.handle) return null;
                handle = entry.handle;
                entryName = entry.name || entryName;
            }
            if (global.FAFOLibrary && opts.requestPermission !== false) {
                const ok = await FAFOLibrary.ensurePermission(handle, 'read');
                if (!ok && !(handle instanceof File)) {
                    console.warn('resolveEntry: permission denied', ref.name);
                    return null;
                }
            }
            let file = null;
            if (handle instanceof File) file = handle;
            else if (typeof handle.getFile === 'function') file = await handle.getFile();
            if (!file) return null;
            return {
                store: storeName,
                key: ref.key,
                name: file.name || entryName || ref.name || 'Unknown',
                type: storeName === 'photos' || ref.type === 'photo' ? 'photo' : 'video',
                handle,
                file,
            };
        } catch (e) {
            console.warn('resolveEntry', e);
            return null;
        }
    }

    async function listLibraryFlat() {
        if (!db) return [];
        const out = [];
        try {
            if (global.FAFOLibrary?.getAllMediaEntries) {
                for (const store of ['videos', 'photos']) {
                    const rows = await FAFOLibrary.getAllMediaEntries(db, store);
                    for (const row of rows) {
                        if (!row?.handle && !row?.key) continue;
                        out.push({
                            store,
                            key: row.key,
                            name: row.name || row.handle?.name || 'Unknown',
                            type: store === 'photos' ? 'photo' : 'video',
                            handle: row.handle || null,
                            parentFolderId: row.parentFolderId,
                        });
                    }
                }
            } else {
                // Minimal fallback without FAFOLibrary
                for (const store of ['videos', 'photos']) {
                    if (!db.objectStoreNames.contains(store)) continue;
                    const rows = await new Promise((resolve) => {
                        try {
                            const tx = db.transaction(store, 'readonly');
                            const req = tx.objectStore(store).openCursor();
                            const items = [];
                            req.onsuccess = (e) => {
                                const c = e.target.result;
                                if (c) {
                                    items.push({ key: c.key, val: c.value });
                                    c.continue();
                                } else resolve(items);
                            };
                            req.onerror = () => resolve([]);
                        } catch {
                            resolve([]);
                        }
                    });
                    for (const r of rows) {
                        const h = r.val?.handle || r.val;
                        out.push({
                            store,
                            key: r.key,
                            name: r.val?.name || h?.name || 'Unknown',
                            type: store === 'photos' ? 'photo' : 'video',
                            handle: h,
                        });
                    }
                }
            }
        } catch (e) {
            console.warn('listLibraryFlat', e);
        }
        return out;
    }

    function setSubtab(name) {
        document.querySelectorAll('.pair-subtab').forEach((b) => {
            b.classList.toggle('active', b.dataset.pairTab === name);
        });
        document.querySelectorAll('.pair-pane').forEach((p) => {
            p.classList.toggle('active', p.id === 'pair-pane-' + name);
        });
    }

    function renderSlot(side) {
        const item = draft[side];
        const nameEl = $(`pair-name-${side}`);
        const thumbEl = $(`pair-thumb-${side}`);
        const slot = $(`pair-slot-${side}`);
        if (!item) {
            if (nameEl) nameEl.textContent = 'Not selected';
            if (thumbEl) thumbEl.innerHTML = '—';
            slot?.classList.remove('filled');
            return;
        }
        if (nameEl) nameEl.textContent = item.name;
        slot?.classList.add('filled');
        if (thumbEl) {
            if (item.thumbUrl) {
                thumbEl.innerHTML = `<img src="${item.thumbUrl}" alt="">`;
            } else {
                thumbEl.textContent = item.type === 'photo' ? '🖼' : '🎬';
            }
        }
    }

    async function fillDraftFromRef(side, ref) {
        if (!side || !ref) return false;
        showToast(`Loading ${ref.name || 'file'}…`);
        const resolved = await resolveEntry(ref, { requestPermission: true });
        if (!resolved?.file) {
            showToast('Could not open file — use Restore Access in Visual Library', 'error');
            return false;
        }
        let thumbUrl = null;
        try {
            if (resolved.type === 'photo') {
                thumbUrl = URL.createObjectURL(resolved.file);
            } else {
                // Don't block selection forever if thumb fails
                thumbUrl = await generateThumbnail(resolved.file, thumbSeekSec);
            }
        } catch (e) {
            console.warn('thumb for draft', e);
        }
        draft[side] = { ...resolved, thumbUrl: thumbUrl || null };
        renderSlot(side);
        showToast(`Selected ${side}: ${resolved.name}`);
        return true;
    }

    async function openPicker(side) {
        pickTarget = side;
        const gen = ++pickerGen;
        const modal = $('pair-picker-modal');
        const grid = $('pair-picker-grid');
        const title = $('pair-picker-title');
        if (!modal || !grid) {
            showToast('Picker UI missing — reload Options', 'error');
            return;
        }
        if (title) title.textContent = side === 'before' ? 'Pick BEFORE / source' : 'Pick AFTER / upscaled';
        modal.classList.remove('hidden');
        grid.innerHTML = '<div style="color:#666;grid-column:1/-1;padding:20px;text-align:center;">Loading library…</div>';

        let items = [];
        try {
            items = await listLibraryFlat();
        } catch (e) {
            console.warn(e);
            grid.innerHTML = '<div style="color:#f66;grid-column:1/-1;padding:20px;text-align:center;">Failed to read library. Restore Access?</div>';
            return;
        }
        if (gen !== pickerGen) return;

        const filter = ($('pair-picker-filter')?.value || '').trim().toLowerCase();
        const list = filter ? items.filter((i) => (i.name || '').toLowerCase().includes(filter)) : items;
        if (!list.length) {
            grid.innerHTML = '<div style="color:#666;grid-column:1/-1;padding:20px;text-align:center;">No library items. Link folders in Visual Library first, then Restore Access.</div>';
            return;
        }

        grid.innerHTML = '';
        const maxShow = Math.min(list.length, 300);
        const statusLine = document.createElement('div');
        statusLine.style.cssText = 'grid-column:1/-1;color:#666;font-size:0.8rem;padding:4px 0 8px;';
        statusLine.textContent = `Showing ${maxShow} of ${list.length} — click a card to select`;
        grid.appendChild(statusLine);

        for (let i = 0; i < maxShow; i++) {
            const item = list[i];
            const card = document.createElement('button');
            card.type = 'button';
            card.className = 'pair-pick-card';
            card.style.cssText = 'text-align:left;width:100%;cursor:pointer;';
            card.innerHTML = `<div class="pt" style="display:flex;align-items:center;justify-content:center;color:#444;font-size:1.4rem;">${item.type === 'photo' ? '🖼' : '🎬'}</div><div class="pn">${escapeHtml(item.name || 'Unknown')}</div>`;
            const pt = card.querySelector('.pt');

            card.addEventListener('click', async (e) => {
                e.preventDefault();
                e.stopPropagation();
                card.disabled = true;
                card.style.outline = '2px solid var(--accent)';
                try {
                    const ok = await fillDraftFromRef(pickTarget || side, item);
                    if (ok) modal.classList.add('hidden');
                    else card.disabled = false;
                } catch (err) {
                    console.warn(err);
                    showToast('Select failed: ' + (err.message || err), 'error');
                    card.disabled = false;
                }
            });

            grid.appendChild(card);

            // Lazy thumbs — capped concurrency, no permission prompts (select does that)
            thumbPool(async () => {
                if (gen !== pickerGen) return;
                try {
                    if (!item.handle) return;
                    // query only — never requestPermission off gesture (causes hangs)
                    if (global.FAFOLibrary?.queryPermissionOnly) {
                        const st = await FAFOLibrary.queryPermissionOnly(item.handle, 'read');
                        if (st !== 'granted' && !(item.handle instanceof File)) {
                            if (pt) pt.textContent = '🔒';
                            return;
                        }
                    }
                    const file =
                        item.handle instanceof File
                            ? item.handle
                            : typeof item.handle.getFile === 'function'
                              ? await item.handle.getFile()
                              : null;
                    if (!file || gen !== pickerGen) return;
                    let url = null;
                    if (item.type === 'photo') url = URL.createObjectURL(file);
                    else url = await generateThumbnail(file, thumbSeekSec);
                    if (url && pt && gen === pickerGen) {
                        pt.innerHTML = `<img src="${url}" alt="" style="width:100%;height:100%;object-fit:cover;">`;
                    }
                } catch {
                    if (pt && gen === pickerGen) pt.textContent = '—';
                }
            });
        }
    }

    function escapeHtml(s) {
        return String(s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    async function createPair(opts = {}) {
        if (!draft.before || !draft.after) {
            showToast('Pick both Before and After', 'error');
            return null;
        }
        if (draft.before.store === draft.after.store && String(draft.before.key) === String(draft.after.key)) {
            showToast('Before and After must be different files', 'error');
            return null;
        }
        const code = nextPairCode(); // pair_ID_01234
        const name =
            ($('pair-create-name')?.value || '').trim() ||
            `${draft.before.name} ↔ ${draft.after.name}`;
        const pair = {
            id: 'pair_' + Date.now().toString(36),
            code,
            pairId: code,
            name,
            before: {
                store: draft.before.store,
                key: draft.before.key,
                name: draft.before.name,
            },
            after: {
                store: draft.after.store,
                key: draft.after.key,
                name: draft.after.name,
            },
            created: Date.now(),
            thumbSeekSec,
            thumbBefore: draft.before.thumbUrl || null,
            thumbAfter: draft.after.thumbUrl || null,
        };
        pairs.unshift(pair);
        await savePairs();

        // Always stamp pair_ID_##### on both files so they can be filtered/picked up
        const writeTags = opts.forceTags || $('pair-write-tags')?.checked !== false;
        if (writeTags) {
            await writePairTags(pair, draft.before, draft.after);
        }

        showToast(`Created ${code} · tagged both files`);
        renderPairList();
        draft = { before: null, after: null };
        renderSlot('before');
        renderSlot('after');
        if ($('pair-create-name')) $('pair-create-name').value = '';

        if (!opts.skipCompare) {
            await loadCompareFromPair(pair);
            setPreviewBanner(false);
            setSubtab('compare');
        }
        return pair;
    }

    async function writePairTags(pair, beforeItem, afterItem) {
        try {
            const res = await chrome.storage.local.get(['fafoMediaMeta', 'fafoTagLibrary']);
            const mediaMeta = res.fafoMediaMeta || {};
            // Do NOT inject pair_ID / role stamps into fafoTagLibrary (quick panel / tag history)
            let tagLib = Array.isArray(res.fafoTagLibrary) ? res.fafoTagLibrary.slice() : [];
            const pairTag = pair.pairId || pair.code; // pair_ID_01234 — stored on .pairId only

            const stamp = async (item, role) => {
                if (!item) return;
                // Prefer live key from file identity
                let key = null;
                if (item.file) {
                    key = global.FAFOId?.keyFromFile
                        ? FAFOId.keyFromFile(item.file, item.name)
                        : `file:${item.file.name}|${item.file.size}|${item.file.lastModified}`;
                }
                if (!key && item.name) {
                    // best-effort lookup by name
                    const hit = global.FAFOId?.findStoredMeta
                        ? FAFOId.findStoredMeta(mediaMeta, { name: item.name, size: item.file?.size })
                        : null;
                    key = hit?.key || null;
                }
                if (!key) return;
                const prev = mediaMeta[key] || {};
                // Keep user tags only in .tags; pair lives in .pairId / .pairRole
                const userTags = global.FAFOId?.userTagsOnly
                    ? FAFOId.userTagsOnly(prev.tags || [])
                    : (prev.tags || []).filter((t) => !/^(pair_ID_|UP-)/i.test(String(t)));
                mediaMeta[key] = {
                    ...prev,
                    name: item.file?.name || item.name || prev.name,
                    size: item.file?.size ?? prev.size,
                    tags: userTags,
                    rating: prev.rating || 0,
                    pairId: pairTag,
                    pairRole: role, // 'before' | 'after'
                    updated: Date.now(),
                };

                // Explorer: write user tags only (no pair-ID bloat in Keywords)
                try {
                    await fetch('http://127.0.0.1:8765/api/fs/write-metadata', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            name: item.file?.name || item.name,
                            size: item.file?.size ?? null,
                            mtime: item.file?.lastModified ?? null,
                            tags: userTags,
                            rating: prev.rating || 0,
                            update_catalog: true,
                        }),
                        signal: AbortSignal.timeout(4000),
                    });
                } catch { /* companion optional */ }
            };

            await stamp(beforeItem, 'before');
            await stamp(afterItem, 'after');
            // Strip any legacy pair/role tags from the vocabulary list
            if (global.FAFOId?.isSystemOrPairTag) {
                tagLib = tagLib.filter((t) => !FAFOId.isSystemOrPairTag(t));
            }
            await chrome.storage.local.set({ fafoMediaMeta: mediaMeta, fafoTagLibrary: tagLib });
            if (global.FAFOBackup?.afterLiveSave) {
                FAFOBackup.afterLiveSave({ fafoMediaMeta: mediaMeta, fafoTagLibrary: tagLib }, 'pairs-tags').catch(() => {});
            }
        } catch (e) {
            console.warn('writePairTags', e);
        }
    }

    function renderPairList() {
        const box = $('pair-list');
        const count = $('pair-list-count');
        if (count) count.textContent = pairs.length ? `(${pairs.length})` : '';
        if (!box) return;
        if (!pairs.length) {
            box.innerHTML = '<div style="color:#555;padding:16px;text-align:center;">No pairs yet — create one above.</div>';
            return;
        }
        box.innerHTML = pairs
            .map(
                (p) => `
            <div class="pair-card" data-id="${escapeHtml(p.id)}">
                <div class="pair-card-thumbs">
                    <div class="pt before">${p.thumbBefore ? `<img src="${p.thumbBefore}" alt="">` : '①'}</div>
                    <div class="pt after">${p.thumbAfter ? `<img src="${p.thumbAfter}" alt="">` : '②'}</div>
                </div>
                <div class="pair-card-meta">
                    <strong>${escapeHtml(p.pairId || p.code)} · ${escapeHtml(p.name || '')}</strong>
                    <span>Before: ${escapeHtml(p.before?.name || '—')}</span><br>
                    <span>After: ${escapeHtml(p.after?.name || '—')}</span>
                </div>
                <div class="pair-card-actions">
                    <button class="btn btn-primary small" data-act="compare">Compare</button>
                    <button class="btn btn-ghost small" data-act="regen">Thumbs</button>
                    <button class="btn btn-danger small" data-act="delete">Delete</button>
                </div>
            </div>`
            )
            .join('');

        box.querySelectorAll('.pair-card').forEach((card) => {
            const id = card.dataset.id;
            const p = pairs.find((x) => x.id === id);
            if (!p) return;
            card.querySelector('[data-act="compare"]')?.addEventListener('click', () => {
                loadCompareFromPair(p).then(() => setSubtab('compare'));
            });
            card.querySelector('[data-act="regen"]')?.addEventListener('click', () => regenPairThumbs(p));
            card.querySelector('[data-act="delete"]')?.addEventListener('click', async () => {
                if (!confirm(`Delete pair ${p.code}?`)) return;
                pairs = pairs.filter((x) => x.id !== id);
                await savePairs();
                renderPairList();
                showToast('Pair deleted');
            });
        });
    }

    async function regenPairThumbs(pair) {
        const b = await resolveEntry(pair.before);
        const a = await resolveEntry(pair.after);
        if (b?.file) {
            pair.thumbBefore =
                b.type === 'photo' ? URL.createObjectURL(b.file) : await generateThumbnail(b.file, thumbSeekSec);
        }
        if (a?.file) {
            pair.thumbAfter =
                a.type === 'photo' ? URL.createObjectURL(a.file) : await generateThumbnail(a.file, thumbSeekSec);
        }
        pair.thumbSeekSec = thumbSeekSec;
        await savePairs();
        renderPairList();
        showToast(`Thumbs refreshed @ ${thumbSeekSec}s`);
    }

    function revokeCmpUrls() {
        (cmp.urls || []).forEach((u) => {
            try {
                URL.revokeObjectURL(u);
            } catch { /* */ }
        });
        cmp.urls = [];
    }

    function stopSweep() {
        if (cmp.sweepRaf) {
            cancelAnimationFrame(cmp.sweepRaf);
            cmp.sweepRaf = null;
        }
        $('cmp-sweep')?.classList.remove('active');
    }

    function clearCompareStages() {
        stopSweep();
        revokeCmpUrls();
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (sb) sb.innerHTML = '';
        if (sa) sa.innerHTML = '';
        cmp.mediaB = null;
        cmp.mediaA = null;
        cmp.before = null;
        cmp.after = null;
        cmp.zoom = 1;
        cmp.panX = 0;
        cmp.panY = 0;
        applyCompareTransform();
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: —';
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: —';
        if ($('cmp-res-before')) $('cmp-res-before').textContent = '— × —';
        if ($('cmp-res-after')) $('cmp-res-after').textContent = '— × —';
        if ($('cmp-pair-id')) $('cmp-pair-id').textContent = '';
        if ($('cmp-zoom-badge')) $('cmp-zoom-badge').textContent = '100%';
    }

    function mountMedia(stageEl, file, type) {
        const url = URL.createObjectURL(file);
        cmp.urls.push(url);
        if (type === 'photo' || String(file.type || '').startsWith('image')) {
            const img = document.createElement('img');
            img.src = url;
            img.draggable = false;
            stageEl.appendChild(img);
            img.onload = () => updateResBadges();
            return img;
        }
        const video = document.createElement('video');
        video.src = url;
        video.playsInline = true;
        video.controls = false;
        video.muted = !!$('cmp-mute')?.checked;
        video.preload = 'auto';
        const vol = parseFloat($('cmp-volume')?.value ?? '1');
        video.volume = Number.isFinite(vol) ? vol : 1;
        const spd = parseFloat($('cmp-speed')?.value ?? '1');
        video.playbackRate = Number.isFinite(spd) ? spd : 1;
        stageEl.appendChild(video);
        video.addEventListener('loadedmetadata', () => updateResBadges());
        return video;
    }

    function updateResBadges() {
        const dim = (el) => {
            if (!el) return '— × —';
            if (el.tagName === 'VIDEO') return `${el.videoWidth || '—'} × ${el.videoHeight || '—'}`;
            if (el.tagName === 'IMG') return `${el.naturalWidth || '—'} × ${el.naturalHeight || '—'}`;
            return '— × —';
        };
        if ($('cmp-res-before')) $('cmp-res-before').textContent = dim(cmp.mediaB);
        if ($('cmp-res-after')) $('cmp-res-after').textContent = dim(cmp.mediaA);
    }

    function applyCompareTransform() {
        const layer = $('cmp-transform');
        if (!layer) return;
        const z = cmp.zoom || 1;
        layer.style.transform = `translate(${cmp.panX}px, ${cmp.panY}px) scale(${z})`;
        if ($('cmp-zoom-badge')) $('cmp-zoom-badge').textContent = Math.round(z * 100) + '%';
    }

    function setCompareZoom(z, cx, cy) {
        const viewer = $('cmp-viewer');
        const prev = cmp.zoom || 1;
        cmp.zoom = Math.max(0.25, Math.min(8, z));
        if (viewer && cx != null && cy != null && prev > 0) {
            // Zoom toward cursor
            const rect = viewer.getBoundingClientRect();
            const px = cx - rect.left - rect.width / 2;
            const py = cy - rect.top - rect.height / 2;
            const ratio = cmp.zoom / prev;
            cmp.panX = px - (px - cmp.panX) * ratio;
            cmp.panY = py - (py - cmp.panY) * ratio;
        }
        if (cmp.zoom <= 1.01) {
            cmp.panX = 0;
            cmp.panY = 0;
            cmp.zoom = 1;
        }
        applyCompareTransform();
    }

    async function loadCompareFromPair(pair) {
        clearCompareStages();
        const b = await resolveEntry(pair.before);
        const a = await resolveEntry(pair.after);
        if (!b?.file || !a?.file) {
            showToast('Could not load pair files — Restore Access?', 'error');
            return;
        }
        cmp.before = b;
        cmp.after = a;
        cmp.currentPair = pair;
        const isPreview = pair.id === 'preview_temp' || pair.code === 'PREVIEW';
        setPreviewBanner(
            isPreview,
            'Preview only — not saved yet. Watch both, then Approve or go back and Skip.'
        );
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (!sb || !sa) return;
        cmp.mediaB = mountMedia(sb, b.file, b.type);
        cmp.mediaA = mountMedia(sa, a.file, a.type);
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: ' + b.name;
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: ' + a.name;
        if ($('cmp-pair-id')) {
            $('cmp-pair-id').textContent = isPreview
                ? 'PREVIEW (unsaved)'
                : pair.pairId || pair.code || '';
        }
        wireCompareMedia();
        applyCompareMode();
        setSliderPct(50);
        applyCompareTransform();
        showToast(
            isPreview
                ? 'Preview loaded — watch both before approving'
                : `Comparing ${pair.pairId || pair.code || 'pair'}`
        );
    }

    function bothVideos() {
        return [cmp.mediaA, cmp.mediaB].filter((m) => m?.tagName === 'VIDEO');
    }

    function stepFrame(dir) {
        const vids = bothVideos();
        if (!vids.length) return;
        const fps = 30;
        const dt = (dir < 0 ? -1 : 1) / fps;
        vids.forEach((v) => {
            try {
                v.pause();
                v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + dt));
            } catch { /* */ }
        });
        updateTimelineFromVideo(vids[0]);
    }

    function updateTimelineFromVideo(v) {
        const timeline = $('cmp-timeline');
        if (!v || !timeline) return;
        const d = v.duration || 1;
        timeline.value = String(Math.round((v.currentTime / d) * 1000));
        if ($('cmp-time-cur')) $('cmp-time-cur').textContent = fmtTime(v.currentTime);
        if ($('cmp-time-tot')) $('cmp-time-tot').textContent = fmtTime(v.duration || 0);
    }

    function startSweep() {
        if (cmp.sweepRaf) {
            stopSweep();
            return;
        }
        $('cmp-sweep')?.classList.add('active');
        const speed = parseFloat($('cmp-sweep-speed')?.value || '0.35');
        const tick = () => {
            if ($('cmp-viewer')?.dataset.mode !== 'slider') {
                stopSweep();
                return;
            }
            let pct = cmp.sliderPct + cmp.sweepDir * speed;
            if (pct >= 100) {
                pct = 100;
                cmp.sweepDir = -1;
            } else if (pct <= 0) {
                pct = 0;
                cmp.sweepDir = 1;
            }
            setSliderPct(pct);
            cmp.sweepRaf = requestAnimationFrame(tick);
        };
        cmp.sweepRaf = requestAnimationFrame(tick);
    }

    function wireCompareMedia() {
        const v = cmp.mediaA?.tagName === 'VIDEO' ? cmp.mediaA : cmp.mediaB?.tagName === 'VIDEO' ? cmp.mediaB : null;
        const timeline = $('cmp-timeline');
        if (!v || !timeline) {
            updateResBadges();
            return;
        }
        const onMeta = () => {
            const d = v.duration || 0;
            if ($('cmp-time-tot')) $('cmp-time-tot').textContent = fmtTime(d);
            updateResBadges();
        };
        v.addEventListener('loadedmetadata', onMeta);
        if (v.readyState >= 1) onMeta();
        v.addEventListener('timeupdate', () => {
            updateTimelineFromVideo(v);
            // soft-sync other
            const other = v === cmp.mediaA ? cmp.mediaB : cmp.mediaA;
            if (other?.tagName === 'VIDEO' && Math.abs(other.currentTime - v.currentTime) > 0.12) {
                try {
                    other.currentTime = v.currentTime;
                } catch { /* */ }
            }
        });
        timeline.oninput = () => {
            const d = v.duration || 1;
            const t = (parseInt(timeline.value, 10) / 1000) * d;
            [cmp.mediaA, cmp.mediaB].forEach((m) => {
                if (m?.tagName === 'VIDEO') {
                    try {
                        m.currentTime = t;
                    } catch { /* */ }
                }
            });
        };
    }

    function applyCompareMode() {
        const mode = $('cmp-mode')?.value || 'slider';
        const viewer = $('cmp-viewer');
        if (viewer) viewer.dataset.mode = mode;
        if (mode === 'blend') {
            const op = (parseInt($('cmp-blend')?.value || '50', 10) / 100);
            const wrapB = $('cmp-wrap-before');
            if (wrapB) wrapB.style.opacity = String(op);
        } else {
            const wrapB = $('cmp-wrap-before');
            if (wrapB) wrapB.style.opacity = '';
        }
        if (mode === 'slider') setSliderPct(cmp.sliderPct);
    }

    function setSliderPct(pct) {
        cmp.sliderPct = Math.max(0, Math.min(100, pct));
        const wrapB = $('cmp-wrap-before');
        const line = $('cmp-slider-line');
        if (wrapB && $('cmp-viewer')?.dataset.mode === 'slider') {
            wrapB.style.clipPath = `inset(0 ${100 - cmp.sliderPct}% 0 0)`;
        }
        if (line) line.style.left = cmp.sliderPct + '%';
    }

    function wireSliderDrag() {
        const viewer = $('cmp-viewer');
        if (!viewer) return;
        const onMove = (clientX) => {
            if (!cmp.dragging) return;
            if (viewer.dataset.mode !== 'slider') return;
            const rect = viewer.getBoundingClientRect();
            const pct = ((clientX - rect.left) / rect.width) * 100;
            setSliderPct(pct);
        };
        viewer.addEventListener('pointerdown', (e) => {
            if (viewer.dataset.mode !== 'slider') return;
            cmp.dragging = true;
            viewer.setPointerCapture(e.pointerId);
            onMove(e.clientX);
        });
        viewer.addEventListener('pointermove', (e) => onMove(e.clientX));
        viewer.addEventListener('pointerup', () => {
            cmp.dragging = false;
        });
        viewer.addEventListener('pointercancel', () => {
            cmp.dragging = false;
        });
    }

    function applyAvSettings() {
        const muted = !!$('cmp-mute')?.checked;
        const vol = parseFloat($('cmp-volume')?.value ?? '0.8');
        const spd = parseFloat($('cmp-speed')?.value ?? '1');
        bothVideos().forEach((v) => {
            v.muted = muted;
            v.volume = Number.isFinite(vol) ? vol : 0.8;
            v.playbackRate = Number.isFinite(spd) ? spd : 1;
        });
    }

    function playBoth() {
        applyAvSettings();
        bothVideos().forEach((m) => m.play().catch(() => {}));
    }
    function pauseBoth() {
        bothVideos().forEach((m) => m.pause());
    }
    function syncBoth() {
        const master =
            cmp.mediaA?.tagName === 'VIDEO' ? cmp.mediaA : cmp.mediaB?.tagName === 'VIDEO' ? cmp.mediaB : null;
        if (!master) return;
        const t = master.currentTime;
        bothVideos().forEach((m) => {
            try {
                m.currentTime = t;
            } catch { /* */ }
        });
        updateTimelineFromVideo(master);
        showToast('Synced to ' + fmtTime(t));
    }

    function toggleCompareFullscreen() {
        const viewer = $('cmp-viewer');
        if (!viewer) return;
        if (document.fullscreenElement === viewer) {
            document.exitFullscreen?.();
        } else {
            viewer.requestFullscreen?.().catch(() => showToast('Fullscreen blocked', 'error'));
        }
    }
    function swapCompare() {
        const sb = $('cmp-stage-before');
        const sa = $('cmp-stage-after');
        if (!sb || !sa) return;
        // swap DOM children and refs
        const tmpH = sb.innerHTML;
        sb.innerHTML = sa.innerHTML;
        sa.innerHTML = tmpH;
        const tmpM = cmp.mediaB;
        cmp.mediaB = cmp.mediaA;
        cmp.mediaA = tmpM;
        // re-query elements
        cmp.mediaB = sb.querySelector('video,img');
        cmp.mediaA = sa.querySelector('video,img');
        const tmpI = cmp.before;
        cmp.before = cmp.after;
        cmp.after = tmpI;
        if ($('cmp-label-before')) $('cmp-label-before').textContent = 'Before: ' + (cmp.before?.name || '—');
        if ($('cmp-label-after')) $('cmp-label-after').textContent = 'After: ' + (cmp.after?.name || '—');
        wireCompareMedia();
    }

    // --- Name-based pair suggestions ---
    let suggestQueue = []; // { beforeRef, afterRef, reason, score }
    let suggestIndex = 0;
    let suggestBusy = false;
    let suggestPreviewUrls = []; // object URLs for inline players
    let previewMode = false; // compare open without saved pair

    // --- Duplicates / name matching ---

    /** UUID in names like grok-video-019f8883-0d63-7753-ac98-dc3ac1c113d2 … */
    const UUID_RE =
        /([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i;

    /**
     * Stable media id for pairing.
     * Prefer grok-video-{uuid}; fall back to any UUID; else cleaned stem.
     *
     * Examples that share an id:
     *   grok-video-0bdb8b22-ede6-41f4-8f0e-bb26ac837d6e.mp4
     *   grok-video-0bdb8b22-ede6-41f4-8f0e-bb26ac837d6e (1).mp4
     *   grok-video-0bdb8b22-ede6-41f4-8f0e-bb26ac837d6e 3_resized_exported_3840w_92q_012100.mp4
     */
    function extractPairGroupId(name) {
        const n = String(name || '');
        const grok = n.match(/grok-video-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/i);
        if (grok) return 'grok:' + grok[1].toLowerCase();
        const uuid = n.match(UUID_RE);
        if (uuid) return 'uuid:' + uuid[1].toLowerCase();
        const stem = nameStem(n);
        return stem ? 'stem:' + stem : null;
    }

    function nameStem(name) {
        return String(name || '')
            .toLowerCase()
            .replace(/\.[a-z0-9]+$/i, '')
            .replace(/\(\d+\)/g, ' ')
            // Export pipeline junk: 3_resized_exported_3840w_92q_012100
            .replace(
                /\b\d*[_\s-]?(resized|exported|export|upscaled|upscale|vsr)[_\s-]?[a-z0-9_]*\b/gi,
                ' '
            )
            .replace(/\b\d{3,5}w\b/g, ' ') // 3840w
            .replace(/\b\d{2,3}q\b/g, ' ') // 92q
            .replace(/\b\d{4,}\b/g, ' ') // long numeric stamps
            .replace(/[_\-\s.]+/g, ' ')
            .replace(
                /\b(upscaled|upscale|vsr|after|before|source|original|raw|input|output|x2|x4|4k|2k|remaster|enhanced|final|copy|edit|resized|exported|export|interpolated|interpolate|rife|flashvsr|96fps|60fps)\b/g,
                ' '
            )
            .replace(/\s+/g, ' ')
            .trim();
    }

    function similarName(a, b) {
        // Same Grok/UUID id always counts as similar
        const ida = extractPairGroupId(a);
        const idb = extractPairGroupId(b);
        if (ida && idb && ida === idb) return true;

        const sa = nameStem(a);
        const sb = nameStem(b);
        if (!sa || !sb) return false;
        if (sa === sb) return true;
        if (sa.includes(sb) || sb.includes(sa)) return true;
        const ta = new Set(sa.split(' ').filter((t) => t.length > 2));
        const tb = new Set(sb.split(' ').filter((t) => t.length > 2));
        if (!ta.size || !tb.size) return false;
        let inter = 0;
        ta.forEach((t) => {
            if (tb.has(t)) inter++;
        });
        return inter / Math.min(ta.size, tb.size) >= 0.7;
    }

    /**
     * Score how “after / export / upscale” a filename looks (higher = more likely After).
     * Tuned for FAFO/Grok libraries:
     *   before:  grok-video-{uuid}.mp4  |  grok-video-{uuid} (1).mp4
     *   after:   grok-video-{uuid} 3_resized_exported_3840w_92q_012100.mp4
     */
    function afterRoleScore(name) {
        const n = String(name || '').toLowerCase();
        let s = 0;
        // Strong After markers (export / upscale pipeline)
        if (/resized/.test(n)) s += 10;
        if (/exported|export/.test(n)) s += 9;
        if (/\b\d{3,5}w\b/.test(n)) s += 6; // 3840w, 1920w
        if (/\b\d{2,3}q\b/.test(n)) s += 4; // 92q quality
        if (/\b(upscaled|upscale|vsr|enhanced|remaster|output|final)\b/.test(n)) s += 5;
        if (/\b(after|result)\b/.test(n)) s += 4;
        if (/\b(x2|x4|2x|4x|4k|2k|1080p|2160p)\b/.test(n)) s += 3;
        // Trailing process stamp like 012100
        if (/[_\s]\d{5,}\b/.test(n)) s += 2;
        // "(1)" / "(2)" = alternate download — mild after bias, still before export names
        const copy = n.match(/\((\d+)\)/);
        if (copy) s += Math.min(2, parseInt(copy[1], 10) * 0.5);
        // Strong Before markers
        if (/\b(source|original|before|raw|input)\b/.test(n)) s -= 6;
        // Bare grok-video-uuid with little else → before
        if (/^grok-video-[0-9a-f-]{36}(\s*\(\d+\))?(\.\w+)?$/i.test(n.trim())) s -= 2;
        return s;
    }

    function pairKey(a, b) {
        const ka = `${a.store}:${a.key}`;
        const kb = `${b.store}:${b.key}`;
        return [ka, kb].sort().join('|');
    }

    function alreadyPairedSet() {
        const set = new Set();
        pairs.forEach((p) => {
            if (p.before?.store != null && p.before?.key != null) {
                set.add(`${p.before.store}:${p.before.key}`);
            }
            if (p.after?.store != null && p.after?.key != null) {
                set.add(`${p.after.store}:${p.after.key}`);
            }
        });
        return set;
    }

    function toRef(it) {
        return {
            store: it.store,
            key: it.key,
            name: it.name,
            type: it.type,
            handle: it.handle,
        };
    }

    /**
     * Build ranked before/after suggestions from filenames.
     * Primary key for Grok libraries: shared UUID in the name.
     */
    function buildNamePairSuggestions(items) {
        const paired = alreadyPairedSet();
        const free = items.filter((it) => it && it.key != null && !paired.has(`${it.store}:${it.key}`));

        const byId = new Map(); // group id → items
        free.forEach((it) => {
            const id = extractPairGroupId(it.name);
            if (!id) return;
            if (!byId.has(id)) byId.set(id, []);
            byId.get(id).push(it);
        });

        const out = [];
        const seen = new Set();

        const pushPair = (a, b, reason, score) => {
            if (!a || !b) return;
            if (a.store === b.store && String(a.key) === String(b.key)) return;
            let before = a;
            let after = b;
            const sa = afterRoleScore(a.name);
            const sb = afterRoleScore(b.name);
            if (sb < sa) {
                before = b;
                after = a;
            } else if (sb === sa && (b.name || '').length < (a.name || '').length) {
                before = b;
                after = a;
            }
            // Prefer shorter / lower-score as before when after isn't clearly export
            if (afterRoleScore(after.name) <= afterRoleScore(before.name)) {
                // still force: highest score = after
                if (afterRoleScore(a.name) >= afterRoleScore(b.name)) {
                    before = b;
                    after = a;
                } else {
                    before = a;
                    after = b;
                }
            }
            const pk = pairKey(before, after);
            if (seen.has(pk)) return;
            seen.add(pk);
            out.push({
                beforeRef: toRef(before),
                afterRef: toRef(after),
                reason,
                score:
                    score +
                    Math.abs(afterRoleScore(after.name) - afterRoleScore(before.name)) +
                    (afterRoleScore(after.name) >= 8 ? 5 : 0),
            });
        };

        // 1) Same Grok UUID / UUID / stem — primary for your library
        byId.forEach((group, id) => {
            if (group.length < 2) return;
            const ranked = group
                .slice()
                .sort((x, y) => afterRoleScore(x.name) - afterRoleScore(y.name));
            const label = id.startsWith('grok:')
                ? `Grok id ${id.slice(5, 13)}…`
                : id.startsWith('uuid:')
                  ? `UUID ${id.slice(5, 13)}…`
                  : `Stem “${id.replace(/^stem:/, '').slice(0, 40)}”`;

            if (ranked.length === 2) {
                pushPair(ranked[0], ranked[1], label, 20);
                return;
            }
            // Multi-variant: pair lowest-score (source) with each higher export-like file
            const source = ranked[0];
            for (let i = 1; i < ranked.length; i++) {
                const cand = ranked[i];
                // Only pair if at least one looks like export/after, or scores differ
                const gap = afterRoleScore(cand.name) - afterRoleScore(source.name);
                if (gap < 1 && ranked.length > 3) continue;
                pushPair(
                    source,
                    cand,
                    `${label} (${ranked.length} variants)`,
                    16 + Math.min(6, gap)
                );
            }
            // Also pair consecutive role ranks (e.g. plain → (1) → resized)
            for (let i = 0; i < ranked.length - 1; i++) {
                const gap = afterRoleScore(ranked[i + 1].name) - afterRoleScore(ranked[i].name);
                if (gap >= 1) {
                    pushPair(ranked[i], ranked[i + 1], `${label} step`, 12 + gap);
                }
            }
        });

        // 2) Soft similar-name among leftover singles (no shared UUID group of 2+)
        const singles = [];
        byId.forEach((group) => {
            if (group.length === 1) singles.push(group[0]);
        });
        const maxSoft = Math.min(singles.length, 100);
        for (let i = 0; i < maxSoft; i++) {
            for (let j = i + 1; j < maxSoft; j++) {
                if (!similarName(singles[i].name, singles[j].name)) continue;
                // Skip if both are bare different UUIDs (false friends)
                const ida = extractPairGroupId(singles[i].name);
                const idb = extractPairGroupId(singles[j].name);
                if (ida && idb && ida !== idb && ida.startsWith('grok:') && idb.startsWith('grok:')) {
                    continue;
                }
                pushPair(singles[i], singles[j], 'Similar filenames', 4);
            }
        }

        out.sort((a, b) => b.score - a.score);
        return out;
    }

    function updateSuggestStatus(msg) {
        const el = $('pair-suggest-status');
        if (el) el.textContent = msg;
    }

    function revokeSuggestPreviewUrls() {
        (suggestPreviewUrls || []).forEach((u) => {
            try { URL.revokeObjectURL(u); } catch { /* */ }
        });
        suggestPreviewUrls = [];
    }

    function setPreviewBanner(visible, text) {
        const banner = $('cmp-preview-banner');
        if (!banner) return;
        banner.classList.toggle('visible', !!visible);
        previewMode = !!visible;
        if (text && $('cmp-preview-banner-text')) {
            $('cmp-preview-banner-text').textContent = text;
        }
    }

    /**
     * Mount a real video (with controls) into a suggest media box so you can watch
     * before approving — thumbs alone are useless after upscale.
     */
    async function mountSuggestPlayer(side, ref) {
        const box = $(side === 'before' ? 'pair-suggest-media-before' : 'pair-suggest-media-after');
        const nameEl = $(side === 'before' ? 'pair-suggest-name-before' : 'pair-suggest-name-after');
        if (nameEl) nameEl.textContent = ref?.name || '—';
        if (!box) return null;
        box.innerHTML = '<span style="color:#666;font-size:0.8rem;">Loading…</span>';
        if (!ref) {
            box.textContent = '—';
            return null;
        }
        try {
            const r = await resolveEntry(ref, { requestPermission: true });
            if (!r?.file) {
                box.innerHTML = '<span style="color:#f66;font-size:0.8rem;">Can’t open — Restore Access?</span>';
                return null;
            }
            const url = URL.createObjectURL(r.file);
            suggestPreviewUrls.push(url);
            if (r.type === 'photo' || String(r.file.type || '').startsWith('image')) {
                box.innerHTML = `<img src="${url}" alt="">`;
                return null;
            }
            const video = document.createElement('video');
            video.src = url;
            video.controls = true;
            video.playsInline = true;
            video.preload = 'metadata';
            video.muted = true; // start muted so autoplay policies don't block scrubbing
            video.style.width = '100%';
            video.style.height = '100%';
            box.innerHTML = '';
            box.appendChild(video);
            return video;
        } catch (e) {
            console.warn('mountSuggestPlayer', e);
            box.innerHTML = '<span style="color:#f66;font-size:0.8rem;">Load failed</span>';
            return null;
        }
    }

    async function renderSuggestMedia(sug) {
        revokeSuggestPreviewUrls();
        if (!sug) {
            const mb = $('pair-suggest-media-before');
            const ma = $('pair-suggest-media-after');
            if (mb) mb.textContent = '—';
            if (ma) ma.textContent = '—';
            return;
        }
        // Sequential load (permission gesture from user click on scan/approve/next)
        await mountSuggestPlayer('before', sug.beforeRef);
        await mountSuggestPlayer('after', sug.afterRef);
    }

    function suggestVideos() {
        return [
            $('pair-suggest-media-before')?.querySelector('video'),
            $('pair-suggest-media-after')?.querySelector('video'),
        ].filter(Boolean);
    }

    function playSuggestBoth() {
        const vids = suggestVideos();
        if (!vids.length) {
            showToast('No playable video loaded yet — wait a second or Restore Access', 'error');
            return;
        }
        vids.forEach((v) => {
            v.muted = false;
            v.play().catch(() => {
                v.muted = true;
                v.play().catch(() => {});
            });
        });
        // Soft-sync to earliest
        const t = Math.min(...vids.map((v) => v.currentTime || 0));
        vids.forEach((v) => {
            try { v.currentTime = t; } catch { /* */ }
        });
    }

    function pauseSuggestBoth() {
        suggestVideos().forEach((v) => v.pause());
    }

    function showCurrentSuggestion() {
        const card = $('pair-suggest-card');
        const progress = $('pair-suggest-progress');
        const reason = $('pair-suggest-reason');
        if (!suggestQueue.length) {
            if (card) card.style.display = 'none';
            revokeSuggestPreviewUrls();
            updateSuggestStatus('No suggestions — try again after linking more files');
            return;
        }
        if (suggestIndex >= suggestQueue.length) {
            if (card) card.style.display = 'none';
            revokeSuggestPreviewUrls();
            updateSuggestStatus(`Done — reviewed all ${suggestQueue.length} suggestion(s)`);
            showToast('No more name-pair suggestions');
            return;
        }
        const sug = suggestQueue[suggestIndex];
        if (card) card.style.display = 'block';
        if (progress) {
            progress.textContent = `Suggestion ${suggestIndex + 1} of ${suggestQueue.length} — watch both before approving`;
        }
        if (reason) {
            reason.textContent = `${sug.reason} · score ${sug.score.toFixed(0)} · use Preview if thumbs look the same`;
        }
        renderSuggestMedia(sug);
        updateSuggestStatus(`${suggestQueue.length - suggestIndex} left · Preview → Approve or Skip`);
    }

    /**
     * Open full Compare tools without creating a pair (preview mode).
     */
    async function previewRefsInCompare(beforeRef, afterRef, label) {
        if (!beforeRef || !afterRef) {
            showToast('Need both before and after', 'error');
            return false;
        }
        const fakePair = {
            id: 'preview_temp',
            code: 'PREVIEW',
            pairId: 'PREVIEW',
            name: label || 'Preview (unsaved)',
            before: beforeRef,
            after: afterRef,
        };
        await loadCompareFromPair(fakePair);
        setPreviewBanner(
            true,
            'Preview only — not saved yet. Watch both (Play), then Approve or go back and Skip.'
        );
        setSubtab('compare');
        // Auto-start play so user can watch immediately
        setTimeout(() => playBoth(), 200);
        return true;
    }

    async function previewCurrentSuggestion() {
        if (!suggestQueue.length || suggestIndex >= suggestQueue.length) {
            showToast('No suggestion to preview', 'error');
            return;
        }
        const sug = suggestQueue[suggestIndex];
        // Keep slots filled for later approve
        await loadSuggestionToSlots();
        await previewRefsInCompare(
            sug.beforeRef,
            sug.afterRef,
            `${sug.beforeRef.name} ↔ ${sug.afterRef.name}`
        );
    }

    async function previewDraftSlots() {
        if (!draft.before || !draft.after) {
            showToast('Pick Before and After first (or use name suggestions)', 'error');
            return;
        }
        await previewRefsInCompare(
            {
                store: draft.before.store,
                key: draft.before.key,
                name: draft.before.name,
                type: draft.before.type,
                handle: draft.before.handle,
            },
            {
                store: draft.after.store,
                key: draft.after.key,
                name: draft.after.name,
                type: draft.after.type,
                handle: draft.after.handle,
            },
            'Draft slots preview'
        );
    }

    async function scanNamePairSuggestions() {
        if (suggestBusy) return;
        suggestBusy = true;
        updateSuggestStatus('Scanning filenames…');
        const card = $('pair-suggest-card');
        if (card) card.style.display = 'none';
        try {
            await loadPairs();
            const items = await listLibraryFlat();
            suggestQueue = buildNamePairSuggestions(items);
            suggestIndex = 0;
            if (!suggestQueue.length) {
                updateSuggestStatus('No name twins found (need similar stems or upscaled/source markers)');
                showToast('No name-based pairs found', 'error');
            } else {
                showCurrentSuggestion();
                showToast(`Found ${suggestQueue.length} name-pair guess(es)`);
            }
        } catch (e) {
            console.warn(e);
            updateSuggestStatus('Scan failed: ' + (e.message || e));
            showToast('Name-pair scan failed', 'error');
        } finally {
            suggestBusy = false;
        }
    }

    function skipSuggestion() {
        if (!suggestQueue.length) return;
        suggestIndex++;
        showCurrentSuggestion();
    }

    function swapSuggestionRoles() {
        if (!suggestQueue.length || suggestIndex >= suggestQueue.length) return;
        const sug = suggestQueue[suggestIndex];
        const tmp = sug.beforeRef;
        sug.beforeRef = sug.afterRef;
        sug.afterRef = tmp;
        showCurrentSuggestion();
        showToast('Swapped Before ↔ After for this guess');
    }

    async function loadSuggestionToSlots() {
        if (!suggestQueue.length || suggestIndex >= suggestQueue.length) return false;
        const sug = suggestQueue[suggestIndex];
        const okB = await fillDraftFromRef('before', sug.beforeRef);
        const okA = await fillDraftFromRef('after', sug.afterRef);
        if (okB && okA) {
            if ($('pair-create-name')) {
                $('pair-create-name').value = `${sug.beforeRef.name} ↔ ${sug.afterRef.name}`;
            }
            return true;
        }
        return false;
    }

    async function approveSuggestion() {
        if (suggestBusy) return;
        if (!suggestQueue.length || suggestIndex >= suggestQueue.length) {
            showToast('No suggestion to approve', 'error');
            return;
        }
        suggestBusy = true;
        try {
            const ok = await loadSuggestionToSlots();
            if (!ok) {
                showToast('Could not open files — Restore Access or Skip', 'error');
                return;
            }
            // Stay on suggest UI so you can keep approving; open Compare via list if needed
            const pair = await createPair({ skipCompare: true });
            if (!pair) return;
            suggestQueue.splice(suggestIndex, 1);
            showCurrentSuggestion();
        } catch (e) {
            console.warn(e);
            showToast('Approve failed: ' + (e.message || e), 'error');
        } finally {
            suggestBusy = false;
        }
    }

    // --- Smart probe helpers (frame hash + resolution) ---
    function frameHashFromCanvas(canvas) {
        const w = 8, h = 8;
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        const ctx = c.getContext('2d', { willReadFrequently: true });
        ctx.drawImage(canvas, 0, 0, w, h);
        const data = ctx.getImageData(0, 0, w, h).data;
        const grays = [];
        let sum = 0;
        for (let i = 0; i < w * h; i++) {
            const o = i * 4;
            const g = 0.299 * data[o] + 0.587 * data[o + 1] + 0.114 * data[o + 2];
            grays.push(g);
            sum += g;
        }
        const avg = sum / grays.length;
        let bits = '';
        for (const g of grays) bits += g >= avg ? '1' : '0';
        let hex = '';
        for (let i = 0; i < 64; i += 4) hex += parseInt(bits.slice(i, i + 4), 2).toString(16);
        return hex;
    }

    function hammingHex(a, b) {
        if (!a || !b || a.length !== b.length) return 64;
        let d = 0;
        for (let i = 0; i < a.length; i++) {
            const x = parseInt(a[i], 16) ^ parseInt(b[i], 16);
            d += (x & 1) + ((x >> 1) & 1) + ((x >> 2) & 1) + ((x >> 3) & 1);
        }
        return d;
    }

    function framesMatch(ha, hb, threshold = 10) {
        return !!(ha && hb && hammingHex(ha, hb) <= threshold);
    }

    async function probeMediaFile(file, seekSec) {
        const out = {
            width: 0, height: 0, duration: 0, frameHash: null, mtime: file?.lastModified || 0, isPhoto: false,
        };
        if (!file) return out;
        const isVid = String(file.type || '').startsWith('video') || /\.(mp4|webm|mkv|mov|m4v)$/i.test(file.name || '');
        const isImg = String(file.type || '').startsWith('image') || /\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name || '');
        if (isImg && !isVid) {
            out.isPhoto = true;
            return new Promise((resolve) => {
                const img = new Image();
                const url = URL.createObjectURL(file);
                img.onload = () => {
                    out.width = img.naturalWidth || 0;
                    out.height = img.naturalHeight || 0;
                    try {
                        const canvas = document.createElement('canvas');
                        canvas.width = Math.min(320, out.width || 320);
                        canvas.height = Math.min(180, out.height || 180);
                        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
                        out.frameHash = frameHashFromCanvas(canvas);
                    } catch (_) {}
                    URL.revokeObjectURL(url);
                    resolve(out);
                };
                img.onerror = () => { URL.revokeObjectURL(url); resolve(out); };
                img.src = url;
            });
        }
        if (!isVid) return out;
        return new Promise((resolve) => {
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.muted = true;
            video.playsInline = true;
            const url = URL.createObjectURL(file);
            let done = false;
            const finish = () => {
                if (done) return;
                done = true;
                try { URL.revokeObjectURL(url); } catch (_) {}
                video.remove();
                resolve(out);
            };
            video.src = url;
            video.onloadedmetadata = () => {
                out.width = video.videoWidth || 0;
                out.height = video.videoHeight || 0;
                out.duration = video.duration || 0;
                const cap = Math.max(0, (video.duration || 1) - 0.05);
                const seek = Math.min(Math.max(0, seekSec ?? thumbSeekSec), cap || 0);
                try { video.currentTime = seek; } catch { finish(); }
            };
            video.onseeked = () => {
                try {
                    const canvas = document.createElement('canvas');
                    const scale = 4;
                    canvas.width = Math.max(1, Math.floor((video.videoWidth || 320) / scale));
                    canvas.height = Math.max(1, Math.floor((video.videoHeight || 180) / scale));
                    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
                    out.frameHash = frameHashFromCanvas(canvas);
                } catch (_) {}
                finish();
            };
            video.onerror = finish;
            setTimeout(finish, 6000);
        });
    }

    function qualityScore(p) {
        const pixels = (p.width || 0) * (p.height || 0);
        return pixels * 1000 + (p.size || 0) / 100 + (p.mtime || 0) / 1e10;
    }

    function resLabel(p) {
        if (!p?.width || !p?.height) return '—';
        return p.width + '×' + p.height;
    }

    function classifyDupePair(a, b) {
        const sameSize = a.size != null && b.size != null && a.size === b.size;
        const sameRes = a.width && b.width && a.width === b.width && a.height === b.height;
        const frameOk = framesMatch(a.frameHash, b.frameHash, 10);
        const nameOk = similarName(a.name, b.name);
        const pixelsA = (a.width || 0) * (a.height || 0);
        const pixelsB = (b.width || 0) * (b.height || 0);
        const resDiff = pixelsA && pixelsB ? Math.abs(pixelsA - pixelsB) / Math.max(pixelsA, pixelsB) : 1;

        if (sameSize && (frameOk || !a.frameHash || !b.frameHash)) {
            return { kind: 'exact', reason: frameOk ? 'Exact size + matching frame' : 'Exact file size' };
        }
        if (frameOk && sameRes) {
            return { kind: 'exact', reason: 'Matching frame + same resolution' };
        }
        if (frameOk && !sameRes && resDiff > 0.05) {
            return { kind: 'upscale', reason: 'Matching frame · different resolution (upscale/interpolate pair?)' };
        }
        if (frameOk && !sameSize) {
            const sizeDiff = Math.abs((a.size || 0) - (b.size || 0)) / Math.max(a.size || 1, b.size || 1);
            if (sizeDiff > 0.08) {
                return { kind: 'upscale', reason: 'Matching frame · different file size' };
            }
        }
        if (nameOk && sameSize) {
            return { kind: 'exact', reason: 'Similar name + exact size' };
        }
        if (nameOk && frameOk) {
            return { kind: 'upscale', reason: 'Similar name + matching frame' };
        }
        if (nameOk) {
            return { kind: 'name', reason: 'Similar filename only (review carefully)' };
        }
        return null;
    }

    async function scanDuplicates() {
        const status = $('dupe-status');
        const box = $('dupe-results');
        const token = ++dupeScanToken;
        if (status) status.textContent = 'Smart scan: size · resolution · frames…';
        if (box) box.innerHTML = '<div style="color:#666;padding:12px;">Reading files…</div>';

        try {
            const mode = $('dupe-mode')?.value || 'smart';
            const items = await listLibraryFlat();
            if (token !== dupeScanToken) return;

            const MAX_FILES = 800;
            const slice = items.slice(0, MAX_FILES);
            if (status) {
                status.textContent =
                    items.length > MAX_FILES
                        ? `Probing first ${MAX_FILES} of ${items.length}…`
                        : `Probing ${slice.length} files…`;
            }

            const wantProbe = mode === 'smart' || mode === 'visual' || mode === 'exact' || mode === 'all';
            const enriched = [];
            for (let i = 0; i < slice.length; i++) {
                if (token !== dupeScanToken) return;
                const it = slice[i];
                if (i % 10 === 0) {
                    if (status) status.textContent = `Probing ${i + 1}/${slice.length}…`;
                    await yieldUI();
                }
                try {
                    await filePool(async () => {
                        if (!it.handle) {
                            enriched.push({ ...it, file: null, size: null, mtime: 0, width: 0, height: 0, frameHash: null });
                            return;
                        }
                        if (global.FAFOLibrary?.queryPermissionOnly) {
                            const st = await FAFOLibrary.queryPermissionOnly(it.handle, 'read');
                            if (st !== 'granted' && !(it.handle instanceof File)) {
                                enriched.push({ ...it, file: null, size: null, locked: true, mtime: 0, width: 0, height: 0, frameHash: null });
                                return;
                            }
                        }
                        const file =
                            it.handle instanceof File
                                ? it.handle
                                : typeof it.handle.getFile === 'function'
                                  ? await it.handle.getFile()
                                  : null;
                        if (!file) {
                            enriched.push({ ...it, file: null, size: null, mtime: 0, width: 0, height: 0, frameHash: null });
                            return;
                        }
                        let probe = { width: 0, height: 0, frameHash: null, mtime: file.lastModified || 0 };
                        if (wantProbe) {
                            probe = await probeMediaFile(file, thumbSeekSec);
                        } else {
                            probe.mtime = file.lastModified || 0;
                        }
                        enriched.push({
                            ...it,
                            file,
                            size: file.size,
                            name: file.name || it.name,
                            mtime: probe.mtime,
                            width: probe.width || 0,
                            height: probe.height || 0,
                            frameHash: probe.frameHash,
                            isPhoto: !!probe.isPhoto,
                        });
                    });
                } catch {
                    enriched.push({ ...it, file: null, size: null, mtime: 0, width: 0, height: 0, frameHash: null });
                }
            }
            if (token !== dupeScanToken) return;

            const n = enriched.length;
            const parent = Array.from({ length: n }, (_, i) => i);
            const find = (i) => (parent[i] === i ? i : (parent[i] = find(parent[i])));
            const unite = (a, b) => {
                const ra = find(a), rb = find(b);
                if (ra !== rb) parent[rb] = ra;
            };
            const edgeMeta = new Map();

            const consider = (i, j) => {
                if (i === j) return;
                const a = enriched[i], b = enriched[j];
                let cls = classifyDupePair(a, b);
                if (!cls) return;
                if (mode === 'size' && !(a.size != null && a.size === b.size)) return;
                if (mode === 'size') cls = { kind: 'exact', reason: 'Exact file size' };
                if (mode === 'visual' && !framesMatch(a.frameHash, b.frameHash, 10)) return;
                if (mode === 'name' && !similarName(a.name, b.name)) return;
                if (mode === 'exact' && cls.kind !== 'exact') return;
                if (mode === 'smart' && cls.kind === 'name') return;
                if (mode === 'both' && !(cls.kind === 'exact' || similarName(a.name, b.name))) return;
                const key = [Math.min(i, j), Math.max(i, j)].join(',');
                const prev = edgeMeta.get(key);
                if (!prev || (cls.kind === 'exact' && prev.kind !== 'exact')) edgeMeta.set(key, cls);
                unite(i, j);
            };

            // Pass: exact size buckets
            if (mode === 'size' || mode === 'exact' || mode === 'smart' || mode === 'both' || mode === 'all') {
                const bySize = new Map();
                enriched.forEach((it, i) => {
                    if (it.size == null) return;
                    if (!bySize.has(it.size)) bySize.set(it.size, []);
                    bySize.get(it.size).push(i);
                });
                bySize.forEach((idxs) => {
                    if (idxs.length < 2) return;
                    for (let a = 0; a < idxs.length; a++) {
                        for (let b = a + 1; b < idxs.length; b++) consider(idxs[a], idxs[b]);
                    }
                });
            }

            // Pass: identical frame hashes
            if (mode === 'visual' || mode === 'smart' || mode === 'exact' || mode === 'all') {
                const byHash = new Map();
                enriched.forEach((it, i) => {
                    if (!it.frameHash) return;
                    if (!byHash.has(it.frameHash)) byHash.set(it.frameHash, []);
                    byHash.get(it.frameHash).push(i);
                });
                byHash.forEach((idxs) => {
                    if (idxs.length < 2) return;
                    for (let a = 0; a < idxs.length; a++) {
                        for (let b = a + 1; b < idxs.length; b++) consider(idxs[a], idxs[b]);
                    }
                });
                // Near-hash for manageable libraries
                if (n <= 350) {
                    const withHash = [];
                    enriched.forEach((it, i) => { if (it.frameHash) withHash.push({ i, h: it.frameHash }); });
                    for (let a = 0; a < withHash.length; a++) {
                        if (token !== dupeScanToken) return;
                        if (a % 40 === 0) await yieldUI();
                        for (let b = a + 1; b < withHash.length; b++) {
                            if (hammingHex(withHash[a].h, withHash[b].h) <= 10) {
                                consider(withHash[a].i, withHash[b].i);
                            }
                        }
                    }
                }
            }

            // Pass: similar names / stems
            if (mode === 'name' || mode === 'both' || mode === 'all') {
                const byStem = new Map();
                enriched.forEach((it, i) => {
                    const stem = nameStem(it.name);
                    if (!stem || stem.length < 3) return;
                    if (!byStem.has(stem)) byStem.set(stem, []);
                    byStem.get(stem).push(i);
                });
                byStem.forEach((idxs) => {
                    if (idxs.length < 2) return;
                    for (let a = 0; a < Math.min(idxs.length, 24); a++) {
                        for (let b = a + 1; b < Math.min(idxs.length, 24); b++) consider(idxs[a], idxs[b]);
                    }
                });
            }

            // Also: same Grok/UUID group ids often before/after
            if (mode === 'smart' || mode === 'all') {
                const byGid = new Map();
                enriched.forEach((it, i) => {
                    const gid = extractPairGroupId(it.name);
                    if (!gid) return;
                    if (!byGid.has(gid)) byGid.set(gid, []);
                    byGid.get(gid).push(i);
                });
                byGid.forEach((idxs) => {
                    if (idxs.length < 2) return;
                    for (let a = 0; a < idxs.length; a++) {
                        for (let b = a + 1; b < idxs.length; b++) consider(idxs[a], idxs[b]);
                    }
                });
            }

            const clusters = new Map();
            for (let i = 0; i < n; i++) {
                const r = find(i);
                if (!clusters.has(r)) clusters.set(r, []);
                clusters.get(r).push(i);
            }

            const groups = [];
            clusters.forEach((indices) => {
                if (indices.length < 2) return;
                let kind = 'name';
                let reason = 'Related files';
                for (let a = 0; a < indices.length; a++) {
                    for (let b = a + 1; b < indices.length; b++) {
                        const key = [Math.min(indices[a], indices[b]), Math.max(indices[a], indices[b])].join(',');
                        const e = edgeMeta.get(key) || classifyDupePair(enriched[indices[a]], enriched[indices[b]]);
                        if (!e) continue;
                        if (e.kind === 'exact') { kind = 'exact'; reason = e.reason; }
                        else if (e.kind === 'upscale' && kind !== 'exact') { kind = 'upscale'; reason = e.reason; }
                        else if (kind === 'name') { reason = e.reason; }
                    }
                }
                // Sort best quality first → KEEP
                indices.sort((ia, ib) => qualityScore(enriched[ib]) - qualityScore(enriched[ia]));
                groups.push({ kind, reason, indices });
            });

            const order = { exact: 0, upscale: 1, name: 2 };
            groups.sort((a, b) => (order[a.kind] ?? 9) - (order[b.kind] ?? 9));
            const finalGroups = groups.slice(0, 40);

            if (status) {
                const ex = finalGroups.filter((g) => g.kind === 'exact').length;
                const up = finalGroups.filter((g) => g.kind === 'upscale').length;
                status.textContent = finalGroups.length
                    ? `Found ${finalGroups.length} group(s): ${ex} exact · ${up} upscale/pair · ${finalGroups.length - ex - up} other. KEEP = higher res / larger / newer.`
                    : 'No duplicate groups found.';
            }
            if (!box) return;
            if (!finalGroups.length) {
                box.innerHTML = '<div style="color:#666;padding:12px;">No matches.</div>';
                return;
            }

            box.innerHTML = '';
            for (const g of finalGroups) {
                if (token !== dupeScanToken) return;
                const el = document.createElement('div');
                el.className = 'dupe-group dupe-kind-' + g.kind;
                const keepIdx = g.indices[0];
                const keep = enriched[keepIdx];
                const canBulk = g.kind === 'exact' && g.indices.length > 1;
                el.innerHTML =
                    '<div class="dupe-group-head">' +
                    '<h4>' + escapeHtml(g.reason) + ' · ' + g.indices.length + ' files ' +
                    '<span class="dupe-badge dupe-badge-' + g.kind + '">' +
                    (g.kind === 'exact' ? 'EXACT' : g.kind === 'upscale' ? 'UPSCALE PAIR' : 'REVIEW') +
                    '</span></h4>' +
                    (canBulk
                        ? '<button type="button" class="btn btn-primary small" data-a="bulk-older">Remove lower-quality / older from lib</button>'
                        : '') +
                    (g.kind === 'upscale'
                        ? '<span class="dupe-hint">Frames match but size/res differ — use Before/After; do not bulk-delete</span>'
                        : '') +
                    '</div><div class="dupe-items"></div>';
                const itemsEl = el.querySelector('.dupe-items');

                el.querySelector('[data-a="bulk-older"]')?.addEventListener('click', async () => {
                    const victims = g.indices.slice(1);
                    if (!confirm(
                        'Remove ' + victims.length + ' lower-quality/older file(s) from the library index?\n\n' +
                        'KEEP: ' + keep.name + ' (' + resLabel(keep) + ', ' + formatBytes(keep.size) + ')\n' +
                        'Does not delete files on disk.'
                    )) return;
                    for (const idx of victims) {
                        const it = enriched[idx];
                        try {
                            const tx = db.transaction(it.store, 'readwrite');
                            tx.objectStore(it.store).delete(it.key);
                            await new Promise((res, rej) => {
                                tx.oncomplete = res;
                                tx.onerror = () => rej(tx.error);
                            });
                            const card = itemsEl.querySelector('[data-idx="' + idx + '"]');
                            if (card) card.style.opacity = '0.3';
                        } catch (e) {
                            showToast(e.message || 'Delete failed', 'error');
                        }
                    }
                    showToast('Removed ' + victims.length + ' · kept best');
                });

                for (const idx of g.indices.slice(0, 12)) {
                    const it = enriched[idx];
                    const isKeep = idx === keepIdx;
                    const card = document.createElement('div');
                    card.className = 'dupe-item' + (isKeep ? ' dupe-keep' : ' dupe-drop');
                    card.dataset.idx = String(idx);
                    const age = it.mtime ? new Date(it.mtime).toLocaleDateString() : '—';
                    card.innerHTML =
                        '<div class="dt" style="display:flex;align-items:center;justify-content:center;color:#555;">' +
                        (it.locked ? '🔒' : '…') + '</div>' +
                        '<div class="dn">' + escapeHtml(it.name || '') + '</div>' +
                        '<div class="dupe-meta">' +
                        '<span>' + resLabel(it) + '</span>' +
                        '<span>' + formatBytes(it.size) + '</span>' +
                        '<span>' + age + '</span>' +
                        (isKeep
                            ? '<span class="dupe-keep-tag">KEEP</span>'
                            : '<span class="dupe-drop-tag">older / lower</span>') +
                        '</div>' +
                        '<div class="da">' +
                        '<button type="button" class="btn btn-ghost small" data-a="pair-b">As Before</button>' +
                        '<button type="button" class="btn btn-ghost small" data-a="pair-a">As After</button>' +
                        '<button type="button" class="btn btn-primary small" data-a="del">' +
                        (isKeep ? 'Remove anyway' : 'Remove from lib') + '</button></div>';
                    itemsEl.appendChild(card);
                    const dt = card.querySelector('.dt');
                    if (it.file) {
                        thumbPool(async () => {
                            if (token !== dupeScanToken) return;
                            try {
                                let url = null;
                                if (it.type === 'photo' || it.isPhoto) url = URL.createObjectURL(it.file);
                                else url = await generateThumbnail(it.file, thumbSeekSec);
                                if (url && dt) dt.innerHTML = '<img src="' + url + '" alt="" style="width:100%;height:100%;object-fit:cover;">';
                                else if (dt) dt.textContent = '🎬';
                            } catch {
                                if (dt) dt.textContent = '—';
                            }
                        });
                    }
                    card.querySelector('[data-a="pair-b"]')?.addEventListener('click', async () => {
                        await fillDraftFromRef('before', it);
                        setSubtab('pairs');
                        showToast('Set as Before (usually source / lower res)');
                    });
                    card.querySelector('[data-a="pair-a"]')?.addEventListener('click', async () => {
                        await fillDraftFromRef('after', it);
                        setSubtab('pairs');
                        showToast('Set as After (usually upscale / higher res)');
                    });
                    card.querySelector('[data-a="del"]')?.addEventListener('click', async () => {
                        const msg = isKeep
                            ? 'Remove KEEP candidate ' + it.name + '? (does not delete disk file)'
                            : 'Remove ' + it.name + ' from library index? (does not delete disk file)';
                        if (!confirm(msg)) return;
                        try {
                            const tx = db.transaction(it.store, 'readwrite');
                            tx.objectStore(it.store).delete(it.key);
                            await new Promise((res, rej) => {
                                tx.oncomplete = res;
                                tx.onerror = () => rej(tx.error);
                            });
                            card.style.opacity = '0.35';
                            showToast('Removed from library');
                        } catch (e) {
                            showToast(e.message || 'Delete failed', 'error');
                        }
                    });
                }
                box.appendChild(el);
                await yieldUI();
            }
        } catch (e) {
            console.error('scanDuplicates crashed', e);
            if (status) status.textContent = 'Scan failed: ' + (e.message || e);
            if (box) {
                box.innerHTML = '<div style="color:#f66;padding:12px;">Scan crashed.<br>' +
                    escapeHtml(String(e.message || e)) +
                    '<br>Try Restore Access, or “Exact file size” only.</div>';
            }
            showToast('Duplicate scan failed', 'error');
        }
    }

    function formatBytes(n) {
        if (n == null) return '—';
        const u = ['B', 'KB', 'MB', 'GB'];
        let i = 0;
        let v = n;
        while (v >= 1024 && i < u.length - 1) {
            v /= 1024;
            i++;
        }
        return `${v.toFixed(v >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
    }

    let uiWired = false;
    function wireUI() {
        if (uiWired) return;
        uiWired = true;
        document.querySelectorAll('.pair-subtab').forEach((b) => {
            b.addEventListener('click', () => {
                // Cancel in-flight dupe scan when leaving that tab
                if (b.dataset.pairTab !== 'dupes') dupeScanToken++;
                setSubtab(b.dataset.pairTab);
            });
        });
        $('pair-pick-before')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openPicker('before');
        });
        $('pair-pick-after')?.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            openPicker('after');
        });
        // Clicking the empty slot also opens picker
        $('pair-slot-before')?.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;
            openPicker('before');
        });
        $('pair-slot-after')?.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;
            openPicker('after');
        });
        $('pair-create-btn')?.addEventListener('click', () => createPair());
        $('pair-preview-draft')?.addEventListener('click', () => previewDraftSlots());
        $('pair-suggest-scan')?.addEventListener('click', () => scanNamePairSuggestions());
        $('pair-suggest-approve')?.addEventListener('click', () => approveSuggestion());
        $('pair-suggest-skip')?.addEventListener('click', () => {
            pauseSuggestBoth();
            skipSuggestion();
        });
        $('pair-suggest-swap')?.addEventListener('click', () => swapSuggestionRoles());
        $('pair-suggest-load')?.addEventListener('click', async () => {
            const ok = await loadSuggestionToSlots();
            if (ok) showToast('Loaded into slots — Preview or Create Pair when ready');
        });
        $('pair-suggest-playboth')?.addEventListener('click', () => playSuggestBoth());
        $('pair-suggest-pauseboth')?.addEventListener('click', () => pauseSuggestBoth());
        $('pair-suggest-preview')?.addEventListener('click', () => previewCurrentSuggestion());
        $('cmp-preview-approve')?.addEventListener('click', async () => {
            if (previewMode && suggestQueue.length && suggestIndex < suggestQueue.length) {
                await approveSuggestion();
                setPreviewBanner(false);
                setSubtab('pairs');
                showToast('Pair saved — continue with next suggestion if any');
                return;
            }
            if (draft.before && draft.after) {
                await createPair({ skipCompare: false });
                setPreviewBanner(false);
                return;
            }
            showToast('Nothing to approve — load a suggestion first', 'error');
        });
        $('cmp-preview-back')?.addEventListener('click', () => {
            pauseBoth();
            setPreviewBanner(false);
            setSubtab('pairs');
        });
        $('pair-refresh-btn')?.addEventListener('click', async () => {
            await loadPairs();
            renderPairList();
            showToast('Pairs refreshed');
        });
        $('pair-scan-dupes-btn')?.addEventListener('click', () => {
            setSubtab('dupes');
            // Don't auto-run huge scan without explicit intent if library is huge —
            // still run, but with safe mode
            scanDuplicates();
        });
        $('dupe-run-btn')?.addEventListener('click', () => scanDuplicates());

        $('cmp-mode')?.addEventListener('change', () => {
            stopSweep();
            applyCompareMode();
        });
        $('cmp-blend')?.addEventListener('input', applyCompareMode);
        $('cmp-play')?.addEventListener('click', playBoth);
        $('cmp-pause')?.addEventListener('click', pauseBoth);
        $('cmp-prev-frame')?.addEventListener('click', () => stepFrame(-1));
        $('cmp-next-frame')?.addEventListener('click', () => stepFrame(1));
        $('cmp-sync')?.addEventListener('click', syncBoth);
        $('cmp-swap')?.addEventListener('click', swapCompare);
        $('cmp-clear')?.addEventListener('click', clearCompareStages);
        $('cmp-sweep')?.addEventListener('click', startSweep);
        $('cmp-fit')?.addEventListener('click', () => {
            cmp.zoom = 1;
            cmp.panX = 0;
            cmp.panY = 0;
            applyCompareTransform();
        });
        $('cmp-1to1')?.addEventListener('click', () => {
            // Approximate 1:1 from after video width if known
            const v = cmp.mediaA || cmp.mediaB;
            const viewer = $('cmp-viewer');
            if (!v || !viewer) {
                setCompareZoom(1);
                return;
            }
            const nat =
                v.tagName === 'VIDEO' ? v.videoWidth : v.tagName === 'IMG' ? v.naturalWidth : 0;
            const vw = viewer.clientWidth || 1;
            if (nat > 0) setCompareZoom(nat / vw);
            else setCompareZoom(1);
        });
        $('cmp-fs')?.addEventListener('click', toggleCompareFullscreen);
        $('cmp-speed')?.addEventListener('change', applyAvSettings);
        $('cmp-mute')?.addEventListener('change', applyAvSettings);
        $('cmp-volume')?.addEventListener('input', applyAvSettings);

        // Zoom with wheel over viewer
        $('cmp-viewer')?.addEventListener(
            'wheel',
            (e) => {
                e.preventDefault();
                const factor = e.deltaY > 0 ? 0.9 : 1.1;
                setCompareZoom((cmp.zoom || 1) * factor, e.clientX, e.clientY);
            },
            { passive: false }
        );

        // Pan when zoomed (middle mouse or alt+drag)
        let panning = false;
        let panLast = null;
        $('cmp-viewer')?.addEventListener('pointerdown', (e) => {
            if (cmp.zoom <= 1.01) return;
            if (e.button === 1 || e.altKey) {
                panning = true;
                panLast = { x: e.clientX, y: e.clientY };
                e.preventDefault();
            }
        });
        window.addEventListener('pointermove', (e) => {
            if (!panning || !panLast) return;
            cmp.panX += e.clientX - panLast.x;
            cmp.panY += e.clientY - panLast.y;
            panLast = { x: e.clientX, y: e.clientY };
            applyCompareTransform();
        });
        window.addEventListener('pointerup', () => {
            panning = false;
            panLast = null;
        });

        // Keyboard when compare pane active
        document.addEventListener('keydown', (e) => {
            const pane = $('pair-pane-compare');
            if (!pane?.classList.contains('active')) return;
            const t = e.target;
            if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT' || t.isContentEditable))
                return;
            if (e.code === 'Space') {
                e.preventDefault();
                const vids = bothVideos();
                if (vids.some((v) => !v.paused)) pauseBoth();
                else playBoth();
            } else if (e.key === ',' || e.key === '<') {
                e.preventDefault();
                stepFrame(-1);
            } else if (e.key === '.' || e.key === '>') {
                e.preventDefault();
                stepFrame(1);
            } else if (e.key === 'f' || e.key === 'F') {
                e.preventDefault();
                toggleCompareFullscreen();
            }
        });

        wireSliderDrag();

        $('thumb-seek-sec')?.addEventListener('input', (e) => {
            if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = e.target.value;
            if ($('thumb-seek-sec-num')) $('thumb-seek-sec-num').value = e.target.value;
        });
        $('thumb-seek-sec-num')?.addEventListener('input', (e) => {
            if ($('thumb-seek-sec')) $('thumb-seek-sec').value = e.target.value;
            if ($('thumb-seek-sec-val')) $('thumb-seek-sec-val').textContent = e.target.value;
        });
        $('thumb-seek-save')?.addEventListener('click', () => {
            const v = parseFloat($('thumb-seek-sec-num')?.value || $('thumb-seek-sec')?.value || '1');
            saveThumbSeek(v);
        });
        $('thumb-regen-pair')?.addEventListener('click', async () => {
            if (draft.before?.file) {
                draft.before.thumbUrl =
                    draft.before.type === 'photo'
                        ? URL.createObjectURL(draft.before.file)
                        : await generateThumbnail(draft.before.file, thumbSeekSec);
                renderSlot('before');
            }
            if (draft.after?.file) {
                draft.after.thumbUrl =
                    draft.after.type === 'photo'
                        ? URL.createObjectURL(draft.after.file)
                        : await generateThumbnail(draft.after.file, thumbSeekSec);
                renderSlot('after');
            }
            showToast('Pair slot thumbs regenerated');
        });

        $('pair-picker-close')?.addEventListener('click', () => {
            $('pair-picker-modal')?.classList.add('hidden');
        });
        $('pair-picker-modal')?.addEventListener('click', (e) => {
            if (e.target.id === 'pair-picker-modal') e.target.classList.add('hidden');
        });
        let filterTimer = null;
        $('pair-picker-filter')?.addEventListener('input', () => {
            clearTimeout(filterTimer);
            filterTimer = setTimeout(() => {
                if (pickTarget) openPicker(pickTarget);
            }, 250);
        });
    }

    async function init(opts = {}) {
        db = opts.db || null;
        if (typeof opts.showToast === 'function') showToast = opts.showToast;
        if (typeof opts.generateThumbnail === 'function') genThumb = opts.generateThumbnail;
        await loadThumbSeek();
        await loadPairs();
        wireUI();
        renderPairList();
        renderSlot('before');
        renderSlot('after');
        applyCompareMode();
    }

    async function onActivate(opts = {}) {
        if (opts.db) db = opts.db;
        await loadThumbSeek();
        await loadPairs();
        renderPairList();
    }

    function getThumbSeekSec() {
        return thumbSeekSec;
    }

    global.FAFOPairs = {
        init,
        onActivate,
        getThumbSeekSec,
        generateThumbnail,
        loadCompareFromPair,
        setSubtab,
    };
})(typeof window !== 'undefined' ? window : globalThis);
