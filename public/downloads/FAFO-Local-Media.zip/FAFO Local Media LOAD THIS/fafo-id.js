/**
 * FAFO shared media identity helpers.
 * Stable keys + exact-only meta lookup (no fuzzy name includes).
 */
(function (global) {
    'use strict';

    /** Soft normalize only — never truncate long dumps into fake tags. */
    function normalizeTag(t) {
        return String(t || '')
            .trim()
            .replace(/\s+/g, ' ')
            .replace(/[\u0000-\u001f\u007f]/g, '');
    }

    /** Reject metadata dumps / paths so they never re-enter library or files. */
    const TAG_MAX_CHARS = 100;
    function isOversizedOrSuspectTag(t) {
        const s = String(t || '').trim();
        if (!s) return true;
        if (s.length >= TAG_MAX_CHARS) return true;
        if (/^[A-Za-z]:[\\/]/.test(s)) return true;
        if (/^\\\\[^\\]/.test(s)) return true;
        if (s.includes('\\\\') && s.length > 40) return true;
        if ((s.match(/[;|{}[\]]/g) || []).length >= 4 && s.length > 40) return true;
        if ((s.match(/[,;]/g) || []).length >= 3 && s.length > 36) return true;
        if (/System\.(Keywords|Rating|Media|Photo|Item|Prop)/i.test(s)) return true;
        if (/\{[^{}]{20,}\}/.test(s)) return true;
        if (/=/.test(s) && s.length > 40 && /[;,]/.test(s)) return true;
        if (/[\t\r\n]/.test(String(t || ''))) return true;
        return false;
    }

    function displayNameFromItem(item) {
        if (!item) return 'Unknown';
        if (item.handle?.name) return item.handle.name;
        if (typeof item === 'object' && item.name) return item.name;
        if (item.url) {
            try {
                return decodeURIComponent(item.url.split('?')[0].split('/').pop() || item.url);
            } catch {
                return item.url;
            }
        }
        if (typeof item === 'string') {
            try {
                return decodeURIComponent(item.split('/').pop() || item);
            } catch {
                return item;
            }
        }
        return 'Unknown';
    }

    /** Canonical storage key: file:name|size|mtime or url:/handle: fallbacks */
    function keyFromParts(name, size, mtime) {
        const n = name || 'unknown';
        if (size != null && mtime != null) return `file:${n}|${size}|${mtime}`;
        if (size != null) return `file:${n}|${size}`;
        return `handle:${n}`;
    }

    function keyFromFile(file, nameHint) {
        if (!file) return keyFromParts(nameHint || 'unknown', null, null);
        return keyFromParts(file.name || nameHint || 'unknown', file.size, file.lastModified);
    }

    async function mediaKeyFor(item) {
        if (!item) return null;
        if (item.mediaKey) return item.mediaKey;
        if (item.handle) {
            try {
                const f = await item.handle.getFile();
                return keyFromFile(f, item.name || item.handle.name);
            } catch {
                return 'handle:' + (item.handle.name || item.name || 'unknown');
            }
        }
        if (typeof item === 'object' && typeof item.getFile === 'function') {
            try {
                const f = await item.getFile();
                return keyFromFile(f, item.name);
            } catch {
                return 'handle:' + (item.name || 'unknown');
            }
        }
        if (item.url) return 'url:' + item.url;
        if (typeof item === 'string') return 'url:' + item;
        return 'unknown:' + displayNameFromItem(item);
    }

    async function identityForItem(item) {
        const name = displayNameFromItem(item);
        if (item?.handle?.getFile) {
            try {
                const f = await item.handle.getFile();
                return {
                    name: f.name || name,
                    size: f.size,
                    mtime: f.lastModified,
                    key: keyFromFile(f, name),
                };
            } catch { /* fall through */ }
        }
        if (typeof item === 'object' && typeof item.getFile === 'function') {
            try {
                const f = await item.getFile();
                return {
                    name: f.name || name,
                    size: f.size,
                    mtime: f.lastModified,
                    key: keyFromFile(f, name),
                };
            } catch { /* fall through */ }
        }
        if (item?.url) {
            return { name, size: null, mtime: null, key: 'url:' + item.url };
        }
        return { name, size: null, mtime: null, key: await mediaKeyFor(item) };
    }

    /**
     * Exact-only lookup in fafoMediaMeta.
     * Order: exact key → exact name+size → unique exact name (no partial includes).
     */
    function findStoredMeta(mediaMeta, opts) {
        const meta = mediaMeta || {};
        const key = opts?.key || null;
        const name = opts?.name || null;
        const size = opts?.size;
        if (key && meta[key]) return { key, meta: meta[key] };

        const low = name ? String(name).toLowerCase() : '';
        if (low && size != null) {
            for (const [k, v] of Object.entries(meta)) {
                if (!v) continue;
                const vName = v.name != null ? String(v.name).toLowerCase() : '';
                const vSize = v.size != null ? v.size : null;
                if (vName === low && vSize === size) return { key: k, meta: v };
                // Key embeds size: file:name|size|mtime
                if (k.startsWith('file:') && k.toLowerCase().startsWith('file:' + low + '|' + size)) {
                    return { key: k, meta: v };
                }
            }
        }

        if (low) {
            const hits = [];
            for (const [k, v] of Object.entries(meta)) {
                if (!v) continue;
                const vName = v.name != null ? String(v.name).toLowerCase() : '';
                if (vName === low) hits.push({ key: k, meta: v });
            }
            if (hits.length === 1) return hits[0];
        }
        return null;
    }

    function tagCountFromMeta(entry) {
        if (!entry || !Array.isArray(entry.tags)) return 0;
        // Count only user-facing tags (pair IDs / role tags live on pairId field)
        return userTagsOnly(entry.tags).length;
    }

    /**
     * Pair IDs and role stamps are NOT user tags.
     * Stored on mediaMeta[key].pairId / pairRole — not the tags chip list.
     */
    const SYSTEM_ROLE_TAGS = new Set([
        'source', 'before', 'after', 'pair', 'vsr',
        'upscaled', 'upscaled-video', 'upscaled-image',
        'original-video', 'original-image', 'original',
        'image',
    ]);

    function isPairIdTag(tag) {
        const t = normalizeTag(tag);
        if (!t) return false;
        return /^pair_ID_\d{1,6}$/i.test(t) || /^UP-\d{1,6}$/i.test(t);
    }

    function isSystemRoleTag(tag) {
        const t = normalizeTag(tag).toLowerCase();
        return !!t && SYSTEM_ROLE_TAGS.has(t);
    }

    /** Built-in non-user tags (pair IDs + role stamps). */
    function isSystemOrPairTag(tag) {
        return isPairIdTag(tag) || isSystemRoleTag(tag);
    }

    /** User chose to hide this name from the tag list UI (data can still exist). */
    function isExcludedTag(tag, excluded) {
        const low = normalizeTag(tag).toLowerCase();
        if (!low || !Array.isArray(excluded) || !excluded.length) return false;
        return excluded.some((e) => normalizeTag(e).toLowerCase() === low);
    }

    /**
     * Hide from tag list / suggestions after sync.
     * Pair/role tags are always hidden; user exclusions are display-only.
     */
    function isHiddenTag(tag, excluded) {
        if (isOversizedOrSuspectTag(tag)) return true;
        if (isSystemOrPairTag(tag)) return true;
        if (isExcludedTag(tag, excluded)) return true;
        return !normalizeTag(tag);
    }

    /**
     * Tags that belong on a file as real user tags (strips pair IDs + role stamps + junk dumps).
     * Does NOT apply user exclude list — exclusions only affect the list UI.
     */
    function userTagsOnly(tags) {
        if (!Array.isArray(tags)) return [];
        return tags
            .map(normalizeTag)
            .filter((t) => t && !isSystemOrPairTag(t) && !isOversizedOrSuspectTag(t));
    }

    /** What should appear in the tag library / suggestions. */
    function listVisibleTags(tags, excluded) {
        if (!Array.isArray(tags)) return [];
        return tags
            .map(normalizeTag)
            .filter((t) => t && !isHiddenTag(t, excluded) && !isOversizedOrSuspectTag(t));
    }

    /** Pull pair id from explicit field or legacy tag list. */
    function pairIdFromMeta(entry) {
        if (!entry) return '';
        if (entry.pairId && isPairIdTag(entry.pairId)) return normalizeTag(entry.pairId);
        const hit = (entry.tags || []).find((t) => isPairIdTag(t));
        return hit ? normalizeTag(hit) : '';
    }

    global.FAFOId = {
        normalizeTag,
        TAG_MAX_CHARS,
        isOversizedOrSuspectTag,
        displayNameFromItem,
        keyFromParts,
        keyFromFile,
        mediaKeyFor,
        identityForItem,
        findStoredMeta,
        tagCountFromMeta,
        SYSTEM_ROLE_TAGS,
        isPairIdTag,
        isSystemRoleTag,
        isSystemOrPairTag,
        isExcludedTag,
        isHiddenTag,
        userTagsOnly,
        listVisibleTags,
        pairIdFromMeta,
    };
})(typeof globalThis !== 'undefined' ? globalThis : window);
