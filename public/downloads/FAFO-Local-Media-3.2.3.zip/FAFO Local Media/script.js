document.addEventListener('DOMContentLoaded', async () => {
    // --- DOM ELEMENTS ---
    const scene = document.getElementById('scene-root');
    const overlay = document.getElementById('overlay');
    const bokehCanvas = document.getElementById('bokeh-canvas');
    const ui = {
        clock: document.getElementById('clock'),
        date: document.getElementById('date'),
        box: document.getElementById('ui-container')
    };
    const hud = {
        box: document.getElementById('player-hud'),
        title: document.getElementById('hud-title'),
        index: document.getElementById('hud-index'),
        play: document.getElementById('hud-play'),
        prev: document.getElementById('hud-prev'),
        next: document.getElementById('hud-next'),
        shuffle: document.getElementById('hud-shuffle'),
        speedDown: document.getElementById('hud-speed-down'),
        speed: document.getElementById('hud-speed'),
        speedUp: document.getElementById('hud-speed-up'),
        mute: document.getElementById('hud-mute'),
        volume: document.getElementById('hud-volume'),
        pip: document.getElementById('hud-pip'),
        fs: document.getElementById('hud-fs'),
        progressWrap: document.getElementById('hud-progress-wrap'),
        progressTrack: document.getElementById('hud-progress-track'),
        progress: document.getElementById('hud-progress'),
        progressThumb: document.getElementById('hud-progress-thumb'),
        timeCurrent: document.getElementById('hud-time-current'),
        timeTotal: document.getElementById('hud-time-total')
    };
    const emptyState = document.getElementById('empty-state');
    const neonFrame = document.getElementById('neon-frame');
    const shortcutHelp = document.getElementById('shortcut-help');

    // --- 1. CONFIGURATION DEFAULTS ---
    let cfg = {
        // Library Settings
        useLocal: true, 
        usePhotos: true, 
        urls: [],
        activePlaylistId: 'all', 
        
        // Layout Settings
        layout: 'cinema', 
        scaling: 'scale-capped',
        gridCols: 4, 
        gridRows: 1, 
        carouselCount: 8, 
        carouselRadius: 650, 
        carouselTilt: 0,
        carouselSpeed: 40,
        reflectOpacity: 30, 
        reflectOffset: 0,
        
        // Playback Settings
        loops: 1, 
        shuffle: true, 
        volume: 0.7,
        playbackSpeed: 1,
        photoDuration: 3, 
        kenburns: true,
        
        // Visual Settings
        accentColor: '#00e5ff', 
        brightness: 100, 
        contrast: 100, 
        saturate: 100, 
        sepia: 0, 
        grayscale: 0,
        
        // Ambilight & Borders
        borderSize: 0, 
        borderColor: '#44858d', 
        borderGlow: 15,
        ambiScale: 1.0, 
        ambiOpacity: 0.25, 
        ambiBlur: 5,
        ambiMode: 'blur',

        // Audio-reactive neon border
        neonBorder: false,
        neonPattern: 'chase',
        neonSegments: 24,
        neonSpeed: 1,
        neonAudio: true,
        neonStrobe: 0.8,
        neonSensitivity: 1.2,
        neonWidth: 4,
        neonUseAccent: true,
        neonColor: '#00e5ff',
        
        // Detailed Particle Configs (Updated with all controls)
        fxSnow: false, fxSnowSpeed: 1, fxSnowDensity: 50, fxSnowSize: 3, fxSnowBlur: 0,
        fxRain: false, fxRainSpeed: 15, fxRainDensity: 100, fxRainSize: 20, fxRainBlur: 0,
        fxEmbers: false, fxEmbersSpeed: 2, fxEmbersDensity: 60, fxEmbersSize: 3, fxEmbersBlur: 0,
        fxSmoke: false, fxSmokeSpeed: 1, fxSmokeDensity: 30, fxSmokeSize: 10, fxSmokeBlur: 5,
        fxSparks: false, fxSparksSpeed: 3, fxSparksDensity: 40, fxSparksSize: 2, fxSparksBlur: 0,
        fxNeon: false, fxNeonSpeed: 1, fxNeonDensity: 20, fxNeonSize: 5, fxNeonBlur: 2,
        
        // UI Settings
        showDate: true, 
        format12h: true, 
        showSeconds: false,
        clockSize: 25, 
        font: "'Arial Black', sans-serif", 
        pos: 'pos-bottom-left',
        
        // Per-File Overrides
        overrides: {} 
    };

    // --- STATE VARIABLES ---
    let playlist = [];
    let currentIdx = 0;
    let loopCount = 0;
    let db = null;
    let mainVideo = null;
    let ambienceVideo = null;
    let photoTimeout = null;
    let collageInterval = null; 
    let isPaused = false;
    let permissionWarned = false;
    let healthCheckInterval = null;
    let consecutiveErrors = 0;
    let currentBlobUrl = null;
    let clockInterval = null;
    let neonEngine = null;
    let particleEngine = null;
    let progressInterval = null;
    let libraryEmpty = false;
    let isSeeking = false;
    let hudIdleTimer = null;
    let gridResizeTimer = null;
    const HUD_IDLE_MS = 5000;
    const SPEED_STEPS = [0.25, 0.33, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2];

    // --- 2. INITIALIZATION SEQUENCE ---
    await loadConfig();
    applyGlobalStyles();
    applyHUD();
    await initDB();
    await buildPlaylist();
    initNeonEngine();
    refreshParticles();
    initLayout();
    startClock();
    initInputListeners();
    initHudControls();
    initHudAutoHide();
    initGridResizeListener();
    startHealthCheck();
    listenForConfigChanges();

    // --- 3. CORE FUNCTIONS ---

    async function loadConfig() {
        const {mediaConfig = {}} = await chrome.storage.local.get('mediaConfig');
        cfg = {...cfg, ...mediaConfig};
    }

    function listenForConfigChanges() {
        chrome.storage.onChanged.addListener(async (changes, area) => {
            if (area !== 'local' || !changes.mediaConfig) return;
            const prevLayout = cfg.layout;
            cfg = {...cfg, ...changes.mediaConfig.newValue};
            applyGlobalStyles();
            applyHUD();
            initNeonEngine();
            refreshParticles();
            await buildPlaylist();
            if (cfg.layout !== prevLayout || changes.mediaConfig.newValue?.activePlaylistId !== undefined) {
                initLayout();
            } else {
                updateHUD();
            }
        });
    }

    function initNeonEngine() {
        if (!neonEngine) neonEngine = new NeonBorderEngine(neonFrame, () => cfg);
        neonEngine.rebuild();
        neonEngine.start();
    }

    function refreshParticles() {
        const anyFx = cfg.fxSnow || cfg.fxRain || cfg.fxEmbers || cfg.fxSmoke || cfg.fxSparks || cfg.fxNeon;
        document.body.classList.toggle('fx-active', anyFx);
        if (!particleEngine) particleEngine = new ParticleFXEngine(bokehCanvas, () => cfg);
        if (anyFx) {
            particleEngine.rebuild();
            if (!particleEngine.rafId) particleEngine.start();
            syncParticlePerformance();
        } else {
            particleEngine.destroy();
        }
    }

    function syncParticlePerformance() {
        if (!particleEngine) return;
        const videoBusy = cfg.layout === 'cinema' && mainVideo && !mainVideo.paused && !isPaused;
        particleEngine.setPerformanceMode(videoBusy);
    }

    function computeOptimalGrid(cellCount) {
        if (cellCount <= 1) return { cols: 1, rows: 1 };
        const aspect = innerWidth / innerHeight;
        let best = { cols: 1, rows: cellCount, score: -Infinity };
        for (let cols = 1; cols <= cellCount; cols++) {
            const rows = Math.ceil(cellCount / cols);
            const waste = cols * rows - cellCount;
            const cellAspect = (cols / rows) * aspect;
            const target = 16 / 9;
            const score = -Math.abs(Math.log(cellAspect / target)) - waste * 0.45;
            if (score > best.score) best = { cols, rows, score };
        }
        return { cols: best.cols, rows: best.rows };
    }

    function applyGridDimensions() {
        const cellCount = Math.max(1, (cfg.gridCols || 4) * (cfg.gridRows || 1));
        const grid = computeOptimalGrid(cellCount);
        document.documentElement.style.setProperty('--grid-cols', grid.cols);
        document.documentElement.style.setProperty('--grid-rows', grid.rows);
        return { ...grid, cellCount };
    }

    function initGridResizeListener() {
        window.addEventListener('resize', () => {
            if (cfg.layout !== 'grid') return;
            clearTimeout(gridResizeTimer);
            gridResizeTimer = setTimeout(applyGridDimensions, 120);
        });
    }

    function revokeCurrentBlob() {
        if (currentBlobUrl) {
            URL.revokeObjectURL(currentBlobUrl);
            currentBlobUrl = null;
        }
    }

    // NEW: Helper for Theme Engine
    function hexToRgb(hex) {
        const shorthandRegex = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        hex = hex.replace(shorthandRegex, (m, r, g, b) => r + r + g + g + b + b);
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
            r: parseInt(result[1], 16),
            g: parseInt(result[2], 16),
            b: parseInt(result[3], 16)
        } : null;
    }

    function applyGlobalStyles() {
        const root = document.documentElement;
        
        // Apply Accent Color Logic
        const rgb = hexToRgb(cfg.accentColor || '#00e5ff');
        if (rgb) {
            root.style.setProperty('--accent', cfg.accentColor);
            root.style.setProperty('--accent-dim', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.15)`);
            root.style.setProperty('--accent-glow', `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.6)`);
        }

        // Color Grading
        root.style.setProperty('--brightness', `${cfg.brightness}%`);
        root.style.setProperty('--contrast', `${cfg.contrast}%`);
        root.style.setProperty('--saturate', `${cfg.saturate}%`);
        root.style.setProperty('--sepia', `${cfg.sepia}%`);
        root.style.setProperty('--grayscale', `${cfg.grayscale}%`);
        
        // Borders & Layout
        root.style.setProperty('--border-size', `${cfg.borderSize}px`);
        root.style.setProperty('--border-color', cfg.borderColor);
        root.style.setProperty('--border-glow', `${cfg.borderGlow}px`);
        if (cfg.layout === 'grid') applyGridDimensions();
        else {
            root.style.setProperty('--grid-cols', cfg.gridCols);
            root.style.setProperty('--grid-rows', cfg.gridRows);
        }
        
        // Reflections (Convert 0-100 to 0.0-1.0)
        root.style.setProperty('--reflect-op', `${cfg.reflectOpacity / 100}`);
        root.style.setProperty('--reflect-off', `${cfg.reflectOffset}px`);
    }

    function applyHUD() {
        ui.clock.style.fontSize = `${cfg.clockSize}px`;
        ui.box.style.fontFamily = cfg.font;
        ui.box.className = cfg.pos;
        ui.date.style.display = cfg.showDate ? 'block' : 'none';
    }

    function initInputListeners() {
        document.addEventListener('keydown', (e) => {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
            if (e.code === 'Space') { e.preventDefault(); togglePause(); }
            if (e.code === 'ArrowRight') skipTrack(1);
            if (e.code === 'ArrowLeft') skipTrack(-1);
            if (e.code === 'KeyM') toggleMute();
            if (e.code === 'KeyS') toggleShuffle();
            if (e.code === 'KeyP') togglePiP();
            if (e.code === 'KeyF') toggleFullscreen();
            if (e.code === 'Comma') changeSpeed(-1);
            if (e.code === 'Period') changeSpeed(1);
            if (e.key === '?') shortcutHelp?.classList.toggle('hidden');
            revealHud();
        });
        document.addEventListener('click', (e) => {
            if (e.target.closest('a') || e.target.closest('button') || e.target.closest('.modal') || e.target.closest('.player-hud')) return;
            togglePause();
        });
        document.addEventListener('mousemove', revealHud, { passive: true });
        
        // Creative 3D Tilt for Carousel
        document.addEventListener('mousemove', (e) => {
            if (cfg.layout === 'carousel') {
                const x = (e.clientX / window.innerWidth - 0.5) * 2; // -1 to 1
                const y = (e.clientY / window.innerHeight - 0.5) * 2;
                
                const pivot = document.querySelector('.carousel-pivot');
                if(pivot) {
                    pivot.style.transformOrigin = 'center center';
                    scene.style.transform = `rotateX(${cfg.carouselTilt + (y * 10)}deg) rotateY(${x * 10}deg)`;
                }
            }
        });
    }

    function skipTrack(dir) {
        if (!playlist.length) return;
        clearTimeout(photoTimeout);
        currentIdx = (currentIdx + dir + playlist.length) % playlist.length;
        loopCount = 0;
        playNext();
    }

    function toggleMute() {
        if (!mainVideo) return;
        mainVideo.muted = !mainVideo.muted;
        if (!mainVideo.muted && mainVideo.volume === 0 && hud.volume) {
            mainVideo.volume = hud.volume.value / 100;
        }
        updateHudMuteIcon();
    }

    function toggleShuffle() {
        cfg.shuffle = !cfg.shuffle;
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, shuffle: cfg.shuffle}});
        });
        if (cfg.shuffle && playlist.length > 1) {
            const current = playlist[currentIdx];
            playlist = playlist.filter((_, i) => i !== currentIdx).sort(() => Math.random() - 0.5);
            playlist.unshift(current);
            currentIdx = 0;
            updateHUD();
        }
    }

    function formatSpeedLabel(speed) {
        if (speed === 1) return '1×';
        if (speed === 0.33) return '0.33×';
        if (speed === 0.25) return '0.25×';
        return `${speed}×`;
    }

    function changeSpeed(dir) {
        const idx = SPEED_STEPS.indexOf(cfg.playbackSpeed);
        const base = idx < 0 ? SPEED_STEPS.indexOf(1) : idx;
        const next = SPEED_STEPS[Math.max(0, Math.min(SPEED_STEPS.length - 1, base + dir))];
        setPlaybackSpeed(next);
        revealHud();
    }

    function setPlaybackSpeed(speed) {
        cfg.playbackSpeed = speed;
        if (mainVideo) mainVideo.playbackRate = speed;
        if (ambienceVideo) ambienceVideo.playbackRate = speed;
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(speed);
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, playbackSpeed: speed}});
        });
    }

    async function togglePiP() {
        if (!mainVideo || mainVideo.tagName !== 'VIDEO') return;
        try {
            if (document.pictureInPictureElement) {
                await document.exitPictureInPicture();
            } else if (document.pictureInPictureEnabled) {
                await mainVideo.requestPictureInPicture();
            }
        } catch (e) { console.warn('PiP unavailable', e); }
    }

    function formatTime(sec) {
        if (!isFinite(sec) || sec < 0) return '0:00';
        const m = Math.floor(sec / 60);
        const s = Math.floor(sec % 60).toString().padStart(2, '0');
        return `${m}:${s}`;
    }

    function updateProgressUI() {
        if (!mainVideo || !mainVideo.duration) return;
        const ratio = mainVideo.currentTime / mainVideo.duration;
        const pct = `${ratio * 100}%`;
        if (hud.progress) hud.progress.style.width = pct;
        if (hud.progressThumb) hud.progressThumb.style.left = pct;
        if (hud.timeCurrent) hud.timeCurrent.textContent = formatTime(mainVideo.currentTime);
        if (hud.timeTotal) hud.timeTotal.textContent = formatTime(mainVideo.duration);
    }

    function seekFromEvent(e) {
        if (!mainVideo || !mainVideo.duration || !hud.progressTrack) return;
        const rect = hud.progressTrack.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        mainVideo.currentTime = ratio * mainVideo.duration;
        if (ambienceVideo && ambienceVideo.duration) ambienceVideo.currentTime = mainVideo.currentTime;
        updateProgressUI();
    }

    function initProgressSeek() {
        if (!hud.progressTrack) return;
        const onDown = (e) => {
            if (!mainVideo?.duration) return;
            isSeeking = true;
            hud.progressTrack.classList.add('seeking');
            seekFromEvent(e);
            e.preventDefault();
        };
        const onMove = (e) => { if (isSeeking) seekFromEvent(e); };
        const onUp = () => {
            isSeeking = false;
            hud.progressTrack?.classList.remove('seeking');
        };
        hud.progressTrack.addEventListener('mousedown', onDown);
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
    }

    function setVolume(level) {
        const vol = Math.max(0, Math.min(1, level));
        cfg.volume = vol;
        if (mainVideo) {
            mainVideo.volume = vol;
            if (vol > 0 && mainVideo.muted) mainVideo.muted = false;
        }
        if (hud.volume) hud.volume.value = Math.round(vol * 100);
        updateHudMuteIcon();
        chrome.storage.local.get('mediaConfig', ({mediaConfig = {}}) => {
            chrome.storage.local.set({mediaConfig: {...mediaConfig, volume: vol}});
        });
    }

    function revealHud() {
        if (!hud.box || cfg.layout !== 'cinema') return;
        hud.box.classList.add('hud-visible');
        hud.box.classList.remove('hud-idle');
        clearTimeout(hudIdleTimer);
        hudIdleTimer = setTimeout(() => {
            if (!hud.box.matches(':hover')) hud.box.classList.add('hud-idle');
            hud.box.classList.remove('hud-visible');
        }, HUD_IDLE_MS);
    }

    function initHudAutoHide() {
        if (cfg.layout === 'cinema') revealHud();
        else if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
    }

    function updateEmptyState() {
        if (!emptyState) return;
        emptyState.classList.toggle('hidden', !libraryEmpty || cfg.layout !== 'cinema');
    }

    function toggleFullscreen() {
        document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
    }

    function togglePause() {
        isPaused = !isPaused;
        ui.clock.style.opacity = isPaused ? 0.5 : 1;
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';

        if (cfg.layout === 'collage') return;

        if (!mainVideo) return;
        if (isPaused) {
            mainVideo.pause();
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.pause();
        } else {
            mainVideo.play().catch(() => {});
            if (ambienceVideo && cfg.ambiMode === 'blur') ambienceVideo.play().catch(() => {});
        }
        syncParticlePerformance();
        revealHud();
    }

    function getTrackName(item) {
        if (!item) return '—';
        if (item.handle?.name) return item.handle.name;
        if (item.url) return item.url.split('/').pop().split('?')[0] || 'Stream';
        return 'Unknown';
    }

    function updateHUD() {
        if (!hud.box) return;
        const item = playlist[currentIdx];
        if (hud.title) hud.title.textContent = getTrackName(item);
        if (hud.index) hud.index.textContent = playlist.length ? `${currentIdx + 1} / ${playlist.length}` : '0 / 0';
        if (hud.play) hud.play.textContent = isPaused ? '▶' : '⏸';
        if (hud.shuffle) hud.shuffle.classList.toggle('active', cfg.shuffle);
        if (hud.speed) hud.speed.textContent = formatSpeedLabel(cfg.playbackSpeed || 1);
        updateHudMuteIcon();
        const isVideo = item?.type === 'video' && cfg.layout === 'cinema';
        if (hud.progressWrap) hud.progressWrap.classList.toggle('hidden', !isVideo);
        if (!isVideo && hud.timeCurrent) hud.timeCurrent.textContent = '0:00';
        if (!isVideo && hud.timeTotal) hud.timeTotal.textContent = '0:00';
        updateEmptyState();
    }

    function updateHudMuteIcon() {
        if (!hud.mute) return;
        const muted = !mainVideo || mainVideo.muted || mainVideo.volume === 0;
        hud.mute.textContent = muted ? '🔇' : '🔊';
    }

    function startProgressBar() {
        if (progressInterval) clearInterval(progressInterval);
        if (!mainVideo) return;
        mainVideo.removeEventListener('timeupdate', updateProgressUI);
        mainVideo.addEventListener('timeupdate', updateProgressUI);
        updateProgressUI();
    }

    function bindHudReveal(el, fn) {
        if (!el) return;
        el.addEventListener('click', () => { revealHud(); fn(); });
    }

    function initHudControls() {
        bindHudReveal(hud.prev, () => skipTrack(-1));
        bindHudReveal(hud.next, () => skipTrack(1));
        bindHudReveal(hud.play, () => togglePause());
        bindHudReveal(hud.shuffle, () => toggleShuffle());
        bindHudReveal(hud.speedDown, () => changeSpeed(-1));
        bindHudReveal(hud.speedUp, () => changeSpeed(1));
        if (hud.speed) hud.speed.onclick = () => { revealHud(); setPlaybackSpeed(1); };
        bindHudReveal(hud.mute, () => toggleMute());
        bindHudReveal(hud.pip, () => togglePiP());
        bindHudReveal(hud.fs, () => toggleFullscreen());
        if (hud.volume) {
            hud.volume.value = Math.round((cfg.volume ?? 0.7) * 100);
            hud.volume.addEventListener('input', () => {
                revealHud();
                setVolume(hud.volume.value / 100);
            });
        }
        initProgressSeek();
        const helpClose = document.getElementById('help-close');
        if (helpClose) helpClose.onclick = () => shortcutHelp?.classList.add('hidden');
        if (hud.box) {
            hud.box.addEventListener('mouseenter', revealHud);
            hud.box.addEventListener('mousemove', revealHud);
        }
        if (hud.progressTrack) {
            hud.progressTrack.addEventListener('mousedown', revealHud);
        }
        updateHUD();
    }

    // --- 4. LIBRARY MANAGEMENT ---

    async function buildPlaylist() {
        playlist = [];
        libraryEmpty = false;
        
        // 1. PLAYLIST MODE: Check if a specific playlist is active
        if (cfg.activePlaylistId && cfg.activePlaylistId !== 'all') {
            try {
                const tx = db.transaction('playlists', 'readonly');
                const store = tx.objectStore('playlists');
                const pl = await new Promise(res => {
                    const req = store.get(cfg.activePlaylistId);
                    req.onsuccess = () => res(req.result);
                    req.onerror = () => res(null);
                });

                if (pl && pl.items && pl.items.length > 0) {
                    // Items are stored as {store: 'videos', key: ...}
                    // We need to fetch the actual handles
                    for (const itemRef of pl.items) {
                        const handle = await getHandleByKey(itemRef.store, itemRef.key);
                        if (handle) {
                            playlist.push({
                                type: itemRef.store === 'videos' ? 'video' : 'photo',
                                handle: handle
                            });
                        }
                    }
                }
            } catch(e) { console.warn("Failed to load playlist", e); }
        } 
        
        // 2. FALLBACK TO ALL IF EMPTY OR 'ALL' MODE
        if (playlist.length === 0) {
            if (cfg.useLocal) {
                const videos = await getHandles('videos');
                if (videos.length) playlist.push(...videos.map(h => ({type: 'video', handle: h})));
            }
            if (cfg.usePhotos) {
                const photos = await getHandles('photos');
                if (photos.length) playlist.push(...photos.map(h => ({type: 'photo', handle: h})));
            }
            const bundled = await loadBundledLibrary();
            if (bundled.length > 0) playlist.push(...bundled);
        }
        
        // 3. FINAL FALLBACK
        if (playlist.length === 0) {
            if (cfg.urls && cfg.urls.length > 0) {
                playlist = cfg.urls.map(u => ({type: 'video', url: u}));
            } else {
                libraryEmpty = true;
                playlist = [{type: 'video', url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm', isDemo: true}];
            }
        }
        
        if (cfg.shuffle) playlist = playlist.sort(() => Math.random() - 0.5);
        updateEmptyState();
    }

    // Helper to get specific item for playlist
    async function getHandleByKey(storeName, key) {
        return new Promise(res => {
            try {
                const tx = db.transaction(storeName, 'readonly');
                const req = tx.objectStore(storeName).get(key);
                req.onsuccess = () => res(req.result);
                req.onerror = () => res(null);
            } catch(e) { res(null); }
        });
    }

    async function loadBundledLibrary() {
        try {
            const resp = await fetch('library.json');
            if (!resp.ok) return [];
            const files = await resp.json();
            return files.map(f => {
                const path = f.replace(/^videos\//i, 'Videos/').replace(/^photos\//i, 'Photos/');
                return {
                    type: path.match(/\.(jpg|jpeg|png|webp|gif)$/i) ? 'photo' : 'video',
                    url: path,
                    isBundled: true
                };
            });
        } catch (e) {
            return [];
        }
    }

    async function getSrc(item) {
        if (item.url) return item.url;
        if (item.handle) {
            if (item.handle instanceof File) {
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(item.handle);
                return currentBlobUrl;
            }
            try {
                const file = await item.handle.getFile();
                revokeCurrentBlob();
                currentBlobUrl = URL.createObjectURL(file);
                return currentBlobUrl;
            } catch (e) {
                if (!permissionWarned) {
                    permissionWarned = true;
                    const warn = document.createElement('button');
                    warn.textContent = "⚠️ Permissions Lost - Click to Restore";
                    warn.style.cssText = "position:fixed; top:20px; left:50%; transform:translateX(-50%); background:#d32f2f; color:white; padding:12px 24px; border:none; border-radius:8px; font-weight:bold; cursor:pointer; z-index:9999; box-shadow: 0 4px 15px rgba(0,0,0,0.5);";
                    warn.onclick = () => window.location.href = 'options.html';
                    document.body.appendChild(warn);
                }
                return null;
            }
        }
        return null;
    }

    async function getHandles(store) {
        if (!db) return [];
        try {
            const tx = db.transaction(store, 'readonly');
            const req = tx.objectStore(store).getAll();
            return new Promise(res => req.onsuccess = () => res(req.result || []));
        } catch(e) { return []; }
    }
    

    /** Center video without upscaling past native resolution (scale-capped). */
    function applyCappedCinemaSize(videoEl) {
        if (!videoEl) return;
        const place = () => {
            const vw = videoEl.videoWidth || videoEl.naturalWidth || 0;
            const vh = videoEl.videoHeight || videoEl.naturalHeight || 0;
            // Prefer native size; never stretch to full viewport when metadata known
            const maxH = Math.min(
                window.innerHeight || 1080,
                vh > 0 ? vh : Math.min(window.innerHeight || 1080, 1080)
            );
            const maxW = Math.min(
                window.innerWidth || 1920,
                vw > 0 ? vw : Math.min(window.innerWidth || 1920, 1920)
            );
            let drawW = vw || Math.min(maxW, 1280);
            let drawH = vh || Math.min(maxH, 720);
            if (vw > 0 && vh > 0) {
                drawW = vw;
                drawH = vh;
            }
            if (drawW > maxW || drawH > maxH) {
                const s = Math.min(maxW / Math.max(drawW, 1), maxH / Math.max(drawH, 1));
                drawW = Math.round(drawW * s);
                drawH = Math.round(drawH * s);
            }
            videoEl.style.objectFit = 'contain';
            videoEl.style.width = drawW + 'px';
            videoEl.style.height = drawH + 'px';
            videoEl.style.maxWidth = '100%';
            videoEl.style.maxHeight = '100%';
            videoEl.style.position = 'absolute';
            videoEl.style.inset = 'auto';
            videoEl.style.left = '50%';
            videoEl.style.top = '50%';
            videoEl.style.right = 'auto';
            videoEl.style.bottom = 'auto';
            videoEl.style.margin = '0';
            videoEl.style.transform = 'translate(-50%, -50%) translateZ(0)';
        };
        place();
        if (!videoEl._fafoCappedBound) {
            videoEl._fafoCappedBound = true;
            videoEl.addEventListener('loadedmetadata', place);
            window.addEventListener('resize', place);
        }
        videoEl._fafoPlaceCapped = place;
    }

    function clearCappedCinemaSize(videoEl) {
        if (!videoEl) return;
        videoEl.style.width = '';
        videoEl.style.height = '';
        videoEl.style.maxWidth = '';
        videoEl.style.maxHeight = '';
        videoEl.style.left = '';
        videoEl.style.top = '';
        videoEl.style.right = '';
        videoEl.style.bottom = '';
        videoEl.style.inset = '';
        videoEl.style.margin = '';
        videoEl.style.transform = '';
        videoEl.style.position = '';
    }

    function getObjectFitFromConfig() {
        switch(cfg.scaling) {
            case 'scale-cover': return 'cover';
            case 'scale-contain': return 'contain';
            case 'scale-capped': return 'contain'; 
            case 'scale-center': return 'none';
            default: return 'contain';
        }
    }

    // --- 5. LAYOUT ENGINES ---

    function initLayout() {
        scene.innerHTML = '';
        if (collageInterval) clearInterval(collageInterval);
        if (photoTimeout) clearTimeout(photoTimeout);
        if (progressInterval) clearInterval(progressInterval);
        if (neonEngine) neonEngine.disconnectAudio();
        revokeCurrentBlob();

        if (cfg.layout !== 'cinema') {
            overlay.style.opacity = '0';
            if (hud.box) hud.box.classList.remove('hud-idle', 'hud-visible');
        } else {
            initHudAutoHide();
        }

        scene.className = `layout-${cfg.layout}`;
        scene.removeAttribute('style'); 
        
        if (cfg.layout === 'grid') initGrid();
        else if (cfg.layout === 'carousel') initCarousel();
        else if (cfg.layout === 'collage') initCollage(); 
        else initCinema();
    }

    function initCinema() {
        // AMBIENCE LOGIC
        if (cfg.ambiMode === 'blur') {
            ambienceVideo = document.createElement('video');
            ambienceVideo.className = 'ambience';
            ambienceVideo.muted = true;
            ambienceVideo.loop = true;
            ambienceVideo.style.filter = `blur(${cfg.ambiBlur}px) brightness(${cfg.ambiOpacity}) saturate(1.2)`;
            ambienceVideo.style.transform = `translate(-50%, -50%) scale(${cfg.ambiScale})`;
            scene.appendChild(ambienceVideo);
        } else {
            // Solid Mode: Just set background color of scene-root
            scene.style.backgroundColor = cfg.accentColor || '#000';
            // Optional: You could use ambiOpacity to control an overlay here if desired
            ambienceVideo = null;
        }

        mainVideo = document.createElement('video');
        mainVideo.id = 'bg-video';
        mainVideo.playsInline = true;
        mainVideo.autoplay = true;
        scene.appendChild(mainVideo);

        playNext();
        updateHUD();
        
        mainVideo.addEventListener('play', syncParticlePerformance);
        mainVideo.addEventListener('pause', syncParticlePerformance);

        mainVideo.onended = () => {
            if (++loopCount >= cfg.loops) {
                loopCount = 0;
                currentIdx = (currentIdx + 1) % playlist.length;
            }
            playNext();
        };

        const sync = () => {
            if(ambienceVideo && Math.abs(mainVideo.currentTime - ambienceVideo.currentTime) > 0.5) 
                ambienceVideo.currentTime = mainVideo.currentTime;
        };
        
        if(ambienceVideo) {
            mainVideo.addEventListener('play', () => ambienceVideo.play().catch(()=>{}));
            mainVideo.addEventListener('pause', () => ambienceVideo.pause());
            mainVideo.addEventListener('timeupdate', sync);
        }
    }

    async function playNext() {
        if (consecutiveErrors > 5) return; 

        if (photoTimeout) clearTimeout(photoTimeout);
        overlay.style.opacity = '1';
        
        await new Promise(r => setTimeout(r, 250));

        const item = playlist[currentIdx];
        if (!item) return; 

        const src = await getSrc(item);
        
        if (!src) {
             consecutiveErrors++;
             currentIdx = (currentIdx + 1) % playlist.length;
             setTimeout(playNext, 100);
             return;
        }

        consecutiveErrors = 0;
        const fileName = item.handle?.name || (item.url ? item.url.split('/').pop() : 'unknown');
        const overrides = cfg.overrides?.[fileName] || {};
        updateHUD();
        
        const vol = overrides.volume !== undefined ? overrides.volume : cfg.volume;
        mainVideo.volume = vol;
        mainVideo.playbackRate = cfg.playbackSpeed || 1;
        if (hud.volume) hud.volume.value = Math.round(vol * 100);

        let scaleMode = overrides.scaling || cfg.scaling;
        let objectFit = 'contain';
        if (scaleMode === 'scale-cover' || scaleMode === 'cover') objectFit = 'cover';
        else if (scaleMode === 'scale-center') objectFit = 'none';
        else if (scaleMode === 'scale-capped') objectFit = 'capped';
        
        mainVideo.classList.remove('ken-burns', 'fit-cover', 'fit-contain');
        if (objectFit === 'capped') {
            applyCappedCinemaSize(mainVideo);
        } else if (objectFit === 'none') {
            clearCappedCinemaSize(mainVideo);
            mainVideo.style.objectFit = 'none';
            mainVideo.style.width = 'auto';
            mainVideo.style.height = 'auto';
            mainVideo.style.maxWidth = '100%';
            mainVideo.style.maxHeight = '100%';
            mainVideo.style.left = '50%';
            mainVideo.style.top = '50%';
            mainVideo.style.inset = 'auto';
            mainVideo.style.transform = 'translate(-50%, -50%) translateZ(0)';
        } else {
            clearCappedCinemaSize(mainVideo);
            mainVideo.classList.add(objectFit === 'cover' ? 'fit-cover' : 'fit-contain');
            mainVideo.style.objectFit = objectFit;
            mainVideo.style.width = '100%';
            mainVideo.style.height = '100%';
            mainVideo.style.left = '0';
            mainVideo.style.top = '0';
            mainVideo.style.inset = '';
            mainVideo.style.transform = 'translateZ(0)';
        }
        
        if(ambienceVideo) ambienceVideo.src = src;

        if (item.type === 'photo') {
            mainVideo.style.background = `url("${src}") center/${objectFit === 'cover' ? 'cover' : 'contain'} no-repeat`;
            mainVideo.src = "";
            
            if(ambienceVideo) ambienceVideo.poster = src;
            if(cfg.kenburns) mainVideo.classList.add('ken-burns');
            
            overlay.style.opacity = '0';
            photoTimeout = setTimeout(() => {
                if(!isPaused) {
                    currentIdx = (currentIdx + 1) % playlist.length;
                    playNext();
                }
            }, cfg.photoDuration * 1000);
        } else {
            mainVideo.src = src;
            mainVideo.style.background = '';
            
            try {
                await mainVideo.play();
                if(ambienceVideo) await ambienceVideo.play();
                overlay.style.opacity = '0';
                if (neonEngine) neonEngine.connectAudio(mainVideo);
                startProgressBar();
                updateHudMuteIcon();
                syncParticlePerformance();
            } catch(e) {
                console.warn("Autoplay blocked, muted retry.");
                mainVideo.muted = true;
                try { 
                    await mainVideo.play(); 
                    overlay.style.opacity = '0';
                } catch(err) {
                    consecutiveErrors++;
                    playNext();
                }
            }
        }
    }

    function initGrid() {
        const { cellCount } = applyGridDimensions();

        for (let i = 0; i < cellCount; i++) {
            const cell = document.createElement('div');
            cell.className = 'grid-cell';
            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;

            v.onerror = () => loadRandomVideo(v);
            cell.appendChild(v);
            scene.appendChild(cell);
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
    }

    function initCarousel() {
        const pivot = document.createElement('div');
        pivot.className = 'carousel-pivot';
        scene.appendChild(pivot);
        
        scene.style.transform = `rotateX(${cfg.carouselTilt}deg)`;

        const count = cfg.carouselCount;
        const radius = cfg.carouselRadius;
        const fit = getObjectFitFromConfig();

        for (let i = 0; i < count; i++) {
            const card = document.createElement('div');
            card.className = 'carousel-card';
            
            // FIX: Inner wrapper for breathing animation
            const inner = document.createElement('div');
            inner.className = 'carousel-inner';
            inner.style.animationDelay = `${i * 0.2}s`;

            const v = document.createElement('video');
            v.muted = true;
            v.autoplay = true;
            v.playsInline = true;
            v.style.width = '100%';
            v.style.height = '100%';
            v.style.objectFit = fit;
            
            v.onerror = () => loadRandomVideo(v);
            
            inner.appendChild(v);
            card.appendChild(inner);
            pivot.appendChild(card);
            
            const angle = (i / count) * 360;
            // 3D Transform is now safe on the outer card
            card.style.transform = `rotateY(${angle}deg) translateZ(${radius}px)`;
            
            loadRandomVideo(v);
            v.onended = () => loadRandomVideo(v);
        }
        // Pivot spin is handled in CSS via class
        pivot.style.animationDuration = `${cfg.carouselSpeed}s`;
    }

    function initCollage() {
        const photoPlaylist = playlist.filter(item => item.type === 'photo');
        
        if (!photoPlaylist.length) {
            const msg = document.createElement('div');
            msg.textContent = "Add photos to library for Collage Mode";
            msg.style.color = "#555";
            scene.appendChild(msg);
            return;
        }

        isPaused = false;

        const spawnPhoto = async () => {
            if (isPaused) return;

            const item = photoPlaylist[Math.floor(Math.random() * photoPlaylist.length)];
            const src = await getSrc(item);
            if (!src) return;

            const img = document.createElement('img');
            img.src = src;
            img.className = 'collage-card';
            
            const top = Math.random() * 80;
            const left = Math.random() * 80;
            const rot = (Math.random() - 0.5) * 40;
            
            img.style.top = `${top}%`;
            img.style.left = `${left}%`;
            img.style.transform = `rotate(${rot}deg) scale(0.8)`;
            
            img.style.zIndex = Date.now() % 10000; 

            scene.appendChild(img);

            requestAnimationFrame(() => {
                img.classList.add('visible');
                img.style.transform = `rotate(${rot}deg) scale(1)`;
            });

            setTimeout(() => {
                img.style.opacity = 0;
                setTimeout(() => img.remove(), 2000);
            }, 60000);
        };

        spawnPhoto();
        spawnPhoto();
        spawnPhoto();
        
        collageInterval = setInterval(spawnPhoto, 3000); 
    }

    async function loadRandomVideo(v) {
        if (!playlist.length) return;
        const item = playlist[Math.floor(Math.random() * playlist.length)];
        const src = await getSrc(item);
        if (!src) return;

        if (item.type === 'photo') {
             v.src = "";
             v.poster = src;
        } else {
            v.src = src;
            v.muted = true;
            v.playsInline = true;
            try {
                await v.play();
            } catch(e) {
                // console.warn("Grid autoplay blocked, retrying muted...", e);
                v.muted = true;
                try {
                    await v.play();
                } catch(err) {
                    // console.error("Grid video failed completely", err);
                }
            }
        }
    }

    // --- 6. UTILITIES ---

    function startClock() {
        if (clockInterval) clearInterval(clockInterval);
        const tick = () => {
            const n = new Date();
            let h = n.getHours();
            if (cfg.format12h) h = h % 12 || 12;
            const m = n.getMinutes().toString().padStart(2, '0');
            const s = n.getSeconds().toString().padStart(2, '0');
            ui.clock.textContent = cfg.showSeconds ? `${h}:${m}:${s}` : `${h}:${m}`;
            if (cfg.showDate) ui.date.textContent = n.toLocaleDateString(undefined, {weekday:'long', month:'long', day:'numeric'});
        };
        tick();
        clockInterval = setInterval(tick, 1000);
    }

    async function initDB() {
        db = await new Promise(res => {
            const req = indexedDB.open('NewTabMediaDB', 3); // V3 for Playlists
            
            // Handle blocked state
            req.onblocked = () => {
               // Do nothing for New Tab, let it wait. Or refresh.
               // It's the Options page that triggers the upgrade usually.
               console.warn("Database Upgrade Pending...");
            };

            req.onupgradeneeded = e => {
                const d = e.target.result;
                ['videos', 'photos'].forEach(s => {
                    if(!d.objectStoreNames.contains(s)) d.createObjectStore(s, {autoIncrement:true});
                });
                if(!d.objectStoreNames.contains('playlists')) d.createObjectStore('playlists', {keyPath: 'id'});
            };
            req.onsuccess = () => res(req.result);
            req.onerror = () => res(null);
        });
    }

    function startHealthCheck() {
        if (healthCheckInterval) clearInterval(healthCheckInterval);
        healthCheckInterval = setInterval(() => {
            if (isPaused) return;
            const videos = document.querySelectorAll('#scene-root video');
            videos.forEach(v => {
                if (v.src && !v.paused && v.readyState < 3 && !v.ended) {
                    v.play().catch(() => {
                         if(!v.muted) { v.muted = true; v.play().catch(()=>{}); }
                    });
                }
            });
        }, 5000);
    }
});